# AI Running Coach — V59

A tela inicial da V58 com **Começar Novo Plano** e **Importar Backup** permanece. A V59 reformula o motor de progressão/regressão aeróbia. A parte principal deixa de usar blocos Z1 redundantes: progressões e regressões usam faixas ativas de Z2 e, quando o atleta atende aos critérios, Z3 controlada. Aquecimento e desaquecimento usam a extremidade mais rápida da Z1 (80–100% da faixa operacional); transições confortáveis da Z2 usam 0–20%.

## Identificação
- `versionCode = 59`, `versionName = V59`.
- `engineVersion = 44`; planos V58 recalculam somente sessões de hoje em diante, preservando ciclo, semanas anteriores e sessões concluídas.
- Backup `schemaVersion = 2`; formato e validação mantidos.

## Estrutura dos treinos
- Progressivo elegível: Z2 confortável (0–20%) → Z2 mais rápida (20–100%) → Z3 controlada (0–40%).
- Regressivo elegível: sequência inversa, Z3 controlada → Z2 mais rápida → Z2 confortável.
- Sem elegibilidade para Z3: progressão/regressão permanece dentro de Z2 (0–20% ↔ 20–65%).
- Longão mantém predominância Z2; Z3 continua restrita a perfis avançados/elite com volume semanal ≥25 km, maior corrida recente ≥12 km, longão planejado ≥8 km, zonas válidas e recuperação adequada. A parcela Z3 fica limitada a 12% da parte principal.
- Aquecimento e desaquecimento: Z1 80–100%, sem reutilizar Z1 como etapa de progressão/regressão.
- Segmentos preservam soma exata da distância prescrita, com distribuição em décimos de quilômetro. Sessões curtas demais para blocos múltiplos permanecem contínuas em Z2.

## Preservação e compatibilidade
- Frequência semanal, backup, importação GPX/FIT/TCX, feedbacks, calibração independente Z1–Z3 e recálculo com preservação de ciclo permanecem.
- O motor sobe para versão 44 para solicitar atualização de sessões futuras/atuais dos planos V58; sessões históricas e concluídas não são reescritas.
- Backup identifica `appVersion = V59`; `schemaVersion = 2`.
