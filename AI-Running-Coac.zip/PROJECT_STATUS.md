# Status atual — AI Running Coach V59

- Entrega atual: V59 (`versionCode = 59`, `versionName = V59`, `engineVersion = 44`).
- Tela inicial mantém **Começar Novo Plano** e **Importar Backup**; a restauração usa o mesmo validador e mantém Schema 2.
- V59 revisa o motor de progressão/regressão por faixas ativas: Z1 é reservada ao aquecimento/desaquecimento e sessões regenerativas; progressões e regressões principais usam Z2 e, quando elegível, Z3. Corrida/caminhada de iniciantes é prescrita por tempo/esforço, sem forçar pace numérico.
- Aquecimento/desaquecimento Z1: 80–100% da faixa da zona (extremidade mais rápida). Transição confortável Z2: 0–20% (extremidade mais lenta).
- Progressivo elegível: Z2 0–20% → Z2 20–100% → Z3 0–40%. Regressivo é o inverso. Sem elegibilidade de Z3, usa Z2 0–20% ↔ Z2 20–65%.
- Longão permanece predominantemente Z2. Z3 continua restrita a perfil Avançado/Elite, volume semanal ≥25 km, maior corrida recente ≥12 km, sessão prescrita ≥8 km, zonas válidas, ausência de dor e recuperação adequada; no máximo 12% da parte principal.
- As distâncias dos blocos são distribuídas em décimos de quilômetro; o último bloco absorve o arredondamento para preservar o total. Sessões principais menores que 1,2 km permanecem contínuas.
- `engineVersion = 44` provoca regeneração de sessões de hoje em diante em planos V58; a âncora do ciclo, semanas passadas, treinos concluídos e feedbacks permanecem. `schemaVersion = 2` não muda.
- Backup passa a registrar `appVersion = V59`.
- Testes direcionados de lógica do motor e componentes puros: 144 aprovados, 0 falhas. Compilação Android completa ainda depende do GitHub Actions; este ambiente não contém Gradle/Android SDK.
