# AI Running Coach — Android / GitHub Build (V59)

## V59 — progressão e regressão por faixas ativas Z2/Z3
- `versionCode = 59`, `versionName = V59`, `engineVersion = 44`; schema de backup 2.
- Progressivos e regressivos aeróbios deixam Z1 fora da parte principal: usam Z2 confortável, Z2 mais rápida e Z3 controlada somente quando elegível.
- Aquecimento/desaquecimento usam Z1 80–100%; a transição confortável Z2 usa 0–20%.
- Longão permanece predominantemente Z2, mantendo Z3 curta e restrita aos critérios avançados anteriores.
- A tela inicial com **Começar Novo Plano** e **Importar Backup** permanece; backup Schema 2 não muda.
- A migração V58→V59 mantém âncora e histórico do ciclo, preserva sessões concluídas e atualiza somente hoje e datas futuras.
- Para compilar: `gradle -p android :app:testDebugUnitTest :app:assembleDebug --no-daemon`.

## Histórico
Veja `CHANGELOG.md` para alterações detalhadas das versões anteriores.
