# Relatório de testes — AI Running Coach V105

**Base:** V104  
**Versão-alvo:** V105 / motor 95 / Backup Schema 17  
**Data:** 2026-11-28

## Verificações executadas nesta sessão

| Verificação | Resultado | Escopo |
|---|---:|---|
| `PersonalRecordsEngine` em Kotlin/JVM | 3/3 | Top 3 ordenado, recorde manual sem data e rejeição de duração inválida |
| `AdaptiveZoneCalibrationEngine` + `PaceCalculator` reais com stubs mínimos de domínio | 10/10 assertions | Reset reavalia histórico anterior, lote próprio Z1, fingerprint deduplica reentrada, Lote B antecipado e créditos em cascata |
| `RaceStrategyEngine` + exportador reais com stubs mínimos de domínio | 4/4 assertions | modo progressivo, redistribuição dos trechos, soma de 5 km e sem aquecimento/desaquecimento |
| Verificação lexical de delimitadores | 12/12 arquivos | MainActivity, calibração, planejamento, estratégia, exportador, recordes e backup |
| Integridade do ZIP de origem V104 | Aprovada | `unzip -t` sem erros antes das alterações |

**Total dos harnesses focalizados:** 17/17 assertions aprovadas. Os harnesses usam os motores Kotlin reais e stubs limitados para os tipos de domínio/Android que não participam do cálculo testado; não equivalem a build completo nem a teste JUnit oficial.

## Testes adicionados/atualizados no projeto

- `AdaptiveZoneCalibrationEngineTest.kt`: reset sem descartar histórico, reprocessamento de evidências antigas, Z1 com lotes próprios A/B, deduplicação por fingerprint estável, Lote B antes do intervalo periódico e apresentação de lote ainda não confirmado.
- `RaceStrategyEngineTest.kt`: modos de execução e recálculo das fases/projeção.
- `RaceStrategyWorkoutExporterTest.kt`: apenas trechos competitivos, distância total oficial e ausência de aquecimento/desaquecimento.
- `PersonalRecordsEngineTest.kt`: classificação e top 3, recorde manual e validação de dados.
- `AppBackupCodecTest.kt`: Schema 17, recordes manuais e leitura de backups anteriores.

## Ainda não executado

- `:app:testDebugUnitTest` pela tarefa Gradle oficial.
- `:app:assembleDebug` / compilação Android Compose.
- Instalação e validação em aparelho físico.
- Fluxo visual completo de GPX/FIT/TCX e compartilhamento no Pace Coach.

O ambiente desta sessão não tem `gradle`, o projeto não contém `gradlew` e `ANDROID_HOME` não está configurado. Portanto, não há APK homologado nesta entrega. O workflow GitHub Actions deve executar:

```bash
gradle -p android :app:testDebugUnitTest :app:assembleDebug --no-daemon
```

A matriz de aceite completa do plano V105 contém 52 cenários planejados. Os 17 resultados acima são verificações focalizadas efetivamente executadas, não uma declaração de que os 52 cenários foram todos aprovados.
