# Build Android — AI Running Coach V79

Correção do erro Kotlin `Unresolved reference: manuallyPlacedSessions` aplicada em `MainActivity.kt`: o ajuste de competições agora recebe `remainingCycleSessions`, já com reagendamentos manuais reaplicados e sessões passadas filtradas. A identidade da versão permanece V79.

- `versionCode = 79`
- `versionName = V79`
- `CURRENT_ENGINE_VERSION = 69`
- Backup Schema 4 (compatível com schemas 1–4, incluindo V78 Schema 3) (`appVersion = V79`)

## GitHub Actions
1. Envie todo o conteúdo do ZIP ao repositório, preservando a estrutura.
2. Abra **Actions** e execute `build-apk` ou faça push na branch configurada.
3. Confirme `:app:testDebugUnitTest` e `:app:assembleDebug`.
4. Baixe `ai-running-coach-debug-apk` e instale em aparelho de teste.

## Principais mudanças V79
- Máscaras de entrada para data, pace, duração e distância; normalização decimal brasileira.
- Calculadora unificada para prescrições por distância, tempo ou ritmo. Sessões concluídas mostram apenas métricas reais do mesmo registro; sessões programadas mostram métricas previstas.
- Importação GPX/FIT/TCX preserva voltas, parciais calculadas e trechos fracionados. Quando a distância declarada excede a cobertura GPS disponível, o restante aparece como estimado/sem detalhe GPS, sem inventar parciais.
- Distribuição semanal com precisão de 0,1 km; o longão pode participar da progressão quando a prontidão e o histórico permitem, sem aumento obrigatório em todas as semanas.
- Revisão assistida das evidências Z1–Z5, sem alteração automática das faixas.
- Estratégia individual de prova em interface própria, com início/meio/final e comportamento distinto por distância e prioridade A/B/C.
- Cadastro/edição/exclusão de competições simplificado; agenda, plano e card da próxima prova abrem a estratégia.
- Cards do plano compactados e melhor distribuição horizontal das métricas.
- Backup Schema 4, com leitura dos schemas 1–4, incluindo V78 Schema 3.
- Treinador independente de frequência cardíaca/FCM.

## Validação local e pendência de build
Harnesses Kotlin/JVM: 10 verificações de máscaras/calculadora; cenários de estratégia para 5 km, 10 km, 10 milhas, meia-maratona e maratona; dois cenários GPX preservando 6,62 km; compilação dos motores de domínio e validação de progressão do longão. Esses testes não substituem a suíte Gradle oficial. A compilação Android/Compose e `:app:testDebugUnitTest` precisam ser confirmadas no GitHub Actions; este ambiente não possui Gradle CLI/Wrapper nem Android SDK. Consulte `BUILD_STATUS_V79.md`.


## V79
O feedback registra pace manual por bloco prescrito; blocos repetidos são expandidos na ordem de execução; análise automática por GPX e entrada de calibração Z2 foram removidas. Testes de domínio novos: `WorkoutBlockFeedbackEngineTest`.


## V79 — validação adicional
- Máscaras testadas: `14071990` → `14/07/1990`, `735` → `7:35`, `011230` → `01:12:30`, decimal com ponto/vírgula.
- Cálculo unificado testado para prescrição por distância e por tempo; métricas reais derivadas do mesmo registro.
- GPX validado com voltas explícitas + GPS e com GPS incompleto: ambos preservam o total declarado de 6,62 km, diferenciando trechos medidos e estimados.
- Estratégia de prova validada para 5 km, 10 km, 10 milhas, meia-maratona e maratona, com restrição de metas sem evidência.
- Longão usa precisão de décimos e continua limitado pela prontidão, histórico e deload; não progride obrigatoriamente em toda semana.
- Novo caminho de estratégia é separado do cadastro de provas; ordinais das telas antigas foram preservados.

### Pendência de build
O ambiente de edição não contém Gradle CLI/Wrapper nem Android SDK. Portanto, os harnesses Kotlin/JVM focados foram executados, mas a compilação Android completa e `:app:testDebugUnitTest` precisam ser confirmadas no GitHub Actions antes de instalar o APK. Consulte `BUILD_STATUS_V79.md`.
