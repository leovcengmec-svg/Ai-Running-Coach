# Build Android — AI Running Coach V98

## V98

- `versionCode = 98`, `versionName = V98`, `CURRENT_ENGINE_VERSION = 88`; Backup Schema 13 (schemas 1–12 legíveis).
- Geração do plano usa o teste fisiológico salvo, não valida formulário transitório vazio e não cria/reescreve histórico de avaliações.
- Histórico Cooper/3 km tem ID estável, editar, remover e restaurar; zonas históricas são reconstruídas pelo método correto.
- Histórico de treinos usa card único expansível com métricas compactas e menu contextual.
- Harness Kotlin/JVM isolado de gestão de avaliações: 5 cenários PASS. Testes JUnit/Gradle e APK ainda precisam do CI.

Workflow `.github/workflows/android.yml`:

```bash
gradle -p android :app:testDebugUnitTest :app:assembleDebug --no-daemon
```

O APK somente estará aprovado após o workflow `build-apk` terminar verde e publicar o artefato.

---

## V97

- `versionCode = 97`, `versionName = V97`, motor 87; Backup Schema 12.
- Feedback normal preserva a semana em andamento; carga declarada protegida, longão até 40% e piso 5 km para sessões regulares no objetivo 5 km, com exceções.
