# Build Android — AI Running Coach V102

- `versionCode = 102`, `versionName = V102`, `CURRENT_ENGINE_VERSION = 92`; Backup Schema 14 (schemas 1–14 compatíveis).
- Histórico com cabeçalho/filtros/resumo fixos, lista virtualizada em `LazyColumn`, resumo compacto e cards expansíveis.
- `HistorySnapshotEngine` constrói e indexa vínculos em `Dispatchers.Default`; a troca de filtros só aplica a faixa temporal sobre o snapshot.
- Fallback de vínculo continua restrito à vaga canônica única; data realizada isolada não cria vínculo. Registros órfãos/removidos e ações preservados.

Workflow `.github/workflows/android.yml`:

```bash
gradle -p android :app:testDebugUnitTest :app:assembleDebug --no-daemon
```

A compilação Android, os testes JUnit oficiais e o APK devem ser confirmados no GitHub Actions.

# Build Android — AI Running Coach V101

## V101

- `versionCode = 101`, `versionName = V101`, `CURRENT_ENGINE_VERSION = 91`; Backup Schema 14 (schemas 1–14 compatíveis).
- Exportação Pace Coach resiliente a variações de título; auditoria estrutural de dose e sequência preservada; erros capturados em vez de crash.
- Prévia, nome do anexo e `workoutName` normalizados para identificadores curtos por semana/treino/modalidade/variante.
- TMP diferencia Tempo Run contínuo de INT e FAR; qualidade genérica não é classificada como INT sem evidência do protocolo.
- Rotação da qualidade evita três semanas consecutivas de maior demanda quando o gate permite alternativa moderada.
- Ciclo de oito semanas e calendário da V100 preservados.

Workflow `.github/workflows/android.yml`:

```bash
gradle -p android :app:testDebugUnitTest :app:assembleDebug --no-daemon
```

A compilação Android, os testes JUnit oficiais e o APK devem ser confirmados no GitHub Actions.

---

# Build Android — AI Running Coach V100

## V100

- `versionCode = 100`, `versionName = V100`, `CURRENT_ENGINE_VERSION = 90`; Backup Schema 14 (schemas 1–13 legíveis).
- Ciclo de 8 semanas persistido e protegido durante migração de motor; semanas anteriores e semana atual preservadas; apenas sessões futuras no mesmo ciclo podem ser atualizadas.
- Backup antigo recupera a âncora com evidências de datas e número da semana; caso ambíguo exige confirmação e não abre novo ciclo silenciosamente.
- Longão continua limitado a 40%; distribuição de 17 km validada como 6,8 + 5,1 + 5,1 km.
- Calendário compacto de 68 dp, siglas INI/REG/ROD/FAR/INT/LNG/PRV/TES e ícones vetoriais coloridos unificados.
- Harnesses Kotlin/JVM focalizados de calendário/distribuição e ciclo passaram. Gradle/JUnit oficial e APK ainda precisam do CI.

Workflow `.github/workflows/android.yml`:

```bash
gradle -p android :app:testDebugUnitTest :app:assembleDebug --no-daemon
```

O APK somente estará aprovado após o workflow `build-apk` terminar verde e publicar o artefato.

---

# Build Android — AI Running Coach V99

## V99

- `versionCode = 99`, `versionName = V99`, `CURRENT_ENGINE_VERSION = 89`; Backup Schema 13 (schemas 1–13 legíveis).
- Frequência futura conta dias distintos e exclui treinos concluídos; conflitos de sessão/prova pendente são validados separadamente.
- Semana parcial não é bloqueada por participação truncada do longão; semanas futuras completas continuam sob o teto de 40%.
- Reteste sem protocolo permanece compromisso futuro com distância pendente, evitando falso erro de distância zero; a validação usa limite superior do Cooper até a escolha.
- 23 métodos de teste do calendário executados localmente com shim JUnit leve. JUnit/Gradle oficial e APK ainda precisam do CI.

Workflow `.github/workflows/android.yml`:

```bash
gradle -p android :app:testDebugUnitTest :app:assembleDebug --no-daemon
```

O APK somente estará aprovado após o workflow `build-apk` terminar verde e publicar o artefato.

---

## V97

- `versionCode = 97`, `versionName = V97`, motor 87; Backup Schema 12.
- Feedback normal preserva a semana em andamento; carga declarada protegida, longão até 40% e piso 5 km para sessões regulares no objetivo 5 km, com exceções.
