# GitHub Actions — AI Running Coach V64

## Versão
- `versionCode = 64`
- `versionName = V64`
- `engineVersion = 50`
- Backup Schema 2; campos novos opcionais e compatíveis com backups anteriores.

## Build
1. Envie o conteúdo completo do ZIP mantendo o nome `AI-Running-Coach.zip`.
2. Execute o workflow **`build-apk`** pela opção `workflow_dispatch` no GitHub Actions. Ele roda `:app:testDebugUnitTest` antes de `:app:assembleDebug`.
3. Confirme `:app:compileDebugKotlin` e o artefato APK gerado.
4. Teste migração de perfil V63→V64 (engineVersion 49→50), datas planejada/real, terreno por atividade, vínculo de resultado com prova, zonas medidas/estimadas, importação GPX/FIT/TCX até 48h, recálculo, calibração e restauração de backups com ciclos de 4–52 semanas.

## Validação no ambiente de edição
- Motores Kotlin/JVM de domínio compilados em conjunto com `kotlinc`, isolando Android/Compose e usando um modelo `Workout` de suporte porque a entidade de UI está declarada em `MainActivity.kt`.
- Harness integrado: velocidade crítica de campo, teto de carga de referência, janelas 7/28/42 dias e plano de 12 semanas para 10 km (36 sessões), com verificação de segmentos e soma das distâncias.
- Testes unitários incluem casos de regressão para prontidão, fisiologia, carga, desempenho, segmentos de pace temporizados, ultradistâncias de até 48h, escala sRPE atual/legada e restauração de ciclos de até 52 semanas. A suíte Gradle/JUnit não foi executada neste ambiente. O teste de regressão exige engineVersion 49→50 para confirmar que planos salvos solicitam atualização e perfis sem plano não são afetados.
- Gradle/Android SDK não estão disponíveis no ambiente de edição; a compilação Android completa deve ser confirmada pelo workflow.
