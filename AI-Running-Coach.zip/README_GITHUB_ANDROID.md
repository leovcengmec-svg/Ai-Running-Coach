# GitHub Actions — AI Running Coach V65

## Versão
- `versionCode = 65`
- `versionName = V65`
- `engineVersion = 51`
- Backup Schema 2; `appVersion = V65`.

## Build
1. Envie o conteúdo completo do ZIP mantendo o nome `AI-Running-Coach.zip`.
2. Execute o workflow **`build-apk`** por `workflow_dispatch`. O workflow deve rodar `:app:testDebugUnitTest` antes de `:app:assembleDebug`.
3. Confirme `:app:compileDebugKotlin`, `:app:testDebugUnitTest` e o artefato APK gerado.
4. Validar migração V64→V65 (engineVersion 50→51), reclassificação com dados demográficos ausentes no registro antigo, revisão de meta quando incompatível, onboarding de seis etapas, Cooper, 3 km (somente 18–39), distribuição por nível, iniciante com Z2 ativa quando há teste, corrida/caminhada por tolerância e backup Schema 2.

## Testes adicionados
- Limites por idade e referência fisiológica, quatro classes, conversão MET→ml/kg/min e parser `mm:ss`.
- Teste Cooper e equações 3 km com rejeição de dados fora da faixa; zonas identificadas como estimativas.
- Catálogo de metas por nível; experiência não altera classe; `Performance` usa a faixa de intensidade correta.
- Iniciante com teste válido tem bloco ativo Z2 com faixa individual; iniciante sem teste não recebe pace inventado.
- Migração engineVersion 50→51; a migração exige plano salvo e mantém perfis sem plano sem recálculo forçado.

## Limitação da validação local
O ambiente desta edição não possui Gradle wrapper executável/Android SDK configurado. Os arquivos de teste estão no projeto, mas a suíte Gradle/JUnit e o APK Android não foram executados localmente. O status final depende do workflow GitHub Actions.
