# Build Android — AI Running Coach V70

## Versão

- `versionCode = 70`
- `versionName = V70`
- `CURRENT_ENGINE_VERSION = 55`
- Backup Schema 2 (`appVersion = V70`)

## Build no GitHub Actions

1. Envie o conteúdo completo do ZIP para o repositório, preservando a estrutura de diretórios.
2. Abra a aba **Actions** e execute o workflow `build-apk` (ou aguarde o disparo automático de push, conforme a configuração do repositório).
3. Confirme que `:app:testDebugUnitTest`, `:app:assembleDebug` e `:app:assembleRelease` terminam com sucesso.
4. Baixe os APKs publicados como artefatos do workflow e instale primeiro em um aparelho de teste.

## Escopo de regressão da V70

- Backup completo e importação seletiva de histórico, com preservação de perfil/plano e deduplicação.
- Migração V69 → V70, preservando treinos concluídos e atualizando apenas sessões futuras quando o atleta solicitar o recálculo.
- Progressão semanal com deload sem perda da referência de construção e longão com limite progressivo condicionado à prontidão.
- Objetivos de completar, correr continuamente, melhorar RP e alcançar tempo-alvo; RP atual e tempo-alvo são entradas distintas.
- Exportação Pace Coach com etapas independentes e grupos de repetição pai/filho, recuperação `recovery` e distância Garmin serializada em centímetros (display em metros).
- Títulos sem códigos técnicos como `FOR01`, `INT05`, `I05` e `ROD`.
- Idade atual no perfil, idade histórica do teste preservada separadamente.

## Limitação da validação nesta edição

O repositório deve rodar os testes e o build no GitHub Actions. O ZIP de origem não contém `gradlew` e o ambiente usado para esta edição não tem Gradle/Android SDK; portanto, a compilação Android, os testes JUnit e a importação real no Pace Coach ainda não são declarados aprovados.
