# Build Android — AI Running Coach V99

## V99

- `versionCode = 99`, `versionName = V99`, `CURRENT_ENGINE_VERSION = 89`; Backup Schema 13 (schemas 1–13 legíveis).
- Frequência futura conta dias distintos e exclui treinos concluídos; conflitos de sessão/prova pendente são validados separadamente.
- Semana parcial não é bloqueada por participação truncada do longão; semanas futuras completas continuam sob o teto de 40%.
- Reteste sem protocolo permanece compromisso futuro com distância pendente, evitando falso erro de distância zero; a validação usa limite superior do Cooper até a escolha.
- 23 métodos de teste do calendário executados localmente com shim JUnit leve. JUnit/Gradle oficial e APK ainda precisam do CI.

Workflow `.github/workflows/android.yml`:

```bash
gradle -p android :app:testDebugUnitTest :app:assembleDebug --no-daemon
```

O APK somente estará aprovado após o workflow `build-apk` terminar verde e publicar o artefato.

---

## V97

- `versionCode = 97`, `versionName = V97`, motor 87; Backup Schema 12.
- Feedback normal preserva a semana em andamento; carga declarada protegida, longão até 40% e piso 5 km para sessões regulares no objetivo 5 km, com exceções.
