# AI Running Coach — Android / GitHub Build (V54)

## V54 — restauração fiel e treinos extras voluntários
- `versionCode = 54`, `versionName = V54`, `engineVersion = 41`.
- Backups V53/V52/V51 são migrados inferindo a âncora original pelas datas e números de semana das sessões quando `planStartDateIso` já tiver sido reancorado; sessões ausentes no ciclo são reconstruídas e semanas renumeradas pela âncora recuperada.
- Backup schema 2 verifica SHA-256, contagens de registros e existência da âncora do plano antes de substituir preferências.
- O treinador mostra opções e riscos para sessão extra; o corredor escolhe se insere. Sessões futuras além de 14 dias continuam disponíveis com aviso de recomendação preliminar. Alertas de dor/fadiga continuam explícitos e não substituem avaliação profissional.
- Workflow: `gradle -p android :app:testDebugUnitTest :app:assembleDebug --no-daemon`.

## V53 — correção de compilação Kotlin
- `versionCode = 53`, `versionName = V53`, `engineVersion = 39`.
- Corrige a referência a `roundToInt()` usada na apresentação da elevação importada e no histórico de feedback.

## V52 — importação de atividades e calibração individual Z1–Z3
- `versionCode = 52`, `versionName = V52`, `engineVersion = 39`.
- GPX/FIT/TCX locais são analisados na tela de feedback. Métricas inexistentes no arquivo continuam nulas; feedback subjetivo permanece separado.
- Histórico da V51 e backups anteriores são mantidos; novas fronteiras de calibração são persistidas para garantir progressão de até 15 s por atualização.
- 38 testes centrais de lógica executados manualmente nesta revisão; a validação Gradle/Android e o APK devem ser concluídos pelo workflow do GitHub.

## V51 — cartões responsivos e layout de competições padronizado
- `versionCode = 51`, `versionName = V51`, `engineVersion = 38`.
- Atualização visual da tela de competições: métricas, campos de formulário, prioridades, pílulas e cartões de provas seguem dimensões e hierarquia consistentes.
- Textos de nome, local e observações quebram linha em vez de serem truncados.
- Toda a lógica e funcionalidades da V50 permanecem preservadas; `engineVersion = 38` não foi alterado.
- Testes unitários novos: `RestDayAdaptationEngineTest`, `PlanMigrationEngineTest` e `WeeklyRangeLabelTest`.


## V45 — biblioteca de treinos e backup completo
- `versionCode = 45`, `versionName = V45`, `engineVersion = 35`.
- Corrige layout da biblioteca e exibe status real de integração dos estímulos; adiciona resistência específica de maratona à lista.
- Inclui exportação/restauração JSON completa e validada das preferências locais.

## V44 — modernização visual
- `versionCode = 44`, `versionName = V44`, `engineVersion = 35`.
- Onboarding, disponibilidade semanal, Cooper e cartão de sessão reorganizados visualmente; funcionalidades preservadas.
- Marca oficial de 1024×1024 reutilizada como drawable raster no onboarding para compatibilidade com `painterResource`; o launcher Android não foi alterado.

- `versionCode = 43`, `versionName = V43`, `engineVersion = 35`.
- Duração calculada com todos os segmentos, sem truncar blocos por distância quando também existem blocos por tempo.
- Exibição `Tempo estimado` com unidade `min`; migração das sessões estruturadas já salvas.
- `BackHandler` usa histórico de navegação e rotas-pai para retornar em vez de encerrar a aplicação em telas internas.

# AI Running Coach — Android / GitHub Build (V43)

## V42 — Tempo estimado e navegação Android
- `versionCode = 42`, `versionName = V42`, `engineVersion = 34`.
- O tempo estimado soma blocos por tempo e distância usando pace-alvo e repetições.
- Planos salvos da V41 são corrigidos no carregamento.
- O botão Voltar do Android retorna à tela anterior com fallback para telas restauradas.

## V41 — Numeração da semana e identificação amigável das exportações
- `versionCode = 41`, `versionName = V41`, `engineVersion = 33`.
- A semana parcial atual passa a ser semana 1; as semanas seguintes mantêm numeração sequencial a partir de 2.
- Sessões concluídas da semana corrente são preservadas como semana 1, e os eventos/provas usam a mesma numeração.
- Instalações V40 migram os índices antigos imediatamente e solicitam recálculo do plano.
- O preview, `UserWorkoutJson.workoutName` e o arquivo `.json` usam `S{semana}_T{treino}_{nome do treino}_{dd.MM}`.

## V40 — Compatibilidade de exportação com Pace Coach
- `versionCode = 40`, `versionName = V40`, `engineVersion = 32`.
- A exportação usa o envelope nativo `com.garmin.connect.workout.json.UserWorkoutJson` reproduzido a partir do JSON de referência do Pace Coach.
- Etapas por tempo são emitidas em ms; etapas por distância em metros; pace é convertido para `centimetersPerMillisecond`; repetições usam grupos Garmin.
- A correção da agenda da V39 permanece incluída: a semana atual não é descartada após segunda-feira.

## V37 — Motor esportivo e controle de carga
- `versionCode = 37`, `versionName = V37`.
- Regras de recuperação também são aplicadas ao calendário inicialmente gerado.
- Iniciantes/reintrodução: até três sessões de corrida/caminhada por semana.
- Carga real baseada em sessões concluídas datadas; média de 28 dias promovida somente com histórico suficiente.
- Diferenciação de sessões-chave por 5 km, 10 km, meia maratona e maratona.
- Z5 usa referência auxiliar de VAM estimada, sem alegar medida laboratorial; Z4/Z5 permanecem estimativas de campo.
- Fortalecimento complementar opcional na biblioteca; não é inserido automaticamente na agenda.
- O build APK precisa ser executado e confirmado pelo GitHub Actions.

## Build do APK debug

## V36 — Exportação JSON como arquivo anexado
- `versionCode = 36`, `versionName = V36`.
- A prescrição é gravada como arquivo `.json` UTF-8 e compartilhada com `application/json` via `EXTRA_STREAM` e `FileProvider`; não é mais enviada como `EXTRA_TEXT`.
- O `FileProvider` libera somente a pasta temporária `cache/exports/` e concede permissão temporária de leitura ao destinatário.
- A exportação nativa UserWorkoutJson substitui o contrato proprietário anterior.
- ZIP: `AI-Running-Coach.zip`.

1. Envie o conteúdo da pasta `AI-Running-Coach` para a raiz do repositório.
2. Abra **Actions → Android APK**.
3. Execute manualmente `workflow_dispatch` ou envie um commit para `main`.
4. Confirme os testes unitários e `:app:assembleDebug`.
5. Baixe o artefato `ai-running-coach-debug-apk`.

## V29
- Cadastro de competições A/B/C, calendário mensal/semanal/diário e periodização orientada pela data da prova.
- A competição substitui uma sessão na frequência semanal; taper e recuperação pós-prova são aplicados como regras conservadoras.
- A partir da V39, o ciclo inclui a semana atual mesmo quando a segunda-feira já passou; sessões anteriores a hoje não são recriadas nem deslocadas.
- Z1–Z5 iniciais calculadas em percentuais da velocidade média do Cooper, não de VO₂máx.
- Z2 refinada após pelo menos dois registros consistentes do teste da fala em rodagens fáceis/longões.
- Contrato Pace Coach 6.0.
- Disponibilidade semanal escolhida pelo atleta e dia preferido para o longão.
- Reagendamento pontual de sessões não concluídas dentro da mesma semana, com validação de colisões, provas e recuperação.
- Datas reagendadas são preservadas durante recálculo compatível do plano, inclusive quando há ajuste de evento na semana corrente.
- Calendário com categorias de treino em cores e abreviações próprias.
- 8 testes unitários do motor de agenda e matriz local com 434 combinações de disponibilidade/dia de longão.
- Unidades do produto: km e `mm:ss min/km`.

## Requisitos
- JDK 21
- Android SDK Platform 37 e Build Tools 36.0.0
- Gradle 9.6.0 (instalado no workflow)


## V31
- Tela de treino com apenas a prescrição ativa e botão compacto para trocar; a alternativa é visualizada e confirmada sob demanda.
- Motor de alternativas independente da interface, com atualização coerente de zonas e pace.
- Cinco testes de domínio adicionados para dose, zonas, calibração e preservação da sessão.
