# AI Running Coach — Android / GitHub Build (V60)

## V60 — estrutura completa das sessões e recuperação coerente
- `versionCode = 60`, `versionName = V60`, `engineVersion = 45`; backup Schema 2.
- A tela de sessão mostra todos os segmentos, sem limite de quatro itens.
- Blocos por tempo exibem duração e distância estimada; o resumo permite comparar a soma dos segmentos com o total da sessão.
- Aquecimento/desaquecimento usam Z1 80–100%; recuperações de fartlek e intervalados usam Z2 0–20% e ficam mais rápidas ou iguais ao desaquecimento Z1.
- O tempo de cada bloco por tempo usa o ponto médio da faixa ativa real, e não o pace médio da zona completa.
- Fartlek ajusta repetições ao nível e ao orçamento da sessão, com relação de recuperação estimada pelo pace individual.
- Corrida sustentada e resistência específica de maratona só incluem Z3 quando há elegibilidade; caso contrário, permanecem em Z2. Metadados internos acompanham essa decisão.
- A migração V59→V60 preserva âncora, histórico e sessões concluídas, atualizando somente sessões futuras.

Testes direcionados do motor Kotlin: 110 aprovados, 0 falhas.

## Compilar no GitHub Actions
1. Envie o ZIP completo mantendo o nome `AI-Running-Coach.zip`.
2. Execute o workflow `build-apk`.
3. Confirme o resultado de `:app:testDebugUnitTest` e `:app:assembleDebug`.
4. Instale o APK gerado e confira uma sessão aeróbia progressiva e uma sessão de qualidade com fartlek.

## Histórico
Veja `CHANGELOG.md` e `TRAINING_STRUCTURE_AUDIT_V60.md` para o histórico e a especificação das alterações.
