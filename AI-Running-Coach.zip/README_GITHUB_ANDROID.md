# Build Android — AI Running Coach V90

## V90

- `versionCode = 90`, `versionName = V90`, `CURRENT_ENGINE_VERSION = 79`; Backup Schema 5 (schemas 1–5).
- Progressão adaptativa de carga, justificativas, consolidação semanal compartilhada e categorias/status de calendário.
- Execute `:app:testDebugUnitTest` e `:app:assembleDebug` pelo workflow `build-apk`.


## V89 — calibração adaptativa
- Calibração por evidências de blocos em Z1–Z3: mínimo de 2%, teto de 3% por revisão e 5% acumulados desde teste válido.
- Revisão a cada 28 dias com confirmação explícita; Z4/Z5 mantidas ancoradas ao teste de campo.
- Monitoramento de pace com cálculo por duração/distância, filtros de exclusão explicados e contadores distintos.
- Médias de 28/42 dias com critérios de amostra; reteste na semana 8 substitui sessão intensa elegível.
- `versionCode = 89`, `versionName = V89`, `CURRENT_ENGINE_VERSION = 78`; Backup Schema 4 (leitura 1–4).
- Harness de domínio focalizado aprovado; build Gradle e APK aguardam execução do workflow abaixo.

## V88 — biblioteca de treinos
- Recuperação ativa Z2 padronizada em 0–20%, mais lenta que o esforço Z2 20–65%.
- F01/F02/F04 usam recuperação ativa Z2; F01 preserva 2 minutos entre variações.
- Longões/rodagens progressivas e regressivas usam bandas principais distintas do aquecimento e sequenciadas.
- Migração de sessões pendentes é idempotente e não modifica sessões concluídas/feedbacks.


## V87 — Estratégia de provas e metas de tempo
- Tempo-alvo informado é usado na estratégia de execução em A/B/C, sem alterar a regra de periodização de B/C.
- Split por distância, pace médio necessário, projeção ponderada, compatibilidade e alertas para metas aspiracionais/conservadoras.
- CTA explícito para recalcular após editar prova; histórico concluído permanece protegido.
- Harnesses isolados: estratégia 11/11, guia de prova 3/3 e smoke test de exportação Pace Coach B/C 2/2. A suíte Gradle completa ainda depende do GitHub Actions.


- `versionCode = 88`
- `versionName = V88`
- `CURRENT_ENGINE_VERSION = 77`
- Backup Schema 4; leitor compatível com schemas 1–4.

## V86 — recuperação de Fartlek
- Recuperações F01/F02/F04 passam a usar trote confortável Z2 20–65%, sem comparação obrigatória de interseção exata com o desaquecimento.
- F01 usa 2 minutos explícitos entre blocos; o tempo não é calculado indiretamente pela distância estimada.
- A migração corrige sessões pendentes antigas, inclusive recuperações que a V84 converteu automaticamente em caminhada. Caminhadas intencionais, pausas passivas, treinos concluídos e feedbacks ficam preservados.
- `CURRENT_ENGINE_VERSION = 75` solicita recalibração de planos antigos pelo fluxo normal.

## V85 — consistência do volume semanal
- O total semanal, a cor do indicador da meta e a mensagem de déficit/superávit usam a mesma base: treinos + provas não canceladas.
- Exemplo: 10,9 km de treinos + 5,0 km de prova = 15,9 km; contra a meta de 17 km, o déficit correto é 1,1 km.
- A correção não altera a prescrição, as prioridades A/B/C ou o taper e não solicita recálculo de planos.
- Cinco cenários focalizados do `WeeklyVolumeSummary` aprovados em harness Kotlin/JVM. Build Android completo permanece pendente no CI.

## Correção de compilação V83
- `PrescribedWorkout` declara `originalScheduledDateIso`, usado pela proteção de sessões reagendadas na chamada de `RaceEventEngine.applyToPlan`.
- `PlanMigrationEngine.reapplyManualRescheduleDates` propaga a data originalmente planejada ao reaplicar um reagendamento.
- As conversões de `Workout` para `PrescribedWorkout` preservam o campo; o ajuste de provas calcula a identidade usando a data original quando disponível.
- Incluídos testes de regressão para persistência da data original e proteção contra substituição por prova.
- `CURRENT_ENGINE_VERSION = 73` e Backup Schema 4 mantidos naquela revisão.
- O build do GitHub Actions que motivou a correção apontou `Unresolved reference: originalScheduledDateIso` em `MainActivity.kt`.

# Build Android — AI Running Coach V84 (histórico)

- `versionCode = 84`; `versionName = V84`; `CURRENT_ENGINE_VERSION = 74`.
- Recuperações entre blocos mantêm pace apenas quando a faixa de corrida se sobrepõe à faixa do desaquecimento; caso contrário, passam para caminhada sem pace-alvo.
- Migração automática corrige recuperações incompatíveis em sessões ainda não concluídas, preservando sessões concluídas e feedbacks.
- Campos de data adotam seleção controlada e movem o cursor para o fim após inserir as barras.

## Principais mudanças V82 (correções de calendário e backup)
- Primeira semana é ancorada na primeira semana civil com ao menos um dia habitual disponível; no cenário de sábado 21/11/2026 com segunda/quarta/sexta, a semana 1 começa em 23/11.
- Sessões recebem identidade determinística por ciclo/data/tipo, evitando colisão entre ciclos.
- Importação seletiva exige correspondência por identidade + data original; colisões legadas são remapeadas como histórico separado e não concluem treinos futuros.
- Feedback e reagendamento preservam a data original da sessão.

## Principais mudanças V81
- Exportação Pace Coach corrigida: 1 km = 1.000 m; duração em ms; ritmo preservado quando prescrito.
- Recuperações ativas mantêm ritmo-alvo e pausas passivas permanecem sem alvo.
- Validação impede exportação de etapas inválidas ou com faixa de ritmo incompleta.
- Seleção F01/F04 determinística por intenção e feedback de prontidão; F04 não libera Z4 sem elegibilidade de limiar.
- Tela Plano exibe evolução do volume semanal planejado.
- Âncora do ciclo começa na primeira semana com dia de treino disponível; a semana vazia de fim de semana não consome a Semana 1.
- Sessões novas usam identidade estável por ciclo/data/tipo; reagendamentos preservam a data original.
- Importação seletiva do histórico relaciona sessão e feedback por identidade + data original; IDs relativos antigos com datas diferentes são remapeados como histórico separado.

## Principais mudanças V80
- Recuperação de Fartlek F01 na parte superior da Z1 (90–100%); recuperação aeróbia Z2 em 0–30%; protocolos Z4 por caminhada e Z5 por pausa passiva.
- Títulos de etapas sem sufixos numéricos redundantes.
- Distribuição de intensidade inclui voltas explícitas e parciais agregadas de vários minutos, sem preencher lacunas GPS longas.
- GPX em quilômetros acumulados e parcial final fracionada, com reconstruções identificadas e dados desconhecidos preservados.
- Revisão de zonas abre o teste devidamente inicializado e registra decisão de manter/observar sem recalibração automática.
- Estratégia de prova exportável ao Pace Coach em `UserWorkoutJson`.
- Nomes de arquivos semanais no padrão `S1_T1_Rodagem Progressiva`, sem data.
- Perfil sem atalho de exportação de sessão.

## GitHub Actions
1. Envie todo o conteúdo do ZIP ao repositório, preservando a estrutura.
2. Abra **Actions** e execute `build-apk` ou faça push na branch configurada.
3. Confirme `:app:testDebugUnitTest` e `:app:assembleDebug`.
4. Baixe `ai-running-coach-debug-apk` e instale em aparelho de teste.

## Funcionalidades-base da V79 preservadas
- Máscaras de entrada para data, pace, duração e distância; normalização decimal brasileira.
- Calculadora unificada para prescrições por distância, tempo ou ritmo. Sessões concluídas mostram apenas métricas reais do mesmo registro; sessões programadas mostram métricas previstas.
- Importação GPX/FIT/TCX preserva voltas, parciais calculadas e trechos fracionados. Quando a distância declarada excede a cobertura GPS disponível, o restante aparece como estimado/sem detalhe GPS, sem inventar parciais.
- Distribuição semanal com precisão de 0,1 km; o longão pode participar da progressão quando a prontidão e o histórico permitem, sem aumento obrigatório em todas as semanas.
- Revisão assistida das evidências Z1–Z5, sem alteração automática das faixas.
- Estratégia individual de prova em interface própria, com início/meio/final e comportamento distinto por distância e prioridade A/B/C.
- Cadastro/edição/exclusão de competições simplificado; agenda, plano e card da próxima prova abrem a estratégia.
- Cards do plano compactados e melhor distribuição horizontal das métricas.
- Backup Schema 4, com leitura dos schemas 1–4, incluindo V78 Schema 3.
- Treinador independente de frequência cardíaca/FCM.

## Validação local e pendência de build
Após as correções da auditoria funcional anterior, o harness Kotlin/JVM executou 370 testes em 49 arquivos: 370 aprovados e 0 falhas. Para o patch de calendário/backup desta revisão, foram executadas 25 verificações adicionais isoladas de âncora, migração, identidade, colisão, reagendamento e planejado versus realizado; um harness separado aprovou também a separação de sessões no motor de feedback por bloco. Quatro arquivos com dependências Android/JSON não foram executados nesse harness (`AppBackupCodecTest.kt`, `PaceCoachExporterTest.kt`, `PaceCoachJsonAttachmentTest.kt` e `RaceStrategyWorkoutExporterTest.kt`). As regressões de mesclagem JSON foram adicionadas a `AppBackupCodecTest.kt`, mas não puderam ser executadas localmente porque a camada `org.json`/Android e o Gradle não estão disponíveis. Esses resultados não substituem a suíte Gradle oficial. A compilação Android/Compose, `:app:testDebugUnitTest` e `:app:assembleDebug` precisam ser confirmadas no GitHub Actions; este ambiente não possui Gradle CLI nem Android SDK. Consulte `BUILD_STATUS_V82.md` e `CORRECTION_REPORT_V82_CALENDAR_BACKUP.md`.


## V79
O feedback registra pace manual por bloco prescrito; blocos repetidos são expandidos na ordem de execução; análise automática por GPX e entrada de calibração Z2 foram removidas. Testes de domínio novos: `WorkoutBlockFeedbackEngineTest`.


## V79 — validação adicional
- Máscaras testadas: `14071990` → `14/07/1990`, `735` → `7:35`, `011230` → `01:12:30`, decimal com ponto/vírgula.
- Cálculo unificado testado para prescrição por distância e por tempo; métricas reais derivadas do mesmo registro.
- GPX validado com voltas explícitas + GPS e com GPS incompleto: ambos preservam o total declarado de 6,62 km, diferenciando trechos medidos e estimados.
- Estratégia de prova validada para 5 km, 10 km, 10 milhas, meia-maratona e maratona, com restrição de metas sem evidência.
- Longão usa precisão de décimos e continua limitado pela prontidão, histórico e deload; não progride obrigatoriamente em toda semana.
- Novo caminho de estratégia é separado do cadastro de provas; ordinais das telas antigas foram preservados.

### Pendência de build
O ambiente de edição não contém Gradle CLI/Wrapper nem Android SDK. Portanto, os harnesses Kotlin/JVM focados foram executados, mas a compilação Android completa e `:app:testDebugUnitTest` precisam ser confirmadas no GitHub Actions antes de instalar o APK. Consulte `BUILD_STATUS_V81.md` para o registro de validação e a pendência do build Android completo.


### Correção de compilação V79
O pacote inclui correções para os erros de compilação reportados no GitHub Actions em `MainActivity.kt` (tipos `Dp`/`Int` nos botões de prova e callback `onRaceStrategy` no card semanal). Execute novamente `:app:testDebugUnitTest` e `:app:assembleDebug`; o APK só deve ser considerado aprovado após ambos concluírem com sucesso.


Consulte `BUILD_STATUS_V80.md` para o registro de validação e a pendência do build Android completo.
