# Build Android — AI Running Coach V76

- `versionCode = 76`
- `versionName = V76`
- `CURRENT_ENGINE_VERSION = 66`
- Backup Schema 3 (`appVersion = V76`)

## GitHub Actions
1. Envie todo o conteúdo do ZIP ao repositório, preservando a estrutura.
2. Abra **Actions** e execute `build-apk` ou faça push na branch configurada.
3. Confirme `:app:testDebugUnitTest` e `:app:assembleDebug`.
4. Baixe `ai-running-coach-debug-apk` e instale em aparelho de teste.

## Regressão V76
- Qualquer faixa ativa válida 0–100% pode ser aplicada dentro das zonas; 0% lento e 100% rápido.
- Corredores com experiência de seis meses ou mais: aquecimento e desaquecimento em Z2 0–20%.
- Pausa passiva por tempo sem pace/distância; caminhada sem pace; recuperação ativa Z2 0–20%.
- Alternativas equivalentes preservam objetivo, dose e progressão com prontidão adequada.
- Backup completo oferece recalibração pelo motor atual e preserva histórico concluído.
- Backup Schema 3 e leitura de schemas 1–3.
- Treinador independente de frequência cardíaca.

## Limitação de validação local
A compilação Kotlin/JVM dos módulos de domínio e testes direcionados com runner local passaram. O runner usa um stub leve de JUnit e não substitui a suíte oficial. A suíte Gradle completa e o build Android/Compose/APK precisam ser confirmados no GitHub Actions; este ambiente não possui Gradle nem Android SDK. Consulte `BUILD_STATUS_V76.md`.
