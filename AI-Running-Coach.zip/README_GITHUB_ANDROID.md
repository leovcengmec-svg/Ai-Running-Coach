# GitHub Actions — AI Running Coach V66

## V66 — refinamento da prescrição

`versionCode=66` • `versionName=V66` • `engineVersion=53` • Backup Schema 2. O motor escolhe protocolos por objetivo, intenção e fase; F01 usa Z2–Z3 com recuperação Z1; níveis fisiológicos não bloqueiam qualidade quando carga e recuperação permitem. Após atualizar, recalcule o plano para aplicar a nova matriz, preservando o histórico.


## Versão
- `versionCode = 66`
- `versionName = V66`
- `engineVersion = 53`
- Backup Schema 2; `appVersion = V66`.

## Build
1. Envie o conteúdo completo do ZIP mantendo o nome `AI-Running-Coach.zip`.
2. Execute o workflow **`build-apk`** por `workflow_dispatch`. O workflow deve rodar `:app:testDebugUnitTest` antes de `:app:assembleDebug`.
3. Confirme `:app:compileDebugKotlin`, `:app:testDebugUnitTest` e o artefato APK gerado.
4. Validar migração V65→V66 (engineVersion 52→53), reclassificação com dados demográficos ausentes no registro antigo, revisão de meta quando incompatível, onboarding de seis etapas, Cooper, 3 km (somente 18–39), matriz de protocolos por objetivo/fase, F01/F04, Tempo Run, intervalados, nível fisiológico separado da tolerância, metas até meia maratona para Iniciante/Intermediário e backup Schema 2.

## Testes adicionados
- Limites por idade e referência fisiológica, quatro classes, conversão MET→ml/kg/min e parser `mm:ss`.
- Teste Cooper e equações 3 km com rejeição de dados fora da faixa; zonas identificadas como estimativas.
- Catálogo de metas por nível; experiência não altera classe; `Performance` usa a faixa de intensidade correta.
- Iniciante com teste válido tem bloco ativo Z2 com faixa individual; iniciante sem teste não recebe pace inventado.
- Migração engineVersion 52→53; a migração exige plano salvo e mantém perfis sem plano sem recálculo forçado.

## Limitação da validação local
O ambiente desta edição não possui Gradle wrapper executável/Android SDK configurado. Os arquivos de teste estão no projeto, mas a suíte Gradle/JUnit e o APK Android não foram executados localmente. O status final depende do workflow GitHub Actions.
