# Build Android — AI Running Coach V71

## Versão

- `versionCode = 71`
- `versionName = V71`
- `CURRENT_ENGINE_VERSION = 56`
- Backup Schema 3 (`appVersion = V71`), com leitura de schemas 1 e 2

## Build no GitHub Actions

1. Envie o conteúdo completo do ZIP para o repositório, preservando a estrutura de diretórios.
2. Abra a aba **Actions** e execute o workflow `build-apk` (ou aguarde o disparo automático de push, conforme a configuração do repositório).
3. Confirme que `:app:testDebugUnitTest`, `:app:assembleDebug` e `:app:assembleRelease` terminam com sucesso.
4. Baixe os APKs publicados como artefatos do workflow e instale primeiro em um aparelho de teste.

## Escopo de regressão da V71

- Backup completo e importação seletiva de histórico, com preservação de perfil/plano e deduplicação.
- Migração V70 → V71 e leitura de backups schema 1/2, preservando sessões concluídas, feedbacks, avaliações e dados existentes.
- Data de nascimento e referência fisiológica como fontes do perfil, com cálculo da idade na data histórica de cada avaliação.
- Perfil reorganizado; avaliação de prontidão retirada da área de gerenciamento do perfil.
- Evolução com filtros 7/28/90 dias, indicadores compactos, gráficos e unidade de elevação em metros.
- GPX: timestamp de Trackpoint prevalece sobre metadata; TCX/ FIT com fontes de data hierarquizadas; segmentos de pista separados não são conectados artificialmente.
- Amostras GPX/FIT/TCX persistem tempo/distância relativos, FC e cadência quando disponíveis; análise alinhada aos blocos e repetições prescritos.
- Histórico ordenado e apresentado pela data real, com horário local quando fornecido pelo arquivo.
- Progressão semanal com deload sem perda da referência de construção e longão com limite progressivo condicionado à prontidão.
- Objetivos de completar, correr continuamente, melhorar RP e alcançar tempo-alvo; RP atual e tempo-alvo são entradas distintas.
- Exportação Pace Coach com etapas independentes e grupos de repetição pai/filho, recuperação `recovery` e distância Garmin serializada em centímetros (display em metros).
- Títulos sem códigos técnicos como `FOR01`, `INT05`, `I05` e `ROD`.
- Idade atual no perfil, idade histórica do teste preservada separadamente.

## Limitação da validação nesta edição

Os testes de domínio para parsing GPX, segmentos separados, prioridade de timestamps e análise dos blocos foram compilados/executados em um harness Kotlin local. O ZIP de origem não contém `gradlew` e o ambiente desta edição não tem Gradle/Android SDK; portanto, a compilação Android, a suíte JUnit completa, os APKs e a importação real em Pace Coach não são declarados aprovados. Execute `:app:testDebugUnitTest`, `:app:assembleDebug` e `:app:assembleRelease` no GitHub Actions antes da distribuição.
