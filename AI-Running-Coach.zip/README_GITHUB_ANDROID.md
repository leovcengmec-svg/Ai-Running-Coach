# Build Android — AI Running Coach V73

## Versão

- `versionCode = 73`
- `versionName = V73`
- `CURRENT_ENGINE_VERSION = 58`
- Backup Schema 3 (`appVersion = V73`), com leitura de schemas 1, 2 e 3.

## Build no GitHub Actions

1. Envie o conteúdo completo do ZIP para o repositório, preservando a estrutura de diretórios.
2. Abra **Actions** e execute o workflow `build-apk` (ou aguarde o disparo de push, conforme a configuração do repositório).
3. Confirme que `:app:testDebugUnitTest`, `:app:assembleDebug` e `:app:assembleRelease` terminam com sucesso.
4. Baixe os APKs publicados como artefatos do workflow e instale primeiro em aparelho de teste.

## Escopo de regressão da V73

- Periodização dos objetivos “Completar” e “Correr continuamente” diferencia estímulos por distância sem liberar limiar/VO₂ fora dos critérios de volume, frequência e recuperação.
- Relatório de distribuição planejada da primeira semana e faixa orientativa por fase/nível/objetivo são integrados ao retorno do motor.
- Migração do motor 57 → 58; backups Schema 3 preservados e exportação identifica V73.

## Funcionalidades herdadas da V72

- Migração V72 → V73; backups V71/schema 3 continuam legíveis; leitura dos schemas 1–3 mantida.
- Treino concluído aparece no calendário na data real da atividade, preservando a data planejada como referência secundária.
- Botões de backup recebem espaçamento consistente e mantêm separadas exportação completa, restauração completa e importação seletiva.
- Cards de resumo do atleta usam altura e hierarquia uniformes.
- Nomes de sessão distinguem Rodagem e Longão do objetivo (leve, moderado, progressivo, regressivo ou específico); códigos internos não entram no título.
- Biblioteca separada em tipos de sessão, protocolos tipados e periodização por distância/nível/prioridade.
- Walk/run inspirado nos programas 5K/10K Sem Parar; caminhos de 5k e 10k diferenciam corredor que já mantém corrida contínua de quem ainda precisa progredir caminhada/trote.
- Protocolos por distância mantêm distância exata por repetição; protocolos por tempo mantêm duração exata. I07 = 5 × 600 m, com quatro recuperações de 2 min.
- Periodização específica para 5 km, 10 km, 15 km (ponte própria do aplicativo), 21,1 km e 42,2 km, utilizando as prioridades completar, correr continuamente, melhorar RP e tempo-alvo.
- Zonas são exclusivamente de pace; RPE, teste da fala e recuperação percebida são complementares. Nenhuma função de treinamento utiliza FC/FCM.
- Novas importações ignoram campos cardíacos. Valores já presentes em registros/backups antigos podem permanecer somente para compatibilidade, sem exibição ou consumo pelos motores.
- GPX/FIT/TCX analisados por timestamp, distância, duração, pace e segmentos; ausência ou baixa qualidade de amostra gera confiança reduzida/estimativa explícita.
- Exportação Pace Coach mantém estrutura tipada de etapas e grupos; protocolos nomeados passam por validação de dose.

## Limitação da validação nesta edição

A compilação Kotlin/JVM dos motores de domínio foi executada com `kotlinc`, e um harness específico confirmou a montagem de `Intervalado 5 × 600 m` em cinco estímulos de 600 m no modo DISTANCE e quatro recuperações de dois minutos. Foram incluídos testes de regressão para calendário, biblioteca, periodização e backup.

O ZIP não contém Gradle Wrapper e o ambiente de edição não dispõe de Gradle/Android SDK. Portanto, `:app:testDebugUnitTest`, `:app:assembleDebug` e `:app:assembleRelease` devem ser executados no GitHub Actions antes da aprovação final. Também são necessários teste em aparelho e importação real no Pace Coach.
