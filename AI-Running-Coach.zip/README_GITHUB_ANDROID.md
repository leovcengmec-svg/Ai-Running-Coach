# GitHub Actions — AI Running Coach V61

## Versão
- `versionCode = 61`
- `versionName = V61`
- `engineVersion = 46`
- Backup Schema 2 (compatível; não houve alteração de estrutura persistida)

## Build
1. Envie o conteúdo completo do ZIP mantendo o nome `AI-Running-Coach.zip`.
2. Execute o workflow `build-apk`.
3. Confirme `:app:compileDebugKotlin` e o artefato APK gerado.
4. Instale e teste a migração de sessões futuras e restauração de backup antes de distribuição.

## Testes locais disponíveis na revisão
- Motores Kotlin centrais compilados isoladamente com `kotlinc`.
- Execução de 256 sessões em oito distâncias-alvo, com verificação de soma dos segmentos e faixas de pace.
- Frequências de 2 a 6 sessões por semana.
- Prioridades de prova A/B/C, intervalados mistos, fartlek, objetivo Saúde e alternativa de sessão.
- Testes unitários Android/JUnit adicionados ao código, mas a suíte completa deve ser executada pelo Gradle no CI.

A compilação Android completa não foi executada no ambiente de edição porque Gradle/Android SDK não estão disponíveis localmente.
