# Build Android — AI Running Coach V100

## V100

- `versionCode = 100`, `versionName = V100`, `CURRENT_ENGINE_VERSION = 90`; Backup Schema 13 (schemas 1–13 legíveis).
- Reteste pendente usa a distância do snapshot original ou estimativa completa dos protocolos elegíveis; sem fonte confiável, a validação exata fica pendente até escolha Cooper/3 km.
- Teto de 40% mantido com precisão integral; snapshot e reteste materializado nunca são somados juntos.
- Calendário mensal dinâmico com 4/5/6 semanas, células de 68 dp e siglas REG/ROD/INT/FAR/LIM/LNG/PRV/TST.
- 34 testes Kotlin/JVM isolados aprovados; a suíte Gradle/JUnit e APK precisam passar no GitHub Actions.

Workflow `.github/workflows/android.yml`:

```bash
gradle -p android :app:testDebugUnitTest :app:assembleDebug --no-daemon
```

O APK somente estará aprovado após o workflow `build-apk` terminar verde e publicar o artefato.
