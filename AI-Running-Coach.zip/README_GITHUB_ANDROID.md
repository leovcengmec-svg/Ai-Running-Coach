# Build Android — AI Running Coach V78

Correção do erro Kotlin `Unresolved reference: manuallyPlacedSessions` aplicada em `MainActivity.kt`: o ajuste de competições agora recebe `remainingCycleSessions`, já com reagendamentos manuais reaplicados e sessões passadas filtradas. A identidade da versão permanece V78.

- `versionCode = 78`
- `versionName = V78`
- `CURRENT_ENGINE_VERSION = 68`
- Backup Schema 3 (`appVersion = V78`)

## GitHub Actions
1. Envie todo o conteúdo do ZIP ao repositório, preservando a estrutura.
2. Abra **Actions** e execute `build-apk` ou faça push na branch configurada.
3. Confirme `:app:testDebugUnitTest` e `:app:assembleDebug`.
4. Baixe `ai-running-coach-debug-apk` e instale em aparelho de teste.

## Regressão V78
- Qualquer faixa ativa válida 0–100% pode ser aplicada dentro das zonas; 0% lento e 100% rápido.
- Corredores com experiência de seis meses ou mais: aquecimento e desaquecimento em Z2 0–20%.
- Pausa passiva por tempo sem pace/distância; caminhada sem pace; recuperação ativa Z2 0–20%.
- Reagendamento manual é reaplicado por `sessionId` antes de recalibração; sessões concluídas em datas coincidentes não apagam outros treinos.
- Provas futuras exibem guia de véspera, aquecimento, largada, pacing, trecho final, abastecimento e recuperação.
- Um feedback isolado de cansaço não transforma o ciclo em recuperação; deloads programados permanecem nas semanas previstas.
- Ritmo previsto é média ponderada dos blocos; ritmo real usa feedback salvo.
- Dashboard distingue km agendados, restantes e meta semanal.
- Backup Schema 3 e leitura de schemas 1–3.
- Treinador independente de frequência cardíaca.

## Limitação de validação local
36 testes de domínio direcionados passaram em compilação Kotlin/JVM com runner local compatível com as asserções JUnit. Isso não substitui a suíte Gradle oficial. A suíte Android/Compose/APK precisa ser confirmada no GitHub Actions; este ambiente não possui Gradle nem Android SDK. Consulte `BUILD_STATUS_V78.md`.


## V78
O feedback registra pace manual por bloco prescrito; blocos repetidos são expandidos na ordem de execução; análise automática por GPX e entrada de calibração Z2 foram removidas. Testes de domínio novos: `WorkoutBlockFeedbackEngineTest`.
