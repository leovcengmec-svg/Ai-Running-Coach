# BUILD FIX — V79 Compose UI compile corrections

## Erros reportados pelo GitHub Actions

O log da execução apontou três erros em `MainActivity.kt`:

1. Linha 3820: `SecondaryButton` recebe `horizontalPadding: Int`, mas a chamada passava `5.dp` (`Dp`).
2. Linha 3821: o mesmo conflito de tipos na chamada do botão Excluir.
3. Linha 4359: `TrainingWeekCard` tentava acessar `state.openRaceStrategy(event)`, mas não possui variável `state` no escopo.

## Correções aplicadas

- Substituído `horizontalPadding = 5.dp` por `horizontalPadding = 5` nos botões Editar e Excluir. A função `SecondaryButton` converte esse inteiro para `dp` internamente.
- Adicionado o callback `onRaceStrategy: (RaceEvent) -> Unit` à assinatura de `TrainingWeekCard`.
- O chamador em `PlanScreen` fornece `onRaceStrategy = { state.openRaceStrategy(it) }`, onde `state` existe e é válido.
- A linha da agenda semanal passa a chamar `onRaceStrategy(event)`, sem acessar estado externo inexistente.

## Verificações

- Confirmado que há apenas um call site de `TrainingWeekCard` e que ele fornece o novo callback.
- Busca estática não encontrou outros argumentos `horizontalPadding` com `.dp` na `MainActivity.kt`.
- Os quatro harnesses JVM disponíveis foram executados novamente: máscaras/calculadora (10 verificações), importador (cobertura 6,62 km), estratégia de prova (5 distâncias + ausência de evidência) e distribuição de carga (18,0/18,5 km). Todos passaram.
- O ZIP foi reaberto e sua integridade verificada após a atualização.

## Limitação de validação

A compilação Android/Compose completa não foi executada neste ambiente porque não há Gradle CLI/Wrapper nem Android SDK disponíveis. A correção responde aos três diagnósticos concretos do log; `:app:testDebugUnitTest` e `:app:assembleDebug` ainda precisam passar no GitHub Actions.

## Versionamento

Mantida a identidade V79 (`versionCode = 79`, `versionName = V79`, `CURRENT_ENGINE_VERSION = 69`, Backup Schema 4). Esta é uma correção de compilação da mesma revisão, não uma nova versão funcional.
