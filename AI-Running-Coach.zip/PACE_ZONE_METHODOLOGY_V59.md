# Metodologia V59 — faixas ativas e estrutura por etapas

## Escala das faixas ativas
Percentual interno da zona: 0% = limite mais lento (maior min/km); 100% = limite mais rápido (menor min/km). Esses percentuais representam posição dentro da faixa de pace da zona, não %VO₂máx.

## Faixas de referência
- Aquecimento/desaquecimento Z1: 80–100% da faixa operacional Z1.
- Entrada/saída confortável Z2: 0–20% da faixa operacional Z2.
- Bloco Z2 mais rápido: 20–100% quando integra transição para Z3; sem Z3, 20–65%.
- Bloco inicial Z3 controlado: 0–40% da faixa operacional Z3.

## Progressão
- Elegível para Z3: Z2 (0–20%) → Z2 (20–100%) → Z3 (0–40%).
- Não elegível: Z2 (0–20%) → Z2 (20–65%).
- Progressões longas distribuem aproximadamente 44% / 44% / 12% da parte principal nas três etapas.

## Regressão
É a sequência inversa das faixas permitidas. Para longões com Z3 elegível, Z3 ocupa no máximo 12% da parte principal; para os demais, a regressão ocorre dentro de Z2.

## Longão e segurança
Z3 no longão continua condicionada a perfil avançado/elite, volume semanal ≥25 km, maior sessão recente ≥12 km, longão prescrito ≥8 km, zonas válidas, ausência de dor e recuperação/fadiga em faixa adequada. O volume de Z3 não ultrapassa 12% da parte principal.

## Distância e estrutura
Distâncias dos blocos são alocadas em décimos de quilômetro. Arredondamentos são compensados no último segmento para que a soma corresponda ao total prescrito. Partes principais menores que 1,2 km permanecem em Z2 contínua em vez de criar microblocos.

## Migração
V59 incrementa `engineVersion` para 44. Na atualização, o recálculo aplica-se a hoje e às datas futuras; a âncora, o histórico passado e as sessões concluídas permanecem. Backup permanece no Schema 2.
