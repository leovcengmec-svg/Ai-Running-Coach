# V95 — Biblioteca revisada, blocos executáveis e exportação Pace Coach

## Identificação
- Base: AI Running Coach V94.
- VersionCode: 95.
- VersionName: V95.
- CURRENT_ENGINE_VERSION: 85.
- Backup Schema: 10; o leitor continua aceitando schemas 1–9.

## Regras de regenerativo
- Iniciantes elegíveis ao protocolo caminhada/corrida usam corrida ativa em Z1 durante a semana regenerativa; as caminhadas não recebem pace de corrida.
- Corredores com mais de 11 meses de prática **consistente**, sem dor e com sinais de recuperação compatíveis, usam Z2 0–20% no aquecimento/desaquecimento e Z2 20–50% na parte principal.
- O limite de 11 meses é uma regra operacional do produto, não uma fronteira fisiológica universal.
- Perfis com mais de 11 meses, mas sem consistência/recuperação suficiente, permanecem em faixa Z2 conservadora; Z1 não é aplicada automaticamente.

## Longões
- Longão contínuo: aquecimento/desaquecimento em Z2 0–20%; principal separada, Z2 25–65% na construção e 20–45% em recuperação.
- Longão progressivo/regressivo: três etapas principais quando a distância permite. Progressivo em Z2 20–35%, 35–50%, 50–65%; regressivo na ordem inversa.
- Para volumes menores, o gerador mantém duas etapas, em vez de criar blocos artificiais muito curtos.
- Quando há evidência/condição para Z3 e dose suficiente, o estágio final pode incluir progressão controlada para Z3; a elegibilidade do atleta continua obrigatória.

## Rodagem com acelerações (strides)
- Estrutura com oito etapas explícitas: aquecimento, rodagem aeróbia, aceleração 1, recuperação 1, aceleração 2, recuperação 2, aceleração 3, desaquecimento.
- Cada aceleração tem 10–15 segundos; cada recuperação individual tem 60–90 segundos, em caminhada ou trote muito leve.
- A prescrição não utiliza mais instrução vaga como “recupere bem” sem duração/método executável.
- `durationSeconds` é persistido, migrado, mostrado e exportado em milissegundos para o Pace Coach.
- Alternativa equivalente preserva 8 etapas e tempos em segundos; alternativa mais leve substitui o estímulo por rodagem em Z2, sem acelerações extras.

## Intervalados nomeados
- Repetições e recuperações são materializadas como etapas individuais, sem grupo repetitivo compacto que esconda etapas no Pace Coach.
- I05 / 6 × 400 m: aquecimento + preparação + 6 intervalos + 5 recuperações + desaquecimento = 14 etapas executáveis.
- A dose pode ser reduzida quando o orçamento de volume/segurança não comporta o protocolo completo; nesse caso, o título/dose real deve refletir a redução.
- Não há recuperação final extra após a última repetição quando o protocolo define apenas recuperações entre repetições.

## Auditoria e bloqueio
- `TrainingPrescriptionAudit.validate()` verifica distância total, faixas de pace, limites da zona, nome/zona, preparação, recuperações e protocolos especiais.
- `validateExportStructure()` verifica alvo executável em cada bloco, duration/distance, pace completo e estruturas especiais de strides.
- `TrainingProtocolCatalog.validateNamedProtocol()` verifica dose, alternância, quantidade de repetições/recuperações, sequência e estrutura I05.
- `RunningCoachEngine.generate()` aplica a auditoria antes de devolver as sessões; prescrição inválida é bloqueada em vez de chegar à tela.
- `PaceCoachExporter` repete os gates e expande segmentos legados com `repeatCount` para passos individuais.

## Escopo da revisão
- Geradores: regenerativo, rodagem, longão contínuo, progressivo/regressivo, strides, intervalados e protocolos nomeados.
- Catálogos: 23 tipos e 13 protocolos com doses exatas; F01–F04, T01 e CC01 também entram na geração/validação de planos.
- Validação é executada na sessão efetivamente gerada, não apenas na definição do catálogo.

## Compatibilidade e proteção de dados
- `durationSeconds` permanece no modelo de sessão, snapshot de reteste e backup.
- Treinos concluídos, feedbacks e datas reais não são recalculados pela revisão da biblioteca; novas regras passam a valer para sessões geradas/atualizadas pelo motor.
- Schema 10 mantém leitura dos schemas 1–9.
