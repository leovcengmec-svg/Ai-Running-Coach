# Modelo de treinamento V23 — Cooper e zonas operacionais Z1–Z5

## 1. Teste de Cooper de 12 minutos

O Cooper é a principal referência de campo para a calibração inicial e periódica. O atleta registra a distância total percorrida em km durante 12 minutos contínuos e a data real da avaliação, preferencialmente em percurso plano, medido e com condições semelhantes entre avaliações. O onboarding aceita resultados com até 56 dias; resultados mais antigos pedem novo teste.

Equação estimativa clássica:

`VO₂máx estimado = 22,351 × distância em km − 11,288`

O pace médio do teste é calculado a partir do tempo fixo de 12 minutos e apresentado como `mm:ss min/km`. A VAM/MAS é utilizada internamente como referência de velocidade aeróbia máxima para produzir as faixas; não é mostrada ao atleta como unidade de velocidade.

O Cooper não é exame laboratorial e não mede diretamente os limiares LT1/LT2. A relação entre o teste, a velocidade aeróbia máxima e o limiar foi estudada em corredores recreativos e treinados, mas uma amostra de 33 participantes não justifica tratar a equação como verdade individual sem incerteza.

## 2. Zonas operacionais do produto

A V23 usa cinco zonas contínuas, baseadas em frações de referência aeróbia estimada. A velocidade é convertida para pace e o resultado é apresentado exclusivamente como `mm:ss min/km`.

| Zona | Finalidade | Fração operacional |
|---|---|---:|
| Z1 | Regenerativa, aquecimento e desaquecimento | 55–65% |
| Z2 | Aeróbia, rodagens fáceis e longões | 65–75% |
| Z3 | Moderada e sustentável | 75–85% |
| Z4 | Limiar estimado, tempo run e intervalos controlados | 85–95% |
| Z5 | Intervalos aeróbios intensos | 95–105% |

As fronteiras são contíguas. Os percentuais são uma escolha operacional inicial do produto, não um padrão universal de zonas, nem uma alegação de que cada divisão corresponda diretamente a um limiar fisiológico medido. Z1/Z2 devem ser conferidas com conversa confortável e RPE; terreno, calor, fadiga e inclinação podem tornar o pace menos apropriado.

`AIRC_ZONES_1` identifica a versão da metodologia. Cada avaliação Cooper salva as cinco faixas em histórico; mudanças futuras de metodologia não reescrevem as zonas de avaliações antigas.

## 3. Revisão de quatro semanas

O sistema agenda uma revisão após 28 dias. O prazo é um ponto de revisão do plano, não uma ordem para realizar teste máximo a cada ciclo.

Antes de aceitar um Cooper novo, o app verifica registros recentes de dor e recuperação. O teste deve substituir uma sessão intensa, não ser adicionado à carga normal. Se o atleta não estiver pronto, a avaliação pode ser adiada e as zonas antigas continuam vigentes.

O pace-base oficial só muda quando um novo Cooper válido é salvo. O monitor de atividades usa sessões reais e comparáveis para indicar tendência, mas não muda zonas a partir de uma corrida isolada.

## 4. Monitoramento das atividades

O feedback armazena distância real em km, tempo decorrido, pace calculado em mm:ss min/km, tipo de sessão, esforço percebido, sensação e dor. O monitor compara rodagens leves do mesmo tipo em janela recente e exige quatro ou mais sessões comparáveis. Dias quentes, subidas, terreno e condições diferentes podem explicar alterações de pace; a tendência não é um diagnóstico.

## 5. Biblioteca de sessões

A biblioteca reconhece rodagem regenerativa, rodagem aeróbia, longão, corrida moderada, tempo run, intervalos de limiar, intervalado VO₂máx, fartlek, subidas, strides e progressiva. O motor escolhe apenas o que é compatível com o histórico e com a fase. Subidas não são geradas automaticamente enquanto o perfil não registrar disponibilidade de percurso inclinado.

## 6. Unidade e integração

Padrão obrigatório:
- Distância em km.
- Pace em mm:ss min/km.
- Tempo decorrido em mm:ss ou hh:mm:ss.
- Distâncias sempre em km; paces sempre em mm:ss min/km; durações de atividade em mm:ss ou hh:mm:ss.

O contrato JSON `pace-coach-workout` 4.0 transmite `distanceUnit=km`, `paceUnit=min/km`, `paceFormat=mm:ss`, o identificador da zona, a versão do modelo e faixas de pace formatadas. A calibração exportada vem do snapshot da própria sessão, preservando a referência e a data originais mesmo após um novo Cooper. Segmentos são executados por tempo ou distância. O Pace Coach precisa implementar o receptor 4.0 para a importação automática funcionar.

## 7. Fontes primárias e limites

- Cooper e predição de velocidade aeróbia máxima / segundo limiar em corredores: https://pubmed.ncbi.nlm.nih.gov/36187713/ (amostra pequena; usar como apoio, não como calibração laboratorial individual).
- Equação de Cooper, confiabilidade e limitações de estimativa: https://pubmed.ncbi.nlm.nih.gov/20647946/
- Revisão sobre testes de campo e estimativa de aptidão aeróbia: https://pmc.ncbi.nlm.nih.gov/articles/PMC4795745/
- Distribuição de intensidade de treinamento em corredores: https://pubmed.ncbi.nlm.nih.gov/34749417/
- Métodos para delimitar zonas de treinamento e limitações: https://pubmed.ncbi.nlm.nih.gov/35661059/

O resultado Cooper orienta a prescrição inicial. Para maior precisão fisiológica, testes laboratoriais de limiar ventilatório/lactato continuam sendo referência superior. O aplicativo apresenta o resultado como estimativa de campo e mantém RPE, conversa confortável e recuperação como verificações complementares.
