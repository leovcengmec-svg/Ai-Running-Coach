# AI Running Coach — Android / GitHub Build (V25)

## Build do APK debug
1. Envie o conteúdo da pasta `AI-Running-Coach` para a raiz do repositório.
2. Abra **Actions → Android APK**.
3. Execute manualmente `workflow_dispatch` ou envie um commit para `main`.
4. Aguarde `:app:testDebugUnitTest` e `:app:assembleDebug` concluírem.
5. Baixe o artefato `ai-running-coach-debug-apk`.

## V25 — Correção do modelo de zonas e integração
- Substituída a metodologia de faixas antiga por regressões Cooper para VAM e segundo limiar estimados.
- Z1–Z5 passam a seguir a proposta de cinco zonas relativas à VAM, com limites contínuos.
- Distâncias permanecem em km e ritmos em mm:ss min/km.
- Histórico e snapshots antigos são preservados; planos com modelo anterior pedem revisão.
- Contrato Pace Coach atualizado para 5.0.

## Requisitos
- JDK 21
- Android SDK Platform 37 e Build Tools 36.0.0
- Gradle 9.6.0 (instalado no workflow)

O APK release permanece sem assinatura. Para distribuição, configure o keystore e os secrets do GitHub sem incluir a chave no repositório.


- Versão Android: `versionCode 25`, `versionName V25`.
- Execute `:app:testDebugUnitTest` e `:app:assembleDebug` no GitHub Actions.
