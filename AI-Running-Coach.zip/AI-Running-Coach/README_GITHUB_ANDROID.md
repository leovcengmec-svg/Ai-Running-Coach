# AI Running Coach — Android / GitHub Build (V20)

## Build principal
O workflow `.github/workflows/android.yml` executa em push na `main`, pull request e manualmente pelo GitHub Actions. Ele:
- configura Java 21 e Android SDK;
- executa `:app:testDebugUnitTest`;
- compila o APK debug com `:app:assembleDebug`;
- publica o APK como Artifact.

## Release
O workflow `release-apk.yml` produz um APK release. O APK release continua sem assinatura enquanto não forem configurados o keystore e os secrets correspondentes no GitHub.

## Versionamento
- Nome fixo do projeto: AI Running Coach.
- Nome fixo do ZIP de entrega: `AI-Running-Coach.zip`.
- Versão Android: V20 (`versionCode = 20`).

## Atualização V20
Redesign da interface com referência Material 3 Expressive/Laps: Training Hub, painéis de indicadores, resumo de sete dias, semanas expansíveis, detalhe por blocos, dock inferior e telas de evolução/perfil atualizadas. O motor V19 e o contrato Pace Coach 1.0 foram preservados.

## Observação
O sucesso do workflow indica que os testes e a compilação foram concluídos. Ainda é necessário instalar o APK no aparelho e validar o fluxo de onboarding, dashboard, plano, calendário, detalhes de sessão e exportação para Pace Coach.
