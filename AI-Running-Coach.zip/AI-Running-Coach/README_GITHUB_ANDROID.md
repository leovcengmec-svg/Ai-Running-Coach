# AI Running Coach — Android / GitHub Build (V41)

## V41 — Numeração da semana e identificação amigável das exportações
- `versionCode = 41`, `versionName = V41`, `engineVersion = 33`.
- A semana parcial atual passa a ser semana 1; as semanas seguintes mantêm numeração sequencial a partir de 2.
- Sessões concluídas da semana corrente são preservadas como semana 1, e os eventos/provas usam a mesma numeração.
- Instalações V40 migram os índices antigos imediatamente e solicitam recálculo do plano.
- O preview, `UserWorkoutJson.workoutName` e o arquivo `.json` usam `S{semana}_T{treino}_{nome do treino}_{dd.MM}`.

## V40 — Compatibilidade de exportação com Pace Coach
- `versionCode = 40`, `versionName = V40`, `engineVersion = 32`.
- A exportação usa o envelope nativo `com.garmin.connect.workout.json.UserWorkoutJson` reproduzido a partir do JSON de referência do Pace Coach.
- Etapas por tempo são emitidas em ms; etapas por distância em metros; pace é convertido para `centimetersPerMillisecond`; repetições usam grupos Garmin.
- A correção da agenda da V39 permanece incluída: a semana atual não é descartada após segunda-feira.

## V37 — Motor esportivo e controle de carga
- `versionCode = 37`, `versionName = V37`.
- Regras de recuperação também são aplicadas ao calendário inicialmente gerado.
- Iniciantes/reintrodução: até três sessões de corrida/caminhada por semana.
- Carga real baseada em sessões concluídas datadas; média de 28 dias promovida somente com histórico suficiente.
- Diferenciação de sessões-chave por 5 km, 10 km, meia maratona e maratona.
- Z5 usa referência auxiliar de VAM estimada, sem alegar medida laboratorial; Z4/Z5 permanecem estimativas de campo.
- Fortalecimento complementar opcional na biblioteca; não é inserido automaticamente na agenda.
- O build APK precisa ser executado e confirmado pelo GitHub Actions.

## Build do APK debug

## V36 — Exportação JSON como arquivo anexado
- `versionCode = 36`, `versionName = V36`.
- A prescrição é gravada como arquivo `.json` UTF-8 e compartilhada com `application/json` via `EXTRA_STREAM` e `FileProvider`; não é mais enviada como `EXTRA_TEXT`.
- O `FileProvider` libera somente a pasta temporária `cache/exports/` e concede permissão temporária de leitura ao destinatário.
- A exportação nativa UserWorkoutJson substitui o contrato proprietário anterior.
- ZIP: `AI-Running-Coach.zip`.

1. Envie o conteúdo da pasta `AI-Running-Coach` para a raiz do repositório.
2. Abra **Actions → Android APK**.
3. Execute manualmente `workflow_dispatch` ou envie um commit para `main`.
4. Confirme os testes unitários e `:app:assembleDebug`.
5. Baixe o artefato `ai-running-coach-debug-apk`.

## V29
- Cadastro de competições A/B/C, calendário mensal/semanal/diário e periodização orientada pela data da prova.
- A competição substitui uma sessão na frequência semanal; taper e recuperação pós-prova são aplicados como regras conservadoras.
- A partir da V39, o ciclo inclui a semana atual mesmo quando a segunda-feira já passou; sessões anteriores a hoje não são recriadas nem deslocadas.
- Z1–Z5 iniciais calculadas em percentuais da velocidade média do Cooper, não de VO₂máx.
- Z2 refinada após pelo menos dois registros consistentes do teste da fala em rodagens fáceis/longões.
- Contrato Pace Coach 6.0.
- Disponibilidade semanal escolhida pelo atleta e dia preferido para o longão.
- Reagendamento pontual de sessões não concluídas dentro da mesma semana, com validação de colisões, provas e recuperação.
- Datas reagendadas são preservadas durante recálculo compatível do plano, inclusive quando há ajuste de evento na semana corrente.
- Calendário com categorias de treino em cores e abreviações próprias.
- 8 testes unitários do motor de agenda e matriz local com 434 combinações de disponibilidade/dia de longão.
- Unidades do produto: km e `mm:ss min/km`.

## Requisitos
- JDK 21
- Android SDK Platform 37 e Build Tools 36.0.0
- Gradle 9.6.0 (instalado no workflow)


## V31
- Tela de treino com apenas a prescrição ativa e botão compacto para trocar; a alternativa é visualizada e confirmada sob demanda.
- Motor de alternativas independente da interface, com atualização coerente de zonas e pace.
- Cinco testes de domínio adicionados para dose, zonas, calibração e preservação da sessão.
