# AI Running Coach — Android / GitHub Build (V26)

## Build do APK debug
1. Envie o conteúdo da pasta `AI-Running-Coach` para a raiz do repositório.
2. Abra **Actions → Android APK**.
3. Execute manualmente `workflow_dispatch` ou envie um commit para `main`.
4. Confirme os testes unitários e `:app:assembleDebug`.
5. Baixe o artefato `ai-running-coach-debug-apk`.

## V26
- Z1–Z5 iniciais calculadas em percentuais da velocidade média do Cooper, não de VO₂máx.
- Z2 refinada após pelo menos dois registros consistentes do teste da fala em rodagens fáceis/longões.
- Contrato Pace Coach 6.0.
- Unidades do produto: km e `mm:ss min/km`.

## Requisitos
- JDK 21
- Android SDK Platform 37 e Build Tools 36.0.0
- Gradle 9.6.0 (instalado no workflow)
