# AI Running Coach — Android / GitHub Build (V27)

## Build do APK debug
1. Envie o conteúdo da pasta `AI-Running-Coach` para a raiz do repositório.
2. Abra **Actions → Android APK**.
3. Execute manualmente `workflow_dispatch` ou envie um commit para `main`.
4. Confirme os testes unitários e `:app:assembleDebug`.
5. Baixe o artefato `ai-running-coach-debug-apk`.

## V27
- Cadastro de competições A/B/C, calendário mensal/semanal/diário e periodização orientada pela data da prova.
- A competição substitui uma sessão na frequência semanal; taper e recuperação pós-prova são aplicados como regras conservadoras.
- A semana atual é preservada ao iniciar o novo ciclo na próxima segunda-feira.
- Z1–Z5 iniciais calculadas em percentuais da velocidade média do Cooper, não de VO₂máx.
- Z2 refinada após pelo menos dois registros consistentes do teste da fala em rodagens fáceis/longões.
- Contrato Pace Coach 6.0.
- Unidades do produto: km e `mm:ss min/km`.

## Requisitos
- JDK 21
- Android SDK Platform 37 e Build Tools 36.0.0
- Gradle 9.6.0 (instalado no workflow)
