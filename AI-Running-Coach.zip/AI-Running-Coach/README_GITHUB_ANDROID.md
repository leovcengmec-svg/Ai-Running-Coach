# AI Running Coach — Android / GitHub Build (V23)

## Build do APK debug
1. Envie o conteúdo da pasta `AI-Running-Coach` para a raiz do repositório.
2. Abra **Actions → Android APK**.
3. Execute manualmente `workflow_dispatch` ou envie um commit para `main`.
4. Aguarde `:app:testDebugUnitTest` e `:app:assembleDebug` concluírem.
5. Baixe o artefato `ai-running-coach-debug-apk`.

## V23 — Cooper e zonas
- O Teste de Cooper de 12 minutos é a única origem oficial das zonas. A distância do teste é informada em km.
- Z1–Z5 são exibidas e exportadas exclusivamente em mm:ss min/km.
- O onboarding pede a data real do Cooper e aceita resultados dos últimos 56 dias. A revisão é programada a cada 28 dias e depende de prontidão e recuperação.
- Histórico guarda a versão do modelo e as faixas da avaliação anterior.
- O monitoramento de treinos sinaliza tendências, mas não recalibra as zonas sem novo Cooper válido.
- O contrato do Pace Coach é 4.0, com unidades declaradas km e mm:ss min/km.

## Requisitos
- JDK 21
- Android SDK Platform 37 e Build Tools 36.0.0
- Gradle 9.6.0 (instalado no workflow)

O APK release permanece sem assinatura. Para distribuição, configure o keystore e os secrets do GitHub sem incluir a chave no repositório.
