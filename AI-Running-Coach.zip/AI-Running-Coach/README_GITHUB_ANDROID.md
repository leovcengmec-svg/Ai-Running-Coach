# AI Running Coach — Android / GitHub Build

## Objetivo

Este repositório contém o aplicativo Android do AI Running Coach. O aplicativo é voltado para **prescrição inteligente de treinos**. Ele não executa o treino, não faz GPS em tempo real e não substitui o Pace Coach.

## Relação com o Pace Coach

AI Running Coach → prescreve e adapta → exporta a prescrição → Pace Coach → executa o treino.

## Gerar APK pelo GitHub

1. Crie um repositório no GitHub.
2. Envie todo o conteúdo deste projeto para o repositório.
3. Abra a aba **Actions**.
4. Execute **Android APK** manualmente em `Run workflow` ou faça um push na branch `main`.
5. Aguarde o workflow terminar.
6. Abra a execução concluída.
7. Na seção **Artifacts**, baixe `ai-running-coach-debug-apk`.
8. Extraia o ZIP e instale o APK no Android.

## Build de release

O workflow **Android Release APK** gera uma versão release não assinada. Para distribuição pública, será necessário configurar uma chave de assinatura Android e secrets no GitHub.

## Versão

V17 — versão de teste Android / GitHub Actions.
