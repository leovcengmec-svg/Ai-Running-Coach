# AI Running Coach — Android / GitHub Build (V21)

## Build do APK debug
1. Envie o conteúdo da pasta `AI-Running-Coach` para a raiz do repositório.
2. Abra **Actions → Android APK**.
3. Execute manualmente `workflow_dispatch` ou envie um commit para `main`.
4. Aguarde `:app:testDebugUnitTest` e `:app:assembleDebug` concluírem.
5. Baixe o artefato `ai-running-coach-debug-apk`.

## V21 — Alvos compatíveis com Pace Coach
- Alvo explícito por distância ou tempo em cada etapa.
- Quando houver resultado recente, pace mínimo/máximo em segundos por km e como `min/km`.
- RPE explicitamente secundário, como orientação complementar de esforço.
- Referência de ritmo opcional no onboarding: 3, 5 ou 10 km e tempo mm:ss.
- Contrato JSON de compartilhamento atualizado para 2.1; com pace calibrado, aquecimento, desaquecimento e recuperação são por tempo, enquanto blocos principais são por distância.

## Requisitos
- JDK 21
- Android SDK Platform 37 e Build Tools 36.0.0
- Gradle 9.6.0 (instalado no workflow)

O APK release permanece sem assinatura. Para distribuição, configure o keystore e os secrets do GitHub sem incluir a chave no repositório.
