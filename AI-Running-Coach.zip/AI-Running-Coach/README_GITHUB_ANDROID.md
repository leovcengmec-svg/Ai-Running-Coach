# AI Running Coach — Android / GitHub Build (V18)

## Objetivo

O aplicativo Android gera ciclos de treinamento e sessões estruturadas para o Pace Coach. Não executa treinos, não utiliza GPS em tempo real e não substitui o Pace Coach.

## Relação com o Pace Coach

AI Running Coach → planeja e prescreve → compartilha JSON versionado → Pace Coach importa e executa.

O contrato de exportação atual é `pace-coach-workout` versão `1.0`. A importação automática depende de o Pace Coach implementar esse contrato.

## Gerar APK pelo GitHub

1. Extraia `AI-Running-Coach.zip` e envie o conteúdo que está dentro da pasta `AI-Running-Coach` diretamente para a raiz do repositório GitHub. A pasta `.github/workflows` precisa ficar na raiz do repositório para que o GitHub Actions detecte os workflows; não crie uma pasta intermediária.
2. Abra a aba **Actions**.
3. Execute **Android APK** manualmente ou faça push na branch `main`.
4. O workflow executa `testDebugUnitTest` e `assembleDebug`.
5. Abra a execução concluída.
6. Na seção **Artifacts**, baixe `ai-running-coach-debug-apk`.
7. Extraia o artefato e instale o APK no Android.

## Build de release

O workflow **Android Release APK** executa os testes e gera uma versão release não assinada. Para distribuição pública, configure o keystore e os secrets de assinatura no GitHub.

## Ambiente de build

- JDK 21
- Android Gradle Plugin 9.4.0 (Kotlin integrado ao AGP)
- Compose Compiler Gradle plugin 2.4.10
- Gradle 9.6.0
- Android SDK Platform 37 (`compileSdk = 37`; `targetSdk = 36`)
- Android Build Tools 36.0.0
- Compose BOM 2026.09.00

## Versão

V18 — motor de prescrição periodizado, feedback persistente, regras de adaptação e exportação JSON versionada.
