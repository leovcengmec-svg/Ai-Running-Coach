# AI Running Coach — Android / GitHub Build (V24)

## Build do APK debug
1. Envie o conteúdo da pasta `AI-Running-Coach` para a raiz do repositório.
2. Abra **Actions → Android APK**.
3. Execute manualmente `workflow_dispatch` ou envie um commit para `main`.
4. Aguarde `:app:testDebugUnitTest` e `:app:assembleDebug` concluírem.
5. Baixe o artefato `ai-running-coach-debug-apk`.

## V24 — Correção de compilação e botões de navegação
- Corrigida a referência ausente `SecondaryButton` que impedia `compileDebugKotlin`.
- Botões lado a lado no painel de zonas agora usam largura ponderada e não extrapolam a tela.
- Mantidas as regras V23: Cooper como origem das zonas, distâncias em km e ritmos em mm:ss min/km.
- Mantidos histórico de avaliações, revisão de 28 dias e contrato Pace Coach 4.0.

## Requisitos
- JDK 21
- Android SDK Platform 37 e Build Tools 36.0.0
- Gradle 9.6.0 (instalado no workflow)

O APK release permanece sem assinatura. Para distribuição, configure o keystore e os secrets do GitHub sem incluir a chave no repositório.
