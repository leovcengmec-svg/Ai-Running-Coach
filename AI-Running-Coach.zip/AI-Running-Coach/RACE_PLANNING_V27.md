# Race planning V27 — especificação técnica

## Modelo de evento
`RaceEvent` é separado de `Workout`. A competição não é exportada como se fosse uma sessão de treino comum.

Campos: `id`, `name`, `distanceKm`, `eventDateIso`, `priority` (A/B/C), `targetTime`, `location`, `notes` e `status` (PLANNED/COMPLETED/CANCELLED).

## Escolha da prova-alvo
1. Seleciona a prova A futura mais próxima.
2. Na ausência de A futura, seleciona a prova B futura mais próxima.
3. Provas C entram no calendário e substituem uma sessão quando estiverem dentro do horizonte, mas não acionam taper.
4. A distância da prova-alvo passa a ser o `goalKm` específico na geração do ciclo.

## Janela do plano
- Sem prova A/B: ciclo padrão de 8 semanas.
- Prova dentro das próximas 16 semanas: plano da próxima segunda-feira até a semana da prova e, quando houver espaço, uma semana posterior. Se a prova estiver na semana 16, a recuperação posterior precisa ser gerada como bloco separado.
- Prova além de 16 semanas: ciclo atual de base de 16 semanas; a prova continua visível e será usada no próximo ciclo.
- Prova já ocorrida ou antes do início do próximo bloco: não cria sessões retroativas nem passa a comandar o objetivo do novo ciclo. Uma prova futura posterior pode ser selecionada como próxima meta.

## Substituição de sessão
Cada prova PLANNED no horizonte retira uma sessão da mesma semana. Se houver sessão na mesma data, essa é removida. Para prova no sábado/domingo, o longão tem prioridade; fora do fim de semana, a sessão mais próxima é substituída. Múltiplas provas na mesma semana retiram múltiplas sessões; o motor emite aviso se o número de compromissos exceder a frequência configurada.

## Taper e recuperação
- Taper inicial estimado: 7 dias para provas menores que 10 km; 10 dias para 10 km; 14 dias para meia maratona; 21 dias para maratona.
- Dentro dos 8–14/21 dias: redução conservadora do volume das sessões.
- Últimos 7 dias: estímulos fortes são substituídos por ativação leve em Z1.
- Recuperação posterior: 5 dias (provas menores que 10 km), 7 dias (10 km), 14 dias (meia) e 21 dias (maratona). Sessões afetadas são muito leves e condicionadas à ausência de dor.
- Esses valores são heurísticas de planejamento, não recomendações médicas nem regra universal. Monitoramento e feedback devem prevalecer.

## Calendário
- Uma semana parcial já em andamento é preservada ao gerar o próximo bloco. Competições futuras nessa semana podem substituir uma sessão pendente; sessões concluídas são mantidas.
- O painel de plano agrupa a semana atual separadamente das semanas do novo ciclo, evitando misturar sessões antigas concluídas com as semanas futuras.
- Mensal: grade de seis semanas, com marcações independentes de treino e prova.
- Semanal: sete dias com compromissos detalhados.
- Dia selecionado: provas e sessões do dia com acesso aos detalhes.
- Competições aparecem separadas dos treinos e podem ser editadas no gerenciador.

## Persistência e migração
- Eventos armazenados em SharedPreferences como JSON.
- V26 permanece acessível; `engineVersion < 27` sinaliza recálculo recomendado.
- Alterar eventos não reescreve sessões concluídas. O app pede recálculo explícito para sessões futuras.

## Unidades
Distâncias somente em km. Pace somente em mm:ss min/km. Tempo-alvo de prova pode ser digitado como mm:ss ou hh:mm:ss.
