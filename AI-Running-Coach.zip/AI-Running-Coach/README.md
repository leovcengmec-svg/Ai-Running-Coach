# AI Running Coach — V18

Aplicativo Android de prescrição e adaptação de treinos de corrida. O AI Running Coach planeja; o Pace Coach continua responsável pela execução do treino, GPS, áudio e registro durante a atividade.

## Arquitetura
- Android nativo com Kotlin e Jetpack Compose.
- Motor local de prescrição inspirado na arquitetura de periodização do projeto open source Laps.
- Análise local de feedback e regras de adaptação sem dependência de fabricante.
- Feedback inclui quilometragem efetivamente realizada; sem esse dado, a aderência fica sem cálculo.
- Ciclos de quatro semanas, com progressão e semana regenerativa.
- Objetivos personalizados de 1 a 100 km, além das distâncias padrão.
- Sessões estruturadas em aquecimento, bloco principal, recuperações e desaquecimento.
- Compartilhamento de prescrição em JSON versionado (`pace-coach-workout`, contrato 1.0).
- Persistência local com SharedPreferences/JSON.
- Sem GPS, cronômetro, áudio de execução ou serviço de IA externo.

## Motor de prescrição
O motor utiliza o volume semanal informado como ponto de partida conservador, limita o longão pela tolerância recente e mantém a intensidade por RPE quando não há dados individuais confiáveis de ritmo ou limiar. Dor reportada bloqueia a geração de uma prescrição normal; sinais de fadiga/baixa recuperação reduzem a carga e suspendem o treino de qualidade.

A periodização, a estrutura de geração de ciclos e as heurísticas de análise/adaptação foram desenvolvidas com referência ao projeto Laps (`https://github.com/coderang-gk/Laps`). As dependências de COROS e Google Calendar não foram incorporadas. Ver `THIRD_PARTY_NOTICES.md` e `LICENSES/LAPS-MIT.txt`.

## Integração com Pace Coach
O app compartilha cada sessão como JSON com versão de contrato. Para importação automática, o Pace Coach precisará implementar o receptor do contrato `pace-coach-workout` versão `1.0` e converter seus segmentos em blocos executáveis. Até essa integração existir, o Android oferece o compartilhamento padrão do sistema.

## Build
O workflow do GitHub Actions executa testes JVM e compila o APK debug. O build release continua sem assinatura; para distribuição, configure o keystore e os secrets do GitHub sem incluir a chave no repositório.

Versão do aplicativo: **V18** (`versionCode = 18`).

A duração total exibida/exportada é apenas uma estimativa de referência; não representa um ritmo-alvo individual.
