# AI Running Coach — V21

Aplicativo Android de prescrição e adaptação de treinos de corrida. O AI Running Coach planeja; o Pace Coach executa o treino, usa GPS/cronômetro/áudio e registra a atividade.

## V21 — Prescrição por pace

A V21 separa o alvo de execução da percepção de esforço:
- Cada bloco define alvo executável por `DISTANCE` (km) ou `TIME` (min). Com pace calibrado, aquecimento, desaquecimento e recuperações são cronometrados; rodagem, longão e estímulos principais usam distância. Sem referência de pace, todos os blocos permanecem por distância, sem presumir velocidade.
- Para blocos por tempo, a distância é apenas estimativa para resumir o volume; o Pace Coach deve obedecer ao tempo e ao pace de cada bloco, não à distância estimada.
- Quando existe um resultado recente válido, cada bloco recebe uma faixa individualizada de pace em `min/km`.
- RPE permanece como indicação auxiliar para controlar o esforço em calor, subida, fadiga ou condições atípicas; não é mais tratado como velocidade de execução.
- O atleta pode informar um resultado recente de 3, 5 ou 10 km com o tempo total no formato `mm:ss`.
- O motor projeta um equivalente de 5 km pela relação de Riegel e calcula faixas iniciais conservadoras para recuperação, rodagem fácil, longão e limiar.
- As faixas são estimativas iniciais, não limiares fisiológicos medidos; devem ser ajustadas com resultados recentes e feedback.
- Resultados com pace médio fora da faixa plausível de 3:00 a 20:00 min/km são rejeitados, em vez de serem limitados artificialmente a um pace máximo/mínimo.
- A tela de sessão e a estrutura dos blocos respeitam explicitamente o modo `TIME` ou `DISTANCE` para exibir a dose que será exportada.
- Sem teste de referência, o app não inventa um pace. A prescrição continua por distância/tempo, com aviso de ritmo não calibrado.

## Interface e arquitetura
- Android nativo em Kotlin, Jetpack Compose e Material 3.
- Interface V20 baseada em padrões visuais de Training Hub e Material 3 Expressive.
- Motor local com ciclos de oito semanas, progressão, regeneração e limites de segurança.
- Dados recentes de volume e maior sessão contínua são usados para limitar a carga.
- Feedback local e análise de sessões concluídas.
- Sem GPS, cronômetro ou áudio de execução no AI Running Coach.

## Contrato Pace Coach
O compartilhamento utiliza `pace-coach-workout`, versão **2.1**. Cada segmento contém o alvo executável (`TIME` ou `DISTANCE`); com pace calibrado, aquecimento, desaquecimento e recuperação são cronometrados. O pace é informado em segundos por quilômetro e unidade legível `min/km`, além do RPE identificado como guardrail secundário. A distância estimada dos blocos cronometrados é informativa e não deve ser executada como meta. A importação automática depende de o Pace Coach implementar o receptor correspondente; a compatibilidade exata com o seu modelo interno deverá ser confirmada ao analisar o código-fonte do Pace Coach.

## Relação com o Laps
O Laps é referência técnica e visual; o motor não foi importado integralmente. Consulte `THIRD_PARTY_NOTICES.md` e `LICENSES/LAPS-MIT.txt` para os avisos aplicáveis.

## Build
O GitHub Actions executa testes JVM e compila o APK debug. O release permanece sem assinatura até que um keystore seja configurado com GitHub Secrets.

Versão do aplicativo: **V21** (`versionCode = 21`).
