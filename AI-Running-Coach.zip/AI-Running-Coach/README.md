# AI Running Coach

Aplicativo pessoal de prescrição inteligente de treinos de corrida.

- Não executa treinos.
- Não possui GPS, cronômetro ou áudio de execução.
- Gera prescrições estruturadas para transferência ao Pace Coach.
- Projeto Android independente do Pace Coach.

## GitHub

A branch principal deve ser `main`.
O workflow `.github/workflows/android.yml` possui `workflow_dispatch`, portanto o GitHub exibirá **Run workflow** em Actions depois que o workflow estiver na branch padrão.

## Build

O workflow gera o APK Debug e publica o arquivo como artifact `ai-running-coach-debug-apk`.
