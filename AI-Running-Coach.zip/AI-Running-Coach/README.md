# AI Running Coach — V20

Aplicativo Android de prescrição e adaptação de treinos de corrida. O AI Running Coach planeja; o Pace Coach continua responsável pela execução do treino, GPS, áudio e registro durante a atividade.

## V20 — Redesign visual
A experiência foi reorganizada com referência ao Material 3 Expressive e ao Training Hub do projeto open source Laps. O redesign inclui:
- Dashboard com visão do ciclo, volume semanal planejado, indicadores do atleta, gráfico de distribuição diária e próximo treino.
- Calendário e plano em semanas expansíveis, com divisão do volume entre rodagem leve, qualidade e longão.
- Detalhe da sessão e blocos de treino em sequência visual.
- Tela Evolução com dados reais de distância registrada; nenhum gráfico é preenchido com números de demonstração.
- Perfil, histórico, feedback e compartilhamento com Pace Coach no mesmo sistema visual.
- Paleta slate/indigo escura, cartões arredondados e dock de navegação inferior.

A V20 é uma atualização da camada visual. O motor de prescrição, os dados solicitados no onboarding, os limites de segurança e o contrato JSON 1.0 foram preservados da V19.

## Arquitetura
- Android nativo com Kotlin e Jetpack Compose / Material 3.
- Motor local de prescrição com ciclo de oito semanas, organizado em dois blocos de quatro semanas.
- Volume inicial calculado a partir da média REAL das últimas quatro semanas, informada em km/semana.
- Maior sessão contínua recente informada numericamente para limitar a dose de cada sessão.
- Nível de experiência separado da carga efetivamente realizada.
- Feedback e regras locais de adaptação, sem dependência de fabricante.
- Sessões estruturadas em aquecimento, bloco principal, recuperações e desaquecimento.
- Compartilhamento de sessão como JSON versionado (`pace-coach-workout`, contrato 1.0).
- Persistência local com SharedPreferences/JSON.
- Sem GPS, cronômetro ou áudio de execução neste aplicativo.

## Relação com o projeto Laps
O Laps foi usado como referência técnica e visual. O README upstream descreve um Training Hub Material 3 Expressive com painéis de métricas, resumo diário de sete dias, planos expansíveis e dock inferior. A V20 recria esses padrões no código do AI Running Coach, sem copiar imagens ou arquivos de interface. O motor do Laps não foi importado integralmente nesta atualização; suas dependências COROS/Calendar continuam isoladas conforme a análise técnica. Consulte `THIRD_PARTY_NOTICES.md` e `LICENSES/LAPS-MIT.txt`.

## Build
O workflow do GitHub Actions executa testes JVM e compila o APK debug. O build release continua sem assinatura; para distribuição, configure o keystore e os secrets do GitHub sem incluir a chave no repositório.

Versão do aplicativo: **V20** (`versionCode = 20`).
