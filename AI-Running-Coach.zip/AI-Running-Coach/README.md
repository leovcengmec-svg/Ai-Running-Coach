# AI Running Coach — V26

Aplicativo Android de planejamento e prescrição de corrida. O AI Running Coach planeja e acompanha; o Pace Coach executa e registra.

## Regras de unidades
- Distâncias: somente km.
- Pace: somente `mm:ss min/km`.
- Tempo decorrido: `mm:ss` ou `hh:mm:ss`.
- A UI e o contrato não exibem pace como segundos/km nem distância como metros.

## Cooper e zonas
O Teste de Cooper de 12 min fornece a velocidade média de referência e VO₂máx estimado. As zonas iniciais seguem a planilha de referência em percentuais da velocidade média do Cooper: Z1 60–70%, Z2 70–80%, Z3 80–90%, Z4 90–100%, Z5 100–110%. Esses percentuais não são percentuais de VO₂máx.

VAM e segundo limiar estimados por regressões publicadas permanecem informações auxiliares; não são tratados como medidas laboratoriais nem determinam diretamente as cinco zonas.

A Z2 pode ser refinada com pelo menos dois registros consistentes do pace do trecho em que o corredor conseguia falar frases completas em sessões fáceis/longões. A personalização usa a mediana dos até três registros recentes, margem conservadora e controle de consistência. O teste da fala aproxima a região do primeiro limiar de forma grosseira e não substitui teste fisiológico.

Leia `PACE_ZONE_METHODOLOGY_V26.md` para metodologia, limitações e fontes.

## Tipos de treino
O motor estrutura rodagem regenerativa, rodagem aeróbia, longão, moderado, tempo run, intervalado de limiar, VO₂máx, fartlek, subidas, strides e corrida progressiva. RPE permanece como orientação complementar; os alvos são tempo/distância e pace `mm:ss min/km` quando calibrado.

## Pace Coach
Contrato `pace-coach-workout` 6.0. Exporta zonas, fundamento da faixa, status de calibração Z2 e blocos em km/tempo. A importação automática exige receptor correspondente no Pace Coach.

## Build Android
1. Envie o conteúdo desta pasta para a raiz do repositório.
2. Abra Actions → Android APK.
3. Execute `workflow_dispatch` ou envie um commit para `main`.
4. Confirme `:app:testDebugUnitTest` e `:app:assembleDebug`.
5. Baixe o artefato `ai-running-coach-debug-apk`.

## Versão
V26 (`versionCode = 26`, `versionName = V26`). Nome fixo do ZIP: `AI-Running-Coach.zip`.
