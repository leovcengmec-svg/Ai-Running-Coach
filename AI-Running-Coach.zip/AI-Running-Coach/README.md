# AI Running Coach — V27

Aplicativo Android de planejamento e prescrição de corrida. O AI Running Coach planeja e acompanha; o Pace Coach executa e registra.

## Regras de unidades
- Distâncias: somente km.
- Pace: somente `mm:ss min/km`.
- Tempo decorrido: `mm:ss` ou `hh:mm:ss`.
- A UI e o contrato não exibem pace como segundos/km nem distância como metros.

## Cooper e zonas
O Teste de Cooper de 12 min fornece a velocidade média de referência e VO₂máx estimado. As zonas iniciais seguem a planilha de referência em percentuais da velocidade média do Cooper: Z1 60–70%, Z2 70–80%, Z3 80–90%, Z4 90–100%, Z5 100–110%. Esses percentuais não são percentuais de VO₂máx.

VAM e segundo limiar estimados por regressões publicadas permanecem informações auxiliares; não são tratados como medidas laboratoriais nem determinam diretamente as cinco zonas.

A Z2 pode ser refinada com pelo menos dois registros consistentes do pace do trecho em que o corredor conseguia falar frases completas em sessões fáceis/longões. A personalização usa a mediana dos até três registros recentes, margem conservadora e controle de consistência. O teste da fala aproxima a região do primeiro limiar de forma grosseira e não substitui teste fisiológico.

Leia `PACE_ZONE_METHODOLOGY_V26.md` para metodologia, limitações e fontes.

## Tipos de treino
O motor estrutura rodagem regenerativa, rodagem aeróbia, longão, moderado, tempo run, intervalado de limiar, VO₂máx, fartlek, subidas, strides e corrida progressiva. RPE permanece como orientação complementar; os alvos são tempo/distância e pace `mm:ss min/km` quando calibrado.

## Competições e calendário (V27)
- Cadastro local de provas com nome, distância em km, data, prioridade A/B/C, tempo-alvo opcional, local e observações.
- A prioridade A (ou B quando não houver A futura) define a competição que orienta o próximo ciclo e fornece a distância específica do objetivo do motor.
- O plano é calculado a partir da próxima segunda-feira. Se a prova estiver no horizonte de até 16 semanas, o ciclo inclui a semana da competição e, quando couber, uma semana posterior de recuperação.
- Cada prova planejada dentro do ciclo substitui uma sessão de corrida naquela semana. Em provas de fim de semana, o longão é a sessão preferencial para substituição; em outros dias, é escolhida a sessão mais próxima.
- Provas A/B acionam redução de carga pré-prova (taper) e sessões de recuperação pós-prova. Os parâmetros são heurísticas conservadoras e precisam de validação em uso real; não substituem avaliação individual.
- Calendário mensal, semanal e detalhamento por dia mostram sessões e competições separadamente.
- Mudanças em provas após a geração do plano solicitam recálculo explícito; treinos concluídos são preservados.
- Eventos fora do horizonte atual permanecem no calendário. O ciclo atual cobre até 16 semanas; o próximo bloco deve ser gerado quando a competição entrar no horizonte. Provas distantes não alteram antecipadamente a distância-alvo do bloco-base atual.

## Pace Coach
Contrato `pace-coach-workout` 6.0. Exporta zonas, fundamento da faixa, status de calibração Z2 e blocos em km/tempo. A competição é atualmente gerenciada no AI Running Coach e exibida como evento separado; a integração de evento com o receptor do Pace Coach ainda não está implementada. A importação automática das sessões exige receptor correspondente no Pace Coach.

## Build Android
1. Envie o conteúdo desta pasta para a raiz do repositório.
2. Abra Actions → Android APK.
3. Execute `workflow_dispatch` ou envie um commit para `main`.
4. Confirme `:app:testDebugUnitTest` e `:app:assembleDebug`.
5. Baixe o artefato `ai-running-coach-debug-apk`.

## Versão
V27 (`versionCode = 27`, `versionName = V27`). Nome fixo do ZIP: `AI-Running-Coach.zip`.
