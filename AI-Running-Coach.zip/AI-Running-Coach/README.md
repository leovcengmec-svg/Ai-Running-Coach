# AI Running Coach

Personal Android app for intelligent running-workout prescription.

## Architecture
- Android UI in Kotlin/Jetpack Compose
- Local prescription motor implementing the Core V1.2 contract
- Prescription-only: no GPS, timer, audio or live execution
- Structured workouts are intended for export to Pace Coach

## Motor contract
ESTADO → OBJETIVO → NECESSIDADE → ESTÍMULO → SESSÃO → DOSE → VALIDAÇÃO → PRESCRIÇÃO

The first-plan generator uses the athlete's goal, experience level, available frequency, current weekly-volume range and longest recent run. When only a volume range is provided, the lower bound is used conservatively.
