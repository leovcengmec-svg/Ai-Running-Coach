# AI Running Coach — V24

Aplicativo Android para avaliação aeróbica, prescrição e adaptação de treinos de corrida. O AI Running Coach planeja e acompanha; o Pace Coach executa as sessões com GPS, cronômetro e áudio, e registra as atividades.

## V23 — Cooper, zonas Z1–Z5 e motor completo de treino

- O Teste de Cooper de 12 minutos passa a ser a única referência oficial para calibrar zonas de pace. O atleta informa a distância percorrida em **km** e a data real do teste (cadastro aceita resultados feitos nos últimos 56 dias).
- O aplicativo estima a condição aeróbica e calcula cinco faixas operacionais Z1–Z5. Todos os paces da interface, histórico, persistência e exportação são apresentados como **mm:ss min/km**.
- O modelo de zonas é identificado por versão. Cada Cooper salva uma fotografia das cinco faixas que valiam naquela data, preservando a referência histórica.
- A revisão ocorre a cada 28 dias. É uma oportunidade de reavaliação, não uma exigência de teste máximo. Um novo Cooper só atualiza o pace-base quando é válido e realizado com recuperação adequada.
- O monitoramento de atividades compara rodagens semelhantes, exige dados reais e sinaliza tendência. Uma sessão rápida isolada não altera as zonas.
- O catálogo identifica 11 tipos de treinamento: regenerativo, aeróbio, longão, moderado, tempo run, intervalos de limiar, intervalado VO₂máx, fartlek, subidas, strides e progressivo.
- O plano padrão contém oito semanas, com progressão controlada e semanas regenerativas. A qualidade depende da experiência, frequência, volume e tolerância recente. Subidas ficam como opção de biblioteca porque o perfil ainda não confirma disponibilidade de percurso inclinado.
- O longão é normalmente a maior sessão semanal, limitado pela tolerância recente. A parcela do longão muda conforme a frequência e é uma heurística do produto, não uma regra universal.
- O feedback registra distância e tempo efetivamente realizados; o pace é calculado e apresentado em mm:ss min/km.

## Padrão obrigatório de unidades

- Distâncias: **km** em todas as telas, relatórios, histórico e integrações.
- Pace: **mm:ss min/km** em todas as telas, armazenamento de referência, histórico e JSON.
- Duração de atividades: aceita `mm:ss` ou `hh:mm:ss`, como tempo decorrido. Esses formatos não são usados para representar pace.
- O contrato de exportação não publica valores de pace como números brutos nem utiliza distâncias em metros.

## Modelo fisiológico e limites

A equação clássica de Cooper estima VO₂máx a partir da distância percorrida em 12 minutos. As zonas Z1–Z5 deste produto são faixas operacionais ancoradas na referência aeróbia estimada; não são limiares LT1/LT2 medidos em laboratório. O resultado deve ser interpretado junto à recuperação, ao esforço percebido, ao terreno e ao histórico do atleta. Consulte `TRAINING_MODEL_V23.md`.

## Contrato Pace Coach

O compartilhamento utiliza `pace-coach-workout`, versão **4.0**. O JSON declara distâncias em km, pace como texto mm:ss min/km, o modelo de zonas, a referência Cooper e os blocos executáveis por tempo ou distância. RPE é orientação complementar. A importação automática depende de implementar o receptor compatível no Pace Coach; isso exige acesso ao código-fonte do executor.

## Build e validação

O GitHub Actions executa testes JVM e compila o APK debug. A release permanece sem assinatura até que um keystore seja configurado com GitHub Secrets. A compilação Android completa deve ser confirmada na execução do workflow do repositório.

Versão: **V23** (`versionCode = 23`). Nome fixo do pacote ZIP de entrega: `AI-Running-Coach.zip`.
