# AI Running Coach — V33

Aplicativo Android de planejamento e prescrição de corrida. O AI Running Coach planeja e acompanha; o Pace Coach executa e registra.

## Regras de unidades
- Distâncias: somente km.
- Pace: somente `mm:ss min/km`.
- Tempo decorrido: `mm:ss` ou `hh:mm:ss`.
- A UI e o contrato não exibem pace como segundos/km nem distância como metros.

## Cooper e zonas
O Teste de Cooper de 12 min fornece a velocidade média de referência e VO₂máx estimado. As zonas iniciais seguem a planilha de referência em percentuais da velocidade média do Cooper: Z1 60–70%, Z2 70–80%, Z3 80–90%, Z4 90–100%, Z5 100–110%. Esses percentuais não são percentuais de VO₂máx.

VAM e segundo limiar estimados por regressões publicadas permanecem informações auxiliares; não são tratados como medidas laboratoriais nem determinam diretamente as cinco zonas.

A Z2 pode ser refinada com pelo menos dois registros consistentes do pace do trecho em que o corredor conseguia falar frases completas em sessões fáceis/longões. A personalização usa a mediana dos até três registros recentes, margem conservadora e controle de consistência. O teste da fala aproxima a região do primeiro limiar de forma grosseira e não substitui teste fisiológico.

Leia `PACE_ZONE_METHODOLOGY_V26.md` para metodologia, limitações e fontes.

## Tipos de treino
O motor estrutura rodagem regenerativa, rodagem aeróbia, longão, moderado, tempo run, intervalado de limiar, VO₂máx, fartlek, subidas, strides e corrida progressiva. RPE permanece como orientação complementar; os alvos são tempo/distância e pace `mm:ss min/km` quando calibrado.

## Competições e calendário (V27)
- Cadastro local de provas com nome, distância em km, data, prioridade A/B/C, tempo-alvo opcional, local e observações.
- A prioridade A (ou B quando não houver A futura) define a competição que orienta o próximo ciclo e fornece a distância específica do objetivo do motor.
- O plano é calculado a partir da próxima segunda-feira. Se a prova estiver no horizonte de até 16 semanas, o ciclo inclui a semana da competição e, quando couber, uma semana posterior de recuperação.
- Cada prova planejada dentro do ciclo substitui uma sessão de corrida naquela semana. Em provas de fim de semana, o longão é a sessão preferencial para substituição; em outros dias, é escolhida a sessão mais próxima.
- Provas A/B acionam redução de carga pré-prova (taper) e sessões de recuperação pós-prova. Os parâmetros são heurísticas conservadoras e precisam de validação em uso real; não substituem avaliação individual.
- Calendário mensal, semanal e detalhamento por dia mostram sessões e competições separadamente.
- Mudanças em provas após a geração do plano solicitam recálculo explícito; treinos concluídos são preservados.
- Eventos fora do horizonte atual permanecem no calendário. O ciclo atual cobre até 16 semanas; o próximo bloco deve ser gerado quando a competição entrar no horizonte. Provas distantes não alteram antecipadamente a distância-alvo do bloco-base atual.

## Pace Coach
Contrato `pace-coach-workout` 6.0. Exporta zonas, fundamento da faixa, status de calibração Z2 e blocos em km/tempo. A competição é atualmente gerenciada no AI Running Coach e exibida como evento separado; a integração de evento com o receptor do Pace Coach ainda não está implementada. A importação automática das sessões exige receptor correspondente no Pace Coach.

## Build Android
1. Envie o conteúdo desta pasta para a raiz do repositório.
2. Abra Actions → Android APK.
3. Execute `workflow_dispatch` ou envie um commit para `main`.
4. Confirme `:app:testDebugUnitTest` e `:app:assembleDebug`.
5. Baixe o artefato `ai-running-coach-debug-apk`.

## Versão
V33 (`versionCode = 33`, `versionName = V33`). Ícone do AI Running Coach atualizado com símbolo de corredor e loop de dados em azul-ciano sobre azul-marinho; ícone adaptativo e recursos legados incluídos. Rótulo Android: `AI Running Coach`. Nome fixo do ZIP: `AI-Running-Coach.zip`.


## V29 — Disponibilidade e reagendamento
- O atleta seleciona seus dias habituais de corrida (2 a 6) e o dia preferido do longão.
- A frequência semanal passa a ser derivada dos dias selecionados; o motor distribui as sessões exatamente nesses dias.
- A agenda permite reagendar uma sessão não concluída para um dia livre da mesma semana, inclusive como exceção à disponibilidade habitual.
- O reagendamento valida colisões, provas, sessões concluídas e intervalo de recuperação entre sessões exigentes.
- A sessão preserva identidade, distância, pace e blocos; a data original fica registrada.
- Calendário mensal e agenda diária/semanal diferenciam regenerativo, aeróbio, moderado, progressivo, qualidade/limiar, intervalado, fartlek, longão e competição.

### V29 — Agenda do atleta
A V29 permite selecionar de 2 a 6 dias habituais de corrida, escolher o dia preferido do longão e reagendar uma sessão não concluída para outro dia livre dentro da mesma semana. O calendário identifica visualmente modalidades de treino. A seleção de dias é persistida localmente; mudanças de disponibilidade solicitam recálculo para redistribuir as sessões futuras.


## V30 — Duas opções por sessão
- Cada sessão futura e não concluída apresenta a opção principal recomendada e uma alternativa compatível com o objetivo geral do dia.
- A alternativa substitui a principal; nunca é somada ao volume semanal como sessão extra.
- A seleção fica salva por sessão e é preservada ao reabrir o aplicativo.
- A alternativa de qualidade troca repetições intensas por um bloco contínuo moderado em Z3; longões oferecem formato contínuo confortável; sessões fáceis oferecem formato corrida-caminhada.
- Distância total e duração estimada da sessão permanecem iguais às da prescrição principal. O pace da alternativa moderada usa a faixa Z3 da calibração quando disponível.
- Sessões concluídas não podem trocar de opção. Provas não recebem opção alternativa.
- As opções são estimadas por regras locais derivadas da sessão principal; não são duas prescrições independentes otimizadas por um segundo ciclo do motor.


## V31 — Tela de sessão simplificada
- Exibe somente o treino ativo e oferece um botão compacto para consultar/trocar a alternativa.
- Remove o resumo redundante; objetivo e estrutura permanecem em áreas distintas e mais espaçadas.
- A escolha entre principal e alternativa é confirmada em uma janela compacta e persiste por sessão.
- Alternativas atualizam os paces de cada bloco conforme a zona correta do snapshot, sem inventar valores quando falta calibração.
- A seleção continua refletida no calendário e na exportação para Pace Coach.


## V33 — Identidade visual e ícone
- Ícone redesenhado com corredor estilizado integrado a um loop de orientação/dados, em azul-ciano sobre azul-marinho.
- O símbolo do launcher não contém texto, para preservar a leitura em tamanhos pequenos.
- Nome exibido no Android confirmado como `AI Running Coach`.
- Ícones adaptativos, camadas foreground/background e variantes legacy atualizados em todas as densidades.
- `versionCode = 33`, `versionName = V33`.
