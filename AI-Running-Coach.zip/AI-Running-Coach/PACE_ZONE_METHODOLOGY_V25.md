# Metodologia de zonas de pace — V25

## Objetivo
Corrigir a metodologia `AIRC_ZONES_1`, que usava o pace médio dos 12 minutos do Cooper como se fosse a velocidade aeróbica máxima. A V25 separa pace médio do teste, VAM estimada e segundo limiar estimado.

## 1. Estimativas derivadas do Cooper
A avaliação recebe somente a distância percorrida em km durante 12 min. O aplicativo calcula internamente duas estimativas a partir de regressões publicadas no estudo *Augmented Cooper test: Biomechanical contributions to endurance performance* (Frontiers in Sports and Active Living, 2022; DOI: 10.3389/fspor.2022.935272):
- VAM estimada a partir da distância Cooper.
- Velocidade associada ao segundo limiar ventilatório estimada a partir da distância Cooper.

As regressões foram desenvolvidas com 33 corredores (18 altamente treinados e 15 recreativos). O artigo reporta ajuste elevado na amostra, mas recomenda validação em amostras mais amplas e diversas. Por isso, a V25 apresenta as saídas como estimativas de campo e converte os resultados para pace `mm:ss min/km` antes de mostrar ou exportar. Não apresenta velocidade numérica em outra unidade.

O VO₂máx continua sendo estimado separadamente pela equação clássica do Cooper. Não é confundido com VAM nem com limiar.

## 2. Cinco faixas relativas à VAM
As faixas percentuais derivam da proposta de prescrição de cinco zonas do artigo *The Relationship Between Lactate and Ventilatory Thresholds in Runners: Validity and Reliability of Exercise Test Performance Parameters* (Frontiers in Physiology, 2018; DOI: 10.3389/fphys.2018.01320):

| Zona do app | Referência da proposta | Faixa publicada relativa à VAM | Nome operacional |
|---|---|---:|---|
| Z1 | R0 | 43–56% | Regenerativa |
| Z2 | R1 | 57–68% | Aeróbia |
| Z3 | R2 | 69–79% | Moderada |
| Z4 | R3 | 80–93% | Limiar estimado |
| Z5 | R3+ | 94–105% | VO₂máx estimado |

A proposta de 2018 relaciona as faixas R0/R1 com regiões ao redor do primeiro limiar; R2 com região de estado estável de lactato; R3 com região do segundo limiar; e R3+ com região do VO₂máx. A proposta foi construída em 22 atletas homens treinados. Os autores observam que a efetividade dos planos segundo as cinco zonas ainda exigia avaliação adicional e que a validade para corredores amadores e mulheres deveria ser examinada.

## 3. Limites contínuos
A tabela científica apresenta percentuais inteiros arredondados, deixando pequenas lacunas aparentes entre os extremos. A implementação usa fronteiras compartilhadas, interpoladas entre os pares adjacentes, para que cada zona termine exatamente onde começa a próxima. Os rótulos preservam as faixas publicadas; os limites práticos em pace são arredondados para o segundo mais próximo e formatados como `mm:ss min/km`.

## 4. Uso do segundo limiar estimado
O segundo limiar calculado pela regressão de 2022 é apresentado como pace equivalente separado. A implementação verifica se ele cai dentro da faixa Z4 para a distância Cooper aceita pelo motor. Essa verificação funciona como teste de coerência do modelo combinado, não como prova de que o limiar individual foi medido.

## 5. Limitações e uso responsável
- A combinação dos dois artigos não foi validada como um único protocolo em um ensaio amplo.
- O artigo de 2018 estudou homens treinados; o resultado não deve ser tratado como limite universal para todos os corredores.
- O artigo de 2022 estudou 33 corredores e recomenda validação em grupos maiores e diversos.
- Terreno, calor, altitude, fadiga, economia de corrida e experiência podem alterar a resposta ao pace.
- O Cooper deve ser repetido em percurso medido, plano, condições semelhantes e com recuperação adequada.
- Em subidas, calor ou fadiga, esforço percebido e segurança prevalecem sobre o pace numérico.
- As zonas são estimativas operacionais e não substituem teste laboratorial com limiares ventilatórios ou lactato.

## 6. Versionamento e migração
- Modelo anterior: `AIRC_ZONES_1` (faixas baseadas indevidamente no pace médio do Cooper).
- Modelo V25: `AIRC_ZONES_2_MAS_SVT2_2018_2022`.
- Método V25: `COOPER_12_MIN_MAS_SVT2_REGRESSION_2022`.
- Cada nova avaliação salva a data, distância Cooper, pace médio, VO₂máx estimado, pace equivalente VAM, pace equivalente segundo limiar, versão do modelo e fotografia de Z1–Z5.
- Registros e treinos antigos mantêm seus snapshots originais. Planos com modelo anterior são identificados como legados e precisam ser recriados para obter novas zonas.

## Fontes
1. Cerezuela-Espejo, V. et al. (2018). *The Relationship Between Lactate and Ventilatory Thresholds in Runners: Validity and Reliability of Exercise Test Performance Parameters*. Frontiers in Physiology. https://doi.org/10.3389/fphys.2018.01320
2. *Augmented Cooper test: Biomechanical contributions to endurance performance* (2022). Frontiers in Sports and Active Living. https://doi.org/10.3389/fspor.2022.935272
