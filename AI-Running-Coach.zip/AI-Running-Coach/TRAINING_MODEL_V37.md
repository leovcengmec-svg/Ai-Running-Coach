# Modelo esportivo AI Running Coach — V37

## Objetivo
V37 fortalece a segurança e a coerência da prescrição. O motor não substitui avaliação clínica, treinador presencial ou teste fisiológico. Zonas calculadas pelo Cooper são faixas operacionais de campo, não limiares laboratoriais.

## Calendário e recuperação
- Uma sessão de qualidade só entra quando há pelo menos um dia completo sem corrida entre ela e o longão, considerando a semana cíclica. Se a disponibilidade não permitir, a qualidade é suprimida.
- Não são inseridas corridas progressivas moderadas como se fossem rodagem fácil na mesma semana que já contém uma sessão-chave. Strides são opcionais/ocasionais e não são somados em semanas com qualidade, recuperação ou iniciantes.
- Iniciantes/reentrada recebem até três sessões de corrida/caminhada por semana; corrida e caminhada são blocos temporizados com pausas explícitas.

## Carga e progressão
- A média semanal usa sessões medidas dos últimos 28 dias e só substitui o valor de perfil após pelo menos seis corridas distribuídas por três semanas ISO.
- A maior sessão real dos últimos 30 dias limita a dose individual planejada; uma margem máxima de 10% é uma heurística conservadora, não uma regra universal.
- Semanas de recuperação visam reduzir 10–20% da carga em relação à semana de desenvolvimento anterior, sempre respeitando limites de sessão, dias disponíveis e sinais do atleta.
- Dor reportada continua bloqueando a prescrição normal. Fadiga/recuperação desfavoráveis reduzem carga e suspendem qualidade.

## Especificidade
- 5 km: progressão, tempo/fartlek e, para corredores experientes com base, intervalos de alta intensidade estimada.
- 10 km: progressão, tempo/limiar estimado e alternância moderada/alta conforme experiência.
- 21,1 km: corrida moderada, tempo e intervalos controlados estimados.
- 42,2 km: resistência aeróbia específica predominantemente em Z2, com final Z3 opcional; o ritmo de maratona não é inventado sem prova/ritmo recente.
- As provas cadastradas continuam podendo ajustar o plano/taper pelo mecanismo de eventos.

## Zonas
Z1–Z4 são referências de campo derivadas de velocidade média do Cooper e teste da fala para a fronteira aeróbia. Z5 pode usar a VAM estimada por regressão de Cooper como referência auxiliar, quando plausível. Z4/Z5 não confirmam LT2 ou VO₂máx medidos. RPE e teste da fala complementam, mas não substituem, avaliação fisiológica.

## Força complementar
A biblioteca inclui duas rotinas curtas, opcionais, com volume inicial conservador. O aplicativo não as adiciona automaticamente à agenda de corrida.

## Evidências consultadas
- NHS, Couch to 5K: programa de nove semanas, três corridas semanais e alternância corrida/caminhada com recuperação entre sessões: https://www.nhs.uk/live-well/exercise/get-running-with-couch-to-5k/
- Revisão sistemática sobre distribuição de intensidade em corredores de endurance: https://pubmed.ncbi.nlm.nih.gov/34749417/
- Estudo observacional sobre aumento abrupto da distância de uma sessão e risco de lesão por sobrecarga: https://pubmed.ncbi.nlm.nih.gov/40623829/ (a associação reportada não estabelece uma regra universal de 10%).
- Revisão sistemática e meta-análise sobre treinamento de força e desempenho em corredores: https://pubmed.ncbi.nlm.nih.gov/38627351/


## V39 — calendário semanal
A ancoragem do ciclo ocorre na segunda-feira da semana atual. Ao gerar um plano no meio da semana, o motor mantém apenas sessões a partir da data de geração, sem recuperar nem deslocar sessões perdidas. A semana parcial aparece como semana em andamento; as semanas completas subsequentes são numeradas a partir de 1.
