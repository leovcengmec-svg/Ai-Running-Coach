# Third-party notices

## Laps — coderang-gk/Laps

Repository: https://github.com/coderang-gk/Laps

License: MIT. The AI Running Coach V18 engine adapts selected architectural ideas and planning heuristics from the Laps plan-generation and local coaching/adaptation architecture. It is not a drop-in copy of the complete Laps source tree. COROS API, Google Calendar integration, UI components, widgets, and other unrelated app modules were not incorporated.

The Laps MIT license notice is preserved in `LICENSES/LAPS-MIT.txt`. This notice does not claim authorship of the original Laps project or imply endorsement by its author.
