# Third-party notices

## Laps — coderang-gk/Laps

Repository: https://github.com/coderang-gk/Laps

License: MIT. Laps is acknowledged as a technical and visual reference for local-first training analysis, training-plan organization, Material 3 Expressive, Training Hub dashboards, seven-day breakdowns, expandable multi-week schedules, metric pods, and dock navigation.

V20 recreates those visual patterns using AI Running Coach components. It does not include copied Laps UI source files, screenshots, artwork, or binary assets. The existing `LICENSES/LAPS-MIT.txt` is retained because earlier project revisions include the license notice and Laps-derived technical references. Any future direct source-code adaptation must preserve the upstream copyright and MIT license text.

The AI Running Coach is an independent project and is not affiliated with, authorized, maintained, or endorsed by the Laps author, COROS, or Google.
