# AI Running Coach — status V28

## Regras permanentes
- Nome fixo do ZIP: `AI-Running-Coach.zip`; nunca renomear.
- AI Running Coach prescreve e acompanha; Pace Coach executa e registra.
- Distâncias exclusivamente em km.
- Todo pace apresentado ou exportado como `mm:ss min/km`.
- Tempo decorrido pode ser `mm:ss` ou `hh:mm:ss`; não confundir com pace.

## Base preservada da V26
- Teste de Cooper de 12 minutos, zonas Z1–Z5 e refinamento inicial da Z2 pelo teste da fala.
- O Cooper e as zonas permanecem estimativas de campo, não limiares medidos em laboratório.
- Registro de feedback, histórico de calibração, snapshots de zonas e exportação de sessões continuam preservados.

## V27 — Competições e periodização por data
- Nova entidade `RaceEvent`: nome, distância em km, data, prioridade A/B/C, tempo-alvo opcional, local, observações e estado.
- Cadastro, edição, exclusão e marcação de competição realizada.
- A prova A futura orienta o ciclo; se não existir A, uma prova B futura pode ser usada como referência. A distância da prova principal passa a ser o objetivo específico do motor.
- A janela do plano é resolvida com base na prova. Até 16 semanas de planejamento são geradas; a semana de prova e, quando possível, uma semana posterior ficam incluídas.
- Cada competição planejada dentro do horizonte substitui uma sessão do número semanal configurado. Para provas no sábado/domingo, o longão é priorizado para substituição; em outros dias, a sessão mais próxima é removida.
- Provas A/B acionam redução de carga pré-prova e recuperação pós-prova. Provas C substituem uma sessão, mas não acionam taper automaticamente.
- Taper: redução progressiva em 7–21 dias conforme distância da prova; a última semana elimina os estímulos fortes e mantém apenas ativações leves.
- Recuperação pós-prova: 5–21 dias conforme a distância; sessões afetadas são reduzidas, leves e condicionadas à ausência de dor/recuperação adequada.
- Calendário reconstruído com visualização mensal, semanal e por dia. Competições e treinos aparecem como compromissos distintos.
- Mudanças nos eventos sinalizam necessidade de recálculo; treinos concluídos são preservados. Ao iniciar o próximo ciclo numa segunda-feira futura, sessões ainda pendentes desta semana são mantidas como “Semana em andamento”; provas antes do início do novo bloco não comandam a nova meta.
- Eventos além do horizonte de 16 semanas permanecem visíveis no calendário, enquanto o ciclo atual desenvolve a base; uma prova distante não substitui o objetivo do bloco atual.

## Limitações conhecidas
- Taper e recuperação são regras conservadoras de planejamento, não protocolo individual validado clinicamente. Devem ser avaliados com histórico e feedback real.
- Evento é armazenado e mostrado no AI Running Coach; o contrato de exportação atual não envia um objeto de competição ao Pace Coach. A sincronização automática de eventos depende de um receptor correspondente no Pace Coach.
- Quando o cadastro de prova muda depois da geração do plano, é necessário selecionar explicitamente `Recalcular preparação`.
- Se a prova estiver antes da próxima segunda-feira, ela permanece no calendário e o novo bloco começa na segunda seguinte; o motor não cria sessões retroativas.

## Validação V27
- Componentes de domínio Kotlin (motor e eventos) compilados isoladamente.
- 20 smoke tests de eventos executados: validação estrita de dados/datas, janela de plano, substituição de sessão, taper, recuperação, eventos cancelados/fora do horizonte, múltiplas provas na mesma semana e frequências de 2 a 6 dias.
- 13 testes JUnit correspondentes adicionados em `RaceEventEngineTest.kt`.
- Sintaxe da MainActivity inspecionada pelo parser Kotlin; compilação Android/Compose completa ainda precisa ser confirmada pelo GitHub Actions.


## V28 — Correção de compilação Android
- Corrigido o construtor inválido `MutableSet<Int>()` em `SevenDayBreakdown`; substituído por `mutableSetOf<Int>()`, implementação mutável válida da interface `MutableSet`.
- Mantida a lógica do gráfico semanal: identifica os dias com competições para aplicar a apresentação visual correspondente.
- `versionCode = 28` e `versionName = V28`.
- A compilação Android completa deve ser confirmada pelo workflow GitHub Actions.
