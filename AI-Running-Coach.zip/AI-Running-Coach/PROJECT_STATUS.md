# AI Running Coach — Base de Teste

Nome fixo do projeto: **AI Running Coach**
Nome do repositório recomendado: **AI-Running-Coach**
Branch principal: **main**
Versão inicial de teste: **1.0.0**
Version code: **1**

O workflow de GitHub Actions está preparado para `workflow_dispatch` e build automático em `main`.
