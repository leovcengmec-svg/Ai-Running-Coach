# AI Running Coach — status V25

## Regras permanentes
- Nome do produto: AI Running Coach.
- Nome fixo do ZIP: `AI-Running-Coach.zip`; nunca renomear.
- Versão Android: V25 (`versionCode = 25`).
- AI Running Coach prescreve e acompanha; Pace Coach executa e registra.
- Distâncias exclusivamente em km.
- Todo pace apresentado ou exportado como `mm:ss min/km`.
- Duração de atividade pode ser informada como `mm:ss` ou `hh:mm:ss`; isso não é formato de pace.
- Não apresentar velocidades numéricas em outras unidades nem distâncias em metros em telas, histórico, relatório ou JSON.

## V25 — Modelo de zonas revisado
- Substituído o cálculo V24 que dividia o pace médio do Cooper em faixas percentuais. O pace médio do teste não é a VAM.
- A distância Cooper de 12 minutos estima VAM e segundo limiar por regressões publicadas em 2022.
- Z1–Z5 utilizam as cinco faixas relativas à VAM propostas por Cerezuela-Espejo et al. (2018): R0 (43–56%), R1 (57–68%), R2 (69–79%), R3 (80–93%) e R3+ (94–105%).
- Fronteiras internas interpoladas entre as faixas publicadas para manter limites compartilhados e contínuos após arredondamento para `mm:ss`.
- O sistema apresenta pace médio do Cooper, pace equivalente da VAM, pace equivalente do segundo limiar e VO₂máx estimado separadamente.
- VAM e segundo limiar são estimativas de campo; não são avaliações laboratoriais. O estudo de zonas de 2018 foi feito com 22 homens treinados e aponta que a efetividade do modelo de cinco zonas ainda precisa de validação adicional. O estudo de Cooper de 2022 teve 33 corredores (18 altamente treinados e 15 recreativos), com recomendação de validação em amostras maiores e mais diversas.
- Modelo versionado: `AIRC_ZONES_2_MAS_SVT2_2018_2022`.
- Método versionado: `COOPER_12_MIN_MAS_SVT2_REGRESSION_2022`.
- Histórico guarda foto das zonas e os paces equivalentes no momento da avaliação.
- Snapshots `AIRC_ZONES_1` são preservados como históricos, mas marcados como legados; planos existentes precisam ser revisados e recriados para usar a metodologia atual.
- Contrato de exportação `pace-coach-workout` 5.0 contém Z1–Z5, faixas em `mm:ss min/km`, pace equivalente VAM/sVT2 e referência Cooper.

## Exemplo de verificação
Para Cooper de 2,10 km em 12 min:
- Pace médio do teste: 5:43 min/km.
- Pace equivalente da VAM estimada: 4:56 min/km.
- Pace equivalente do segundo limiar estimado: 5:41 min/km.
- VO₂máx estimado: 35,6.
- Z1: 8:43–11:28 min/km.
- Z2: 7:12–8:43 min/km.
- Z3: 6:12–7:12 min/km.
- Z4: 5:16–6:12 min/km.
- Z5: 4:42–5:16 min/km.

## Itens que ainda dependem do Pace Coach
- Implementar receptor compatível com `pace-coach-workout` 5.0.
- Confirmar no código do executor o mapeamento de Z1–Z5 e de blocos por tempo/distância.
- Enviar o código-fonte do Pace Coach para auditoria ponta a ponta.

## Validação nesta revisão
- Compilação Kotlin isolada do núcleo de calibração e motor de avaliações.
- Testes atualizados para a regressão MAS/sVT2, cinco zonas, fronteiras contínuas, histórico e contrato JSON.
- Build Android completo ainda depende do GitHub Actions; não declarar APK aprovado antes de uma execução verde real.

## Histórico de versões
- V24: correção de compilação do `SecondaryButton`.
- V23: Cooper e primeira geração de zonas `AIRC_ZONES_1`.
- V22 e anteriores: ver CHANGELOG e documentação histórica.
