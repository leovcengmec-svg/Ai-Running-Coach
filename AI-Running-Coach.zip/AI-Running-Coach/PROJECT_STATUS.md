# AI Running Coach — status V21

## Regras fixas
- Nome do projeto: AI Running Coach.
- Nome fixo do ZIP de entrega: `AI-Running-Coach.zip`; não renomear.
- Versão Android: V21 (`versionCode = 21`).
- O AI Running Coach prescreve; o Pace Coach executa, fornece GPS/cronômetro/áudio e registra as atividades.

## Atualização V21 — prescrição por pace
- Adicionado `PaceCalculator.kt` para estimar faixas iniciais de pace em min/km a partir de um resultado recente de 3, 5 ou 10 km.
- O onboarding permite inserir distância e tempo total no formato mm:ss, valida a plausibilidade do resultado e não aceita tempos extremos que produziriam um pace artificial.
- O pace é o alvo de velocidade quando há referência válida; RPE fica como orientação complementar e limite de esforço.
- Sem resultado recente, o app não inventa velocidade: mantém alvo por distância/tempo e marca pace como não calibrado.
- Cada segmento contém `targetMode` (`TIME` ou `DISTANCE`), dose e, quando disponível, faixa de pace em segundos/km e formato legível.
- Duração estimada é individualizada quando há pace calibrado; caso contrário permanece uma estimativa genérica explicitamente identificada.
- Contrato JSON `pace-coach-workout` atualizado para 2.1, com alvo segmentado `TIME`/`DISTANCE`, pace-alvo e RPE explicitamente secundário. Com pace calibrado, aquecimento, desaquecimento e recuperações são temporizados; sem referência, o motor mantém todos os blocos por distância. A distância de blocos temporizados é estimativa.
- UI de sessão, detalhes dos blocos e exportação agora priorizam pace-alvo em min/km.
- Perfis com planos V20 são marcados para revisão e regeneração, pois as sessões antigas não possuem paces de referência.

## Arquitetura preservada
- Android nativo em Kotlin e Jetpack Compose / Material 3.
- Motor de prescrição com ciclo de oito semanas, progressão e semanas regenerativas.
- Carga baseada na média semanal real e no maior treino contínuo recente.
- Controle de recuperação e bloqueio diante de dor relatada.
- Feedback persistido localmente.
- Integração via compartilhamento JSON; importação automática ainda depende de implementar o receptor no Pace Coach.

## Relação com o Laps
A interface V20 recriou padrões visuais descritos no projeto Laps. O motor do Laps não foi importado integralmente. As referências técnicas e avisos de licença permanecem documentados em `THIRD_PARTY_NOTICES.md` e `LICENSES/LAPS-MIT.txt`.

## Validação
- Compilação isolada de `CoachEngine.kt`, `PaceCalculator.kt` e `TrainingAdaptationEngine.kt` com `kotlinc`.
- Testes automatizados ampliados para parser de tempo, cálculo de faixas, validação de resultados extremos, geração com/sem benchmark e persistência do tipo de alvo.
- 25 testes JVM executados com sucesso em compilação isolada do núcleo (inclui matriz de 60 perfis); sintaxe da Activity inspecionada, mas compilação Android completa depende do GitHub Actions.
- Build Android completo ainda deve ser executado no GitHub Actions; este ambiente não possui Gradle nem Android SDK.
- O contrato 2.1 é a especificação de exportação do AI Running Coach. A compatibilidade exata com o parser interno do Pace Coach deve ser confirmada quando o código-fonte correspondente for integrado.
