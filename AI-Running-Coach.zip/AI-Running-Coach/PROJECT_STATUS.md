# AI Running Coach — status V18

## Base de trabalho
- Nome fixo do projeto: AI Running Coach.
- Nome fixo do ZIP de entrega: `AI-Running-Coach.zip`.
- Versão Android: V18 (`versionCode = 18`).
- A interface aprovada continua preservada; GPS e execução continuam sob responsabilidade do Pace Coach.

## Motor de prescrição
- O motor V18 substitui a geração isolada da primeira semana por um ciclo completo de quatro semanas.
- A arquitetura de periodização e adaptação é inspirada no projeto Laps e foi desacoplada das integrações COROS/Google Calendar.
- Inclui progressão de volume em etapas conservadoras, semana regenerativa, distribuição de sessões para 2–6 dias e limites individuais para longão/rodagens fáceis. O volume atual funciona como teto; o motor não força quilometragem em poucas sessões.
- As sessões possuem blocos estruturados e intensidade por RPE quando não há dados individuais de ritmo.
- Dor reportada bloqueia a prescrição normal; fadiga alta ou recuperação baixa reduzem volume e suspendem qualidade.

## Feedback e adaptação
- Feedback de esforço, sensação, observação, dor e distância efetivamente realizada é persistido localmente.
- A aderência só é calculada quando a distância real é informada; não se presume que o atleta completou toda a distância planejada.
- Objetivos personalizados aceitam uma distância entre 1 e 100 km.
- O feedback mais recente gera uma análise simples explicável.
- Os últimos três feedbacks influenciam a avaliação de recuperação/fadiga na próxima geração de plano.
- A análise não é diagnóstico médico e não substitui avaliação profissional.

## Integração
- Exportação de uma sessão como JSON `pace-coach-workout` versão 1.0 via compartilhamento Android.
- O Pace Coach ainda precisa implementar o importador desse contrato para integração automática.

## Build e qualidade
- GitHub Actions executa testes JVM e build APK debug.
- Build Release continua sem assinatura.
- A versão V17 instalada será sinalizada para atualização do plano; os dados do perfil são preservados.
- Testes automatizados cobrem frequências, ciclos, longão, segurança, fadiga, segmentos e decisão sobre treinos perdidos.

## Limitações restantes
- O onboarding ainda não coleta dias específicos disponíveis, data da prova, idade, frequência cardíaca de limiar ou ritmos de referência.
- Sem esses dados, não se calculam zonas fisiológicas individuais nem pace exato. A duração total apresentada é apenas uma estimativa geral e não é um alvo individual.
- A evolução utiliza a distância efetivamente informada no feedback; sessões sem quilometragem real registrada não entram no gráfico de distância.
- Não existe integração com API de IA ou importação automática de atividades nesta versão.
