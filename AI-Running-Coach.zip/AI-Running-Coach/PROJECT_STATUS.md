# AI Running Coach — status V26

## Regras permanentes
- Nome fixo do ZIP: `AI-Running-Coach.zip`; nunca renomear.
- AI Running Coach prescreve e acompanha; Pace Coach executa e registra.
- Distâncias exclusivamente em km.
- Todo pace apresentado ou exportado como `mm:ss min/km`.
- Tempo decorrido pode ser `mm:ss` ou `hh:mm:ss`; não confundir com pace.

## V26 — Modelo Cooper + teste da fala
- Faixas iniciais de Z1–Z5 baseadas em 60–70%, 70–80%, 80–90%, 90–100% e 100–110% da velocidade média do Cooper.
- A interface e a exportação identificam explicitamente que esses percentuais não são percentuais de VO₂máx.
- VAM e segundo limiar estimados permanecem apenas como referências complementares.
- Z2 pode ser refinada após dois ou três registros consistentes, em até 42 dias, do pace do trecho estável em que o atleta conseguia falar frases completas durante rodagem fácil ou longão.
- A calibração exige feedback sem dor, esforço não pesado e sensação geral boa; registros divergentes (>45 s de diferença) não alteram a zona.
- A fronteira personalizada usa uma margem conservadora e mantém limites compartilhados entre Z1/Z2/Z3.
- O dashboard solicita recriação do plano depois que uma calibração de Z2 fica disponível; os treinos antigos preservam os snapshots originais.
- Recuperações de intervalados/fartlek e rodagens regenerativas usam alvo numérico Z1; rodagens fáceis e longões usam Z2.
- Quando a Z2 é personalizada, os rótulos de intensidade e metadados de exportação de Z1–Z3 acompanham as fronteiras recalculadas, sem manter percentuais-base desatualizados.
- Contrato JSON `pace-coach-workout` 6.0, com modelo, fundamento percentual e metadados do teste da fala.

## Exemplo de Cooper de 2,10 km
- Pace médio do teste: 5:43 min/km.
- Z1: 8:10–9:31 min/km.
- Z2 inicial: 7:09–8:10 min/km.
- Z3: 6:21–7:09 min/km.
- Z4: 5:43–6:21 min/km.
- Z5: 5:12–5:43 min/km.

## Limitações
- Percentual da velocidade média do Cooper é referência operacional, não percentual de VO₂máx.
- O teste da fala é um indicador de campo aproximado; não mede VT1.
- A combinação completa do modelo ainda requer validação em uso real e comparação com avaliação laboratorial, quando disponível.
- Importação automática ainda depende da implementação do receptor no Pace Coach.

## Validação V26
- 45 testes do núcleo executados em JVM: aprovados.
- Compilação Kotlin dos componentes de domínio e do exportador: aprovada.
- Smoke test do JSON 6.0: confirmou zonas personalizadas, metadados da fala e unidades km / mm:ss min/km.
- Regressão: sessões regenerativas usam Z1 tanto no identificador da zona quanto na faixa numérica de pace.
- A compilação Android completa e a execução JUnit no ambiente Gradle devem ser confirmadas pelo GitHub Actions; não declarar APK aprovado antes de uma execução verde real.
