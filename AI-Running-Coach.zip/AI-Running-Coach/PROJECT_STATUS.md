# AI Running Coach — status

## Motor integration
The Android app now contains the first local Kotlin implementation of the Core V1.2 prescription contract.

Flow: runner input → current state → safety/recovery → necessity → stimulus → session → dose → validation → prescription.

The first plan is generated from onboarding values instead of hardcoded workouts. Exact pace is not fabricated when performance data are insufficient; the initial prescription uses RPE.

The app remains prescription-only. Execution/GPS/audio belong to Pace Coach.
