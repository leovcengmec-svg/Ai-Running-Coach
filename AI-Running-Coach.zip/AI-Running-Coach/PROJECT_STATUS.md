# AI Running Coach — status V20

## Regras fixas
- Nome do projeto: AI Running Coach.
- Nome fixo do ZIP de entrega: `AI-Running-Coach.zip`; não renomear.
- Versão Android: V20 (`versionCode = 20`).
- Pace Coach continua responsável pela execução, GPS, cronômetros, áudio e registro dos treinos.

## Atualização V20 — experiência visual
- Redesign amplo da camada Compose inspirado na estrutura Material 3 Expressive e Training Hub descrita pelo projeto open source Laps.
- Dashboard com resumo de ciclo, volume prescrito, sessões, métricas reais do perfil, distribuição semanal prevista e próximo treino.
- Calendário e plano com semanas expansíveis e lista de sessões.
- Cards de sessão e detalhe por blocos com informações e intensidades.
- Evolução baseada apenas nas distâncias informadas nos feedbacks, sem gráficos preenchidos com valores fictícios.
- Perfil, histórico, exportação e feedback alinhados ao novo sistema visual.
- Nova paleta slate/indigo escura, cartões arredondados, pills de status e navegação inferior em dock.
- Onboarding ajustado ao mesmo sistema visual.

## Regras preservadas da V19
- O motor continua solicitando a média semanal real das últimas quatro semanas e o maior treino contínuo recente.
- O nível de experiência não substitui a carga realizada.
- O motor mantém limites por sessão, controle de recuperação e bloqueio diante de dor relatada.
- Sessões mantêm blocos estruturados com distâncias consistentes com o total exportado.
- O contrato JSON `pace-coach-workout` 1.0 permanece inalterado.

## Relação com Laps
O redesign usa como referência os padrões descritos no repositório Laps: Training Hub, pods de métricas, resumo interativo de sete dias, acordeão de plano plurissemanal, dock inferior e linguagem Material 3 Expressive. Nesta V20 não foram copiados arquivos de UI, imagens ou código-fonte do Laps; os componentes foram implementados no projeto AI Running Coach. O aviso MIT e os créditos do projeto permanecem em `THIRD_PARTY_NOTICES.md`.

## Validação
- Revisão estática da estrutura Kotlin e dos fluxos de navegação.
- Os testes JVM existentes permanecem no projeto e o workflow continua configurado para executá-los antes do APK debug.
- Não foi possível executar uma compilação Gradle/Android neste ambiente, pois Gradle e Android SDK não estão instalados e o ambiente não teve acesso ao GitHub para baixar ferramentas ou repositório.
- Requer validação visual em aparelho Android: dashboard, calendário expansível, plano, detalhe de sessão, evolução vazia e feedback.

## Limitações conhecidas
- Condicionamento fisiológico ainda não é estimado sem histórico de ritmo/FC confiável.
- Não há sincronização automática com Pace Coach; exportação JSON permanece compartilhável e depende de implementação do receptor no Pace Coach.
- Os gráficos do dashboard apresentam distâncias planejadas por dia; a tela Evolução usa somente distâncias reais registradas.
- Widgets nativos de tela inicial do Android, presentes no Laps, não fazem parte desta etapa; exigem AppWidgetProvider e atualização de dados próprios.
