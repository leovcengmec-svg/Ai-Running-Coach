# AI Running Coach — status V24

## Regras permanentes
- Nome do produto: AI Running Coach.
- Nome fixo do ZIP: `AI-Running-Coach.zip`; não renomear.
- Versão Android: V24 (`versionCode = 24`).
- AI Running Coach prescreve e acompanha; Pace Coach executa e registra os treinos.
- Unidade de distância em toda a experiência: km.
- Unidade de pace em toda a experiência: mm:ss min/km.
- Não publicar pace como valor numérico bruto nem distância em metros em telas, histórico, relatório ou contrato JSON.

## Entregas V23
- Teste de Cooper de 12 minutos como única referência oficial para novas zonas.
- Entrada do resultado exclusivamente como distância em km; a duração do protocolo é fixa em 12 minutos. No onboarding, a data real também é informada e validada (resultado até 56 dias).
- Cálculo estimado de VO₂máx e cinco zonas operacionais Z1–Z5 ancoradas na referência aeróbia do Cooper.
- Versão do modelo de zonas `AIRC_ZONES_1`.
- Histórico de Cooper com distância em km, pace médio mm:ss min/km, VO₂máx estimado e fotografia de Z1–Z5 da avaliação.
- Revisão programada a cada 28 dias; novo teste depende de prontidão e recuperação adequada.
- Monitor de tendência de pace baseado em atividades reais e comparáveis, sem recalibração automática por uma sessão isolada.
- Biblioteca com 11 estímulos de treino e plano de oito semanas com progressão e semanas regenerativas.
- Controle da distribuição semanal e do longão como maior sessão, quando a tolerância permitir.
- Feedback de atividade com distância real em km e duração `mm:ss` ou `hh:mm:ss`; pace derivado e exibido em mm:ss min/km.
- Contrato de exportação `pace-coach-workout` 4.0, com distâncias em km, pace em mm:ss min/km, zonas e snapshot de Cooper associado à sessão (inclui a data original).
- Migração: resultados de prova V22 antigos não são mais usados como fonte oficial das zonas. Planos antigos permanecem salvos, mas solicitam revisão/recriação; até existir Cooper válido, não são inventadas zonas.

## Modelo de zonas
| Zona | Objetivo | Fração operacional da referência aeróbia |
|---|---|---:|
| Z1 | Regenerativa | 55–65% |
| Z2 | Aeróbia | 65–75% |
| Z3 | Moderada | 75–85% |
| Z4 | Limiar estimado | 85–95% |
| Z5 | VO₂máx estimado | 95–105% |

As faixas são convenções operacionais do produto, não medidas diretas de LT1/LT2. O Cooper é uma estimativa de campo, não exame laboratorial.

## Itens que ainda dependem do Pace Coach
- Implementar receptor para `pace-coach-workout` 4.0.
- Confirmar mapeamento de zonas e blocos por tempo/distância no modelo interno do executor.
- Enviar o código-fonte do Pace Coach para auditoria de compatibilidade ponta a ponta.

## Validação disponível
- 41 testes JVM de domínio executados em compilação Kotlin isolada; todos aprovados.
- Simulação do motor cobre frequências de 2–6 dias, ciclos de oito semanas, zonas, datas, snapshots históricos, longão, sessões e blocos repetidos.
- Exportação JSON 4.0 gerada e validada com parser JSON: cinco zonas, distâncias em km e todos os paces em mm:ss min/km.
- Build Android completo não foi executado neste ambiente; depende do GitHub Actions e não está declarado aprovado antes da execução real.


## V24 — Correção da compilação Android
- Corrigida a ausência do composable `SecondaryButton`, que causava referências não resolvidas em `MainActivity.kt` nas linhas de painel de zonas e evolução.
- Criado botão secundário com estilo OutlinedButton do Material 3.
- Ajustado o par de ações do painel para compartilhar a largura disponível sem sobreposição.
- `versionCode=24`, `versionName=V24`.
- A validação final do APK deve ocorrer no GitHub Actions com `:app:testDebugUnitTest` e `:app:assembleDebug`.
