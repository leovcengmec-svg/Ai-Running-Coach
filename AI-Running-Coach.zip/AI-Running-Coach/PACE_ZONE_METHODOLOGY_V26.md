# Metodologia de zonas de pace — V26

## 1. O que mudou

A V26 substitui o modelo V25 baseado em percentuais da VAM estimada por faixas iniciais baseadas na velocidade média do Teste de Cooper de 12 minutos, conforme a planilha de referência apresentada pelo usuário. Os percentuais são aplicados à velocidade média do Cooper; **não são percentuais de VO₂máx**.

| Zona | Percentual da velocidade média do Cooper | Finalidade operacional |
|---|---:|---|
| Z1 | 60–70% | Regenerativa |
| Z2 | 70–80% | Aeróbia confortável |
| Z3 | 80–90% | Moderada |
| Z4 | 90–100% | Limiar estimado |
| Z5 | 100–110% | Alta intensidade |

Todos os ritmos são exibidos em `mm:ss min/km`; distâncias em km. A distância do Cooper é informada em km e o teste tem duração fixa de 12 min.

## 2. Exemplo de referência

Para 2,10 km no Cooper:

- Pace médio do Cooper: 5:43 min/km.
- Z1: 8:10–9:31 min/km.
- Z2 inicial: 7:09–8:10 min/km.
- Z3: 6:21–7:09 min/km.
- Z4: 5:43–6:21 min/km.
- Z5: 5:12–5:43 min/km.

Os limites são arredondados para `mm:ss` e compartilham fronteiras para não criar lacunas ou sobreposições.

## 3. Personalização da Z2 pelo teste da fala

A faixa inicial da Z2 pode ser refinada com registros de campo feitos em rodagens fáceis ou longões. O atleta informa o pace do trecho estável em que conseguiu dizer frases completas com conforto. Não deve usar o pace médio total quando a sessão incluiu aquecimento, paradas ou variações relevantes.

A personalização exige pelo menos dois registros recentes, sem dor, com esforço leve/aceitável e sensação geral boa. Os dois ou três registros mais recentes precisam estar dentro de uma diferença máxima de 45 segundos. O motor utiliza a mediana e acrescenta uma margem conservadora de 10 segundos, limitando o ajuste para manter zonas adjacentes contínuas e com largura mínima.

A Z2 ajustada passa a ser a referência para as rodagens aeróbias e longões futuros após o usuário recriar o plano. Os snapshots dos treinos antigos permanecem intactos.

O teste da fala é uma ferramenta prática aproximada para identificar a região próxima do primeiro limiar ventilatório; sua resolução é grosseira e não equivale a um teste laboratorial. Evidências sistemáticas relacionam a última etapa em que a fala permanece confortável à região do primeiro limiar, mas alertam que os protocolos variam e exigem interpretação cautelosa (Systematic Review, 2024; Reed & Pipe, 2014).

## 4. VAM e segundo limiar

As regressões do estudo `Augmented Cooper Test` (2022) continuam exibidas como referências complementares estimadas. Nesta versão, elas **não definem diretamente** as fronteiras das cinco zonas. O estudo incluiu 33 corredores (18 altamente treinados e 15 recreativos); as estimativas devem ser tratadas como estimativas de grupo, não como medidas individuais exatas.

## 5. Limitações e segurança

- As faixas iniciais inspiradas na planilha são operacionais e não um protocolo universal de zonas fisiológicas.
- Percentual da velocidade média do Cooper não é equivalente a percentual do VO₂máx.
- O teste da fala não mede VT1 diretamente; o resultado deve ser combinado com sensação, recuperação, terreno e histórico.
- Calor, subidas, vento, fadiga, doença e superfície podem alterar a relação entre pace e esforço.
- Uma corrida isolada não acelera automaticamente o pace-base.
- Dor ou recuperação insuficiente impedem usar o registro como evidência de calibração.

## 6. Consistência entre zona exibida e alvo executável

- Uma sessão regenerativa usa Z1 tanto no identificador do bloco quanto nos limites numéricos exportados.
- Rodagem fácil e longão usam Z2; recuperações de intervalos e fartlek usam Z1.
- Quando a fala personaliza as fronteiras, os rótulos de Z1–Z3 descrevem a calibração individual e não repetem percentuais da faixa-base que já não correspondem exatamente ao novo intervalo.

## 7. Exportação

Contrato Pace Coach `pace-coach-workout` versão 6.0. Exporta modelo de zonas, faixas em `mm:ss min/km`, percentual da velocidade média do Cooper, estado de calibração da Z2 e evidências do teste da fala. Distâncias em km. Não exporta percentuais como se fossem %VO₂máx.

## Fontes

- Augmented Cooper test: Biomechanical contributions to endurance performance (2022): https://pmc.ncbi.nlm.nih.gov/articles/PMC9515446/
- Application and Measurement Properties of the Talk Test in Cardiopulmonary Patients: A Systematic Review (2024): https://pmc.ncbi.nlm.nih.gov/articles/PMC11266803/
- The talk test: a useful tool for prescribing and monitoring exercise intensity (2014): https://pubmed.ncbi.nlm.nih.gov/25010379/
- Simple Approach to Defining Training Intensity in Endurance Runners (2022): https://pubmed.ncbi.nlm.nih.gov/35661059/
