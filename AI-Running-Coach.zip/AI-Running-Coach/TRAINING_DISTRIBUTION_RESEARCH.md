# Evidência e critérios de distribuição do treino — V23

## 1. Distribuição de intensidade

A maior parte do treinamento de endurance costuma ser realizada em baixa intensidade, com proporções menores de trabalho moderado/próximo ao limiar e alta intensidade. Revisões sistemáticas sobre corredores de média e longa distância descrevem distribuição predominantemente piramidal ou polarizada, mas apontam que os resultados dependem da população, fase da temporada e método usado para classificar zonas.

A V23 não converte a literatura em regra cega de quilômetros por sessão. O motor distingue:
- distribuição por sessão: como os quilômetros semanais são distribuídos entre rodagem fácil, qualidade e longão;
- distribuição por intensidade: quanto do tempo real é realizado em cada zona.

A sessão de qualidade inclui aquecimento, recuperação e desaquecimento em zonas leves. A distância total dessa sessão não representa, por si só, a quantidade de trabalho intenso.

## 2. Longão e distribuição semanal

Não há uma proporção científica universal que estabeleça a fração ideal do longão para todo corredor. A participação varia com frequência de corrida, volume, objetivo, histórico e tolerância individual.

A V23 mantém heurísticas iniciais do produto, ajustadas à frequência:

| Corridas por semana | Alvo inicial do longão |
|---:|---:|
| 2 | 53% |
| 3 | 40% |
| 4 | 32% |
| 5 | 28% |
| 6 | 25% |

Esses percentuais são parâmetros de planejamento do produto, não percentuais ideais universais. O longão deve normalmente ser a maior sessão, mas é limitado pelo maior treino contínuo recente e pela progressão que o atleta efetivamente tolerou.

Estudo de coorte com 5.205 corredores identificou maior risco populacional de lesão por sobrecarga quando uma sessão ultrapassava em mais de 10% a maior distância realizada nos 30 dias anteriores. Isso é um sinal de risco, não garantia de segurança abaixo desse limite.

## 3. Tipos de treinamento disponíveis

O catálogo da V23 cobre 11 categorias:
1. Rodagem regenerativa (Z1).
2. Rodagem aeróbia (Z2).
3. Longão aeróbio (predominantemente Z2).
4. Corrida moderada/steady (Z3).
5. Tempo run (Z4 estimada).
6. Intervalos de limiar (Z4 estimada).
7. Intervalado VO₂máx (Z5 estimada).
8. Fartlek (alternância de Z2–Z4).
9. Repetições em subida (opcional; exige percurso apropriado, portanto não é gerado automaticamente sem preferência de terreno).
10. Strides (acelerações breves e relaxadas; complemento técnico, sem pace-alvo e sem confundir com Z5).
11. Corrida progressiva (Z2–Z3).

A seleção é condicionada à experiência, frequência, volume real, fase do ciclo, recuperação e tolerância. Nem todos os tipos devem aparecer em toda semana.

## 4. Fontes consultadas

- *Training-intensity Distribution on Middle- and Long-distance Runners: A Systematic Review* (2021). PubMed: https://pubmed.ncbi.nlm.nih.gov/34749417/
- *Training Intensity Distribution in Elite Runners* / revisão relacionada (2022). PubMed: https://pubmed.ncbi.nlm.nih.gov/35418513/
- Seiler, S. (2010). *What is best practice for training intensity and duration distribution in endurance athletes?* PubMed: https://pubmed.ncbi.nlm.nih.gov/20861519/
- *How much running is too much? Identifying high-risk running sessions in a 5200-person cohort study* (2025). British Journal of Sports Medicine: https://bjsm.bmj.com/content/59/17/1203.long
- *Training Intensity Distribution, Load Management, and Performance in Recreational Long-Distance Runners* (2026). PubMed: https://pubmed.ncbi.nlm.nih.gov/41765005/

## 5. Limites da evidência

As revisões ajudam a orientar o predomínio aeróbio, mas não definem a melhor distribuição individual de quilômetros nem uma participação universal do longão. Os parâmetros da V23 precisam ser validados com o histórico real, a resposta do atleta e testes progressivos. Dor, fadiga e recuperação têm prioridade sobre a meta matemática de volume.
