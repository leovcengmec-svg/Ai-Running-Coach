package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Test

class WorkoutDurationEstimatorTest {
    @Test
    fun `soma blocos por distancia e tempo em treino misto`() {
        val segments = listOf(
            WorkoutSegment("Aquecimento", "Leve", distanceKm = 1.2, targetPaceMinValue = 490, targetPaceMaxValue = 571, paceZone = "Z1"),
            WorkoutSegment("Bloco aeróbio", "Conversável", distanceKm = 3.5, targetPaceMinValue = 429, targetPaceMaxValue = 490, paceZone = "Z2"),
            WorkoutSegment("Desaquecimento", "Finalizar", durationMin = 11, distanceKm = 1.2, targetMode = "TIME", paceZone = "Z1")
        )
        // 10.6 min warm-up + 26.8 min aerobic + 11 min cooldown, rounded up.
        assertEquals(49, WorkoutDurationEstimator.estimateMinutes(segments, fallbackDistanceKm = 5.9))
    }

    @Test
    fun `estima a sessao regenerativa da referencia com distancia mais desaquecimento por tempo`() {
        val segments = listOf(
            WorkoutSegment("Aquecimento", "Leve", distanceKm = 1.0, targetPaceMinValue = 490, targetPaceMaxValue = 571, paceZone = "Z1"),
            WorkoutSegment("Bloco aeróbio", "Regenerativo", distanceKm = 3.1, targetPaceMinValue = 490, targetPaceMaxValue = 571, paceZone = "Z1"),
            WorkoutSegment("Desaquecimento", "Finalizar", durationMin = 9, distanceKm = 1.0, targetMode = "TIME", paceZone = "Z1")
        )
        assertEquals(46, WorkoutDurationEstimator.estimateMinutes(segments, fallbackDistanceKm = 5.1))
    }

    @Test
    fun `nao conta distancia estimada duas vezes em etapa por tempo`() {
        val segments = listOf(
            WorkoutSegment("Corrida", "Run", durationMin = 2, distanceKm = 0.25, repeatCount = 4),
            WorkoutSegment("Caminhada", "Walk", durationMin = 2, distanceKm = 0.10, repeatCount = 4)
        )
        assertEquals(16, WorkoutDurationEstimator.estimateMinutes(segments, fallbackDistanceKm = 1.4))
    }

    @Test
    fun `multiplica etapas por distancia pela quantidade de repeticoes`() {
        val segments = listOf(
            WorkoutSegment("Intervalo", "Forte", distanceKm = 0.4, intensity = "HIGH", repeatCount = 4, targetPaceMinValue = 300, targetPaceMaxValue = 330),
            WorkoutSegment("Recuperação", "Leve", durationMin = 2, repeatCount = 3, targetMode = "TIME")
        )
        assertEquals(15, WorkoutDurationEstimator.estimateMinutes(segments))
    }

    @Test
    fun `usa ritmo de outros blocos quando uma distancia nao tem pace proprio`() {
        val segments = listOf(
            WorkoutSegment("Aquecimento", "Leve", distanceKm = 1.0, targetPaceMinValue = 480, targetPaceMaxValue = 540),
            WorkoutSegment("Strides", "Técnica", distanceKm = 0.4, repeatCount = 4, intensity = "HIGH"),
            WorkoutSegment("Desaquecimento", "Leve", durationMin = 5, targetMode = "TIME")
        )
        assertEquals(28, WorkoutDurationEstimator.estimateMinutes(segments))
    }

    @Test
    fun `nao aplica piso artificial de quinze minutos quando os blocos somam menos`() {
        val segments = listOf(
            WorkoutSegment("Aquecimento", "Leve", durationMin = 3),
            WorkoutSegment("Estímulo", "Controlado", durationMin = 2, repeatCount = 2),
            WorkoutSegment("Desaquecimento", "Leve", durationMin = 1)
        )
        assertEquals(8, WorkoutDurationEstimator.estimateMinutes(segments))
    }

    @Test
    fun `usa base aproximada quando nenhum bloco tem pace calibrado`() {
        val segments = listOf(
            WorkoutSegment("Rodagem", "Leve", distanceKm = 5.0)
        )
        assertEquals(35, WorkoutDurationEstimator.estimateMinutes(segments))
    }
}
