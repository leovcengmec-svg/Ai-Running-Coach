package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TrainingTypeCatalogTest {
    @Test
    fun `biblioteca contem onze tipos de sessao com zonas operacionais`() {
        assertEquals(11, TrainingTypeCatalog.all.size)
        val ids = TrainingTypeCatalog.all.map { it.id }.toSet()
        assertEquals(11, ids.size)
        listOf(
            "RECOVERY", "EASY_AEROBIC", "LONG_RUN", "STEADY_RUN", "TEMPO_RUN",
            "THRESHOLD_INTERVAL", "VO2_MAX_INTERVAL", "FARTLEK", "HILL_REPEATS",
            "STRIDES", "PROGRESSION_RUN"
        ).forEach { assertNotNull("Tipo ausente: $it", TrainingTypeCatalog.find(it)) }
    }

    @Test
    fun `catalogo identifica o objetivo e a zona principal de cada sessao`() {
        assertEquals("Z1", TrainingTypeCatalog.find("RECOVERY")!!.zone)
        assertEquals("Z2", TrainingTypeCatalog.find("LONG_RUN")!!.zone)
        assertEquals("Z3", TrainingTypeCatalog.find("STEADY_RUN")!!.zone)
        assertEquals("Z4", TrainingTypeCatalog.find("TEMPO_RUN")!!.zone)
        assertEquals("Z5", TrainingTypeCatalog.find("VO2_MAX_INTERVAL")!!.zone)
        assertEquals("Técnica", TrainingTypeCatalog.find("STRIDES")!!.zone)
        assertTrue(TrainingTypeCatalog.find("HILL_REPEATS")!!.use.contains("percurso"))
    }
}
