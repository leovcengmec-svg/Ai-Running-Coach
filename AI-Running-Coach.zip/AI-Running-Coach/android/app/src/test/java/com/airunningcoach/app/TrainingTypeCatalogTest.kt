package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TrainingTypeCatalogTest {
    @Test
    fun `biblioteca contem doze tipos de sessao com zonas operacionais`() {
        assertEquals(12, TrainingTypeCatalog.all.size)
        val ids = TrainingTypeCatalog.all.map { it.id }.toSet()
        assertEquals(12, ids.size)
        listOf(
            "RUN_WALK", "RECOVERY", "EASY_AEROBIC", "LONG_RUN", "STEADY_RUN", "TEMPO_RUN",
            "THRESHOLD_INTERVAL", "VO2_MAX_INTERVAL", "FARTLEK", "HILL_REPEATS",
            "STRIDES", "PROGRESSION_RUN"
        ).forEach { assertNotNull("Tipo ausente: $it", TrainingTypeCatalog.find(it)) }
    }

    @Test
    fun `catalogo oferece fortalecimento opcional sem inserir sessao automaticamente`() {
        assertEquals(2, StrengthTrainingCatalog.all.size)
        assertTrue(StrengthTrainingCatalog.all.all { it.duration.contains("min") && it.exercises.isNotBlank() })
        assertTrue(StrengthTrainingCatalog.all.any { it.title.contains("panturrilhas") })
        assertTrue(StrengthTrainingCatalog.all.any { it.title.contains("posterior") })
    }

    @Test
    fun `catalogo identifica o objetivo e a zona principal de cada sessao`() {
        assertEquals("Z1–Z2", TrainingTypeCatalog.find("RUN_WALK")!!.zone)
        assertEquals("Z1", TrainingTypeCatalog.find("RECOVERY")!!.zone)
        assertEquals("Z2", TrainingTypeCatalog.find("LONG_RUN")!!.zone)
        assertEquals("Z3", TrainingTypeCatalog.find("STEADY_RUN")!!.zone)
        assertEquals("Z4", TrainingTypeCatalog.find("TEMPO_RUN")!!.zone)
        assertEquals("Z5", TrainingTypeCatalog.find("VO2_MAX_INTERVAL")!!.zone)
        assertEquals("Técnica", TrainingTypeCatalog.find("STRIDES")!!.zone)
        assertTrue(TrainingTypeCatalog.find("HILL_REPEATS")!!.use.contains("percurso"))
    }
}
