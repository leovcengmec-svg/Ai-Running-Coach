package com.airunningcoach.app

import java.io.File
import java.nio.file.Files
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PaceCoachJsonAttachmentTest {
    @Test
    fun `anexo e arquivo json real com mime correto e conteudo utf8`() {
        val cacheDirectory = Files.createTempDirectory("pace-coach-export-test").toFile()
        try {
            val json = JSONObject()
                .put("contract", "pace-coach-workout")
                .put("title", "Corrida progressiva")
                .toString(2)

            val file = PaceCoachJsonAttachment.create(cacheDirectory, "W1/MONDAY:QUALITY", json)

            assertEquals("pace-coach-workout-W1_MONDAY_QUALITY.json", file.name)
            assertEquals("application/json", PaceCoachJsonAttachment.MIME_TYPE)
            assertEquals(json, file.readText(Charsets.UTF_8))
            assertTrue(file.isFile)
            assertFalse(file.name.endsWith(".txt", ignoreCase = true))
            assertTrue(file.canonicalPath.startsWith(File(cacheDirectory, "exports").canonicalPath + File.separator))
            assertEquals("Corrida progressiva", JSONObject(file.readText(Charsets.UTF_8)).getString("title"))
        } finally {
            cacheDirectory.deleteRecursively()
        }
    }

    @Test
    fun `reexportar a mesma sessao atualiza o mesmo arquivo json`() {
        val cacheDirectory = Files.createTempDirectory("pace-coach-export-overwrite").toFile()
        try {
            val first = PaceCoachJsonAttachment.create(cacheDirectory, "SESSION-01", "{\"revision\":1}")
            val second = PaceCoachJsonAttachment.create(cacheDirectory, "SESSION-01", "{\"revision\":2}")

            assertEquals(first.canonicalPath, second.canonicalPath)
            assertEquals(2, JSONObject(second.readText(Charsets.UTF_8)).getInt("revision"))
        } finally {
            cacheDirectory.deleteRecursively()
        }
    }
}
