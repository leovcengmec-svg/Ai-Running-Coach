package com.airunningcoach.app

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TrainingLoadEngineTest {
    private val today = LocalDate.of(2026, 11, 9)

    @Test
    fun `historico parcial nao substitui o volume informado no perfil`() {
        val activities = listOf(
            LoggedRunActivity(today.minusDays(2), 5.0),
            LoggedRunActivity(today.minusDays(8), 6.0),
            LoggedRunActivity(today.minusDays(15), 7.0),
            LoggedRunActivity(today.minusDays(25), 4.0)
        )
        val snapshot = TrainingLoadEngine.summarize(activities, today)
        assertFalse(snapshot.reliable)
        assertNull(snapshot.averageWeeklyKmLast28Days)
        assertEquals(4, snapshot.recordedRunsLast28Days)
    }

    @Test
    fun `historico suficiente calcula media real das ultimas quatro semanas`() {
        val activities = listOf(
            LoggedRunActivity(today.minusDays(1), 5.0),
            LoggedRunActivity(today.minusDays(3), 4.0),
            LoggedRunActivity(today.minusDays(8), 6.0),
            LoggedRunActivity(today.minusDays(10), 5.0),
            LoggedRunActivity(today.minusDays(15), 7.0),
            LoggedRunActivity(today.minusDays(16), 5.0)
        )
        val snapshot = TrainingLoadEngine.summarize(activities, today)
        assertTrue(snapshot.reliable)
        assertEquals(32.0, snapshot.totalKmLast28Days, 0.01)
        assertEquals(8.0, snapshot.averageWeeklyKmLast28Days!!, 0.01)
        assertEquals(7.0, snapshot.longestRunLast30DaysKm!!, 0.01)
        assertEquals(3, snapshot.activeWeeksLast28Days)
    }

    @Test
    fun `atividade fora da janela nao entra no volume nem na maior corrida`() {
        val activities = listOf(
            LoggedRunActivity(today.minusDays(3), 5.0),
            LoggedRunActivity(today.minusDays(10), 5.0),
            LoggedRunActivity(today.minusDays(17), 5.0),
            LoggedRunActivity(today.minusDays(25), 5.0),
            LoggedRunActivity(today.minusDays(31), 25.0)
        )
        val snapshot = TrainingLoadEngine.summarize(activities, today)
        assertEquals(20.0, snapshot.totalKmLast28Days, 0.01)
        assertEquals(5.0, snapshot.longestRunLast30DaysKm!!, 0.01)
    }

    @Test
    fun `ignora distancia ausente negativa nao finita e data futura`() {
        val activities = listOf(
            LoggedRunActivity(today.minusDays(1), 5.0),
            LoggedRunActivity(today.minusDays(4), -3.0),
            LoggedRunActivity(today.minusDays(7), Double.NaN),
            LoggedRunActivity(today.plusDays(1), 12.0)
        )
        val snapshot = TrainingLoadEngine.summarize(activities, today)
        assertEquals(1, snapshot.recordedRunsLast28Days)
        assertEquals(5.0, snapshot.totalKmLast28Days, 0.01)
    }
}
