package com.airunningcoach.app

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CoachEngineTest {
    private fun input(frequency: Int = 4) = RunnerInput(
        goalKm = 10.0,
        level = "Intermediário",
        frequency = frequency,
        weeklyVolumeKm = 30.0,
        longestRecentKm = 10.0,
        startDate = LocalDate.of(2026, 11, 9)
    )

    @Test
    fun `gera oito semanas completas sem duplicar dia na mesma semana`() {
        for (frequency in 2..6) {
            val plan = RunningCoachEngine.generate(input(frequency))
            assertEquals(frequency * 8, plan.workouts.size)
            assertEquals(8, plan.weeklySummaries.size)
            assertTrue(plan.workouts.all { it.scheduledDateIso.matches(Regex("\\d{4}-\\d{2}-\\d{2}")) })
            plan.workouts.groupBy { it.week }.values.forEach { week ->
                assertEquals(frequency, week.size)
                assertEquals(frequency, week.map { it.date }.distinct().size)
            }
        }
    }

    @Test
    fun `volume semanal real nao e reduzido ao limite inferior de uma faixa`() {
        val plan = RunningCoachEngine.generate(input(3).copy(weeklyVolumeKm = 20.0, longestRecentKm = 10.0))
        assertEquals(20.0, plan.weeklySummaries.first().totalKm, 0.01)
        assertEquals(20.0, plan.state.recentVolumeKm, 0.01)
    }

    @Test
    fun `nivel intermediario nao substitui volume semanal real`() {
        val plan = RunningCoachEngine.generate(input(3).copy(level = "Intermediário", weeklyVolumeKm = 10.0, longestRecentKm = 10.0))
        assertEquals(10.0, plan.weeklySummaries.first().totalKm, 0.01)
        assertFalse(plan.workouts.any { it.type == "Qualidade" })
    }

    @Test
    fun `historico curto limita sessoes e explica reducao do volume`() {
        val plan = RunningCoachEngine.generate(input(3).copy(weeklyVolumeKm = 20.0, longestRecentKm = 3.0))
        assertTrue(plan.weeklySummaries.first().totalKm < 20.0)
        assertTrue(plan.state.flags.contains("WEEKLY_VOLUME_CAPPED_BY_RECENT_TOLERANCE"))
        assertFalse(plan.workouts.filter { it.week == 1 }.any { it.distanceKm > 3.0 })
        assertTrue(plan.weeklySummaries.zipWithNext().all { (a, b) -> b.totalKm <= a.totalKm * 1.11 })
    }

    @Test
    fun `sem feedback recuperacao e seguranca nao sao exibidas como avaliadas`() {
        val plan = RunningCoachEngine.generate(input().copy(recoveryScore = null, fatigueScore = null))
        assertEquals("UNKNOWN", plan.state.recoveryStatus)
        assertEquals("UNASSESSED", plan.state.safetyStatus)
    }

    @Test
    fun `semanas quatro e oito sao regenerativas e reduzem a carga`() {
        val plan = RunningCoachEngine.generate(input())
        assertTrue(plan.weeklySummaries[3].isRecoveryWeek)
        assertTrue(plan.weeklySummaries[3].totalKm < plan.weeklySummaries[2].totalKm)
        assertTrue(plan.weeklySummaries[7].isRecoveryWeek)
        assertTrue(plan.weeklySummaries[7].totalKm < plan.weeklySummaries[6].totalKm)
    }

    @Test
    fun `progressao semanal nao salta mais de onze por cento`() {
        val plan = RunningCoachEngine.generate(input())
        assertTrue(plan.weeklySummaries.zipWithNext().all { (previous, next) -> next.totalKm <= previous.totalKm * 1.11 })
    }

    @Test
    fun `matriz de sessenta perfis nao gera dias duplicados ou distancias negativas`() {
        val levels = listOf("Iniciante", "Intermediário", "Avançado", "Elite")
        val volumes = listOf(5.0, 10.0, 20.0)
        var cases = 0
        levels.forEach { level ->
            for (frequency in 2..6) {
                volumes.forEach { volume ->
                    val plan = RunningCoachEngine.generate(input(frequency).copy(level = level, weeklyVolumeKm = volume, longestRecentKm = 10.0))
                    assertEquals(frequency * 8, plan.workouts.size)
                    assertTrue(plan.workouts.all { it.distanceKm > 0.0 })
                    plan.workouts.groupBy { it.week }.values.forEach { sessions ->
                        assertEquals(frequency, sessions.map { it.date }.distinct().size)
                    }
                    assertTrue(plan.weeklySummaries.zipWithNext().all { (a, b) -> b.totalKm <= a.totalKm * 1.11 })
                    cases++
                }
            }
        }
        assertEquals(60, cases)
    }

    @Test
    fun `longao permanece limitado pela parcela do volume e pela tolerancia recente`() {
        val plan = RunningCoachEngine.generate(input(5))
        plan.workouts.groupBy { it.week }.forEach { (_, sessions) ->
            val weeklyKm = sessions.sumOf { it.distanceKm }
            val longRunKm = sessions.single { it.type == "Longo" }.distanceKm
            val allowedShare = when {
                sessions.first().week == 4 -> 0.52
                sessions.size == 2 -> 0.52
                sessions.size >= 3 -> 0.42
                else -> 0.52
            }
            assertTrue(longRunKm <= weeklyKm * allowedShare)
            assertTrue(longRunKm <= 10.8)
            assertTrue(sessions.all { it.distanceKm <= 11.0 })
        }
    }

    @Test
    fun `dor bloqueia a prescricao normal`() {
        val plan = RunningCoachEngine.generate(input().copy(painPresent = true))
        assertEquals("RED", plan.state.safetyStatus)
        assertTrue(plan.workouts.isEmpty())
        assertEquals("BLOCK", plan.decision.action)
    }

    @Test
    fun `fadiga alta suspende qualidade e reduz volume`() {
        val normal = RunningCoachEngine.generate(input())
        val fatigued = RunningCoachEngine.generate(input().copy(fatigueScore = 80.0))
        assertEquals("YELLOW", fatigued.state.safetyStatus)
        assertFalse(fatigued.workouts.any { it.type == "Qualidade" })
        assertTrue(fatigued.weeklyKm < normal.weeklyKm)
    }

    @Test
    fun `sem resultado recente nao inventa pace e mantem distancia como alvo`() {
        val plan = RunningCoachEngine.generate(input())
        assertTrue(plan.workouts.all { it.paceMode == "PACE_NOT_CALIBRATED" })
        val segments = plan.workouts.flatMap { it.segments }
        assertTrue(segments.all { it.targetMode == "DISTANCE" })
        assertTrue(segments.all { it.targetPaceMinSecPerKm == null && it.targetPaceMaxSecPerKm == null })
    }

    @Test
    fun `resultado recente gera faixas de pace e preserva RPE como apoio`() {
        val plan = RunningCoachEngine.generate(input().copy(benchmarkDistanceKm = 5.0, benchmarkTimeSeconds = 25 * 60))
        assertTrue(plan.workouts.all { it.paceMode == "PACE_RANGE" })
        val segments = plan.workouts.flatMap { it.segments }
        assertTrue(segments.any { it.targetMode == "TIME" })
        assertTrue(segments.any { it.targetMode == "DISTANCE" })
        assertTrue(segments.filter { it.targetMode == "TIME" }.all { it.durationMin != null })
        assertTrue(segments.all { it.targetPaceMinSecPerKm != null && it.targetPaceMaxSecPerKm != null })
        val quality = plan.workouts.first { it.type == "Qualidade" }
        assertEquals("TIME", quality.segments.first { it.name == "Aquecimento" }.targetMode)
        assertEquals("DISTANCE", quality.segments.first { it.name == "Estímulo principal" }.targetMode)
        assertEquals("TIME", quality.segments.first { it.name.contains("Recuperação") }.targetMode)
        assertTrue(segments.all { it.targetPaceMinSecPerKm!! <= it.targetPaceMaxSecPerKm!! })
        assertTrue(segments.all { it.rpeRange.isNotBlank() })
    }

    @Test
    fun `todas as sessoes possuem estrutura de blocos exportaveis`() {
        val plan = RunningCoachEngine.generate(input())
        assertTrue(plan.workouts.all { it.segments.size >= 3 })
        assertTrue(plan.workouts.all { it.sessionId.isNotBlank() })
    }

    @Test
    fun `distancia dos blocos corresponde ao total da sessao exportada`() {
        val plan = RunningCoachEngine.generate(input(3).copy(weeklyVolumeKm = 20.0, longestRecentKm = 10.0))
        plan.workouts.forEach { workout ->
            val segmentDistance = workout.segments.sumOf { (it.distanceKm ?: 0.0) * it.repeatCount }
            assertEquals(workout.distanceKm, segmentDistance, 0.11)
        }
    }
}

class TrainingAdaptationEngineTest {
    @Test
    fun `treino perdido nao e transferido para antes de longao proximo`() {
        val resolution = TrainingAdaptationEngine.reasonMissedWorkout(
            missedTitle = "Threshold",
            missedDistanceKm = 8.0,
            nextTitle = "Longão aeróbio",
            nextDistanceKm = 18.0,
            hoursUntilNext = 24
        )
        assertTrue(resolution.options.first().recommended)
        assertEquals("DROP", resolution.options.first().action)
    }


    @Test
    fun `muito leve nao e classificado como esforco excessivo`() {
        val analysis = TrainingAdaptationEngine.analyzeRun(
            TrainingAdaptationEngine.RunResult(
                distanceKm = 5.0,
                plannedDistanceKm = 5.0,
                perceivedEffort = "Muito leve",
                feeling = "Ótimo"
            )
        )
        assertEquals("Treino aeróbio registrado", analysis.headline)
        assertEquals(100, analysis.adherencePercent)
    }

    @Test
    fun `sem distancia real nao inventa aderencia`() {
        val analysis = TrainingAdaptationEngine.analyzeRun(
            TrainingAdaptationEngine.RunResult(
                distanceKm = null,
                plannedDistanceKm = 6.0,
                perceivedEffort = "Leve",
                feeling = "Bem"
            )
        )
        assertEquals(null, analysis.adherencePercent)
        assertTrue(analysis.insights.any { it.contains("não informada") })
    }

    @Test
    fun `relato de dor gera alerta de revisao`() {
        val analysis = TrainingAdaptationEngine.analyzeRun(
            TrainingAdaptationEngine.RunResult(
                distanceKm = 5.0,
                plannedDistanceKm = 5.0,
                painReported = true
            )
        )
        assertTrue(analysis.headline.contains("Dor reportada"))
    }
}
