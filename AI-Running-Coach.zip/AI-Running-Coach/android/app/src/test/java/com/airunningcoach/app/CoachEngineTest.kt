package com.airunningcoach.app

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CoachEngineTest {
    private fun input(frequency: Int = 4) = RunnerInput(
        goalKm = 10.0,
        level = "Intermediário",
        frequency = frequency,
        weeklyVolumeMinKm = 30.0,
        longestRecentKm = 10.0,
        startDate = LocalDate.of(2026, 11, 9)
    )

    @Test
    fun `gera quatro semanas completas sem duplicar dia na mesma semana`() {
        for (frequency in 2..6) {
            val plan = RunningCoachEngine.generate(input(frequency))
            assertEquals(frequency * 4, plan.workouts.size)
            assertEquals(4, plan.weeklySummaries.size)
            assertTrue(plan.workouts.all { it.scheduledDateIso.matches(Regex("\\d{4}-\\d{2}-\\d{2}")) })
            plan.workouts.groupBy { it.week }.values.forEach { week ->
                assertEquals(frequency, week.size)
                assertEquals(frequency, week.map { it.date }.distinct().size)
            }
        }
    }

    @Test
    fun `semana regenerativa reduz o volume em relacao a semana de progressao`() {
        val plan = RunningCoachEngine.generate(input())
        assertTrue(plan.weeklySummaries[3].isRecoveryWeek)
        assertTrue(plan.weeklySummaries[3].totalKm < plan.weeklySummaries[2].totalKm)
    }

    @Test
    fun `longao permanece limitado pela parcela do volume e pela tolerancia recente`() {
        val plan = RunningCoachEngine.generate(input(5))
        plan.workouts.groupBy { it.week }.forEach { (_, sessions) ->
            val weeklyKm = sessions.sumOf { it.distanceKm }
            val longRunKm = sessions.single { it.type == "Longo" }.distanceKm
            val allowedShare = when {
                sessions.first().week == 4 -> 0.52
                sessions.size == 2 -> 0.52
                sessions.size >= 3 -> 0.42
                else -> 0.52
            }
            assertTrue(longRunKm <= weeklyKm * allowedShare)
            assertTrue(longRunKm <= 10.8)
            assertTrue(sessions.all { it.distanceKm <= 11.0 })
        }
    }

    @Test
    fun `dor bloqueia a prescricao normal`() {
        val plan = RunningCoachEngine.generate(input().copy(painPresent = true))
        assertEquals("RED", plan.state.safetyStatus)
        assertTrue(plan.workouts.isEmpty())
        assertEquals("BLOCK", plan.decision.action)
    }

    @Test
    fun `fadiga alta suspende qualidade e reduz volume`() {
        val normal = RunningCoachEngine.generate(input())
        val fatigued = RunningCoachEngine.generate(input().copy(fatigueScore = 80.0))
        assertEquals("YELLOW", fatigued.state.safetyStatus)
        assertFalse(fatigued.workouts.any { it.type == "Qualidade" })
        assertTrue(fatigued.weeklyKm < normal.weeklyKm)
    }

    @Test
    fun `nenhuma prescricao inventa pace individual`() {
        val plan = RunningCoachEngine.generate(input())
        assertTrue(plan.workouts.all { it.paceMode == "RPE" })
    }

    @Test
    fun `todas as sessoes possuem estrutura de blocos exportaveis`() {
        val plan = RunningCoachEngine.generate(input())
        assertTrue(plan.workouts.all { it.segments.size >= 3 })
        assertTrue(plan.workouts.all { it.sessionId.isNotBlank() })
    }
}

class TrainingAdaptationEngineTest {
    @Test
    fun `treino perdido nao e transferido para antes de longao proximo`() {
        val resolution = TrainingAdaptationEngine.reasonMissedWorkout(
            missedTitle = "Threshold",
            missedDistanceKm = 8.0,
            nextTitle = "Longão aeróbio",
            nextDistanceKm = 18.0,
            hoursUntilNext = 24
        )
        assertTrue(resolution.options.first().recommended)
        assertEquals("DROP", resolution.options.first().action)
    }


    @Test
    fun `muito leve nao e classificado como esforco excessivo`() {
        val analysis = TrainingAdaptationEngine.analyzeRun(
            TrainingAdaptationEngine.RunResult(
                distanceKm = 5.0,
                plannedDistanceKm = 5.0,
                perceivedEffort = "Muito leve",
                feeling = "Ótimo"
            )
        )
        assertEquals("Treino aeróbio registrado", analysis.headline)
        assertEquals(100, analysis.adherencePercent)
    }

    @Test
    fun `sem distancia real nao inventa aderencia`() {
        val analysis = TrainingAdaptationEngine.analyzeRun(
            TrainingAdaptationEngine.RunResult(
                distanceKm = null,
                plannedDistanceKm = 6.0,
                perceivedEffort = "Leve",
                feeling = "Bem"
            )
        )
        assertEquals(null, analysis.adherencePercent)
        assertTrue(analysis.insights.any { it.contains("não informada") })
    }

    @Test
    fun `relato de dor gera alerta de revisao`() {
        val analysis = TrainingAdaptationEngine.analyzeRun(
            TrainingAdaptationEngine.RunResult(
                distanceKm = 5.0,
                plannedDistanceKm = 5.0,
                painReported = true
            )
        )
        assertTrue(analysis.headline.contains("Dor reportada"))
    }
}
