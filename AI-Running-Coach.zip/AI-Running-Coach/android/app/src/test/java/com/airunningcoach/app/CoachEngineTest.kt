package com.airunningcoach.app

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CoachEngineTest {
    private fun input(frequency: Int = 4) = RunnerInput(
        goalKm = 10.0,
        level = "Intermediário",
        frequency = frequency,
        weeklyVolumeKm = 30.0,
        longestRecentKm = 10.0,
        startDate = LocalDate.of(2026, 11, 9)
    )

    @Test
    fun `gera oito semanas completas sem duplicar dia na mesma semana`() {
        for (frequency in 2..6) {
            val plan = RunningCoachEngine.generate(input(frequency))
            val prescribedFrequency = frequency
            assertEquals(prescribedFrequency * 8, plan.workouts.size)
            assertEquals(8, plan.weeklySummaries.size)
            assertTrue(plan.workouts.all { it.scheduledDateIso.matches(Regex("\\d{4}-\\d{2}-\\d{2}")) })
            plan.workouts.groupBy { it.week }.values.forEach { week ->
                assertEquals(prescribedFrequency, week.size)
                assertEquals(prescribedFrequency, week.map { it.date }.distinct().size)
            }
        }
    }

    @Test
    fun `volume semanal real nao e reduzido ao limite inferior de uma faixa`() {
        val plan = RunningCoachEngine.generate(input(3).copy(weeklyVolumeKm = 20.0, longestRecentKm = 10.0))
        assertEquals(20.0, plan.weeklySummaries.first().totalKm, 0.01)
        assertEquals(20.0, plan.state.recentVolumeKm, 0.01)
    }

    @Test
    fun `nivel intermediario nao substitui volume semanal real`() {
        val plan = RunningCoachEngine.generate(input(3).copy(level = "Intermediário", weeklyVolumeKm = 10.0, longestRecentKm = 10.0))
        assertEquals(10.0, plan.weeklySummaries.first().totalKm, 0.01)
        assertFalse(plan.workouts.any { it.type == "Qualidade" })
    }

    @Test
    fun `historico curto limita sessoes e explica reducao do volume`() {
        val plan = RunningCoachEngine.generate(input(3).copy(weeklyVolumeKm = 20.0, longestRecentKm = 3.0))
        assertTrue(plan.weeklySummaries.first().totalKm < 20.0)
        assertTrue(plan.state.flags.contains("WEEKLY_VOLUME_CAPPED_BY_RECENT_TOLERANCE"))
        assertTrue(plan.workouts.filter { it.week == 1 }.all { it.distanceKm <= 3.3 })
        assertTrue(plan.weeklySummaries.zipWithNext().all { (a, b) -> b.totalKm <= a.totalKm * 1.11 })
    }

    @Test
    fun `sem feedback recuperacao e seguranca nao sao exibidas como avaliadas`() {
        val plan = RunningCoachEngine.generate(input().copy(recoveryScore = null, fatigueScore = null))
        assertEquals("UNKNOWN", plan.state.recoveryStatus)
        assertEquals("UNASSESSED", plan.state.safetyStatus)
    }

    @Test
    fun `semanas quatro e oito sao regenerativas e reduzem a carga`() {
        val plan = RunningCoachEngine.generate(input())
        assertTrue(plan.weeklySummaries[3].isRecoveryWeek)
        assertTrue(plan.weeklySummaries[3].totalKm < plan.weeklySummaries[2].totalKm)
        assertTrue(plan.weeklySummaries[7].isRecoveryWeek)
        assertTrue(plan.weeklySummaries[7].totalKm < plan.weeklySummaries[6].totalKm)
    }

    @Test
    fun `progressao semanal nao salta mais de onze por cento`() {
        val plan = RunningCoachEngine.generate(input())
        assertTrue(plan.weeklySummaries.zipWithNext().all { (previous, next) -> next.totalKm <= previous.totalKm * 1.11 })
    }

    @Test
    fun `matriz de sessenta perfis nao gera dias duplicados ou distancias negativas`() {
        val levels = listOf("Iniciante", "Intermediário", "Avançado", "Elite")
        val volumes = listOf(5.0, 10.0, 20.0)
        var cases = 0
        levels.forEach { level ->
            for (frequency in 2..6) {
                volumes.forEach { volume ->
                    val plan = RunningCoachEngine.generate(input(frequency).copy(level = level, weeklyVolumeKm = volume, longestRecentKm = 10.0))
                    val prescribedFrequency = if (level == "Iniciante" || volume < 8.0) minOf(frequency, 3) else frequency
                    assertEquals(prescribedFrequency * 8, plan.workouts.size)
                    assertTrue(plan.workouts.all { it.distanceKm > 0.0 })
                    plan.workouts.groupBy { it.week }.values.forEach { sessions ->
                        assertEquals(prescribedFrequency, sessions.map { it.date }.distinct().size)
                    }
                    assertTrue(plan.weeklySummaries.zipWithNext().all { (a, b) -> b.totalKm <= a.totalKm * 1.11 })
                    cases++
                }
            }
        }
        assertEquals(60, cases)
    }


    @Test
    fun `tempo de sessao combina blocos por distancia e por tempo`() {
        val plan = RunningCoachEngine.generate(
            input(3).copy(weeklyVolumeKm = 18.0, longestRecentKm = 10.0, cooperDistanceKm = 2.1)
        )
        val mixedModeWorkout = plan.workouts.first { workout ->
            workout.segments.any { it.targetMode == "TIME" } && workout.segments.any { it.targetMode == "DISTANCE" }
        }
        val recomputed = WorkoutDurationEstimator.estimateMinutes(mixedModeWorkout.segments, mixedModeWorkout.distanceKm).coerceAtLeast(15)
        assertEquals(recomputed, mixedModeWorkout.durationMin)
        assertTrue("A sessão mista não pode mostrar apenas os minutos do desaquecimento", mixedModeWorkout.durationMin > 15)
    }

    @Test
    fun `longao permanece limitado pela parcela do volume e pela tolerancia recente`() {
        val plan = RunningCoachEngine.generate(input(5))
        plan.workouts.groupBy { it.week }.forEach { (_, sessions) ->
            val weeklyKm = sessions.sumOf { it.distanceKm }
            val longRunKm = sessions.single { it.type == "Longo" }.distanceKm
            val allowedShare = when {
                sessions.first().week == 4 -> 0.52
                sessions.size == 2 -> 0.52
                sessions.size >= 3 -> 0.42
                else -> 0.52
            }
            assertTrue(longRunKm <= weeklyKm * allowedShare)
            assertTrue(longRunKm <= 11.0)
            assertTrue(sessions.all { it.distanceKm <= 11.0 })
        }
    }


    @Test
    fun `longao e a maior sessao e rodagem facil fica proxima quando ha tres treinos`() {
        val plan = RunningCoachEngine.generate(input(3).copy(weeklyVolumeKm = 18.0, longestRecentKm = 10.0))
        val sessions = plan.workouts.filter { it.week == 1 }
        val longRun = sessions.single { it.type == "Longo" }
        val others = sessions.filter { it.type != "Longo" }
        assertTrue(longRun.distanceKm > others.maxOf { it.distanceKm })
        assertEquals(18.0, sessions.sumOf { it.distanceKm }, 0.01)
        assertEquals(7.0, longRun.distanceKm, 0.01)
        assertEquals(6.0, others.single { it.type == "Aeróbio" }.distanceKm, 0.01)
        assertEquals(5.0, others.single { it.type == "Qualidade" }.distanceKm, 0.01)
    }

    @Test
    fun `longao permanece a maior sessao em todas as frequencias`() {
        for (frequency in 2..6) {
            val plan = RunningCoachEngine.generate(input(frequency).copy(weeklyVolumeKm = 30.0, longestRecentKm = 10.0))
            plan.workouts.groupBy { it.week }.values.forEach { sessions ->
                val longRun = sessions.single { it.type == "Longo" }
                assertTrue("Frequência $frequency, semana ${longRun.week}: longão não é o maior", longRun.distanceKm >= sessions.filter { it.type != "Longo" }.maxOf { it.distanceKm })
            }
        }
    }

    @Test
    fun `volume semanal e reduzido quando a frequencia nao permite distribuir sem exceder a tolerancia`() {
        val plan = RunningCoachEngine.generate(input(2).copy(weeklyVolumeKm = 30.0, longestRecentKm = 6.0))
        assertTrue(plan.weeklySummaries.first().totalKm < 30.0)
        val sessions = plan.workouts.filter { it.week == 1 }
        assertTrue(sessions.single { it.type == "Longo" }.distanceKm > sessions.single { it.type != "Longo" }.distanceKm)
    }

    @Test
    fun `dor bloqueia a prescricao normal`() {
        val plan = RunningCoachEngine.generate(input().copy(painPresent = true))
        assertEquals("RED", plan.state.safetyStatus)
        assertTrue(plan.workouts.isEmpty())
        assertEquals("BLOCK", plan.decision.action)
    }

    @Test
    fun `fadiga alta suspende qualidade e reduz volume`() {
        val normal = RunningCoachEngine.generate(input())
        val fatigued = RunningCoachEngine.generate(input().copy(fatigueScore = 80.0))
        assertEquals("YELLOW", fatigued.state.safetyStatus)
        assertFalse(fatigued.workouts.any { it.type == "Qualidade" })
        assertTrue(fatigued.weeklyKm < normal.weeklyKm)
    }

    @Test
    fun `sem resultado recente nao inventa pace e mantem distancia como alvo`() {
        val plan = RunningCoachEngine.generate(input())
        assertTrue(plan.workouts.all { it.paceMode == "PACE_NOT_CALIBRATED" })
        val segments = plan.workouts.flatMap { it.segments }
        assertTrue(segments.all { it.targetMode == "DISTANCE" })
        assertTrue(segments.all { it.targetPaceMinValue == null && it.targetPaceMaxValue == null })
    }

    @Test
    fun `resultado recente gera faixas de pace e preserva RPE como apoio`() {
        val plan = RunningCoachEngine.generate(input().copy(cooperDistanceKm = 2.4))
        assertTrue(plan.workouts.all { it.paceMode == "PACE_RANGE" })
        val segments = plan.workouts.flatMap { it.segments }
        assertTrue(segments.any { it.targetMode == "TIME" })
        assertTrue(segments.any { it.targetMode == "DISTANCE" })
        assertTrue(segments.filter { it.targetMode == "TIME" }.all { it.durationMin != null })
        assertTrue(segments.filter { it.paceZone != null }.all { it.targetPaceMinValue != null && it.targetPaceMaxValue != null })
        assertTrue(segments.all { (it.targetPaceMinValue == null) == (it.targetPaceMaxValue == null) })
        val interval = plan.workouts.first { it.title == "Intervalos controlados (Z4 estimada)" }
        assertEquals("TIME", interval.segments.first { it.name == "Aquecimento" }.targetMode)
        assertTrue(interval.segments.any { it.targetMode == "DISTANCE" })
        assertEquals("TIME", interval.segments.first { it.name.contains("Recuperação") }.targetMode)
        assertTrue(segments.all { it.targetPaceMinValue!! <= it.targetPaceMaxValue!! })
        assertTrue(segments.all { it.rpeRange.isNotBlank() })
    }

    @Test
    fun `strides ficam como complemento tecnico e nao sao somados a semana de qualidade`() {
        val plan = RunningCoachEngine.generate(input(5).copy(cooperDistanceKm = 2.4))
        assertTrue(TrainingTypeCatalog.find("STRIDES")!!.zone == "Técnica")
        // A semana já contém uma sessão-chave; o motor não soma outra carga intensa em forma de strides.
        assertTrue(plan.workouts.filter { it.week == 1 }.flatMap { it.segments }
            .none { it.name.contains("strides", ignoreCase = true) })
    }

    @Test
    fun `todas as sessoes possuem estrutura de blocos exportaveis`() {
        val plan = RunningCoachEngine.generate(input())
        assertTrue(plan.workouts.all { it.segments.size >= 3 })
        assertTrue(plan.workouts.all { it.sessionId.isNotBlank() })
    }

    @Test
    fun `distancia dos blocos corresponde ao total da sessao exportada`() {
        val plan = RunningCoachEngine.generate(input(3).copy(weeklyVolumeKm = 20.0, longestRecentKm = 10.0))
        plan.workouts.forEach { workout ->
            val segmentDistance = workout.segments.sumOf { (it.distanceKm ?: 0.0) * it.repeatCount }
            assertEquals(workout.distanceKm, segmentDistance, 0.11)
        }
    }
    @Test
    fun `iniciante com muitos dias disponiveis recebe no maximo tres corridas caminhada`() {
        val allDays = listOf(java.time.DayOfWeek.MONDAY, java.time.DayOfWeek.TUESDAY, java.time.DayOfWeek.WEDNESDAY,
            java.time.DayOfWeek.THURSDAY, java.time.DayOfWeek.FRIDAY, java.time.DayOfWeek.SATURDAY)
        val plan = RunningCoachEngine.generate(input(6).copy(level = "Iniciante", availableDays = allDays,
            preferredLongRunDay = java.time.DayOfWeek.SATURDAY, weeklyVolumeKm = 4.0, longestRecentKm = 3.0))
        assertEquals(3 * 8, plan.workouts.size)
        assertTrue(plan.workouts.all { it.title.contains("corrida/caminhada", ignoreCase = true) || it.title.contains("longão leve", ignoreCase = true) })
        assertTrue(plan.workouts.all { workout -> workout.segments.any { it.name == "Corrida leve" } && workout.segments.any { it.name == "Caminhada de recuperação" } })
    }

    @Test
    fun `motor suprime qualidade quando disponibilidade nao permite dia completo de recuperacao`() {
        val closeDays = listOf(java.time.DayOfWeek.MONDAY, java.time.DayOfWeek.TUESDAY, java.time.DayOfWeek.WEDNESDAY)
        val plan = RunningCoachEngine.generate(input(3).copy(availableDays = closeDays,
            preferredLongRunDay = java.time.DayOfWeek.TUESDAY, weeklyVolumeKm = 24.0, longestRecentKm = 10.0))
        assertFalse(plan.workouts.any { it.type == "Qualidade" })
        assertTrue(plan.state.flags.contains("QUALITY_SUPPRESSED_BY_RECOVERY_SPACING"))
    }

    @Test
    fun `estimulo de qualidade diferencia 5k 10k meia maratona e maratona`() {
        fun qualityTitle(goalKm: Double, week: Int): String = RunningCoachEngine.generate(
            input(4).copy(goalKm = goalKm, planWeeks = week)
        ).workouts.first { it.week == week && it.type == "Qualidade" }.title

        assertEquals("Corrida progressiva", qualityTitle(5.0, 1))
        assertEquals("Corrida progressiva", qualityTitle(10.0, 1))
        assertEquals("Corrida moderada", qualityTitle(21.1, 1))
        assertEquals("Corrida moderada", qualityTitle(42.2, 1))
        assertEquals("Resistência específica (maratona)", qualityTitle(42.2, 3))
        assertEquals("Intervalos controlados (Z4 estimada)", qualityTitle(21.1, 3))
    }

    @Test
    fun `semana regenerativa reduz entre dez e vinte por cento da semana anterior`() {
        val plan = RunningCoachEngine.generate(input(4))
        val before = plan.weeklySummaries[2].totalKm
        val recovery = plan.weeklySummaries[3].totalKm
        val reduction = (before - recovery) / before
        assertTrue("Redução regenerativa foi ${(reduction * 100).toInt()}%", reduction in 0.10..0.20)
    }

    @Test
    fun `rodagem regenerativa usa pace Z1 tambem no alvo numerico`() {
        val plan = RunningCoachEngine.generate(input().copy(cooperDistanceKm = 2.4, planWeeks = 4))
        val recoverySessions = plan.workouts.filter { it.week == 4 && it.type == "Recuperação" }
        assertTrue(recoverySessions.isNotEmpty())
        val expected = PaceCalculator.calculateCooper(2.4)!!.z1.range
        recoverySessions.forEach { session ->
            val main = session.segments.first { it.name == "Bloco aeróbio" }
            assertEquals("Z1", main.paceZone)
            assertEquals(expected.fastestPaceValue, main.targetPaceMinValue)
            assertEquals(expected.slowestPaceValue, main.targetPaceMaxValue)
        }
    }

}

class TrainingAdaptationEngineTest {
    @Test
    fun `treino perdido nao e transferido para antes de longao proximo`() {
        val resolution = TrainingAdaptationEngine.reasonMissedWorkout(
            missedTitle = "Threshold",
            missedDistanceKm = 8.0,
            nextTitle = "Longão aeróbio",
            nextDistanceKm = 18.0,
            hoursUntilNext = 24
        )
        assertTrue(resolution.options.first().recommended)
        assertEquals("DROP", resolution.options.first().action)
    }


    @Test
    fun `muito leve nao e classificado como esforco excessivo`() {
        val analysis = TrainingAdaptationEngine.analyzeRun(
            TrainingAdaptationEngine.RunResult(
                distanceKm = 5.0,
                plannedDistanceKm = 5.0,
                perceivedEffort = "Muito leve",
                feeling = "Ótimo"
            )
        )
        assertEquals("Treino aeróbio registrado", analysis.headline)
        assertEquals(100, analysis.adherencePercent)
    }

    @Test
    fun `sem distancia real nao inventa aderencia`() {
        val analysis = TrainingAdaptationEngine.analyzeRun(
            TrainingAdaptationEngine.RunResult(
                distanceKm = null,
                plannedDistanceKm = 6.0,
                perceivedEffort = "Leve",
                feeling = "Bem"
            )
        )
        assertEquals(null, analysis.adherencePercent)
        assertTrue(analysis.insights.any { it.contains("não informada") })
    }

    @Test
    fun `relato de dor gera alerta de revisao`() {
        val analysis = TrainingAdaptationEngine.analyzeRun(
            TrainingAdaptationEngine.RunResult(
                distanceKm = 5.0,
                plannedDistanceKm = 5.0,
                painReported = true
            )
        )
        assertTrue(analysis.headline.contains("Dor reportada"))
    }

}
