package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class AppBackupCodecTest {
    @Test fun roundTripPreservesAllSupportedPreferenceTypesAndSavedRecords() {
        val source = mapOf<String, Any>(
            "name" to "Atleta",
            "frequency" to 3,
            "createdAt" to 1762862400000L,
            "cooperEnabled" to true,
            "volumeFactor" to 1.25f,
            "availableTrainingDaysSet" to setOf("MONDAY", "WEDNESDAY", "FRIDAY"),
            "workouts" to "[]",
            "raceEvents" to "[]",
            "feedbackRecords" to "[]",
            "cooperAssessments" to "[]",
            "racePlanWarnings" to "[]",
            "motorState" to "{}"
        )

        val decoded = AppBackupCodec.decode(AppBackupCodec.encode(source, "2026-11-11T12:00:00Z"))
        source.filterKeys { it !in setOf("selectedScreen", "selectedWorkoutIndex") }.forEach { (key, value) ->
            assertEquals("Mismatch in $key", value, decoded[key])
        }
    }

    @Test fun backupDoesNotRestoreTransientNavigationState() {
        val encoded = AppBackupCodec.encode(mapOf("name" to "Atleta", "selectedScreen" to 9, "selectedWorkoutIndex" to 4))
        val decoded = AppBackupCodec.decode(encoded)
        assertTrue(decoded.containsKey("name"))
        assertFalse(decoded.containsKey("selectedScreen"))
        assertFalse(decoded.containsKey("selectedWorkoutIndex"))
    }

    @Test fun rejectsWrongApplicationAndUnsupportedFormat() {
        val wrongApp = AppBackupCodec.encode(mapOf("name" to "Atleta")).replace("com.airunningcoach.app", "other.app")
        assertThrows(IllegalArgumentException::class.java) { AppBackupCodec.decode(wrongApp) }
        assertThrows(IllegalArgumentException::class.java) { AppBackupCodec.decode("{\"format\":\"unknown\"}") }
    }

    @Test fun rejectsMalformedSavedWorkoutJsonBeforeRestore() {
        val broken = AppBackupCodec.encode(mapOf("name" to "Atleta", "workouts" to "not-json"))
        assertThrows(Exception::class.java) { AppBackupCodec.decode(broken) }
    }

    @Test fun acceptsAnEmptyBackupForAProfileNotYetConfigured() {
        assertTrue(AppBackupCodec.decode(AppBackupCodec.encode(emptyMap<String, Any>())).isEmpty())
    }

    @Test fun rejectsWrongPreferenceTypesBeforeRestore() {
        val wrongType = AppBackupCodec.encode(mapOf("frequency" to "three"))
        assertThrows(IllegalArgumentException::class.java) { AppBackupCodec.decode(wrongType) }
    }
}
