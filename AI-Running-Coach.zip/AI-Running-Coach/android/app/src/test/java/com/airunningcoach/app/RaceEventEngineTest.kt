package com.airunningcoach.app

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RaceEventEngineTest {
    private val start = LocalDate.of(2026, 11, 9) // Monday

    private fun workout(dayOffset: Long, week: Int = 1, type: String = "Aeróbio", id: String = "w$dayOffset"): PrescribedWorkout {
        return PrescribedWorkout(
            day = "Dia", date = "Data", scheduledDateIso = start.plusDays(dayOffset).toString(),
            title = if (type == "Longo") "Longão" else if (type == "Qualidade") "Qualidade" else "Rodagem",
            type = type, objective = "Objetivo", stimulus = "AEROBIC", sessionId = id,
            distanceKm = if (type == "Longo") 8.0 else 5.0, durationMin = 40,
            intensity = "LOW", paceMode = "PACE_RANGE", rpeRange = "3-4", detail = "Detalhe",
            rationale = "Justificativa", week = week, phase = "PROGRESSION",
            segments = listOf(WorkoutSegment("Corrida", "Confortável", durationMin = 30, targetMode = "TIME"))
        )
    }

    private fun event(date: LocalDate, priority: String = "A", distance: Double = 10.0) = RaceEvent(
        id = "race-${date}", name = "Prova teste", distanceKm = distance,
        eventDateIso = date.toString(), priority = priority
    )

    @Test
    fun `valida evento e aceita tempo em mmss ou hhmmss`() {
        assertEquals(null, RaceEventEngine.validate("Corrida", 10.0, "15/11/2026", "A", "01:09:55"))
        assertEquals(null, RaceEventEngine.validate("Corrida", 10.0, "15/11/2026", "B", "69:55"))
        assertTrue(RaceEventEngine.validate("", 10.0, "15/11/2026", "A", "") != null)
        assertTrue(RaceEventEngine.validate("Corrida", 10.0, "31/02/2026", "A", "") != null)
    }


    @Test
    fun `data impossivel e rejeitada sem normalizacao automatica`() {
        assertTrue(RaceEventEngine.validate("Corrida", 10.0, "31/02/2026", "A", "") != null)
        assertTrue(RaceEventEngine.validate("Corrida", 10.0, "29/02/2025", "A", "") != null)
        assertEquals(null, RaceEventEngine.validate("Corrida", 10.0, "28/02/2026", "A", ""))
    }

    @Test
    fun `semana atual permanece no plano mesmo quando segunda ja passou`() {
        val today = start.plusDays(1) // terça-feira, 10/11/2026
        val currentWeekRace = event(start.plusDays(5), "A", 10.0).copy(id = "this-week")
        val futureGoal = event(start.plusWeeks(3).plusDays(6), "A", 21.1).copy(id = "next-cycle")
        val window = RaceEventEngine.resolvePlanWindow(today, listOf(currentWeekRace, futureGoal))
        assertEquals(start, window.startDate)
        assertEquals("this-week", window.primaryRaceId)
        assertEquals(1, window.raceWeek)
        assertTrue(window.raceInsideWindow)
    }

    @Test
    fun `prova que ja passou nao comanda o planejamento da semana atual`() {
        val today = start.plusDays(1)
        val yesterdayRace = event(start, "A", 10.0).copy(id = "past")
        val futureGoal = event(start.plusWeeks(3).plusDays(6), "A", 21.1).copy(id = "future")
        val window = RaceEventEngine.resolvePlanWindow(today, listOf(yesterdayRace, futureGoal))
        assertEquals(start, window.startDate)
        assertEquals("future", window.primaryRaceId)
    }

    @Test
    fun `janela do plano inclui semana da prova principal e semana posterior`() {
        val race = event(start.plusWeeks(7).plusDays(6))
        val window = RaceEventEngine.resolvePlanWindow(start, listOf(race))
        assertEquals(start, window.startDate)
        assertEquals(9, window.weeks)
        assertTrue(window.raceInsideWindow)
    }

    @Test
    fun `prova a substitui longao e reduz frequencia para treinos mais prova`() {
        val sessions = listOf(
            workout(1, id = "tue"),
            workout(3, type = "Qualidade", id = "thu"),
            workout(6, type = "Longo", id = "sun")
        )
        val race = event(start.plusDays(6))
        val adjusted = RaceEventEngine.applyToPlan(sessions, listOf(race), start, 3, null)
        assertEquals(2, adjusted.workouts.size)
        assertTrue(adjusted.replacedSessionIds.contains("sun"))
        assertEquals(3, adjusted.workouts.size + 1) // two training sessions + one race
    }

    @Test
    fun `prova nesta semana substitui sessao pendente antes do novo ciclo`() {
        val currentMonday = start.minusWeeks(1)
        val sessions = listOf(
            workout(-5, id = "current-wed"),
            workout(-3, type = "Qualidade", id = "current-fri"),
            workout(-1, type = "Longo", id = "current-sun")
        )
        val race = event(start.minusDays(1))
        val adjusted = RaceEventEngine.applyToPlan(sessions, listOf(race), currentMonday, 3, null, today = currentMonday)
        assertEquals(2, adjusted.workouts.size)
        assertTrue(adjusted.replacedSessionIds.contains("current-sun"))
    }

    @Test
    fun `prova no sabado substitui longao de domingo e nao aumenta compromissos`() {
        val sessions = listOf(workout(1, id = "tue"), workout(3, type = "Qualidade", id = "thu"), workout(6, type = "Longo", id = "sun"))
        val adjusted = RaceEventEngine.applyToPlan(sessions, listOf(event(start.plusDays(5))), start, 3, null)
        assertEquals(2, adjusted.workouts.size)
        assertTrue(adjusted.replacedSessionIds.contains("sun"))
    }

    @Test
    fun `taper reduz e converte qualidade na semana da prova`() {
        val sessions = listOf(
            workout(1, id = "tue"),
            workout(3, type = "Qualidade", id = "thu"),
            workout(6, type = "Longo", id = "sun")
        )
        val adjusted = RaceEventEngine.applyToPlan(sessions, listOf(event(start.plusDays(6), distance = 21.1)), start, 3, null)
        val preRaceQuality = adjusted.workouts.first { it.sessionId == "thu" }
        assertEquals("TAPER", preRaceQuality.phase)
        assertNotEquals("Qualidade", preRaceQuality.type)
        assertTrue(preRaceQuality.distanceKm < 5.0)
        assertTrue(adjusted.taperedSessionIds.contains("thu"))
    }

    @Test
    fun `semana posterior a prova recebe recuperacao`() {
        val sessions = listOf(
            workout(8, week = 2, id = "week2-tue"),
            workout(10, week = 2, type = "Qualidade", id = "week2-thu"),
            workout(13, week = 2, type = "Longo", id = "week2-sun")
        )
        val race = event(start.plusDays(6), distance = 21.1)
        val adjusted = RaceEventEngine.applyToPlan(sessions, listOf(race), start, 3, null)
        assertTrue(adjusted.workouts.all { it.phase == "POST_RACE_RECOVERY" })
        assertTrue(adjusted.workouts.all { it.type == "Recuperação" })
        assertTrue(adjusted.recoverySessionIds.size == 3)
    }

    @Test
    fun `eventos cancelados e eventos fora do horizonte nao alteram sessoes`() {
        val sessions = listOf(workout(1, id = "tue"), workout(3, type = "Qualidade", id = "thu"), workout(6, type = "Longo", id = "sun"))
        val cancelled = event(start.plusDays(6)).copy(status = "CANCELLED")
        val distant = event(start.plusWeeks(20))
        val adjusted = RaceEventEngine.applyToPlan(sessions, listOf(cancelled, distant), start, 3, null)
        assertEquals(3, adjusted.workouts.size)
        assertTrue(adjusted.replacedSessionIds.isEmpty())
    }

    @Test
    fun `duas provas na mesma semana substituem duas sessoes`() {
        val sessions = listOf(workout(1, id = "tue"), workout(3, type = "Qualidade", id = "thu"), workout(6, type = "Longo", id = "sun"))
        val races = listOf(event(start.plusDays(5), "A"), event(start.plusDays(6), "B", 5.0).copy(id = "race-b"))
        val adjusted = RaceEventEngine.applyToPlan(sessions, races, start, 3, null)
        assertEquals(1, adjusted.workouts.size)
        assertEquals(2, adjusted.replacedSessionIds.size)
        assertTrue(adjusted.workouts.size + races.size <= 3)
    }

    @Test
    fun `treinos concluidos nao fazem parte da camada de eventos`() {
        val past = event(start.minusDays(2)).copy(status = "COMPLETED")
        val window = RaceEventEngine.resolvePlanWindow(start, listOf(past))
        assertEquals(8, window.weeks)
        assertFalse(window.raceInsideWindow)
    }
    @Test
    fun `prova conta como um dos compromissos semanais para frequencias de dois a seis dias`() {
        for (frequency in 2..6) {
            val input = RunnerInput(
                goalKm = 10.0,
                level = "Intermediário",
                frequency = frequency,
                weeklyVolumeKm = 30.0,
                longestRecentKm = 10.0,
                planWeeks = 4,
                startDate = start
            )
            val window = RaceEventEngine.resolvePlanWindow(start, listOf(event(start.plusWeeks(2).plusDays(6))))
            val generated = RunningCoachEngine.generate(input.copy(planWeeks = window.weeks, startDate = window.startDate))
            val adjusted = RaceEventEngine.applyToPlan(
                generated.workouts,
                listOf(event(start.plusWeeks(2).plusDays(6))),
                window.startDate,
                frequency,
                null
            )
            val raceWeekTraining = adjusted.workouts.count { it.week == 3 }
            assertEquals(frequency - 1, raceWeekTraining)
            assertEquals(frequency, raceWeekTraining + 1)
        }
    }

    @Test
    fun `prova ja ocorrida nao substitui treino pendente da semana atual`() {
        val today = start.plusDays(1)
        val sessions = listOf(
            workout(2, week = 1, type = "Aeróbio", id = "wed"),
            workout(4, week = 1, type = "Longo", id = "fri")
        )
        val pastRace = event(start, "A", 10.0).copy(id = "past")
        val adjusted = RaceEventEngine.applyToPlan(sessions, listOf(pastRace), start, 2, null, today = today)
        assertEquals(2, adjusted.workouts.size)
        assertTrue(adjusted.replacedSessionIds.isEmpty())
        assertTrue(adjusted.taperedSessionIds.isEmpty())
    }

}
