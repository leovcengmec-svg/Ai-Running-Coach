package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PaceCalculatorTest {
    @Test
    fun `parseia tempo mm ss`() {
        assertEquals(1530, PaceCalculator.parseMmSs("25:30"))
        assertEquals(3600, PaceCalculator.parseMmSs("60:00"))
        assertNull(PaceCalculator.parseMmSs("25:75"))
        assertNull(PaceCalculator.parseMmSs("25"))
        assertNull(PaceCalculator.parseMmSs("abc"))
    }

    @Test
    fun `converte resultado de cinco km em faixas coerentes`() {
        val zones = PaceCalculator.calculate(5.0, 25 * 60)
        assertNotNull(zones)
        zones!!
        assertEquals(300, zones.estimatedFiveKmPaceSecPerKm)
        assertEquals("6:00–6:45 min/km", zones.easy.label())
        assertEquals("5:15–5:30 min/km", zones.threshold.label())
        assertTrue(zones.recovery.fastestSecPerKm > zones.easy.fastestSecPerKm)
        assertTrue(zones.longRun.fastestSecPerKm >= zones.easy.fastestSecPerKm)
    }

    @Test
    fun `converte resultado de dez km para equivalente de cinco km`() {
        val zones = PaceCalculator.calculate(10.0, 50 * 60)
        assertNotNull(zones)
        assertTrue(zones!!.estimatedFiveKmPaceSecPerKm < 300)
        assertTrue(zones.threshold.fastestSecPerKm < zones.easy.fastestSecPerKm)
    }

    @Test
    fun `nao comprime tempo extremo para um pace artificial`() {
        assertNull(PaceCalculator.calculate(5.0, 180 * 60))
        assertNotNull(PaceCalculator.calculate(10.0, 90 * 60))
    }

    @Test
    fun `blocos reconhecem alvo por tempo ou distancia`() {
        val byTime = WorkoutSegment(name = "Limiar", instruction = "Controlado", durationMin = 6)
        val byDistance = WorkoutSegment(name = "Rodagem", instruction = "Leve", distanceKm = 2.0)
        assertEquals("TIME", byTime.targetMode)
        assertEquals("DISTANCE", byDistance.targetMode)
    }

    @Test
    fun `nao cria zonas sem distancia e tempo validos`() {
        assertNull(PaceCalculator.calculate(null, 1500))
        assertNull(PaceCalculator.calculate(5.0, null))
        assertNull(PaceCalculator.calculate(4.0, 1500))
        assertNull(PaceCalculator.calculate(5.0, 500))
    }
}
