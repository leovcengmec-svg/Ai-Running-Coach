package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PaceCalculatorTest {
    @Test
    fun `aceita tempo de atividade em mm ss e hh mm ss`() {
        assertEquals(4_195, PaceCalculator.parseDuration("69:55"))
        assertEquals(4_195, PaceCalculator.parseDuration("01:09:55"))
        assertEquals(1_530, PaceCalculator.parseDuration("25:30"))
        assertEquals("01:09:55", PaceRange.formatDuration(4_195))
        assertEquals("25:30", PaceRange.formatDuration(1_530))
    }

    @Test
    fun `rejeita duracoes com componentes invalidos`() {
        assertNull(PaceCalculator.parseDuration("25:75"))
        assertNull(PaceCalculator.parseDuration("1:69:55"))
        assertNull(PaceCalculator.parseDuration("01:09:60"))
        assertEquals(10_801, PaceCalculator.parseDuration("03:00:01"))
        assertNull(PaceCalculator.parseDuration("24:00:00"))
        assertNull(PaceCalculator.parseDuration("25"))
        assertNull(PaceCalculator.parseDuration("abc"))
    }

    @Test
    fun `cooper calcula pace medio e cinco zonas em mm ss min km`() {
        val zones = PaceCalculator.calculateCooper(2.40)
        assertNotNull(zones)
        zones!!
        assertEquals("5:00", PaceRange.format(zones.averageTestPaceValue))
        assertEquals("COOPER_12_MIN_ESTIMATED_MAS", zones.method)
        assertEquals(listOf("Z1", "Z2", "Z3", "Z4", "Z5"), zones.all().map { it.id })
        assertTrue(zones.all().all { it.range.fastestPaceValue < it.range.slowestPaceValue })
        assertTrue(zones.z1.range.fastestPaceValue > zones.z2.range.fastestPaceValue)
        assertTrue(zones.z2.range.fastestPaceValue > zones.z3.range.fastestPaceValue)
        assertTrue(zones.z3.range.fastestPaceValue > zones.z4.range.fastestPaceValue)
        assertTrue(zones.z4.range.fastestPaceValue > zones.z5.range.fastestPaceValue)
        assertTrue(zones.z1.intensityBand.contains("referência aeróbia estimada"))
    }

    @Test
    fun `cooper de dois quatro km estima vo2 pela equacao classica`() {
        val zones = PaceCalculator.calculateCooper(2.4)!!
        assertEquals(42.3544, zones.estimatedVo2Max!!, 0.001)
    }

    @Test
    fun `cooper rejeita distancia fora da faixa validada`() {
        assertNull(PaceCalculator.calculateCooper(null))
        assertNull(PaceCalculator.calculateCooper(0.9))
        assertNotNull(PaceCalculator.calculateCooper(5.0))
        assertNull(PaceCalculator.calculateCooper(5.1))
        assertNull(PaceCalculator.calculateCooper(Double.NaN))
    }

    @Test
    fun `duracao e pace real de atividade sao calculados separadamente`() {
        val duration = PaceCalculator.parseDuration("01:09:55")!!
        val pace = PaceCalculator.paceFromDistanceAndDuration(10.0, duration)
        assertEquals("7:00", PaceRange.format(pace!!))
        assertEquals("7:00", PaceCalculator.formatPace(pace))
    }

    @Test
    fun `zonas de cooper nao precisam de tempo ou distancia em outra unidade`() {
        val zones = PaceCalculator.calculateCooper(2.5)
        assertNotNull(zones)
        assertEquals("4:48", PaceRange.format(zones!!.averageTestPaceValue))
        assertTrue(zones.all().all { it.range.label().endsWith("min/km") })
    }

    @Test
    fun `blocos reconhecem alvo por tempo ou distancia em km`() {
        val byTime = WorkoutSegment(name = "Limiar", instruction = "Controlado", durationMin = 6)
        val byDistance = WorkoutSegment(name = "Rodagem", instruction = "Leve", distanceKm = 2.0)
        assertEquals("TIME", byTime.targetMode)
        assertEquals("DISTANCE", byDistance.targetMode)
    }
}
