package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PaceCalculatorTest {
    @Test
    fun `aceita tempo de atividade em mm ss e hh mm ss`() {
        assertEquals(4_195, PaceCalculator.parseDuration("69:55"))
        assertEquals(4_195, PaceCalculator.parseDuration("01:09:55"))
        assertEquals(1_530, PaceCalculator.parseDuration("25:30"))
        assertEquals("01:09:55", PaceRange.formatDuration(4_195))
        assertEquals("25:30", PaceRange.formatDuration(1_530))
    }

    @Test
    fun `rejeita duracoes com componentes invalidos`() {
        assertNull(PaceCalculator.parseDuration("25:75"))
        assertNull(PaceCalculator.parseDuration("1:69:55"))
        assertNull(PaceCalculator.parseDuration("01:09:60"))
        assertEquals(10_801, PaceCalculator.parseDuration("03:00:01"))
        assertNull(PaceCalculator.parseDuration("24:00:00"))
        assertNull(PaceCalculator.parseDuration("25"))
        assertNull(PaceCalculator.parseDuration("abc"))
    }

    @Test
    fun `cooper de 2 e 10 usa regressao para vam e segundo limiar`() {
        val zones = PaceCalculator.calculateCooper(2.10)!!
        assertEquals("5:43", PaceRange.format(zones.averageTestPaceValue))
        assertEquals("4:56", zones.estimatedMasPace)
        assertEquals("5:41", zones.estimatedSvt2Pace)
        assertEquals("Cooper 12 min • VAM e segundo limiar estimados", zones.method)
        assertEquals("AIRC_ZONES_2_MAS_SVT2_2018_2022", zones.modelVersion)
    }

    @Test
    fun `cooper de 2 e 10 gera faixas do modelo de cinco zonas`() {
        val zones = PaceCalculator.calculateCooper(2.10)!!
        assertEquals("8:43–11:28 min/km", zones.z1.range.label())
        assertEquals("7:12–8:43 min/km", zones.z2.range.label())
        assertEquals("6:12–7:12 min/km", zones.z3.range.label())
        assertEquals("5:16–6:12 min/km", zones.z4.range.label())
        assertEquals("4:42–5:16 min/km", zones.z5.range.label())
        assertEquals(listOf("Z1", "Z2", "Z3", "Z4", "Z5"), zones.all().map { it.id })
    }

    @Test
    fun `zonas sao contiguas e ficam ordenadas da mais lenta para mais rapida`() {
        val zones = PaceCalculator.calculateCooper(2.4)!!
        val all = zones.all()
        assertTrue(all.all { it.range.fastestPaceValue < it.range.slowestPaceValue })
        for (i in 0 until all.lastIndex) {
            assertEquals(all[i].range.fastestPaceValue, all[i + 1].range.slowestPaceValue)
            assertTrue(all[i].range.slowestPaceValue > all[i + 1].range.slowestPaceValue)
        }
        assertTrue(zones.z1.intensityBand.contains("R0"))
        assertTrue(zones.z2.intensityBand.contains("R1"))
        assertTrue(zones.z3.intensityBand.contains("R2"))
        assertTrue(zones.z4.intensityBand.contains("R3"))
        assertTrue(zones.z5.intensityBand.contains("R3+"))
    }

    @Test
    fun `segundo limiar estimado fica dentro da zona quatro`() {
        listOf(1.0, 1.5, 2.1, 2.4, 3.0, 4.0, 5.0).forEach { distance ->
            val zones = PaceCalculator.calculateCooper(distance)!!
            assertTrue(
                "O segundo limiar deve ficar na Z4 para Cooper ${distance} km",
                zones.estimatedSvt2PaceValue in zones.z4.range.fastestPaceValue..zones.z4.range.slowestPaceValue
            )
        }
    }

    @Test
    fun `cooper de 2 e 4 calcula vo2max pela equacao classica`() {
        val zones = PaceCalculator.calculateCooper(2.4)!!
        assertEquals(42.3544, zones.estimatedVo2Max, 0.001)
    }

    @Test
    fun `cooper rejeita distancia fora da faixa validada`() {
        assertNull(PaceCalculator.calculateCooper(null))
        assertNull(PaceCalculator.calculateCooper(0.9))
        assertNotNull(PaceCalculator.calculateCooper(5.0))
        assertNull(PaceCalculator.calculateCooper(5.1))
        assertNull(PaceCalculator.calculateCooper(Double.NaN))
    }

    @Test
    fun `duracao e pace real de atividade sao calculados separadamente`() {
        val duration = PaceCalculator.parseDuration("01:09:55")!!
        val pace = PaceCalculator.paceFromDistanceAndDuration(10.0, duration)
        assertEquals("7:00", PaceRange.format(pace!!))
        assertEquals("7:00", PaceCalculator.formatPace(pace))
    }

    @Test
    fun `todas as faixas sao exibidas em mm ss min por km`() {
        val zones = PaceCalculator.calculateCooper(2.5)!!
        assertEquals("4:48", PaceRange.format(zones.averageTestPaceValue))
        assertTrue(zones.all().all { it.range.label().endsWith("min/km") })
        assertTrue(zones.estimatedMasPace.matches(Regex("\\d{1,2}:\\d{2}")))
        assertTrue(zones.estimatedSvt2Pace.matches(Regex("\\d{1,2}:\\d{2}")))
    }

    @Test
    fun `blocos reconhecem alvo por tempo ou distancia em km`() {
        val byTime = WorkoutSegment(name = "Limiar", instruction = "Controlado", durationMin = 6)
        val byDistance = WorkoutSegment(name = "Rodagem", instruction = "Leve", distanceKm = 2.0)
        assertEquals("TIME", byTime.targetMode)
        assertEquals("DISTANCE", byDistance.targetMode)
    }
}
