package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PaceCalculatorTest {
    @Test
    fun `aceita tempo de atividade em mm ss e hh mm ss`() {
        assertEquals(4_195, PaceCalculator.parseDuration("69:55"))
        assertEquals(4_195, PaceCalculator.parseDuration("01:09:55"))
        assertEquals(1_530, PaceCalculator.parseDuration("25:30"))
        assertEquals("01:09:55", PaceRange.formatDuration(4_195))
        assertEquals("25:30", PaceRange.formatDuration(1_530))
    }

    @Test
    fun `rejeita duracoes com componentes invalidos`() {
        assertNull(PaceCalculator.parseDuration("25:75"))
        assertNull(PaceCalculator.parseDuration("1:69:55"))
        assertNull(PaceCalculator.parseDuration("01:09:60"))
        assertEquals(10_801, PaceCalculator.parseDuration("03:00:01"))
        assertNull(PaceCalculator.parseDuration("24:00:00"))
        assertNull(PaceCalculator.parseDuration("25"))
        assertNull(PaceCalculator.parseDuration("abc"))
    }

    @Test
    fun `cooper de 2 e 10 mantem referencias complementares de vam e segundo limiar`() {
        val zones = PaceCalculator.calculateCooper(2.10)!!
        assertEquals("5:43", PaceRange.format(zones.averageTestPaceValue))
        assertEquals("4:56", zones.estimatedMasPace)
        assertEquals("5:41", zones.estimatedSvt2Pace)
        assertEquals("AIRC_ZONES_4_COOPER_TALK_MAS_REFERENCE_2026", zones.modelVersion)
        assertEquals("COOPER_INITIAL", zones.z2CalibrationStatus)
    }

    @Test
    fun `cooper de 2 e 10 reproduz as bandas percentuais da planilha`() {
        val zones = PaceCalculator.calculateCooper(2.10)!!
        assertEquals("8:10–9:31 min/km", zones.z1.range.label())
        assertEquals("7:09–8:10 min/km", zones.z2.range.label())
        assertEquals("6:21–7:09 min/km", zones.z3.range.label())
        assertEquals("5:43–6:21 min/km", zones.z4.range.label())
        assertEquals("4:56–5:43 min/km", zones.z5.range.label())
        assertTrue(zones.z5.intensityBand.contains("VAM estimada"))
        assertTrue(zones.z5.intensityBand.contains("não é VO₂máx medido"))
        assertTrue(zones.z5.purpose.contains("não representa VO₂máx medido"))
        assertTrue(zones.z2.intensityBand.contains("velocidade média do Cooper"))
        assertTrue(!zones.z2.intensityBand.contains("VO₂máx"))
    }


    @Test
    fun `z5 informa a origem da referencia mesmo sem teste da fala`() {
        val withMasReference = PaceCalculator.calculateCooper(2.10)!!
        assertTrue(withMasReference.z5.intensityBand.contains("VAM estimada"))
        assertTrue(withMasReference.z5.intensityBand.contains("não é VO₂máx medido"))

        val conservativeFallback = PaceCalculator.calculateCooper(1.0)!!
        assertTrue(conservativeFallback.z5.intensityBand.contains("banda conservadora do Cooper"))
        assertTrue(conservativeFallback.z5.intensityBand.contains("não é VO₂máx medido"))
    }

    @Test
    fun `zonas sao contiguas e ficam ordenadas depois do arredondamento`() {
        listOf(1.0, 1.4, 1.9, 2.1, 2.4, 3.0, 4.0, 5.0).forEach { distance ->
            val zones = PaceCalculator.calculateCooper(distance)!!
            val all = zones.all()
            assertTrue(all.all { it.range.fastestPaceValue < it.range.slowestPaceValue })
            for (i in 0 until all.lastIndex) {
                assertEquals(all[i].range.fastestPaceValue, all[i + 1].range.slowestPaceValue)
                assertTrue(all[i].range.slowestPaceValue > all[i + 1].range.slowestPaceValue)
            }
        }
    }

    @Test
    fun `uma unica observacao do teste da fala nao altera a z2`() {
        val baseline = PaceCalculator.calculateCooper(2.10)!!
        val oneObservation = PaceCalculator.calculateCooper(2.10, listOf(440))!!
        assertEquals("TALK_TEST_PENDING", oneObservation.z2CalibrationStatus)
        assertEquals(baseline.z2.range, oneObservation.z2.range)
    }

    @Test
    fun `duas observacoes consistentes personalizam a fronteira da z2`() {
        val baseline = PaceCalculator.calculateCooper(2.10)!!
        val calibrated = PaceCalculator.calculateCooper(2.10, listOf(440, 445))!!
        assertEquals("TALK_TEST_CONFIRMED", calibrated.z2CalibrationStatus)
        assertEquals(2, calibrated.talkTestEvidenceCount)
        assertEquals("7:23", calibrated.talkTestReferencePace)
        assertEquals("7:33–8:10 min/km", calibrated.z2.range.label())
        assertTrue(calibrated.z2.range != baseline.z2.range)
        assertTrue(calibrated.z2.intensityBand.contains("teste da fala"))
        assertTrue(calibrated.z1.intensityBand.contains("fronteira aeróbia"))
        assertTrue(calibrated.z3.intensityBand.contains("fronteira aeróbia"))
        assertEquals(calibrated.z2.range.fastestPaceValue, calibrated.z3.range.slowestPaceValue)
        assertEquals(calibrated.z1.range.fastestPaceValue, calibrated.z2.range.slowestPaceValue)
    }

    @Test
    fun `observacoes inconsistentes nao alteram a faixa inicial`() {
        val baseline = PaceCalculator.calculateCooper(2.10)!!
        val inconsistent = PaceCalculator.calculateCooper(2.10, listOf(430, 490))!!
        assertEquals("TALK_TEST_INCONSISTENT", inconsistent.z2CalibrationStatus)
        assertEquals(baseline.z2.range, inconsistent.z2.range)
    }

    @Test
    fun `limites personalizados mantem todas as zonas com largura positiva`() {
        listOf(listOf(370, 380), listOf(440, 445), listOf(500, 510)).forEach { evidence ->
            val zones = PaceCalculator.calculateCooper(2.10, evidence)!!
            assertTrue(zones.all().all { it.range.fastestPaceValue < it.range.slowestPaceValue })
            for (i in 0 until zones.all().lastIndex) {
                assertEquals(zones.all()[i].range.fastestPaceValue, zones.all()[i + 1].range.slowestPaceValue)
            }
        }
    }

    @Test
    fun `cooper de 2 e 4 calcula vo2max pela equacao classica`() {
        val zones = PaceCalculator.calculateCooper(2.4)!!
        assertEquals(42.3544, zones.estimatedVo2Max, 0.001)
    }

    @Test
    fun `cooper rejeita distancia fora da faixa validada`() {
        assertNull(PaceCalculator.calculateCooper(null))
        assertNull(PaceCalculator.calculateCooper(0.9))
        assertNotNull(PaceCalculator.calculateCooper(5.0))
        assertNull(PaceCalculator.calculateCooper(5.1))
        assertNull(PaceCalculator.calculateCooper(Double.NaN))
    }

    @Test
    fun `duracao e pace real de atividade sao calculados separadamente`() {
        val duration = PaceCalculator.parseDuration("01:09:55")!!
        val pace = PaceCalculator.paceFromDistanceAndDuration(10.0, duration)
        assertEquals("7:00", PaceRange.format(pace!!))
        assertEquals("7:00", PaceCalculator.formatPace(pace))
    }

    @Test
    fun `todas as faixas sao exibidas em mm ss min por km`() {
        val zones = PaceCalculator.calculateCooper(2.5)!!
        assertEquals("4:48", PaceRange.format(zones.averageTestPaceValue))
        assertTrue(zones.all().all { it.range.label().endsWith("min/km") })
        assertTrue(zones.estimatedMasPace.matches(Regex("\\d{1,2}:\\d{2}")))
        assertTrue(zones.estimatedSvt2Pace.matches(Regex("\\d{1,2}:\\d{2}")))
    }

    @Test
    fun `blocos reconhecem alvo por tempo ou distancia em km`() {
        val byTime = WorkoutSegment(name = "Limiar", instruction = "Controlado", durationMin = 6)
        val byDistance = WorkoutSegment(name = "Rodagem", instruction = "Leve", distanceKm = 2.0)
        assertEquals("TIME", byTime.targetMode)
        assertEquals("DISTANCE", byDistance.targetMode)
    }
}
