package com.airunningcoach.app

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PerformanceMonitoringEngineTest {
    @Test
    fun `monitora tendencia de melhora sem recalibrar pace automaticamente`() {
        val start = LocalDate.of(2026, 11, 1)
        val rows = listOf("7:00", "6:58", "6:48", "6:45").mapIndexed { index, pace ->
            PaceObservation(start.plusDays((index * 4).toLong()).toString(), 5.0, pace, "Aeróbio", "Leve", "Bem", false)
        }
        val result = PerformanceMonitoringEngine.evaluate(rows, start.plusDays(15))
        assertEquals("FASTER", result.status)
        assertTrue(result.comparableSessions >= 4)
        assertTrue(result.explanation.contains("novo Cooper"))
    }

    @Test
    fun `exclui treinos com dor ou fadiga e nao usa treino de qualidade para comparar`() {
        val start = LocalDate.of(2026, 11, 1)
        val rows = listOf(
            PaceObservation(start.toString(), 5.0, "7:00", "Aeróbio", "Leve", "Bem", false),
            PaceObservation(start.plusDays(3).toString(), 5.0, "6:58", "Aeróbio", "Leve", "Bem", false),
            PaceObservation(start.plusDays(6).toString(), 5.0, "6:50", "Aeróbio", "Bem cansado", "Muito cansado", true),
            PaceObservation(start.plusDays(9).toString(), 5.0, "5:00", "Qualidade", "Pesado", "Cansado", false)
        )
        val result = PerformanceMonitoringEngine.evaluate(rows, start.plusDays(12))
        assertEquals("INSUFFICIENT", result.status)
        assertEquals(2, result.comparableSessions)
    }

    @Test
    fun `nao utiliza dados fora da janela de vinte e oito dias`() {
        val start = LocalDate.of(2026, 10, 1)
        val rows = (0..3).map { index ->
            PaceObservation(start.plusDays((index * 3).toLong()).toString(), 5.0, "7:00", "Aeróbio", "Leve", "Bem", false)
        }
        val result = PerformanceMonitoringEngine.evaluate(rows, LocalDate.of(2026, 11, 6))
        assertEquals("INSUFFICIENT", result.status)
    }
}
