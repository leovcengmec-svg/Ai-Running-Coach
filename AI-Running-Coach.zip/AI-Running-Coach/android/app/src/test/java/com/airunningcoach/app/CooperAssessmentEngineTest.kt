package com.airunningcoach.app

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CooperAssessmentEngineTest {
    @Test
    fun `salva distancia do cooper em km e pace em mm ss`() {
        val record = CooperAssessmentEngine.createRecord(2.4, LocalDate.of(2026, 11, 6))
        assertNotNull(record)
        assertEquals(2.4, record!!.distanceKm, 0.001)
        assertEquals("5:00", record.averagePace)
        assertTrue(record.estimatedVo2Max > 0.0)
        assertEquals(PaceCalculator.ZONE_MODEL_VERSION, record.zoneModelVersion)
        assertEquals(setOf("Z1", "Z2", "Z3", "Z4", "Z5"), record.zoneRanges.keys)
        assertTrue(record.zoneRanges.values.all { it.endsWith("min/km") })
    }

    @Test
    fun `revisao fica disponivel depois de quatro semanas`() {
        val date = LocalDate.of(2026, 11, 6)
        val record = CooperAssessmentEngine.createRecord(2.4, date)!!
        assertFalse(CooperAssessmentEngine.reviewStatus(listOf(record), date.plusDays(27)).isDue)
        assertTrue(CooperAssessmentEngine.reviewStatus(listOf(record), date.plusDays(28)).isDue)
    }

    @Test
    fun `data de cooper no onboarding deve estar no passado e ter ate oito semanas`() {
        val today = LocalDate.of(2026, 11, 6)
        assertEquals(LocalDate.of(2026, 10, 10), CooperAssessmentEngine.parseAssessmentDate("10/10/2026"))
        assertNull(CooperAssessmentEngine.parseAssessmentDate("31/02/2026"))
        assertTrue(CooperAssessmentEngine.isRecentAssessmentDate(today.minusDays(56), today))
        assertFalse(CooperAssessmentEngine.isRecentAssessmentDate(today.minusDays(57), today))
        assertFalse(CooperAssessmentEngine.isRecentAssessmentDate(today.plusDays(1), today))
    }

    @Test
    fun `melhora de distancia do cooper e calculada em ordem cronologica`() {
        val first = CooperAssessmentEngine.createRecord(2.3, LocalDate.of(2026, 10, 1))!!
        val second = CooperAssessmentEngine.createRecord(2.4, LocalDate.of(2026, 10, 29))!!
        assertEquals(100.0 * (2.4 - 2.3) / 2.3, CooperAssessmentEngine.improvementSincePrevious(listOf(second, first))!!, 0.001)
        assertNull(CooperAssessmentEngine.improvementSincePrevious(listOf(first)))
    }

    @Test
    fun `data da ultima avaliacao e escolhida mesmo se historico vier fora de ordem`() {
        val old = CooperAssessmentEngine.createRecord(2.2, LocalDate.of(2026, 10, 1))!!
        val recent = CooperAssessmentEngine.createRecord(2.4, LocalDate.of(2026, 11, 1))!!
        val status = CooperAssessmentEngine.reviewStatus(listOf(recent, old), LocalDate.of(2026, 11, 20))
        assertEquals(LocalDate.of(2026, 11, 29), status.nextReviewDate)
    }
}
