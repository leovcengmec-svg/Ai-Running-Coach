package com.airunningcoach.app

import java.time.DayOfWeek
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TrainingScheduleEngineTest {
    private val monday = LocalDate.of(2026, 11, 9)

    @Test fun `aceita dois a seis dias e rejeita disponibilidade fora da faixa`() {
        assertEquals(null, TrainingScheduleEngine.validateAvailability(listOf(DayOfWeek.TUESDAY, DayOfWeek.SUNDAY), DayOfWeek.SUNDAY))
        assertTrue(TrainingScheduleEngine.validateAvailability(listOf(DayOfWeek.TUESDAY), DayOfWeek.TUESDAY) != null)
        assertTrue(TrainingScheduleEngine.validateAvailability(DayOfWeek.values().toList(), DayOfWeek.SUNDAY) != null)
    }

    @Test fun `normaliza dias em ordem semanal e remove duplicados`() {
        assertEquals(listOf(DayOfWeek.TUESDAY, DayOfWeek.THURSDAY, DayOfWeek.SUNDAY),
            TrainingScheduleEngine.normalizeDays(listOf(DayOfWeek.SUNDAY, DayOfWeek.TUESDAY, DayOfWeek.THURSDAY, DayOfWeek.TUESDAY), 3))
    }

    @Test fun `reagendamento permanece dentro da mesma semana`() {
        val source = TrainingScheduleEngine.SessionSlot("s1", monday.plusDays(1), "Aeróbio")
        val result = TrainingScheduleEngine.validateMove(source, monday.plusDays(2), listOf(source), emptySet(), monday)
        assertTrue(result.allowed)
        val outside = TrainingScheduleEngine.validateMove(source, monday.plusWeeks(1), listOf(source), emptySet(), monday)
        assertFalse(outside.allowed)
    }

    @Test fun `reagendamento bloqueia dia ocupado e dia de prova`() {
        val source = TrainingScheduleEngine.SessionSlot("s1", monday.plusDays(1), "Aeróbio")
        val occupied = TrainingScheduleEngine.SessionSlot("s2", monday.plusDays(2), "Longo")
        assertFalse(TrainingScheduleEngine.validateMove(source, occupied.date, listOf(source, occupied), emptySet(), monday).allowed)
        assertFalse(TrainingScheduleEngine.validateMove(source, monday.plusDays(3), listOf(source), setOf(monday.plusDays(3)), monday).allowed)
    }

    @Test fun `treino concluido nao pode ser movido`() {
        val source = TrainingScheduleEngine.SessionSlot("s1", monday.plusDays(1), "Aeróbio", done = true)
        assertFalse(TrainingScheduleEngine.validateMove(source, monday.plusDays(2), listOf(source), emptySet(), monday).allowed)
    }

    @Test fun `qualidade ou longao respeita intervalo minimo de recuperacao`() {
        val quality = TrainingScheduleEngine.SessionSlot("s1", monday.plusDays(1), "Qualidade")
        val longRun = TrainingScheduleEngine.SessionSlot("s2", monday.plusDays(5), "Longo")
        assertFalse(TrainingScheduleEngine.validateMove(quality, monday.plusDays(4), listOf(quality, longRun), emptySet(), monday).allowed)
        assertTrue(TrainingScheduleEngine.validateMove(quality, monday.plusDays(2), listOf(quality, longRun), emptySet(), monday).allowed)
    }

    @Test fun `motor respeita dias escolhidos e dia preferido do longao`() {
        val chosen = listOf(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.SATURDAY)
        val plan = RunningCoachEngine.generate(RunnerInput(
            goalKm = 10.0, level = "Intermediário", frequency = 3, availableDays = chosen,
            preferredLongRunDay = DayOfWeek.SATURDAY, weeklyVolumeKm = 24.0, longestRecentKm = 10.0,
            startDate = monday, planWeeks = 4
        ))
        val firstWeek = plan.workouts.filter { it.week == 1 }
        assertEquals(chosen.map { it.value }.sorted(), firstWeek.map { LocalDate.parse(it.scheduledDateIso).dayOfWeek.value }.sorted())
        assertTrue(firstWeek.any { it.type == "Longo" && LocalDate.parse(it.scheduledDateIso).dayOfWeek == DayOfWeek.SATURDAY })
    }
    @Test fun `iniciante usa no maximo tres dias e distribui descanso entre eles`() {
        val available = listOf(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY, DayOfWeek.FRIDAY, DayOfWeek.SATURDAY)
        val selected = TrainingScheduleEngine.prescribedRunningDays(available, 6, novice = true, preferredLongRunDay = DayOfWeek.SATURDAY)
        assertEquals(3, selected.size)
        assertTrue(DayOfWeek.SATURDAY in selected)
        assertTrue(selected.zipWithNext().all { (a, b) -> TrainingScheduleEngine.circularGapDays(a, b) >= 2 })
    }

    @Test fun `nao escolhe qualidade quando todos os dias estao colados ao longao`() {
        val selected = listOf(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY)
        assertEquals(null, TrainingScheduleEngine.qualityDayWithRecoveryGap(selected, DayOfWeek.TUESDAY))
    }

    @Test fun `preferencia do longao e preservada ou ajustada sem falhar com lista vazia`() {
        assertEquals(DayOfWeek.SATURDAY, TrainingScheduleEngine.resolvePreferredLongRunDay(DayOfWeek.SATURDAY, listOf(DayOfWeek.TUESDAY, DayOfWeek.SATURDAY)))
        assertEquals(DayOfWeek.SUNDAY, TrainingScheduleEngine.resolvePreferredLongRunDay(DayOfWeek.SATURDAY, listOf(DayOfWeek.TUESDAY, DayOfWeek.SUNDAY)))
        assertEquals(null, TrainingScheduleEngine.resolvePreferredLongRunDay(DayOfWeek.SATURDAY, emptyList()))
    }

}
