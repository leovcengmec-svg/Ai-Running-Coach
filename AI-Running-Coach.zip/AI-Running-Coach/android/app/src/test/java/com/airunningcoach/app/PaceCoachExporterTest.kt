package com.airunningcoach.app

import java.time.LocalDate
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PaceCoachExporterTest {
    private fun createWorkout(cooperKm: Double = 2.4, talkPaces: List<Int> = emptyList()): PrescribedWorkout = RunningCoachEngine.generate(
        RunnerInput(
            goalKm = 10.0, level = "Intermediário", frequency = 3,
            weeklyVolumeKm = 20.0, longestRecentKm = 10.0,
            cooperDistanceKm = cooperKm,
            cooperAssessmentDateIso = "2026-11-06",
            talkTestComfortPaceValues = talkPaces,
            startDate = LocalDate.of(2026, 11, 9)
        )
    ).workouts.first()

    @Test
    fun `contrato exporta distancias em km e pace em mm ss min km`() {
        val workout = createWorkout()
        val raw = PaceCoachExporter.workoutToJson(workout, "10 km", 10.0)
        val root = JSONObject(raw)
        assertEquals("6.0", root.getString("contractVersion"))
        assertEquals("km", root.getString("distanceUnit"))
        assertEquals("min/km", root.getString("paceUnit"))
        assertEquals("mm:ss", root.getString("paceFormat"))
        assertEquals(PaceCalculator.CALIBRATION_METHOD, root.getString("paceMethod"))
        assertEquals(PaceCalculator.ZONE_MODEL_VERSION, root.getString("paceZoneModelVersion"))
        assertFalse(root.has("distanceMeters"))
        assertFalse(root.has("paceSecondsPerKm"))

        val reference = root.getJSONObject("paceReference")
        assertEquals("COOPER_12_MIN", reference.getString("type"))
        assertEquals(2.4, reference.getDouble("distanceKm"), 0.001)
        assertEquals(12, reference.getInt("durationMinutes"))
        assertEquals("12 min", reference.getString("durationLabel"))
        assertEquals("5:00", reference.getString("averagePace"))
        assertEquals("4:23", reference.getString("estimatedMasPace"))
        assertEquals("5:01", reference.getString("estimatedSecondThresholdPace"))
        assertEquals("2026-11-06", reference.getString("assessmentDate"))
        assertEquals("COOPER_OPERATIONAL_ZONES_WITH_ESTIMATED_Z5_REFERENCE", reference.getString("zoneFramework"))
        assertEquals("AUGMENTED_COOPER_2022_SUPPORTING_ESTIMATES_ONLY", reference.getString("cooperRegression"))
        assertEquals("Z1_Z4_COOPER_AVERAGE_SPEED_NOT_PERCENT_VO2MAX;Z5_ESTIMATED_MAS_OR_CONSERVATIVE_COOPER_REFERENCE", reference.getString("zonePercentageBasis"))

        val zones = root.getJSONArray("paceZones")
        assertEquals(5, zones.length())
        val exportedZ5 = (0 until zones.length()).map { zones.getJSONObject(it) }.first { it.getString("id") == "Z5" }
        assertEquals("Alta intensidade estimada", exportedZ5.getString("name"))
        assertTrue(exportedZ5.getString("intensityBand").contains("VAM estimada"))
        assertEquals("COOPER_REGRESSION_ESTIMATED_MAS_REFERENCE_NOT_LAB_MEASURED", exportedZ5.getString("percentageBasis"))
        for (i in 0 until zones.length()) {
            val zone = zones.getJSONObject(i)
            assertTrue(zone.getString("id") in setOf("Z1", "Z2", "Z3", "Z4", "Z5"))
            assertTrue(zone.getString("range").matches(Regex("\\d{1,2}:\\d{2}–\\d{1,2}:\\d{2} min/km")))
            assertEquals("mm:ss", zone.getString("format"))
        }

        val segments = root.getJSONArray("segments")
        assertTrue(segments.length() > 0)
        val firstWithPace = (0 until segments.length()).map { segments.getJSONObject(it) }
            .first { it.has("paceTarget") }
        val paceTarget = firstWithPace.getJSONObject("paceTarget")
        assertTrue(paceTarget.getString("faster").matches(Regex("\\d{1,2}:\\d{2}")))
        assertTrue(paceTarget.getString("slower").matches(Regex("\\d{1,2}:\\d{2}")))
        assertEquals("min/km", paceTarget.getString("unit"))

        val lower = raw.lowercase()
        listOf("secondsperkm", "secperkm", "distanceMeters", "distancemeters", "targetsecperkm", "meters", "metres", "m/km", "km/h").forEach {
            assertFalse("Campo proibido no contrato: $it", lower.contains(it.lowercase()))
        }
        assertTrue(raw.contains("\"distanceKm\""))
        assertTrue(raw.contains("\"paceTarget\""))
        assertFalse(raw.contains("LEGACY_RACE_RESULT"))
    }


    @Test
    fun `contrato exporta personalizacao da z2 pelo teste da fala`() {
        val workout = createWorkout(2.10, listOf(440, 445))
        val root = JSONObject(PaceCoachExporter.workoutToJson(workout, "10 km", 10.0))
        val calibration = root.getJSONObject("z2Calibration")
        assertEquals("TALK_TEST_CONFIRMED", calibration.getString("status"))
        assertEquals(2, calibration.getInt("evidenceCount"))
        assertEquals("7:23", calibration.getString("comfortableSpeechReferencePace"))
        val zones = root.getJSONArray("paceZones")
        val z2 = (0 until zones.length()).map { zones.getJSONObject(it) }.first { it.getString("id") == "Z2" }
        assertEquals("7:33–8:10 min/km", z2.getString("range"))
        assertEquals("COOPER_BASELINE_REFINED_BY_TALK_TEST", z2.getString("percentageBasis"))
        assertTrue(z2.getString("intensityBand").contains("teste da fala"))
        assertEquals("COOPER_OPERATIONAL_ZONES_WITH_TALK_TEST_Z2_REFINEMENT_AND_ESTIMATED_Z5_REFERENCE", root.getJSONObject("paceReference").getString("zoneFramework"))
    }

    @Test
    fun `treino antigo exporta snapshot original mesmo apos novo cooper`() {
        val oldWorkout = createWorkout(2.4)
        val newerZones = PaceCalculator.createCalibrationSnapshot(2.7, "2026-12-04")!!
        assertTrue(oldWorkout.paceCalibrationSnapshot!!.zoneRanges != newerZones.zoneRanges)

        val root = JSONObject(PaceCoachExporter.workoutToJson(oldWorkout, "10 km", 10.0))
        val reference = root.getJSONObject("paceReference")
        assertEquals(2.4, reference.getDouble("distanceKm"), 0.001)
        assertEquals("2026-11-06", reference.getString("assessmentDate"))
    }

    @Test
    fun `zonas antigas nao sao exportadas como calibracao atual`() {
        val generated = createWorkout()
        val legacySnapshot = generated.paceCalibrationSnapshot!!.copy(modelVersion = "AIRC_ZONES_1")
        val legacyWorkout = generated.copy(paceCalibrationSnapshot = legacySnapshot)
        val root = JSONObject(PaceCoachExporter.workoutToJson(legacyWorkout, "10 km", 10.0))
        assertEquals("LEGACY_CALIBRATION_REVIEW", root.getString("paceTargetStatus"))
        assertEquals("AIRC_ZONES_1", root.getString("paceZoneModelVersion"))
        assertFalse(root.has("paceZones"))
        assertTrue(root.has("calibrationNote"))
    }

    @Test
    fun `exportacao sem cooper nao inventa cinco zonas`() {
        val workout = RunningCoachEngine.generate(
            RunnerInput(
                goalKm = 5.0, level = "Iniciante", frequency = 3,
                weeklyVolumeKm = 8.0, longestRecentKm = 4.0,
                startDate = LocalDate.of(2026, 11, 9)
            )
        ).workouts.first()
        val root = JSONObject(PaceCoachExporter.workoutToJson(workout, "5 km", 5.0))
        assertEquals("AWAITING_COOPER_TEST", root.getString("paceTargetStatus"))
        assertEquals("NOT_CALIBRATED", root.getString("paceZoneModelVersion"))
        assertFalse(root.has("paceZones"))
        assertFalse(root.has("paceReference"))
    }
}
