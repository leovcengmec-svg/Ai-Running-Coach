package com.airunningcoach.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PaceCoachExporterTest {
    private fun workout(segments: List<WorkoutSegment>): PrescribedWorkout = PrescribedWorkout(
        day = "Segunda-feira",
        date = "Segunda-feira, 09/11",
        scheduledDateIso = "2026-11-09",
        title = "Treino de teste",
        type = "Qualidade",
        objective = "Testar interoperabilidade",
        stimulus = "INTERVALS",
        sessionId = "W1-MONDAY-QUALITY",
        distanceKm = 8.0,
        durationMin = 48,
        intensity = "MODERATE",
        paceMode = "PACE_RANGE",
        rpeRange = "5-7",
        detail = "Teste",
        rationale = "Fixture de interoperabilidade",
        segments = segments
    )

    @Test
    fun `exporta wrapper UserWorkoutJson exatamente como o arquivo padrao`() {
        val sampleLike = workout(
            listOf(
                WorkoutSegment("Aquecimento", "Aqueça", durationMin = 8, intensity = "LOW"),
                WorkoutSegment("Intervalo principal", "Corra forte", durationMin = 8, targetPaceMinValue = 250, targetPaceMaxValue = 250, paceZone = "Z4"),
                WorkoutSegment("Recuperação", "Recupere", durationMin = 2, intensity = "LOW"),
                WorkoutSegment("Desaquecimento", "Reduza", durationMin = 5, intensity = "LOW")
            )
        )

        val root = JSONObject(PaceCoachExporter.workoutToJson(sampleLike, "5 km", 5.0))
        assertEquals(1, root.length())
        assertTrue(root.has("com.garmin.connect.workout.json.UserWorkoutJson"))
        val userWorkout = root.getJSONObject(PaceCoachExporter.USER_WORKOUT_JSON_KEY)
        assertTrue(userWorkout.getLong("workoutId") > 0L)
        assertEquals("Treino de teste", userWorkout.getString("workoutName"))
        assertTrue(userWorkout.getString("createdDate").endsWith(" GMT"))
        assertTrue(userWorkout.getString("updatedDate").endsWith(" GMT"))
        assertEquals(0, userWorkout.getInt("ownerId"))
        assertEquals("running", userWorkout.getString("sportTypeKey"))

        val steps = userWorkout.getJSONArray("workoutSteps")
        assertEquals(4, steps.length())
        val warmup = steps.getJSONObject(0)
        assertEquals(1, warmup.getInt("stepOrder"))
        assertEquals("warmup", warmup.getString("stepTypeKey"))
        assertEquals("time", warmup.getString("endConditionTypeKey"))
        assertEquals(480000.0, warmup.getDouble("endConditionValue"), 0.0)
        assertEquals(41, warmup.getInt("endConditionUnitPk"))

        val active = steps.getJSONObject(1)
        assertEquals("interval", active.getString("stepTypeKey"))
        assertEquals("active", active.getString("intensityTypeKey"))
        assertEquals("pace.zone", active.getString("targetTypeKey"))
        assertEquals(7, active.getInt("targetValueUnitPk"))
        assertEquals("centimetersPerMillisecond", active.getString("targetValueUnitKey"))
        assertEquals(0.4, active.getDouble("targetValueOne"), 0.000001)
        assertEquals(0.4, active.getDouble("targetValueTwo"), 0.000001)
        assertEquals("04:10", active.getString("targetOneDisplayValue"))
        assertEquals("04:10", active.getString("targetTwoDisplayValue"))

        val recovery = steps.getJSONObject(2)
        assertEquals("rest", recovery.getString("stepTypeKey"))
        assertEquals("rest", recovery.getString("intensityTypeKey"))
        assertEquals("no.target", recovery.getString("targetTypeKey"))
        assertEquals("dimensionless", recovery.getString("targetValueUnitKey"))

        assertEquals("cooldown", steps.getJSONObject(3).getString("stepTypeKey"))
    }

    @Test
    fun `distancia e exportada em metros e mantendo unidade nativa`() {
        val value = workout(
            listOf(WorkoutSegment("Rodagem aeróbia", "Ritmo fácil", distanceKm = 1.25, targetPaceMinValue = 420, targetPaceMaxValue = 450))
        )
        val exported = JSONObject(PaceCoachExporter.workoutToJson(value, "5 km", 5.0))
            .getJSONObject(PaceCoachExporter.USER_WORKOUT_JSON_KEY)
            .getJSONArray("workoutSteps").getJSONObject(0)

        assertEquals("distance", exported.getString("endConditionTypeKey"))
        assertEquals(1250.0, exported.getDouble("endConditionValue"), 0.0)
        assertEquals(1, exported.getInt("endConditionUnitPk"))
        assertEquals("meter", exported.getString("endConditionUnitKey"))
        assertEquals("Meters", exported.getString("endConditionDisplayUnit"))
        assertEquals("pace.zone", exported.getString("targetTypeKey"))
        assertTrue(exported.getDouble("targetValueOne") < exported.getDouble("targetValueTwo"))
        assertFalse(exported.has("distanceKm"))
    }

    @Test
    fun `repeticoes viram grupo Garmin e preservam a alternancia dos blocos`() {
        val value = workout(
            listOf(
                WorkoutSegment("Aquecimento", "Aqueça", durationMin = 5),
                WorkoutSegment("Corrida leve", "Corra", durationMin = 2, repeatCount = 3),
                WorkoutSegment("Caminhada de recuperação", "Caminhe", durationMin = 2, repeatCount = 3),
                WorkoutSegment("Desaquecimento", "Finalize", durationMin = 5)
            )
        )
        val steps = JSONObject(PaceCoachExporter.workoutToJson(value, "5 km", 5.0))
            .getJSONObject(PaceCoachExporter.USER_WORKOUT_JSON_KEY)
            .getJSONArray("workoutSteps")

        assertEquals(5, steps.length())
        val repeat = steps.getJSONObject(1)
        assertEquals("repeat", repeat.getString("stepTypeKey"))
        assertEquals("iterations", repeat.getString("endConditionTypeKey"))
        assertEquals(3.0, repeat.getDouble("endConditionValue"), 0.0)
        val groupId = repeat.getInt("groupId")
        val run = steps.getJSONObject(2)
        val walk = steps.getJSONObject(3)
        assertEquals(groupId, run.getInt("groupId"))
        assertEquals(groupId, run.getInt("parentGroupId"))
        assertEquals("interval", run.getString("stepTypeKey"))
        assertEquals(groupId, walk.getInt("groupId"))
        assertEquals("rest", walk.getString("stepTypeKey"))
        assertEquals(5, steps.getJSONObject(4).getInt("stepOrder"))
    }

    @Test
    fun `todas as etapas possuem ids unicos e ordem sequencial`() {
        val value = workout(
            listOf(
                WorkoutSegment("Aquecimento", "Aqueça", durationMin = 5),
                WorkoutSegment("Série", "Execute", durationMin = 3, repeatCount = 4),
                WorkoutSegment("Recuperação", "Recupere", durationMin = 2, repeatCount = 4),
                WorkoutSegment("Desaquecimento", "Finalize", distanceKm = 0.5)
            )
        )
        val steps = JSONObject(PaceCoachExporter.workoutToJson(value, "10 km", 10.0))
            .getJSONObject(PaceCoachExporter.USER_WORKOUT_JSON_KEY)
            .getJSONArray("workoutSteps")
        val ids = (0 until steps.length()).map { steps.getJSONObject(it).getLong("stepId") }
        val orders = (0 until steps.length()).map { steps.getJSONObject(it).getInt("stepOrder") }
        assertEquals(ids.size, ids.toSet().size)
        assertEquals((1..steps.length()).toList(), orders)
    }
}
