package com.airunningcoach.app

import java.time.LocalDate
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PaceCoachExporterTest {
    private fun createWorkout(cooperKm: Double = 2.4): PrescribedWorkout = RunningCoachEngine.generate(
        RunnerInput(
            goalKm = 10.0, level = "Intermediário", frequency = 3,
            weeklyVolumeKm = 20.0, longestRecentKm = 10.0,
            cooperDistanceKm = cooperKm,
            cooperAssessmentDateIso = "2026-11-06",
            startDate = LocalDate.of(2026, 11, 9)
        )
    ).workouts.first()

    @Test
    fun `contrato exporta distancias em km e pace em mm ss min km`() {
        val workout = createWorkout()
        val raw = PaceCoachExporter.workoutToJson(workout, "10 km", 10.0)
        val root = JSONObject(raw)
        assertEquals("5.0", root.getString("contractVersion"))
        assertEquals("km", root.getString("distanceUnit"))
        assertEquals("min/km", root.getString("paceUnit"))
        assertEquals("mm:ss", root.getString("paceFormat"))
        assertEquals(PaceCalculator.CALIBRATION_METHOD, root.getString("paceMethod"))
        assertEquals(PaceCalculator.ZONE_MODEL_VERSION, root.getString("paceZoneModelVersion"))
        assertFalse(root.has("distanceMeters"))
        assertFalse(root.has("paceSecondsPerKm"))

        val reference = root.getJSONObject("paceReference")
        assertEquals("COOPER_12_MIN", reference.getString("type"))
        assertEquals(2.4, reference.getDouble("distanceKm"), 0.001)
        assertEquals(12, reference.getInt("durationMinutes"))
        assertEquals("12 min", reference.getString("durationLabel"))
        assertEquals("5:00", reference.getString("averagePace"))
        assertEquals("4:23", reference.getString("estimatedMasPace"))
        assertEquals("5:01", reference.getString("estimatedSecondThresholdPace"))
        assertEquals("2026-11-06", reference.getString("assessmentDate"))
        assertEquals("CEREZUELA_ESPEJO_2018_FIVE_ZONE_AUTHOR_PROPOSAL", reference.getString("zoneFramework"))
        assertEquals("AUGMENTED_COOPER_2022", reference.getString("cooperRegression"))

        val zones = root.getJSONArray("paceZones")
        assertEquals(5, zones.length())
        for (i in 0 until zones.length()) {
            val zone = zones.getJSONObject(i)
            assertTrue(zone.getString("id") in setOf("Z1", "Z2", "Z3", "Z4", "Z5"))
            assertTrue(zone.getString("range").matches(Regex("\\d{1,2}:\\d{2}–\\d{1,2}:\\d{2} min/km")))
            assertEquals("mm:ss", zone.getString("format"))
        }

        val segments = root.getJSONArray("segments")
        assertTrue(segments.length() > 0)
        val firstWithPace = (0 until segments.length()).map { segments.getJSONObject(it) }
            .first { it.has("paceTarget") }
        val paceTarget = firstWithPace.getJSONObject("paceTarget")
        assertTrue(paceTarget.getString("faster").matches(Regex("\\d{1,2}:\\d{2}")))
        assertTrue(paceTarget.getString("slower").matches(Regex("\\d{1,2}:\\d{2}")))
        assertEquals("min/km", paceTarget.getString("unit"))

        val lower = raw.lowercase()
        listOf("secondsperkm", "secperkm", "distanceMeters", "distancemeters", "targetsecperkm", "meters", "metres", "m/km", "km/h").forEach {
            assertFalse("Campo proibido no contrato: $it", lower.contains(it.lowercase()))
        }
        assertTrue(raw.contains("\"distanceKm\""))
        assertTrue(raw.contains("\"paceTarget\""))
        assertFalse(raw.contains("LEGACY_RACE_RESULT"))
    }

    @Test
    fun `treino antigo exporta snapshot original mesmo apos novo cooper`() {
        val oldWorkout = createWorkout(2.4)
        val newerZones = PaceCalculator.createCalibrationSnapshot(2.7, "2026-12-04")!!
        assertTrue(oldWorkout.paceCalibrationSnapshot!!.zoneRanges != newerZones.zoneRanges)

        val root = JSONObject(PaceCoachExporter.workoutToJson(oldWorkout, "10 km", 10.0))
        val reference = root.getJSONObject("paceReference")
        assertEquals(2.4, reference.getDouble("distanceKm"), 0.001)
        assertEquals("2026-11-06", reference.getString("assessmentDate"))
    }

    @Test
    fun `zonas antigas nao sao exportadas como calibracao atual`() {
        val generated = createWorkout()
        val legacySnapshot = generated.paceCalibrationSnapshot!!.copy(modelVersion = "AIRC_ZONES_1")
        val legacyWorkout = generated.copy(paceCalibrationSnapshot = legacySnapshot)
        val root = JSONObject(PaceCoachExporter.workoutToJson(legacyWorkout, "10 km", 10.0))
        assertEquals("LEGACY_CALIBRATION_REVIEW", root.getString("paceTargetStatus"))
        assertEquals("AIRC_ZONES_1", root.getString("paceZoneModelVersion"))
        assertFalse(root.has("paceZones"))
        assertTrue(root.has("calibrationNote"))
    }

    @Test
    fun `exportacao sem cooper nao inventa cinco zonas`() {
        val workout = RunningCoachEngine.generate(
            RunnerInput(
                goalKm = 5.0, level = "Iniciante", frequency = 3,
                weeklyVolumeKm = 8.0, longestRecentKm = 4.0,
                startDate = LocalDate.of(2026, 11, 9)
            )
        ).workouts.first()
        val root = JSONObject(PaceCoachExporter.workoutToJson(workout, "5 km", 5.0))
        assertEquals("AWAITING_COOPER_TEST", root.getString("paceTargetStatus"))
        assertEquals("NOT_CALIBRATED", root.getString("paceZoneModelVersion"))
        assertFalse(root.has("paceZones"))
        assertFalse(root.has("paceReference"))
    }
}
