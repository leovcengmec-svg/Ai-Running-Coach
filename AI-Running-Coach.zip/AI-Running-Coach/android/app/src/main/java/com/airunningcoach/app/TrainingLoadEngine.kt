package com.airunningcoach.app

import java.time.LocalDate
import java.time.temporal.WeekFields
import kotlin.math.round

/** A completed run with measured distance and the date assigned to the workout itself. */
internal data class LoggedRunActivity(
    val date: LocalDate,
    val distanceKm: Double
)

internal data class TrainingLoadSnapshot(
    val reliable: Boolean,
    val averageWeeklyKmLast28Days: Double?,
    val longestRunLast30DaysKm: Double?,
    val recordedRunsLast28Days: Int,
    val activeWeeksLast28Days: Int,
    val totalKmLast28Days: Double
)

/**
 * Uses completed, measured activities rather than planned distances.
 * A four-week average is promoted to the planning baseline only after at least six
 * measured runs span three distinct ISO weeks. Otherwise the profile baseline remains
 * authoritative and recorded long runs are used only as an additional tolerance bound.
 */
internal object TrainingLoadEngine {
    fun summarize(activities: List<LoggedRunActivity>, today: LocalDate = LocalDate.now()): TrainingLoadSnapshot {
        val start28 = today.minusDays(27)
        val start30 = today.minusDays(29)
        val valid = activities.filter { it.distanceKm.isFinite() && it.distanceKm > 0.0 && it.distanceKm <= 200.0 }
        val last28 = valid.filter { !it.date.isBefore(start28) && !it.date.isAfter(today) }
        val last30 = valid.filter { !it.date.isBefore(start30) && !it.date.isAfter(today) }
        val activeWeeks = last28.map { activity ->
            val week = activity.date.get(WeekFields.ISO.weekOfWeekBasedYear())
            val year = activity.date.get(WeekFields.ISO.weekBasedYear())
            year * 100 + week
        }.distinct().size
        val total = last28.sumOf { it.distanceKm }
        val reliable = last28.size >= 6 && activeWeeks >= 3
        return TrainingLoadSnapshot(
            reliable = reliable,
            averageWeeklyKmLast28Days = if (reliable) round1(total / 4.0) else null,
            longestRunLast30DaysKm = last30.maxOfOrNull { it.distanceKm }?.let(::round1),
            recordedRunsLast28Days = last28.size,
            activeWeeksLast28Days = activeWeeks,
            totalKmLast28Days = round1(total)
        )
    }

    private fun round1(value: Double): Double = round(value * 10.0) / 10.0
}
