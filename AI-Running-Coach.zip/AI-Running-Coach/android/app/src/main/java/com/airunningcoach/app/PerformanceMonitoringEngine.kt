package com.airunningcoach.app

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.abs
import kotlin.math.roundToInt

internal data class PaceObservation(
    val dateIso: String,
    val distanceKm: Double,
    val paceMmSs: String,
    val sessionType: String,
    val effort: String,
    val feeling: String,
    val painPresent: Boolean
)

internal data class PerformanceTrend(
    val status: String,
    val headline: String,
    val explanation: String,
    val comparableSessions: Int,
    val changePercent: Double? = null
)

/**
 * Monitora tendências de pace em rodagens comparáveis. Nunca recalibra as zonas sozinho:
 * somente um novo Cooper válido atualiza oficialmente o pace-base.
 */
internal object PerformanceMonitoringEngine {
    private const val REVIEW_DAYS = 28L
    private const val MIN_COMPARABLE_SESSIONS = 4

    fun evaluate(observations: List<PaceObservation>, today: LocalDate = LocalDate.now()): PerformanceTrend {
        val comparable = observations.mapNotNull { item ->
            val date = runCatching { LocalDate.parse(item.dateIso) }.getOrNull() ?: return@mapNotNull null
            val pace = PaceRange.parsePace(item.paceMmSs) ?: return@mapNotNull null
            val easyType = item.sessionType in setOf("Aeróbio", "Recuperação", "Longo")
            val safeEffort = item.effort !in setOf("Pesado", "Muito pesado")
            val safeFeeling = item.feeling !in setOf("Cansado", "Muito cansado")
            if (ChronoUnit.DAYS.between(date, today) !in 0..REVIEW_DAYS || item.distanceKm < 2.0 ||
                !easyType || !safeEffort || !safeFeeling || item.painPresent) return@mapNotNull null
            Triple(date, item.sessionType, pace)
        }.sortedBy { it.first }

        if (comparable.size < MIN_COMPARABLE_SESSIONS) {
            return PerformanceTrend(
                status = "INSUFFICIENT",
                headline = "Ainda não há sessões comparáveis suficientes",
                explanation = "Registre pelo menos quatro rodagens aeróbias, regenerativas ou longões com distância e tempo reais. Esses dados monitoram tendências, mas não alteram as zonas sem um novo Cooper.",
                comparableSessions = comparable.size
            )
        }

        val mostCommonType = comparable.groupingBy { it.second }.eachCount().maxByOrNull { it.value }?.key
        val sameType = comparable.filter { it.second == mostCommonType }.map { it.third }
        if (sameType.size < MIN_COMPARABLE_SESSIONS) {
            return PerformanceTrend(
                "INSUFFICIENT", "Ainda não há sessões comparáveis suficientes",
                "Compare o mesmo tipo de corrida em condições semelhantes. Não misture longões com rodagens curtas para inferir evolução.",
                sameType.size
            )
        }

        val split = (sameType.size / 2).coerceAtLeast(2)
        val early = median(sameType.take(split))
        val recent = median(sameType.takeLast(split))
        val change = ((early - recent) / early) * 100.0
        val rounded = (change * 10.0).roundToInt() / 10.0
        return when {
            change >= 2.0 -> PerformanceTrend(
                "FASTER", "Sinal de melhora nas rodagens comparáveis",
                "O pace recente está cerca de ${String.format(java.util.Locale.US, "%.1f", rounded)}% mais rápido. Isso é um sinal para revisar a evolução, não uma autorização para acelerar as zonas automaticamente. Valide com um novo Cooper quando estiver recuperado.",
                sameType.size, rounded
            )
            change <= -2.0 -> PerformanceTrend(
                "SLOWER", "Ritmos recentes ficaram mais lentos",
                "O pace recente está cerca de ${String.format(java.util.Locale.US, "%.1f", abs(rounded))}% mais lento. Verifique fadiga, clima, terreno, sono e saúde. Não altere as zonas a partir de um período isolado.",
                sameType.size, rounded
            )
            else -> PerformanceTrend(
                "STABLE", "Pace estável nas rodagens comparáveis",
                "A variação recente está dentro da faixa de estabilidade adotada pelo aplicativo. Mantenha as zonas até a próxima avaliação válida.",
                sameType.size, rounded
            )
        }
    }

    private fun median(values: List<Int>): Double {
        val sorted = values.sorted()
        val middle = sorted.size / 2
        return if (sorted.size % 2 == 0) (sorted[middle - 1] + sorted[middle]) / 2.0 else sorted[middle].toDouble()
    }
}
