package com.airunningcoach.app

import kotlin.math.ceil

/** Estimates total session time from the actual dose of every prescribed segment.
 * TIME segments contribute their explicit duration; DISTANCE segments are converted
 * using their pace range. Distance metadata attached to a TIME segment is never
 * counted twice. When pace is unavailable, the estimate uses the weighted pace of
 * other calibrated distance segments, or a clearly approximate 7:00 min/km baseline.
 */
internal object WorkoutDurationEstimator {
    private const val UNCALIBRATED_FALLBACK_SECONDS_PER_KM = 7.0 * 60.0

    fun estimateMinutes(
        segments: List<WorkoutSegment>,
        fallbackDistanceKm: Double = 0.0,
        fallbackDurationMin: Int = 0
    ): Int {
        if (segments.isEmpty()) return fallbackDurationMin.coerceAtLeast(0)

        val calibratedDistanceSegments = segments.filter { segment ->
            segment.targetMode == "DISTANCE" &&
                (segment.distanceKm ?: 0.0) > 0.0 &&
                segment.targetPaceMinValue != null && segment.targetPaceMaxValue != null
        }
        val calibratedDistance = calibratedDistanceSegments.sumOf {
            (it.distanceKm ?: 0.0) * it.repeatCount
        }
        val inferredPace = if (calibratedDistance > 0.0) {
            calibratedDistanceSegments.sumOf { segment ->
                val midpoint = (segment.targetPaceMinValue!! + segment.targetPaceMaxValue!!) / 2.0
                midpoint * (segment.distanceKm ?: 0.0) * segment.repeatCount
            } / calibratedDistance
        } else UNCALIBRATED_FALLBACK_SECONDS_PER_KM

        val totalSeconds = segments.sumOf { segment ->
            val repeats = segment.repeatCount.coerceAtLeast(1)
            when (segment.targetMode) {
                "TIME" -> (segment.durationMin ?: 0).coerceAtLeast(0) * 60.0 * repeats
                else -> {
                    val distance = (segment.distanceKm ?: 0.0).coerceAtLeast(0.0) * repeats
                    val pace = if (segment.targetPaceMinValue != null && segment.targetPaceMaxValue != null) {
                        (segment.targetPaceMinValue + segment.targetPaceMaxValue) / 2.0
                    } else inferredPace
                    distance * pace
                }
            }
        }

        val resolvedSeconds = if (totalSeconds > 0.0) totalSeconds else {
            fallbackDistanceKm.coerceAtLeast(0.0) * inferredPace
        }
        return if (resolvedSeconds > 0.0) ceil(resolvedSeconds / 60.0).toInt().coerceAtLeast(1)
        else fallbackDurationMin.coerceAtLeast(0)
    }
}
