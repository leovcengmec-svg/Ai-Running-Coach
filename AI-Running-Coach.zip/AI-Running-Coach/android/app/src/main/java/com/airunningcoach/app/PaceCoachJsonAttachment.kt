package com.airunningcoach.app

import java.io.File
import java.io.IOException

/** Creates a real JSON file for Android ACTION_SEND attachments (never a text/plain payload). */
internal object PaceCoachJsonAttachment {
    const val MIME_TYPE = "application/json"

    fun create(cacheDirectory: File, sessionId: String, json: String): File {
        require(json.isNotBlank()) { "A prescrição JSON não pode estar vazia." }

        val exportDirectory = File(cacheDirectory, "exports")
        if (!exportDirectory.isDirectory && !exportDirectory.mkdirs()) {
            throw IOException("Não foi possível criar a pasta temporária de exportação JSON.")
        }

        // Keep the identifier in the file name, but never allow path separators or control chars.
        val safeSessionId = sessionId
            .replace(Regex("[^A-Za-z0-9._-]"), "_")
            .trim('.', '_', '-')
            .take(80)
            .ifBlank { "workout" }
        val destination = File(exportDirectory, "pace-coach-workout-$safeSessionId.json")
        destination.writeText(json, Charsets.UTF_8)
        return destination
    }
}
