package com.airunningcoach.app

import java.io.File
import java.io.IOException

/** Creates a real JSON file for Android ACTION_SEND attachments (never a text/plain payload). */
internal object PaceCoachJsonAttachment {
    const val MIME_TYPE = "application/json"

    fun create(cacheDirectory: File, exportName: String, json: String): File {
        require(json.isNotBlank()) { "A prescrição JSON não pode estar vazia." }

        val exportDirectory = File(cacheDirectory, "exports")
        if (!exportDirectory.isDirectory && !exportDirectory.mkdirs()) {
            throw IOException("Não foi possível criar a pasta temporária de exportação JSON.")
        }

        // Preserve the human-readable identifier, including accents and spaces, while
        // stripping path separators, reserved filename characters and control codes.
        val safeName = WorkoutExportNaming.safeFileBaseName(exportName)
        val destination = File(exportDirectory, "$safeName.json")
        destination.writeText(json, Charsets.UTF_8)
        return destination
    }
}
