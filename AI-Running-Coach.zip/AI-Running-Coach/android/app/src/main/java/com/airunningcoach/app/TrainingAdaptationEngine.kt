package com.airunningcoach.app

import java.util.Locale
import kotlin.math.roundToInt

/**
 * Análise local e independente de fabricante, inspirada no fluxo adaptativo do Laps.
 * Não depende de COROS, Google Calendar, rede ou serviços externos.
 */
internal object TrainingAdaptationEngine {
    data class RunResult(
        val distanceKm: Double?,
        val plannedDistanceKm: Double,
        val avgHeartRate: Int? = null,
        val thresholdHeartRate: Int? = null,
        val averagePaceMinKm: String? = null,
        val perceivedEffort: String = "Não informado",
        val feeling: String = "Não informado",
        val plannedWorkoutType: String = "Aeróbio",
        val painReported: Boolean = false
    )

    data class CoachingAnalysis(
        val headline: String,
        val summary: String,
        val insights: List<String>,
        val nextStep: String,
        val adherencePercent: Int?
    )

    data class MissedWorkoutOption(
        val label: String,
        val description: String,
        val action: String,
        val recommended: Boolean
    )

    data class MissedWorkoutResolution(
        val rationale: String,
        val options: List<MissedWorkoutOption>
    )

    fun analyzeRun(result: RunResult): CoachingAnalysis {
        val adherence = result.distanceKm?.takeIf { it > 0.0 }?.let { distance ->
            if (result.plannedDistanceKm > 0.0) ((distance / result.plannedDistanceKm) * 100.0).roundToInt().coerceIn(0, 200) else null
        }
        val rpe = result.perceivedEffort.lowercase(Locale.ROOT)
        val feeling = result.feeling.lowercase(Locale.ROOT)
        val highEffort = rpe == "pesado" || rpe == "muito pesado" || feeling == "cansado" || feeling == "muito cansado"
        val threshold = result.thresholdHeartRate
        val hrHigh = threshold != null && result.avgHeartRate != null && result.avgHeartRate >= threshold
        val type = result.plannedWorkoutType.lowercase(Locale.ROOT)

        return when {
            result.painReported -> CoachingAnalysis(
                headline = "Dor reportada — revisão necessária",
                summary = "O relato de dor impede uma progressão automática. O plano deve ser revisto antes de retomar estímulos de corrida.",
                insights = listOf("A prescrição não consegue diagnosticar a causa da dor.", "Não tente compensar o treino nem aumentar a carga enquanto houver dor.", "Procure orientação profissional quando a dor persistir, piorar ou limitar atividades."),
                nextStep = "Não gere uma progressão normal com este sinal ativo; reavalie a condição antes de voltar a correr.",
                adherencePercent = adherence
            )
            highEffort || hrHigh -> CoachingAnalysis(
                headline = "Carga percebida acima do esperado",
                summary = "O treino foi concluído, mas os sinais informados sugerem esforço elevado. Não aumente a carga automaticamente com base apenas na distância realizada.",
                insights = buildList {
                    add(if (adherence != null) "Aderência de distância: $adherence% da distância planejada." else "Distância realizada não informada; aderência não calculada.")
                    if (result.avgHeartRate != null && threshold != null) add("Frequência cardíaca média: ${result.avgHeartRate} bpm; limiar informado: $threshold bpm.")
                    add("Esforço percebido: ${result.perceivedEffort}; sensação: ${result.feeling}.")
                },
                nextStep = "Priorize recuperação e reavalie a prontidão antes do próximo estímulo de qualidade.",
                adherencePercent = adherence
            )
            type.contains("qualidade") || type.contains("limiar") || type.contains("interval") -> CoachingAnalysis(
                headline = "Estímulo de qualidade registrado",
                summary = "O treino foi registrado como sessão de qualidade. Compare o esforço percebido e a execução antes de progredir a intensidade.",
                insights = listOf(
                    if (adherence != null) "Aderência de distância: $adherence% da distância planejada." else "Distância realizada não informada; aderência não calculada.",
                    "O ritmo não é usado para ajustar automaticamente sem uma referência individual validada.",
                    "Considere o feedback do atleta junto ao histórico de carga da semana."
                ),
                nextStep = "Mantenha a próxima sessão leve e evite sessões intensas em dias consecutivos.",
                adherencePercent = adherence
            )
            else -> CoachingAnalysis(
                headline = "Treino aeróbio registrado",
                summary = "A sessão foi registrada como trabalho aeróbio. A progressão depende da consistência semanal e da recuperação, não de um único treino.",
                insights = listOf(
                    if (adherence != null) "Aderência de distância: $adherence% da distância planejada." else "Distância realizada não informada; aderência não calculada.",
                    "Use conversa confortável como referência nos treinos leves.",
                    "A análise de ritmo e zonas exige dados individuais confiáveis."
                ),
                nextStep = "Mantenha a intensidade leve nas próximas sessões previstas.",
                adherencePercent = adherence
            )
        }
    }

    fun reasonMissedWorkout(
        missedTitle: String,
        missedDistanceKm: Double,
        nextTitle: String,
        nextDistanceKm: Double,
        hoursUntilNext: Int
    ): MissedWorkoutResolution {
        val nextIsLong = nextDistanceKm >= 14.0 || nextTitle.contains("long", ignoreCase = true) || nextTitle.contains("longão", ignoreCase = true)
        val missedIsQuality = listOf("threshold", "limiar", "interval", "fartlek", "tempo").any { missedTitle.contains(it, true) }
        return when {
            nextIsLong && hoursUntilNext <= 48 -> MissedWorkoutResolution(
                rationale = "Não compense os ${missedDistanceKm.toInt()} km perdidos antes do longão. Empilhar sessões pode elevar a carga em pouco tempo e comprometer a recuperação.",
                options = listOf(
                    MissedWorkoutOption("Pular e proteger o longão", "Preserve a sessão-chave já programada.", "DROP", true),
                    MissedWorkoutOption("Substituir por descanso", "Retome o calendário somente quando estiver recuperado.", "REST", false)
                )
            )
            missedIsQuality -> MissedWorkoutResolution(
                rationale = "Uma sessão de qualidade perdida não deve ser automaticamente transferida para o dia seguinte. Evite dias intensos consecutivos.",
                options = listOf(
                    MissedWorkoutOption("Pular a sessão", "Mantenha a recuperação e continue o plano.", "DROP", true),
                    MissedWorkoutOption("Reavaliar a semana", "O treinador pode substituir uma sessão futura, sem somar os dois estímulos.", "REPLAN", false)
                )
            )
            else -> MissedWorkoutResolution(
                rationale = "O volume aeróbio perdido pode ser absorvido pelo plano. Não tente recuperar quilômetros acumulando sessões.",
                options = listOf(
                    MissedWorkoutOption("Pular e seguir o plano", "Não compense quilômetros perdidos.", "DROP", true),
                    MissedWorkoutOption("Replanejar a semana", "Ajuste somente se houver espaço e recuperação adequados.", "REPLAN", false)
                )
            )
        }
    }
}
