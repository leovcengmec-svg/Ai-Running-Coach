package com.airunningcoach.app

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.util.Locale

private val Navy = Color(0xFF061B2B)
private val Navy2 = Color(0xFF0B2639)
private val CardBlue = Color(0xFF12364D)
private val Blue = Color(0xFF2CA7FF)
private val Blue2 = Color(0xFF63C5FF)
private val TextWhite = Color(0xFFF4F8FB)
private val TextMuted = Color(0xFF9EB2C2)
private val Green = Color(0xFF35D5A0)
private val Yellow = Color(0xFFFFC857)

private enum class Screen { DASHBOARD, CALENDAR, WORKOUT, STRUCTURE, PLAN, EVOLUTION, FEEDBACK, HISTORY, PROFILE, EXPORT }

private data class Workout(
    val date: String,
    val scheduledDateIso: String = "",
    val title: String,
    val detail: String,
    val type: String,
    val objective: String,
    val stimulus: String,
    val distanceKm: Double,
    val done: Boolean = false,
    val sessionId: String = "",
    val durationMin: Int = 0,
    val intensity: String = "LOW",
    val paceMode: String = "RPE",
    val rpeRange: String = "3-4",
    val rationale: String = "",
    val week: Int = 1,
    val phase: String = "BASE",
    val segments: List<WorkoutSegment> = emptyList()
)

private data class FeedbackRecord(
    val sessionId: String,
    val effort: String,
    val feeling: String,
    val notes: String,
    val painPresent: Boolean = false,
    val actualDistanceKm: Double? = null,
    val savedAt: Long = System.currentTimeMillis()
)

private class CoachState(private val context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("ai_running_coach", Context.MODE_PRIVATE)

    var name by mutableStateOf("Leonardo")
    var goal by mutableStateOf("")
    var customGoalKm by mutableStateOf("")
    var level by mutableStateOf("")
    var frequency by mutableStateOf(0)
    var targetDate by mutableStateOf("Sem data definida")
    var volume by mutableStateOf("")
    var longestRecent by mutableStateOf("")
    var onboardingStep by mutableStateOf(-1)
    var selectedScreen by mutableStateOf(Screen.DASHBOARD)
    var selectedWorkoutIndex by mutableStateOf(0)
    var feedbackSaved by mutableStateOf(false)
    var workouts by mutableStateOf(listOf<Workout>())
    var planWeeks by mutableStateOf(4)
    var motorState by mutableStateOf<MotorState?>(null)
    var motorDecision by mutableStateOf<MotorDecision?>(null)
    var motorExplanation by mutableStateOf("")
    var motorError by mutableStateOf("")
    var needsEngineRefresh by mutableStateOf(false)
    var feedbackRecords by mutableStateOf(listOf<FeedbackRecord>())
    var latestFeedbackHeadline by mutableStateOf("")
    var latestFeedbackAdvice by mutableStateOf("")

    init { load() }

    fun createPlan(): Boolean {
        motorError = ""
        if (goal.isBlank() || level.isBlank() || frequency !in 2..6 || volume.isBlank() || longestRecent.isBlank()) {
            motorError = "Complete todas as escolhas antes de criar o plano."
            persist()
            return false
        }

        val goalKm = when {
            goal.startsWith("5") -> 5.0
            goal.startsWith("10") -> 10.0
            goal.startsWith("Meia") -> 21.1
            goal.startsWith("Maratona") -> 42.2
            goal.startsWith("Saúde") -> 5.0
            goal == "Outro objetivo" -> customGoalKm.trim().replace(",", ".").toDoubleOrNull()
                ?.takeIf { it in 1.0..100.0 }
            else -> null
        }
        if (goalKm == null) {
            motorError = "Informe uma distância válida entre 1 e 100 km para o objetivo personalizado."
            persist()
            return false
        }
        // "Mais de 10 km" representa um limite inferior conhecido, não um valor exato.
        val recentKm = if (longestRecent.startsWith("Mais", ignoreCase = true)) 10.0
            else longestRecent.substringBefore(" ").replace(",", ".").toDoubleOrNull()
        // Em faixas, usar o limite inferior como ponto de partida conservador.
        val weeklyMin = when {
            volume.startsWith("Até") -> 8.0
            volume.startsWith("10") -> 10.0
            volume.startsWith("30") -> 30.0
            volume.startsWith("Acima") -> 50.0
            else -> 8.0
        }
        if (recentKm == null) {
            motorError = "Não foi possível interpretar o maior treino recente."
            persist()
            return false
        }

        return try {
            val input = RunnerInput(
                goalKm = goalKm,
                level = level,
                frequency = frequency,
                weeklyVolumeMinKm = weeklyMin,
                longestRecentKm = recentKm,
                painPresent = feedbackRecords.takeLast(3).any { it.painPresent },
                recoveryScore = deriveRecoveryScore(),
                fatigueScore = deriveFatigueScore(),
                planWeeks = 4,
                startDate = RunningCoachEngine.nextMonday(LocalDate.now())
            )
            val plan = RunningCoachEngine.generate(input)
            motorState = plan.state
            motorDecision = plan.decision
            motorExplanation = plan.explanation
            if (plan.decision.safety == "RED") {
                // Preserve the previous cycle so the athlete can review/update the pain feedback
                // after recovery; a blocked generation must not erase the only way to do that.
                motorError = "Nova prescrição bloqueada por relato de dor. O plano anterior foi preservado; atualize o feedback somente quando estiver sem dor."
                onboardingStep = 7
                selectedScreen = Screen.DASHBOARD
                persist()
                return false
            }
            if (plan.workouts.isEmpty()) {
                motorError = "O motor terminou sem gerar sessões."
                persist()
                return false
            }
            workouts = plan.workouts.map { p ->
                Workout(
                    date = p.date, scheduledDateIso = p.scheduledDateIso, title = p.title, detail = p.detail, type = p.type,
                    objective = p.objective, stimulus = p.stimulus, distanceKm = p.distanceKm,
                    sessionId = p.sessionId, durationMin = p.durationMin, intensity = p.intensity,
                    paceMode = p.paceMode, rpeRange = p.rpeRange, rationale = p.rationale,
                    week = p.week, phase = p.phase, segments = p.segments
                )
            }
            motorError = ""
            planWeeks = plan.weeklySummaries.size.coerceAtLeast(4)
            needsEngineRefresh = false
            prefs.edit().putInt("engineVersion", 18).apply()
            selectedWorkoutIndex = 0
            selectedScreen = Screen.DASHBOARD
            onboardingStep = 7
            persist()
            true
        } catch (e: Exception) {
            motorError = "Erro ao executar o motor: ${e.message ?: "erro desconhecido"}"
            persist()
            false
        }
    }

    fun selectedWorkout(): Workout? = workouts.getOrNull(selectedWorkoutIndex)

    fun completedWorkouts(): List<Workout> = workouts.filter { it.done }

    fun saveFeedback(effort: String, feeling: String, notes: String, painPresent: Boolean, actualDistanceText: String) {
        val current = selectedWorkout() ?: return
        val actualDistanceKm = actualDistanceText.trim().replace(",", ".").toDoubleOrNull()?.takeIf { it > 0.0 && it <= 200.0 }
        workouts = workouts.mapIndexed { index, workout ->
            if (index == selectedWorkoutIndex) workout.copy(done = true) else workout
        }
        feedbackRecords = feedbackRecords.filterNot { it.sessionId == current.sessionId } + FeedbackRecord(
            sessionId = current.sessionId, effort = effort, feeling = feeling, notes = notes, painPresent = painPresent, actualDistanceKm = actualDistanceKm
        )
        val analysis = TrainingAdaptationEngine.analyzeRun(
            TrainingAdaptationEngine.RunResult(
                distanceKm = actualDistanceKm,
                plannedDistanceKm = current.distanceKm,
                perceivedEffort = effort,
                feeling = feeling,
                plannedWorkoutType = current.type,
                painReported = painPresent
            )
        )
        latestFeedbackHeadline = analysis.headline
        latestFeedbackAdvice = analysis.nextStep
        feedbackSaved = true
        persist()
    }

    private fun deriveRecoveryScore(): Double? {
        val recent = feedbackRecords.takeLast(3)
        if (recent.isEmpty()) return null
        val tired = recent.count { it.feeling == "Cansado" || it.feeling == "Muito cansado" }
        val heavy = recent.count { it.effort == "Pesado" || it.effort == "Muito pesado" }
        return when {
            recent.any { it.painPresent } -> 10.0
            tired >= 2 || heavy >= 2 -> 35.0
            tired + heavy >= 1 -> 60.0
            else -> 80.0
        }
    }

    private fun deriveFatigueScore(): Double? {
        val recent = feedbackRecords.takeLast(3)
        if (recent.isEmpty()) return null
        val tired = recent.count { it.feeling == "Cansado" || it.feeling == "Muito cansado" }
        val heavy = recent.count { it.effort == "Pesado" || it.effort == "Muito pesado" }
        return when {
            recent.any { it.painPresent } -> 95.0
            tired >= 2 || heavy >= 2 -> 80.0
            tired + heavy >= 1 -> 65.0
            else -> 30.0
        }
    }

    fun selectWorkout(workout: Workout) {
        val index = workouts.indexOf(workout)
        if (index >= 0) selectedWorkoutIndex = index
        selectedScreen = Screen.WORKOUT
        persist()
    }

    fun persist() {
        val e = prefs.edit()
            .putString("name", name)
            .putString("goal", goal)
            .putString("customGoalKm", customGoalKm)
            .putString("level", level)
            .putInt("frequency", frequency)
            .putString("targetDate", targetDate)
            .putString("volume", volume)
            .putString("longestRecent", longestRecent)
            .putInt("onboardingStep", onboardingStep)
            .putInt("selectedScreen", selectedScreen.ordinal)
            .putInt("selectedWorkoutIndex", selectedWorkoutIndex)
            .putInt("planWeeks", planWeeks)
            .putString("latestFeedbackHeadline", latestFeedbackHeadline)
            .putString("latestFeedbackAdvice", latestFeedbackAdvice)
            .putString("motorExplanation", motorExplanation)
            .putString("motorError", motorError)

        motorState?.let { ms ->
            e.putString("motorState", JSONObject().apply {
                put("fitnessConfidence", ms.fitnessConfidence)
                put("paceConfidence", ms.paceConfidence)
                put("recentVolumeKm", ms.recentVolumeKm)
                put("recentLongRunKm", ms.recentLongRunKm)
                put("recoveryStatus", ms.recoveryStatus)
                put("safetyStatus", ms.safetyStatus)
                put("phase", ms.phase)
                put("flags", JSONArray(ms.flags))
            }.toString())
        }
        motorDecision?.let { md ->
            e.putString("motorDecision", JSONObject().apply {
                put("action", md.action)
                put("necessity", md.necessity)
                put("stimulus", md.stimulus)
                put("rationale", md.rationale)
                put("confidence", md.confidence)
                put("safety", md.safety)
            }.toString())
        }
        val arr = JSONArray()
        workouts.forEach { w ->
            arr.put(JSONObject().apply {
                put("date", w.date); put("scheduledDateIso", w.scheduledDateIso); put("title", w.title); put("detail", w.detail)
                put("type", w.type); put("objective", w.objective); put("stimulus", w.stimulus)
                put("distanceKm", w.distanceKm); put("done", w.done); put("sessionId", w.sessionId)
                put("durationMin", w.durationMin); put("intensity", w.intensity); put("paceMode", w.paceMode)
                put("rpeRange", w.rpeRange); put("rationale", w.rationale); put("week", w.week)
                put("phase", w.phase)
                put("segments", JSONArray().apply {
                    w.segments.forEach { segment -> put(JSONObject().apply {
                        put("name", segment.name); put("instruction", segment.instruction)
                        if (segment.durationMin != null) put("durationMin", segment.durationMin)
                        if (segment.distanceKm != null) put("distanceKm", segment.distanceKm)
                        put("intensity", segment.intensity); put("rpeRange", segment.rpeRange)
                        put("repeatCount", segment.repeatCount)
                    }) }
                })
            })
        }
        val feedbackArray = JSONArray()
        feedbackRecords.forEach { feedback -> feedbackArray.put(JSONObject().apply {
            put("sessionId", feedback.sessionId); put("effort", feedback.effort)
            put("feeling", feedback.feeling); put("notes", feedback.notes); put("painPresent", feedback.painPresent)
            feedback.actualDistanceKm?.let { put("actualDistanceKm", it) }; put("savedAt", feedback.savedAt)
        }) }
        e.putString("feedbackRecords", feedbackArray.toString())
        e.putString("workouts", arr.toString()).apply()
    }

    private fun load() {
        name = prefs.getString("name", "Leonardo") ?: "Leonardo"
        goal = prefs.getString("goal", "") ?: ""
        customGoalKm = prefs.getString("customGoalKm", "") ?: ""
        level = prefs.getString("level", "") ?: ""
        frequency = prefs.getInt("frequency", 0)
        targetDate = prefs.getString("targetDate", "Sem data definida") ?: "Sem data definida"
        volume = prefs.getString("volume", "") ?: ""
        longestRecent = prefs.getString("longestRecent", "") ?: ""
        onboardingStep = prefs.getInt("onboardingStep", if (goal.isBlank()) -1 else 6)
        selectedWorkoutIndex = prefs.getInt("selectedWorkoutIndex", 0)
        planWeeks = prefs.getInt("planWeeks", 4)
        needsEngineRefresh = prefs.getInt("engineVersion", 0) < 18 && prefs.getString("workouts", null) != null
        motorExplanation = prefs.getString("motorExplanation", "") ?: ""
        latestFeedbackHeadline = prefs.getString("latestFeedbackHeadline", "") ?: ""
        latestFeedbackAdvice = prefs.getString("latestFeedbackAdvice", "") ?: ""
        motorError = prefs.getString("motorError", "") ?: ""
        selectedScreen = Screen.entries.getOrNull(prefs.getInt("selectedScreen", Screen.DASHBOARD.ordinal)) ?: Screen.DASHBOARD

        prefs.getString("motorState", null)?.let { raw -> runCatching {
            val o = JSONObject(raw)
            motorState = MotorState(
                fitnessConfidence = o.optString("fitnessConfidence"),
                paceConfidence = o.optString("paceConfidence"),
                recentVolumeKm = o.optDouble("recentVolumeKm"),
                recentLongRunKm = o.optDouble("recentLongRunKm"),
                recoveryStatus = o.optString("recoveryStatus"),
                safetyStatus = o.optString("safetyStatus"),
                phase = o.optString("phase"),
                flags = buildList { val a=o.optJSONArray("flags"); if (a != null) for (i in 0 until a.length()) add(a.optString(i)) }
            )
        }}
        prefs.getString("motorDecision", null)?.let { raw -> runCatching {
            val o = JSONObject(raw)
            motorDecision = MotorDecision(
                action = o.optString("action"), necessity = o.optString("necessity"), stimulus = o.optString("stimulus"),
                rationale = o.optString("rationale"), confidence = o.optDouble("confidence"), safety = o.optString("safety")
            )
        }}
        prefs.getString("workouts", null)?.let { raw -> runCatching {
            val a = JSONArray(raw)
            workouts = buildList {
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    add(Workout(
                        date=o.optString("date"), scheduledDateIso=o.optString("scheduledDateIso"), title=o.optString("title"), detail=o.optString("detail"), type=o.optString("type"),
                        objective=o.optString("objective"), stimulus=o.optString("stimulus"), distanceKm=o.optDouble("distanceKm"),
                        done=o.optBoolean("done"), sessionId=o.optString("sessionId"), durationMin=o.optInt("durationMin"),
                        intensity=o.optString("intensity", "LOW"), paceMode=o.optString("paceMode", "RPE"),
                        rpeRange=o.optString("rpeRange", "3-4"), rationale=o.optString("rationale"),
                        week=o.optInt("week",1), phase=o.optString("phase", "BASE"),
                        segments=buildList {
                            val segmentArray = o.optJSONArray("segments")
                            if (segmentArray != null) for (j in 0 until segmentArray.length()) {
                                val item = segmentArray.optJSONObject(j) ?: continue
                                add(WorkoutSegment(
                                    name=item.optString("name"), instruction=item.optString("instruction"),
                                    durationMin=if (item.has("durationMin")) item.optInt("durationMin") else null,
                                    distanceKm=if (item.has("distanceKm")) item.optDouble("distanceKm") else null,
                                    intensity=item.optString("intensity", "LOW"), rpeRange=item.optString("rpeRange", "2-3"),
                                    repeatCount=item.optInt("repeatCount", 1)
                                ))
                            }
                        }
                    ))
                }
            }
        }}

        prefs.getString("feedbackRecords", null)?.let { raw -> runCatching {
            val a = JSONArray(raw)
            feedbackRecords = buildList {
                for (i in 0 until a.length()) {
                    val item = a.optJSONObject(i) ?: continue
                    add(FeedbackRecord(
                        sessionId = item.optString("sessionId"), effort = item.optString("effort"),
                        feeling = item.optString("feeling"), notes = item.optString("notes"),
                        painPresent = item.optBoolean("painPresent", false),
                        actualDistanceKm = if (item.has("actualDistanceKm")) item.optDouble("actualDistanceKm") else null,
                        savedAt = item.optLong("savedAt", 0L)
                    ))
                }
            }
        } }
        feedbackSaved = feedbackRecords.isNotEmpty()

        // Se o perfil já existe, mas ainda não há plano salvo, leva o usuário ao resumo.
        // O plano só é criado quando ele confirma explicitamente "Criar meu plano".
        if (goal.isNotBlank() && workouts.isNotEmpty()) onboardingStep = 7
    }
}
private val AppColors = darkColorScheme(
    primary = Blue,
    onPrimary = Color.White,
    background = Navy,
    surface = Navy2,
    surfaceVariant = CardBlue,
    onBackground = TextWhite,
    onSurface = TextWhite,
    onSurfaceVariant = TextMuted
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RunningCoachApp() }
    }
}

@Composable
private fun RunningCoachApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val state = remember(context) { CoachState(context.applicationContext) }
    MaterialTheme(colorScheme = AppColors) {
        Surface(Modifier.fillMaxSize(), color = Navy) {
            if (state.onboardingStep in -1..6) Onboarding(state) else MainShell(state)
        }
    }
}

@Composable
private fun Onboarding(state: CoachState) {
    val step = state.onboardingStep
    Column(
        Modifier.fillMaxSize().background(Navy).verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(22.dp))
        Text("AI", color = Blue, fontSize = 38.sp, fontWeight = FontWeight.Black)
        Text("RUNNING COACH", color = TextWhite, fontSize = 25.sp, fontWeight = FontWeight.Black)
        Text("PRESCREVE HOJE, EVOLUI SEMPRE", color = Blue2, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))
        StepBar(step)
        Spacer(Modifier.height(28.dp))
        when (step) {
            -1 -> {
                BigRunnerMark()
                Text("Seu plano. Sua evolução.", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("Prescrição inteligente de treinos de corrida. Sem execução de treino neste app.", color = TextMuted, textAlign = TextAlign.Center, modifier = Modifier.padding(12.dp))
            }
            0 -> {
                Text("Vamos começar", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("Em alguns passos vamos criar seu perfil e seu primeiro plano de corrida.", color = TextMuted, textAlign = TextAlign.Center, modifier = Modifier.padding(12.dp))
            }
            1 -> {
                ChoiceScreen("Qual é o seu objetivo?", listOf("5 km", "10 km", "Meia Maratona (21 km)", "Maratona (42 km)", "Saúde e qualidade de vida", "Outro objetivo"), state.goal) { state.goal = it; state.persist() }
                if (state.goal == "Outro objetivo") {
                    OutlinedTextField(
                        value = state.customGoalKm,
                        onValueChange = { state.customGoalKm = it.filter { ch -> ch.isDigit() || ch == ',' || ch == '.' }; state.persist() },
                        label = { Text("Distância do objetivo em km") },
                        modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color(0xFF35536A))
                    )
                }
            }
            2 -> ChoiceScreen("Qual é o seu nível de experiência?", listOf("Iniciante", "Intermediário", "Avançado", "Elite"), state.level) { state.level = it; state.persist() }
            3 -> ChoiceScreen("Quantos dias por semana você pode treinar?", listOf("2", "3", "4", "5", "6"), if (state.frequency == 0) "" else state.frequency.toString()) { state.frequency = it.toInt(); state.persist() }
            4 -> ChoiceScreen("Qual é o seu volume semanal atual?", listOf("Até 10 km/semana", "10–30 km/semana", "30–50 km/semana", "Acima de 50 km/semana"), state.volume) { state.volume = it; state.persist() }
            5 -> ChoiceScreen("Qual é o seu maior treino recente?", listOf("3 km", "5 km", "7 km", "10 km", "Mais de 10 km"), state.longestRecent) { state.longestRecent = it; state.persist() }
            6 -> {
                Text("Resumo do seu perfil", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = CardBlue)) {
                    Column(Modifier.padding(18.dp)) {
                        InfoRow("Nome", state.name)
                        InfoRow("Nível", state.level)
                        InfoRow("Objetivo", if (state.goal == "Outro objetivo") "${state.customGoalKm} km" else state.goal)
                        InfoRow("Data-alvo", state.targetDate)
                        InfoRow("Frequência", "${state.frequency} dias por semana")
                        InfoRow("Volume semanal", state.volume)
                        InfoRow("Maior treino recente", state.longestRecent)
                    }
                }
            }
        }
        Spacer(Modifier.height(26.dp))
        val canContinue = when (step) {
            1 -> state.goal.isNotBlank()
            2 -> state.level.isNotBlank()
            3 -> state.frequency in 2..6
            4 -> state.volume.isNotBlank()
            5 -> state.longestRecent.isNotBlank()
            6 -> state.goal.isNotBlank() && state.level.isNotBlank() && state.frequency in 2..6 && state.volume.isNotBlank() && state.longestRecent.isNotBlank() && (state.goal != "Outro objetivo" || state.customGoalKm.trim().replace(",", ".").toDoubleOrNull()?.let { it in 1.0..100.0 } == true)
            else -> true
        }
        PrimaryButton(if (step == 6) "Criar meu plano" else if (step <= 0) "Começar" else "Continuar", enabled = canContinue) {
            if (step == 6) state.createPlan() else { state.onboardingStep++; state.persist() }
        }
        if (state.motorError.isNotBlank()) {
            Text(state.motorError, color = Color(0xFFFF8A8A), fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
        }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable private fun StepBar(step: Int) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        repeat(5) { Box(Modifier.weight(1f).height(5.dp).clip(RoundedCornerShape(10.dp)).background(if (it <= step) Blue else Color(0xFF24445B))) }
    }
}

@Composable private fun BigRunnerMark() {
    Box(Modifier.size(150.dp).clip(RoundedCornerShape(80.dp)).background(Color(0xFF0D3148)), contentAlignment = Alignment.Center) {
        Text("🏃", fontSize = 76.sp)
    }
}

@Composable private fun ChoiceScreen(title: String, options: List<String>, current: String, selected: (String) -> Unit) {
    Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
    Spacer(Modifier.height(14.dp))
    options.forEach { option ->
        val isSelected = option == current
        Card(
            Modifier
                .fillMaxWidth()
                .padding(vertical = 5.dp)
                .then(if (isSelected) Modifier.border(2.dp, Blue, RoundedCornerShape(12.dp)) else Modifier)
                .clickable { selected(option) },
            colors = CardDefaults.cardColors(containerColor = if (isSelected) Color(0xFF174968) else CardBlue),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(20.dp).border(2.dp, if (isSelected) Blue else TextMuted, RoundedCornerShape(50)),
                    contentAlignment = Alignment.Center
                ) {
                    if (isSelected) Box(Modifier.size(10.dp).clip(RoundedCornerShape(50)).background(Blue))
                }
                Spacer(Modifier.width(12.dp))
                Text(option, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold)
            }
        }
    }
}

@Composable private fun MainShell(state: CoachState) {
    Scaffold(containerColor = Navy, bottomBar = { BottomNav(state) }) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (state.selectedScreen) {
                Screen.DASHBOARD -> Dashboard(state)
                Screen.CALENDAR -> CalendarScreen(state)
                Screen.WORKOUT -> WorkoutDetail(state)
                Screen.STRUCTURE -> StructureScreen(state)
                Screen.PLAN -> PlanScreen(state)
                Screen.EVOLUTION -> EvolutionScreen(state)
                Screen.FEEDBACK -> FeedbackScreen(state)
                Screen.HISTORY -> HistoryScreen(state)
                Screen.PROFILE -> ProfileScreen(state)
                Screen.EXPORT -> ExportScreen(state)
            }
        }
    }
}

@Composable private fun Header(title: String, back: Boolean = false, onBack: () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        if (back) Text("‹", fontSize = 34.sp, color = Blue, modifier = Modifier.clickable { onBack() }.padding(end = 12.dp))
        Column(Modifier.weight(1f)) { Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text("AI RUNNING COACH", color = Blue2, fontSize = 9.sp, fontWeight = FontWeight.Bold) }
    }
}

@Composable private fun Dashboard(state: CoachState) {
    LazyColumnLike {
        Header("Olá, ${state.name}! 👋")
        Text("Aqui está o seu panorama atual.", color = TextMuted, modifier = Modifier.padding(horizontal = 20.dp))
        Spacer(Modifier.height(12.dp))
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard("Fitness", state.motorState?.fitnessConfidence ?: "Muito baixo", "🏃", Blue2, Modifier.weight(1f))
            MetricCard("Carga", if (state.motorState?.recentVolumeKm ?: 0.0 > 0) "Base conhecida" else "Sem dados", "⚡", Yellow, Modifier.weight(1f))
        }
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard("Recuperação", state.motorState?.recoveryStatus ?: "Desconhecida", "◔", Blue2, Modifier.weight(1f))
            MetricCard("Segurança", state.motorState?.safetyStatus ?: "GREEN", "♥", Green, Modifier.weight(1f))
        }
        val firstWeekCount = state.workouts.count { it.week == 1 }
        CardBlock("Plano de ${state.planWeeks} semanas", "$firstWeekCount treinos na semana 1", "Prescrição com periodização, progressão e semanas regenerativas.")
        val readinessFlags = state.motorState?.flags.orEmpty()
        if (readinessFlags.contains("LOW_WEEKLY_BASELINE") || readinessFlags.contains("LIMITED_LONG_RUN_HISTORY")) {
            NoteBlock("Sua base recente ainda é limitada. O motor reduziu as doses e pode prescrever menos quilômetros que a faixa informada; não tente completar a diferença por conta própria.")
        }
        if (state.needsEngineRefresh) {
            NoteBlock("O motor V18 está disponível. Recalcule seu plano para substituir a prescrição anterior por um ciclo completo.")
            PrimaryButton("Atualizar plano para V18") { state.createPlan() }
        }
        if (state.motorDecision?.safety == "RED" && state.motorError.isNotBlank()) {
            NoteBlock(state.motorError)
        }
        if (state.latestFeedbackHeadline.isNotBlank()) {
            CardBlock(state.latestFeedbackHeadline, "Feedback integrado", state.latestFeedbackAdvice)
        }
        if (state.workouts.isEmpty()) {
            NoteBlock(if (state.motorError.isBlank()) "Seu perfil foi salvo. Confirme os dados e gere o plano para o motor criar as prescrições." else state.motorError)
            PrimaryButton("Gerar plano agora") { state.onboardingStep = 6; state.selectedScreen = Screen.DASHBOARD; state.persist() }
        }
        Text("Próximos treinos", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(20.dp, 14.dp, 20.dp, 4.dp))
        state.workouts.take(3).forEach { WorkoutCard(it) { state.selectWorkout(it) } }
    }
}

@Composable private fun MetricCard(label: String, value: String, icon: String, accent: Color, modifier: Modifier = Modifier) {
    Card(modifier.padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = CardBlue)) {
        Column(Modifier.padding(14.dp)) { Text(icon, fontSize = 22.sp); Text(label, color = TextMuted, fontSize = 11.sp); Text(value, color = accent, fontWeight = FontWeight.Bold) }
    }
}

@Composable private fun CardBlock(title: String, main: String, note: String) {
    Card(Modifier.fillMaxWidth().padding(16.dp, 8.dp), colors = CardDefaults.cardColors(containerColor = CardBlue)) {
        Column(Modifier.padding(18.dp)) { Text(title, color = Blue2, fontWeight = FontWeight.Bold); Text(main, fontSize = 24.sp, fontWeight = FontWeight.Black); Text(note, color = TextMuted, fontSize = 12.sp) }
    }
}

@Composable private fun WorkoutCard(w: Workout, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp).clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = CardBlue)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(21.dp)).background(Color(0xFF16455D)), contentAlignment = Alignment.Center) { Text(if (w.type.contains("Velocidade")) "⚡" else "🏃", fontSize = 20.sp) }
            Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(w.date, color = TextMuted, fontSize = 11.sp); Text(w.title, fontWeight = FontWeight.Bold); Text(w.detail, color = Blue2, fontSize = 12.sp) }
            Text(if (w.done) "✓" else "○", color = if (w.done) Green else TextMuted, fontSize = 24.sp)
        }
    }
}

@Composable private fun CalendarScreen(state: CoachState) {
    LazyColumnLike {
        Header("Calendário do plano")
        if (state.workouts.isEmpty()) {
            NoteBlock("Gere um plano para visualizar as sessões programadas.")
        } else {
            state.workouts.groupBy { it.week }.toSortedMap().forEach { (week, sessions) ->
                val km = sessions.sumOf { it.distanceKm }
                CardBlock("Semana $week • ${sessions.firstOrNull()?.phase ?: "BASE"}", "${String.format(Locale.US, "%.1f", km)} km", "${sessions.size} sessões planejadas")
                sessions.forEach { WorkoutCard(it) { state.selectWorkout(it) } }
            }
        }
    }
}

@Composable private fun WorkoutDetail(state: CoachState) {
    val w = state.selectedWorkout()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("Detalhes do treino", true) { state.selectedScreen = Screen.CALENDAR }
        if (w == null) {
            CardBlock("Plano ainda não criado", "Complete o perfil", "O treinador precisa dos seus dados para prescrever.")
            return@Column
        }
        Card(Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(containerColor = CardBlue)) {
            Text("🏃  ${w.type.uppercase()}", color = Blue2, fontWeight = FontWeight.Bold)
            Text(w.title, fontSize = 26.sp, fontWeight = FontWeight.Black)
            Text(w.date, color = TextMuted)
            Spacer(Modifier.height(14.dp))
            InfoRow("Objetivo", w.objective)
            InfoRow("Estímulo", w.stimulus)
            InfoRow("Volume estimado", "${w.distanceKm} km")
            InfoRow("Dose", w.detail)
        }
        ListButton("Estrutura do treino") { state.selectedScreen = Screen.STRUCTURE }
        ListButton("Por que este treino?") {}
        ListButton("Como ele se encaixa no plano?") {}
        PrimaryButton("Exportar para Pace Coach") { state.selectedScreen = Screen.EXPORT }
    }
}

@Composable private fun StructureScreen(state: CoachState) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("Estrutura do treino", true) { state.selectedScreen = Screen.WORKOUT }
        val w = state.selectedWorkout()
        if (w == null) {
            NoteBlock("Selecione um treino no calendário para visualizar a estrutura prescrita.")
            return@Column
        }
        if (w.segments.isEmpty()) {
            StructureBlock("1", w.title, w.detail, "Estrutura antiga. Atualize o plano para receber os blocos estruturados do motor V18.")
        } else {
            w.segments.forEachIndexed { index, segment ->
                val dose = when {
                    segment.repeatCount > 1 && segment.durationMin != null -> "${segment.repeatCount} × ${segment.durationMin} min"
                    segment.distanceKm != null -> "${String.format(Locale.US, "%.1f", segment.distanceKm)} km"
                    segment.durationMin != null -> "${segment.durationMin} min"
                    else -> "Conforme orientação"
                }
                StructureBlock("${index + 1}", segment.name, "$dose • RPE ${segment.rpeRange}", segment.instruction)
            }
        }
        NoteBlock(w.rationale)
    }
}

@Composable
private fun StructureBlock(n: String, title: String, dose: String, desc: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 5.dp),
        colors = CardDefaults.cardColors(containerColor = CardBlue)
    ) {
        Row(Modifier.padding(16.dp)) {
            Text(
                text = n,
                modifier = Modifier.width(36.dp),
                color = Blue,
                fontSize = 25.sp,
                fontWeight = FontWeight.Black
            )
            Column {
                Text(text = title, fontWeight = FontWeight.Bold)
                Text(
                    text = dose,
                    fontSize = 19.sp,
                    color = Blue2,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = desc,
                    color = TextMuted,
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            color = TextMuted,
            fontSize = 12.sp,
            modifier = Modifier.weight(0.42f)
        )
        Text(
            text = value,
            color = TextWhite,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.End,
            modifier = Modifier.weight(0.58f)
        )
    }
}

@Composable
private fun ListButton(text: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 5.dp)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = CardBlue),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 15.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = text,
                color = TextWhite,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = "›",
                color = TextMuted,
                fontSize = 22.sp
            )
        }
    }
}

@Composable private fun NoteBlock(text: String) { Card(Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF0E3144))) { Text("ⓘ  $text", Modifier.padding(14.dp), color = Blue2, fontSize = 12.sp) } }

@Composable private fun PlanScreen(state: CoachState) {
    LazyColumnLike {
        Header("Plano de treinos")
        CardBlock("${state.goal}", "${state.planWeeks} semanas", state.motorDecision?.rationale ?: "Plano gerado pelo motor de prescrição.")
        state.motorDecision?.let { d ->
            CardBlock("Decisão do motor", "${d.action} • ${d.stimulus}", "Necessidade: ${d.necessity} • Confiança: ${String.format(Locale.US, "%.0f", d.confidence * 100)}% • Segurança: ${d.safety}")
        }
        state.workouts.groupBy { it.week }.toSortedMap().forEach { (week, sessions) ->
            val km = sessions.sumOf { it.distanceKm }
            val phase = sessions.firstOrNull()?.phase ?: "BASE"
            ListButton("Semana $week — $phase • ${String.format(Locale.US, "%.1f", km)} km • ${sessions.size} treinos") {
                state.selectWorkout(sessions.first())
            }
        }
        if (state.workouts.isEmpty()) NoteBlock("Nenhuma sessão foi gerada. Revise o perfil do atleta.")
        NoteBlock(state.motorExplanation.ifBlank { "O motor ainda não gerou uma explicação para este plano." })
    }
}

@Composable private fun EvolutionScreen(state: CoachState) {
    val completed = state.completedWorkouts()
    LazyColumnLike {
        Header("Evolução")
        if (completed.isEmpty()) {
            NoteBlock("Ainda não há treinos marcados como concluídos. Registre o feedback após uma sessão para começar a construir seu histórico.")
        } else {
            val recordedDistances = state.feedbackRecords.associateBy { it.sessionId }
            val withDistance = completed.mapNotNull { workout ->
                recordedDistances[workout.sessionId]?.actualDistanceKm?.let { workout.week to it }
            }
            if (withDistance.isNotEmpty()) {
                val weeklyTotals = withDistance.groupBy { it.first }.toSortedMap().mapValues { (_, runs) -> runs.sumOf { it.second }.toInt() }
                ChartCard("Distância efetivamente registrada (km)", weeklyTotals.values.toList())
                CardBlock("Treinos concluídos", completed.size.toString(), "Distância informada: ${String.format(Locale.US, "%.1f", withDistance.sumOf { it.second })} km")
            } else {
                CardBlock("Treinos com feedback", completed.size.toString(), "Nenhuma distância realizada foi informada ainda.")
            }
            NoteBlock("O condicionamento fisiológico ainda não é estimado. Isso exigirá histórico confiável de ritmo, frequência cardíaca ou testes de referência.")
        }
    }
}

@Composable private fun ChartCard(title: String, values: List<Int>) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 7.dp), colors = CardDefaults.cardColors(containerColor = CardBlue)) {
        Column(Modifier.padding(16.dp)) { Text(title, fontWeight = FontWeight.Bold); Spacer(Modifier.height(18.dp)); Row(Modifier.fillMaxWidth().height(90.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) { values.forEach { v -> Box(Modifier.weight(1f).height((v * 1.4).dp).background(Blue, RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))) } } }
    }
}

@Composable private fun Segmented(vararg labels: String) { Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) { labels.forEachIndexed { i, label -> Box(Modifier.weight(1f).clip(RoundedCornerShape(9.dp)).background(if (i == 0) Blue else CardBlue).padding(10.dp), contentAlignment = Alignment.Center) { Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold) } } } }

@Composable private fun FeedbackScreen(state: CoachState) {
    var effort by remember(state.selectedWorkoutIndex) { mutableStateOf("Leve") }
    var feeling by remember(state.selectedWorkoutIndex) { mutableStateOf("Bem") }
    var pain by remember(state.selectedWorkoutIndex) { mutableStateOf("Não") }
    var notes by remember(state.selectedWorkoutIndex) { mutableStateOf("") }
    var actualDistance by remember(state.selectedWorkoutIndex) { mutableStateOf("") }
    val workout = state.selectedWorkout()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("Feedback do treino", true) { state.selectedScreen = Screen.HISTORY }
        Text(workout?.let { "${it.title} • ${it.date}" } ?: "Selecione um treino", color = TextMuted, modifier = Modifier.padding(horizontal = 20.dp))
        Spacer(Modifier.height(18.dp))
        FeedbackGroup("Como foi o treino?", listOf("Muito leve","Leve","Ok","Pesado","Muito pesado"), effort) { effort = it }
        FeedbackGroup("Como você se sentiu?", listOf("Ótimo","Bem","Cansado","Muito cansado"), feeling) { feeling = it }
        FeedbackGroup("Sentiu dor durante ou após o treino?", listOf("Não", "Sim"), pain) { pain = it }
        OutlinedTextField(actualDistance, { actualDistance = it.filter { ch -> ch.isDigit() || ch == ',' || ch == '.' } }, label = { Text("Distância realizada em km (opcional)") }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp), singleLine = true, colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color(0xFF35536A)))
        OutlinedTextField(notes, { notes = it }, label = { Text("Observações (opcional)") }, modifier = Modifier.fillMaxWidth().padding(16.dp), minLines = 4, colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color(0xFF35536A)))
        PrimaryButton(if (state.feedbackSaved) "Salvar novo feedback" else "Salvar feedback", enabled = workout != null) {
            state.saveFeedback(effort, feeling, notes, pain == "Sim", actualDistance)
            state.selectedScreen = Screen.DASHBOARD
        }
    }
}

@Composable private fun FeedbackGroup(title: String, options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Text(title, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)); Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) { options.forEach { o -> Box(Modifier.clip(RoundedCornerShape(18.dp)).background(if (o == selected) Blue else CardBlue).clickable { onSelect(o) }.padding(horizontal = 13.dp, vertical = 9.dp)) { Text(o, fontSize = 11.sp) } } }
}

@Composable private fun HistoryScreen(state: CoachState) {
    LazyColumnLike {
        Header("Histórico de treinos")
        val completed = state.completedWorkouts()
        if (completed.isEmpty()) NoteBlock("Nenhum treino concluído registrado ainda.")
        completed.forEach { w -> WorkoutCard(w) { state.selectWorkout(w); state.selectedScreen = Screen.FEEDBACK } }
    }
}

@Composable private fun ProfileScreen(state: CoachState) {
    LazyColumnLike {
        Header("Perfil / Configurações", true) { state.selectedScreen = Screen.DASHBOARD }
        CardBlock(state.name, state.level, "Objetivo: ${state.goal}")
        ListButton("Dados pessoais") {}
        ListButton("Objetivos") {}
        ListButton("Disponibilidade") {}
        ListButton("Preferências") {}
        ListButton("Conexão com Pace Coach") { state.selectedScreen = Screen.EXPORT }
        ListButton("Notificações") {}
        ListButton("Privacidade") {}
        ListButton("Ajuda e suporte") {}
    }
}

@Composable private fun ExportScreen(state: CoachState) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val workout = state.selectedWorkout()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("Exportar para Pace Coach", true) { state.selectedScreen = Screen.WORKOUT }
        BigRunnerMark()
        Text("Compartilhar prescrição estruturada", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterHorizontally))
        Spacer(Modifier.height(20.dp))
        StepExport("1", "Treino selecionado", workout?.let { "${it.title} • ${it.date}" } ?: "Nenhum treino selecionado")
        StepExport("2", "Dados estruturados", workout?.let { "${it.distanceKm} km • ~${it.durationMin} min (estimativa geral) • RPE ${it.rpeRange} • ${it.segments.size} blocos" } ?: "Estrutura da prescrição")
        StepExport("3", "Transferência", "Será gerado um JSON versionado para compartilhamento. A importação automática depende do Pace Coach reconhecer o contrato pace-coach-workout 1.0.")
        PrimaryButton("Compartilhar JSON", enabled = workout != null) {
            val selected = workout
            if (selected != null) {
                val prescription = selected.toPrescribedWorkout()
                val goalDistanceKm = when {
                    state.goal.startsWith("5") -> 5.0
                    state.goal.startsWith("10") -> 10.0
                    state.goal.startsWith("Meia") -> 21.1
                    state.goal.startsWith("Maratona") -> 42.2
                    state.goal == "Outro objetivo" -> state.customGoalKm.trim().replace(",", ".").toDoubleOrNull()
                    else -> 5.0
                }
                val json = PaceCoachExporter.workoutToJson(prescription, state.goal, goalDistanceKm)
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "application/json"
                    putExtra(Intent.EXTRA_SUBJECT, "Prescrição — ${selected.title}")
                    putExtra(Intent.EXTRA_TEXT, json)
                }
                context.startActivity(Intent.createChooser(sendIntent, "Enviar prescrição para o Pace Coach"))
            }
        }
    }
}

private fun Workout.toPrescribedWorkout(): PrescribedWorkout = PrescribedWorkout(
    day = date.substringBefore(","), date = date, scheduledDateIso = scheduledDateIso, title = title, type = type, objective = objective,
    stimulus = stimulus, sessionId = sessionId, distanceKm = distanceKm, durationMin = durationMin,
    intensity = intensity, paceMode = paceMode, rpeRange = rpeRange, detail = detail,
    rationale = rationale, week = week, phase = phase, segments = segments
)

@Composable
private fun StepExport(n: String, title: String, desc: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp, 6.dp),
        colors = CardDefaults.cardColors(containerColor = CardBlue)
    ) {
        Row(Modifier.padding(16.dp)) {
            Text(
                text = n,
                modifier = Modifier.width(34.dp),
                color = Blue,
                fontSize = 24.sp,
                fontWeight = FontWeight.Black
            )
            Column {
                Text(text = title, fontWeight = FontWeight.Bold)
                Text(
                    text = desc,
                    color = TextMuted,
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable private fun BottomNav(state: CoachState) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(72.dp)
            .background(Color(0xFF071522)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        NavItem(Modifier.weight(1f), "⌂", "Início", state.selectedScreen == Screen.DASHBOARD) { state.selectedScreen = Screen.DASHBOARD }
        NavItem(Modifier.weight(1f), "▦", "Calendário", state.selectedScreen == Screen.CALENDAR) { state.selectedScreen = Screen.CALENDAR }
        NavItem(Modifier.weight(1f), "☷", "Plano", state.selectedScreen == Screen.PLAN) { state.selectedScreen = Screen.PLAN }
        NavItem(Modifier.weight(1f), "↗", "Evolução", state.selectedScreen == Screen.EVOLUTION) { state.selectedScreen = Screen.EVOLUTION }
        NavItem(Modifier.weight(1f), "⋯", "Mais", state.selectedScreen == Screen.PROFILE) { state.selectedScreen = Screen.PROFILE }
    }
}

@Composable private fun NavItem(modifier: Modifier, icon: String, label: String, selected: Boolean, onClick: () -> Unit) {
    Column(
        modifier = modifier
            .fillMaxHeight()
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = icon,
            fontSize = 20.sp,
            color = if (selected) Blue else TextMuted
        )
        Text(
            text = label,
            fontSize = 9.sp,
            color = if (selected) Blue else TextMuted,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

@Composable private fun PrimaryButton(text: String, enabled: Boolean = true, onClick: () -> Unit) { Button(onClick = onClick, enabled = enabled, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(52.dp), shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.buttonColors(containerColor = Blue)) { Text(text, fontWeight = FontWeight.Bold) } }

@Composable private fun LazyColumnLike(content: @Composable ColumnScope.() -> Unit) { Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), content = content) }
