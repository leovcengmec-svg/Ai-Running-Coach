package com.airunningcoach.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Navy = Color(0xFF061B2B)
private val Navy2 = Color(0xFF0B2639)
private val CardBlue = Color(0xFF12364D)
private val Blue = Color(0xFF2CA7FF)
private val Blue2 = Color(0xFF63C5FF)
private val TextWhite = Color(0xFFF4F8FB)
private val TextMuted = Color(0xFF9EB2C2)
private val Green = Color(0xFF35D5A0)
private val Yellow = Color(0xFFFFC857)

private enum class Screen { DASHBOARD, CALENDAR, WORKOUT, STRUCTURE, PLAN, EVOLUTION, FEEDBACK, HISTORY, PROFILE, EXPORT }

private data class Workout(val date: String, val title: String, val detail: String, val type: String, val done: Boolean = false)

private class CoachState {
    var name by mutableStateOf("Leonardo")
    var goal by mutableStateOf("Maratona (42 km)")
    var level by mutableStateOf("Intermediário")
    var frequency by mutableStateOf(5)
    var targetDate by mutableStateOf("21/04/2026")
    var volume by mutableStateOf("30–50 km/semana")
    var onboardingStep by mutableStateOf(-1)
    var selectedScreen by mutableStateOf(Screen.DASHBOARD)
    var feedbackSaved by mutableStateOf(false)
    val workouts = listOf(
        Workout("17/04", "Intervalado", "6 × 800 m", "Velocidade e limiar"),
        Workout("19/04", "Rodagem leve", "8 km", "Resistência aeróbia"),
        Workout("21/04", "Longão", "18 km", "Resistência específica"),
        Workout("23/04", "Regenerativo", "5 km", "Recuperação")
    )
}

private val AppColors = darkColorScheme(
    primary = Blue,
    onPrimary = Color.White,
    background = Navy,
    surface = Navy2,
    surfaceVariant = CardBlue,
    onBackground = TextWhite,
    onSurface = TextWhite,
    onSurfaceVariant = TextMuted
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RunningCoachApp() }
    }
}

@Composable
private fun RunningCoachApp() {
    val state = remember { CoachState() }
    MaterialTheme(colorScheme = AppColors) {
        Surface(Modifier.fillMaxSize(), color = Navy) {
            if (state.onboardingStep < 6) Onboarding(state) else MainShell(state)
        }
    }
}

@Composable
private fun Onboarding(state: CoachState) {
    val step = state.onboardingStep
    Column(
        Modifier.fillMaxSize().background(Navy).verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(22.dp))
        Text("AI", color = Blue, fontSize = 38.sp, fontWeight = FontWeight.Black)
        Text("RUNNING COACH", color = TextWhite, fontSize = 25.sp, fontWeight = FontWeight.Black)
        Text("PRESCREVE HOJE, EVOLUI SEMPRE", color = Blue2, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))
        StepBar(step)
        Spacer(Modifier.height(28.dp))
        when (step) {
            -1 -> {
                BigRunnerMark()
                Text("Seu plano. Sua evolução.", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("Prescrição inteligente de treinos de corrida. Sem execução de treino neste app.", color = TextMuted, textAlign = TextAlign.Center, modifier = Modifier.padding(12.dp))
            }
            0 -> {
                Text("Vamos começar", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("Em alguns passos vamos criar seu perfil e seu primeiro plano de corrida.", color = TextMuted, textAlign = TextAlign.Center, modifier = Modifier.padding(12.dp))
            }
            1 -> ChoiceScreen("Qual é o seu objetivo?", listOf("5 km", "10 km", "Meia Maratona (21 km)", "Maratona (42 km)", "Saúde e qualidade de vida", "Outro objetivo")) { state.goal = it }
            2 -> ChoiceScreen("Qual é o seu nível de experiência?", listOf("Iniciante", "Intermediário", "Avançado", "Elite")) { state.level = it }
            3 -> ChoiceScreen("Quantos dias por semana você pode treinar?", listOf("2", "3", "4", "5", "6")) { state.frequency = it.toInt() }
            4 -> ChoiceScreen("Qual é a sua disponibilidade?", listOf("Até 10 km/semana", "10–30 km/semana", "30–50 km/semana", "Acima de 50 km/semana")) { state.volume = it }
            5 -> {
                Text("Resumo do seu perfil", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = CardBlue)) {
                    Column(Modifier.padding(18.dp)) {
                        InfoRow("Nome", state.name)
                        InfoRow("Nível", state.level)
                        InfoRow("Objetivo", state.goal)
                        InfoRow("Data-alvo", state.targetDate)
                        InfoRow("Frequência", "${state.frequency} dias por semana")
                        InfoRow("Volume atual", state.volume)
                    }
                }
            }
        }
        Spacer(Modifier.height(26.dp))
        PrimaryButton(if (step == 5) "Criar meu plano" else if (step <= 0) "Começar" else "Continuar") {
            if (step == 5) state.onboardingStep = 6 else state.onboardingStep++
        }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable private fun StepBar(step: Int) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        repeat(5) { Box(Modifier.weight(1f).height(5.dp).clip(RoundedCornerShape(10.dp)).background(if (it <= step) Blue else Color(0xFF24445B))) }
    }
}

@Composable private fun BigRunnerMark() {
    Box(Modifier.size(150.dp).clip(RoundedCornerShape(80.dp)).background(Color(0xFF0D3148)), contentAlignment = Alignment.Center) {
        Text("🏃", fontSize = 76.sp)
    }
}

@Composable private fun ChoiceScreen(title: String, options: List<String>, selected: (String) -> Unit) {
    Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
    Spacer(Modifier.height(14.dp))
    options.forEach { option ->
        Card(Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { selected(option) }, colors = CardDefaults.cardColors(containerColor = CardBlue), shape = RoundedCornerShape(12.dp)) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("◉", color = Blue, fontSize = 18.sp)
                Spacer(Modifier.width(12.dp))
                Text(option, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable private fun MainShell(state: CoachState) {
    Scaffold(containerColor = Navy, bottomBar = { BottomNav(state) }) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (state.selectedScreen) {
                Screen.DASHBOARD -> Dashboard(state)
                Screen.CALENDAR -> CalendarScreen(state)
                Screen.WORKOUT -> WorkoutDetail(state)
                Screen.STRUCTURE -> StructureScreen(state)
                Screen.PLAN -> PlanScreen(state)
                Screen.EVOLUTION -> EvolutionScreen()
                Screen.FEEDBACK -> FeedbackScreen(state)
                Screen.HISTORY -> HistoryScreen(state)
                Screen.PROFILE -> ProfileScreen(state)
                Screen.EXPORT -> ExportScreen(state)
            }
        }
    }
}

@Composable private fun Header(title: String, back: Boolean = false, onBack: () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        if (back) Text("‹", fontSize = 34.sp, color = Blue, modifier = Modifier.clickable { onBack() }.padding(end = 12.dp))
        Column(Modifier.weight(1f)) { Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text("AI RUNNING COACH", color = Blue2, fontSize = 9.sp, fontWeight = FontWeight.Bold) }
    }
}

@Composable private fun Dashboard(state: CoachState) {
    LazyColumnLike {
        Header("Olá, ${state.name}! 👋")
        Text("Aqui está o seu panorama atual.", color = TextMuted, modifier = Modifier.padding(horizontal = 20.dp))
        Spacer(Modifier.height(12.dp))
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard("Fitness", "Bom", "🏃", Green, Modifier.weight(1f))
            MetricCard("Carga", "Moderada", "⚡", Yellow, Modifier.weight(1f))
        }
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard("Recuperação", "Boa", "◔", Blue2, Modifier.weight(1f))
            MetricCard("Segurança", "OK", "♥", Green, Modifier.weight(1f))
        }
        CardBlock("Semana atual", "3 / ${state.frequency} treinos", "Consistência adequada para o objetivo.")
        Text("Próximos treinos", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(20.dp, 14.dp, 20.dp, 4.dp))
        state.workouts.take(3).forEach { WorkoutCard(it) { state.selectedScreen = Screen.WORKOUT } }
    }
}

@Composable private fun MetricCard(label: String, value: String, icon: String, accent: Color, modifier: Modifier = Modifier) {
    Card(modifier.padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = CardBlue)) {
        Column(Modifier.padding(14.dp)) { Text(icon, fontSize = 22.sp); Text(label, color = TextMuted, fontSize = 11.sp); Text(value, color = accent, fontWeight = FontWeight.Bold) }
    }
}

@Composable private fun CardBlock(title: String, main: String, note: String) {
    Card(Modifier.fillMaxWidth().padding(16.dp, 8.dp), colors = CardDefaults.cardColors(containerColor = CardBlue)) {
        Column(Modifier.padding(18.dp)) { Text(title, color = Blue2, fontWeight = FontWeight.Bold); Text(main, fontSize = 24.sp, fontWeight = FontWeight.Black); Text(note, color = TextMuted, fontSize = 12.sp) }
    }
}

@Composable private fun WorkoutCard(w: Workout, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp).clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = CardBlue)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(21.dp)).background(Color(0xFF16455D)), contentAlignment = Alignment.Center) { Text(if (w.type.contains("Velocidade")) "⚡" else "🏃", fontSize = 20.sp) }
            Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(w.date, color = TextMuted, fontSize = 11.sp); Text(w.title, fontWeight = FontWeight.Bold); Text(w.detail, color = Blue2, fontSize = 12.sp) }
            Text(if (w.done) "✓" else "○", color = if (w.done) Green else TextMuted, fontSize = 24.sp)
        }
    }
}

@Composable private fun CalendarScreen(state: CoachState) {
    LazyColumnLike {
        Header("Calendário")
        CardBlock("Abril 2026", "‹     17     ›", "Semana 5 de 16")
        CalendarGrid()
        state.workouts.forEach { WorkoutCard(it) { state.selectedScreen = Screen.WORKOUT } }
    }
}

@Composable private fun CalendarGrid() {
    val days = listOf("D","S","T","Q","Q","S","S")
    Column(Modifier.padding(horizontal = 18.dp)) {
        Row(Modifier.fillMaxWidth()) { days.forEach { Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, color = TextMuted, fontSize = 11.sp) } }
        (1..28).chunked(7).forEach { week -> Row(Modifier.fillMaxWidth()) { week.forEach { d -> Box(Modifier.weight(1f).padding(4.dp).height(34.dp), contentAlignment = Alignment.Center) { Text(if (d == 17) "●\n$d" else d.toString(), textAlign = TextAlign.Center, color = if (d == 17) Blue else TextWhite, fontSize = 12.sp) } } } }
    }
}

@Composable private fun WorkoutDetail(state: CoachState) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("Detalhes do treino", true) { state.selectedScreen = Screen.CALENDAR }
        Card(Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(containerColor = CardBlue)) {
            Text("⚡  INTERVALADO", color = Blue2, fontWeight = FontWeight.Bold); Text("6 × 800 m", fontSize = 26.sp, fontWeight = FontWeight.Black); Text("Sex, 17 de Abril de 2026", color = TextMuted)
            Spacer(Modifier.height(14.dp)); InfoRow("Objetivo", "Desenvolver velocidade"); InfoRow("Estímulo", "VO₂ e limiar"); InfoRow("Volume estimado", "10 km"); InfoRow("Duração estimada", "~55 min")
        }
        ListButton("Estrutura do treino") { state.selectedScreen = Screen.STRUCTURE }
        ListButton("Ritmos de referência") {}
        ListButton("Benefícios") {}
        ListButton("Observações") {}
        PrimaryButton("Exportar para Pace Coach") { state.selectedScreen = Screen.EXPORT }
        Spacer(Modifier.height(30.dp))
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
    ) {
        Text(
            label,
            Modifier.weight(1f),
            color = TextMuted
        )
        Text(
            value,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable private fun ListButton(text: String, onClick: () -> Unit) { Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = CardBlue)) { Row(Modifier.padding(16.dp)) { Text(text, Modifier.weight(1f), fontWeight = FontWeight.SemiBold); Text("›", color = Blue, fontSize = 22.sp) } } }

@Composable private fun StructureScreen(state: CoachState) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("Estrutura do treino", true) { state.selectedScreen = Screen.WORKOUT }
        StructureBlock("1", "Aquecimento", "2 km", "Ritmo leve (6:30 – 7:00/km)")
        StructureBlock("2", "Bloco principal", "6 × 800 m", "Ritmo: 4:50 – 5:00/km\nRecuperação: 400 m leve (6:30 – 7:00/km)")
        StructureBlock("3", "Desaquecimento", "2 km", "Ritmo leve (6:30 – 7:00/km)")
        NoteBlock("Os ritmos são referências e podem ser ajustados conforme sua evolução.")
    }
}

@Composable
private fun StructureBlock(n: String, title: String, dose: String, desc: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 5.dp),
        colors = CardDefaults.cardColors(containerColor = CardBlue)
    ) {
        Row(Modifier.padding(16.dp)) {
            Text(
                text = n,
                modifier = Modifier.width(36.dp),
                color = Blue,
                fontSize = 25.sp,
                fontWeight = FontWeight.Black
            )
            Column {
                Text(text = title, fontWeight = FontWeight.Bold)
                Text(
                    text = dose,
                    fontSize = 19.sp,
                    color = Blue2,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = desc,
                    color = TextMuted,
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable private fun NoteBlock(text: String) { Card(Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF0E3144))) { Text("ⓘ  $text", Modifier.padding(14.dp), color = Blue2, fontSize = 12.sp) } }

@Composable private fun PlanScreen(state: CoachState) {
    LazyColumnLike {
        Header("Plano de treinos")
        CardBlock("Maratona (42 km)", "16 semanas", "Até ${state.targetDate}")
        listOf("Semana 1 — Base e adaptação", "Semana 2 — Progressão", "Semana 3 — Desenvolvimento", "Semana 4 — Consolidação", "Semana 5 — Especificidade").forEachIndexed { i, t ->
            ListButton("${i + 1}.  $t") { if (i == 4) state.selectedScreen = Screen.CALENDAR }
        }
        Row(Modifier.fillMaxWidth().padding(20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricCard("Volume", "28 km", "▥", Blue2, Modifier.weight(1f)); MetricCard("Treinos", "5", "✓", Green, Modifier.weight(1f)) }
    }
}

@Composable private fun EvolutionScreen() {
    LazyColumnLike {
        Header("Evolução")
        Segmented("Semanas", "Meses", "Anos")
        ChartCard("Volume semanal (km)", listOf(24, 28, 27, 34, 38, 42))
        ChartCard("Fitness estimado", listOf(45, 47, 48, 51, 53, 55))
        NoteBlock("Evolução consistente! Seu volume e condicionamento estão em progresso.")
    }
}

@Composable private fun ChartCard(title: String, values: List<Int>) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 7.dp), colors = CardDefaults.cardColors(containerColor = CardBlue)) {
        Column(Modifier.padding(16.dp)) { Text(title, fontWeight = FontWeight.Bold); Spacer(Modifier.height(18.dp)); Row(Modifier.fillMaxWidth().height(90.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) { values.forEach { v -> Box(Modifier.weight(1f).height((v * 1.4).dp).background(Blue, RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))) } } }
    }
}

@Composable private fun Segmented(vararg labels: String) { Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) { labels.forEachIndexed { i, label -> Box(Modifier.weight(1f).clip(RoundedCornerShape(9.dp)).background(if (i == 0) Blue else CardBlue).padding(10.dp), contentAlignment = Alignment.Center) { Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold) } } } }

@Composable private fun FeedbackScreen(state: CoachState) {
    var effort by remember { mutableStateOf("Leve") }
    var feeling by remember { mutableStateOf("Bem") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("Feedback do treino", true) { state.selectedScreen = Screen.HISTORY }
        Text("Sex, 17 de Abril", color = TextMuted, modifier = Modifier.padding(horizontal = 20.dp))
        Spacer(Modifier.height(18.dp)); FeedbackGroup("Como foi o treino?", listOf("Muito leve","Leve","Ok","Pesado","Muito pesado"), effort) { effort = it }
        FeedbackGroup("Como você se sentiu?", listOf("Ótimo","Bem","Cansado","Muito cansado"), feeling) { feeling = it }
        OutlinedTextField("", {}, label = { Text("Observações (opcional)") }, modifier = Modifier.fillMaxWidth().padding(16.dp), minLines = 4, colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color(0xFF35536A)))
        PrimaryButton(if (state.feedbackSaved) "Feedback salvo ✓" else "Salvar feedback") { state.feedbackSaved = true; state.selectedScreen = Screen.DASHBOARD }
    }
}

@Composable private fun FeedbackGroup(title: String, options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Text(title, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)); Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) { options.forEach { o -> Box(Modifier.clip(RoundedCornerShape(18.dp)).background(if (o == selected) Blue else CardBlue).clickable { onSelect(o) }.padding(horizontal = 13.dp, vertical = 9.dp)) { Text(o, fontSize = 11.sp) } } }
}

@Composable private fun HistoryScreen(state: CoachState) {
    LazyColumnLike { Header("Histórico de treinos"); state.workouts.forEach { w -> WorkoutCard(w) { state.selectedScreen = Screen.FEEDBACK } }; ListButton("Ver mais resultados") {} }
}

@Composable private fun ProfileScreen(state: CoachState) {
    LazyColumnLike {
        Header("Perfil / Configurações", true) { state.selectedScreen = Screen.DASHBOARD }
        CardBlock(state.name, state.level, "Objetivo: ${state.goal}")
        ListButton("Dados pessoais") {}
        ListButton("Objetivos") {}
        ListButton("Disponibilidade") {}
        ListButton("Preferências") {}
        ListButton("Conexão com Pace Coach") { state.selectedScreen = Screen.EXPORT }
        ListButton("Notificações") {}
        ListButton("Privacidade") {}
        ListButton("Ajuda e suporte") {}
    }
}

@Composable private fun ExportScreen(state: CoachState) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("Exportar para Pace Coach", true) { state.selectedScreen = Screen.WORKOUT }
        BigRunnerMark()
        Text("Enviar treino para o Pace Coach", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterHorizontally))
        Spacer(Modifier.height(20.dp))
        StepExport("1", "Selecione o treino", "Intervalado — 17/04/2026")
        StepExport("2", "Revise os dados", "Estrutura • Ritmos • Repetições • Recuperação")
        StepExport("3", "Enviar para o Pace Coach", "A prescrição será transferida para execução no Pace Coach.")
        PrimaryButton("Exportar agora") { state.selectedScreen = Screen.DASHBOARD }
    }
}

@Composable
private fun StepExport(n: String, title: String, desc: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp, 6.dp),
        colors = CardDefaults.cardColors(containerColor = CardBlue)
    ) {
        Row(Modifier.padding(16.dp)) {
            Text(
                text = n,
                modifier = Modifier.width(34.dp),
                color = Blue,
                fontSize = 24.sp,
                fontWeight = FontWeight.Black
            )
            Column {
                Text(text = title, fontWeight = FontWeight.Bold)
                Text(
                    text = desc,
                    color = TextMuted,
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable private fun BottomNav(state: CoachState) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(72.dp)
            .background(Color(0xFF071522)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        NavItem(Modifier.weight(1f), "⌂", "Início", state.selectedScreen == Screen.DASHBOARD) { state.selectedScreen = Screen.DASHBOARD }
        NavItem(Modifier.weight(1f), "▦", "Calendário", state.selectedScreen == Screen.CALENDAR) { state.selectedScreen = Screen.CALENDAR }
        NavItem(Modifier.weight(1f), "☷", "Plano", state.selectedScreen == Screen.PLAN) { state.selectedScreen = Screen.PLAN }
        NavItem(Modifier.weight(1f), "↗", "Evolução", state.selectedScreen == Screen.EVOLUTION) { state.selectedScreen = Screen.EVOLUTION }
        NavItem(Modifier.weight(1f), "⋯", "Mais", state.selectedScreen == Screen.PROFILE) { state.selectedScreen = Screen.PROFILE }
    }
}

@Composable private fun NavItem(modifier: Modifier, icon: String, label: String, selected: Boolean, onClick: () -> Unit) {
    Column(
        modifier = modifier
            .fillMaxHeight()
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = icon,
            fontSize = 20.sp,
            color = if (selected) Blue else TextMuted
        )
        Text(
            text = label,
            fontSize = 9.sp,
            color = if (selected) Blue else TextMuted,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

@Composable private fun PrimaryButton(text: String, onClick: () -> Unit) { Button(onClick = onClick, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(52.dp), shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.buttonColors(containerColor = Blue)) { Text(text, fontWeight = FontWeight.Bold) } }

@Composable private fun LazyColumnLike(content: @Composable ColumnScope.() -> Unit) { Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), content = content) }
