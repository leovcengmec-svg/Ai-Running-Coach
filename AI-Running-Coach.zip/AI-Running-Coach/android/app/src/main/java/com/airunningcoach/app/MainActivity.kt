package com.airunningcoach.app

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.util.Locale

private val Navy = Color(0xFF0A1220)
private val Navy2 = Color(0xFF111D2D)
private val CardBlue = Color(0xFF1A2B40)
private val Blue = Color(0xFF8EAEF5)
private val Blue2 = Color(0xFFC1D0FF)
private val TextWhite = Color(0xFFF4F6FC)
private val TextMuted = Color(0xFFA3B0C3)
private val Green = Color(0xFF7AD6B7)
private val Yellow = Color(0xFFF4C77B)

private enum class Screen { DASHBOARD, CALENDAR, WORKOUT, STRUCTURE, PLAN, EVOLUTION, FEEDBACK, HISTORY, PROFILE, EXPORT }

private data class Workout(
    val date: String,
    val scheduledDateIso: String = "",
    val title: String,
    val detail: String,
    val type: String,
    val objective: String,
    val stimulus: String,
    val distanceKm: Double,
    val done: Boolean = false,
    val sessionId: String = "",
    val durationMin: Int = 0,
    val intensity: String = "LOW",
    val paceMode: String = "PACE_NOT_CALIBRATED",
    val rpeRange: String = "3-4",
    val rationale: String = "",
    val week: Int = 1,
    val phase: String = "BASE",
    val segments: List<WorkoutSegment> = emptyList()
)

private data class FeedbackRecord(
    val sessionId: String,
    val effort: String,
    val feeling: String,
    val notes: String,
    val painPresent: Boolean = false,
    val actualDistanceKm: Double? = null,
    val savedAt: Long = System.currentTimeMillis()
)

private class CoachState(private val context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("ai_running_coach", Context.MODE_PRIVATE)

    var name by mutableStateOf("Leonardo")
    var goal by mutableStateOf("")
    var customGoalKm by mutableStateOf("")
    var level by mutableStateOf("")
    var frequency by mutableStateOf(0)
    var targetDate by mutableStateOf("Sem data definida")
    var volume by mutableStateOf("") // legado V18; mantido apenas para migração local
    var weeklyVolumeText by mutableStateOf("")
    var longestRecent by mutableStateOf("")
    var benchmarkEnabled by mutableStateOf(false)
    var benchmarkDistanceText by mutableStateOf("5")
    var benchmarkTimeText by mutableStateOf("")
    var onboardingStep by mutableStateOf(-1)
    var selectedScreen by mutableStateOf(Screen.DASHBOARD)
    var selectedWorkoutIndex by mutableStateOf(0)
    var feedbackSaved by mutableStateOf(false)
    var workouts by mutableStateOf(listOf<Workout>())
    var planWeeks by mutableStateOf(8)
    var motorState by mutableStateOf<MotorState?>(null)
    var motorDecision by mutableStateOf<MotorDecision?>(null)
    var motorExplanation by mutableStateOf("")
    var motorError by mutableStateOf("")
    var needsEngineRefresh by mutableStateOf(false)
    var feedbackRecords by mutableStateOf(listOf<FeedbackRecord>())
    var latestFeedbackHeadline by mutableStateOf("")
    var latestFeedbackAdvice by mutableStateOf("")

    init { load() }

    fun createPlan(): Boolean {
        motorError = ""
        if (goal.isBlank() || level.isBlank() || frequency !in 2..6 || weeklyVolumeText.isBlank() || longestRecent.isBlank()) {
            motorError = "Complete todas as escolhas antes de criar o plano."
            persist()
            return false
        }

        val goalKm = when {
            goal.startsWith("5") -> 5.0
            goal.startsWith("10") -> 10.0
            goal.startsWith("Meia") -> 21.1
            goal.startsWith("Maratona") -> 42.2
            goal.startsWith("Saúde") -> 5.0
            goal == "Outro objetivo" -> customGoalKm.trim().replace(",", ".").toDoubleOrNull()
                ?.takeIf { it in 1.0..100.0 }
            else -> null
        }
        if (goalKm == null) {
            motorError = "Informe uma distância válida entre 1 e 100 km para o objetivo personalizado."
            persist()
            return false
        }
        val recentKm = longestRecent.trim().replace(",", ".").toDoubleOrNull()
        // A V19 exige a média real das últimas quatro semanas; não converte mais faixas em números arbitrários.
        val weeklyKm = weeklyVolumeText.trim().replace(",", ".").toDoubleOrNull()
        if (weeklyKm == null || weeklyKm !in 0.0..150.0) {
            motorError = "Informe a média semanal real entre 0 e 150 km, considerando as últimas quatro semanas."
            persist()
            return false
        }
        if (recentKm == null || recentKm !in 0.0..60.0) {
            motorError = "Informe o maior treino recente entre 0 e 60 km."
            persist()
            return false
        }
        val benchmarkDistance = if (benchmarkEnabled) benchmarkDistanceText.toDoubleOrNull() else null
        val benchmarkSeconds = if (benchmarkEnabled) PaceCalculator.parseMmSs(benchmarkTimeText) else null
        if (benchmarkEnabled && (benchmarkDistance == null || benchmarkSeconds == null || PaceCalculator.calculate(benchmarkDistance, benchmarkSeconds) == null)) {
            motorError = "Confira a distância (3, 5 ou 10 km) e o tempo total. O resultado precisa permitir uma estimativa de pace válida."
            persist()
            return false
        }

        return try {
            val input = RunnerInput(
                goalKm = goalKm,
                level = level,
                frequency = frequency,
                weeklyVolumeKm = weeklyKm,
                longestRecentKm = recentKm,
                painPresent = feedbackRecords.takeLast(3).any { it.painPresent },
                recoveryScore = deriveRecoveryScore(),
                fatigueScore = deriveFatigueScore(),
                planWeeks = 8,
                benchmarkDistanceKm = benchmarkDistance,
                benchmarkTimeSeconds = benchmarkSeconds,
                startDate = RunningCoachEngine.nextMonday(LocalDate.now())
            )
            val plan = RunningCoachEngine.generate(input)
            motorState = plan.state
            motorDecision = plan.decision
            motorExplanation = plan.explanation
            if (plan.decision.safety == "RED") {
                // Preserve the previous cycle so the athlete can review/update the pain feedback
                // after recovery; a blocked generation must not erase the only way to do that.
                motorError = "Nova prescrição bloqueada por relato de dor. O plano anterior foi preservado; atualize o feedback somente quando estiver sem dor."
                onboardingStep = 8
                selectedScreen = Screen.DASHBOARD
                persist()
                return false
            }
            if (plan.workouts.isEmpty()) {
                motorError = "O motor terminou sem gerar sessões."
                persist()
                return false
            }
            workouts = plan.workouts.map { p ->
                Workout(
                    date = p.date, scheduledDateIso = p.scheduledDateIso, title = p.title, detail = p.detail, type = p.type,
                    objective = p.objective, stimulus = p.stimulus, distanceKm = p.distanceKm,
                    sessionId = p.sessionId, durationMin = p.durationMin, intensity = p.intensity,
                    paceMode = p.paceMode, rpeRange = p.rpeRange, rationale = p.rationale,
                    week = p.week, phase = p.phase, segments = p.segments
                )
            }
            motorError = ""
            planWeeks = plan.weeklySummaries.size.coerceAtLeast(4)
            needsEngineRefresh = false
            prefs.edit().putInt("engineVersion", 21).apply()
            selectedWorkoutIndex = 0
            selectedScreen = Screen.DASHBOARD
            onboardingStep = 8
            persist()
            true
        } catch (e: Exception) {
            motorError = "Erro ao executar o motor: ${e.message ?: "erro desconhecido"}"
            persist()
            false
        }
    }

    fun selectedWorkout(): Workout? = workouts.getOrNull(selectedWorkoutIndex)

    fun completedWorkouts(): List<Workout> = workouts.filter { it.done }

    fun saveFeedback(effort: String, feeling: String, notes: String, painPresent: Boolean, actualDistanceText: String) {
        val current = selectedWorkout() ?: return
        val actualDistanceKm = actualDistanceText.trim().replace(",", ".").toDoubleOrNull()?.takeIf { it > 0.0 && it <= 200.0 }
        workouts = workouts.mapIndexed { index, workout ->
            if (index == selectedWorkoutIndex) workout.copy(done = true) else workout
        }
        feedbackRecords = feedbackRecords.filterNot { it.sessionId == current.sessionId } + FeedbackRecord(
            sessionId = current.sessionId, effort = effort, feeling = feeling, notes = notes, painPresent = painPresent, actualDistanceKm = actualDistanceKm
        )
        val analysis = TrainingAdaptationEngine.analyzeRun(
            TrainingAdaptationEngine.RunResult(
                distanceKm = actualDistanceKm,
                plannedDistanceKm = current.distanceKm,
                perceivedEffort = effort,
                feeling = feeling,
                plannedWorkoutType = current.type,
                painReported = painPresent
            )
        )
        latestFeedbackHeadline = analysis.headline
        latestFeedbackAdvice = analysis.nextStep
        feedbackSaved = true
        persist()
    }

    private fun deriveRecoveryScore(): Double? {
        val recent = feedbackRecords.takeLast(3)
        if (recent.isEmpty()) return null
        val tired = recent.count { it.feeling == "Cansado" || it.feeling == "Muito cansado" }
        val heavy = recent.count { it.effort == "Pesado" || it.effort == "Muito pesado" }
        return when {
            recent.any { it.painPresent } -> 10.0
            tired >= 2 || heavy >= 2 -> 35.0
            tired + heavy >= 1 -> 60.0
            else -> 80.0
        }
    }

    private fun deriveFatigueScore(): Double? {
        val recent = feedbackRecords.takeLast(3)
        if (recent.isEmpty()) return null
        val tired = recent.count { it.feeling == "Cansado" || it.feeling == "Muito cansado" }
        val heavy = recent.count { it.effort == "Pesado" || it.effort == "Muito pesado" }
        return when {
            recent.any { it.painPresent } -> 95.0
            tired >= 2 || heavy >= 2 -> 80.0
            tired + heavy >= 1 -> 65.0
            else -> 30.0
        }
    }

    fun selectWorkout(workout: Workout) {
        val index = workouts.indexOf(workout)
        if (index >= 0) selectedWorkoutIndex = index
        selectedScreen = Screen.WORKOUT
        persist()
    }

    fun persist() {
        val e = prefs.edit()
            .putString("name", name)
            .putString("goal", goal)
            .putString("customGoalKm", customGoalKm)
            .putString("level", level)
            .putInt("frequency", frequency)
            .putString("targetDate", targetDate)
            .putString("volume", volume)
            .putString("weeklyVolumeText", weeklyVolumeText)
            .putString("longestRecent", longestRecent)
            .putBoolean("benchmarkEnabled", benchmarkEnabled)
            .putString("benchmarkDistanceText", benchmarkDistanceText)
            .putString("benchmarkTimeText", benchmarkTimeText)
            .putInt("onboardingStep", onboardingStep)
            .putInt("selectedScreen", selectedScreen.ordinal)
            .putInt("selectedWorkoutIndex", selectedWorkoutIndex)
            .putInt("planWeeks", planWeeks)
            .putString("latestFeedbackHeadline", latestFeedbackHeadline)
            .putString("latestFeedbackAdvice", latestFeedbackAdvice)
            .putString("motorExplanation", motorExplanation)
            .putString("motorError", motorError)

        motorState?.let { ms ->
            e.putString("motorState", JSONObject().apply {
                put("fitnessConfidence", ms.fitnessConfidence)
                put("paceConfidence", ms.paceConfidence)
                put("recentVolumeKm", ms.recentVolumeKm)
                put("recentLongRunKm", ms.recentLongRunKm)
                put("recoveryStatus", ms.recoveryStatus)
                put("safetyStatus", ms.safetyStatus)
                put("phase", ms.phase)
                put("flags", JSONArray(ms.flags))
            }.toString())
        }
        motorDecision?.let { md ->
            e.putString("motorDecision", JSONObject().apply {
                put("action", md.action)
                put("necessity", md.necessity)
                put("stimulus", md.stimulus)
                put("rationale", md.rationale)
                put("confidence", md.confidence)
                put("safety", md.safety)
            }.toString())
        }
        val arr = JSONArray()
        workouts.forEach { w ->
            arr.put(JSONObject().apply {
                put("date", w.date); put("scheduledDateIso", w.scheduledDateIso); put("title", w.title); put("detail", w.detail)
                put("type", w.type); put("objective", w.objective); put("stimulus", w.stimulus)
                put("distanceKm", w.distanceKm); put("done", w.done); put("sessionId", w.sessionId)
                put("durationMin", w.durationMin); put("intensity", w.intensity); put("paceMode", w.paceMode)
                put("rpeRange", w.rpeRange); put("rationale", w.rationale); put("week", w.week)
                put("phase", w.phase)
                put("segments", JSONArray().apply {
                    w.segments.forEach { segment -> put(JSONObject().apply {
                        put("name", segment.name); put("instruction", segment.instruction)
                        if (segment.durationMin != null) put("durationMin", segment.durationMin)
                        if (segment.distanceKm != null) put("distanceKm", segment.distanceKm)
                        put("intensity", segment.intensity); put("rpeRange", segment.rpeRange)
                        put("repeatCount", segment.repeatCount); put("targetMode", segment.targetMode)
                        segment.targetPaceMinSecPerKm?.let { put("targetPaceMinSecPerKm", it) }
                        segment.targetPaceMaxSecPerKm?.let { put("targetPaceMaxSecPerKm", it) }
                    }) }
                })
            })
        }
        val feedbackArray = JSONArray()
        feedbackRecords.forEach { feedback -> feedbackArray.put(JSONObject().apply {
            put("sessionId", feedback.sessionId); put("effort", feedback.effort)
            put("feeling", feedback.feeling); put("notes", feedback.notes); put("painPresent", feedback.painPresent)
            feedback.actualDistanceKm?.let { put("actualDistanceKm", it) }; put("savedAt", feedback.savedAt)
        }) }
        e.putString("feedbackRecords", feedbackArray.toString())
        e.putString("workouts", arr.toString()).apply()
    }

    private fun load() {
        name = prefs.getString("name", "Leonardo") ?: "Leonardo"
        goal = prefs.getString("goal", "") ?: ""
        customGoalKm = prefs.getString("customGoalKm", "") ?: ""
        level = prefs.getString("level", "") ?: ""
        frequency = prefs.getInt("frequency", 0)
        targetDate = prefs.getString("targetDate", "Sem data definida") ?: "Sem data definida"
        volume = prefs.getString("volume", "") ?: ""
        weeklyVolumeText = prefs.getString("weeklyVolumeText", "") ?: ""
        longestRecent = prefs.getString("longestRecent", "") ?: ""
        benchmarkEnabled = prefs.getBoolean("benchmarkEnabled", false)
        benchmarkDistanceText = prefs.getString("benchmarkDistanceText", "5") ?: "5"
        benchmarkTimeText = prefs.getString("benchmarkTimeText", "") ?: ""
        // Migra opções antigas (ex.: "5 km" e "Mais de 10 km") para valor editável.
        longestRecent = when {
            longestRecent.startsWith("Mais", ignoreCase = true) -> "" // faixa aberta não é distância medida; exige revisão manual
            longestRecent.contains("km", ignoreCase = true) -> longestRecent.substringBefore(" ").trim()
            else -> longestRecent
        }
        onboardingStep = prefs.getInt("onboardingStep", if (goal.isBlank()) -1 else 6)
        selectedWorkoutIndex = prefs.getInt("selectedWorkoutIndex", 0)
        planWeeks = prefs.getInt("planWeeks", 8)
        needsEngineRefresh = prefs.getInt("engineVersion", 0) < 21 && prefs.getString("workouts", null) != null
        motorExplanation = prefs.getString("motorExplanation", "") ?: ""
        latestFeedbackHeadline = prefs.getString("latestFeedbackHeadline", "") ?: ""
        latestFeedbackAdvice = prefs.getString("latestFeedbackAdvice", "") ?: ""
        motorError = prefs.getString("motorError", "") ?: ""
        selectedScreen = Screen.entries.getOrNull(prefs.getInt("selectedScreen", Screen.DASHBOARD.ordinal)) ?: Screen.DASHBOARD

        prefs.getString("motorState", null)?.let { raw -> runCatching {
            val o = JSONObject(raw)
            motorState = MotorState(
                fitnessConfidence = o.optString("fitnessConfidence"),
                paceConfidence = o.optString("paceConfidence"),
                recentVolumeKm = o.optDouble("recentVolumeKm"),
                recentLongRunKm = o.optDouble("recentLongRunKm"),
                recoveryStatus = o.optString("recoveryStatus"),
                safetyStatus = o.optString("safetyStatus"),
                phase = o.optString("phase"),
                flags = buildList { val a=o.optJSONArray("flags"); if (a != null) for (i in 0 until a.length()) add(a.optString(i)) }
            )
        }}
        prefs.getString("motorDecision", null)?.let { raw -> runCatching {
            val o = JSONObject(raw)
            motorDecision = MotorDecision(
                action = o.optString("action"), necessity = o.optString("necessity"), stimulus = o.optString("stimulus"),
                rationale = o.optString("rationale"), confidence = o.optDouble("confidence"), safety = o.optString("safety")
            )
        }}
        prefs.getString("workouts", null)?.let { raw -> runCatching {
            val a = JSONArray(raw)
            workouts = buildList {
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    add(Workout(
                        date=o.optString("date"), scheduledDateIso=o.optString("scheduledDateIso"), title=o.optString("title"), detail=o.optString("detail"), type=o.optString("type"),
                        objective=o.optString("objective"), stimulus=o.optString("stimulus"), distanceKm=o.optDouble("distanceKm"),
                        done=o.optBoolean("done"), sessionId=o.optString("sessionId"), durationMin=o.optInt("durationMin"),
                        intensity=o.optString("intensity", "LOW"), paceMode=o.optString("paceMode", "PACE_NOT_CALIBRATED"),
                        rpeRange=o.optString("rpeRange", "3-4"), rationale=o.optString("rationale"),
                        week=o.optInt("week",1), phase=o.optString("phase", "BASE"),
                        segments=buildList {
                            val segmentArray = o.optJSONArray("segments")
                            if (segmentArray != null) for (j in 0 until segmentArray.length()) {
                                val item = segmentArray.optJSONObject(j) ?: continue
                                add(WorkoutSegment(
                                    name=item.optString("name"), instruction=item.optString("instruction"),
                                    durationMin=if (item.has("durationMin")) item.optInt("durationMin") else null,
                                    distanceKm=if (item.has("distanceKm")) item.optDouble("distanceKm") else null,
                                    intensity=item.optString("intensity", "LOW"), rpeRange=item.optString("rpeRange", "2-3"),
                                    repeatCount=item.optInt("repeatCount", 1),
                                    targetMode=item.optString("targetMode", if (item.has("durationMin")) "TIME" else "DISTANCE"),
                                    targetPaceMinSecPerKm=if (item.has("targetPaceMinSecPerKm")) item.optInt("targetPaceMinSecPerKm") else null,
                                    targetPaceMaxSecPerKm=if (item.has("targetPaceMaxSecPerKm")) item.optInt("targetPaceMaxSecPerKm") else null
                                ))
                            }
                        }
                    ))
                }
            }
        }}

        prefs.getString("feedbackRecords", null)?.let { raw -> runCatching {
            val a = JSONArray(raw)
            feedbackRecords = buildList {
                for (i in 0 until a.length()) {
                    val item = a.optJSONObject(i) ?: continue
                    add(FeedbackRecord(
                        sessionId = item.optString("sessionId"), effort = item.optString("effort"),
                        feeling = item.optString("feeling"), notes = item.optString("notes"),
                        painPresent = item.optBoolean("painPresent", false),
                        actualDistanceKm = if (item.has("actualDistanceKm")) item.optDouble("actualDistanceKm") else null,
                        savedAt = item.optLong("savedAt", 0L)
                    ))
                }
            }
        } }
        feedbackSaved = feedbackRecords.isNotEmpty()

        // Se o perfil legado não tem volume numérico, leva diretamente à revisão do dado obrigatório.
        if (goal.isNotBlank() && weeklyVolumeText.isBlank() && workouts.isEmpty()) onboardingStep = 4
        // Um plano antigo permanece acessível; o painel pede revisão antes da nova geração.
        if (goal.isNotBlank() && workouts.isNotEmpty()) onboardingStep = 8
    }
}
private val AppColors = darkColorScheme(
    primary = Blue,
    onPrimary = Color(0xFF101827),
    secondary = Green,
    onSecondary = Color(0xFF0D201B),
    tertiary = Yellow,
    background = Navy,
    surface = Navy2,
    surfaceVariant = CardBlue,
    onBackground = TextWhite,
    onSurface = TextWhite,
    onSurfaceVariant = TextMuted
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RunningCoachApp() }
    }
}

@Composable
private fun RunningCoachApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val state = remember(context) { CoachState(context.applicationContext) }
    MaterialTheme(colorScheme = AppColors) {
        Surface(Modifier.fillMaxSize(), color = Navy) {
            if (state.onboardingStep in -1..7) Onboarding(state) else MainShell(state)
        }
    }
}

@Composable
private fun Onboarding(state: CoachState) {
    val step = state.onboardingStep
    Column(
        Modifier.fillMaxSize().background(Navy).verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(22.dp))
        Text("AI", color = Blue, fontSize = 38.sp, fontWeight = FontWeight.Black)
        Text("RUNNING COACH", color = TextWhite, fontSize = 25.sp, fontWeight = FontWeight.Black)
        Text("PRESCREVE HOJE, EVOLUI SEMPRE", color = Blue2, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))
        StepBar(step)
        Spacer(Modifier.height(28.dp))
        when (step) {
            -1 -> {
                BigRunnerMark()
                Text("Seu plano. Sua evolução.", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("Prescrição inteligente de treinos de corrida. Sem execução de treino neste app.", color = TextMuted, textAlign = TextAlign.Center, modifier = Modifier.padding(12.dp))
            }
            0 -> {
                Text("Vamos começar", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("Em alguns passos vamos criar seu perfil e seu primeiro plano de corrida.", color = TextMuted, textAlign = TextAlign.Center, modifier = Modifier.padding(12.dp))
            }
            1 -> {
                ChoiceScreen("Qual é o seu objetivo?", listOf("5 km", "10 km", "Meia Maratona (21 km)", "Maratona (42 km)", "Saúde e qualidade de vida", "Outro objetivo"), state.goal) { state.goal = it; state.persist() }
                if (state.goal == "Outro objetivo") {
                    OutlinedTextField(
                        value = state.customGoalKm,
                        onValueChange = { state.customGoalKm = it.filter { ch -> ch.isDigit() || ch == ',' || ch == '.' }; state.persist() },
                        label = { Text("Distância do objetivo em km") },
                        modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color(0xFF35536A))
                    )
                }
            }
            2 -> ChoiceScreen("Qual é o seu nível de experiência?", listOf("Iniciante", "Intermediário", "Avançado", "Elite"), state.level) { state.level = it; state.persist() }
            3 -> ChoiceScreen("Quantos dias por semana você pode treinar?", listOf("2", "3", "4", "5", "6"), if (state.frequency == 0) "" else state.frequency.toString()) { state.frequency = it.toInt(); state.persist() }
            4 -> {
                Text("Quanto você correu por semana?", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Informe a média REAL das últimas quatro semanas. Não escolha uma faixa: esse número determina o ponto de partida do seu plano.", color = TextMuted, fontSize = 13.sp)
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = state.weeklyVolumeText,
                    onValueChange = { state.weeklyVolumeText = it.filter { ch -> ch.isDigit() || ch == ',' || ch == '.' }; state.persist() },
                    label = { Text("Média semanal em km") },
                    supportingText = { Text("Exemplo: se correu 18, 20, 22 e 20 km, informe 20 km.") },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color(0xFF35536A))
                )
                Spacer(Modifier.height(8.dp))
                Text("Sem corrida nas últimas quatro semanas? Informe 0. O motor criará uma reintrodução leve, mesmo que seu nível de experiência seja intermediário ou avançado.", color = TextMuted, fontSize = 12.sp)
            }
            5 -> {
                Text("Qual foi sua maior corrida recente?", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Informe a distância da maior sessão contínua que você realizou nas últimas quatro semanas. Isso limita o tamanho inicial do longão e das outras sessões.", color = TextMuted, fontSize = 13.sp)
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = state.longestRecent,
                    onValueChange = { state.longestRecent = it.filter { ch -> ch.isDigit() || ch == ',' || ch == '.' }; state.persist() },
                    label = { Text("Maior distância recente em km") },
                    supportingText = { Text("Exemplo: informe 8,5 para uma corrida de 8,5 km.") },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color(0xFF35536A))
                )
                Spacer(Modifier.height(8.dp))
                Text("Se não correu nas últimas quatro semanas, informe 0. Não use a distância de uma prova antiga como histórico recente.", color = TextMuted, fontSize = 12.sp)
            }
            6 -> {
                Text("Calibrar seu pace", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Informe um resultado recente, feito em esforço forte e contínuo. O treinador estima faixas iniciais de ritmo por quilômetro a partir dele.", color = TextMuted, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = CardBlue)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Tenho um resultado recente", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("Preferencialmente dos últimos 3 meses", color = TextMuted, fontSize = 11.sp)
                            }
                            Switch(checked = state.benchmarkEnabled, onCheckedChange = { state.benchmarkEnabled = it; state.persist() })
                        }
                        if (state.benchmarkEnabled) {
                            ChoiceScreen("Distância do teste", listOf("3", "5", "10"), state.benchmarkDistanceText) {
                                state.benchmarkDistanceText = it; state.persist()
                            }
                            OutlinedTextField(
                                value = state.benchmarkTimeText,
                                onValueChange = { value ->
                                    state.benchmarkTimeText = value.filter { ch -> ch.isDigit() || ch == ':' }.take(6)
                                    state.persist()
                                },
                                label = { Text("Tempo total (mm:ss)") },
                                supportingText = { Text("Exemplo: 5 km em 25:30; aceita mm:ss até 180:00") },
                                modifier = Modifier.fillMaxWidth(), singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color(0xFF35536A))
                            )
                            val parsed = PaceCalculator.parseMmSs(state.benchmarkTimeText)
                            if (parsed != null) {
                                val zones = PaceCalculator.calculate(state.benchmarkDistanceText.toDoubleOrNull(), parsed)
                                if (zones != null) {
                                    Text("Pace aeróbio estimado: ${zones.easy.label()}", color = Green, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                } else {
                                    Text("Não foi possível estimar o pace com esses dados. Confira a distância e o tempo do resultado.", color = Color(0xFFFFB77A), fontSize = 11.sp)
                                }
                            }
                        } else {
                            Text("Sem um teste recente, não vamos inventar velocidade. O plano será enviado por distância ou tempo, sem pace fixo, até você registrar uma referência.", color = TextMuted, fontSize = 12.sp, lineHeight = 18.sp)
                        }
                    }
                }
                Text("O RPE continuará como orientação complementar para dias de calor, subida ou fadiga; ele não será o alvo principal enviado ao Pace Coach.", color = TextMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            }
            7 -> {
                Text("Resumo do seu perfil", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = CardBlue)) {
                    Column(Modifier.padding(18.dp)) {
                        InfoRow("Nome", state.name)
                        InfoRow("Nível", state.level)
                        InfoRow("Objetivo", if (state.goal == "Outro objetivo") "${state.customGoalKm} km" else state.goal)
                        InfoRow("Data-alvo", state.targetDate)
                        InfoRow("Frequência", "${state.frequency} dias por semana")
                        InfoRow("Volume médio nas últimas 4 semanas", if (state.weeklyVolumeText.isBlank()) "Precisa ser informado" else "${state.weeklyVolumeText} km/semana")
                        InfoRow("Maior treino recente", "${state.longestRecent} km")
                        InfoRow("Referência de pace", if (state.benchmarkEnabled) "${state.benchmarkDistanceText} km em ${state.benchmarkTimeText}" else "Ainda não informada")
                    }
                }
            }
        }
        Spacer(Modifier.height(26.dp))
        val canContinue = when (step) {
            1 -> state.goal.isNotBlank()
            2 -> state.level.isNotBlank()
            3 -> state.frequency in 2..6
            4 -> state.weeklyVolumeText.trim().replace(",", ".").toDoubleOrNull()?.let { it in 0.0..150.0 } == true
            5 -> state.longestRecent.trim().replace(",", ".").toDoubleOrNull()?.let { it in 0.0..60.0 } == true
            6 -> !state.benchmarkEnabled || run {
                val distance = state.benchmarkDistanceText.toDoubleOrNull()
                val seconds = PaceCalculator.parseMmSs(state.benchmarkTimeText)
                PaceCalculator.calculate(distance, seconds) != null
            }
            7 -> state.goal.isNotBlank() && state.level.isNotBlank() && state.frequency in 2..6 && state.weeklyVolumeText.trim().replace(",", ".").toDoubleOrNull()?.let { it in 0.0..150.0 } == true && state.longestRecent.trim().replace(",", ".").toDoubleOrNull()?.let { it in 0.0..60.0 } == true && (state.goal != "Outro objetivo" || state.customGoalKm.trim().replace(",", ".").toDoubleOrNull()?.let { it in 1.0..100.0 } == true)
            else -> true
        }
        PrimaryButton(if (step == 7) "Criar meu plano" else if (step <= 0) "Começar" else "Continuar", enabled = canContinue) {
            if (step == 7) state.createPlan() else { state.onboardingStep++; state.persist() }
        }
        if (state.motorError.isNotBlank()) {
            Text(state.motorError, color = Color(0xFFFF8A8A), fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
        }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable private fun StepBar(step: Int) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        repeat(8) { index ->
            Box(
                Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(50))
                    .background(if (index <= step) Blue else Color(0xFF293A52))
            )
        }
    }
}

@Composable private fun BigRunnerMark() {
    Box(
        Modifier.size(142.dp).clip(RoundedCornerShape(42.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF344E7B), Color(0xFF193B53)))),
        contentAlignment = Alignment.Center
    ) {
        Text("↗", color = Color(0xFFD9E4FF), fontSize = 76.sp, fontWeight = FontWeight.Black)
    }
}

@Composable private fun ChoiceScreen(title: String, options: List<String>, current: String, selected: (String) -> Unit) {
    Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
    Spacer(Modifier.height(14.dp))
    options.forEach { option ->
        val isSelected = option == current
        Card(
            Modifier
                .fillMaxWidth()
                .padding(vertical = 5.dp)
                .then(if (isSelected) Modifier.border(2.dp, Blue, RoundedCornerShape(12.dp)) else Modifier)
                .clickable { selected(option) },
            colors = CardDefaults.cardColors(containerColor = if (isSelected) Color(0xFF174968) else CardBlue),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(22.dp).border(2.dp, if (isSelected) Blue2 else TextMuted, RoundedCornerShape(50)),
                    contentAlignment = Alignment.Center
                ) {
                    if (isSelected) Box(Modifier.size(11.dp).clip(RoundedCornerShape(50)).background(Blue2))
                }
                Spacer(Modifier.width(12.dp))
                Text(option, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold)
            }
        }
    }
}

@Composable private fun MainShell(state: CoachState) {
    Scaffold(
        containerColor = Navy,
        bottomBar = { BottomNav(state) }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (state.selectedScreen) {
                Screen.DASHBOARD -> Dashboard(state)
                Screen.CALENDAR -> CalendarScreen(state)
                Screen.WORKOUT -> WorkoutDetail(state)
                Screen.STRUCTURE -> StructureScreen(state)
                Screen.PLAN -> PlanScreen(state)
                Screen.EVOLUTION -> EvolutionScreen(state)
                Screen.FEEDBACK -> FeedbackScreen(state)
                Screen.HISTORY -> HistoryScreen(state)
                Screen.PROFILE -> ProfileScreen(state)
                Screen.EXPORT -> ExportScreen(state)
            }
        }
    }
}

@Composable private fun Header(title: String, back: Boolean = false, onBack: () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (back) {
            Surface(
                modifier = Modifier.size(42.dp).clickable(onClick = onBack),
                shape = RoundedCornerShape(15.dp),
                color = Navy2
            ) { Box(contentAlignment = Alignment.Center) { Text("‹", fontSize = 30.sp, color = Blue2) } }
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("AI RUNNING COACH", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Text(title, fontSize = 23.sp, fontWeight = FontWeight.Bold, color = TextWhite)
        }
    }
}

@Composable private fun Dashboard(state: CoachState) {
    val firstWeekSessions = state.workouts.filter { it.week == 1 }
    val firstWeekKm = firstWeekSessions.sumOf { it.distanceKm }
    val nextWorkout = state.workouts.firstOrNull { !it.done }
    val actualDistance = state.feedbackRecords.mapNotNull { it.actualDistanceKm }.sum()
    val weeklyReference = state.weeklyVolumeText.trim().replace(",", ".").toDoubleOrNull()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 22.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(start = 22.dp, end = 18.dp, top = 18.dp, bottom = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("TRAINING HUB", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.8.sp)
                Text("Olá, ${state.name}!", color = TextWhite, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text("Seu treinamento, em um só lugar.", color = TextMuted, fontSize = 13.sp)
            }
            Surface(shape = RoundedCornerShape(18.dp), color = CardBlue, modifier = Modifier.size(48.dp)) {
                Box(contentAlignment = Alignment.Center) { Text(state.name.take(1).uppercase(), color = Blue2, fontWeight = FontWeight.Bold, fontSize = 20.sp) }
            }
        }

        Surface(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            shape = RoundedCornerShape(28.dp),
            color = Color.Transparent
        ) {
            Column(
                Modifier.background(Brush.linearGradient(listOf(Color(0xFF263D62), Color(0xFF172B46), Color(0xFF183B50)))).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("SEU CICLO ATUAL", color = Color(0xFFCEDAFF), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                        Text("Plano de ${state.planWeeks} semanas", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    }
                    Surface(shape = RoundedCornerShape(50), color = Color(0x333FCEB7)) {
                        Text(if (state.workouts.isNotEmpty()) "ATIVO" else "PENDENTE", color = Color(0xFF9AF0D5), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp))
                    }
                }
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text(formatKmUi(firstWeekKm), fontSize = 38.sp, fontWeight = FontWeight.Black, color = Color.White)
                        Text("km estimados na semana 1", fontSize = 12.sp, color = Color(0xFFD0D9EA))
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("${firstWeekSessions.size}", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("sessões", fontSize = 12.sp, color = Color(0xFFD0D9EA))
                    }
                }
                ProgressTrack(progress = if (weeklyReference != null && weeklyReference > 0.0) (firstWeekKm / weeklyReference).toFloat().coerceIn(0f, 1f) else 0f, color = Color(0xFF9BE2D0), trackColor = Color(0x55FFFFFF))
                Text(
                    text = if (state.weeklyVolumeText.isNotBlank()) "Base informada: ${state.weeklyVolumeText} km/semana" else "Informe sua base recente para personalizar a carga",
                    color = Color(0xFFD0D9EA), fontSize = 11.sp
                )
            }
        }

        SectionHeading("Indicadores do atleta", "Dados do perfil")
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricPod("Volume de referência", state.weeklyVolumeText.takeIf { it.isNotBlank() }?.let { "$it km" } ?: "Não informado", "↗", Blue2, Modifier.weight(1f), "Média das últimas 4 semanas")
            MetricPod("Maior sessão", state.longestRecent.takeIf { it.isNotBlank() }?.let { "$it km" } ?: "Não informada", "◷", Color(0xFFFFD18A), Modifier.weight(1f), "Distância contínua recente")
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricPod("Recuperação", recoveryLabel(state.motorState?.recoveryStatus), "✦", Color(0xFF91D9C5), Modifier.weight(1f), "Baseada nos feedbacks registrados")
            MetricPod("Segurança", safetyLabel(state.motorState?.safetyStatus), "♥", if (state.motorState?.safetyStatus == "RED") Color(0xFFFF9292) else Color(0xFF91D9C5), Modifier.weight(1f), "Alertas conhecidos pelo treinador")
        }

        SectionHeading("Distribuição semanal", "Planejado")
        CardSurface(Modifier.padding(horizontal = 16.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Semana 1 do plano", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text("Distância prevista por dia", color = TextMuted, fontSize = 11.sp)
                    }
                    Text("${formatKmUi(firstWeekKm)} km", color = Blue2, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                SevenDayBreakdown(firstWeekSessions)
                Text("Este gráfico mostra sessões prescritas, não atividades realizadas.", color = TextMuted, fontSize = 10.sp)
            }
        }

        SectionHeading("Próximo treino", "Ver calendário") {
            state.selectedScreen = Screen.CALENDAR
        }
        if (nextWorkout != null) {
            NextWorkoutCard(nextWorkout) { state.selectWorkout(nextWorkout) }
        } else {
            EmptyStateCard("Nenhum treino pendente", "Gere um novo ciclo para visualizar suas próximas sessões.", "Criar ou revisar plano") {
                state.onboardingStep = if (state.weeklyVolumeText.isBlank()) 4 else 6
                state.persist()
            }
        }

        state.motorDecision?.let { decision ->
            SectionHeading("Leitura do treinador")
            CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF182B3D)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text(stimulusLabel(decision.stimulus), color = Blue2, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(decision.rationale, color = TextMuted, fontSize = 12.sp, lineHeight = 18.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        StatusPill("Confiança ${((decision.confidence * 100).toInt()).coerceIn(0, 100)}%", Color(0xFFB7C8FF))
                        StatusPill(safetyLabel(decision.safety), if (decision.safety == "RED") Color(0xFFFF9292) else Color(0xFF9BE2D0))
                    }
                }
            }
        }
        if (state.needsEngineRefresh) {
            NoteBlock("Este plano foi criado por uma versão anterior. Revise os dados reais do atleta e gere um novo ciclo antes de seguir esta prescrição.")
            PrimaryButton("Revisar dados e recriar plano") { state.onboardingStep = 4; state.persist() }
        }
        if (actualDistance > 0.0) {
            CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("Distância registrada", color = TextMuted, fontSize = 11.sp)
                        Text("${formatKmUi(actualDistance)} km", color = TextWhite, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("${state.completedWorkouts().size} concluídos", color = Green, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
    }
}

@Composable private fun MetricPod(label: String, value: String, icon: String, accent: Color, modifier: Modifier = Modifier, subtitle: String = "") {
    CardSurface(modifier.padding(vertical = 5.dp), containerColor = CardBlue) {
        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                Text(icon, color = accent, fontSize = 18.sp)
                Text(label, color = TextMuted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text(value, color = accent, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (subtitle.isNotBlank()) Text(subtitle, color = TextMuted, fontSize = 9.sp, lineHeight = 12.sp)
        }
    }
}

@Composable private fun CardBlock(title: String, main: String, note: String) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, color = Blue2, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(main, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = TextWhite)
            Text(note, color = TextMuted, fontSize = 12.sp, lineHeight = 17.sp)
        }
    }
}

@Composable private fun WorkoutCard(w: Workout, onClick: () -> Unit) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp).clickable(onClick = onClick)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            SessionGlyph(w.type, w.done, 44)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("${w.date}  •  ~${formatKmUi(w.distanceKm)} km estimados", color = TextMuted, fontSize = 10.sp)
                Text(w.title, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(workoutTypeLabel(w.type), color = Blue2, fontSize = 11.sp)
            }
            Text(if (w.done) "✓" else "›", color = if (w.done) Green else TextMuted, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable private fun CalendarScreen(state: CoachState) {
    val groups = state.workouts.groupBy { it.week }.toSortedMap()
    var expandedWeek by remember(state.workouts.size) { mutableStateOf(groups.keys.firstOrNull() ?: 1) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 22.dp)) {
        Header("Calendário")
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20334D)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("AGENDA DO CICLO", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                Text("${state.workouts.size} sessões programadas", color = TextWhite, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("As sessões são organizadas por semana e data. Toque em um treino para ver os detalhes.", color = TextMuted, fontSize = 12.sp)
            }
        }
        SectionHeading("Semanas do plano")
        if (groups.isEmpty()) EmptyStateCard("Calendário vazio", "Crie um plano para organizar suas sessões.", "Revisar perfil") { state.onboardingStep = 4; state.persist() }
        groups.forEach { (week, sessions) ->
            TrainingWeekCard(
                week = week, sessions = sessions, expanded = expandedWeek == week,
                onToggle = { expandedWeek = if (expandedWeek == week) -1 else week },
                onSession = { state.selectWorkout(it) }
            )
        }
    }
}

@Composable private fun WorkoutDetail(state: CoachState) {
    val workout = state.selectedWorkout()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Sessão de treinamento", true) { state.selectedScreen = Screen.CALENDAR }
        if (workout == null) {
            EmptyStateCard("Nenhuma sessão selecionada", "Escolha um treino no calendário ou no plano.", "Abrir calendário") { state.selectedScreen = Screen.CALENDAR }
            return@Column
        }
        SessionHero(workout)
        SectionHeading("Objetivo da sessão")
        CardSurface(Modifier.padding(horizontal = 16.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(workout.objective, color = TextWhite, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Text(workout.rationale, color = TextMuted, fontSize = 12.sp, lineHeight = 18.sp)
            }
        }
        SectionHeading("Resumo")
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricPod("Distância estimada", "${formatKmUi(workout.distanceKm)} km", "↔", Blue2, Modifier.weight(1f))
            MetricPod("Duração", "${workout.durationMin} min", "◷", Color(0xFFFFD18A), Modifier.weight(1f))
            MetricPod("Pace-alvo", workout.primaryPaceRange()?.let { it } ?: "Sem teste", "◷", Blue2, Modifier.weight(1f))
        }
        SectionHeading("Estrutura do treino", "Ver todos") { state.selectedScreen = Screen.STRUCTURE }
        workout.segments.take(4).forEachIndexed { index, segment -> SegmentRow(index + 1, segment) }
        PrimaryButton("Ver treino completo") { state.selectedScreen = Screen.STRUCTURE }
        PrimaryButton("Registrar feedback") { state.selectedScreen = Screen.FEEDBACK }
        PrimaryButton("Exportar para Pace Coach") { state.selectedScreen = Screen.EXPORT }
    }
}

@Composable private fun StructureScreen(state: CoachState) {
    val workout = state.selectedWorkout()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 22.dp)) {
        Header("Estrutura da sessão", true) { state.selectedScreen = Screen.WORKOUT }
        if (workout == null) {
            EmptyStateCard("Sessão não encontrada", "Selecione uma sessão para consultar os blocos.", "Voltar ao calendário") { state.selectedScreen = Screen.CALENDAR }
            return@Column
        }
        SessionHero(workout)
        SectionHeading("Blocos prescritos")
        if (workout.segments.isEmpty()) {
            NoteBlock("Esta sessão pertence a um plano antigo e não possui blocos detalhados. Gere um novo ciclo para receber a estrutura completa.")
        } else {
            workout.segments.forEachIndexed { index, segment -> SegmentRow(index + 1, segment) }
        }
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF1A2A3D)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("Orientação do treinador", color = Blue2, fontWeight = FontWeight.Bold)
                Text(workout.rationale, color = TextMuted, fontSize = 12.sp, lineHeight = 18.sp)
            }
        }
    }
}

@Composable private fun SessionHero(workout: Workout) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).clip(RoundedCornerShape(28.dp)).background(Brush.linearGradient(listOf(Color(0xFF263D62), Color(0xFF18364D)))).padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatusPill(workoutTypeLabel(workout.type).uppercase(), Color(0xFFBFD0FF))
            Spacer(Modifier.weight(1f))
            Text(if (workout.done) "CONCLUÍDO" else "PROGRAMADO", color = if (workout.done) Color(0xFF9BE2D0) else Color(0xFFCEDAFF), fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
        Text(workout.title, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
        Text("${workout.date}  •  Semana ${workout.week} · ${phaseLabel(workout.phase)}", color = Color(0xFFD0D9EA), fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(22.dp)) {
            Column { Text(formatKmUi(workout.distanceKm), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold); Text("km estimados", color = Color(0xFFD0D9EA), fontSize = 10.sp) }
            Column { Text("${workout.durationMin}", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold); Text("minutos estimados", color = Color(0xFFD0D9EA), fontSize = 10.sp) }
            Column { Text(workout.primaryPaceRange() ?: "—", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold); Text("pace min/km", color = Color(0xFFD0D9EA), fontSize = 10.sp) }
        }
    }
}

@Composable private fun SegmentRow(index: Int, segment: WorkoutSegment) {
    val dose = when {
        segment.targetMode == "TIME" && segment.repeatCount > 1 && segment.durationMin != null -> "${segment.repeatCount} × ${segment.durationMin} min"
        segment.targetMode == "TIME" && segment.durationMin != null -> "${segment.durationMin} min"
        segment.repeatCount > 1 && segment.distanceKm != null -> "${segment.repeatCount} × ${formatKmUi(segment.distanceKm)} km"
        segment.distanceKm != null -> "${formatKmUi(segment.distanceKm)} km"
        segment.durationMin != null -> "${segment.durationMin} min"
        else -> "Conforme orientação"
    }
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
            Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFF253A56), modifier = Modifier.size(34.dp)) {
                Box(contentAlignment = Alignment.Center) { Text(index.toString(), color = Blue2, fontWeight = FontWeight.Bold) }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(segment.name, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(dose, color = Blue2, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(segment.instruction, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                if (segment.targetPaceMinSecPerKm != null && segment.targetPaceMaxSecPerKm != null) {
                    Text("Pace-alvo: ${PaceRange(segment.targetPaceMinSecPerKm, segment.targetPaceMaxSecPerKm).label()}", color = Blue2, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                } else {
                    Text("Pace individual ainda não calibrado", color = Yellow, fontSize = 10.sp)
                }
                Text("RPE ${segment.rpeRange}: referência complementar de esforço", color = TextMuted, fontSize = 10.sp)
            }
        }
    }
}

@Composable private fun PlanScreen(state: CoachState) {
    val groups = state.workouts.groupBy { it.week }.toSortedMap()
    var expandedWeek by remember(state.workouts.size) { mutableStateOf(groups.keys.firstOrNull() ?: 1) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 26.dp)) {
        Header("Plano de treinamento")
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).clip(RoundedCornerShape(28.dp)).background(Brush.linearGradient(listOf(Color(0xFF293F63), Color(0xFF182C45)))).padding(20.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
            Text("OBJETIVO PRINCIPAL", color = Color(0xFFCEDAFF), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
            Text(goalLabel(state), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black)
            Text("${state.level.ifBlank { "Nível não informado" }}  •  ${state.frequency} dias por semana", color = Color(0xFFD0D9EA), fontSize = 12.sp)
            HorizontalDivider(color = Color(0x446F8DB8))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                PlanStat("Duração", "${state.planWeeks} sem.")
                PlanStat("Base recente", "${state.weeklyVolumeText.ifBlank { "—" }} km")
                PlanStat("Maior treino", "${state.longestRecent.ifBlank { "—" }} km")
            }
        }
        SectionHeading("Periodização", "${groups.size} semanas")
        if (state.motorDecision != null) {
            CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 2.dp), containerColor = Color(0xFF192B40)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("ESTRATÉGIA DO TREINADOR", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                    Text(stimulusLabel(state.motorDecision!!.stimulus), color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(state.motorDecision!!.rationale, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                }
            }
        }
        if (groups.isEmpty()) EmptyStateCard("Plano não criado", "Complete o perfil para o treinador organizar o seu ciclo.", "Revisar perfil") { state.onboardingStep = 4; state.persist() }
        groups.forEach { (week, sessions) ->
            TrainingWeekCard(
                week = week, sessions = sessions, expanded = expandedWeek == week,
                onToggle = { expandedWeek = if (expandedWeek == week) -1 else week },
                onSession = { state.selectWorkout(it) }
            )
        }
        NoteBlock("Os volumes representam a prescrição. A evolução real só é calculada quando as sessões são concluídas e a distância realizada é registrada.")
    }
}

@Composable private fun TrainingWeekCard(
    week: Int,
    sessions: List<Workout>,
    expanded: Boolean,
    onToggle: () -> Unit,
    onSession: (Workout) -> Unit
) {
    val totalKm = sessions.sumOf { it.distanceKm }
    val longKm = sessions.filter { it.type == "Longo" }.sumOf { it.distanceKm }
    val qualityKm = sessions.filter { it.type == "Qualidade" }.sumOf { it.distanceKm }
    val easyKm = (totalKm - longKm - qualityKm).coerceAtLeast(0.0)
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
            Row(Modifier.fillMaxWidth().clickable(onClick = onToggle), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("SEMANA $week", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                    Text(phaseLabel(sessions.firstOrNull()?.phase ?: "BASE"), color = TextWhite, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("~${formatKmUi(totalKm)} km", color = TextWhite, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text("${sessions.size} sessões", color = TextMuted, fontSize = 10.sp)
                }
                Spacer(Modifier.width(10.dp))
                Text(if (expanded) "⌃" else "⌄", color = Blue2, fontSize = 20.sp)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                if (totalKm > 0.0) {
                    if (easyKm > 0.0) Box(Modifier.weight((easyKm / totalKm).toFloat().coerceAtLeast(0.02f)).height(7.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF7BA9E8)))
                    if (qualityKm > 0.0) Box(Modifier.weight((qualityKm / totalKm).toFloat().coerceAtLeast(0.02f)).height(7.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFFE2B66E)))
                    if (longKm > 0.0) Box(Modifier.weight((longKm / totalKm).toFloat().coerceAtLeast(0.02f)).height(7.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF76CDB1)))
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Leves ${formatKmUi(easyKm)} km", color = TextMuted, fontSize = 9.sp)
                Text("Qualidade ${formatKmUi(qualityKm)} km", color = TextMuted, fontSize = 9.sp)
                Text("Longão ${formatKmUi(longKm)} km", color = TextMuted, fontSize = 9.sp)
            }
            if (expanded) {
                HorizontalDivider(color = Color(0xFF31445A))
                sessions.forEach { SessionAgendaRow(it) { onSession(it) } }
            } else {
                Text("Toque para expandir as sessões  ›", color = Blue2, fontSize = 10.sp, modifier = Modifier.clickable(onClick = onToggle))
            }
        }
    }
}

@Composable private fun SessionAgendaRow(workout: Workout, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(Color(0xFF142338)).clickable(onClick = onClick).padding(11.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        SessionGlyph(workout.type, workout.done, 36)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(workout.title, color = TextWhite, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            Text("${workout.date}  •  ${workoutTypeLabel(workout.type)}", color = TextMuted, fontSize = 9.sp)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text("~${formatKmUi(workout.distanceKm)} km", color = Blue2, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(if (workout.done) "Concluído" else "Planejado", color = if (workout.done) Green else TextMuted, fontSize = 9.sp)
        }
    }
}

@Composable private fun EvolutionScreen(state: CoachState) {
    val completed = state.completedWorkouts()
    val actualBySession = state.feedbackRecords.associateBy { it.sessionId }
    val recorded = completed.mapNotNull { workout -> actualBySession[workout.sessionId]?.actualDistanceKm?.let { workout.week to it } }
    val weeklyTotals = recorded.groupBy { it.first }.toSortedMap().map { (week, items) -> "S$week" to items.sumOf { it.second } }
    val totalDistance = recorded.sumOf { it.second }
    val totalSessionsWithDistance = recorded.size
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Evolução")
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            MetricPod("Sessões concluídas", completed.size.toString(), "✓", Green, Modifier.weight(1f))
            MetricPod("Distância registrada", "${formatKmUi(totalDistance)} km", "↗", Blue2, Modifier.weight(1f))
        }
        SectionHeading("Seu histórico")
        if (recorded.isEmpty()) {
            EmptyStateCard("Ainda estamos construindo seu histórico", "Depois de cada treino, registre o feedback e a distância realmente percorrida. Só então os gráficos de evolução serão exibidos.", "Ver treinos") { state.selectedScreen = Screen.HISTORY }
            CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("O que será acompanhado", color = Blue2, fontWeight = FontWeight.Bold)
                    Text("Distância realizada, consistência semanal, percepção de esforço e resposta à carga. Não exibimos estimativas fisiológicas enquanto não houver dados suficientes.", color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                }
            }
        } else {
            ChartCard("Quilômetros efetivamente registrados", weeklyTotals)
            CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 7.dp)) {
                Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Resumo dos registros", color = Blue2, fontWeight = FontWeight.Bold)
                    InfoRow("Treinos com distância real", totalSessionsWithDistance.toString())
                    InfoRow("Distância total informada", "${formatKmUi(totalDistance)} km")
                    InfoRow("Treinos concluídos", completed.size.toString())
                }
            }
        }
        NoteBlock("Os gráficos usam somente distâncias informadas no feedback. Quilômetros planejados não são contabilizados como desempenho realizado.")
    }
}

@Composable private fun ChartCard(title: String, values: List<Pair<String, Double>>) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 7.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
            Text(title, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            if (values.isEmpty()) {
                Text("Sem dados suficientes para montar o gráfico.", color = TextMuted, fontSize = 11.sp)
            } else {
                val maxValue = (values.maxOfOrNull { it.second } ?: 0.0).coerceAtLeast(1.0)
                Row(Modifier.fillMaxWidth().height(132.dp), horizontalArrangement = Arrangement.spacedBy(9.dp), verticalAlignment = Alignment.Bottom) {
                    values.forEach { (label, value) ->
                        Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                            Text(formatKmUi(value), color = Blue2, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(5.dp))
                            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.BottomCenter) {
                                Box(Modifier.fillMaxWidth(0.68f).height((value / maxValue * 82.0).coerceAtLeast(5.0).dp).clip(RoundedCornerShape(topStart = 9.dp, topEnd = 9.dp)).background(Brush.verticalGradient(listOf(Color(0xFF9BB7FF), Color(0xFF5479BC)))))
                            }
                            Spacer(Modifier.height(7.dp))
                            Text(label, color = TextMuted, fontSize = 9.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun FeedbackScreen(state: CoachState) {
    var effort by remember(state.selectedWorkoutIndex) { mutableStateOf("Leve") }
    var feeling by remember(state.selectedWorkoutIndex) { mutableStateOf("Bem") }
    var pain by remember(state.selectedWorkoutIndex) { mutableStateOf("Não") }
    var notes by remember(state.selectedWorkoutIndex) { mutableStateOf("") }
    var actualDistance by remember(state.selectedWorkoutIndex) { mutableStateOf("") }
    val workout = state.selectedWorkout()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Feedback da sessão", true) { state.selectedScreen = Screen.WORKOUT }
        if (workout != null) SessionHero(workout)
        else NoteBlock("Selecione uma sessão para registrar o feedback.")
        SectionHeading("Como foi o esforço?")
        FeedbackGroup("Esforço percebido", listOf("Muito leve", "Leve", "Ok", "Pesado", "Muito pesado"), effort) { effort = it }
        SectionHeading("Como você se sentiu?")
        FeedbackGroup("Sensação geral", listOf("Ótimo", "Bem", "Cansado", "Muito cansado"), feeling) { feeling = it }
        SectionHeading("Segurança")
        FeedbackGroup("Sentiu dor durante ou após o treino?", listOf("Não", "Sim"), pain) { pain = it }
        CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Distância realizada", color = TextWhite, fontWeight = FontWeight.Bold)
                Text("Informe o valor real para atualizar seu histórico. Não é obrigatório.", color = TextMuted, fontSize = 11.sp)
                OutlinedTextField(actualDistance, { actualDistance = it.filter { ch -> ch.isDigit() || ch == ',' || ch == '.' } }, label = { Text("Distância em km") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(notes, { notes = it }, label = { Text("Observações (opcional)") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
            }
        }
        PrimaryButton("Salvar feedback", enabled = workout != null) {
            state.saveFeedback(effort, feeling, notes, pain == "Sim", actualDistance)
            state.selectedScreen = Screen.DASHBOARD
        }
    }
}

@Composable private fun FeedbackGroup(title: String, options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text(title, color = TextMuted, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 20.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            options.forEach { option ->
                val active = option == selected
                Surface(
                    modifier = Modifier.clickable { onSelect(option) },
                    shape = RoundedCornerShape(50),
                    color = if (active) Color(0xFF344B78) else CardBlue,
                    border = if (active) androidx.compose.foundation.BorderStroke(1.dp, Blue2) else null
                ) { Text(option, color = if (active) Color.White else TextMuted, fontSize = 11.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) }
            }
        }
    }
}

@Composable private fun HistoryScreen(state: CoachState) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 22.dp)) {
        Header("Histórico de treinos")
        val completed = state.completedWorkouts().asReversed()
        if (completed.isEmpty()) {
            EmptyStateCard("Nenhuma sessão concluída", "Quando concluir um treino no Pace Coach, registre o feedback aqui para manter o histórico do treinador atualizado.", "Voltar ao início") { state.selectedScreen = Screen.DASHBOARD }
        } else {
            SectionHeading("Sessões registradas", "${completed.size} no total")
            completed.forEach { workout -> WorkoutCard(workout) { state.selectWorkout(workout); state.selectedScreen = Screen.FEEDBACK } }
        }
    }
}

@Composable private fun ProfileScreen(state: CoachState) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Perfil do atleta")
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20344E)) {
            Column(Modifier.padding(19.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Surface(shape = RoundedCornerShape(20.dp), color = Color(0xFF3C527A), modifier = Modifier.size(54.dp)) { Box(contentAlignment = Alignment.Center) { Text(state.name.take(1).uppercase(), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold) } }
                    Column {
                        Text(state.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("${state.level.ifBlank { "Nível não informado" }} • AI Running Coach", color = Color(0xFFD0D9EA), fontSize = 11.sp)
                    }
                }
                HorizontalDivider(color = Color(0x446F8DB8))
                InfoRow("Objetivo", goalLabel(state))
                InfoRow("Disponibilidade", "${state.frequency} dias por semana")
                InfoRow("Volume médio real", if (state.weeklyVolumeText.isBlank()) "Não informado" else "${state.weeklyVolumeText} km/semana")
                InfoRow("Maior sessão recente", if (state.longestRecent.isBlank()) "Não informado" else "${state.longestRecent} km")
                InfoRow("Resultado de referência", if (state.benchmarkEnabled) "${state.benchmarkDistanceText} km em ${state.benchmarkTimeText}" else "Não informado")
                InfoRow("Duração do ciclo", "${state.planWeeks} semanas")
            }
        }
        SectionHeading("Gerenciar perfil")
        ProfileAction("Revisar histórico e dados do atleta", "Atualizar volume, maior sessão e objetivo", "✎") { state.onboardingStep = 1; state.persist() }
        ProfileAction("Exportar sessão para Pace Coach", "Compartilhar uma prescrição estruturada", "⇧") { state.selectedScreen = Screen.EXPORT }
        ProfileAction("Calibrar ou atualizar pace", "Informar resultado recente de 3, 5 ou 10 km", "◷") { state.onboardingStep = 6; state.persist() }
        ProfileAction("Consultar sessões concluídas", "Ver feedback e distância registrada", "◷") { state.selectedScreen = Screen.HISTORY }
        CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("Privacidade e funcionamento", color = Blue2, fontWeight = FontWeight.Bold)
                Text("O perfil, o plano e os feedbacks são armazenados localmente neste dispositivo. O Pace Coach continua responsável pela execução, GPS, áudio e registro das corridas.", color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
            }
        }
    }
}

@Composable private fun ProfileAction(title: String, description: String, icon: String, onClick: () -> Unit) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp).clickable(onClick = onClick)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Surface(shape = RoundedCornerShape(13.dp), color = Color(0xFF293E5C), modifier = Modifier.size(40.dp)) { Box(contentAlignment = Alignment.Center) { Text(icon, color = Blue2, fontSize = 18.sp) } }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text(description, color = TextMuted, fontSize = 10.sp)
            }
            Text("›", color = TextMuted, fontSize = 23.sp)
        }
    }
}

@Composable private fun ExportScreen(state: CoachState) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val workout = state.selectedWorkout()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Compartilhar com Pace Coach", true) { state.selectedScreen = Screen.WORKOUT }
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20344E)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("PRESCRIÇÃO ESTRUTURADA", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                Text(workout?.title ?: "Nenhuma sessão selecionada", color = TextWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                if (workout != null) Text("${workout.date} • ~${formatKmUi(workout.distanceKm)} km estimados • ${workout.segments.size} blocos", color = TextMuted, fontSize = 11.sp)
                Text("O AI Running Coach planeja. O Pace Coach executa e registra o treino.", color = TextMuted, fontSize = 11.sp)
            }
        }
        SectionHeading("O que será compartilhado")
        StepExport("01", "Identificação", workout?.let { "ID ${it.sessionId} • ${it.date} • Semana ${it.week}" } ?: "ID da sessão, data, semana e tipo de treino")
        StepExport("02", "Blocos de treino", workout?.let { "${it.segments.size} blocos • Aquecimento, estímulos, recuperação e desaquecimento" } ?: "Estrutura da sessão")
        StepExport("03", "Alvo de execução", workout?.let {
            val modes = it.segments.map { segment -> segment.targetMode }.distinct()
            val modeLabel = when (modes.size) { 2 -> "Tempo + distância"; 1 -> if (modes.first() == "TIME") "Tempo" else "Distância"; else -> "Sem blocos" }
            "$modeLabel • Pace ${it.primaryPaceRange() ?: "não calibrado"} min/km • RPE ${it.rpeRange} como apoio"
        } ?: "Etapas por tempo ou distância, com pace em min/km quando houver referência")
        NoteBlock("A transferência gera um JSON pace-coach-workout 2.1. Cada bloco declara alvo por distância ou tempo e pace em min/km quando calibrado. A distância e a duração totais são estimativas; o alvo executável está em cada bloco. A importação automática depende de o Pace Coach implementar o receptor desse contrato.")
        PrimaryButton("Compartilhar prescrição JSON", enabled = workout != null) {
            val selected = workout
            if (selected != null) {
                val prescription = selected.toPrescribedWorkout()
                val goalDistanceKm = when {
                    state.goal.startsWith("5") -> 5.0
                    state.goal.startsWith("10") -> 10.0
                    state.goal.startsWith("Meia") -> 21.1
                    state.goal.startsWith("Maratona") -> 42.2
                    state.goal == "Outro objetivo" -> state.customGoalKm.trim().replace(",", ".").toDoubleOrNull()
                    else -> 5.0
                }
                val json = PaceCoachExporter.workoutToJson(
                    prescription, state.goal, goalDistanceKm,
                    paceReferenceDistanceKm = if (state.benchmarkEnabled) state.benchmarkDistanceText.toDoubleOrNull() else null,
                    paceReferenceTimeSeconds = if (state.benchmarkEnabled) PaceCalculator.parseMmSs(state.benchmarkTimeText) else null
                )
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "application/json"
                    putExtra(Intent.EXTRA_SUBJECT, "Prescrição — ${selected.title}")
                    putExtra(Intent.EXTRA_TEXT, json)
                }
                context.startActivity(Intent.createChooser(sendIntent, "Enviar prescrição para o Pace Coach"))
            }
        }
    }
}

private fun Workout.primaryPaceRange(): String? {
    val preferred = segments.firstOrNull { it.name.contains("principal", true) || it.name.contains("aeróbio", true) || it.name.contains("longão", true) }
        ?: segments.firstOrNull { it.targetPaceMinSecPerKm != null && it.targetPaceMaxSecPerKm != null }
    val minPace = preferred?.targetPaceMinSecPerKm ?: return null
    val maxPace = preferred.targetPaceMaxSecPerKm ?: return null
    return "${PaceRange.format(minPace)}–${PaceRange.format(maxPace)}"
}

private fun Workout.toPrescribedWorkout(): PrescribedWorkout = PrescribedWorkout(
    day = date.substringBefore(","), date = date, scheduledDateIso = scheduledDateIso, title = title, type = type, objective = objective,
    stimulus = stimulus, sessionId = sessionId, distanceKm = distanceKm, durationMin = durationMin,
    intensity = intensity, paceMode = paceMode, rpeRange = rpeRange, detail = detail,
    rationale = rationale, week = week, phase = phase, segments = segments
)

@Composable private fun BottomNav(state: CoachState) {
    Row(
        Modifier.fillMaxWidth().background(Color(0xFF0D1726)).padding(horizontal = 9.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        DockItem(Modifier.weight(1f), "⌂", "Início", state.selectedScreen == Screen.DASHBOARD) { state.selectedScreen = Screen.DASHBOARD }
        DockItem(Modifier.weight(1f), "▦", "Agenda", state.selectedScreen == Screen.CALENDAR) { state.selectedScreen = Screen.CALENDAR }
        DockItem(Modifier.weight(1f), "≋", "Plano", state.selectedScreen == Screen.PLAN) { state.selectedScreen = Screen.PLAN }
        DockItem(Modifier.weight(1f), "↗", "Evolução", state.selectedScreen == Screen.EVOLUTION) { state.selectedScreen = Screen.EVOLUTION }
        DockItem(Modifier.weight(1f), "•••", "Mais", state.selectedScreen == Screen.PROFILE || state.selectedScreen == Screen.HISTORY) { state.selectedScreen = Screen.PROFILE }
    }
}

@Composable private fun DockItem(modifier: Modifier, icon: String, label: String, selected: Boolean, onClick: () -> Unit) {
    Column(modifier.clickable(onClick = onClick).padding(vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Surface(shape = RoundedCornerShape(15.dp), color = if (selected) Color(0xFF2B4168) else Color.Transparent) {
            Box(Modifier.widthIn(min = 52.dp).height(32.dp).padding(horizontal = 13.dp), contentAlignment = Alignment.Center) {
                Text(icon, color = if (selected) Color.White else TextMuted, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            }
        }
        Text(label, color = if (selected) Blue2 else TextMuted, fontSize = 9.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium)
    }
}

@Composable private fun SectionHeading(title: String, action: String? = null, onAction: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 21.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = TextWhite, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (action != null) Text(action, color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = if (onAction != null) Modifier.clickable(onClick = onAction) else Modifier)
    }
}

@Composable private fun CardSurface(modifier: Modifier = Modifier, containerColor: Color = CardBlue, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier = modifier, shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = containerColor), content = content)
}

@Composable private fun StatusPill(text: String, color: Color) {
    Surface(shape = RoundedCornerShape(50), color = color.copy(alpha = 0.13f), border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.35f))) {
        Text(text, color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp))
    }
}

@Composable private fun ProgressTrack(progress: Float, color: Color = Blue2, trackColor: Color = Color(0xFF2A3D55)) {
    Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)).background(trackColor)) {
        if (progress > 0f) Box(Modifier.fillMaxWidth(progress.coerceIn(0f, 1f)).fillMaxHeight().clip(RoundedCornerShape(50)).background(color))
    }
}

@Composable private fun SevenDayBreakdown(sessions: List<Workout>) {
    val labels = listOf("SEG", "TER", "QUA", "QUI", "SEX", "SÁB", "DOM")
    val values = MutableList(7) { 0.0 }
    sessions.forEach { workout ->
        val dayIndex = runCatching { LocalDate.parse(workout.scheduledDateIso).dayOfWeek.value - 1 }.getOrNull()
        if (dayIndex != null && dayIndex in 0..6) values[dayIndex] = values[dayIndex] + workout.distanceKm
    }
    val maxValue = (values.maxOrNull() ?: 0.0).coerceAtLeast(1.0)
    Row(Modifier.fillMaxWidth().height(126.dp), horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.Bottom) {
        values.forEachIndexed { index, value ->
            Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                if (value > 0.0) Text(formatKmUi(value), color = Blue2, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(5.dp))
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.BottomCenter) {
                    Box(Modifier.fillMaxWidth(0.62f).height(if (value > 0.0) (value / maxValue * 76.0).coerceAtLeast(10.0).dp else 4.dp).clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp)).background(if (value > 0.0) Brush.verticalGradient(listOf(Color(0xFFB4C8FF), Color(0xFF5E81C3))) else Brush.verticalGradient(listOf(Color(0xFF34445A), Color(0xFF34445A)))))
                }
                Spacer(Modifier.height(7.dp))
                Text(labels[index], color = TextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable private fun NextWorkoutCard(workout: Workout, onClick: () -> Unit) {
    CardSurface(Modifier.padding(horizontal = 16.dp).clickable(onClick = onClick), containerColor = Color(0xFF1B3048)) {
        Row(Modifier.fillMaxWidth().padding(17.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(13.dp)) {
            SessionGlyph(workout.type, workout.done, 48)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(workout.date.uppercase(), color = Blue2, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text(workout.title, color = TextWhite, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text("~${formatKmUi(workout.distanceKm)} km  •  ${workout.durationMin} min  •  Pace ${workout.primaryPaceRange() ?: "a calibrar"}", color = TextMuted, fontSize = 10.sp)
            }
            Text("›", color = Blue2, fontSize = 27.sp)
        }
    }
}

@Composable private fun SessionGlyph(type: String, done: Boolean, size: Int) {
    val color = when {
        done -> Color(0xFF1D4A43)
        type == "Qualidade" -> Color(0xFF55452E)
        type == "Longo" -> Color(0xFF294667)
        type == "Recuperação" -> Color(0xFF34465E)
        else -> Color(0xFF2D455D)
    }
    Surface(shape = RoundedCornerShape(16.dp), color = color, modifier = Modifier.size(size.dp)) {
        Box(contentAlignment = Alignment.Center) {
            Text(when { done -> "✓"; type == "Qualidade" -> "⚡"; type == "Longo" -> "↗"; type == "Recuperação" -> "☾"; else -> "◉" }, color = if (done) Green else Color(0xFFD7E3FF), fontSize = if (size > 40) 19.sp else 15.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable private fun PlanStat(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, color = Color(0xFFD0D9EA), fontSize = 9.sp)
        Text(value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable private fun EmptyStateCard(title: String, description: String, action: String, onClick: () -> Unit) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
        Column(Modifier.fillMaxWidth().padding(19.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("◌", color = Blue2, fontSize = 26.sp)
            Text(title, color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(description, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
            Text(action + "  ›", color = Blue2, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable(onClick = onClick).padding(top = 3.dp))
        }
    }
}

@Composable private fun NoteBlock(text: String) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), containerColor = Color(0xFF1B2D42)) {
        Row(Modifier.padding(15.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Top) {
            Text("ⓘ", color = Blue2, fontSize = 17.sp)
            Text(text, color = Color(0xFFB9C8DD), fontSize = 11.sp, lineHeight = 17.sp, modifier = Modifier.weight(1f))
        }
    }
}

@Composable private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = TextMuted, fontSize = 11.sp, modifier = Modifier.weight(0.45f))
        Text(value, color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End, modifier = Modifier.weight(0.55f))
    }
}

@Composable private fun ListButton(text: String, onClick: () -> Unit) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp).clickable(onClick = onClick)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text(text, color = TextWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text("›", color = Blue2, fontSize = 22.sp)
        }
    }
}

@Composable private fun StepExport(n: String, title: String, desc: String) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(n, color = Blue2, fontSize = 24.sp, fontWeight = FontWeight.Black)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(desc, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
            }
        }
    }
}

@Composable private fun PrimaryButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Button(onClick = onClick, enabled = enabled, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(54.dp), shape = RoundedCornerShape(18.dp), colors = ButtonDefaults.buttonColors(containerColor = Blue, contentColor = Color(0xFF101827))) {
        Text(text, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

@Composable private fun LazyColumnLike(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 16.dp), content = content)
}

private fun goalLabel(state: CoachState): String = when {
    state.goal == "Outro objetivo" -> "${state.customGoalKm} km"
    state.goal.isBlank() -> "Objetivo não definido"
    else -> state.goal
}

private fun formatKmUi(value: Double): String = String.format(Locale("pt", "BR"), "%.1f", value).replace(",0", "")
private fun recoveryLabel(status: String?): String = when (status) {
    "GOOD" -> "Boa"
    "MODERATE" -> "Moderada"
    "POOR" -> "Baixa"
    else -> "Não avaliada"
}
private fun safetyLabel(status: String?): String = when (status) {
    "RED" -> "Dor relatada"
    "YELLOW" -> "Atenção à fadiga"
    "GREEN" -> "Sem alerta"
    else -> "Não avaliada"
}
private fun phaseLabel(phase: String): String = when (phase) {
    "ADAPTATION" -> "Adaptação"
    "CONSOLIDATION" -> "Consolidação"
    "PROGRESSION" -> "Progressão"
    "RECOVERY" -> "Regenerativa"
    else -> "Base aeróbia"
}
private fun workoutTypeLabel(type: String): String = when (type) {
    "Longo" -> "Longão aeróbio"
    "Qualidade" -> "Treino de qualidade"
    "Aeróbio" -> "Rodagem aeróbia"
    "Recuperação" -> "Rodagem regenerativa"
    else -> type
}
private fun stimulusLabel(stimulus: String): String = when (stimulus) {
    "AEROBIC_BASE" -> "Desenvolvimento da base aeróbia"
    "AEROBIC_BASE_AND_CONTROLLED_QUALITY" -> "Base aeróbia com qualidade controlada"
    "LOW_INTENSITY_AEROBIC" -> "Recuperação e baixa intensidade"
    "NONE" -> "Prescrição suspensa por segurança"
    else -> "Desenvolvimento de resistência"
}

