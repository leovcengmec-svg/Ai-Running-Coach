package com.airunningcoach.app

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Navy = Color(0xFF061B2B)
private val Navy2 = Color(0xFF0B2639)
private val CardBlue = Color(0xFF12364D)
private val Blue = Color(0xFF2CA7FF)
private val Blue2 = Color(0xFF63C5FF)
private val TextWhite = Color(0xFFF4F8FB)
private val TextMuted = Color(0xFF9EB2C2)
private val Green = Color(0xFF35D5A0)
private val Yellow = Color(0xFFFFC857)

private enum class Screen { DASHBOARD, CALENDAR, WORKOUT, STRUCTURE, PLAN, EVOLUTION, FEEDBACK, HISTORY, PROFILE, EXPORT }

private data class Workout(
    val date: String,
    val title: String,
    val detail: String,
    val type: String,
    val objective: String,
    val stimulus: String,
    val distanceKm: Double,
    val done: Boolean = false,
    val sessionId: String = "",
    val durationMin: Int = 0,
    val intensity: String = "LOW",
    val paceMode: String = "RPE",
    val rpeRange: String = "3-4",
    val rationale: String = "",
    val week: Int = 1
)

private class CoachState(private val context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("ai_running_coach", Context.MODE_PRIVATE)

    var name by mutableStateOf("Leonardo")
    var goal by mutableStateOf("")
    var level by mutableStateOf("")
    var frequency by mutableStateOf(0)
    var targetDate by mutableStateOf("Sem data definida")
    var volume by mutableStateOf("")
    var longestRecent by mutableStateOf("")
    var onboardingStep by mutableStateOf(-1)
    var selectedScreen by mutableStateOf(Screen.DASHBOARD)
    var selectedWorkoutIndex by mutableStateOf(0)
    var feedbackSaved by mutableStateOf(false)
    var workouts by mutableStateOf(listOf<Workout>())
    var planWeeks by mutableStateOf(4)
    var motorState by mutableStateOf<MotorState?>(null)
    var motorDecision by mutableStateOf<MotorDecision?>(null)
    var motorExplanation by mutableStateOf("")
    var motorError by mutableStateOf("")

    init { load() }

    fun createPlan(): Boolean {
        motorError = ""
        if (goal.isBlank() || level.isBlank() || frequency !in 2..6 || volume.isBlank() || longestRecent.isBlank()) {
            motorError = "Complete todas as escolhas antes de criar o plano."
            persist()
            return false
        }

        val goalKm = when {
            goal.startsWith("5") -> 5.0
            goal.startsWith("10") -> 10.0
            goal.startsWith("Meia") -> 21.0
            goal.startsWith("Maratona") -> 42.0
            else -> 5.0
        }
        val recentKm = longestRecent.substringBefore(" ").replace(",", ".").toDoubleOrNull()
        val weeklyMin = when {
            volume.startsWith("Até") -> 10.0
            volume.startsWith("10") -> 10.0
            volume.startsWith("30") -> 30.0
            volume.startsWith("Acima") -> 50.0
            else -> 10.0
        }
        if (recentKm == null) {
            motorError = "Não foi possível interpretar o maior treino recente."
            persist()
            return false
        }

        return try {
            val input = RunnerInput(
                goalKm = goalKm,
                level = level,
                frequency = frequency,
                weeklyVolumeMinKm = weeklyMin,
                longestRecentKm = recentKm
            )
            val plan = RunningCoachEngine.generate(input)
            motorState = plan.state
            motorDecision = plan.decision
            motorExplanation = plan.explanation
            workouts = plan.workouts.map { p ->
                Workout(
                    date = p.day, title = p.title, detail = p.detail, type = p.type,
                    objective = p.objective, stimulus = p.stimulus, distanceKm = p.distanceKm,
                    sessionId = p.sessionId, durationMin = p.durationMin, intensity = p.intensity,
                    paceMode = p.paceMode, rpeRange = p.rpeRange, rationale = p.rationale, week = p.week
                )
            }
            if (plan.decision.safety == "RED") {
                motorError = "O motor bloqueou a prescrição por segurança."
            } else if (workouts.isEmpty()) {
                motorError = "O motor terminou sem gerar sessões."
                persist()
                return false
            }
            planWeeks = 4
            selectedWorkoutIndex = 0
            selectedScreen = Screen.DASHBOARD
            onboardingStep = 7
            persist()
            true
        } catch (e: Exception) {
            motorError = "Erro ao executar o motor: ${e.message ?: "erro desconhecido"}"
            persist()
            false
        }
    }

    fun selectedWorkout(): Workout? = workouts.getOrNull(selectedWorkoutIndex)

    fun selectWorkout(workout: Workout) {
        val index = workouts.indexOf(workout)
        if (index >= 0) selectedWorkoutIndex = index
        selectedScreen = Screen.WORKOUT
        persist()
    }

    fun persist() {
        val e = prefs.edit()
            .putString("name", name)
            .putString("goal", goal)
            .putString("level", level)
            .putInt("frequency", frequency)
            .putString("targetDate", targetDate)
            .putString("volume", volume)
            .putString("longestRecent", longestRecent)
            .putInt("onboardingStep", onboardingStep)
            .putInt("selectedScreen", selectedScreen.ordinal)
            .putInt("selectedWorkoutIndex", selectedWorkoutIndex)
            .putInt("planWeeks", planWeeks)
            .putString("motorExplanation", motorExplanation)
            .putString("motorError", motorError)

        motorState?.let { ms ->
            e.putString("motorState", JSONObject().apply {
                put("fitnessConfidence", ms.fitnessConfidence)
                put("paceConfidence", ms.paceConfidence)
                put("recentVolumeKm", ms.recentVolumeKm)
                put("recentLongRunKm", ms.recentLongRunKm)
                put("recoveryStatus", ms.recoveryStatus)
                put("safetyStatus", ms.safetyStatus)
                put("phase", ms.phase)
                put("flags", JSONArray(ms.flags))
            }.toString())
        }
        motorDecision?.let { md ->
            e.putString("motorDecision", JSONObject().apply {
                put("action", md.action)
                put("necessity", md.necessity)
                put("stimulus", md.stimulus)
                put("rationale", md.rationale)
                put("confidence", md.confidence)
                put("safety", md.safety)
            }.toString())
        }
        val arr = JSONArray()
        workouts.forEach { w ->
            arr.put(JSONObject().apply {
                put("date", w.date); put("title", w.title); put("detail", w.detail)
                put("type", w.type); put("objective", w.objective); put("stimulus", w.stimulus)
                put("distanceKm", w.distanceKm); put("done", w.done); put("sessionId", w.sessionId)
                put("durationMin", w.durationMin); put("intensity", w.intensity); put("paceMode", w.paceMode)
                put("rpeRange", w.rpeRange); put("rationale", w.rationale); put("week", w.week)
            })
        }
        e.putString("workouts", arr.toString()).apply()
    }

    private fun load() {
        name = prefs.getString("name", "Leonardo") ?: "Leonardo"
        goal = prefs.getString("goal", "") ?: ""
        level = prefs.getString("level", "") ?: ""
        frequency = prefs.getInt("frequency", 0)
        targetDate = prefs.getString("targetDate", "Sem data definida") ?: "Sem data definida"
        volume = prefs.getString("volume", "") ?: ""
        longestRecent = prefs.getString("longestRecent", "") ?: ""
        onboardingStep = prefs.getInt("onboardingStep", if (goal.isBlank()) -1 else 6)
        selectedWorkoutIndex = prefs.getInt("selectedWorkoutIndex", 0)
        planWeeks = prefs.getInt("planWeeks", 4)
        motorExplanation = prefs.getString("motorExplanation", "") ?: ""
        motorError = prefs.getString("motorError", "") ?: ""
        selectedScreen = Screen.entries.getOrNull(prefs.getInt("selectedScreen", Screen.DASHBOARD.ordinal)) ?: Screen.DASHBOARD

        prefs.getString("motorState", null)?.let { raw -> runCatching {
            val o = JSONObject(raw)
            motorState = MotorState(
                fitnessConfidence = o.optString("fitnessConfidence"),
                paceConfidence = o.optString("paceConfidence"),
                recentVolumeKm = o.optDouble("recentVolumeKm"),
                recentLongRunKm = o.optDouble("recentLongRunKm"),
                recoveryStatus = o.optString("recoveryStatus"),
                safetyStatus = o.optString("safetyStatus"),
                phase = o.optString("phase"),
                flags = buildList { val a=o.optJSONArray("flags"); if (a != null) for (i in 0 until a.length()) add(a.optString(i)) }
            )
        }}
        prefs.getString("motorDecision", null)?.let { raw -> runCatching {
            val o = JSONObject(raw)
            motorDecision = MotorDecision(
                action = o.optString("action"), necessity = o.optString("necessity"), stimulus = o.optString("stimulus"),
                rationale = o.optString("rationale"), confidence = o.optDouble("confidence"), safety = o.optString("safety")
            )
        }}
        prefs.getString("workouts", null)?.let { raw -> runCatching {
            val a = JSONArray(raw)
            workouts = buildList {
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    add(Workout(
                        date=o.optString("date"), title=o.optString("title"), detail=o.optString("detail"), type=o.optString("type"),
                        objective=o.optString("objective"), stimulus=o.optString("stimulus"), distanceKm=o.optDouble("distanceKm"),
                        done=o.optBoolean("done"), sessionId=o.optString("sessionId"), durationMin=o.optInt("durationMin"),
                        intensity=o.optString("intensity", "LOW"), paceMode=o.optString("paceMode", "RPE"),
                        rpeRange=o.optString("rpeRange", "3-4"), rationale=o.optString("rationale"), week=o.optInt("week",1)
                    ))
                }
            }
        }}

        // Se o perfil já existe, mas ainda não há plano salvo, leva o usuário ao resumo.
        // O plano só é criado quando ele confirma explicitamente "Criar meu plano".
        if (goal.isNotBlank() && workouts.isNotEmpty()) onboardingStep = 7
    }
}
private val AppColors = darkColorScheme(
    primary = Blue,
    onPrimary = Color.White,
    background = Navy,
    surface = Navy2,
    surfaceVariant = CardBlue,
    onBackground = TextWhite,
    onSurface = TextWhite,
    onSurfaceVariant = TextMuted
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RunningCoachApp() }
    }
}

@Composable
private fun RunningCoachApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val state = remember(context) { CoachState(context.applicationContext) }
    MaterialTheme(colorScheme = AppColors) {
        Surface(Modifier.fillMaxSize(), color = Navy) {
            if (state.onboardingStep in -1..6) Onboarding(state) else MainShell(state)
        }
    }
}

@Composable
private fun Onboarding(state: CoachState) {
    val step = state.onboardingStep
    Column(
        Modifier.fillMaxSize().background(Navy).verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(22.dp))
        Text("AI", color = Blue, fontSize = 38.sp, fontWeight = FontWeight.Black)
        Text("RUNNING COACH", color = TextWhite, fontSize = 25.sp, fontWeight = FontWeight.Black)
        Text("PRESCREVE HOJE, EVOLUI SEMPRE", color = Blue2, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))
        StepBar(step)
        Spacer(Modifier.height(28.dp))
        when (step) {
            -1 -> {
                BigRunnerMark()
                Text("Seu plano. Sua evolução.", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("Prescrição inteligente de treinos de corrida. Sem execução de treino neste app.", color = TextMuted, textAlign = TextAlign.Center, modifier = Modifier.padding(12.dp))
            }
            0 -> {
                Text("Vamos começar", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("Em alguns passos vamos criar seu perfil e seu primeiro plano de corrida.", color = TextMuted, textAlign = TextAlign.Center, modifier = Modifier.padding(12.dp))
            }
            1 -> ChoiceScreen("Qual é o seu objetivo?", listOf("5 km", "10 km", "Meia Maratona (21 km)", "Maratona (42 km)", "Saúde e qualidade de vida", "Outro objetivo"), state.goal) { state.goal = it; state.persist() }
            2 -> ChoiceScreen("Qual é o seu nível de experiência?", listOf("Iniciante", "Intermediário", "Avançado", "Elite"), state.level) { state.level = it; state.persist() }
            3 -> ChoiceScreen("Quantos dias por semana você pode treinar?", listOf("2", "3", "4", "5", "6"), if (state.frequency == 0) "" else state.frequency.toString()) { state.frequency = it.toInt(); state.persist() }
            4 -> ChoiceScreen("Qual é o seu volume semanal atual?", listOf("Até 10 km/semana", "10–30 km/semana", "30–50 km/semana", "Acima de 50 km/semana"), state.volume) { state.volume = it; state.persist() }
            5 -> ChoiceScreen("Qual é o seu maior treino recente?", listOf("3 km", "5 km", "7 km", "10 km", "Mais de 10 km"), state.longestRecent) { state.longestRecent = it; state.persist() }
            6 -> {
                Text("Resumo do seu perfil", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = CardBlue)) {
                    Column(Modifier.padding(18.dp)) {
                        InfoRow("Nome", state.name)
                        InfoRow("Nível", state.level)
                        InfoRow("Objetivo", state.goal)
                        InfoRow("Data-alvo", state.targetDate)
                        InfoRow("Frequência", "${state.frequency} dias por semana")
                        InfoRow("Volume semanal", state.volume)
                        InfoRow("Maior treino recente", state.longestRecent)
                    }
                }
            }
        }
        Spacer(Modifier.height(26.dp))
        val canContinue = when (step) {
            1 -> state.goal.isNotBlank()
            2 -> state.level.isNotBlank()
            3 -> state.frequency in 2..6
            4 -> state.volume.isNotBlank()
            5 -> state.longestRecent.isNotBlank()
            6 -> state.goal.isNotBlank() && state.level.isNotBlank() && state.frequency in 2..6 && state.volume.isNotBlank() && state.longestRecent.isNotBlank()
            else -> true
        }
        PrimaryButton(if (step == 6) "Criar meu plano" else if (step <= 0) "Começar" else "Continuar", enabled = canContinue) {
            if (step == 6) state.createPlan() else { state.onboardingStep++; state.persist() }
        }
        if (state.motorError.isNotBlank()) {
            Text(state.motorError, color = Color(0xFFFF8A8A), fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
        }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable private fun StepBar(step: Int) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        repeat(5) { Box(Modifier.weight(1f).height(5.dp).clip(RoundedCornerShape(10.dp)).background(if (it <= step) Blue else Color(0xFF24445B))) }
    }
}

@Composable private fun BigRunnerMark() {
    Box(Modifier.size(150.dp).clip(RoundedCornerShape(80.dp)).background(Color(0xFF0D3148)), contentAlignment = Alignment.Center) {
        Text("🏃", fontSize = 76.sp)
    }
}

@Composable private fun ChoiceScreen(title: String, options: List<String>, current: String, selected: (String) -> Unit) {
    Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
    Spacer(Modifier.height(14.dp))
    options.forEach { option ->
        val isSelected = option == current
        Card(
            Modifier
                .fillMaxWidth()
                .padding(vertical = 5.dp)
                .then(if (isSelected) Modifier.border(2.dp, Blue, RoundedCornerShape(12.dp)) else Modifier)
                .clickable { selected(option) },
            colors = CardDefaults.cardColors(containerColor = if (isSelected) Color(0xFF174968) else CardBlue),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(20.dp).border(2.dp, if (isSelected) Blue else TextMuted, RoundedCornerShape(50)),
                    contentAlignment = Alignment.Center
                ) {
                    if (isSelected) Box(Modifier.size(10.dp).clip(RoundedCornerShape(50)).background(Blue))
                }
                Spacer(Modifier.width(12.dp))
                Text(option, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold)
            }
        }
    }
}

@Composable private fun MainShell(state: CoachState) {
    Scaffold(containerColor = Navy, bottomBar = { BottomNav(state) }) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (state.selectedScreen) {
                Screen.DASHBOARD -> Dashboard(state)
                Screen.CALENDAR -> CalendarScreen(state)
                Screen.WORKOUT -> WorkoutDetail(state)
                Screen.STRUCTURE -> StructureScreen(state)
                Screen.PLAN -> PlanScreen(state)
                Screen.EVOLUTION -> EvolutionScreen()
                Screen.FEEDBACK -> FeedbackScreen(state)
                Screen.HISTORY -> HistoryScreen(state)
                Screen.PROFILE -> ProfileScreen(state)
                Screen.EXPORT -> ExportScreen(state)
            }
        }
    }
}

@Composable private fun Header(title: String, back: Boolean = false, onBack: () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        if (back) Text("‹", fontSize = 34.sp, color = Blue, modifier = Modifier.clickable { onBack() }.padding(end = 12.dp))
        Column(Modifier.weight(1f)) { Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text("AI RUNNING COACH", color = Blue2, fontSize = 9.sp, fontWeight = FontWeight.Bold) }
    }
}

@Composable private fun Dashboard(state: CoachState) {
    LazyColumnLike {
        Header("Olá, ${state.name}! 👋")
        Text("Aqui está o seu panorama atual.", color = TextMuted, modifier = Modifier.padding(horizontal = 20.dp))
        Spacer(Modifier.height(12.dp))
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard("Fitness", state.motorState?.fitnessConfidence ?: "Muito baixo", "🏃", Blue2, Modifier.weight(1f))
            MetricCard("Carga", if (state.motorState?.recentVolumeKm ?: 0.0 > 0) "Base conhecida" else "Sem dados", "⚡", Yellow, Modifier.weight(1f))
        }
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard("Recuperação", state.motorState?.recoveryStatus ?: "Desconhecida", "◔", Blue2, Modifier.weight(1f))
            MetricCard("Segurança", state.motorState?.safetyStatus ?: "GREEN", "♥", Green, Modifier.weight(1f))
        }
        CardBlock("Plano inicial", "${state.workouts.size} treinos / semana", "Prescrição gerada a partir do seu objetivo, nível, frequência e volume atual.")
        if (state.workouts.isEmpty()) {
            NoteBlock(if (state.motorError.isBlank()) "Seu perfil foi salvo. Confirme os dados e gere o plano para o motor criar as prescrições." else state.motorError)
            PrimaryButton("Gerar plano agora") { state.onboardingStep = 6; state.selectedScreen = Screen.DASHBOARD; state.persist() }
        }
        Text("Próximos treinos", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(20.dp, 14.dp, 20.dp, 4.dp))
        state.workouts.take(3).forEach { WorkoutCard(it) { state.selectWorkout(it) } }
    }
}

@Composable private fun MetricCard(label: String, value: String, icon: String, accent: Color, modifier: Modifier = Modifier) {
    Card(modifier.padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = CardBlue)) {
        Column(Modifier.padding(14.dp)) { Text(icon, fontSize = 22.sp); Text(label, color = TextMuted, fontSize = 11.sp); Text(value, color = accent, fontWeight = FontWeight.Bold) }
    }
}

@Composable private fun CardBlock(title: String, main: String, note: String) {
    Card(Modifier.fillMaxWidth().padding(16.dp, 8.dp), colors = CardDefaults.cardColors(containerColor = CardBlue)) {
        Column(Modifier.padding(18.dp)) { Text(title, color = Blue2, fontWeight = FontWeight.Bold); Text(main, fontSize = 24.sp, fontWeight = FontWeight.Black); Text(note, color = TextMuted, fontSize = 12.sp) }
    }
}

@Composable private fun WorkoutCard(w: Workout, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp).clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = CardBlue)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(21.dp)).background(Color(0xFF16455D)), contentAlignment = Alignment.Center) { Text(if (w.type.contains("Velocidade")) "⚡" else "🏃", fontSize = 20.sp) }
            Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(w.date, color = TextMuted, fontSize = 11.sp); Text(w.title, fontWeight = FontWeight.Bold); Text(w.detail, color = Blue2, fontSize = 12.sp) }
            Text(if (w.done) "✓" else "○", color = if (w.done) Green else TextMuted, fontSize = 24.sp)
        }
    }
}

@Composable private fun CalendarScreen(state: CoachState) {
    LazyColumnLike {
        Header("Calendário")
        CardBlock("Abril 2026", "‹     17     ›", "Semana 5 de 16")
        CalendarGrid()
        state.workouts.forEach { WorkoutCard(it) { state.selectWorkout(it) } }
    }
}

@Composable private fun CalendarGrid() {
    val days = listOf("D","S","T","Q","Q","S","S")
    Column(Modifier.padding(horizontal = 18.dp)) {
        Row(Modifier.fillMaxWidth()) { days.forEach { Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, color = TextMuted, fontSize = 11.sp) } }
        (1..28).chunked(7).forEach { week -> Row(Modifier.fillMaxWidth()) { week.forEach { d -> Box(Modifier.weight(1f).padding(4.dp).height(34.dp), contentAlignment = Alignment.Center) { Text(if (d == 17) "●\n$d" else d.toString(), textAlign = TextAlign.Center, color = if (d == 17) Blue else TextWhite, fontSize = 12.sp) } } } }
    }
}

@Composable private fun WorkoutDetail(state: CoachState) {
    val w = state.selectedWorkout()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("Detalhes do treino", true) { state.selectedScreen = Screen.CALENDAR }
        if (w == null) {
            CardBlock("Plano ainda não criado", "Complete o perfil", "O treinador precisa dos seus dados para prescrever.")
            return@Column
        }
        Card(Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(containerColor = CardBlue)) {
            Text("🏃  ${w.type.uppercase()}", color = Blue2, fontWeight = FontWeight.Bold)
            Text(w.title, fontSize = 26.sp, fontWeight = FontWeight.Black)
            Text(w.date, color = TextMuted)
            Spacer(Modifier.height(14.dp))
            InfoRow("Objetivo", w.objective)
            InfoRow("Estímulo", w.stimulus)
            InfoRow("Volume estimado", "${w.distanceKm} km")
            InfoRow("Dose", w.detail)
        }
        ListButton("Estrutura do treino") { state.selectedScreen = Screen.STRUCTURE }
        ListButton("Por que este treino?") {}
        ListButton("Como ele se encaixa no plano?") {}
        PrimaryButton("Exportar para Pace Coach") { state.selectedScreen = Screen.EXPORT }
    }
}

@Composable private fun StructureScreen(state: CoachState) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("Estrutura do treino", true) { state.selectedScreen = Screen.WORKOUT }
        val w = state.selectedWorkout()
        if (w == null) {
            NoteBlock("Selecione um treino no calendário para visualizar a estrutura prescrita.")
            return@Column
        }
        StructureBlock("1", "Aquecimento", "Leve • RPE 2–3", "Preparação aeróbia. O motor não inventa pace sem dados suficientes.")
        StructureBlock("2", w.title, w.detail, "Estímulo ${w.stimulus} • ${w.paceMode} • RPE ${w.rpeRange}")
        StructureBlock("3", "Desaquecimento", "Leve", "Reduzir gradualmente o esforço após o bloco principal.")
        NoteBlock(w.rationale)
    }
}

@Composable
private fun StructureBlock(n: String, title: String, dose: String, desc: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 5.dp),
        colors = CardDefaults.cardColors(containerColor = CardBlue)
    ) {
        Row(Modifier.padding(16.dp)) {
            Text(
                text = n,
                modifier = Modifier.width(36.dp),
                color = Blue,
                fontSize = 25.sp,
                fontWeight = FontWeight.Black
            )
            Column {
                Text(text = title, fontWeight = FontWeight.Bold)
                Text(
                    text = dose,
                    fontSize = 19.sp,
                    color = Blue2,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = desc,
                    color = TextMuted,
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            color = TextMuted,
            fontSize = 12.sp,
            modifier = Modifier.weight(0.42f)
        )
        Text(
            text = value,
            color = TextWhite,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.End,
            modifier = Modifier.weight(0.58f)
        )
    }
}

@Composable
private fun ListButton(text: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 5.dp)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = CardBlue),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 15.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = text,
                color = TextWhite,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = "›",
                color = TextMuted,
                fontSize = 22.sp
            )
        }
    }
}

@Composable private fun NoteBlock(text: String) { Card(Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF0E3144))) { Text("ⓘ  $text", Modifier.padding(14.dp), color = Blue2, fontSize = 12.sp) } }

@Composable private fun PlanScreen(state: CoachState) {
    LazyColumnLike {
        Header("Plano de treinos")
        CardBlock("${state.goal}", "${state.planWeeks} semanas", state.motorDecision?.rationale ?: "Plano gerado pelo motor de prescrição.")
        state.motorDecision?.let { d ->
            CardBlock("Decisão do motor", "${d.action} • ${d.stimulus}", "Necessidade: ${d.necessity} • Confiança: ${String.format(Locale.US, "%.0f", d.confidence * 100)}%")
        }
        listOf("Semana 1 — Adaptação", "Semana 2 — Consolidação", "Semana 3 — Progressão", "Semana 4 — Consolidação").forEachIndexed { i, t ->
            ListButton("${i + 1}.  $t") { if (i == 0) state.selectedScreen = Screen.CALENDAR }
        }
        val weeklyKm = state.workouts.sumOf { it.distanceKm }
        Row(Modifier.fillMaxWidth().padding(20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricCard("Volume", "${String.format(Locale.US, "%.1f", weeklyKm)} km", "▥", Blue2, Modifier.weight(1f)); MetricCard("Treinos", "${state.workouts.size}", "✓", Green, Modifier.weight(1f)) }
    }
}

@Composable private fun EvolutionScreen() {
    LazyColumnLike {
        Header("Evolução")
        Segmented("Semanas", "Meses", "Anos")
        ChartCard("Volume semanal (km)", listOf(24, 28, 27, 34, 38, 42))
        ChartCard("Fitness estimado", listOf(45, 47, 48, 51, 53, 55))
        NoteBlock("Evolução consistente! Seu volume e condicionamento estão em progresso.")
    }
}

@Composable private fun ChartCard(title: String, values: List<Int>) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 7.dp), colors = CardDefaults.cardColors(containerColor = CardBlue)) {
        Column(Modifier.padding(16.dp)) { Text(title, fontWeight = FontWeight.Bold); Spacer(Modifier.height(18.dp)); Row(Modifier.fillMaxWidth().height(90.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) { values.forEach { v -> Box(Modifier.weight(1f).height((v * 1.4).dp).background(Blue, RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))) } } }
    }
}

@Composable private fun Segmented(vararg labels: String) { Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) { labels.forEachIndexed { i, label -> Box(Modifier.weight(1f).clip(RoundedCornerShape(9.dp)).background(if (i == 0) Blue else CardBlue).padding(10.dp), contentAlignment = Alignment.Center) { Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold) } } } }

@Composable private fun FeedbackScreen(state: CoachState) {
    var effort by remember { mutableStateOf("Leve") }
    var feeling by remember { mutableStateOf("Bem") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("Feedback do treino", true) { state.selectedScreen = Screen.HISTORY }
        Text("Sex, 17 de Abril", color = TextMuted, modifier = Modifier.padding(horizontal = 20.dp))
        Spacer(Modifier.height(18.dp)); FeedbackGroup("Como foi o treino?", listOf("Muito leve","Leve","Ok","Pesado","Muito pesado"), effort) { effort = it }
        FeedbackGroup("Como você se sentiu?", listOf("Ótimo","Bem","Cansado","Muito cansado"), feeling) { feeling = it }
        OutlinedTextField("", {}, label = { Text("Observações (opcional)") }, modifier = Modifier.fillMaxWidth().padding(16.dp), minLines = 4, colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color(0xFF35536A)))
        PrimaryButton(if (state.feedbackSaved) "Feedback salvo ✓" else "Salvar feedback") { state.feedbackSaved = true; state.selectedScreen = Screen.DASHBOARD }
    }
}

@Composable private fun FeedbackGroup(title: String, options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Text(title, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)); Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) { options.forEach { o -> Box(Modifier.clip(RoundedCornerShape(18.dp)).background(if (o == selected) Blue else CardBlue).clickable { onSelect(o) }.padding(horizontal = 13.dp, vertical = 9.dp)) { Text(o, fontSize = 11.sp) } } }
}

@Composable private fun HistoryScreen(state: CoachState) {
    LazyColumnLike { Header("Histórico de treinos"); state.workouts.forEach { w -> WorkoutCard(w) { state.selectWorkout(w); state.selectedScreen = Screen.FEEDBACK } }; ListButton("Ver mais resultados") {} }
}

@Composable private fun ProfileScreen(state: CoachState) {
    LazyColumnLike {
        Header("Perfil / Configurações", true) { state.selectedScreen = Screen.DASHBOARD }
        CardBlock(state.name, state.level, "Objetivo: ${state.goal}")
        ListButton("Dados pessoais") {}
        ListButton("Objetivos") {}
        ListButton("Disponibilidade") {}
        ListButton("Preferências") {}
        ListButton("Conexão com Pace Coach") { state.selectedScreen = Screen.EXPORT }
        ListButton("Notificações") {}
        ListButton("Privacidade") {}
        ListButton("Ajuda e suporte") {}
    }
}

@Composable private fun ExportScreen(state: CoachState) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("Exportar para Pace Coach", true) { state.selectedScreen = Screen.WORKOUT }
        BigRunnerMark()
        Text("Enviar treino para o Pace Coach", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterHorizontally))
        Spacer(Modifier.height(20.dp))
        StepExport("1", "Treino selecionado", state.selectedWorkout()?.let { "${it.title} • ${it.date}" } ?: "Nenhum treino selecionado")
        StepExport("2", "Revise os dados", state.selectedWorkout()?.let { "${it.distanceKm} km • ${it.durationMin} min • RPE ${it.rpeRange}" } ?: "Estrutura da prescrição")
        StepExport("3", "Enviar para o Pace Coach", "A prescrição será transferida para execução no Pace Coach.")
        PrimaryButton("Exportar agora") { state.selectedScreen = Screen.DASHBOARD }
    }
}

@Composable
private fun StepExport(n: String, title: String, desc: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp, 6.dp),
        colors = CardDefaults.cardColors(containerColor = CardBlue)
    ) {
        Row(Modifier.padding(16.dp)) {
            Text(
                text = n,
                modifier = Modifier.width(34.dp),
                color = Blue,
                fontSize = 24.sp,
                fontWeight = FontWeight.Black
            )
            Column {
                Text(text = title, fontWeight = FontWeight.Bold)
                Text(
                    text = desc,
                    color = TextMuted,
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable private fun BottomNav(state: CoachState) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(72.dp)
            .background(Color(0xFF071522)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        NavItem(Modifier.weight(1f), "⌂", "Início", state.selectedScreen == Screen.DASHBOARD) { state.selectedScreen = Screen.DASHBOARD }
        NavItem(Modifier.weight(1f), "▦", "Calendário", state.selectedScreen == Screen.CALENDAR) { state.selectedScreen = Screen.CALENDAR }
        NavItem(Modifier.weight(1f), "☷", "Plano", state.selectedScreen == Screen.PLAN) { state.selectedScreen = Screen.PLAN }
        NavItem(Modifier.weight(1f), "↗", "Evolução", state.selectedScreen == Screen.EVOLUTION) { state.selectedScreen = Screen.EVOLUTION }
        NavItem(Modifier.weight(1f), "⋯", "Mais", state.selectedScreen == Screen.PROFILE) { state.selectedScreen = Screen.PROFILE }
    }
}

@Composable private fun NavItem(modifier: Modifier, icon: String, label: String, selected: Boolean, onClick: () -> Unit) {
    Column(
        modifier = modifier
            .fillMaxHeight()
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = icon,
            fontSize = 20.sp,
            color = if (selected) Blue else TextMuted
        )
        Text(
            text = label,
            fontSize = 9.sp,
            color = if (selected) Blue else TextMuted,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

@Composable private fun PrimaryButton(text: String, enabled: Boolean = true, onClick: () -> Unit) { Button(onClick = onClick, enabled = enabled, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(52.dp), shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.buttonColors(containerColor = Blue)) { Text(text, fontWeight = FontWeight.Bold) } }

@Composable private fun LazyColumnLike(content: @Composable ColumnScope.() -> Unit) { Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), content = content) }
