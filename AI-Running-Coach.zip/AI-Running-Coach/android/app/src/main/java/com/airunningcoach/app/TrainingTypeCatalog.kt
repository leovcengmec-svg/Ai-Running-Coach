package com.airunningcoach.app

internal data class TrainingTypeDefinition(
    val id: String,
    val title: String,
    val zone: String,
    val objective: String,
    val structure: String,
    val use: String
)

/** Biblioteca de estímulos reconhecidos pelo motor. A disponibilidade depende do histórico e do ciclo. */
internal object TrainingTypeCatalog {
    val all = listOf(
        TrainingTypeDefinition("RUN_WALK", "Corrida/caminhada", "Z1–Z2", "Construir tolerância à corrida com pausas planejadas", "Alternância por tempo entre corrida leve e caminhada, com aquecimento e desaquecimento", "Iniciantes ou atletas retornando após pausa; normalmente até três sessões semanais com dias de recuperação"),
        TrainingTypeDefinition("RECOVERY", "Rodagem regenerativa", "Z1", "Facilitar a recuperação entre sessões", "Corrida curta, contínua e muito confortável", "Após qualidade, em semana regenerativa ou quando a recuperação pedir redução"),
        TrainingTypeDefinition("EASY_AEROBIC", "Rodagem aeróbia", "Z2", "Construir consistência e base aeróbia", "Corrida contínua em ritmo conversável", "Sessão mais frequente do plano"),
        TrainingTypeDefinition("LONG_RUN", "Longão aeróbio", "Z2", "Desenvolver resistência prolongada", "Sessão contínua mais longa da semana", "Quando o histórico recente sustentar a duração"),
        TrainingTypeDefinition("STEADY_RUN", "Corrida moderada", "Z3", "Sustentar ritmo moderado sem atingir o limiar", "Bloco contínuo ou progressivo", "Corredores com base e recuperação adequadas"),
        TrainingTypeDefinition("TEMPO_RUN", "Tempo controlado (Z4 estimada)", "Z4", "Desenvolver tolerância ao esforço sustentado", "Aquecimento, bloco contínuo controlado e desaquecimento; pace e RPE se complementam", "Quando a carga e a experiência permitirem; Z4 não confirma LT2 medido"),
        TrainingTypeDefinition("THRESHOLD_INTERVAL", "Intervalos controlados (Z4 estimada)", "Z4", "Acumular tempo de qualidade próximo do esforço de limiar estimado", "Repetições controladas com recuperação leve", "Alternativa ao tempo contínuo; a faixa não substitui avaliação fisiológica"),
        TrainingTypeDefinition("VO2_MAX_INTERVAL", "Intervalos de alta intensidade (Z5 estimada)", "Z5", "Desenvolver potência aeróbia com esforços curtos", "Repetições intensas e recuperações suficientes", "Somente para corredores experientes com tolerância documentada; Z5 não significa VO₂máx medido"),
        TrainingTypeDefinition("FARTLEK", "Fartlek", "Z2–Z4", "Variar intensidade dentro de uma corrida", "Alternância de blocos moderados/fortes e leves", "Quando houver necessidade de variar o estímulo"),
        TrainingTypeDefinition("HILL_REPEATS", "Repetições em subida", "Z3–Z4", "Desenvolver força específica e potência", "Subidas controladas por tempo ou distância; descida leve", "Somente com percurso adequado; pace não é comparável ao plano"),
        TrainingTypeDefinition("STRIDES", "Acelerações (strides)", "Técnica", "Melhorar coordenação e economia de corrida", "Acelerações curtas, soltas e com recuperação completa; não perseguir um pace específico", "Complemento ocasional em rodagem fácil, sem sprint máximo"),
        TrainingTypeDefinition("PROGRESSION_RUN", "Corrida progressiva", "Z2–Z3", "Praticar controle de ritmo sob fadiga leve", "Começar fácil e terminar moderado", "Quando o atleta já controla bem o ritmo fácil")
    )

    fun find(id: String): TrainingTypeDefinition? = all.firstOrNull { it.id == id }
}

internal data class StrengthRoutineDefinition(
    val title: String,
    val duration: String,
    val focus: String,
    val exercises: String,
    val guidance: String
)

/** Optional complementary work; these sessions are deliberately not inserted into the running calendar. */
internal object StrengthTrainingCatalog {
    val all = listOf(
        StrengthRoutineDefinition(
            "Força A — base e panturrilhas", "20–30 min", "Agachamento, quadril, panturrilhas e estabilidade do tronco",
            "Agachamento • avanço assistido • elevação de panturrilha • ponte de glúteos • prancha",
            "Comece com 1–2 séries por exercício, movimento controlado e margem de 2–3 repetições."
        ),
        StrengthRoutineDefinition(
            "Força B — unilateral e posterior", "20–30 min", "Estabilidade unilateral, posterior de coxa e controle pélvico",
            "Step-up baixo • levantamento terra romeno leve • panturrilha unilateral assistida • bird-dog • prancha lateral",
            "Use amplitude confortável, sem dor e sem chegar à falha. Como referência inicial: 8–12 repetições, 10–15 elevações de panturrilha e 20–30 s nas pranchas. Iniciantes podem alternar A e B em semanas diferentes."
        )
    )
}
