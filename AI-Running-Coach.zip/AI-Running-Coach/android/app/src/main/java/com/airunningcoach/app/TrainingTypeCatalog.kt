package com.airunningcoach.app

internal data class TrainingTypeDefinition(
    val id: String,
    val title: String,
    val zone: String,
    val objective: String,
    val structure: String,
    val use: String
)

/** Catálogo de estímulos do produto; o status de prescrição diferencia uso automático, condicional e não integrado. */
internal object TrainingTypeCatalog {
    val all = listOf(
        TrainingTypeDefinition("RUN_WALK", "Corrida/caminhada", "Z1–Z2", "Construir tolerância à corrida com pausas planejadas", "Alternância por tempo entre corrida leve e caminhada, com aquecimento e desaquecimento", "Iniciantes ou atletas retornando após pausa; normalmente até três sessões semanais com dias de recuperação"),
        TrainingTypeDefinition("RECOVERY", "Rodagem regenerativa", "Z1", "Facilitar a recuperação entre sessões", "Corrida curta, contínua e muito confortável", "Após qualidade, em semana regenerativa ou quando a recuperação pedir redução"),
        TrainingTypeDefinition("EASY_AEROBIC", "Rodagem aeróbia", "Z2", "Construir consistência e base aeróbia", "Corrida contínua em ritmo conversável", "Sessão mais frequente do plano"),
        TrainingTypeDefinition("LONG_RUN", "Longão aeróbio", "Z2", "Desenvolver resistência prolongada", "Sessão contínua mais longa da semana", "Quando o histórico recente sustentar a duração"),
        TrainingTypeDefinition("STEADY_RUN", "Corrida moderada", "Z3", "Sustentar ritmo moderado sem atingir o limiar", "Bloco contínuo ou progressivo", "Corredores com base e recuperação adequadas"),
        TrainingTypeDefinition("TEMPO_RUN", "Tempo controlado (Z4 estimada)", "Z4", "Desenvolver tolerância ao esforço sustentado", "Aquecimento, bloco contínuo controlado e desaquecimento; pace e RPE se complementam", "Quando a carga e a experiência permitirem; Z4 não confirma LT2 medido"),
        TrainingTypeDefinition("THRESHOLD_INTERVAL", "Intervalos controlados (Z4 estimada)", "Z4", "Acumular tempo de qualidade próximo do esforço de limiar estimado", "Repetições controladas com recuperação leve", "Alternativa ao tempo contínuo; a faixa não substitui avaliação fisiológica"),
        TrainingTypeDefinition("VO2_MAX_INTERVAL", "Intervalos de alta intensidade (Z5 estimada)", "Z5", "Desenvolver potência aeróbia com esforços curtos", "Repetições intensas e recuperações suficientes", "Somente para corredores experientes com tolerância documentada; Z5 não significa VO₂máx medido"),
        TrainingTypeDefinition("MARATHON_SPECIFIC", "Resistência específica de maratona", "Z2–Z3", "Construir resistência específica para a maratona sem excesso de intensidade", "Bloco aeróbio predominante em Z2 com final moderado opcional em Z3", "Selecionado em ciclos cujo objetivo principal é maratona, conforme a fase e a carga"),
        TrainingTypeDefinition("FARTLEK", "Fartlek", "Z2–Z4", "Variar intensidade dentro de uma corrida", "Alternância de blocos moderados/fortes e leves", "Quando houver necessidade de variar o estímulo"),
        TrainingTypeDefinition("HILL_REPEATS", "Repetições em subida", "Z3–Z4", "Desenvolver força específica e potência", "Subidas controladas por tempo ou distância; descida leve", "Somente com percurso adequado; pace não é comparável ao plano"),
        TrainingTypeDefinition("STRIDES", "Acelerações (strides)", "Técnica", "Melhorar coordenação e economia de corrida", "Acelerações curtas, soltas e com recuperação completa; não perseguir um pace específico", "Complemento ocasional em rodagem fácil, sem sprint máximo"),
        TrainingTypeDefinition("PROGRESSION_RUN", "Corrida progressiva", "Z2–Z3", "Praticar controle de ritmo sob fadiga leve", "Começar fácil e terminar moderado", "Quando o atleta já controla bem o ritmo fácil")
    )

    fun find(id: String): TrainingTypeDefinition? = all.firstOrNull { it.id == id }

    /** Describes actual V44 motor integration; listing an item does not imply automatic prescription. */
    fun prescriptionStatus(id: String): String = when (id) {
        "RUN_WALK" -> "Automático"
        "RECOVERY" -> "Automático"
        "EASY_AEROBIC" -> "Automático"
        "LONG_RUN" -> "Automático"
        "STEADY_RUN" -> "Condicional"
        "TEMPO_RUN" -> "Condicional"
        "THRESHOLD_INTERVAL" -> "Condicional"
        "VO2_MAX_INTERVAL" -> "Condicional"
        "MARATHON_SPECIFIC" -> "Condicional"
        "FARTLEK" -> "Condicional"
        "HILL_REPEATS" -> "Não integrado"
        "STRIDES" -> "Complementar"
        "PROGRESSION_RUN" -> "Automático"
        else -> "Não classificado"
    }

    fun prescriptionDetail(id: String): String = when (id) {
        "RUN_WALK" -> "Gerado para iniciantes ou reintrodução, em blocos alternados de corrida e caminhada, com até três sessões semanais."
        "RECOVERY" -> "Entra em semanas regenerativas ou quando os indicadores de recuperação/fadiga pedem redução de carga."
        "EASY_AEROBIC" -> "É a sessão padrão de baixa intensidade nos dias sem qualidade ou longão."
        "LONG_RUN" -> "É gerado como a maior sessão da semana, limitado pelo histórico recente e pelo objetivo."
        "STEADY_RUN" -> "Pode ser selecionado pelo motor conforme distância-alvo, fase do ciclo e elegibilidade para qualidade."
        "TEMPO_RUN" -> "Pode ser selecionado em ciclos de desenvolvimento quando volume, experiência e recuperação permitem qualidade."
        "THRESHOLD_INTERVAL" -> "Pode substituir tempo contínuo em ciclos selecionados; a Z4 é estimada, não limiar medido."
        "VO2_MAX_INTERVAL" -> "Restrito a perfis experientes e condições de carga adequadas; Z5 estimada não confirma VO₂máx medido."
        "MARATHON_SPECIFIC" -> "Entra em ciclos de maratona nas semanas de desenvolvimento específico, com Z2 predominante e trecho Z3 opcional."
        "FARTLEK" -> "Alternativa de qualidade usada em ciclos selecionados, com blocos fortes e recuperações leves."
        "HILL_REPEATS" -> "Está descrito na biblioteca, mas a versão atual do motor não gera sessões de subida automaticamente."
        "STRIDES" -> "Pode ser inserido como acelerações técnicas dentro de uma rodagem fácil; não é sessão isolada."
        "PROGRESSION_RUN" -> "É selecionado como sessão de qualidade em fases iniciais de ciclos de 5 km e 10 km."
        else -> "Uso pelo motor ainda não classificado."
    }
}

internal data class StrengthRoutineDefinition(
    val title: String,
    val duration: String,
    val focus: String,
    val exercises: String,
    val guidance: String
)

/** Optional complementary work; these sessions are deliberately not inserted into the running calendar. */
internal object StrengthTrainingCatalog {
    val all = listOf(
        StrengthRoutineDefinition(
            "Força A — base e panturrilhas", "20–30 min", "Agachamento, quadril, panturrilhas e estabilidade do tronco",
            "Agachamento • avanço assistido • elevação de panturrilha • ponte de glúteos • prancha",
            "Comece com 1–2 séries por exercício, movimento controlado e margem de 2–3 repetições."
        ),
        StrengthRoutineDefinition(
            "Força B — unilateral e posterior", "20–30 min", "Estabilidade unilateral, posterior de coxa e controle pélvico",
            "Step-up baixo • levantamento terra romeno leve • panturrilha unilateral assistida • bird-dog • prancha lateral",
            "Use amplitude confortável, sem dor e sem chegar à falha. Como referência inicial: 8–12 repetições, 10–15 elevações de panturrilha e 20–30 s nas pranchas. Iniciantes podem alternar A e B em semanas diferentes."
        )
    )
}
