package com.airunningcoach.app

internal data class TrainingTypeDefinition(
    val id: String,
    val title: String,
    val zone: String,
    val objective: String,
    val structure: String,
    val use: String
)

/** Biblioteca de estímulos reconhecidos pelo motor. A disponibilidade depende do histórico e do ciclo. */
internal object TrainingTypeCatalog {
    val all = listOf(
        TrainingTypeDefinition("RECOVERY", "Rodagem regenerativa", "Z1", "Facilitar a recuperação entre sessões", "Corrida curta, contínua e muito confortável", "Após qualidade, em semana regenerativa ou quando a recuperação pedir redução"),
        TrainingTypeDefinition("EASY_AEROBIC", "Rodagem aeróbia", "Z2", "Construir consistência e base aeróbia", "Corrida contínua em ritmo conversável", "Sessão mais frequente do plano"),
        TrainingTypeDefinition("LONG_RUN", "Longão aeróbio", "Z2", "Desenvolver resistência prolongada", "Sessão contínua mais longa da semana", "Quando o histórico recente sustentar a duração"),
        TrainingTypeDefinition("STEADY_RUN", "Corrida moderada", "Z3", "Sustentar ritmo moderado sem atingir o limiar", "Bloco contínuo ou progressivo", "Corredores com base e recuperação adequadas"),
        TrainingTypeDefinition("TEMPO_RUN", "Tempo run", "Z4", "Desenvolver tolerância ao esforço próximo do limiar", "Aquecimento, bloco contínuo controlado e desaquecimento", "Quando a carga e a experiência permitirem"),
        TrainingTypeDefinition("THRESHOLD_INTERVAL", "Intervalos de limiar", "Z4", "Acumular tempo de qualidade próximo do limiar", "Repetições controladas com recuperação leve", "Alternativa ao tempo contínuo"),
        TrainingTypeDefinition("VO2_MAX_INTERVAL", "Intervalado VO₂máx", "Z5", "Desenvolver potência aeróbia", "Repetições intensas e recuperações suficientes", "Corredores experientes com tolerância documentada"),
        TrainingTypeDefinition("FARTLEK", "Fartlek", "Z2–Z4", "Variar intensidade dentro de uma corrida", "Alternância de blocos moderados/fortes e leves", "Quando houver necessidade de variar o estímulo"),
        TrainingTypeDefinition("HILL_REPEATS", "Repetições em subida", "Z3–Z4", "Desenvolver força específica e potência", "Subidas controladas por tempo ou distância; descida leve", "Somente com percurso adequado; pace não é comparável ao plano"),
        TrainingTypeDefinition("STRIDES", "Acelerações (strides)", "Técnica", "Melhorar coordenação e economia de corrida", "Acelerações curtas, soltas e com recuperação completa; não perseguir um pace específico", "Complemento ocasional em rodagem fácil, sem sprint máximo"),
        TrainingTypeDefinition("PROGRESSION_RUN", "Corrida progressiva", "Z2–Z3", "Praticar controle de ritmo sob fadiga leve", "Começar fácil e terminar moderado", "Quando o atleta já controla bem o ritmo fácil")
    )

    fun find(id: String): TrainingTypeDefinition? = all.firstOrNull { it.id == id }
}
