package com.airunningcoach.app

import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.round

/**
 * Exporta no mesmo envelope legado UserWorkoutJson que o Pace Coach gera ao exportar
 * seus próprios treinos. Não usar o contrato interno pace-coach-workout: o receptor
 * do Pace Coach procura explicitamente a chave Garmin UserWorkoutJson.
 */
internal object PaceCoachExporter {
    const val USER_WORKOUT_JSON_KEY = "com.garmin.connect.workout.json.UserWorkoutJson"

    private const val END_CONDITION_ID = 1
    private const val UNIT_DIMENSIONLESS_PK = 6
    private const val UNIT_MILLISECONDS_PK = 41
    private const val UNIT_METERS_PK = 1
    private const val TARGET_PACE_UNIT_PK = 7

    fun workoutToJson(
        workout: PrescribedWorkout,
        @Suppress("UNUSED_PARAMETER") athleteGoal: String,
        @Suppress("UNUSED_PARAMETER") athleteGoalKm: Double?
    ): String {
        val now = gmtTimestamp()
        val workoutId = nextLegacyId()
        val stepRows = buildWorkoutSteps(workout.segments, workoutId)
        require(stepRows.isNotEmpty()) { "A prescrição não contém etapas exportáveis." }

        val userWorkout = JSONObject().apply {
            put("workoutId", workoutId)
            put("workoutName", workout.title.trim().ifBlank { "AI Running Coach" }.take(60))
            put("createdDate", now)
            put("updatedDate", now)
            // O arquivo é uma cópia independente; ownerId=0 evita atribuir o treino
            // ao identificador de conta de outra pessoa presente em arquivos de exemplo.
            put("ownerId", 0)
            put("sportTypeKey", "running")
            put("workoutSteps", JSONArray().apply { stepRows.forEach { put(it) } })
        }

        // Este wrapper é obrigatório: o receptor procura UserWorkoutJson nesta chave.
        return JSONObject().put(USER_WORKOUT_JSON_KEY, userWorkout).toString(2)
    }

    private fun buildWorkoutSteps(segments: List<WorkoutSegment>, workoutId: Long): List<JSONObject> {
        val result = mutableListOf<JSONObject>()
        var index = 0
        var stepOrder = 1
        var nextGroupId = 1

        fun addStep(segment: WorkoutSegment, groupId: Int = 0, parentGroupId: Int? = null) {
            val row = segmentToStep(segment, workoutId + stepOrder, stepOrder, groupId, parentGroupId)
            result += row
            stepOrder++
        }

        while (index < segments.size) {
            val segment = segments[index]
            if (segment.repeatCount <= 1) {
                addStep(segment)
                index++
                continue
            }

            // Segmentos adjacentes com a mesma repetição formam um único grupo.
            // Ex.: corrida 2 min + caminhada 2 min, repetidas 5 vezes.
            val repeatCount = segment.repeatCount
            val groupSegments = mutableListOf<WorkoutSegment>()
            while (index < segments.size && segments[index].repeatCount == repeatCount && repeatCount > 1) {
                groupSegments += segments[index]
                index++
            }

            val groupId = nextGroupId++
            result += JSONObject().apply {
                put("stepId", workoutId + stepOrder)
                put("stepOrder", stepOrder++)
                put("groupId", groupId)
                put("endConditionId", END_CONDITION_ID)
                put("endConditionValue", repeatCount.toDouble())
                put("endConditionUnitPk", UNIT_DIMENSIONLESS_PK)
                put("stepTypeKey", "repeat")
                put("endConditionTypeKey", "iterations")
                put("endConditionUnitKey", "dimensionless")
            }
            groupSegments.forEach { addStep(it, groupId, groupId) }
        }
        return result
    }

    private fun segmentToStep(
        segment: WorkoutSegment,
        stepId: Long,
        stepOrder: Int,
        groupId: Int,
        parentGroupId: Int?
    ): JSONObject {
        val kind = stepKind(segment)
        val hasPace = segment.targetPaceMinValue != null && segment.targetPaceMaxValue != null
        val isTime = segment.targetMode == "TIME"

        return JSONObject().apply {
            put("stepId", stepId)
            put("stepOrder", stepOrder)
            put("groupId", groupId)
            put("parentGroupId", parentGroupId ?: groupId)
            put("endConditionId", END_CONDITION_ID)

            if (isTime) {
                val durationMillis = requireNotNull(segment.durationMin) * 60_000L
                put("endConditionValue", durationMillis.toDouble())
                put("endConditionUnitPk", UNIT_MILLISECONDS_PK)
                put("endConditionTypeKey", "time")
                put("endConditionUnitKey", "ms")
                put("endConditionDisplayValue", formatDuration(durationMillis))
                put("endConditionDisplayUnit", "Hours:Minutes:Seconds")
                put("endConditionDisplayUnitAbbr", "h:m:s")
            } else {
                val distanceMeters = requireNotNull(segment.distanceKm) * 1000.0
                put("endConditionValue", round(distanceMeters * 10.0) / 10.0)
                put("endConditionUnitPk", UNIT_METERS_PK)
                put("endConditionTypeKey", "distance")
                put("endConditionUnitKey", "meter")
                put("endConditionDisplayValue", formatDistanceMeters(distanceMeters))
                put("endConditionDisplayUnit", "Meters")
                put("endConditionDisplayUnitAbbr", "m")
            }

            put("stepTypeKey", kind.stepTypeKey)
            put("intensityTypeKey", kind.intensityTypeKey)
            put("targetTypeKey", if (hasPace && kind.allowsPaceTarget) "pace.zone" else "no.target")

            if (hasPace && kind.allowsPaceTarget) {
                val fasterPaceSeconds = requireNotNull(segment.targetPaceMinValue).toDouble()
                val slowerPaceSeconds = requireNotNull(segment.targetPaceMaxValue).toDouble()
                // Garmin representa pace como velocidade em cm/ms. O primeiro valor
                // é o limite numérico inferior (pace mais lento), o segundo o superior.
                val slowerSpeed = round((100.0 / slowerPaceSeconds) * 100_000_000.0) / 100_000_000.0
                val fasterSpeed = round((100.0 / fasterPaceSeconds) * 100_000_000.0) / 100_000_000.0
                put("targetValueOne", slowerSpeed)
                put("targetOneDisplayValue", formatGarminPace(slowerPaceSeconds.toInt()))
                put("targetValueUnitPk", TARGET_PACE_UNIT_PK)
                put("targetValueTwo", fasterSpeed)
                put("targetTwoDisplayValue", formatGarminPace(fasterPaceSeconds.toInt()))
                put("targetValueDisplayUnit", "Minutes per Kilometer")
                put("targetValueDisplayUnitAbbr", "min/km")
                put("targetValueUnitKey", "centimetersPerMillisecond")
            } else {
                put("targetValueUnitPk", UNIT_DIMENSIONLESS_PK)
                put("targetValueUnitKey", "dimensionless")
            }
        }
    }

    private data class StepKind(
        val stepTypeKey: String,
        val intensityTypeKey: String,
        val allowsPaceTarget: Boolean
    )

    private fun stepKind(segment: WorkoutSegment): StepKind {
        val name = segment.name.lowercase(Locale.ROOT)
        return when {
            "desaquecimento" in name || "cooldown" in name || "volta à calma" in name ->
                StepKind("cooldown", "cooldown", true)
            "aquecimento" in name || "warm up" in name || "warmup" in name ->
                StepKind("warmup", "warmup", true)
            "recupera" in name || "caminhada" in name || "descanso" in name || "pausa" in name ->
                StepKind("rest", "rest", false)
            else -> StepKind("interval", "active", true)
        }
    }

    private fun formatDuration(durationMillis: Long): String {
        val totalSeconds = (durationMillis / 1000L).coerceAtLeast(0L)
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
    }

    private fun formatGarminPace(totalSeconds: Int): String {
        val safe = totalSeconds.coerceAtLeast(0)
        return String.format(Locale.US, "%02d:%02d", safe / 60, safe % 60)
    }

    private fun formatDistanceMeters(distanceMeters: Double): String =
        if (distanceMeters % 1.0 == 0.0) distanceMeters.toLong().toString()
        else String.format(Locale.US, "%.1f", distanceMeters)

    private fun gmtTimestamp(): String {
        val formatter = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S 'GMT'", Locale.US)
        formatter.timeZone = TimeZone.getTimeZone("GMT")
        return formatter.format(Date())
    }

    private fun nextLegacyId(): Long = 100_000_000L + (System.currentTimeMillis() % 900_000_000L)
}
