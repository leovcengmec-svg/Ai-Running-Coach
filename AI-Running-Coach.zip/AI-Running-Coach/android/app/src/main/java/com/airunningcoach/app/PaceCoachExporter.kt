package com.airunningcoach.app

import org.json.JSONArray
import org.json.JSONObject

/** Contrato JSON versionado para compartilhar uma prescrição com o Pace Coach. */
internal object PaceCoachExporter {
    const val CONTRACT_VERSION = "1.0"

    fun workoutToJson(workout: PrescribedWorkout, athleteGoal: String, athleteGoalKm: Double?): String = JSONObject().apply {
        put("contract", "pace-coach-workout")
        put("contractVersion", CONTRACT_VERSION)
        put("source", "AI Running Coach")
        put("sessionId", workout.sessionId)
        put("title", workout.title)
        put("dateLabel", workout.date)
        put("scheduledDate", workout.scheduledDateIso)
        put("week", workout.week)
        put("phase", workout.phase)
        put("goal", athleteGoal)
        if (athleteGoalKm != null) put("goalDistanceKm", athleteGoalKm)
        put("workoutType", workout.type)
        put("objective", workout.objective)
        put("stimulus", workout.stimulus)
        put("distanceKm", workout.distanceKm)
        put("estimatedDurationMinutes", workout.durationMin)
        put("durationEstimateBasis", "Estimativa geral de 7 min/km; não é pace-alvo individual.")
        put("durationEstimateIsIndividualized", false)
        put("intensity", workout.intensity)
        put("targetMode", workout.paceMode)
        put("targetRpe", workout.rpeRange)
        put("rationale", workout.rationale)
        put("segments", JSONArray().apply {
            workout.segments.forEach { segment ->
                put(JSONObject().apply {
                    put("name", segment.name)
                    put("instruction", segment.instruction)
                    segment.durationMin?.let { put("durationMinutes", it) }
                    segment.distanceKm?.let { put("distanceKm", it) }
                    put("intensity", segment.intensity)
                    put("rpe", segment.rpeRange)
                    put("repeatCount", segment.repeatCount)
                })
            }
        })
    }.toString(2)
}
