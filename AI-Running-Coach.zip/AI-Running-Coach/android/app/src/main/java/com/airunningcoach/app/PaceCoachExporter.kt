package com.airunningcoach.app

import org.json.JSONArray
import org.json.JSONObject

/** Contract 5.0: distances are km; every pace is formatted as mm:ss min/km. */
internal object PaceCoachExporter {
    const val CONTRACT_VERSION = "5.0"

    private val zoneNames = mapOf(
        "Z1" to "Regenerativa",
        "Z2" to "Aeróbia",
        "Z3" to "Moderada",
        "Z4" to "Limiar estimado",
        "Z5" to "VO₂máx estimado"
    )
    private val zoneBands = mapOf(
        "Z1" to "R0 • 43–56% da VAM estimada",
        "Z2" to "R1 • 57–68% da VAM estimada",
        "Z3" to "R2 • 69–79% da VAM estimada",
        "Z4" to "R3 • 80–93% da VAM estimada",
        "Z5" to "R3+ • 94–105% da VAM estimada"
    )
    private val rangePattern = Regex("^(\\d{1,2}:\\d{2})–(\\d{1,2}:\\d{2}) min/km$")

    fun workoutToJson(
        workout: PrescribedWorkout,
        athleteGoal: String,
        athleteGoalKm: Double?
    ): String {
        // Always export the calibration snapshot attached to the workout. A later Cooper
        // must not silently rewrite the zones of an older, already prescribed session.
        val calibration = workout.paceCalibrationSnapshot
        val hasCurrentCalibration = calibration != null &&
            calibration.modelVersion == PaceCalculator.ZONE_MODEL_VERSION &&
            calibration.zoneRanges.keys.containsAll(zoneNames.keys) &&
            calibration.estimatedMasPaceMmSs.isNotBlank() &&
            calibration.estimatedSvt2PaceMmSs.isNotBlank()
        val hasLegacyCalibration = calibration != null && calibration.zoneRanges.keys.containsAll(zoneNames.keys) && !hasCurrentCalibration

        return JSONObject().apply {
            put("contract", "pace-coach-workout")
            put("contractVersion", CONTRACT_VERSION)
            put("source", "AI Running Coach")
            put("distanceUnit", "km")
            put("paceUnit", "min/km")
            put("paceFormat", "mm:ss")
            put("paceZoneModelVersion", when {
                hasCurrentCalibration -> PaceCalculator.ZONE_MODEL_VERSION
                hasLegacyCalibration -> calibration!!.modelVersion
                else -> "NOT_CALIBRATED"
            })
            put("sessionId", workout.sessionId)
            put("title", workout.title)
            put("dateLabel", workout.date)
            put("scheduledDate", workout.scheduledDateIso)
            put("week", workout.week)
            put("phase", workout.phase)
            put("goal", athleteGoal)
            if (athleteGoalKm != null) put("goalDistanceKm", athleteGoalKm)
            put("workoutType", workout.type)
            put("workoutStimulus", workout.stimulus)
            put("objective", workout.objective)
            put("stimulus", workout.stimulus)
            put("estimatedDistanceKm", workout.distanceKm)
            put("estimatedDurationMinutes", workout.durationMin)
            put("distanceEstimateBasis", "Soma das distâncias dos blocos e das contribuições estimadas dos blocos por tempo.")
            put("intensity", workout.intensity)
            put("executionTarget", JSONObject().apply {
                put("mode", "SEGMENTED")
                put("sourceOfTruth", "segments[].target")
                put("note", "Cada bloco define execução por tempo ou distância. Distâncias e durações totais são estimativas.")
            })
            put("paceTargetStatus", when {
                hasCurrentCalibration -> "CALIBRATED"
                hasLegacyCalibration -> "LEGACY_CALIBRATION_REVIEW"
                else -> "AWAITING_COOPER_TEST"
            })
            put("paceMethod", when {
                hasCurrentCalibration -> PaceCalculator.CALIBRATION_METHOD
                hasLegacyCalibration -> "LEGACY_ZONE_MODEL_REVIEW_REQUIRED"
                else -> "NOT_CALIBRATED"
            })

            if (hasCurrentCalibration) {
                val snapshot = calibration!!
                put("paceZones", JSONArray().apply {
                    listOf("Z1", "Z2", "Z3", "Z4", "Z5").forEach { zoneId ->
                        val range = snapshot.zoneRanges[zoneId] ?: return@forEach
                        val parts = rangePattern.matchEntire(range)?.groupValues
                        if (parts == null || parts.size != 3) return@forEach
                        put(JSONObject().apply {
                            put("id", zoneId)
                            put("name", zoneNames[zoneId])
                            put("modelVersion", snapshot.modelVersion)
                            put("unit", "min/km")
                            put("format", "mm:ss")
                            put("faster", parts[1])
                            put("slower", parts[2])
                            put("range", range)
                            put("intensityBand", zoneBands[zoneId])
                        })
                    }
                })
                put("paceReference", JSONObject().apply {
                    put("type", "COOPER_12_MIN")
                    put("distanceKm", snapshot.distanceKm)
                    put("durationMinutes", 12)
                    put("durationLabel", "12 min")
                    put("averagePace", snapshot.averagePaceMmSs)
                    put("estimatedVo2Max", snapshot.estimatedVo2Max)
                    put("estimatedMasPace", snapshot.estimatedMasPaceMmSs)
                    put("estimatedSecondThresholdPace", snapshot.estimatedSvt2PaceMmSs)
                    put("assessmentDate", snapshot.assessmentDateIso)
                    put("paceUnit", "min/km")
                    put("paceFormat", "mm:ss")
                    put("zoneFramework", "CEREZUELA_ESPEJO_2018_FIVE_ZONE_AUTHOR_PROPOSAL")
                    put("cooperRegression", "AUGMENTED_COOPER_2022")
                    put("note", "Estimativas de campo combinando regressões Cooper de 2022 e faixas relativas de cinco zonas propostas em 2018. Não substituem avaliação laboratorial; valide a resposta individual.")
                })
            } else if (hasLegacyCalibration) {
                put("calibrationNote", "Esta sessão foi criada com um modelo anterior de zonas. Revise e recrie o plano para gerar prescrições com o modelo atual.")
            }

            put("paceMode", workout.paceMode)
            put("effortGuidance", JSONObject().apply {
                put("type", "RPE")
                put("range", workout.rpeRange)
                put("role", "SECONDARY_GUARDRAIL_NOT_EXECUTION_TARGET")
            })
            put("rationale", workout.rationale)
            put("segments", JSONArray().apply {
                workout.segments.forEach { segment ->
                    put(JSONObject().apply {
                        put("name", segment.name)
                        put("instruction", segment.instruction)
                        put("target", JSONObject().apply {
                            put("mode", segment.targetMode)
                            if (segment.targetMode == "TIME") {
                                segment.durationMin?.let { put("value", it); put("unit", "min") }
                            } else {
                                segment.distanceKm?.let { put("value", it); put("unit", "km") }
                            }
                        })
                        if (segment.targetMode == "TIME") {
                            segment.durationMin?.let { put("durationMinutes", it) }
                            segment.distanceKm?.let { put("estimatedDistanceKm", it) }
                        } else {
                            segment.distanceKm?.let { put("distanceKm", it) }
                        }
                        segment.paceZone?.let { put("paceZone", it) }
                        if (segment.targetPaceMinValue != null && segment.targetPaceMaxValue != null) {
                            val target = ((segment.targetPaceMinValue + segment.targetPaceMaxValue) / 2.0).toInt()
                            put("paceTarget", JSONObject().apply {
                                put("unit", "min/km")
                                put("format", "mm:ss")
                                put("faster", PaceRange.format(segment.targetPaceMinValue))
                                put("slower", PaceRange.format(segment.targetPaceMaxValue))
                                put("target", PaceRange.format(target))
                                put("range", "${PaceRange.format(segment.targetPaceMinValue)}–${PaceRange.format(segment.targetPaceMaxValue)} min/km")
                            })
                        }
                        put("intensity", segment.intensity)
                        put("rpeGuidance", JSONObject().apply {
                            put("range", segment.rpeRange)
                            put("role", "SECONDARY_GUARDRAIL_NOT_EXECUTION_TARGET")
                        })
                        put("repeatCount", segment.repeatCount)
                    })
                }
            })
        }.toString(2)
    }
}
