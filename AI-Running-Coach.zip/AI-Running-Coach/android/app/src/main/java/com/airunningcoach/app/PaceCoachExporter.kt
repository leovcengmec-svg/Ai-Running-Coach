package com.airunningcoach.app

import org.json.JSONArray
import org.json.JSONObject

/** Contract 6.0: distances are km; every pace is formatted as mm:ss min/km. */
internal object PaceCoachExporter {
    const val CONTRACT_VERSION = "6.0"

    private val zoneNames = mapOf(
        "Z1" to "Regenerativa",
        "Z2" to "Aeróbia confortável",
        "Z3" to "Moderada",
        "Z4" to "Limiar estimado",
        "Z5" to "Alta intensidade estimada"
    )
    private val zoneBands = mapOf(
        "Z1" to "60–70% da velocidade média do Cooper",
        "Z2" to "70–80% da velocidade média do Cooper",
        "Z3" to "80–90% da velocidade média do Cooper",
        "Z4" to "90–100% da velocidade média do Cooper",
        "Z5" to "Alta intensidade • referência auxiliar de VAM estimada quando plausível"
    )
    private val rangePattern = Regex("^(\\d{1,2}:\\d{2})–(\\d{1,2}:\\d{2}) min/km$")

    fun workoutToJson(
        workout: PrescribedWorkout,
        athleteGoal: String,
        athleteGoalKm: Double?
    ): String {
        // Always export the calibration snapshot attached to the workout. A later Cooper
        // must not silently rewrite the zones of an older, already prescribed session.
        val calibration = workout.paceCalibrationSnapshot
        val hasCurrentCalibration = calibration != null &&
            calibration.modelVersion == PaceCalculator.ZONE_MODEL_VERSION &&
            calibration.zoneRanges.keys.containsAll(zoneNames.keys) &&
            calibration.estimatedMasPaceMmSs.isNotBlank() &&
            calibration.estimatedSvt2PaceMmSs.isNotBlank()
        val hasLegacyCalibration = calibration != null && calibration.zoneRanges.keys.containsAll(zoneNames.keys) && !hasCurrentCalibration

        return JSONObject().apply {
            put("contract", "pace-coach-workout")
            put("contractVersion", CONTRACT_VERSION)
            put("source", "AI Running Coach")
            put("distanceUnit", "km")
            put("paceUnit", "min/km")
            put("paceFormat", "mm:ss")
            put("paceZoneModelVersion", when {
                hasCurrentCalibration -> PaceCalculator.ZONE_MODEL_VERSION
                hasLegacyCalibration -> calibration!!.modelVersion
                else -> "NOT_CALIBRATED"
            })
            put("sessionId", workout.sessionId)
            put("title", workout.title)
            put("dateLabel", workout.date)
            put("scheduledDate", workout.scheduledDateIso)
            put("week", workout.week)
            put("phase", workout.phase)
            put("goal", athleteGoal)
            if (athleteGoalKm != null) put("goalDistanceKm", athleteGoalKm)
            put("workoutType", workout.type)
            put("workoutStimulus", workout.stimulus)
            put("objective", workout.objective)
            put("stimulus", workout.stimulus)
            put("estimatedDistanceKm", workout.distanceKm)
            put("estimatedDurationMinutes", workout.durationMin)
            put("distanceEstimateBasis", "Soma das distâncias dos blocos e das contribuições estimadas dos blocos por tempo.")
            put("intensity", workout.intensity)
            put("executionTarget", JSONObject().apply {
                put("mode", "SEGMENTED")
                put("sourceOfTruth", "segments[].target")
                put("note", "Cada bloco define execução por tempo ou distância. Distâncias e durações totais são estimativas.")
            })
            put("paceTargetStatus", when {
                hasCurrentCalibration -> "CALIBRATED"
                hasLegacyCalibration -> "LEGACY_CALIBRATION_REVIEW"
                else -> "AWAITING_COOPER_TEST"
            })
            put("paceMethod", when {
                hasCurrentCalibration -> PaceCalculator.CALIBRATION_METHOD
                hasLegacyCalibration -> "LEGACY_ZONE_MODEL_REVIEW_REQUIRED"
                else -> "NOT_CALIBRATED"
            })

            if (hasCurrentCalibration) {
                val snapshot = calibration!!
                put("paceZones", JSONArray().apply {
                    listOf("Z1", "Z2", "Z3", "Z4", "Z5").forEach { zoneId ->
                        val range = snapshot.zoneRanges[zoneId] ?: return@forEach
                        val parts = rangePattern.matchEntire(range)?.groupValues
                        if (parts == null || parts.size != 3) return@forEach
                        put(JSONObject().apply {
                            put("id", zoneId)
                            put("name", zoneNames[zoneId])
                            put("modelVersion", snapshot.modelVersion)
                            put("unit", "min/km")
                            put("format", "mm:ss")
                            put("faster", parts[1])
                            put("slower", parts[2])
                            put("range", range)
                            val z5UsesMasReference = zoneId == "Z5" &&
                                snapshot.zoneRanges["Z5"]?.startsWith("${snapshot.estimatedMasPaceMmSs}–") == true
                            val bandLabel = when {
                                zoneId == "Z5" && z5UsesMasReference -> "Z5 • limite rápido usa VAM estimada como referência auxiliar; não é VO₂máx medido"
                                zoneId == "Z5" -> "Z5 • banda alta conservadora do Cooper; não é VO₂máx medido"
                                snapshot.z2CalibrationStatus == "TALK_TEST_CONFIRMED" -> when (zoneId) {
                                    "Z1" -> "Regenerativa; margem individual abaixo da fronteira aeróbia"
                                    "Z2" -> "Faixa aeróbia individual refinada pelo teste da fala"
                                    "Z3" -> "Moderada; acima da fronteira aeróbia individual"
                                    else -> zoneBands[zoneId]
                                }
                                else -> zoneBands[zoneId]
                            }
                            put("intensityBand", bandLabel)
                            val percentageBasis = when {
                                snapshot.z2CalibrationStatus == "TALK_TEST_CONFIRMED" && zoneId in setOf("Z1", "Z2", "Z3") -> "COOPER_BASELINE_REFINED_BY_TALK_TEST"
                                zoneId == "Z5" && z5UsesMasReference -> "COOPER_REGRESSION_ESTIMATED_MAS_REFERENCE_NOT_LAB_MEASURED"
                                zoneId == "Z5" -> "COOPER_CONSERVATIVE_HIGH_INTENSITY_REFERENCE_NOT_VO2MAX"
                                else -> "COOPER_AVERAGE_SPEED_NOT_VO2MAX"
                            }
                            put("percentageBasis", percentageBasis)
                        })
                    }
                })
                put("z2Calibration", JSONObject().apply {
                    put("status", snapshot.z2CalibrationStatus)
                    put("method", if (snapshot.z2CalibrationStatus == "TALK_TEST_CONFIRMED") "TWO_OR_MORE_CONSISTENT_TALK_TEST_OBSERVATIONS" else "COOPER_SPEED_BASELINE")
                    put("evidenceCount", snapshot.talkTestEvidenceCount)
                    if (snapshot.talkTestReferencePaceMmSs.isNotBlank()) {
                        put("comfortableSpeechReferencePace", snapshot.talkTestReferencePaceMmSs)
                        put("paceUnit", "min/km")
                        put("paceFormat", "mm:ss")
                    }
                })
                put("paceReference", JSONObject().apply {
                    put("type", "COOPER_12_MIN")
                    put("distanceKm", snapshot.distanceKm)
                    put("durationMinutes", 12)
                    put("durationLabel", "12 min")
                    put("averagePace", snapshot.averagePaceMmSs)
                    put("estimatedVo2Max", snapshot.estimatedVo2Max)
                    put("estimatedMasPace", snapshot.estimatedMasPaceMmSs)
                    put("estimatedSecondThresholdPace", snapshot.estimatedSvt2PaceMmSs)
                    put("assessmentDate", snapshot.assessmentDateIso)
                    put("paceUnit", "min/km")
                    put("paceFormat", "mm:ss")
                    put("zoneFramework", if (snapshot.z2CalibrationStatus == "TALK_TEST_CONFIRMED") "COOPER_OPERATIONAL_ZONES_WITH_TALK_TEST_Z2_REFINEMENT_AND_ESTIMATED_Z5_REFERENCE" else "COOPER_OPERATIONAL_ZONES_WITH_ESTIMATED_Z5_REFERENCE")
                    put("zonePercentageBasis", "Z1_Z4_COOPER_AVERAGE_SPEED_NOT_PERCENT_VO2MAX;Z5_ESTIMATED_MAS_OR_CONSERVATIVE_COOPER_REFERENCE")
                    put("cooperRegression", "AUGMENTED_COOPER_2022_SUPPORTING_ESTIMATES_ONLY")
                    put("note", "Z1–Z4 são faixas operacionais de campo derivadas da velocidade média do Cooper; Z2 pode ser refinada pelo teste da fala. Z5 pode usar a VAM estimada como limite rápido auxiliar quando a regressão é plausível, ou a banda conservadora do Cooper. Nenhuma faixa confirma VO2max ou limiar medido em laboratório.")
                })
            } else if (hasLegacyCalibration) {
                put("calibrationNote", "Esta sessão foi criada com um modelo anterior de zonas. Revise e recrie o plano para gerar prescrições com o modelo atual.")
            }

            put("paceMode", workout.paceMode)
            put("effortGuidance", JSONObject().apply {
                put("type", "RPE")
                put("range", workout.rpeRange)
                put("role", "SECONDARY_GUARDRAIL_NOT_EXECUTION_TARGET")
            })
            put("rationale", workout.rationale)
            put("segments", JSONArray().apply {
                workout.segments.forEach { segment ->
                    put(JSONObject().apply {
                        put("name", segment.name)
                        put("instruction", segment.instruction)
                        put("target", JSONObject().apply {
                            put("mode", segment.targetMode)
                            if (segment.targetMode == "TIME") {
                                segment.durationMin?.let { put("value", it); put("unit", "min") }
                            } else {
                                segment.distanceKm?.let { put("value", it); put("unit", "km") }
                            }
                        })
                        if (segment.targetMode == "TIME") {
                            segment.durationMin?.let { put("durationMinutes", it) }
                            segment.distanceKm?.let { put("estimatedDistanceKm", it) }
                        } else {
                            segment.distanceKm?.let { put("distanceKm", it) }
                        }
                        segment.paceZone?.let { put("paceZone", it) }
                        if (segment.targetPaceMinValue != null && segment.targetPaceMaxValue != null) {
                            val target = ((segment.targetPaceMinValue + segment.targetPaceMaxValue) / 2.0).toInt()
                            put("paceTarget", JSONObject().apply {
                                put("unit", "min/km")
                                put("format", "mm:ss")
                                put("faster", PaceRange.format(segment.targetPaceMinValue))
                                put("slower", PaceRange.format(segment.targetPaceMaxValue))
                                put("target", PaceRange.format(target))
                                put("range", "${PaceRange.format(segment.targetPaceMinValue)}–${PaceRange.format(segment.targetPaceMaxValue)} min/km")
                            })
                        }
                        put("intensity", segment.intensity)
                        put("rpeGuidance", JSONObject().apply {
                            put("range", segment.rpeRange)
                            put("role", "SECONDARY_GUARDRAIL_NOT_EXECUTION_TARGET")
                        })
                        put("repeatCount", segment.repeatCount)
                    })
                }
            })
        }.toString(2)
    }
}
