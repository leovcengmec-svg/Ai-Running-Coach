package com.airunningcoach.app

import org.json.JSONArray
import org.json.JSONObject

/** Contrato JSON versionado para compartilhar uma prescrição com o Pace Coach. */
internal object PaceCoachExporter {
    const val CONTRACT_VERSION = "2.1"

    fun workoutToJson(
        workout: PrescribedWorkout,
        athleteGoal: String,
        athleteGoalKm: Double?,
        paceReferenceDistanceKm: Double? = null,
        paceReferenceTimeSeconds: Int? = null
    ): String = JSONObject().apply {
        put("contract", "pace-coach-workout")
        put("contractVersion", CONTRACT_VERSION)
        put("source", "AI Running Coach")
        put("sessionId", workout.sessionId)
        put("title", workout.title)
        put("dateLabel", workout.date)
        put("scheduledDate", workout.scheduledDateIso)
        put("week", workout.week)
        put("phase", workout.phase)
        put("goal", athleteGoal)
        if (athleteGoalKm != null) put("goalDistanceKm", athleteGoalKm)
        put("workoutType", workout.type)
        put("objective", workout.objective)
        put("stimulus", workout.stimulus)
        put("estimatedDistanceKm", workout.distanceKm)
        put("estimatedDurationMinutes", workout.durationMin)
        put("distanceEstimateBasis", "Soma dos blocos por distância e das contribuições estimadas dos blocos por tempo.")
        put("durationEstimateBasis", if (workout.paceMode == "PACE_RANGE") "Estimativa calculada a partir das faixas de pace individualizadas por resultado recente." else "Estimativa genérica; ainda não há teste recente para calcular o pace individual.")
        put("durationEstimateIsIndividualized", workout.paceMode == "PACE_RANGE")
        put("intensity", workout.intensity)
        put("executionTarget", JSONObject().apply {
            put("mode", "SEGMENTED")
            put("sourceOfTruth", "segments[].target")
            put("note", "Cada bloco define se a execução é por tempo ou distância. Os totais da sessão são estimativas.")
        })
        put("paceUnit", "min/km")
        put("paceTargetStatus", if (workout.paceMode == "PACE_RANGE") "ESTIMATED_FROM_RECENT_RESULT" else "AWAITING_REFERENCE_RESULT")
        if (paceReferenceDistanceKm != null && paceReferenceTimeSeconds != null) {
            put("paceReference", JSONObject().apply {
                put("distanceKm", paceReferenceDistanceKm)
                put("timeSeconds", paceReferenceTimeSeconds)
                put("time", PaceRange.format(paceReferenceTimeSeconds))
                put("method", "RIEGEL_EQUIVALENT_5K_WITH_CONSERVATIVE_STARTING_RANGES")
            })
        }
        put("paceMode", workout.paceMode)
        put("effortGuidance", JSONObject().apply {
            put("type", "RPE")
            put("range", workout.rpeRange)
            put("role", "SECONDARY_GUARDRAIL_NOT_EXECUTION_TARGET")
        })
        put("rationale", workout.rationale)
        put("segments", JSONArray().apply {
            workout.segments.forEach { segment ->
                put(JSONObject().apply {
                    put("name", segment.name)
                    put("instruction", segment.instruction)
                    put("target", JSONObject().apply {
                        put("mode", segment.targetMode)
                        if (segment.targetMode == "TIME") {
                            segment.durationMin?.let { put("value", it); put("unit", "min") }
                        } else {
                            segment.distanceKm?.let { put("value", it); put("unit", "km") }
                        }
                    })
                    if (segment.targetMode == "TIME") {
                        segment.durationMin?.let { put("durationMinutes", it) }
                        segment.distanceKm?.let { put("estimatedDistanceKm", it) }
                    } else {
                        segment.distanceKm?.let { put("distanceKm", it) }
                    }
                    if (segment.targetPaceMinSecPerKm != null && segment.targetPaceMaxSecPerKm != null) {
                        put("paceTarget", JSONObject().apply {
                            put("unit", "min/km")
                            put("minSecPerKm", segment.targetPaceMinSecPerKm)
                            put("maxSecPerKm", segment.targetPaceMaxSecPerKm)
                            put("targetSecPerKm", ((segment.targetPaceMinSecPerKm + segment.targetPaceMaxSecPerKm) / 2.0).toInt())
                            put("target", PaceRange.format(((segment.targetPaceMinSecPerKm + segment.targetPaceMaxSecPerKm) / 2.0).toInt()))
                            put("min", PaceRange.format(segment.targetPaceMinSecPerKm))
                            put("max", PaceRange.format(segment.targetPaceMaxSecPerKm))
                        })
                    }
                    put("intensity", segment.intensity)
                    put("rpeGuidance", JSONObject().apply {
                        put("range", segment.rpeRange)
                        put("role", "SECONDARY_GUARDRAIL_NOT_EXECUTION_TARGET")
                    })
                    put("repeatCount", segment.repeatCount)
                })
            }
        })
    }.toString(2)
}
