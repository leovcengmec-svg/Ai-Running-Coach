package com.airunningcoach.app

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.time.format.DateTimeFormatter
import java.time.format.ResolverStyle

internal data class CooperAssessmentRecord(
    val dateIso: String,
    val distanceKm: Double,
    val estimatedVo2Max: Double,
    val averagePace: String,
    val zoneModelVersion: String = PaceCalculator.ZONE_MODEL_VERSION,
    /** Snapshot of Z1–Z5 in mm:ss min/km; old evaluations remain reproducible. */
    val zoneRanges: Map<String, String> = emptyMap()
)

internal data class CooperReviewStatus(
    val lastAssessmentDate: LocalDate?,
    val nextReviewDate: LocalDate?,
    val daysUntilReview: Long?,
    val isDue: Boolean,
    val message: String
)

internal object CooperAssessmentEngine {
    const val REVIEW_INTERVAL_DAYS = 28L
    const val TEST_DURATION = "12 min"
    const val MAX_ONBOARDING_RESULT_AGE_DAYS = 56L
    private val inputDateFormatter = DateTimeFormatter.ofPattern("dd/MM/uuuu").withResolverStyle(ResolverStyle.STRICT)

    fun parseAssessmentDate(text: String): LocalDate? = runCatching {
        LocalDate.parse(text.trim(), inputDateFormatter)
    }.getOrNull()

    fun isRecentAssessmentDate(date: LocalDate, today: LocalDate = LocalDate.now()): Boolean {
        return ChronoUnit.DAYS.between(date, today) in 0..MAX_ONBOARDING_RESULT_AGE_DAYS
    }

    fun createRecord(distanceKm: Double, date: LocalDate = LocalDate.now()): CooperAssessmentRecord? {
        val zones = PaceCalculator.calculateCooper(distanceKm) ?: return null
        return CooperAssessmentRecord(
            dateIso = date.toString(),
            distanceKm = distanceKm,
            estimatedVo2Max = zones.estimatedVo2Max,
            averagePace = PaceRange.format(zones.averageTestPaceValue),
            zoneModelVersion = zones.modelVersion,
            zoneRanges = zones.all().associate { it.id to it.range.label() }
        )
    }

    fun reviewStatus(history: List<CooperAssessmentRecord>, today: LocalDate = LocalDate.now()): CooperReviewStatus {
        val lastDate = history.mapNotNull { record ->
            runCatching { LocalDate.parse(record.dateIso) }.getOrNull()
        }.maxOrNull()
        if (lastDate == null) {
            return CooperReviewStatus(null, null, null, true, "Faça seu primeiro Teste de Cooper para calibrar as zonas de pace.")
        }
        val next = lastDate.plusDays(REVIEW_INTERVAL_DAYS)
        val days = ChronoUnit.DAYS.between(today, next)
        val due = days <= 0
        val message = when {
            due -> "A revisão de quatro semanas está disponível. Reavalie a recuperação antes de realizar um novo Cooper."
            days <= 7 -> "Sua próxima revisão de pace está próxima. Continue registrando as sessões e priorize a recuperação."
            else -> "Próxima revisão programada para ${next.format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy"))}."
        }
        return CooperReviewStatus(lastDate, next, days, due, message)
    }

    fun improvementSincePrevious(history: List<CooperAssessmentRecord>): Double? {
        val sorted = history.mapNotNull { record ->
            runCatching { LocalDate.parse(record.dateIso) }.getOrNull()?.let { it to record }
        }.sortedBy { it.first }.map { it.second }
        if (sorted.size < 2) return null
        val previous = sorted[sorted.lastIndex - 1].distanceKm
        val current = sorted.last().distanceKm
        if (previous <= 0.0) return null
        return ((current - previous) / previous) * 100.0
    }
}
