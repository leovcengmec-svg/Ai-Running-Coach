package com.airunningcoach.app

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/** Motor de prescrição V37: carga realizada, recuperação, especificidade e faixas de campo. */
internal data class RunnerInput(
    val goalKm: Double,
    val level: String,
    val frequency: Int,
    /** Dias habituais escolhidos pelo atleta; lista vazia mantém compatibilidade com perfis antigos. */
    val availableDays: List<DayOfWeek> = emptyList(),
    /** Dia preferido para o longão, quando disponível. */
    val preferredLongRunDay: DayOfWeek? = null,
    /** Média semanal efetivamente corrida nas últimas quatro semanas. */
    val weeklyVolumeKm: Double,
    val longestRecentKm: Double,
    val painPresent: Boolean = false,
    val recoveryScore: Double? = null,
    val fatigueScore: Double? = null,
    val planWeeks: Int = 8,
    /** Distância percorrida no Teste de Cooper de 12 minutos; unidade única: km. */
    val cooperDistanceKm: Double? = null,
    val cooperAssessmentDateIso: String? = null,
    /** Pace da etapa estável em que frases completas permaneceram confortáveis, observado em sessões aeróbias. */
    val talkTestComfortPaceValues: List<Int> = emptyList(),
    /** Count of real activities with distance/time recorded in the previous 28 days. */
    val recentActivityCount: Int = 0,
    /** True only after enough logged sessions span at least three distinct weeks. */
    val recentActivityHistoryReliable: Boolean = false,
    val startDate: LocalDate = LocalDate.now().with(TemporalAdjusters.nextOrSame(DayOfWeek.MONDAY))
)

internal data class MotorState(
    val fitnessConfidence: String,
    val paceConfidence: String,
    val recentVolumeKm: Double,
    val recentLongRunKm: Double,
    val recoveryStatus: String,
    val safetyStatus: String,
    val phase: String,
    val flags: List<String>
)

internal data class MotorDecision(
    val action: String,
    val necessity: String,
    val stimulus: String,
    val rationale: String,
    val confidence: Double,
    val safety: String
)

internal data class WorkoutSegment(
    val name: String,
    val instruction: String,
    val durationMin: Int? = null,
    val distanceKm: Double? = null,
    val intensity: String = "LOW",
    /** RPE é uma referência complementar, nunca o alvo primário de execução. */
    val rpeRange: String = "2-3",
    val repeatCount: Int = 1,
    /** TIME ou DISTANCE, conforme o campo de dose preenchido. */
    val targetMode: String = if (durationMin != null) "TIME" else "DISTANCE",
    /** Limites numéricos internos; UI e contrato sempre formatam como mm:ss min/km. */
    val targetPaceMinValue: Int? = null,
    val targetPaceMaxValue: Int? = null,
    /** Zona operacional Z1–Z5 associada ao bloco, quando aplicável. */
    val paceZone: String? = null
) {
    init {
        require(targetMode == "TIME" || targetMode == "DISTANCE") { "O alvo deve ser TIME ou DISTANCE." }
        require(if (targetMode == "TIME") durationMin != null && durationMin > 0 else distanceKm != null && distanceKm >= 0.0) {
            "Cada etapa precisa ter uma dose compatível com o tipo de alvo."
        }
        require((targetPaceMinValue == null) == (targetPaceMaxValue == null)) { "A faixa de pace precisa ter os dois limites." }
        if (targetPaceMinValue != null && targetPaceMaxValue != null) {
            require(targetPaceMinValue > 0 && targetPaceMaxValue >= targetPaceMinValue) { "Faixa de pace inválida." }
        }
        require(repeatCount >= 1) { "A repetição deve ser pelo menos 1." }
    }
}

internal data class PrescribedWorkout(
    val day: String,
    val date: String,
    val scheduledDateIso: String,
    val title: String,
    val type: String,
    val objective: String,
    val stimulus: String,
    val sessionId: String,
    val distanceKm: Double,
    val durationMin: Int,
    val intensity: String,
    val paceMode: String,
    val rpeRange: String,
    val detail: String,
    val rationale: String,
    val week: Int = 1,
    val phase: String = "BASE",
    val segments: List<WorkoutSegment> = emptyList(),
    val paceCalibrationSnapshot: PaceCalibrationSnapshot? = null
)

internal data class WeeklyPlanSummary(
    val week: Int,
    val phase: String,
    val totalKm: Double,
    val workoutCount: Int,
    val isRecoveryWeek: Boolean
)

internal data class MotorPlan(
    val state: MotorState,
    val decision: MotorDecision,
    val workouts: List<PrescribedWorkout>,
    val weeklyKm: Double,
    val explanation: String,
    val weeklySummaries: List<WeeklyPlanSummary>
)

internal object RunningCoachEngine {
    fun generate(input: RunnerInput): MotorPlan {
        require(input.frequency in 2..6) { "A frequência deve estar entre 2 e 6 dias por semana." }
        if (input.availableDays.isNotEmpty()) {
            require(input.availableDays.distinct().size == input.frequency) { "A quantidade de dias selecionados precisa corresponder à frequência semanal." }
            require(input.preferredLongRunDay == null || input.preferredLongRunDay in input.availableDays) { "O dia preferido do longão precisa estar disponível." }
        }
        require(input.goalKm in 1.0..100.0) { "O objetivo precisa estar entre 1 e 100 km." }
        require(input.weeklyVolumeKm in 0.0..150.0) { "Informe um volume semanal entre 0 e 150 km." }
        require(input.longestRecentKm in 0.0..60.0) { "O maior treino recente precisa estar entre 0 e 60 km." }

        val novice = isNovicePlan(input)
        val paceZones = PaceCalculator.calculateCooper(input.cooperDistanceKm, input.talkTestComfortPaceValues)
        val recovery = recoveryStatus(input.recoveryScore)
        val safety = safetyStatus(input)
        val flags = buildFlags(input, recovery, safety)
        val state = MotorState(
            fitnessConfidence = when {
                input.weeklyVolumeKm < 8.0 || input.longestRecentKm < 5.0 -> "LOW"
                else -> "PARTIAL"
            },
            paceConfidence = if (paceZones != null) "ESTIMATED_FROM_COOPER" else "AWAITING_COOPER",
            recentVolumeKm = input.weeklyVolumeKm,
            recentLongRunKm = input.longestRecentKm,
            recoveryStatus = recovery,
            safetyStatus = safety,
            phase = if (recovery == "POOR" || safety == "YELLOW") "RECOVERY" else "BASE_AND_BUILD",
            flags = flags
        )

        if (safety == "RED") {
            val decision = MotorDecision(
                action = "BLOCK", necessity = "SAFETY_REVIEW", stimulus = "NONE",
                rationale = "Há relato de dor. O motor não gera sessões de corrida; procure orientação adequada antes de retomar a carga.",
                confidence = 0.99, safety = "RED"
            )
            return MotorPlan(state, decision, emptyList(), 0.0, decision.rationale, emptyList())
        }

        val weeks = input.planWeeks.coerceIn(4, 16)
        // Sem volume recente, o ciclo começa como reintrodução muito leve, não como intermediário/avançado.
        val baselineKm = if (input.weeklyVolumeKm == 0.0) 3.0 else input.weeklyVolumeKm
        val workouts = mutableListOf<PrescribedWorkout>()
        val calibrationDate = input.cooperAssessmentDateIso ?: input.startDate.toString()
        val calibrationSnapshot = PaceCalculator.createCalibrationSnapshot(input.cooperDistanceKm, calibrationDate, input.talkTestComfortPaceValues)
        val summaries = mutableListOf<WeeklyPlanSummary>()
        val initialReadinessFactor = when {
            recovery == "POOR" -> 0.72
            safety == "YELLOW" -> 0.82
            else -> 1.0
        }

        for (week in 1..weeks) {
            val cycleWeek = (week - 1) % 4
            val isRecoveryWeek = cycleWeek == 3
            val blockIndex = (week - 1) / 4
            val blockFactor = (1.0 + blockIndex * 0.04).coerceAtMost(1.16)
            val progressionFactor = when (cycleWeek) {
                0 -> 1.00
                1 -> 1.04
                2 -> 1.08
                // Deload is a controlled reduction from the preceding build weeks,
                // not a drop to an arbitrary fraction of the original baseline.
                else -> 0.92
            }
            val readinessFactor = when {
                recovery == "POOR" -> 0.72
                safety == "YELLOW" -> 0.82
                else -> 1.0
            }
            val candidateWeekKm = max(1.5, baselineKm * blockFactor * progressionFactor * readinessFactor)
            val previousDeliveredKm = summaries.lastOrNull()?.totalKm
            val progressionCeiling = when {
                previousDeliveredKm == null -> candidateWeekKm
                isRecoveryWeek -> previousDeliveredKm * 0.88
                cycleWeek == 0 -> previousDeliveredKm * 1.08
                else -> previousDeliveredKm * 1.05
            }
            val targetWeekKm = min(candidateWeekKm, progressionCeiling).coerceAtLeast(1.5)
            val weekPhase = when {
                recovery == "POOR" || safety == "YELLOW" || isRecoveryWeek -> "RECOVERY"
                cycleWeek == 0 -> "ADAPTATION"
                cycleWeek == 1 -> "CONSOLIDATION"
                else -> "PROGRESSION"
            }
            val weekSessions = buildWeek(
                input = input,
                targetWeekKm = targetWeekKm,
                week = week,
                phase = weekPhase,
                suppressQuality = isRecoveryWeek || recovery == "POOR" || safety == "YELLOW"
            ).map { it.copy(paceCalibrationSnapshot = calibrationSnapshot) }
            workouts += weekSessions
            summaries += WeeklyPlanSummary(
                week = week,
                phase = weekPhase,
                totalKm = round1(weekSessions.sumOf { it.distanceKm }),
                workoutCount = weekSessions.size,
                isRecoveryWeek = isRecoveryWeek || recovery == "POOR" || safety == "YELLOW"
            )
        }

        val firstWeekKm = summaries.firstOrNull()?.totalKm ?: 0.0
        val volumeWasCapped = firstWeekKm + 0.1 < baselineKm * initialReadinessFactor
        val finalState = if (volumeWasCapped) state.copy(flags = state.flags + "WEEKLY_VOLUME_CAPPED_BY_RECENT_TOLERANCE") else state
        val qualityCount = workouts.count { it.type == "Qualidade" }
        val necessity = when {
            recovery == "POOR" -> "RECOVERY_FIRST"
            input.goalKm <= 10.0 -> "AEROBIC_DEVELOPMENT"
            else -> "ENDURANCE_DEVELOPMENT"
        }
        val stimulus = when {
            recovery == "POOR" || safety == "YELLOW" -> "LOW_INTENSITY_AEROBIC"
            qualityCount > 0 -> "AEROBIC_BASE_AND_CONTROLLED_QUALITY"
            else -> "AEROBIC_BASE"
        }
        val rationale = when {
            recovery == "POOR" -> "A recuperação registrada está baixa. O volume foi reduzido e os estímulos de qualidade foram suspensos."
            safety == "YELLOW" -> "Os sinais recentes de fadiga pedem redução temporária da carga e suspensão de estímulos intensos."
            volumeWasCapped -> "A média semanal informada é maior do que a dose que o histórico do maior treino recente permite distribuir com segurança na frequência escolhida. O plano fica abaixo da média informada até haver tolerância documentada."
            input.weeklyVolumeKm == 0.0 -> "Como não há corrida registrada nas últimas quatro semanas, o plano começa com reintrodução leve, independentemente do nível de experiência declarado."
            input.level == "Iniciante" -> "O plano prioriza consistência aeróbia e progressão gradual, sem estímulos intensos nesta etapa."
            novice -> "O plano prioriza até três sessões de corrida-caminhada por semana, com progressão por tempo e recuperação entre os dias. A disponibilidade selecionada não é interpretada como obrigação de correr todos os dias."
            else -> "A primeira semana parte do volume semanal real informado. A progressão é gradual; a qualidade só aparece quando o volume, a recuperação e o espaçamento entre sessões permitem."
        }
        val decision = MotorDecision(
            action = if (recovery == "POOR" || safety == "YELLOW") "REDUCE_LOAD" else "PRESCRIBE",
            necessity = necessity,
            stimulus = stimulus,
            rationale = rationale,
            confidence = when {
                input.weeklyVolumeKm == 0.0 -> 0.25
                input.weeklyVolumeKm >= 8.0 && input.longestRecentKm >= 5.0 -> 0.68
                else -> 0.42
            },
            safety = safety
        )
        val explanation = buildString {
            append("O volume da semana 1 usa a média semanal efetivamente informada para as últimas quatro semanas, sem reduzir uma faixa inteira ao seu limite inferior. ")
            append("A experiência declarada define a elegibilidade dos estímulos, mas não substitui o histórico de carga. ")
            append("O longão é limitado pelo maior treino recente, pela parcela da semana e pela distância-alvo. ")
            append("O limite de sessão é baseado na maior corrida recente registrada; o motor não presume que sessões futuras do plano já foram concluídas. Recalcule o ciclo após registrar a carga real para liberar progressões posteriores. ")
            if (novice) append("Para iniciantes ou atletas em reintrodução, são prescritas no máximo três sessões semanais de corrida-caminhada, independentemente de quantos dias foram marcados como disponíveis. ")
            if (input.recentActivityHistoryReliable) {
                append("A carga de referência foi atualizada com ${input.recentActivityCount} atividades reais registradas nas últimas quatro semanas. ")
            } else if (input.recentActivityCount > 0) {
                append("O histórico registrado ainda é parcial (${input.recentActivityCount} atividades recentes); a média informada no perfil foi mantida como referência, e as sessões já registradas entram como limite adicional de tolerância. ")
            }
            if (paceZones != null) {
                if (input.cooperDistanceKm != null) {
                    append("As cinco zonas iniciais Z1–Z5 são faixas operacionais estimadas a partir do Cooper (${formatKm(input.cooperDistanceKm)} km em 12 min); não são medições laboratoriais nem percentuais de VO₂máx. Z4 e Z5 são referências de esforço estimadas, e o RPE permanece como controle complementar. Dois registros consistentes de fala confortável podem personalizar o limite da Z2.")
                } else {
                    append("O perfil anterior ainda não possui uma avaliação Cooper válida. Faça o teste de 12 minutos para calibrar as zonas Z1–Z5.")
                }
            } else {
                append("Sem Teste de Cooper ou referência anterior válida, o motor não inventa pace: as sessões usam alvos por distância/tempo e RPE apenas como orientação temporária. Registre a distância percorrida no Cooper de 12 minutos para calibrar Z1–Z5.")
            }
        }
        return MotorPlan(finalState, decision, workouts, firstWeekKm, explanation, summaries)
    }

    private fun buildWeek(
        input: RunnerInput,
        targetWeekKm: Double,
        week: Int,
        phase: String,
        suppressQuality: Boolean
    ): List<PrescribedWorkout> {
        val novice = isNovicePlan(input)
        val days = trainingDays(input)
        val dayCount = days.size
        val longDay = input.preferredLongRunDay?.takeIf { it in days } ?: days.last()
        val goalLongCap = when {
            input.goalKm <= 5.0 -> 8.0
            input.goalKm <= 10.0 -> 14.0
            input.goalKm <= 21.1 -> 22.0
            else -> 30.0
        }

        // Do not increase a single-session cap based on future planned sessions.
        // A new higher cap is released only after the athlete records a new tolerated run.
        val historyCap = if (input.longestRecentKm <= 0.0) 1.0
            else input.longestRecentKm * 1.10
        val sessionCap = min(historyCap, goalLongCap)

        val longIndex = days.indexOf(longDay)
        val qualityDay = TrainingScheduleEngine.qualityDayWithRecoveryGap(days, longDay)
        val allowQuality = !suppressQuality && !novice &&
            dayCount >= 3 && targetWeekKm >= 16.0 && input.longestRecentKm >= 8.0 && qualityDay != null

        // A distribuição muda com a frequência. Não existe uma fração universal do longão:
        // com poucas sessões ele ocupa uma parcela maior; com mais dias, uma parcela menor.
        // Em todas as frequências, o longão deve ser a maior sessão se o histórico permitir.
        val longShare = when (dayCount) {
            2 -> 0.53
            3 -> 0.40
            4 -> 0.32
            5 -> 0.28
            else -> 0.25
        }
        val qualityShare = when (dayCount) {
            3 -> 0.29
            4 -> 0.20
            5 -> 0.18
            else -> 0.15
        }

        var longKm = min(sessionCap, roundHalf(targetWeekKm * longShare))
            .coerceAtLeast(min(0.5, targetWeekKm))
        var nonLongCap = (longKm - 0.5).coerceAtLeast(0.5)

        var qualityKm = if (allowQuality) {
            min(min(sessionCap, nonLongCap), roundHalf(targetWeekKm * qualityShare))
                .coerceAtLeast(min(0.5, targetWeekKm - longKm))
        } else 0.0

        // A qualidade só entra quando há pelo menos um dia completo sem corrida
        // entre ela e o longão. Se a disponibilidade não permitir, ela é suprimida.
        val qualityIndex = if (allowQuality) days.indexOf(qualityDay) else -1
        val easyIndices = days.indices.filter { it != longIndex && (!allowQuality || it != qualityIndex) }
        // Com apenas duas corridas semanais não há sessão de qualidade: o longão precisa
        // superar a única rodagem fácil, inclusive após arredondamento em semanas leves.
        if (easyIndices.size == 1 && !allowQuality) {
            val minimumDominantLong = kotlin.math.ceil((targetWeekKm + 0.5) * 2.0) / 4.0
            longKm = min(sessionCap, max(longKm, minimumDominantLong))
            nonLongCap = (longKm - 0.5).coerceAtLeast(0.1)
        }
        var easyTotal = max(0.0, targetWeekKm - longKm - qualityKm)

        // Na frequência de 3 dias há apenas uma rodagem fácil além da qualidade e do longão.
        // Se a limitação histórica reduzir o longão, transferimos parte do volume para o bloco
        // de qualidade (que inclui aquecimento/recuperações/desaquecimento) antes de reduzir a semana.
        if (easyIndices.size == 1 && easyTotal > nonLongCap && allowQuality) {
            val extraNeeded = easyTotal - nonLongCap
            val qualityRoom = (nonLongCap - qualityKm).coerceAtLeast(0.0)
            val transfer = min(extraNeeded, qualityRoom)
            qualityKm = round1(qualityKm + transfer)
            easyTotal = max(0.0, targetWeekKm - longKm - qualityKm)
        }

        val easySessionCap = min(sessionCap, nonLongCap)
        val easyDistances = distributeDistance(easyTotal, easyIndices.size, easySessionCap)
        val strideDayIndex = if (!novice && !suppressQuality && !allowQuality && dayCount >= 5) {
            easyIndices.firstOrNull { idx -> easyDistances.getOrElse(easyIndices.indexOf(idx)) { 0.0 } >= 4.0 &&
                TrainingScheduleEngine.circularGapDays(days[idx], longDay) >= 2 }
        } else null
        var easyCursor = 0
        val startMonday = input.startDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))

        return days.mapIndexed { index, day ->
            val date = startMonday.plusWeeks((week - 1).toLong()).plusDays(day.value - 1L)
            when {
                day == longDay -> createLongRun(input, date, longKm, week, phase)
                allowQuality && index == qualityIndex -> createQuality(input, date, qualityKm, week, phase)
                else -> {
                    val km = easyDistances.getOrElse(easyCursor++) { 0.5 }
                    // Acelerações técnicas são ocasionais e só entram quando não há
                    // sessão de qualidade na semana; não são usadas em iniciantes,
                    // semanas regenerativas ou sessões próximas do longão.
                    val style = if (index == strideDayIndex) "STRIDES" else "EASY"
                    createEasy(input, date, km, week, phase, recovery = suppressQuality, style = style)
                }
            }
        }
    }

    private fun cycleWeekFor(week: Int): Int = (week - 1) % 4

    private fun distributeDistance(totalKm: Double, count: Int, sessionCapKm: Double): List<Double> {
        if (count <= 0) return emptyList()
        var remaining = round1(totalKm.coerceAtLeast(0.0))
        return (0 until count).map { index ->
            val slotsLeft = count - index
            if (slotsLeft == 1) {
                min(sessionCapKm, remaining).coerceAtLeast(0.1).also { remaining = 0.0 }
            } else {
                val minimumForEachRemaining = if (remaining >= slotsLeft * 0.5) 0.5 else max(0.1, remaining / slotsLeft)
                val maxForCurrent = min(sessionCapKm, remaining - minimumForEachRemaining * (slotsLeft - 1))
                    .coerceAtLeast(minimumForEachRemaining)
                val desired = round1(remaining / slotsLeft)
                val allocated = round1(desired.coerceIn(minimumForEachRemaining, maxForCurrent))
                remaining = round1((remaining - allocated).coerceAtLeast(0.0))
                allocated
            }
        }
    }

    private fun createEasy(input: RunnerInput, date: LocalDate, km: Double, week: Int, phase: String, recovery: Boolean, style: String = "EASY"): PrescribedWorkout {
        if (isNovicePlan(input)) return createRunWalk(date, km, week, phase, recovery, isLongRun = false)
        val beginner = false
        val title = when {
            recovery -> "Rodagem regenerativa"
            style == "PROGRESSION" -> "Corrida progressiva"
            style == "STRIDES" -> "Rodagem aeróbia com acelerações"
            beginner -> "Corrida leve / caminhada"
            else -> "Rodagem aeróbia"
        }
        val rpe = if (recovery) "2-3" else "3-4"
        val warmupKm = round1(km * 0.2)
        val mainKm = round1(km * 0.6)
        val cooldownKm = round1((km - warmupKm - mainKm).coerceAtLeast(0.0))
        val zones = PaceCalculator.calculateCooper(input.cooperDistanceKm, input.talkTestComfortPaceValues)
        val warm = WorkoutSegment("Aquecimento", "Comece com caminhada ativa ou trote muito leve.", distanceKm = warmupKm, intensity = "LOW", rpeRange = "1-2",
            targetPaceMinValue = zones?.z1?.range?.fastestPaceValue, targetPaceMaxValue = zones?.z1?.range?.slowestPaceValue, paceZone = "Z1")
        val aerobicZone = if (recovery) zones?.z1 else zones?.z2
        val aerobicZoneId = if (recovery) "Z1" else "Z2"
        val main = when (style) {
            "PROGRESSION" -> WorkoutSegment("Bloco fácil", "Mantenha conversa confortável; a sessão progride apenas no trecho final.", distanceKm = mainKm * 0.70, intensity = "LOW", rpeRange = "3-4",
                targetPaceMinValue = zones?.z2?.range?.fastestPaceValue, targetPaceMaxValue = zones?.z2?.range?.slowestPaceValue, paceZone = "Z2")
            "STRIDES" -> WorkoutSegment("Bloco aeróbio", "Corrida confortável antes das acelerações; não transforme a sessão em sprint.", distanceKm = mainKm, intensity = "LOW", rpeRange = "3-4",
                targetPaceMinValue = zones?.z2?.range?.fastestPaceValue, targetPaceMaxValue = zones?.z2?.range?.slowestPaceValue, paceZone = "Z2")
            else -> WorkoutSegment("Bloco aeróbio", if (recovery) "Mantenha esforço regenerativo em Z1; encerre mais leve se a respiração não estiver confortável." else "Converse em frases completas; reduza o ritmo se a respiração ficar difícil.", distanceKm = mainKm, intensity = "LOW", rpeRange = rpe,
                targetPaceMinValue = aerobicZone?.range?.fastestPaceValue, targetPaceMaxValue = aerobicZone?.range?.slowestPaceValue, paceZone = aerobicZoneId)
        }
        val segments = mutableListOf(warm, main)
        if (style == "PROGRESSION") {
            val finishKm = round1(mainKm * 0.30)
            segments += WorkoutSegment("Final moderado", "Aumente gradualmente até ritmo moderado, sem chegar ao limiar.", distanceKm = finishKm, intensity = "MODERATE", rpeRange = "5-6",
                targetPaceMinValue = zones?.z3?.range?.fastestPaceValue, targetPaceMaxValue = zones?.z3?.range?.slowestPaceValue, paceZone = "Z3")
        }
        if (style == "STRIDES" && km >= 4.0) {
            val stridesKm = min(0.4, cooldownKm * 0.5)
            if (stridesKm >= 0.2) segments += WorkoutSegment("Acelerações técnicas (strides)", "Faça acelerações curtas, soltas e tecnicamente estáveis; recupere completamente. Não persiga um pace numérico.", distanceKm = stridesKm / 4.0, intensity = "HIGH", rpeRange = "6-7", repeatCount = 4)
        }
        val usedKm = segments.sumOf { (it.distanceKm ?: 0.0) * it.repeatCount }
        val remainder = round1((km - usedKm).coerceAtLeast(0.0))
        if (remainder > 0.0) segments += asTimeTarget(WorkoutSegment("Desaquecimento", "Reduza gradualmente o esforço até encerrar a sessão.", distanceKm = remainder, intensity = "LOW", rpeRange = "1-2",
            targetPaceMinValue = zones?.z1?.range?.fastestPaceValue, targetPaceMaxValue = zones?.z1?.range?.slowestPaceValue, paceZone = "Z1"), zones)
        val total = segments.sumOf { (it.distanceKm ?: 0.0) * it.repeatCount }
        return workout(date, title, if (recovery) "Recuperação" else "Aeróbio", "Construir consistência aeróbia", when {
            recovery -> "RECOVERY_Z1"
            style == "PROGRESSION" -> "PROGRESSION_RUN_Z2_Z3"
            style == "STRIDES" -> "EASY_WITH_STRIDES_Z2_Z5"
            else -> "EASY_AEROBIC_Z2"
        }, total, rpe, week, phase, segments,
            if (recovery) "Carga baixa em Z1 para facilitar a recuperação." else if (zones != null) "Pace individual por zona, derivado do Cooper ou referência legada. O esforço deve continuar compatível com a zona e com as condições do dia." else "Sem teste de referência: mantenha esforço confortável e use o alvo por distância/tempo até calibrar as zonas.", "LOW")
    }

    private fun createQuality(input: RunnerInput, date: LocalDate, km: Double, week: Int, phase: String): PrescribedWorkout {
        val zones = PaceCalculator.calculateCooper(input.cooperDistanceKm, input.talkTestComfortPaceValues)
        val cycleWeek = (week - 1) % 4
        val blockIndex = (week - 1) / 4
        val experienced = input.level == "Avançado" || input.level == "Elite"
        val kind = when {
            input.goalKm <= 5.0 -> when (cycleWeek) {
                0 -> "PROGRESSIVE_RUN"
                1 -> if (blockIndex % 2 == 0) "TEMPO_RUN" else "FARTLEK"
                else -> if (experienced && blockIndex % 2 == 0) "VO2_MAX_INTERVAL" else "FARTLEK"
            }
            input.goalKm <= 10.0 -> when (cycleWeek) {
                0 -> "PROGRESSIVE_RUN"
                1 -> if (blockIndex % 2 == 0) "TEMPO_RUN" else "THRESHOLD_INTERVAL"
                else -> if (experienced && blockIndex % 2 == 0) "VO2_MAX_INTERVAL" else "STEADY_RUN"
            }
            input.goalKm <= 21.1 -> when (cycleWeek) {
                0 -> "STEADY_RUN"
                1 -> "TEMPO_RUN"
                else -> "THRESHOLD_INTERVAL"
            }
            else -> when (cycleWeek) {
                0 -> "STEADY_RUN"
                1 -> "TEMPO_RUN"
                else -> "MARATHON_SPECIFIC"
            }
        }
        val warmKm = round1(km * 0.20)
        val coolKm = round1(km * 0.20)
        val mainBudget = round1((km - warmKm - coolKm).coerceAtLeast(0.5))
        val segments = mutableListOf<WorkoutSegment>()
        segments += asTimeTarget(WorkoutSegment("Aquecimento", "Comece em Z1 e progrida suavemente para Z2 antes do bloco principal.", distanceKm = warmKm, intensity = "LOW", rpeRange = "2-3",
            targetPaceMinValue = zones?.z1?.range?.fastestPaceValue, targetPaceMaxValue = zones?.z1?.range?.slowestPaceValue, paceZone = "Z1"), zones)
        when (kind) {
            "PROGRESSIVE_RUN" -> {
                val z2Km = round1(mainBudget * 0.60)
                val z3Km = round1(mainBudget - z2Km)
                segments += WorkoutSegment("Bloco aeróbio", "Mantenha ritmo confortável e conversável.", distanceKm = z2Km, intensity = "LOW", rpeRange = "3-4",
                    targetPaceMinValue = zones?.z2?.range?.fastestPaceValue, targetPaceMaxValue = zones?.z2?.range?.slowestPaceValue, paceZone = "Z2")
                if (z3Km > 0.0) segments += WorkoutSegment("Final moderado", "Aumente gradualmente para Z3, sem entrar em esforço de limiar.", distanceKm = z3Km, intensity = "MODERATE", rpeRange = "5-6",
                    targetPaceMinValue = zones?.z3?.range?.fastestPaceValue, targetPaceMaxValue = zones?.z3?.range?.slowestPaceValue, paceZone = "Z3")
            }
            "TEMPO_RUN" -> segments += WorkoutSegment("Tempo controlado", "Ritmo sustentado e controlado. Z4 é uma referência estimada pelo Cooper, não um limiar medido; ajuste pelo esforço e interrompa a progressão se perder o controle.", distanceKm = mainBudget, intensity = "MODERATE", rpeRange = "6-7",
                targetPaceMinValue = zones?.z4?.range?.fastestPaceValue, targetPaceMaxValue = zones?.z4?.range?.slowestPaceValue, paceZone = "Z4")
            "STEADY_RUN" -> segments += WorkoutSegment(if (input.goalKm > 21.1) "Bloco específico de resistência" else "Corrida moderada", if (input.goalKm > 21.1) "Sustente esforço moderado controlado em Z3 estimada, sem tentar reproduzir pace de maratona sem prova recente. Preserve a conversa em frases curtas." else "Mantenha ritmo sustentado em Z3 estimada, sem transformar a sessão em esforço de limiar.", distanceKm = mainBudget, intensity = "MODERATE", rpeRange = "5-6",
                targetPaceMinValue = zones?.z3?.range?.fastestPaceValue, targetPaceMaxValue = zones?.z3?.range?.slowestPaceValue, paceZone = "Z3")
            "MARATHON_SPECIFIC" -> {
                val easyKm = round1(mainBudget * 0.80)
                val moderateKm = round1((mainBudget - easyKm).coerceAtLeast(0.0))
                segments += WorkoutSegment("Resistência aeróbia específica", "Mantenha Z2 confortável e estável; a meta é acumular resistência, não transformar o bloco em treino de limiar.", distanceKm = easyKm, intensity = "LOW", rpeRange = "3-4",
                    targetPaceMinValue = zones?.z2?.range?.fastestPaceValue, targetPaceMaxValue = zones?.z2?.range?.slowestPaceValue, paceZone = "Z2")
                if (moderateKm > 0.0) segments += WorkoutSegment("Final moderado controlado", "Se estiver confortável, termine em Z3 estimada. Se houver fadiga, mantenha Z2 em todo o bloco.", distanceKm = moderateKm, intensity = "MODERATE", rpeRange = "4-5",
                    targetPaceMinValue = zones?.z3?.range?.fastestPaceValue, targetPaceMaxValue = zones?.z3?.range?.slowestPaceValue, paceZone = "Z3")
            }
            "THRESHOLD_INTERVAL" -> {
                val reps = if (input.level == "Elite" || input.level == "Avançado") 4 else 3
                val repKm = round1(mainBudget * 0.65 / reps)
                val recoverTotal = round1(mainBudget - repKm * reps)
                segments += WorkoutSegment("Intervalos controlados (Z4 estimada)", "Repita em Z4 estimada com controle; a zona não substitui limiar medido. Não acelere para além da faixa prescrita.", distanceKm = repKm, intensity = "MODERATE", rpeRange = "6-7", repeatCount = reps,
                    targetPaceMinValue = zones?.z4?.range?.fastestPaceValue, targetPaceMaxValue = zones?.z4?.range?.slowestPaceValue, paceZone = "Z4")
                if (recoverTotal > 0.0) segments += asTimeTarget(WorkoutSegment("Recuperação entre repetições", "Trote leve em Z1 até recuperar a respiração.", distanceKm = recoverTotal / (reps - 1), intensity = "LOW", rpeRange = "2-3", repeatCount = reps - 1,
                    targetPaceMinValue = zones?.z1?.range?.fastestPaceValue, targetPaceMaxValue = zones?.z1?.range?.slowestPaceValue, paceZone = "Z1"), zones)
            }
            "VO2_MAX_INTERVAL" -> {
                val reps = if (input.level == "Elite") 5 else 4
                val repKm = round1(mainBudget * 0.60 / reps)
                val recoverTotal = round1(mainBudget - repKm * reps)
                segments += WorkoutSegment("Intervalos de alta intensidade (Z5 estimada)", "Repetições curtas e controladas na faixa alta estimada. Z5 não confirma VO₂máx; priorize técnica e recuperação completa.", distanceKm = repKm, intensity = "HIGH", rpeRange = "7-8", repeatCount = reps,
                    targetPaceMinValue = zones?.z5?.range?.fastestPaceValue, targetPaceMaxValue = zones?.z5?.range?.slowestPaceValue, paceZone = "Z5")
                if (recoverTotal > 0.0) segments += asTimeTarget(WorkoutSegment("Recuperação entre repetições", "Recupere em Z1; inicie a próxima repetição apenas quando estiver pronto.", distanceKm = recoverTotal / (reps - 1), intensity = "LOW", rpeRange = "2-3", repeatCount = reps - 1,
                    targetPaceMinValue = zones?.z1?.range?.fastestPaceValue, targetPaceMaxValue = zones?.z1?.range?.slowestPaceValue, paceZone = "Z1"), zones)
            }
            else -> {
                val reps = 4
                val fastKm = round1(mainBudget * 0.45 / reps)
                val easyTotal = round1(mainBudget - fastKm * reps)
                segments += WorkoutSegment("Fartlek forte", "Alterne acelerações controladas em Z4 com recuperação leve.", distanceKm = fastKm, intensity = "MODERATE", rpeRange = "6-7", repeatCount = reps,
                    targetPaceMinValue = zones?.z4?.range?.fastestPaceValue, targetPaceMaxValue = zones?.z4?.range?.slowestPaceValue, paceZone = "Z4")
                if (easyTotal > 0.0) segments += asTimeTarget(WorkoutSegment("Fartlek leve", "Recupere em Z1 entre os trechos fortes; inicie a próxima repetição somente quando a respiração estiver controlada.", distanceKm = easyTotal / reps, intensity = "LOW", rpeRange = "3-4", repeatCount = reps,
                    targetPaceMinValue = zones?.z1?.range?.fastestPaceValue, targetPaceMaxValue = zones?.z1?.range?.slowestPaceValue, paceZone = "Z1"), zones)
            }
        }
        segments += asTimeTarget(WorkoutSegment("Desaquecimento", "Reduza gradualmente até encerrar a sessão.", distanceKm = coolKm, intensity = "LOW", rpeRange = "2-3",
            targetPaceMinValue = zones?.z1?.range?.fastestPaceValue, targetPaceMaxValue = zones?.z1?.range?.slowestPaceValue, paceZone = "Z1"), zones)
        val title = when (kind) {
            "PROGRESSIVE_RUN" -> "Corrida progressiva"
            "TEMPO_RUN" -> "Tempo run"
            "STEADY_RUN" -> "Corrida moderada"
            "THRESHOLD_INTERVAL" -> "Intervalos controlados (Z4 estimada)"
            "MARATHON_SPECIFIC" -> "Resistência específica (maratona)"
            "VO2_MAX_INTERVAL" -> "Intervalos de alta intensidade (Z5 estimada)"
            else -> "Fartlek controlado"
        }
        val objective = when (kind) {
            "PROGRESSIVE_RUN" -> "Praticar progressão de ritmo sem sair do controle aeróbio"
            "TEMPO_RUN", "THRESHOLD_INTERVAL" -> "Desenvolver resistência em intensidade sustentada estimada"
            "STEADY_RUN" -> "Desenvolver resistência em ritmo moderado e sustentável"
            "MARATHON_SPECIFIC" -> "Desenvolver resistência aeróbia específica para a maratona sem excesso de intensidade"
            "VO2_MAX_INTERVAL" -> "Desenvolver potência aeróbia com intervalos controlados"
            else -> "Desenvolver capacidade de variar o ritmo e recuperar em movimento"
        }
        val stimulus = when (kind) {
            "PROGRESSIVE_RUN" -> "PROGRESSION_RUN_Z2_Z3"
            "TEMPO_RUN" -> "TEMPO_RUN_Z4"
            "STEADY_RUN" -> "STEADY_RUN_Z3"
            "THRESHOLD_INTERVAL" -> "THRESHOLD_INTERVAL_Z4_ESTIMATED"
            "MARATHON_SPECIFIC" -> "MARATHON_ENDURANCE_Z2_Z3"
            "VO2_MAX_INTERVAL" -> "HIGH_INTENSITY_INTERVAL_Z5_ESTIMATED"
            else -> "FARTLEK_Z2_Z4"
        }
        val totalKm = segments.sumOf { (it.distanceKm ?: 0.0) * it.repeatCount }
        return workout(date, title, "Qualidade", objective, stimulus, totalKm, if (kind == "VO2_MAX_INTERVAL") "7-8" else "5-7", week, phase, segments,
            if (zones != null) "Sessão selecionada conforme a fase do ciclo, experiência e carga recente. A zona é calculada pela calibração atual; o RPE atua apenas como controle complementar." else "Sessão estruturada por distância e tempo, mas sem faixa individual de pace até registrar o Cooper. A intensidade deve permanecer dentro do RPE indicado.", "MODERATE")
    }

    private fun createLongRun(input: RunnerInput, date: LocalDate, km: Double, week: Int, phase: String): PrescribedWorkout {
        if (isNovicePlan(input)) return createRunWalk(date, km, week, phase, recovery = phase == "RECOVERY", isLongRun = true)
        val recoveryWeek = phase == "RECOVERY"
        val rpe = if (recoveryWeek) "2-3" else "3-4"
        val warmupKm = round1(km * 0.10)
        val mainKm = round1(km * 0.80)
        val cooldownKm = round1((km - warmupKm - mainKm).coerceAtLeast(0.0))
        val zones = PaceCalculator.calculateCooper(input.cooperDistanceKm, input.talkTestComfortPaceValues)
        val segments = listOf(
            asTimeTarget(WorkoutSegment("Aquecimento", "Comece muito leve e aumente gradualmente até o esforço confortável.", distanceKm = warmupKm, intensity = "LOW", rpeRange = "2-3",
                targetPaceMinValue = zones?.z1?.range?.fastestPaceValue, targetPaceMaxValue = zones?.z1?.range?.slowestPaceValue, paceZone = "Z1"), zones),
            WorkoutSegment("Longão aeróbio", "Mantenha esforço conversável e constante em Z2. Não transforme o longão em prova.", distanceKm = mainKm, intensity = "LOW", rpeRange = rpe,
                targetPaceMinValue = zones?.z2?.range?.fastestPaceValue, targetPaceMaxValue = zones?.z2?.range?.slowestPaceValue, paceZone = "Z2"),
            asTimeTarget(WorkoutSegment("Desaquecimento", "Reduza gradualmente até encerrar a sessão.", distanceKm = cooldownKm, intensity = "LOW", rpeRange = "1-2",
                targetPaceMinValue = zones?.z1?.range?.fastestPaceValue, targetPaceMaxValue = zones?.z1?.range?.slowestPaceValue, paceZone = "Z1"), zones)
        )
        return workout(date, if (recoveryWeek) "Longão aeróbio reduzido" else "Longão aeróbio", "Longo", "Desenvolver resistência com carga compatível com a tolerância recente", "AEROBIC_ENDURANCE", km, rpe, week, phase, segments,
            if (recoveryWeek) "Volume reduzido na semana regenerativa; mantenha esforço conversável em Z2. O termo regenerativo descreve a redução de carga, não uma mudança automática do longão para Z1."
            else if (zones != null) "Distância limitada pelo maior treino recente registrado, pela parcela da semana e pela distância-alvo. Pace longo derivado do resultado recente." else "Distância limitada pelo maior treino recente registrado, pela parcela da semana e pela distância-alvo. Informe um resultado recente para calibrar o pace.", "LOW")
    }

    /** Time-based beginner/re-entry session. Distance values are estimates for weekly-load accounting only. */
    private fun createRunWalk(
        date: LocalDate,
        km: Double,
        week: Int,
        phase: String,
        recovery: Boolean,
        isLongRun: Boolean
    ): PrescribedWorkout {
        val stage = when {
            week <= 2 -> 0
            week <= 4 -> 1
            week <= 6 -> 2
            else -> 3
        }
        val runMinutes = listOf(1, 2, 3, 5)[stage]
        val baseWalkMinutes = listOf(2, 2, 2, 2)[stage]
        val targetMinutes = (km * 8.0).toInt().coerceIn(15, if (isLongRun) 45 else 38)
        val warmCoolMinutes = if (targetMinutes >= 24) 4 else 3
        val intervalBudget = (targetMinutes - warmCoolMinutes * 2).coerceAtLeast(4)
        val baseRepeats = (intervalBudget / (runMinutes + baseWalkMinutes)).coerceIn(2, 6)
        val repeats = if (recovery) (baseRepeats - 1).coerceAtLeast(2) else baseRepeats
        val walkMinutes = if (recovery) baseWalkMinutes + 1 else baseWalkMinutes
        val warmKm = km * 0.10
        val coolKm = km * 0.10
        val runTotalKm = km * 0.55
        val walkTotalKm = (km - warmKm - coolKm - runTotalKm).coerceAtLeast(0.0)
        val segments = listOf(
            WorkoutSegment("Aquecimento caminhando", "Caminhe em ritmo confortável e mobilize tornozelos e quadris antes dos intervalos.",
                durationMin = warmCoolMinutes, distanceKm = warmKm, intensity = "LOW", rpeRange = "1-2"),
            WorkoutSegment("Corrida leve", "Corra relaxado, em esforço fácil. Deve ser possível falar frases curtas; não persiga pace.",
                durationMin = runMinutes, distanceKm = runTotalKm / repeats, intensity = "LOW", rpeRange = "3-4", repeatCount = repeats),
            WorkoutSegment("Caminhada de recuperação", "Caminhe até recuperar a respiração antes de iniciar o próximo intervalo. Não elimine as pausas.",
                durationMin = walkMinutes, distanceKm = walkTotalKm / repeats, intensity = "LOW", rpeRange = "1-2", repeatCount = repeats),
            WorkoutSegment("Desaquecimento caminhando", "Finalize caminhando devagar até a respiração voltar ao normal.",
                durationMin = warmCoolMinutes, distanceKm = coolKm, intensity = "LOW", rpeRange = "1-2")
        )
        val totalKm = segments.sumOf { (it.distanceKm ?: 0.0) * it.repeatCount }
        val duration = segments.sumOf { (it.durationMin ?: 0) * it.repeatCount }
        val title = when {
            isLongRun && recovery -> "Longão leve reduzido (corrida/caminhada)"
            isLongRun -> "Longão leve (corrida/caminhada)"
            recovery -> "Corrida/caminhada regenerativa"
            else -> "Corrida/caminhada intervalada"
        }
        return workout(date, title, if (isLongRun) "Longo" else if (recovery) "Recuperação" else "Aeróbio",
            "Desenvolver tolerância gradual à corrida e consistência sem forçar corrida contínua",
            if (isLongRun) "BEGINNER_RUN_WALK_LONG" else "BEGINNER_RUN_WALK",
            totalKm, if (recovery) "2-3" else "3-4", week, phase, segments,
            "Prescrição por tempo, alternando corrida leve e caminhada. A distância indicada é estimada para controle de volume; siga os minutos e o esforço, não um pace. A semana regenerativa reduz repetições e amplia a caminhada.", "LOW")
            .copy(durationMin = duration)
    }

    /**
     * Com pace calibrado, aquecimento, recuperação e desaquecimento são mais naturais por tempo.
     * Sem referência recente, mantém esses blocos por distância e não presume uma velocidade.
     * distanceKm em um bloco TIME é somente a contribuição estimada para o volume semanal.
     */
    private fun asTimeTarget(segment: WorkoutSegment, zones: TrainingPaceZones?): WorkoutSegment {
        if (zones == null) return segment
        val estimatedDistance = segment.distanceKm ?: return segment
        val midpointPace = if (segment.targetPaceMinValue != null && segment.targetPaceMaxValue != null) {
            (segment.targetPaceMinValue + segment.targetPaceMaxValue) / 2.0
        } else {
            return segment
        }
        val minutes = kotlin.math.round(estimatedDistance * midpointPace / 60.0).toInt().coerceAtLeast(1)
        return segment.copy(durationMin = minutes, targetMode = "TIME")
    }

    private fun workout(date: LocalDate, title: String, type: String, objective: String, stimulus: String, distanceKm: Double, rpe: String,
        week: Int, phase: String, segments: List<WorkoutSegment>, rationale: String, intensity: String): PrescribedWorkout {
        val weightedPace = segments.mapNotNull { segment ->
            val minPace = segment.targetPaceMinValue
            val maxPace = segment.targetPaceMaxValue
            val distance = segment.distanceKm
            if (minPace != null && maxPace != null && distance != null && distance > 0.0) {
                (minPace + maxPace) / 2.0 to (distance * segment.repeatCount)
            } else null
        }
        val averagePace = if (weightedPace.isNotEmpty()) weightedPace.sumOf { it.first * it.second } / weightedPace.sumOf { it.second } else 420.0
        val explicitDuration = segments.sumOf { (it.durationMin ?: 0) * it.repeatCount }
        val duration = max(15, if (explicitDuration > 0) explicitDuration else kotlin.math.round(distanceKm * averagePace / 60.0).toInt())
        val dayName = date.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, Locale.forLanguageTag("pt-BR"))
        val dateLabel = "${dayName.replaceFirstChar { it.uppercase(Locale.forLanguageTag("pt-BR")) }}, ${date.format(DateTimeFormatter.ofPattern("dd/MM"))}"
        val detail = formatSegments(segments)
        val id = "W$week-${date.dayOfWeek.name}-${type.uppercase(Locale.US).replace(' ', '-')}"
        return PrescribedWorkout(dayName.replaceFirstChar { it.uppercase(Locale.forLanguageTag("pt-BR")) }, dateLabel, date.toString(), title, type, objective, stimulus,
            id, round1(distanceKm), duration, intensity,
            if (segments.any { it.targetPaceMinValue != null && it.targetPaceMaxValue != null }) "PACE_RANGE" else "PACE_NOT_CALIBRATED",
            rpe, detail, rationale, week, phase, segments)
    }

    private fun formatSegments(segments: List<WorkoutSegment>): String = segments.joinToString(" • ") { segment ->
        val dose = when {
            segment.targetMode == "TIME" && segment.repeatCount > 1 && segment.durationMin != null -> "${segment.repeatCount} × ${segment.durationMin} min"
            segment.targetMode == "TIME" && segment.durationMin != null -> "${segment.durationMin} min"
            segment.repeatCount > 1 && segment.distanceKm != null -> "${segment.repeatCount} × ${formatKm(segment.distanceKm)} km"
            segment.distanceKm != null -> "${formatKm(segment.distanceKm)} km"
            segment.durationMin != null -> "${segment.durationMin} min"
            else -> ""
        }
        val pace = if (segment.targetPaceMinValue != null && segment.targetPaceMaxValue != null) {
            "pace ${PaceRange(segment.targetPaceMinValue, segment.targetPaceMaxValue).label()}"
        } else "pace não calibrado"
        val zone = segment.paceZone?.let { "$it • " } ?: ""
        "${segment.name}: $dose ($zone$pace; RPE auxiliar ${segment.rpeRange})"
    }

    private fun trainingDays(input: RunnerInput): List<DayOfWeek> =
        TrainingScheduleEngine.prescribedRunningDays(
            input.availableDays, input.frequency, isNovicePlan(input), input.preferredLongRunDay
        )

    private fun isNovicePlan(input: RunnerInput): Boolean =
        input.level == "Iniciante" || input.weeklyVolumeKm < 8.0 || input.longestRecentKm < 5.0


    private fun recoveryStatus(score: Double?): String = when {
        score == null -> "UNKNOWN"
        score >= 75.0 -> "GOOD"
        score >= 50.0 -> "MODERATE"
        else -> "POOR"
    }

    private fun safetyStatus(input: RunnerInput): String = when {
        input.painPresent -> "RED"
        input.fatigueScore != null && input.fatigueScore >= 75.0 -> "YELLOW"
        input.recoveryScore != null && input.recoveryScore < 25.0 -> "YELLOW"
        input.recoveryScore == null && input.fatigueScore == null -> "UNASSESSED"
        else -> "GREEN"
    }

    private fun buildFlags(input: RunnerInput, recovery: String, safety: String): List<String> = buildList {
        if (input.frequency < 3) add("LOW_FREQUENCY")
        if (input.weeklyVolumeKm == 0.0) add("NO_RECENT_WEEKLY_VOLUME")
        if (input.longestRecentKm < 5.0) add("LIMITED_LONG_RUN_HISTORY")
        if (input.fatigueScore != null && input.fatigueScore >= 75.0) add("HIGH_FATIGUE")
        if (input.recentActivityHistoryReliable) add("RECENT_LOAD_FROM_LOGGED_ACTIVITIES")
        else if (input.recentActivityCount > 0) add("RECENT_ACTIVITY_HISTORY_PARTIAL")
        if (isNovicePlan(input)) add("BEGINNER_RUN_WALK_MAX_THREE_SESSIONS")
        if (input.longestRecentKm > 0.0) add("SINGLE_SESSION_CAP_BASED_ON_RECENT_TOLERANCE")
        val days = trainingDays(input)
        val longDay = input.preferredLongRunDay?.takeIf { it in days } ?: days.last()
        val qualityPrerequisites = !isNovicePlan(input) && input.frequency >= 3 &&
            input.weeklyVolumeKm >= 16.0 && input.longestRecentKm >= 8.0
        if (qualityPrerequisites && TrainingScheduleEngine.qualityDayWithRecoveryGap(days, longDay) == null) {
            add("QUALITY_SUPPRESSED_BY_RECOVERY_SPACING")
        }
        if (recovery == "POOR") add("LOW_RECOVERY")
        if (safety == "UNASSESSED") add("READINESS_NOT_ASSESSED")
        if (safety == "RED") add("PAIN_REPORTED")
    }

    private fun roundHalf(value: Double): Double = kotlin.math.floor(value * 2.0 + 0.5) / 2.0
    private fun floorHalf(value: Double): Double = kotlin.math.floor(value * 2.0) / 2.0
    private fun round1(value: Double): Double = kotlin.math.round(value * 10.0) / 10.0
    internal fun formatKm(value: Double): String = if (value % 1.0 == 0.0) value.toInt().toString() else String.format(Locale.US, "%.1f", value)
    internal fun nextMonday(from: LocalDate): LocalDate = from.with(TemporalAdjusters.nextOrSame(DayOfWeek.MONDAY))
}
