package com.airunningcoach.app

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/**
 * Motor local de prescrição do AI Running Coach — V18.
 *
 * Reaproveita a arquitetura de domínio do Laps (geração de ciclos, progressão,
 * semanas regenerativas e distribuição de estímulos), mas remove dependências
 * de COROS/Google Calendar e acrescenta limites baseados na tolerância recente.
 *
 * A prescrição é determinística e explicável. Não afirma possuir dados fisiológicos
 * que o usuário não informou e não inventa ritmos-alvo.
 */
internal data class RunnerInput(
    val goalKm: Double,
    val level: String,
    val frequency: Int,
    val weeklyVolumeMinKm: Double,
    val longestRecentKm: Double,
    val painPresent: Boolean = false,
    val recoveryScore: Double? = null,
    val fatigueScore: Double? = null,
    val planWeeks: Int = 4,
    val startDate: LocalDate = LocalDate.now().with(TemporalAdjusters.nextOrSame(DayOfWeek.MONDAY))
)

internal data class MotorState(
    val fitnessConfidence: String,
    val paceConfidence: String,
    val recentVolumeKm: Double,
    val recentLongRunKm: Double,
    val recoveryStatus: String,
    val safetyStatus: String,
    val phase: String,
    val flags: List<String>
)

internal data class MotorDecision(
    val action: String,
    val necessity: String,
    val stimulus: String,
    val rationale: String,
    val confidence: Double,
    val safety: String
)

/** Segmento estruturado destinado à futura importação pelo Pace Coach. */
internal data class WorkoutSegment(
    val name: String,
    val instruction: String,
    val durationMin: Int? = null,
    val distanceKm: Double? = null,
    val intensity: String = "LOW",
    val rpeRange: String = "2-3",
    val repeatCount: Int = 1
)

internal data class PrescribedWorkout(
    val day: String,
    val date: String,
    val scheduledDateIso: String,
    val title: String,
    val type: String,
    val objective: String,
    val stimulus: String,
    val sessionId: String,
    val distanceKm: Double,
    val durationMin: Int,
    val intensity: String,
    val paceMode: String,
    val rpeRange: String,
    val detail: String,
    val rationale: String,
    val week: Int = 1,
    val phase: String = "BASE",
    val segments: List<WorkoutSegment> = emptyList()
)

internal data class WeeklyPlanSummary(
    val week: Int,
    val phase: String,
    val totalKm: Double,
    val workoutCount: Int,
    val isRecoveryWeek: Boolean
)

internal data class MotorPlan(
    val state: MotorState,
    val decision: MotorDecision,
    val workouts: List<PrescribedWorkout>,
    val weeklyKm: Double,
    val explanation: String,
    val weeklySummaries: List<WeeklyPlanSummary>
)

internal object RunningCoachEngine {
    fun generate(input: RunnerInput): MotorPlan {
        require(input.frequency in 2..6) { "A frequência deve estar entre 2 e 6 dias por semana." }
        require(input.goalKm > 0.0) { "O objetivo precisa ser maior que zero." }
        require(input.weeklyVolumeMinKm >= 0.0) { "O volume semanal não pode ser negativo." }
        require(input.longestRecentKm >= 0.0) { "O maior treino recente não pode ser negativo." }

        val recovery = recoveryStatus(input.recoveryScore)
        val safety = safetyStatus(input)
        val flags = buildFlags(input, recovery, safety)
        val state = MotorState(
            fitnessConfidence = if (input.weeklyVolumeMinKm > 0 && input.longestRecentKm > 0) "LOW" else "VERY_LOW",
            paceConfidence = "VERY_LOW",
            recentVolumeKm = input.weeklyVolumeMinKm,
            recentLongRunKm = input.longestRecentKm,
            recoveryStatus = recovery,
            safetyStatus = safety,
            phase = if (recovery == "POOR") "RECOVERY" else "BASE_AND_BUILD",
            flags = flags
        )

        if (safety == "RED") {
            val decision = MotorDecision(
                action = "BLOCK",
                necessity = "SAFETY_REVIEW",
                stimulus = "NONE",
                rationale = "Há relato de dor. O motor não gera sessões de corrida; priorize avaliação adequada antes de retomar a carga.",
                confidence = 0.99,
                safety = "RED"
            )
            return MotorPlan(state, decision, emptyList(), 0.0, decision.rationale, emptyList())
        }

        val weeks = input.planWeeks.coerceIn(4, 16)
        val baseVolume = input.weeklyVolumeMinKm.coerceIn(8.0, 100.0)
        val workouts = mutableListOf<PrescribedWorkout>()
        val summaries = mutableListOf<WeeklyPlanSummary>()

        for (week in 1..weeks) {
            val cycleWeek = (week - 1) % 4
            val isRecoveryWeek = cycleWeek == 3
            val blockIndex = (week - 1) / 4
            val blockFactor = (1.0 + blockIndex * 0.05).coerceAtMost(1.20)
            val buildFactor = when (cycleWeek) {
                0 -> 0.90
                1 -> 0.95
                2 -> 1.00
                else -> 0.78
            }
            val recoveryFactor = when {
                recovery == "POOR" -> 0.72
                safety == "YELLOW" -> 0.82
                else -> 1.0
            }
            val targetWeekKm = max(5.0, baseVolume * blockFactor * buildFactor * recoveryFactor)
            val weekPhase = when {
                recovery == "POOR" || isRecoveryWeek -> "RECOVERY"
                cycleWeek == 0 -> "ADAPTATION"
                cycleWeek == 1 -> "CONSOLIDATION"
                else -> "PROGRESSION"
            }
            var weekSessions = buildWeek(input, targetWeekKm, week, weekPhase, isRecoveryWeek || recovery == "POOR" || safety == "YELLOW")
            if (isRecoveryWeek) {
                val previousWeekKm = summaries.lastOrNull()?.totalKm ?: 0.0
                val currentWeekKm = weekSessions.sumOf { it.distanceKm }
                val recoveryCeiling = previousWeekKm * 0.78
                if (previousWeekKm > 0.0 && currentWeekKm > recoveryCeiling) {
                    val scale = recoveryCeiling / currentWeekKm
                    weekSessions = weekSessions.map { workout ->
                        val adjustedDistance = round1((workout.distanceKm * scale).coerceAtLeast(0.5))
                        val adjustedSegments = workout.segments.map { segment ->
                            if (segment.distanceKm != null) segment.copy(distanceKm = round1((segment.distanceKm * scale).coerceAtLeast(0.5))) else segment
                        }
                        workout.copy(
                            distanceKm = adjustedDistance,
                            durationMin = max(15, (adjustedDistance * 7.0).toInt()),
                            detail = formatSegments(adjustedSegments),
                            segments = adjustedSegments
                        )
                    }
                }
            }
            workouts += weekSessions
            summaries += WeeklyPlanSummary(
                week = week,
                phase = weekPhase,
                totalKm = round1(weekSessions.sumOf { it.distanceKm }),
                workoutCount = weekSessions.size,
                isRecoveryWeek = isRecoveryWeek || recovery == "POOR" || safety == "YELLOW"
            )
        }

        val firstWeekKm = summaries.firstOrNull()?.totalKm ?: 0.0
        val hasQuality = workouts.any { it.type == "Qualidade" }
        val necessity = when {
            recovery == "POOR" -> "RECOVERY_FIRST"
            input.goalKm <= 10.0 -> "AEROBIC_DEVELOPMENT"
            else -> "ENDURANCE_DEVELOPMENT"
        }
        val stimulus = when {
            recovery == "POOR" || safety == "YELLOW" -> "LOW_INTENSITY_AEROBIC"
            hasQuality -> "AEROBIC_BASE_AND_CONTROLLED_QUALITY"
            else -> "AEROBIC_BASE"
        }
        val rationale = when {
            recovery == "POOR" -> "A recuperação informada está baixa. O ciclo foi reduzido e os estímulos de qualidade foram suspensos temporariamente."
            safety == "YELLOW" -> "Os sinais de fadiga exigem uma semana conservadora, sem estímulos intensos. Reavalie a recuperação antes de aumentar a carga."
            input.level == "Iniciante" -> "O plano prioriza consistência e adaptação. A qualidade, quando presente, é curta e controlada por percepção de esforço."
            else -> "O plano alterna estímulos aeróbios, um estímulo controlado de qualidade e longão, com semanas regenerativas planejadas."
        }
        val decision = MotorDecision(
            action = if (recovery == "POOR" || safety == "YELLOW") "REDUCE_LOAD" else "PRESCRIBE",
            necessity = necessity,
            stimulus = stimulus,
            rationale = rationale,
            confidence = if (state.fitnessConfidence == "LOW") 0.68 else 0.45,
            safety = safety
        )
        val explanation = buildString {
            append("Ciclo de $weeks semanas inspirado na arquitetura de periodização do Laps. ")
            append("O volume parte do limite conservador informado, progride em pequenos passos e inclui semanas regenerativas. O volume de referência é um teto: o motor não força toda a quilometragem quando o histórico recente ou a frequência não justificam sessões longas. ")
            append("A dose do longão é limitada pela tolerância recente e pela parcela do volume semanal. ")
            append("Sem histórico de ritmo, a intensidade é orientada por RPE; nenhum pace exato é inventado. ")
            append("A distribuição 80/20 é tratada como princípio de predominância leve, não como promessa matemática de proporção por distância.")
        }
        return MotorPlan(state, decision, workouts, firstWeekKm, explanation, summaries)
    }

    private fun buildWeek(
        input: RunnerInput,
        targetWeekKm: Double,
        week: Int,
        phase: String,
        suppressQuality: Boolean
    ): List<PrescribedWorkout> {
        val days = trainingDays(input.frequency)
        val dayCount = days.size
        val longShare = when (input.frequency) {
            2 -> 0.35
            3 -> 0.34
            else -> 0.32
        }
        val goalLongCap = when {
            input.goalKm <= 5.0 -> 8.0
            input.goalKm <= 10.0 -> 12.0
            input.goalKm <= 21.1 -> 22.0
            else -> 30.0
        }
        val growthSteps = week - 1
        val conditionCap = when {
            input.recoveryScore != null && input.recoveryScore < 50.0 -> 0.72
            input.fatigueScore != null && input.fatigueScore >= 75.0 -> 0.82
            else -> 1.0
        }
        val cycleCap = if ((week - 1) % 4 == 3) 0.85 else 1.0
        val historyCap = max(2.0, (input.longestRecentKm + growthSteps * 0.35) * conditionCap * cycleCap)
        val longKm = floorHalf(min(targetWeekKm * longShare, min(historyCap, goalLongCap))).coerceAtLeast(2.0)
        val hasQuality = dayCount >= 3 && targetWeekKm >= 14.0 && !suppressQuality
        val qualityShare = if (input.level == "Iniciante") 0.12 else 0.18
        val qualityKm = if (hasQuality) roundHalf(targetWeekKm * qualityShare).coerceAtLeast(2.5) else 0.0
        val easyCount = dayCount - 1 - if (hasQuality) 1 else 0
        val easyTotal = max(0.0, targetWeekKm - longKm - qualityKm)
        // O volume informado é um teto de referência, não uma meta a ser forçada.
        // Limita cada rodagem fácil para não concentrar volume excessivo em poucos dias.
        val easySessionCap = min(targetWeekKm * 0.45, max(1.0, historyCap * 1.1))
        val easyPerSession = if (easyCount > 0) {
            floorHalf(min(easyTotal / easyCount, easySessionCap)).coerceAtLeast(0.5)
        } else 0.0
        val easyDistances = MutableList(easyCount) { easyPerSession }

        val startMonday = input.startDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        var easyIndex = 0
        return days.mapIndexed { index, day ->
            val date = startMonday.plusWeeks((week - 1).toLong()).plusDays(day.value - 1L)
            when {
                day == DayOfWeek.SUNDAY -> createLongRun(date, longKm, week, phase)
                hasQuality && index == 1 -> createQuality(input, date, qualityKm, week, phase)
                else -> {
                    val km = easyDistances.getOrElse(easyIndex++) { 2.0 }
                    createEasy(input, date, km, week, phase, recovery = suppressQuality)
                }
            }
        }
    }

    private fun createEasy(
        input: RunnerInput,
        date: LocalDate,
        km: Double,
        week: Int,
        phase: String,
        recovery: Boolean
    ): PrescribedWorkout {
        val beginner = input.level == "Iniciante"
        val title = when {
            recovery -> "Rodagem regenerativa"
            beginner -> "Corrida leve / caminhada"
            else -> "Rodagem aeróbia"
        }
        val rpe = if (recovery) "2-3" else "3-4"
        val segments = listOf(
            WorkoutSegment("Aquecimento", "Caminhada ativa ou trote confortável.", 5, intensity = "LOW", rpeRange = "2-3"),
            WorkoutSegment("Bloco aeróbio", "Converse em frases completas; reduza o ritmo se a respiração ficar difícil.", distanceKm = round1(km), intensity = "LOW", rpeRange = rpe),
            WorkoutSegment("Desaquecimento", "Reduza gradualmente o esforço e caminhe ao final.", 5, intensity = "LOW", rpeRange = "1-2")
        )
        return workout(
            date, title, if (recovery) "Recuperação" else "Aeróbio", "Construir consistência aeróbia",
            if (recovery) "RECOVERY" else "AEROBIC_BASE", km, rpe, week, phase, segments,
            if (recovery) "Carga baixa para facilitar a recuperação." else "Estímulo leve, sem ritmo-alvo fixo por falta de dados de desempenho.",
            "LOW"
        )
    }

    private fun createQuality(
        input: RunnerInput,
        date: LocalDate,
        km: Double,
        week: Int,
        phase: String
    ): PrescribedWorkout {
        val beginner = input.level == "Iniciante"
        val mainTitle = if (beginner) "Fartlek introdutório" else if (week % 2 == 0) "Tempo controlado" else "Intervalos de limiar controlados"
        val repetitions = if (beginner) 4 else 3
        val workMinutes = if (beginner) 1 else 4
        val recoveryMinutes = if (beginner) 2 else 3
        val segments = listOf(
            WorkoutSegment("Aquecimento", "Trote muito confortável; finalize com mobilidade dinâmica.", 12, intensity = "LOW", rpeRange = "2-3"),
            WorkoutSegment("Estímulo principal", if (beginner) "Aumente o esforço sem sprintar; mantenha técnica relaxada." else "Esforço forte-controlado; termine cada repetição sentindo que conseguiria mais uma.", workMinutes, intensity = "MODERATE", rpeRange = if (beginner) "5-6" else "6-7", repeatCount = repetitions),
            WorkoutSegment("Recuperação entre repetições", "Trote ou caminhada leve até recuperar a respiração.", recoveryMinutes, intensity = "LOW", rpeRange = "2-3", repeatCount = repetitions - 1),
            WorkoutSegment("Desaquecimento", "Trote leve seguido de caminhada.", 10, intensity = "LOW", rpeRange = "2-3")
        )
        return workout(
            date, mainTitle, "Qualidade", "Desenvolver tolerância a esforço moderado de forma controlada",
            if (beginner) "VARIABLE_AEROBIC" else "THRESHOLD_CONTROLLED", km,
            if (beginner) "5-6" else "6-7", week, phase, segments,
            "A sessão usa percepção de esforço; não há pace ou frequência cardíaca individual suficiente para prescrever números exatos.",
            "MODERATE"
        )
    }

    private fun createLongRun(
        date: LocalDate,
        km: Double,
        week: Int,
        phase: String
    ): PrescribedWorkout {
        val recoveryWeek = phase == "RECOVERY"
        val rpe = if (recoveryWeek) "2-3" else "3-4"
        val segments = listOf(
            WorkoutSegment("Aquecimento", "Comece muito leve e aumente gradualmente até o esforço confortável.", 8, intensity = "LOW", rpeRange = "2-3"),
            WorkoutSegment("Longão aeróbio", "Mantenha esforço conversável e constante. Não transforme o longão em prova.", distanceKm = round1(km), intensity = "LOW", rpeRange = rpe),
            WorkoutSegment("Desaquecimento", "Caminhe alguns minutos e finalize sem esforço.", 5, intensity = "LOW", rpeRange = "1-2")
        )
        return workout(
            date, if (recoveryWeek) "Longão regenerativo" else "Longão aeróbio", "Longo",
            "Desenvolver resistência com carga compatível com a tolerância recente", "AEROBIC_ENDURANCE",
            km, rpe, week, phase, segments,
            "Distância limitada ao histórico recente e a aproximadamente um terço do volume semanal.",
            "LOW"
        )
    }

    private fun workout(
        date: LocalDate,
        title: String,
        type: String,
        objective: String,
        stimulus: String,
        distanceKm: Double,
        rpe: String,
        week: Int,
        phase: String,
        segments: List<WorkoutSegment>,
        rationale: String,
        intensity: String
    ): PrescribedWorkout {
        val duration = max(15, (distanceKm * 7.0).toInt())
        val dayName = date.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, Locale.forLanguageTag("pt-BR"))
        val dateLabel = "${dayName.replaceFirstChar { it.uppercase(Locale.forLanguageTag("pt-BR")) }}, ${date.format(DateTimeFormatter.ofPattern("dd/MM"))}"
        val detail = formatSegments(segments)
        val id = "W${week}-${date.dayOfWeek.name}-${type.uppercase(Locale.US).replace(' ', '-') }"
        return PrescribedWorkout(
            day = dayName.replaceFirstChar { it.uppercase(Locale.forLanguageTag("pt-BR")) },
            date = dateLabel,
            scheduledDateIso = date.toString(),
            title = title,
            type = type,
            objective = objective,
            stimulus = stimulus,
            sessionId = id,
            distanceKm = round1(distanceKm),
            durationMin = duration,
            intensity = intensity,
            paceMode = "RPE",
            rpeRange = rpe,
            detail = detail,
            rationale = rationale,
            week = week,
            phase = phase,
            segments = segments
        )
    }

    private fun formatSegments(segments: List<WorkoutSegment>): String = segments.joinToString(" • ") { segment ->
        val dose = when {
            segment.repeatCount > 1 && segment.durationMin != null -> "${segment.repeatCount} × ${segment.durationMin} min"
            segment.distanceKm != null -> "${formatKm(segment.distanceKm)} km"
            segment.durationMin != null -> "${segment.durationMin} min"
            else -> ""
        }
        "${segment.name}: $dose (RPE ${segment.rpeRange})"
    }

    private fun trainingDays(frequency: Int): List<DayOfWeek> = when (frequency) {
        2 -> listOf(DayOfWeek.TUESDAY, DayOfWeek.SUNDAY)
        3 -> listOf(DayOfWeek.TUESDAY, DayOfWeek.THURSDAY, DayOfWeek.SUNDAY)
        4 -> listOf(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY, DayOfWeek.SUNDAY)
        5 -> listOf(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.THURSDAY, DayOfWeek.SATURDAY, DayOfWeek.SUNDAY)
        else -> listOf(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY, DayOfWeek.SATURDAY, DayOfWeek.SUNDAY)
    }

    private fun recoveryStatus(score: Double?): String = when {
        score == null -> "UNKNOWN"
        score >= 75.0 -> "GOOD"
        score >= 50.0 -> "MODERATE"
        else -> "POOR"
    }

    private fun safetyStatus(input: RunnerInput): String = when {
        input.painPresent -> "RED"
        input.fatigueScore != null && input.fatigueScore >= 75.0 -> "YELLOW"
        input.recoveryScore != null && input.recoveryScore < 25.0 -> "YELLOW"
        else -> "GREEN"
    }

    private fun buildFlags(input: RunnerInput, recovery: String, safety: String): List<String> = buildList {
        if (input.frequency < 3) add("LOW_FREQUENCY")
        if (input.longestRecentKm < 5.0) add("LIMITED_LONG_RUN_HISTORY")
        if (input.fatigueScore != null && input.fatigueScore >= 75.0) add("HIGH_FATIGUE")
        if (recovery == "POOR") add("LOW_RECOVERY")
        if (safety == "RED") add("PAIN_REPORTED")
        if (input.weeklyVolumeMinKm <= 10.0) add("LOW_WEEKLY_BASELINE")
    }

    private fun roundHalf(value: Double): Double = kotlin.math.round(value * 2.0) / 2.0
    private fun floorHalf(value: Double): Double = kotlin.math.floor(value * 2.0) / 2.0
    private fun round1(value: Double): Double = kotlin.math.round(value * 10.0) / 10.0

    internal fun formatKm(value: Double): String = if (value % 1.0 == 0.0) value.toInt().toString() else String.format(Locale.US, "%.1f", value)

    internal fun nextMonday(from: LocalDate): LocalDate = from.with(TemporalAdjusters.nextOrSame(DayOfWeek.MONDAY))
}
