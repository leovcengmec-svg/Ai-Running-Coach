package com.airunningcoach.app

import kotlin.math.max
import kotlin.math.min

/**
 * Motor de prescrição local do AI Running Coach.
 *
 * Mantém no Android o contrato central do Core V1.2:
 * ESTADO -> OBJETIVO -> NECESSIDADE -> ESTÍMULO -> SESSÃO -> DOSE -> VALIDAÇÃO -> PRESCRIÇÃO.
 *
 * O app não executa treinos. Ele somente gera prescrições estruturadas para revisão/exportação.
 */

internal data class RunnerInput(
    val goalKm: Double,
    val level: String,
    val frequency: Int,
    val weeklyVolumeMinKm: Double,
    val longestRecentKm: Double,
    val painPresent: Boolean = false,
    val recoveryScore: Double? = null,
    val fatigueScore: Double? = null
)

internal data class MotorState(
    val fitnessConfidence: String,
    val paceConfidence: String,
    val recentVolumeKm: Double,
    val recentLongRunKm: Double,
    val recoveryStatus: String,
    val safetyStatus: String,
    val phase: String,
    val flags: List<String>
)

internal data class MotorDecision(
    val action: String,
    val necessity: String,
    val stimulus: String,
    val rationale: String,
    val confidence: Double,
    val safety: String
)

internal data class PrescribedWorkout(
    val day: String,
    val title: String,
    val type: String,
    val objective: String,
    val stimulus: String,
    val sessionId: String,
    val distanceKm: Double,
    val durationMin: Int,
    val intensity: String,
    val paceMode: String,
    val rpeRange: String,
    val detail: String,
    val rationale: String,
    val week: Int = 1
)

internal data class MotorPlan(
    val state: MotorState,
    val decision: MotorDecision,
    val workouts: List<PrescribedWorkout>,
    val weeklyKm: Double,
    val explanation: String
)

internal object RunningCoachEngine {
    fun generate(input: RunnerInput): MotorPlan {
        val safety = safety(input)
        val recovery = recovery(input)
        val phase = phase(input, recovery)
        val state = MotorState(
            fitnessConfidence = "VERY_LOW",
            paceConfidence = "VERY_LOW",
            recentVolumeKm = input.weeklyVolumeMinKm,
            recentLongRunKm = input.longestRecentKm,
            recoveryStatus = recovery,
            safetyStatus = safety,
            phase = phase,
            flags = buildFlags(input)
        )

        if (safety == "RED") {
            val decision = MotorDecision(
                action = "ESCALATE",
                necessity = "SAFETY",
                stimulus = "NONE",
                rationale = "O motor bloqueou a prescrição normal por uma condição de segurança informada.",
                confidence = 0.99,
                safety = "RED"
            )
            return MotorPlan(state, decision, emptyList(), 0.0, decision.rationale)
        }

        val necessity = if (recovery == "POOR") "RECOVERY" else if (input.goalKm <= 10.0) "AEROBIC_DEVELOPMENT" else "ENDURANCE"
        val stimulus = when (necessity) {
            "RECOVERY" -> "RECOVERY"
            "ENDURANCE" -> "AEROBIC_ENDURANCE"
            else -> "AEROBIC_BASE"
        }
        val decision = MotorDecision(
            action = if (necessity == "RECOVERY") "RECOVER" else "PRESCRIBE",
            necessity = necessity,
            stimulus = stimulus,
            rationale = rationale(input, necessity),
            confidence = 0.55,
            safety = safety
        )

        val workouts = buildWeek1(input, state)
        val total = workouts.sumOf { it.distanceKm }
        val explanation = "Semana 1 calculada pelo motor a partir do volume informado, maior treino recente, nível, frequência e objetivo. O motor usa o limite inferior do volume informado como referência conservadora quando existe apenas uma faixa. Ritmo exato não é inventado sem dados de desempenho."
        return MotorPlan(state, decision, workouts, total, explanation)
    }

    private fun buildWeek1(input: RunnerInput, state: MotorState): List<PrescribedWorkout> {
        val days = when (input.frequency) {
            2 -> listOf("Terça", "Domingo")
            3 -> listOf("Terça", "Quinta", "Domingo")
            4 -> listOf("Terça", "Quinta", "Sábado", "Domingo")
            5 -> listOf("Segunda", "Terça", "Quinta", "Sábado", "Domingo")
            else -> listOf("Segunda", "Terça", "Quarta", "Quinta", "Sábado", "Domingo")
        }

        val weekly = conservativeWeeklyBaseline(input.weeklyVolumeMinKm)
        val longKm = longRunDose(input, weekly)
        val remaining = max(0.0, weekly - longKm)

        if (state.recoveryStatus == "POOR") {
            return recoveryWeek(days, weekly, longKm)
        }

        val workouts = mutableListOf<PrescribedWorkout>()
        when (input.frequency) {
            2 -> {
                val easy = roundHalf(max(3.0, remaining * 0.48))
                workouts += easyWorkout(days[0], easy, "EASY-01")
                workouts += longWorkout(days[1], longKm)
            }
            3 -> {
                val easy = roundHalf(max(2.5, remaining * 0.50))
                val quality = roundHalf(max(2.5, remaining - easy))
                workouts += easyWorkout(days[0], easy, "EASY-01")
                workouts += fartlekWorkout(days[1], quality)
                workouts += longWorkout(days[2], longKm)
            }
            else -> {
                val easy = roundHalf(max(2.5, remaining * 0.38))
                val quality = roundHalf(max(2.5, remaining * 0.30))
                val recovery = roundHalf(max(2.0, remaining - easy - quality))
                workouts += easyWorkout(days[0], easy, "EASY-01")
                workouts += fartlekWorkout(days[1], quality)
                workouts += easyWorkout(days[2], recovery, "REC-01")
                workouts += longWorkout(days.last(), longKm)
                while (workouts.size < input.frequency) {
                    workouts.add(easyWorkout(days[workouts.size], 2.0, "EASY-02"))
                }
            }
        }
        return workouts.take(input.frequency).map { it.copy(week = 1) }
    }

    private fun recoveryWeek(days: List<String>, weekly: Double, longKm: Double): List<PrescribedWorkout> {
        val count = days.size
        val per = roundHalf(max(2.0, weekly / count))
        return days.mapIndexed { index, day ->
            if (index == count - 1) longWorkout(day, min(longKm, per + 0.5), recovery = true)
            else easyWorkout(day, per, "REC-01")
        }
    }

    private fun easyWorkout(day: String, km: Double, sessionId: String): PrescribedWorkout {
        val recovery = sessionId == "REC-01"
        return PrescribedWorkout(
            day = day,
            title = if (recovery) "Rodagem regenerativa" else "Rodagem leve",
            type = if (recovery) "Recuperação" else "Aeróbio",
            objective = if (recovery) "Facilitar recuperação" else "Construir base aeróbia",
            stimulus = if (recovery) "RECOVERY" else "AEROBIC_BASE",
            sessionId = sessionId,
            distanceKm = km,
            durationMin = durationFor(km, recovery),
            intensity = "LOW",
            paceMode = "RPE",
            rpeRange = if (recovery) "2-3" else "3-4",
            detail = if (recovery) "${formatKm(km)} km • esforço RPE 2–3" else "${formatKm(km)} km • esforço RPE 3–4",
            rationale = if (recovery) "Dose reduzida para recuperação." else "Dose aeróbia baixa, sem pace exato por falta de dados de desempenho."
        )
    }

    private fun fartlekWorkout(day: String, km: Double): PrescribedWorkout {
        return PrescribedWorkout(
            day = day,
            title = "Fartlek controlado",
            type = "Qualidade",
            objective = "Introduzir estímulo de qualidade sem exigir pace exato",
            stimulus = "VARIABLE_AEROBIC",
            sessionId = "FART-01",
            distanceKm = km,
            durationMin = durationFor(km, false),
            intensity = "MODERATE",
            paceMode = "RPE",
            rpeRange = "4-6",
            detail = "Aquecimento leve + 4 × 1 min moderado / 2 min leve + desaquecimento",
            rationale = "Primeiro estímulo de qualidade é controlado por percepção de esforço e não por velocidade inventada."
        )
    }

    private fun longWorkout(day: String, km: Double, recovery: Boolean = false): PrescribedWorkout {
        return PrescribedWorkout(
            day = day,
            title = if (recovery) "Longão muito leve" else "Longão fácil",
            type = "Longo",
            objective = "Desenvolver resistência sem excesso de carga",
            stimulus = "AEROBIC_ENDURANCE",
            sessionId = "LONG-01",
            distanceKm = km,
            durationMin = durationFor(km, false),
            intensity = "LOW",
            paceMode = "RPE",
            rpeRange = "3-4",
            detail = "${formatKm(km)} km • RPE 3–4 • sem pace exato",
            rationale = "Longão ancorado na tolerância recente e limitado pelo volume semanal conservador."
        )
    }

    private fun conservativeWeeklyBaseline(minKm: Double): Double = max(8.0, minKm)

    private fun longRunDose(input: RunnerInput, weekly: Double): Double {
        val beginnerCap = when {
            input.goalKm <= 5.0 && input.level == "Iniciante" -> 5.0
            input.goalKm <= 10.0 && input.level == "Iniciante" -> 7.0
            else -> min(input.goalKm, 12.0)
        }
        val toleranceCap = max(3.0, input.longestRecentKm)
        val volumeCap = weekly * if (input.level == "Iniciante") 0.40 else 0.45
        return roundHalf(min(beginnerCap, min(toleranceCap, volumeCap)))
    }

    private fun safety(input: RunnerInput): String {
        if (input.painPresent) return "RED"
        if (input.fatigueScore != null && input.fatigueScore >= 90.0) return "YELLOW"
        return "GREEN"
    }

    private fun recovery(input: RunnerInput): String {
        val score = input.recoveryScore ?: return "UNKNOWN"
        return when {
            score >= 75.0 -> "GOOD"
            score >= 50.0 -> "MODERATE"
            else -> "POOR"
        }
    }

    private fun phase(input: RunnerInput, recovery: String): String {
        if (recovery == "POOR") return "RECOVERY"
        return if (input.goalKm <= 10.0) "BASE" else "DEVELOPMENT"
    }

    private fun buildFlags(input: RunnerInput): List<String> {
        val flags = mutableListOf<String>()
        if (input.frequency < 2) flags += "LOW_FREQUENCY"
        if (input.fatigueScore != null && input.fatigueScore >= 75.0) flags += "HIGH_FATIGUE"
        return flags
    }

    private fun rationale(input: RunnerInput, necessity: String): String {
        return when (necessity) {
            "AEROBIC_DEVELOPMENT" -> "Para um corredor ${input.level.lowercase()} com objetivo de ${formatKm(input.goalKm)} km, o motor prioriza consistência aeróbia e introduz qualidade de forma controlada."
            "ENDURANCE" -> "O objetivo exige desenvolvimento progressivo de resistência, mantendo a carga compatível com a tolerância recente."
            else -> "A recuperação tem prioridade antes de aumentar a carga."
        }
    }

    private fun durationFor(km: Double, recovery: Boolean): Int {
        val pace = if (recovery) 7.5 else 6.5
        return max(15, (km * pace).toInt())
    }

    private fun roundHalf(value: Double): Double = kotlin.math.round(value * 2.0) / 2.0

    internal fun formatKm(value: Double): String = if (value % 1.0 == 0.0) value.toInt().toString() else String.format(java.util.Locale.US, "%.1f", value)
}
