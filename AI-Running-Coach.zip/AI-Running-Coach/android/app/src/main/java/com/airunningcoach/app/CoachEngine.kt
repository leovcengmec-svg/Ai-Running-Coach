package com.airunningcoach.app

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/** Núcleo de prescrição V21. Mantém carga real e separa pace-alvo de RPE complementar. */
internal data class RunnerInput(
    val goalKm: Double,
    val level: String,
    val frequency: Int,
    /** Média semanal efetivamente corrida nas últimas quatro semanas. */
    val weeklyVolumeKm: Double,
    val longestRecentKm: Double,
    val painPresent: Boolean = false,
    val recoveryScore: Double? = null,
    val fatigueScore: Double? = null,
    val planWeeks: Int = 8,
    val benchmarkDistanceKm: Double? = null,
    val benchmarkTimeSeconds: Int? = null,
    val startDate: LocalDate = LocalDate.now().with(TemporalAdjusters.nextOrSame(DayOfWeek.MONDAY))
)

internal data class MotorState(
    val fitnessConfidence: String,
    val paceConfidence: String,
    val recentVolumeKm: Double,
    val recentLongRunKm: Double,
    val recoveryStatus: String,
    val safetyStatus: String,
    val phase: String,
    val flags: List<String>
)

internal data class MotorDecision(
    val action: String,
    val necessity: String,
    val stimulus: String,
    val rationale: String,
    val confidence: Double,
    val safety: String
)

internal data class WorkoutSegment(
    val name: String,
    val instruction: String,
    val durationMin: Int? = null,
    val distanceKm: Double? = null,
    val intensity: String = "LOW",
    /** RPE é uma referência complementar, nunca o alvo primário de execução. */
    val rpeRange: String = "2-3",
    val repeatCount: Int = 1,
    /** TIME ou DISTANCE, conforme o campo de dose preenchido. */
    val targetMode: String = if (durationMin != null) "TIME" else "DISTANCE",
    /** Limites de pace em segundos por quilômetro; menor valor = mais rápido. */
    val targetPaceMinSecPerKm: Int? = null,
    val targetPaceMaxSecPerKm: Int? = null
) {
    init {
        require(targetMode == "TIME" || targetMode == "DISTANCE") { "O alvo deve ser TIME ou DISTANCE." }
        require(if (targetMode == "TIME") durationMin != null && durationMin > 0 else distanceKm != null && distanceKm >= 0.0) {
            "Cada etapa precisa ter uma dose compatível com o tipo de alvo."
        }
        require((targetPaceMinSecPerKm == null) == (targetPaceMaxSecPerKm == null)) { "A faixa de pace precisa ter os dois limites." }
        if (targetPaceMinSecPerKm != null && targetPaceMaxSecPerKm != null) {
            require(targetPaceMinSecPerKm > 0 && targetPaceMaxSecPerKm >= targetPaceMinSecPerKm) { "Faixa de pace inválida." }
        }
        require(repeatCount >= 1) { "A repetição deve ser pelo menos 1." }
    }
}

internal data class PrescribedWorkout(
    val day: String,
    val date: String,
    val scheduledDateIso: String,
    val title: String,
    val type: String,
    val objective: String,
    val stimulus: String,
    val sessionId: String,
    val distanceKm: Double,
    val durationMin: Int,
    val intensity: String,
    val paceMode: String,
    val rpeRange: String,
    val detail: String,
    val rationale: String,
    val week: Int = 1,
    val phase: String = "BASE",
    val segments: List<WorkoutSegment> = emptyList()
)

internal data class WeeklyPlanSummary(
    val week: Int,
    val phase: String,
    val totalKm: Double,
    val workoutCount: Int,
    val isRecoveryWeek: Boolean
)

internal data class MotorPlan(
    val state: MotorState,
    val decision: MotorDecision,
    val workouts: List<PrescribedWorkout>,
    val weeklyKm: Double,
    val explanation: String,
    val weeklySummaries: List<WeeklyPlanSummary>
)

internal object RunningCoachEngine {
    fun generate(input: RunnerInput): MotorPlan {
        require(input.frequency in 2..6) { "A frequência deve estar entre 2 e 6 dias por semana." }
        require(input.goalKm in 1.0..100.0) { "O objetivo precisa estar entre 1 e 100 km." }
        require(input.weeklyVolumeKm in 0.0..150.0) { "Informe um volume semanal entre 0 e 150 km." }
        require(input.longestRecentKm in 0.0..60.0) { "O maior treino recente precisa estar entre 0 e 60 km." }

        val paceZones = PaceCalculator.calculate(input.benchmarkDistanceKm, input.benchmarkTimeSeconds)
        val recovery = recoveryStatus(input.recoveryScore)
        val safety = safetyStatus(input)
        val flags = buildFlags(input, recovery, safety)
        val state = MotorState(
            fitnessConfidence = when {
                input.weeklyVolumeKm < 8.0 || input.longestRecentKm < 5.0 -> "LOW"
                else -> "PARTIAL"
            },
            paceConfidence = if (paceZones != null) "ESTIMATED_FROM_RECENT_RESULT" else "NO_REFERENCE_RESULT",
            recentVolumeKm = input.weeklyVolumeKm,
            recentLongRunKm = input.longestRecentKm,
            recoveryStatus = recovery,
            safetyStatus = safety,
            phase = if (recovery == "POOR" || safety == "YELLOW") "RECOVERY" else "BASE_AND_BUILD",
            flags = flags
        )

        if (safety == "RED") {
            val decision = MotorDecision(
                action = "BLOCK", necessity = "SAFETY_REVIEW", stimulus = "NONE",
                rationale = "Há relato de dor. O motor não gera sessões de corrida; procure orientação adequada antes de retomar a carga.",
                confidence = 0.99, safety = "RED"
            )
            return MotorPlan(state, decision, emptyList(), 0.0, decision.rationale, emptyList())
        }

        val weeks = input.planWeeks.coerceIn(4, 16)
        // Sem volume recente, o ciclo começa como reintrodução muito leve, não como intermediário/avançado.
        val baselineKm = if (input.weeklyVolumeKm == 0.0) 3.0 else input.weeklyVolumeKm
        val workouts = mutableListOf<PrescribedWorkout>()
        val summaries = mutableListOf<WeeklyPlanSummary>()
        val initialReadinessFactor = when {
            recovery == "POOR" -> 0.72
            safety == "YELLOW" -> 0.82
            else -> 1.0
        }

        for (week in 1..weeks) {
            val cycleWeek = (week - 1) % 4
            val isRecoveryWeek = cycleWeek == 3
            val blockIndex = (week - 1) / 4
            val blockFactor = (1.0 + blockIndex * 0.04).coerceAtMost(1.16)
            val progressionFactor = when (cycleWeek) {
                0 -> 1.00
                1 -> 1.04
                2 -> 1.08
                else -> 0.82
            }
            val readinessFactor = when {
                recovery == "POOR" -> 0.72
                safety == "YELLOW" -> 0.82
                else -> 1.0
            }
            val candidateWeekKm = max(1.5, baselineKm * blockFactor * progressionFactor * readinessFactor)
            val previousDeliveredKm = summaries.lastOrNull()?.totalKm
            val progressionCeiling = when {
                previousDeliveredKm == null -> candidateWeekKm
                isRecoveryWeek -> previousDeliveredKm * 0.82
                cycleWeek == 0 -> previousDeliveredKm * 1.10
                else -> previousDeliveredKm * 1.05
            }
            val targetWeekKm = min(candidateWeekKm, progressionCeiling).coerceAtLeast(1.5)
            val weekPhase = when {
                recovery == "POOR" || safety == "YELLOW" || isRecoveryWeek -> "RECOVERY"
                cycleWeek == 0 -> "ADAPTATION"
                cycleWeek == 1 -> "CONSOLIDATION"
                else -> "PROGRESSION"
            }
            val weekSessions = buildWeek(
                input = input,
                targetWeekKm = targetWeekKm,
                week = week,
                phase = weekPhase,
                suppressQuality = isRecoveryWeek || recovery == "POOR" || safety == "YELLOW"
            )
            workouts += weekSessions
            summaries += WeeklyPlanSummary(
                week = week,
                phase = weekPhase,
                totalKm = round1(weekSessions.sumOf { it.distanceKm }),
                workoutCount = weekSessions.size,
                isRecoveryWeek = isRecoveryWeek || recovery == "POOR" || safety == "YELLOW"
            )
        }

        val firstWeekKm = summaries.firstOrNull()?.totalKm ?: 0.0
        val volumeWasCapped = firstWeekKm + 0.1 < baselineKm * initialReadinessFactor
        val finalState = if (volumeWasCapped) state.copy(flags = state.flags + "WEEKLY_VOLUME_CAPPED_BY_RECENT_TOLERANCE") else state
        val qualityCount = workouts.count { it.type == "Qualidade" }
        val necessity = when {
            recovery == "POOR" -> "RECOVERY_FIRST"
            input.goalKm <= 10.0 -> "AEROBIC_DEVELOPMENT"
            else -> "ENDURANCE_DEVELOPMENT"
        }
        val stimulus = when {
            recovery == "POOR" || safety == "YELLOW" -> "LOW_INTENSITY_AEROBIC"
            qualityCount > 0 -> "AEROBIC_BASE_AND_CONTROLLED_QUALITY"
            else -> "AEROBIC_BASE"
        }
        val rationale = when {
            recovery == "POOR" -> "A recuperação registrada está baixa. O volume foi reduzido e os estímulos de qualidade foram suspensos."
            safety == "YELLOW" -> "Os sinais recentes de fadiga pedem redução temporária da carga e suspensão de estímulos intensos."
            volumeWasCapped -> "A média semanal informada é maior do que a dose que o histórico do maior treino recente permite distribuir com segurança na frequência escolhida. O plano fica abaixo da média informada até haver tolerância documentada."
            input.weeklyVolumeKm == 0.0 -> "Como não há corrida registrada nas últimas quatro semanas, o plano começa com reintrodução leve, independentemente do nível de experiência declarado."
            input.level == "Iniciante" -> "O plano prioriza consistência aeróbia e progressão gradual, sem estímulos intensos nesta etapa."
            else -> "A primeira semana parte do volume semanal real informado. A progressão é gradual; a qualidade só aparece quando o volume e o histórico recente permitem."
        }
        val decision = MotorDecision(
            action = if (recovery == "POOR" || safety == "YELLOW") "REDUCE_LOAD" else "PRESCRIBE",
            necessity = necessity,
            stimulus = stimulus,
            rationale = rationale,
            confidence = when {
                input.weeklyVolumeKm == 0.0 -> 0.25
                input.weeklyVolumeKm >= 8.0 && input.longestRecentKm >= 5.0 -> 0.68
                else -> 0.42
            },
            safety = safety
        )
        val explanation = buildString {
            append("O volume da semana 1 usa a média semanal efetivamente informada para as últimas quatro semanas, sem reduzir uma faixa inteira ao seu limite inferior. ")
            append("A experiência declarada define a elegibilidade dos estímulos, mas não substitui o histórico de carga. ")
            append("O longão é limitado pelo maior treino recente, pela parcela da semana e pela distância-alvo. ")
            if (paceZones != null) {
                append("As faixas de pace são estimativas iniciais derivadas do resultado recente de ${input.benchmarkDistanceKm} km; o RPE permanece como referência complementar para ajustar o esforço em calor, subidas ou fadiga.")
            } else {
                append("Sem resultado recente de referência, o motor não inventa pace: as sessões usam alvos de distância/tempo e RPE apenas como orientação temporária. Informe um resultado recente de 3, 5 ou 10 km para calibrar o pace.")
            }
        }
        return MotorPlan(finalState, decision, workouts, firstWeekKm, explanation, summaries)
    }

    private fun buildWeek(
        input: RunnerInput,
        targetWeekKm: Double,
        week: Int,
        phase: String,
        suppressQuality: Boolean
    ): List<PrescribedWorkout> {
        val days = trainingDays(input.frequency)
        val dayCount = days.size
        val goalLongCap = when {
            input.goalKm <= 5.0 -> 8.0
            input.goalKm <= 10.0 -> 14.0
            input.goalKm <= 21.1 -> 22.0
            else -> 30.0
        }
        val growthAllowance = (week - 1) * 0.5
        val historyCap = if (input.longestRecentKm <= 0.0) 1.0 else input.longestRecentKm + growthAllowance
        val longShare = when (dayCount) {
            2 -> 0.45
            3 -> if (suppressQuality) 0.38 else 0.40
            4 -> 0.32
            5 -> 0.30
            else -> 0.28
        }
        val minimumLong = min(0.5, targetWeekKm)
        val longKm = floorHalf(min(targetWeekKm * longShare, min(historyCap, goalLongCap))).coerceAtLeast(minimumLong)
        val allowQuality = !suppressQuality && input.level != "Iniciante" &&
            dayCount >= 3 && targetWeekKm >= 16.0 && input.longestRecentKm >= 8.0
        val qualityShare = when (input.level) {
            "Elite", "Avançado", "Intermediário" -> 0.20
            else -> 0.18
        }
        val qualityKm = if (allowQuality) min(historyCap, roundHalf(targetWeekKm * qualityShare)).coerceAtLeast(2.5) else 0.0
        val qualityIndex = when (dayCount) {
            3 -> 1
            4, 5 -> 2
            else -> 3
        }
        val easyIndices = days.indices.filter { it != days.lastIndex && (!allowQuality || it != qualityIndex) }
        val easyTotal = max(0.0, targetWeekKm - longKm - qualityKm)
        val easyDistances = distributeDistance(easyTotal, easyIndices.size, historyCap)
        var easyCursor = 0
        val startMonday = input.startDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))

        return days.mapIndexed { index, day ->
            val date = startMonday.plusWeeks((week - 1).toLong()).plusDays(day.value - 1L)
            when {
                day == DayOfWeek.SUNDAY -> createLongRun(input, date, longKm, week, phase)
                allowQuality && index == qualityIndex -> createQuality(input, date, qualityKm, week, phase)
                else -> {
                    val km = easyDistances.getOrElse(easyCursor++) { 0.5 }
                    createEasy(input, date, km, week, phase, recovery = suppressQuality)
                }
            }
        }
    }

    private fun distributeDistance(totalKm: Double, count: Int, sessionCapKm: Double): List<Double> {
        if (count <= 0) return emptyList()
        var remaining = totalKm
        return (0 until count).map { index ->
            val slotsLeft = count - index
            val desired = floorHalf(remaining / slotsLeft)
            val allocated = min(sessionCapKm, desired).coerceAtLeast(0.5)
            remaining = max(0.0, remaining - allocated)
            round1(allocated)
        }
    }

    private fun createEasy(input: RunnerInput, date: LocalDate, km: Double, week: Int, phase: String, recovery: Boolean): PrescribedWorkout {
        val beginner = input.level == "Iniciante" || input.weeklyVolumeKm == 0.0
        val title = when {
            recovery -> "Rodagem regenerativa"
            beginner -> "Corrida leve / caminhada"
            else -> "Rodagem aeróbia"
        }
        val rpe = if (recovery) "2-3" else "3-4"
        val warmupKm = round1(km * 0.2)
        val mainKm = round1(km * 0.6)
        val cooldownKm = round1((km - warmupKm - mainKm).coerceAtLeast(0.0))
        val zones = PaceCalculator.calculate(input.benchmarkDistanceKm, input.benchmarkTimeSeconds)
        val segments = listOf(
            asTimeTarget(WorkoutSegment("Aquecimento", "Comece com caminhada ativa ou trote muito leve.", distanceKm = warmupKm, intensity = "LOW", rpeRange = "1-2",
                targetPaceMinSecPerKm = zones?.recovery?.fastestSecPerKm, targetPaceMaxSecPerKm = zones?.recovery?.slowestSecPerKm), zones),
            WorkoutSegment("Bloco aeróbio", "Converse em frases completas; reduza o ritmo se a respiração ficar difícil.", distanceKm = mainKm, intensity = "LOW", rpeRange = rpe,
                targetPaceMinSecPerKm = zones?.easy?.fastestSecPerKm, targetPaceMaxSecPerKm = zones?.easy?.slowestSecPerKm),
            asTimeTarget(WorkoutSegment("Desaquecimento", "Reduza gradualmente o esforço até encerrar a sessão.", distanceKm = cooldownKm, intensity = "LOW", rpeRange = "1-2",
                targetPaceMinSecPerKm = zones?.recovery?.fastestSecPerKm, targetPaceMaxSecPerKm = zones?.recovery?.slowestSecPerKm), zones)
        )
        return workout(date, title, if (recovery) "Recuperação" else "Aeróbio", "Construir consistência aeróbia", if (recovery) "RECOVERY" else "AEROBIC_BASE", km, rpe, week, phase, segments,
            if (recovery) "Carga baixa para facilitar a recuperação." else if (zones != null) "Pace aeróbio individual estimado a partir do resultado de referência; ajuste para manter conversa confortável." else "Sem resultado recente para calibrar o pace. Use a distância prescrita e mantenha esforço confortável até registrar um teste de referência.", "LOW")
    }

    private fun createQuality(input: RunnerInput, date: LocalDate, km: Double, week: Int, phase: String): PrescribedWorkout {
        val repetitions = if (input.level == "Elite" || input.level == "Avançado") 4 else 3
        val warmupKm = round1(km * 0.20)
        val workTotalKm = round1(km * 0.50)
        val workRepKm = round1(workTotalKm / repetitions)
        val recoveryTotalKm = round1(km * 0.10)
        val recoveryRepKm = round1(recoveryTotalKm / (repetitions - 1))
        val usedKm = warmupKm + workRepKm * repetitions + recoveryRepKm * (repetitions - 1)
        val cooldownKm = round1((km - usedKm).coerceAtLeast(0.0))
        val zones = PaceCalculator.calculate(input.benchmarkDistanceKm, input.benchmarkTimeSeconds)
        val segments = listOf(
            asTimeTarget(WorkoutSegment("Aquecimento", "Comece em ritmo muito confortável e faça mobilidade dinâmica antes das repetições.", distanceKm = warmupKm, intensity = "LOW", rpeRange = "2-3",
                targetPaceMinSecPerKm = zones?.recovery?.fastestSecPerKm, targetPaceMaxSecPerKm = zones?.recovery?.slowestSecPerKm), zones),
            WorkoutSegment("Estímulo principal", "Esforço controlado; termine cada repetição sentindo que conseguiria mais uma. Não sprintar.", distanceKm = workRepKm, intensity = "MODERATE", rpeRange = "6-7", repeatCount = repetitions,
                targetPaceMinSecPerKm = zones?.threshold?.fastestSecPerKm, targetPaceMaxSecPerKm = zones?.threshold?.slowestSecPerKm),
            asTimeTarget(WorkoutSegment("Recuperação entre repetições", "Trote ou caminhada leve até recuperar a respiração.", distanceKm = recoveryRepKm, intensity = "LOW", rpeRange = "2-3", repeatCount = repetitions - 1,
                targetPaceMinSecPerKm = zones?.recovery?.fastestSecPerKm, targetPaceMaxSecPerKm = zones?.recovery?.slowestSecPerKm), zones),
            asTimeTarget(WorkoutSegment("Desaquecimento", "Trote muito leve e reduza gradualmente até encerrar a sessão.", distanceKm = cooldownKm, intensity = "LOW", rpeRange = "2-3",
                targetPaceMinSecPerKm = zones?.easy?.fastestSecPerKm, targetPaceMaxSecPerKm = zones?.easy?.slowestSecPerKm), zones)
        )
        return workout(date, if (week % 2 == 0) "Tempo controlado" else "Intervalos de limiar controlados", "Qualidade", "Desenvolver tolerância a esforço moderado de forma controlada", "THRESHOLD_CONTROLLED", km, "6-7", week, phase, segments,
            if (zones != null) "A sessão só é incluída quando o volume semanal e o maior treino recente sustentam um estímulo de qualidade. O bloco principal usa uma faixa de pace estimada do resultado recente; RPE é apenas controle complementar." else "A sessão só é incluída quando o histórico sustenta qualidade. Sem resultado de referência, não há pace individual: use o alvo de distância e RPE como limite temporário.", "MODERATE")
    }

    private fun createLongRun(input: RunnerInput, date: LocalDate, km: Double, week: Int, phase: String): PrescribedWorkout {
        val recoveryWeek = phase == "RECOVERY"
        val rpe = if (recoveryWeek) "2-3" else "3-4"
        val warmupKm = round1(km * 0.10)
        val mainKm = round1(km * 0.80)
        val cooldownKm = round1((km - warmupKm - mainKm).coerceAtLeast(0.0))
        val zones = PaceCalculator.calculate(input.benchmarkDistanceKm, input.benchmarkTimeSeconds)
        val segments = listOf(
            asTimeTarget(WorkoutSegment("Aquecimento", "Comece muito leve e aumente gradualmente até o esforço confortável.", distanceKm = warmupKm, intensity = "LOW", rpeRange = "2-3",
                targetPaceMinSecPerKm = zones?.recovery?.fastestSecPerKm, targetPaceMaxSecPerKm = zones?.recovery?.slowestSecPerKm), zones),
            WorkoutSegment("Longão aeróbio", "Mantenha esforço conversável e constante. Não transforme o longão em prova.", distanceKm = mainKm, intensity = "LOW", rpeRange = rpe,
                targetPaceMinSecPerKm = zones?.longRun?.fastestSecPerKm, targetPaceMaxSecPerKm = zones?.longRun?.slowestSecPerKm),
            asTimeTarget(WorkoutSegment("Desaquecimento", "Reduza gradualmente até encerrar a sessão.", distanceKm = cooldownKm, intensity = "LOW", rpeRange = "1-2",
                targetPaceMinSecPerKm = zones?.recovery?.fastestSecPerKm, targetPaceMaxSecPerKm = zones?.recovery?.slowestSecPerKm), zones)
        )
        return workout(date, if (recoveryWeek) "Longão regenerativo" else "Longão aeróbio", "Longo", "Desenvolver resistência com carga compatível com a tolerância recente", "AEROBIC_ENDURANCE", km, rpe, week, phase, segments,
            if (zones != null) "Distância limitada pelo maior treino recente, pela parcela da semana e pela distância-alvo. Pace longo derivado do resultado recente." else "Distância limitada pelo maior treino recente, pela parcela da semana e pela distância-alvo. Informe um resultado recente para calibrar o pace.", "LOW")
    }

    /**
     * Com pace calibrado, aquecimento, recuperação e desaquecimento são mais naturais por tempo.
     * Sem referência recente, mantém esses blocos por distância e não presume uma velocidade.
     * distanceKm em um bloco TIME é somente a contribuição estimada para o volume semanal.
     */
    private fun asTimeTarget(segment: WorkoutSegment, zones: TrainingPaceZones?): WorkoutSegment {
        if (zones == null) return segment
        val estimatedDistance = segment.distanceKm ?: return segment
        val midpointPace = if (segment.targetPaceMinSecPerKm != null && segment.targetPaceMaxSecPerKm != null) {
            (segment.targetPaceMinSecPerKm + segment.targetPaceMaxSecPerKm) / 2.0
        } else {
            return segment
        }
        val minutes = kotlin.math.round(estimatedDistance * midpointPace / 60.0).toInt().coerceAtLeast(1)
        return segment.copy(durationMin = minutes, targetMode = "TIME")
    }

    private fun workout(date: LocalDate, title: String, type: String, objective: String, stimulus: String, distanceKm: Double, rpe: String,
        week: Int, phase: String, segments: List<WorkoutSegment>, rationale: String, intensity: String): PrescribedWorkout {
        val weightedPace = segments.mapNotNull { segment ->
            val minPace = segment.targetPaceMinSecPerKm
            val maxPace = segment.targetPaceMaxSecPerKm
            val distance = segment.distanceKm
            if (minPace != null && maxPace != null && distance != null && distance > 0.0) {
                (minPace + maxPace) / 2.0 to (distance * segment.repeatCount)
            } else null
        }
        val averagePace = if (weightedPace.isNotEmpty()) weightedPace.sumOf { it.first * it.second } / weightedPace.sumOf { it.second } else 420.0
        val duration = max(15, kotlin.math.round(distanceKm * averagePace / 60.0).toInt())
        val dayName = date.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, Locale.forLanguageTag("pt-BR"))
        val dateLabel = "${dayName.replaceFirstChar { it.uppercase(Locale.forLanguageTag("pt-BR")) }}, ${date.format(DateTimeFormatter.ofPattern("dd/MM"))}"
        val detail = formatSegments(segments)
        val id = "W$week-${date.dayOfWeek.name}-${type.uppercase(Locale.US).replace(' ', '-')}"
        return PrescribedWorkout(dayName.replaceFirstChar { it.uppercase(Locale.forLanguageTag("pt-BR")) }, dateLabel, date.toString(), title, type, objective, stimulus,
            id, round1(distanceKm), duration, intensity,
            if (segments.any { it.targetPaceMinSecPerKm != null && it.targetPaceMaxSecPerKm != null }) "PACE_RANGE" else "PACE_NOT_CALIBRATED",
            rpe, detail, rationale, week, phase, segments)
    }

    private fun formatSegments(segments: List<WorkoutSegment>): String = segments.joinToString(" • ") { segment ->
        val dose = when {
            segment.targetMode == "TIME" && segment.repeatCount > 1 && segment.durationMin != null -> "${segment.repeatCount} × ${segment.durationMin} min"
            segment.targetMode == "TIME" && segment.durationMin != null -> "${segment.durationMin} min"
            segment.repeatCount > 1 && segment.distanceKm != null -> "${segment.repeatCount} × ${formatKm(segment.distanceKm)} km"
            segment.distanceKm != null -> "${formatKm(segment.distanceKm)} km"
            segment.durationMin != null -> "${segment.durationMin} min"
            else -> ""
        }
        val pace = if (segment.targetPaceMinSecPerKm != null && segment.targetPaceMaxSecPerKm != null) {
            "pace ${PaceRange(segment.targetPaceMinSecPerKm, segment.targetPaceMaxSecPerKm).label()}"
        } else "pace não calibrado"
        "${segment.name}: $dose ($pace; RPE auxiliar ${segment.rpeRange})"
    }

    private fun trainingDays(frequency: Int): List<DayOfWeek> = when (frequency) {
        2 -> listOf(DayOfWeek.TUESDAY, DayOfWeek.SUNDAY)
        3 -> listOf(DayOfWeek.TUESDAY, DayOfWeek.THURSDAY, DayOfWeek.SUNDAY)
        4 -> listOf(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY, DayOfWeek.SUNDAY)
        5 -> listOf(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.THURSDAY, DayOfWeek.SATURDAY, DayOfWeek.SUNDAY)
        else -> listOf(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY, DayOfWeek.SATURDAY, DayOfWeek.SUNDAY)
    }

    private fun recoveryStatus(score: Double?): String = when {
        score == null -> "UNKNOWN"
        score >= 75.0 -> "GOOD"
        score >= 50.0 -> "MODERATE"
        else -> "POOR"
    }

    private fun safetyStatus(input: RunnerInput): String = when {
        input.painPresent -> "RED"
        input.fatigueScore != null && input.fatigueScore >= 75.0 -> "YELLOW"
        input.recoveryScore != null && input.recoveryScore < 25.0 -> "YELLOW"
        input.recoveryScore == null && input.fatigueScore == null -> "UNASSESSED"
        else -> "GREEN"
    }

    private fun buildFlags(input: RunnerInput, recovery: String, safety: String): List<String> = buildList {
        if (input.frequency < 3) add("LOW_FREQUENCY")
        if (input.weeklyVolumeKm == 0.0) add("NO_RECENT_WEEKLY_VOLUME")
        if (input.longestRecentKm < 5.0) add("LIMITED_LONG_RUN_HISTORY")
        if (input.fatigueScore != null && input.fatigueScore >= 75.0) add("HIGH_FATIGUE")
        if (recovery == "POOR") add("LOW_RECOVERY")
        if (safety == "UNASSESSED") add("READINESS_NOT_ASSESSED")
        if (safety == "RED") add("PAIN_REPORTED")
    }

    private fun roundHalf(value: Double): Double = kotlin.math.round(value * 2.0) / 2.0
    private fun floorHalf(value: Double): Double = kotlin.math.floor(value * 2.0) / 2.0
    private fun round1(value: Double): Double = kotlin.math.round(value * 10.0) / 10.0
    internal fun formatKm(value: Double): String = if (value % 1.0 == 0.0) value.toInt().toString() else String.format(Locale.US, "%.1f", value)
    internal fun nextMonday(from: LocalDate): LocalDate = from.with(TemporalAdjusters.nextOrSame(DayOfWeek.MONDAY))
}
