package com.airunningcoach.app

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters

/** Regras de disponibilidade habitual e reagendamento pontual de sessões. */
internal object TrainingScheduleEngine {
    fun defaultDays(frequency: Int): List<DayOfWeek> = when (frequency.coerceIn(2, 6)) {
        2 -> listOf(DayOfWeek.TUESDAY, DayOfWeek.SUNDAY)
        3 -> listOf(DayOfWeek.TUESDAY, DayOfWeek.THURSDAY, DayOfWeek.SUNDAY)
        4 -> listOf(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY, DayOfWeek.SUNDAY)
        5 -> listOf(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.THURSDAY, DayOfWeek.SATURDAY, DayOfWeek.SUNDAY)
        else -> listOf(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY, DayOfWeek.SATURDAY, DayOfWeek.SUNDAY)
    }

    fun normalizeDays(days: List<DayOfWeek>, fallbackFrequency: Int): List<DayOfWeek> {
        val distinct = days.distinct().sortedBy { it.value }
        return if (distinct.size in 2..6) distinct else defaultDays(fallbackFrequency)
    }

    /**
     * The days selected in the profile are availability, not a requirement to run on
     * every selected day. For a novice/re-entry plan, prescribe at most three runs and
     * distribute them as evenly as the athlete's availability allows.
     */
    fun prescribedRunningDays(
        availableDays: List<DayOfWeek>,
        fallbackFrequency: Int,
        novice: Boolean,
        preferredLongRunDay: DayOfWeek? = null
    ): List<DayOfWeek> {
        val normalized = normalizeDays(availableDays, fallbackFrequency)
        if (!novice || normalized.size <= 3) return normalized

        val preferred = preferredLongRunDay?.takeIf { it in normalized }
        val combinations = mutableListOf<List<DayOfWeek>>()
        for (a in 0 until normalized.size - 2) {
            for (b in a + 1 until normalized.size - 1) {
                for (c in b + 1 until normalized.size) {
                    combinations += listOf(normalized[a], normalized[b], normalized[c])
                }
            }
        }

        return combinations.maxWithOrNull(
            compareBy<List<DayOfWeek>> { days -> if (preferred == null || preferred in days) 1 else 0 }
                .thenBy { days -> minimumCircularGap(days) }
                .thenBy { days -> days.sumOf { day -> days.filterNot { it == day }.sumOf { other -> circularGapDays(day, other) } } }
        ) ?: normalized.take(3)
    }

    /** Number of calendar-day steps between two weekdays, wrapping across Sunday. */
    fun circularGapDays(first: DayOfWeek, second: DayOfWeek): Int {
        val difference = kotlin.math.abs(first.value - second.value)
        return minOf(difference, 7 - difference)
    }

    /** A key session is not scheduled unless there is at least one full calendar day between it and the long run. */
    fun qualityDayWithRecoveryGap(days: List<DayOfWeek>, longRunDay: DayOfWeek): DayOfWeek? =
        days.asSequence()
            .filter { it != longRunDay }
            .filter { circularGapDays(it, longRunDay) >= 2 }
            .maxByOrNull { circularGapDays(it, longRunDay) }

    private fun minimumCircularGap(days: List<DayOfWeek>): Int {
        if (days.size < 2) return 7
        return days.indices.minOf { index ->
            circularGapDays(days[index], days[(index + 1) % days.size])
        }
    }

    fun validateAvailability(days: List<DayOfWeek>, longRunDay: DayOfWeek?): String? {
        val normalized = days.distinct()
        if (normalized.size !in 2..6) return "Selecione entre 2 e 6 dias habituais de corrida."
        if (longRunDay != null && longRunDay !in normalized) return "O dia preferido do longão precisa estar entre os dias disponíveis."
        return null
    }

    /** Mantém a preferência válida; em disponibilidade vazia, limpa-a sem lançar exceção. */
    fun resolvePreferredLongRunDay(current: DayOfWeek?, availableDays: List<DayOfWeek>): DayOfWeek? =
        current?.takeIf { it in availableDays } ?: availableDays.maxByOrNull { it.value }

    data class SessionSlot(
        val sessionId: String,
        val date: LocalDate,
        val type: String,
        val done: Boolean = false
    )

    data class MoveResult(val allowed: Boolean, val reason: String = "")

    /** Reagenda somente dentro da mesma semana; não altera dose, zona ou identidade da sessão. */
    fun validateMove(
        source: SessionSlot,
        targetDate: LocalDate,
        sessions: List<SessionSlot>,
        raceDates: Set<LocalDate>,
        today: LocalDate = LocalDate.now()
    ): MoveResult {
        if (source.done) return MoveResult(false, "Treinos concluídos não podem ser reagendados.")
        if (targetDate.isBefore(today)) return MoveResult(false, "Escolha uma data futura ou hoje.")
        val sourceMonday = source.date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val targetMonday = targetDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        if (sourceMonday != targetMonday) return MoveResult(false, "O reagendamento deve permanecer na mesma semana, de segunda a domingo.")
        if (targetDate == source.date) return MoveResult(false, "Esse já é o dia atual da sessão.")
        if (targetDate in raceDates) return MoveResult(false, "Já existe uma competição nessa data.")
        if (sessions.any { it.sessionId != source.sessionId && it.date == targetDate }) {
            return MoveResult(false, "Já existe outro treino nessa data.")
        }
        val sourceIsHard = source.type in setOf("Qualidade", "Longo")
        if (sourceIsHard) {
            val tooClose = sessions.any { other ->
                other.sessionId != source.sessionId && other.date != source.date &&
                    other.type in setOf("Qualidade", "Longo") && kotlin.math.abs(java.time.temporal.ChronoUnit.DAYS.between(targetDate, other.date)) < 2
            }
            if (tooClose) return MoveResult(false, "Esse dia deixa menos de um dia completo de recuperação entre sessões exigentes.")
        } else {
            val adjacentHard = sessions.any { other ->
                other.sessionId != source.sessionId && other.type in setOf("Qualidade", "Longo") &&
                    kotlin.math.abs(java.time.temporal.ChronoUnit.DAYS.between(targetDate, other.date)) == 0L
            }
            if (adjacentHard) return MoveResult(false, "Já existe uma sessão exigente nessa data.")
        }
        return MoveResult(true)
    }
}
