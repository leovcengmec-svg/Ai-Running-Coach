package com.airunningcoach.app

import java.util.Locale
import kotlin.math.roundToInt

/** Internal arithmetic is converted before it reaches any screen or exported field. */
internal data class PaceRange(
    val fastestPaceValue: Int,
    val slowestPaceValue: Int
) {
    init {
        require(fastestPaceValue > 0)
        require(slowestPaceValue >= fastestPaceValue)
    }

    fun label(): String = "${format(fastestPaceValue)}–${format(slowestPaceValue)} min/km"

    companion object {
        fun format(paceValue: Int): String {
            val safe = paceValue.coerceAtLeast(0)
            return String.format(Locale.US, "%d:%02d", safe / 60, safe % 60)
        }

        /** Interprets a displayed pace in mm:ss min/km. */
        fun parsePace(text: String): Int? {
            val value = text.trim()
            if (!Regex("^\\d{1,2}:[0-5]\\d$").matches(value)) return null
            val parts = value.split(":")
            val minutes = parts[0].toIntOrNull() ?: return null
            val seconds = parts[1].toIntOrNull() ?: return null
            return (minutes * 60 + seconds).takeIf { it in 120..1800 }
        }

        fun formatDuration(totalValue: Int): String {
            val safe = totalValue.coerceAtLeast(0)
            val hours = safe / 3600
            val minutes = (safe % 3600) / 60
            val seconds = safe % 60
            return if (hours > 0) String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
            else String.format(Locale.US, "%d:%02d", safe / 60, seconds)
        }
    }
}

internal data class PaceZone(
    val id: String,
    val name: String,
    val purpose: String,
    val range: PaceRange,
    val intensityBand: String
)

internal data class PaceCalibrationSnapshot(
    val assessmentDateIso: String,
    val distanceKm: Double,
    val averagePaceMmSs: String,
    val estimatedVo2Max: Double,
    val estimatedMasPaceMmSs: String = "",
    val estimatedSvt2PaceMmSs: String = "",
    val modelVersion: String,
    /** Frozen zone labels, each formatted as mm:ss–mm:ss min/km. */
    val zoneRanges: Map<String, String>
)

internal data class TrainingPaceZones(
    val method: String,
    val modelVersion: String,
    val averageTestPaceValue: Int,
    val estimatedVo2Max: Double,
    /** Pace equivalent of the Cooper-estimated maximal aerobic speed. */
    val estimatedMasPaceValue: Int,
    /** Pace equivalent of the Cooper-estimated second ventilatory threshold. */
    val estimatedSvt2PaceValue: Int,
    val z1: PaceZone,
    val z2: PaceZone,
    val z3: PaceZone,
    val z4: PaceZone,
    val z5: PaceZone
) {
    val recovery: PaceRange get() = z1.range
    val easy: PaceRange get() = z2.range
    val longRun: PaceRange get() = z2.range
    val threshold: PaceRange get() = z4.range
    val interval: PaceRange get() = z5.range

    fun zone(id: String): PaceZone? = when (id.uppercase(Locale.ROOT)) {
        "Z1" -> z1
        "Z2" -> z2
        "Z3" -> z3
        "Z4" -> z4
        "Z5" -> z5
        else -> null
    }

    fun all(): List<PaceZone> = listOf(z1, z2, z3, z4, z5)

    val estimatedMasPace: String get() = PaceRange.format(estimatedMasPaceValue)
    val estimatedSvt2Pace: String get() = PaceRange.format(estimatedSvt2PaceValue)
}

/**
 * Cooper-derived pace calibration.
 *
 * MAS and sVT2 estimates use the Cooper-distance regressions reported in the 2022
 * "Augmented Cooper test" study. The five operational training bands use the MAS
 * percentages proposed by Cerezuela-Espejo et al. (2018). These are two distinct
 * research sources combined as a field-estimation model; they are not lab measurements.
 */
internal object PaceCalculator {
    private const val MIN_COOPER_DISTANCE_KM = 1.0
    private const val MAX_COOPER_DISTANCE_KM = 5.0
    const val COOPER_DURATION_LABEL = "12 min"
    const val ZONE_MODEL_VERSION = "AIRC_ZONES_2_MAS_SVT2_2018_2022"
    const val CALIBRATION_METHOD = "COOPER_12_MIN_MAS_SVT2_REGRESSION_2022"

    private data class ZoneBand(
        val id: String,
        val name: String,
        val purpose: String,
        val publishedBand: String
    )

    /**
     * Published rounded bands are 43–56, 57–68, 69–79, 80–93 and 94–105% MAS.
     * Shared midpoint boundaries interpolate their rounded edges so displayed ranges
     * remain contiguous without changing the source bands' intended distribution.
     */
    private val speedFractions = listOf(0.43, 0.565, 0.685, 0.795, 0.935, 1.05)

    private val zoneBands = listOf(
        ZoneBand("Z1", "Regenerativa", "Recuperação muito leve; referência R0, abaixo da região de transição aeróbia.", "R0 • 43–56% da VAM estimada"),
        ZoneBand("Z2", "Aeróbia", "Corrida leve a moderada; referência R1, próxima da primeira transição aeróbia.", "R1 • 57–68% da VAM estimada"),
        ZoneBand("Z3", "Moderada", "Esforço sustentado; referência R2, associada à região de estado estável de lactato.", "R2 • 69–79% da VAM estimada"),
        ZoneBand("Z4", "Limiar", "Esforço alto controlado; referência R3, associada ao segundo limiar ventilatório.", "R3 • 80–93% da VAM estimada"),
        ZoneBand("Z5", "VO₂máx", "Intervalos intensos; referência R3+, próxima da capacidade aeróbia máxima.", "R3+ • 94–105% da VAM estimada")
    )

    /** Distance is entered in km; the Cooper test duration is fixed at 12 minutes. */
    fun calculateCooper(distanceKm: Double?): TrainingPaceZones? {
        if (distanceKm == null || !distanceKm.isFinite() || distanceKm !in MIN_COOPER_DISTANCE_KM..MAX_COOPER_DISTANCE_KM) return null

        val estimatedVo2 = 22.351 * distanceKm - 11.288
        if (!estimatedVo2.isFinite() || estimatedVo2 !in 10.0..110.0) return null

        // Published regressions estimate the aerobic references from Cooper distance.
        // Their results are converted immediately to the product's displayed pace format.
        val masEstimate = 5.0629 * distanceKm + 1.5427
        val svt2Estimate = 4.6486 * distanceKm + 0.7878
        if (!masEstimate.isFinite() || !svt2Estimate.isFinite() || masEstimate <= 0.0 || svt2Estimate <= 0.0) return null

        val averagePace = (720.0 / distanceKm).roundToInt()
        val masPace = paceFromEstimatedSpeed(masEstimate)
        val svt2Pace = paceFromEstimatedSpeed(svt2Estimate)
        val boundaryPaces = speedFractions.map { fraction -> paceFromEstimatedSpeed(masEstimate * fraction) }

        val zones = zoneBands.mapIndexed { index, band ->
            PaceZone(
                id = band.id,
                name = band.name,
                purpose = band.purpose,
                range = PaceRange(
                    fastestPaceValue = boundaryPaces[index + 1],
                    slowestPaceValue = boundaryPaces[index]
                ),
                intensityBand = band.publishedBand
            )
        }

        // Regression-derived sVT2 should sit inside the R3/Z4 operational band.
        // If not, reject the calibration rather than quietly publishing contradictory zones.
        val thresholdZone = zones[3].range
        if (svt2Pace < thresholdZone.fastestPaceValue || svt2Pace > thresholdZone.slowestPaceValue) return null

        return TrainingPaceZones(
            method = "Cooper 12 min • VAM e segundo limiar estimados",
            modelVersion = ZONE_MODEL_VERSION,
            averageTestPaceValue = averagePace,
            estimatedVo2Max = estimatedVo2,
            estimatedMasPaceValue = masPace,
            estimatedSvt2PaceValue = svt2Pace,
            z1 = zones[0], z2 = zones[1], z3 = zones[2], z4 = zones[3], z5 = zones[4]
        )
    }

    fun createCalibrationSnapshot(distanceKm: Double?, assessmentDateIso: String): PaceCalibrationSnapshot? {
        val zones = calculateCooper(distanceKm) ?: return null
        return PaceCalibrationSnapshot(
            assessmentDateIso = assessmentDateIso,
            distanceKm = distanceKm ?: return null,
            averagePaceMmSs = PaceRange.format(zones.averageTestPaceValue),
            estimatedVo2Max = zones.estimatedVo2Max,
            estimatedMasPaceMmSs = zones.estimatedMasPace,
            estimatedSvt2PaceMmSs = zones.estimatedSvt2Pace,
            modelVersion = zones.modelVersion,
            zoneRanges = zones.all().associate { it.id to it.range.label() }
        )
    }

    /** Parse elapsed time entered as mm:ss or hh:mm:ss. */
    fun parseDuration(text: String): Int? {
        val value = text.trim()
        val total = when {
            Regex("^\\d{1,3}:[0-5]\\d$").matches(value) -> {
                val parts = value.split(":")
                (parts[0].toIntOrNull() ?: return null) * 60 + (parts[1].toIntOrNull() ?: return null)
            }
            Regex("^\\d{1,2}:[0-5]\\d:[0-5]\\d$").matches(value) -> {
                val parts = value.split(":")
                (parts[0].toIntOrNull() ?: return null) * 3600 +
                    (parts[1].toIntOrNull() ?: return null) * 60 +
                    (parts[2].toIntOrNull() ?: return null)
            }
            else -> return null
        }
        return total.takeIf { it in 1..86_399 }
    }

    /** Calculates recorded activity pace; result is displayed only as mm:ss min/km. */
    fun paceFromDistanceAndDuration(distanceKm: Double, totalDurationValue: Int): Int? {
        if (!distanceKm.isFinite() || distanceKm <= 0.0 || totalDurationValue <= 0) return null
        return (totalDurationValue / distanceKm).roundToInt().takeIf { it in 120..1800 }
    }

    fun formatPace(paceValue: Int): String = PaceRange.format(paceValue)

    private fun paceFromEstimatedSpeed(estimatedSpeed: Double): Int {
        // Internal conversion only. Screens and integrations expose mm:ss min/km.
        return (3_600.0 / estimatedSpeed).roundToInt().coerceIn(120, 1800)
    }
}
