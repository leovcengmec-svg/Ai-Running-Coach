package com.airunningcoach.app

import java.util.Locale
import kotlin.math.pow
import kotlin.math.roundToInt

/** Faixas iniciais de pace calculadas a partir de uma prova/teste recente conhecido. */
internal data class PaceRange(
    val fastestSecPerKm: Int,
    val slowestSecPerKm: Int
) {
    init {
        require(fastestSecPerKm > 0)
        require(slowestSecPerKm >= fastestSecPerKm)
    }

    fun label(): String = "${format(fastestSecPerKm)}–${format(slowestSecPerKm)} min/km"

    companion object {
        fun format(secondsPerKm: Int): String = String.format(
            Locale.US, "%d:%02d", secondsPerKm / 60, secondsPerKm % 60
        )
    }
}

internal data class TrainingPaceZones(
    val recovery: PaceRange,
    val easy: PaceRange,
    val longRun: PaceRange,
    val threshold: PaceRange,
    val estimatedFiveKmPaceSecPerKm: Int
)

internal object PaceCalculator {
    /**
     * Projeta o resultado informado para equivalente de 5 km pela relação de Riegel.
     * As zonas são faixas conservadoras de partida, não limiares laboratoriais.
     */
    fun calculate(distanceKm: Double?, timeSeconds: Int?): TrainingPaceZones? {
        if (distanceKm == null || timeSeconds == null) return null
        if (distanceKm !in 3.0..10.0 || timeSeconds !in 600..10800) return null
        if (distanceKm != 3.0 && distanceKm != 5.0 && distanceKm != 10.0) return null

        // Rejeita tempos incompatíveis com uma referência de corrida utilizável;
        // não comprime resultados extremos para um pace artificial.
        val observedPace = timeSeconds / distanceKm
        if (observedPace !in 180.0..1200.0) return null

        val equivalentFiveKmSeconds = timeSeconds * (5.0 / distanceKm).pow(1.06)
        val fiveKpace = (equivalentFiveKmSeconds / 5.0).roundToInt()
        if (fiveKpace !in 180..1200) return null

        fun range(fastOffset: Int, slowOffset: Int): PaceRange {
            val fast = (fiveKpace + fastOffset).coerceAtLeast(180)
            val slow = (fiveKpace + slowOffset).coerceAtLeast(fast)
            return PaceRange(fast, slow)
        }

        return TrainingPaceZones(
            recovery = range(90, 135),
            easy = range(60, 105),
            longRun = range(65, 115),
            threshold = range(15, 30),
            estimatedFiveKmPaceSecPerKm = fiveKpace
        )
    }

    fun parseMmSs(text: String): Int? {
        val match = Regex("^(\\d{1,3}):([0-5]\\d)$").matchEntire(text.trim()) ?: return null
        val minutes = match.groupValues[1].toIntOrNull() ?: return null
        val seconds = match.groupValues[2].toIntOrNull() ?: return null
        return (minutes * 60 + seconds).takeIf { it in 600..10800 }
    }
}
