package com.airunningcoach.app

import java.util.Locale
import kotlin.math.roundToInt

/** Internal arithmetic is converted before it reaches any screen or exported field. */
internal data class PaceRange(
    val fastestPaceValue: Int,
    val slowestPaceValue: Int
) {
    init {
        require(fastestPaceValue > 0)
        require(slowestPaceValue >= fastestPaceValue)
    }

    fun label(): String = "${format(fastestPaceValue)}–${format(slowestPaceValue)} min/km"

    companion object {
        fun format(paceValue: Int): String {
            val safe = paceValue.coerceAtLeast(0)
            return String.format(Locale.US, "%d:%02d", safe / 60, safe % 60)
        }

        /** Interprets a displayed pace in mm:ss min/km. */
        fun parsePace(text: String): Int? {
            val value = text.trim()
            if (!Regex("^\\d{1,2}:[0-5]\\d$").matches(value)) return null
            val parts = value.split(":")
            val minutes = parts[0].toIntOrNull() ?: return null
            val seconds = parts[1].toIntOrNull() ?: return null
            return (minutes * 60 + seconds).takeIf { it in 120..1800 }
        }

        fun formatDuration(totalValue: Int): String {
            val safe = totalValue.coerceAtLeast(0)
            val hours = safe / 3600
            val minutes = (safe % 3600) / 60
            val seconds = safe % 60
            return if (hours > 0) String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
            else String.format(Locale.US, "%d:%02d", safe / 60, seconds)
        }
    }
}

internal data class PaceZone(
    val id: String,
    val name: String,
    val purpose: String,
    val range: PaceRange,
    val intensityBand: String
)

internal data class PaceCalibrationSnapshot(
    val assessmentDateIso: String,
    val distanceKm: Double,
    val averagePaceMmSs: String,
    val estimatedVo2Max: Double,
    val estimatedMasPaceMmSs: String = "",
    val estimatedSvt2PaceMmSs: String = "",
    val modelVersion: String,
    /** Frozen zone labels, each formatted as mm:ss–mm:ss min/km. */
    val zoneRanges: Map<String, String>,
    val z2CalibrationStatus: String = "COOPER_INITIAL",
    val talkTestEvidenceCount: Int = 0,
    val talkTestReferencePaceMmSs: String = ""
)

internal data class TrainingPaceZones(
    val method: String,
    val modelVersion: String,
    val averageTestPaceValue: Int,
    val estimatedVo2Max: Double,
    /** Supporting estimate only; not used as the sole anchor for the five zones. */
    val estimatedMasPaceValue: Int,
    /** Supporting estimate only; it is not assumed to be a measured threshold. */
    val estimatedSvt2PaceValue: Int,
    val z1: PaceZone,
    val z2: PaceZone,
    val z3: PaceZone,
    val z4: PaceZone,
    val z5: PaceZone,
    val z2CalibrationStatus: String = "COOPER_INITIAL",
    val talkTestEvidenceCount: Int = 0,
    val talkTestReferencePaceValue: Int? = null
) {
    val recovery: PaceRange get() = z1.range
    val easy: PaceRange get() = z2.range
    val longRun: PaceRange get() = z2.range
    val threshold: PaceRange get() = z4.range
    val interval: PaceRange get() = z5.range

    fun zone(id: String): PaceZone? = when (id.uppercase(Locale.ROOT)) {
        "Z1" -> z1
        "Z2" -> z2
        "Z3" -> z3
        "Z4" -> z4
        "Z5" -> z5
        else -> null
    }

    fun all(): List<PaceZone> = listOf(z1, z2, z3, z4, z5)

    val estimatedMasPace: String get() = PaceRange.format(estimatedMasPaceValue)
    val estimatedSvt2Pace: String get() = PaceRange.format(estimatedSvt2PaceValue)
    val talkTestReferencePace: String get() = talkTestReferencePaceValue?.let(PaceRange::format).orEmpty()
}

/**
 * Cooper-derived operational zones, revision V37.
 *
 * Z1–Z4 start from practical Cooper average-speed bands; Z2 can be refined using
 * at least two consistent talk-test observations from easy/long sessions. Z5 uses
 * a plausible Cooper-derived MAS estimate as an auxiliary fast boundary, falling
 * back to the conservative Cooper band when the estimate is outside the expected
 * ratio. None of these field estimates is a laboratory measurement or confirms
 * VO2max/threshold physiology for an individual athlete.
 */
internal object PaceCalculator {
    private const val MIN_COOPER_DISTANCE_KM = 1.0
    private const val MAX_COOPER_DISTANCE_KM = 5.0
    const val COOPER_DURATION_LABEL = "12 min"
    const val ZONE_MODEL_VERSION = "AIRC_ZONES_4_COOPER_TALK_MAS_REFERENCE_2026"
    const val CALIBRATION_METHOD = "COOPER_OPERATIONAL_BANDS_TALK_TEST_AND_ESTIMATED_MAS_REFERENCE"

    private data class ZoneBand(
        val id: String,
        val name: String,
        val purpose: String,
        val percentageLabel: String
    )

    private val zoneBands = listOf(
        ZoneBand("Z1", "Regenerativa", "Corrida muito leve e recuperação. Reduza ainda mais se a respiração não estiver confortável.", "60–70% da velocidade média do Cooper"),
        ZoneBand("Z2", "Aeróbia confortável", "Rodagem e longão em esforço conversável. A faixa inicial pode ser refinada com registros consistentes do teste da fala.", "70–80% da velocidade média do Cooper"),
        ZoneBand("Z3", "Moderada", "Ritmo sustentado acima da rodagem fácil, sem transformar toda sessão em limiar.", "80–90% da velocidade média do Cooper"),
        ZoneBand("Z4", "Moderada/limiar estimado", "Esforço sustentado controlado. É uma faixa operacional estimada, não uma medição de LT2.", "90–100% da velocidade média do Cooper"),
        ZoneBand("Z5", "Alta intensidade estimada", "Intervalos curtos e controlados. A faixa superior pode usar a VAM estimada como referência auxiliar; não representa VO₂máx medido.", "Faixa operacional com referência auxiliar de VAM estimada")
    )

    /**
     * Distance is entered in km; the Cooper duration is fixed at 12 minutes.
     * talkTestComfortPaces are the paces of steady segments in which full sentences
     * remained comfortable, recorded in at least two easy/long sessions.
     */
    fun calculateCooper(
        distanceKm: Double?,
        talkTestComfortPaces: List<Int> = emptyList()
    ): TrainingPaceZones? {
        if (distanceKm == null || !distanceKm.isFinite() || distanceKm !in MIN_COOPER_DISTANCE_KM..MAX_COOPER_DISTANCE_KM) return null

        val estimatedVo2 = 22.351 * distanceKm - 11.288
        if (!estimatedVo2.isFinite() || estimatedVo2 !in 10.0..110.0) return null

        // Published Cooper regressions are retained as context and secondary estimates.
        val averageCooperSpeed = distanceKm * 5.0
        val masEstimate = 5.0629 * distanceKm + 1.5427
        val svt2Estimate = 4.6486 * distanceKm + 0.7878
        if (!masEstimate.isFinite() || !svt2Estimate.isFinite() || masEstimate <= 0.0 || svt2Estimate <= 0.0) return null

        val averagePace = (720.0 / distanceKm).roundToInt()
        val masPace = paceFromEstimatedSpeed(masEstimate)
        val svt2Pace = paceFromEstimatedSpeed(svt2Estimate)

        // The reference bands match the supplied spreadsheet's practical structure.
        // They are based on Cooper average speed, not on a linear %VO2max conversion.
        val p60 = paceFromEstimatedSpeed(averageCooperSpeed * 0.60)
        val p70 = paceFromEstimatedSpeed(averageCooperSpeed * 0.70)
        val p80 = paceFromEstimatedSpeed(averageCooperSpeed * 0.80)
        val p90 = paceFromEstimatedSpeed(averageCooperSpeed * 0.90)
        val p100 = paceFromEstimatedSpeed(averageCooperSpeed)
        val p110 = paceFromEstimatedSpeed(averageCooperSpeed * 1.10)

        val validTalkPaces = talkTestComfortPaces.filter { it in 120..1800 }.takeLast(3)
        val talkEvidence = resolveTalkTestBoundary(validTalkPaces, p60, p90)
        val z2FastBoundary = talkEvidence.first ?: p80
        val z1Z2Boundary = if (talkEvidence.first != null) {
            maxOf(p70, z2FastBoundary + 30).coerceAtMost(p60 - 15)
        } else p70

        // The Cooper average speed is a conservative lower boundary for high-intensity
        // work. Where the secondary MAS regression is within a plausible range, use its
        // estimated pace as the upper (faster) bound. This avoids labelling an interval
        // zone whose entire range sits below the app's own MAS estimate. The regression
        // remains a field estimate, not an individual laboratory measurement.
        val masRatio = masEstimate / averageCooperSpeed
        val highIntensityFastBoundary = if (masRatio in 1.03..1.22 && masPace < p100) masPace else p110

        val zones = zoneBands.mapIndexed { index, band ->
            val range = when (index) {
                0 -> PaceRange(z1Z2Boundary, p60)
                1 -> PaceRange(z2FastBoundary, z1Z2Boundary)
                2 -> PaceRange(p90, z2FastBoundary)
                3 -> PaceRange(p100, p90)
                else -> PaceRange(highIntensityFastBoundary, p100)
            }
            val effectiveBandLabel = when {
                // Z5 uses the same explicit provenance whether or not Z2 has talk-test evidence.
                band.id == "Z5" && highIntensityFastBoundary == masPace ->
                    "Z5 • limite rápido usa VAM estimada como referência auxiliar; não é VO₂máx medido"
                band.id == "Z5" ->
                    "Z5 • limite rápido usa a banda conservadora do Cooper; não é VO₂máx medido"
                talkEvidence.first != null -> when (band.id) {
                    "Z1" -> "Regenerativa • margem individual abaixo da fronteira aeróbia"
                    "Z2" -> "Faixa aeróbia individual refinada pelo teste da fala"
                    "Z3" -> "Moderada • acima da fronteira aeróbia individual"
                    "Z4" -> "Faixa estimada a partir do Cooper; não equivale a LT2 medido"
                    else -> band.percentageLabel
                }
                else -> band.percentageLabel
            }
            PaceZone(
                id = band.id,
                name = band.name,
                purpose = band.purpose,
                range = range,
                intensityBand = effectiveBandLabel
            )
        }

        // Ensure all ranges are continuous and ordered after display rounding.
        if (zones.any { it.range.fastestPaceValue >= it.range.slowestPaceValue }) return null
        for (index in 0 until zones.lastIndex) {
            if (zones[index].range.fastestPaceValue != zones[index + 1].range.slowestPaceValue) return null
        }

        return TrainingPaceZones(
            method = "Cooper 12 min • faixas operacionais, teste da fala e referência auxiliar de VAM estimada",
            modelVersion = ZONE_MODEL_VERSION,
            averageTestPaceValue = averagePace,
            estimatedVo2Max = estimatedVo2,
            estimatedMasPaceValue = masPace,
            estimatedSvt2PaceValue = svt2Pace,
            z1 = zones[0], z2 = zones[1], z3 = zones[2], z4 = zones[3], z5 = zones[4],
            z2CalibrationStatus = talkEvidence.second,
            talkTestEvidenceCount = validTalkPaces.size,
            talkTestReferencePaceValue = talkEvidence.third
        )
    }

    /**
     * Returns a Z2/Z3 boundary pace, status, and reference pace.
     * At least two observations are required; a spread above 45 s is treated as
     * inconsistent and does not alter the Cooper-only baseline.
     */
    private fun resolveTalkTestBoundary(
        observations: List<Int>,
        slowCooperBoundary: Int,
        fastCooperBoundary: Int
    ): Triple<Int?, String, Int?> {
        if (observations.size < 2) {
            return Triple(null, if (observations.isEmpty()) "COOPER_INITIAL" else "TALK_TEST_PENDING", null)
        }
        val spread = observations.maxOrNull()!! - observations.minOrNull()!!
        if (spread > 45) return Triple(null, "TALK_TEST_INCONSISTENT", null)

        val sorted = observations.sorted()
        val median = if (sorted.size % 2 == 1) sorted[sorted.size / 2]
            else ((sorted[sorted.size / 2 - 1] + sorted[sorted.size / 2]) / 2.0).roundToInt()
        // Keep a 10-second conservative buffer slower than the fastest observed
        // full-sentence pace and preserve at least 30 seconds for adjacent zones.
        val rawBoundary = median + 10
        val minBoundary = fastCooperBoundary + 15
        val maxBoundary = slowCooperBoundary - 45
        // The initial Cooper range must leave at least a small positive space for
        // Z1, Z2 and Z3. If not, the calibration is rejected rather than throwing.
        if (minBoundary > maxBoundary) return Triple(null, "TALK_TEST_INCONSISTENT", null)
        val boundary = rawBoundary.coerceIn(minBoundary, maxBoundary)
        return Triple(boundary, "TALK_TEST_CONFIRMED", median)
    }

    fun createCalibrationSnapshot(
        distanceKm: Double?,
        assessmentDateIso: String,
        talkTestComfortPaces: List<Int> = emptyList()
    ): PaceCalibrationSnapshot? {
        val zones = calculateCooper(distanceKm, talkTestComfortPaces) ?: return null
        return PaceCalibrationSnapshot(
            assessmentDateIso = assessmentDateIso,
            distanceKm = distanceKm ?: return null,
            averagePaceMmSs = PaceRange.format(zones.averageTestPaceValue),
            estimatedVo2Max = zones.estimatedVo2Max,
            estimatedMasPaceMmSs = zones.estimatedMasPace,
            estimatedSvt2PaceMmSs = zones.estimatedSvt2Pace,
            modelVersion = zones.modelVersion,
            zoneRanges = zones.all().associate { it.id to it.range.label() },
            z2CalibrationStatus = zones.z2CalibrationStatus,
            talkTestEvidenceCount = zones.talkTestEvidenceCount,
            talkTestReferencePaceMmSs = zones.talkTestReferencePace
        )
    }

    /** Parse elapsed time entered as mm:ss or hh:mm:ss. */
    fun parseDuration(text: String): Int? {
        val value = text.trim()
        val total = when {
            Regex("^\\d{1,3}:[0-5]\\d$").matches(value) -> {
                val parts = value.split(":")
                (parts[0].toIntOrNull() ?: return null) * 60 + (parts[1].toIntOrNull() ?: return null)
            }
            Regex("^\\d{1,2}:[0-5]\\d:[0-5]\\d$").matches(value) -> {
                val parts = value.split(":")
                (parts[0].toIntOrNull() ?: return null) * 3600 +
                    (parts[1].toIntOrNull() ?: return null) * 60 +
                    (parts[2].toIntOrNull() ?: return null)
            }
            else -> return null
        }
        return total.takeIf { it in 1..86_399 }
    }

    /** Calculates recorded activity pace; result is displayed only as mm:ss min/km. */
    fun paceFromDistanceAndDuration(distanceKm: Double, totalDurationValue: Int): Int? {
        if (!distanceKm.isFinite() || distanceKm <= 0.0 || totalDurationValue <= 0) return null
        return (totalDurationValue / distanceKm).roundToInt().takeIf { it in 120..1800 }
    }

    fun formatPace(paceValue: Int): String = PaceRange.format(paceValue)

    private fun paceFromEstimatedSpeed(estimatedSpeed: Double): Int {
        // Internal conversion only. Screens and integrations expose mm:ss min/km.
        return (3_600.0 / estimatedSpeed).roundToInt().coerceIn(120, 1800)
    }
}
