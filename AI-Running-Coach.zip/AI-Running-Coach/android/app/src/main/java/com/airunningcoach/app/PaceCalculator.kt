package com.airunningcoach.app

import java.util.Locale
import kotlin.math.roundToInt

/**
 * Pace is calculated internally as a numeric value for arithmetic, but every user-facing
 * value and every integration field is formatted exclusively as mm:ss min/km.
 */
internal data class PaceRange(
    val fastestPaceValue: Int,
    val slowestPaceValue: Int
) {
    init {
        require(fastestPaceValue > 0)
        require(slowestPaceValue >= fastestPaceValue)
    }

    fun label(): String = "${format(fastestPaceValue)}–${format(slowestPaceValue)} min/km"

    companion object {
        fun format(paceValue: Int): String {
            val safe = paceValue.coerceAtLeast(0)
            return String.format(Locale.US, "%d:%02d", safe / 60, safe % 60)
        }

        /** Interprets a displayed pace in mm:ss min/km. */
        fun parsePace(text: String): Int? {
            val value = text.trim()
            if (!Regex("^\\d{1,2}:[0-5]\\d$").matches(value)) return null
            val parts = value.split(":")
            val minutes = parts[0].toIntOrNull() ?: return null
            val seconds = parts[1].toIntOrNull() ?: return null
            return (minutes * 60 + seconds).takeIf { it in 120..1800 }
        }

        fun formatDuration(totalValue: Int): String {
            val safe = totalValue.coerceAtLeast(0)
            val hours = safe / 3600
            val minutes = (safe % 3600) / 60
            val seconds = safe % 60
            return if (hours > 0) String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
            else String.format(Locale.US, "%d:%02d", safe / 60, seconds)
        }
    }
}

internal data class PaceZone(
    val id: String,
    val name: String,
    val purpose: String,
    val range: PaceRange,
    val intensityBand: String
)

internal data class PaceCalibrationSnapshot(
    val assessmentDateIso: String,
    val distanceKm: Double,
    val averagePaceMmSs: String,
    val estimatedVo2Max: Double,
    val modelVersion: String,
    /** Frozen zone labels, each formatted as mm:ss–mm:ss min/km. */
    val zoneRanges: Map<String, String>
)

internal data class TrainingPaceZones(
    val method: String,
    val modelVersion: String,
    val averageTestPaceValue: Int,
    val estimatedVo2Max: Double,
    val z1: PaceZone,
    val z2: PaceZone,
    val z3: PaceZone,
    val z4: PaceZone,
    val z5: PaceZone
) {
    val recovery: PaceRange get() = z1.range
    val easy: PaceRange get() = z2.range
    val longRun: PaceRange get() = z2.range
    val threshold: PaceRange get() = z4.range
    val interval: PaceRange get() = z5.range

    fun zone(id: String): PaceZone? = when (id.uppercase(Locale.ROOT)) {
        "Z1" -> z1
        "Z2" -> z2
        "Z3" -> z3
        "Z4" -> z4
        "Z5" -> z5
        else -> null
    }

    fun all(): List<PaceZone> = listOf(z1, z2, z3, z4, z5)
}

/** Cooper is the only supported source for official Z1–Z5 pace calibration. */
internal object PaceCalculator {
    private const val MIN_COOPER_DISTANCE_KM = 1.0
    private const val MAX_COOPER_DISTANCE_KM = 5.0
    const val COOPER_DURATION_LABEL = "12 min"
    const val ZONE_MODEL_VERSION = "AIRC_ZONES_1"

    /**
     * Product-defined operational training bands anchored to Cooper-estimated aerobic speed.
     * They are not direct measurements of LT1/LT2/ventilatory thresholds. Boundaries touch
     * without gaps or overlaps; real-world effort also depends on conditions and terrain.
     */
    private data class ZoneBand(
        val id: String,
        val name: String,
        val purpose: String,
        val low: Double,
        val high: Double
    )

    private val zoneBands = listOf(
        ZoneBand("Z1", "Regenerativa", "Recuperação, aquecimento e desaquecimento", 0.55, 0.65),
        ZoneBand("Z2", "Aeróbia", "Rodagens fáceis e longões conversáveis", 0.65, 0.75),
        ZoneBand("Z3", "Moderada", "Corrida contínua em ritmo sustentável", 0.75, 0.85),
        ZoneBand("Z4", "Limiar", "Tempo run e intervalos controlados de limiar", 0.85, 0.95),
        ZoneBand("Z5", "VO₂máx", "Intervalos aeróbios intensos e curtos", 0.95, 1.05)
    )

    /** Distance is entered only in km; the Cooper test duration is fixed at 12 minutes. */
    fun calculateCooper(distanceKm: Double?): TrainingPaceZones? {
        if (distanceKm == null || !distanceKm.isFinite() || distanceKm !in MIN_COOPER_DISTANCE_KM..MAX_COOPER_DISTANCE_KM) return null
        val estimatedVo2 = 22.351 * distanceKm - 11.288
        if (!estimatedVo2.isFinite() || estimatedVo2 !in 10.0..110.0) return null

        // Average Cooper pace over the fixed 12-minute test, used as the calibration anchor.
        val averagePace = (720.0 / distanceKm).roundToInt()
        val zones = zoneBands.map { band ->
            PaceZone(
                id = band.id,
                name = band.name,
                purpose = band.purpose,
                range = paceRangeFromCooperPace(averagePace, band.low, band.high),
                intensityBand = "${(band.low * 100).roundToInt()}–${(band.high * 100).roundToInt()}% da referência aeróbia estimada"
            )
        }
        return TrainingPaceZones(
            method = "COOPER_12_MIN_ESTIMATED_MAS",
            modelVersion = ZONE_MODEL_VERSION,
            averageTestPaceValue = averagePace,
            estimatedVo2Max = estimatedVo2,
            z1 = zones[0], z2 = zones[1], z3 = zones[2], z4 = zones[3], z5 = zones[4]
        )
    }

    fun createCalibrationSnapshot(distanceKm: Double?, assessmentDateIso: String): PaceCalibrationSnapshot? {
        val zones = calculateCooper(distanceKm) ?: return null
        return PaceCalibrationSnapshot(
            assessmentDateIso = assessmentDateIso,
            distanceKm = distanceKm ?: return null,
            averagePaceMmSs = PaceRange.format(zones.averageTestPaceValue),
            estimatedVo2Max = zones.estimatedVo2Max,
            modelVersion = zones.modelVersion,
            zoneRanges = zones.all().associate { it.id to it.range.label() }
        )
    }

    /** Parse elapsed time entered as mm:ss or hh:mm:ss. */
    fun parseDuration(text: String): Int? {
        val value = text.trim()
        val total = when {
            Regex("^\\d{1,3}:[0-5]\\d$").matches(value) -> {
                val parts = value.split(":")
                (parts[0].toIntOrNull() ?: return null) * 60 + (parts[1].toIntOrNull() ?: return null)
            }
            Regex("^\\d{1,2}:[0-5]\\d:[0-5]\\d$").matches(value) -> {
                val parts = value.split(":")
                (parts[0].toIntOrNull() ?: return null) * 3600 +
                    (parts[1].toIntOrNull() ?: return null) * 60 +
                    (parts[2].toIntOrNull() ?: return null)
            }
            else -> return null
        }
        return total.takeIf { it in 1..86_399 }
    }

    /** Calculates the recorded activity pace; result is displayed only as mm:ss min/km. */
    fun paceFromDistanceAndDuration(distanceKm: Double, totalDurationValue: Int): Int? {
        if (!distanceKm.isFinite() || distanceKm <= 0.0 || totalDurationValue <= 0) return null
        return (totalDurationValue / distanceKm).roundToInt().takeIf { it in 120..1800 }
    }

    fun formatPace(paceValue: Int): String = PaceRange.format(paceValue)

    private fun paceRangeFromCooperPace(cooperPaceValue: Int, slowerSpeedFraction: Double, fasterSpeedFraction: Double): PaceRange {
        val fastest = (cooperPaceValue / fasterSpeedFraction).roundToInt()
        val slowest = (cooperPaceValue / slowerSpeedFraction).roundToInt()
        return PaceRange(fastest, slowest)
    }
}
