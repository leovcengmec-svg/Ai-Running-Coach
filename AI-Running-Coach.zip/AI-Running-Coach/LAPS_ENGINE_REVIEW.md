# Revisão técnica do motor Laps

Fonte: https://github.com/coderang-gk/Laps (branch main, consultada em 05/11/2026).

## PlanGenerator.kt
- Gera 6 a 16 semanas, mas o volume de pico não é calculado pelo histórico do atleta: é fixado em 30 km para 5K, 40 km para 10K, 48 km para meia maratona e 68 km para maratona.
- Usa `ltspPace` padrão `4:56 /km` e `lthrBpm` padrão 172.
- Trata terça-feira como dia de qualidade e domingo como longão; a distribuição depende dos dias escolhidos.
- O último bloco é taper; a regra de semana regenerativa é condicionada por `week % 4` e pela regra de taper.

## EvoLabAnalyzer.kt
- Recebe `CorosApiClient.CorosActivity`, `CalendarSyncManager.PlannedWorkout` e LTHR.
- Analisa frequência cardíaca, pace, Training Load, potência, cadência e Training Effect.
- As mensagens geradas pressupõem esses dados e algumas faixas fixas. Sem esses campos, a análise não pode ser usada literalmente.

## Decisão para AI Running Coach
Não importar esses arquivos sem adaptação. O AI Running Coach não pode aplicar os picos fixos ou os valores COROS como se fossem dados de qualquer atleta. A extração correta é transformar a lógica em módulos puros e injetar volume recente, maior sessão recente, frequência disponível, feedback do Pace Coach e métricas fisiológicas apenas quando existirem.
