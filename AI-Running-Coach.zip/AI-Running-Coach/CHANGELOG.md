# Changelog

## V18

- Substituída a geração isolada da primeira semana por um ciclo completo de quatro semanas.
- Adotada arquitetura de prescrição inspirada no Laps, sem dependências COROS ou Google Calendar.
- Incluídas progressão, semana regenerativa, controle conservador do longão e bloqueio por dor reportada.
- Criadas sessões estruturadas com aquecimento, estímulos, recuperações e desaquecimento.
- Adicionado motor local de análise de feedback e regras para treinos perdidos.
- Persistidos feedbacks e quilometragem efetivamente realizada; aderência não é inferida sem distância real.
- Adicionado suporte a objetivos personalizados de 1 a 100 km.
- Implementado compartilhamento de sessão em JSON versionado para futura importação no Pace Coach.
- Atualizada configuração GitHub Actions para executar testes e build APK.
- Atualizados SDK, dependências Compose e versionamento para V18.
