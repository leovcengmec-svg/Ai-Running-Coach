# Changelog

## V20 — Redesign Material 3 Expressive
- Reconstruída a experiência principal com linguagem visual inspirada no Laps: Training Hub, painéis de métricas, superfícies expressivas, dock inferior e hierarquia tipográfica revisada.
- Dashboard reorganizado com resumo do ciclo, volume planejado da primeira semana, métricas do perfil, gráfico de distribuição diária e próximo treino.
- Calendário e plano reorganizados por semana em cartões expansíveis, com divisão entre rodagem leve, qualidade e longão.
- Detalhes da sessão e estrutura dos blocos redesenhados, com distância, duração estimada, RPE, fases e status.
- Evolução passa a apresentar apenas distâncias efetivamente registradas em feedback, com estado vazio explicativo quando não há dados.
- Perfil, histórico, feedback e compartilhamento com Pace Coach receberam layout consistente.
- Onboarding recebeu superfícies, seleção e marca visual atualizadas.
- Paleta atualizada para slate/indigo escuro, cartões arredondados e contraste mais claro.
- Mantido o motor de prescrição V19 sem alterações funcionais nesta revisão.
- Mantida a separação de responsabilidades: AI Running Coach planeja; Pace Coach executa e registra a corrida.
- Atualizado `versionCode` para 20 e `versionName` para V20.

## V19
- Consistência corrigida entre a distância total das sessões e a soma das distâncias dos blocos enviados ao Pace Coach.
- Migração de valores antigos não medidos passa a exigir confirmação numérica.
- Corrigida a falha que convertia a faixa de volume semanal 10–30 km em 10 km, produzindo planos artificialmente baixos.
- Onboarding passa a solicitar média semanal real das últimas quatro semanas e maior sessão contínua recente em valores numéricos.
- Primeira semana passa a partir do volume informado, sem redução fixa de 10% por padrão.
- Ciclo padrão ampliado para oito semanas, com blocos progressivos e semanas regenerativas 4 e 8.
- Experiência declarada separada da carga real; elegibilidade de qualidade depende também do histórico recente.
- Limite por sessão baseado na maior distância contínua recente; redução do volume semanal é explicada quando a frequência e a tolerância não comportam a carga declarada.
- Estados não avaliados deixam de ser apresentados como GREEN/LOW sem contexto.
- Removidos botões sem ação nas telas de treino e perfil.

## V18
- Substituída a geração isolada da primeira semana por um ciclo completo de quatro semanas.
- Adotada arquitetura de prescrição inspirada no Laps, sem dependências COROS ou Google Calendar.
- Incluídas progressão, semana regenerativa, controle conservador do longão e bloqueio por dor reportada.
- Criadas sessões estruturadas com aquecimento, estímulos, recuperações e desaquecimento.
- Adicionado motor local de análise de feedback e regras para treinos perdidos.
- Persistidos feedbacks e quilometragem efetivamente realizada; aderência não é inferida sem distância real.
- Adicionado suporte a objetivos personalizados de 1 a 100 km.
- Implementado compartilhamento de sessão em JSON versionado para futura importação no Pace Coach.
