## V28 — Correção de compilação
- Corrigido `MutableSet<Int>()`, que tentava instanciar diretamente uma interface Kotlin, usando `mutableSetOf<Int>()`.
- Preservada a identificação dos dias com competições no gráfico semanal.
- Incrementado `versionCode` para 28 e `versionName` para V28.

# Changelog

## V27 — Competições, calendário e preparação por data
- Adicionado cadastro, edição e exclusão de provas com distância, data e prioridade A/B/C.
- Data-alvo passa a ser derivada da próxima prova principal cadastrada.
- A distância da prova A (ou B quando não houver A futura) é utilizada como objetivo específico do motor.
- Janela de planejamento ajustada para incluir a semana de competição e, quando possível, uma semana de recuperação posterior.
- Prova programada dentro do ciclo substitui uma sessão semanal; a frequência configurada passa a contar treinos + provas.
- Taper pré-prova e recuperação pós-prova adicionados, com parâmetros diferentes por distância.
- Calendário mensal, semanal e diário reconstruído para apresentar treinos, competições e dias livres.
- Eventos e sinalização de recálculo persistidos localmente.
- Treinos concluídos são preservados ao gerar novo plano.
- Corrigida a seleção do objetivo do ciclo: uma prova distante, fora da janela ativa de 16 semanas, permanece no calendário, mas não altera prematuramente a distância-alvo do bloco atual.
- Mantidas as regras de distância em km e pace em mm:ss min/km.

## V26 — Modelo Cooper + teste da fala
- Faixas iniciais de Z1–Z5 baseadas na velocidade média do Cooper.
- Personalização inicial da Z2 por registros de fala confortável.
- Atualização de snapshots e contrato de sessão.


## V26 — Zonas iniciais pela velocidade do Cooper e Z2 individualizada
- Substituído o modelo de cinco zonas relativo à VAM da V25 por faixas operacionais percentuais da velocidade média do Cooper, seguindo a planilha de referência: 60–70%, 70–80%, 80–90%, 90–100% e 100–110%.
- Corrigida a nomenclatura: os percentuais são da velocidade média do Cooper, não percentuais de VO₂máx.
- VAM estimada e segundo limiar estimado permanecem como referências complementares; não determinam diretamente as fronteiras das zonas.
- Adicionada personalização conservadora de Z2 por pelo menos dois registros consistentes de pace em trechos de fala confortável durante rodagens fáceis ou longões.
- Registros de fala precisam estar associados a sessões aeróbias concluídas, com dados reais da atividade, sem dor, com esforço leve/aceitável e sensação geral boa.
- A calibração utiliza mediana dos até três registros mais recentes, tolerância máxima de 45 segundos e margem conservadora de 10 segundos; mantém fronteiras contínuas e largura mínima das zonas.
- Feedback passa a registrar pace do trecho estável em que frases completas eram confortáveis. O novo limite de Z2 pede recriação do plano; sessões passadas preservam seus snapshots.
- Rodagem fácil e longão usam Z2; recuperação entre repetições/fartlek utiliza Z1. Corridas regenerativas também recebem alvo numérico Z1, evitando divergência entre o rótulo da zona e o pace exportado.
- Quando o teste da fala personaliza Z1–Z3, os rótulos de intensidade na tela e no JSON deixam de exibir percentuais iniciais incompatíveis com as novas fronteiras.
- Atualizado contrato Pace Coach para 6.0 com base percentual explícita e metadados da calibração da Z2.
- Atualizado versionCode 26 / versionName V26.

## V25 — Modelo fisiológico estimado de zonas Cooper
- Cooper de 12 min e estimativas VAM/sVT2; modelo legado agora preservado apenas em histórico.

## V24 — Correção de compilação Android
- Corrigido erro `Unresolved reference: SecondaryButton` em dois pontos da `MainActivity.kt`.
- Adicionado botão secundário baseado em Material 3.

## V23 — Cooper, zonas Z1–Z5 e revisão inteligente
- Cooper de 12 minutos e ciclo de avaliação a cada 28 dias.
- Registro de histórico, prescrição estruturada, feedback e exportação.

## V22 e anteriores
- Ver histórico de versões e arquivos de metodologia anteriores.
