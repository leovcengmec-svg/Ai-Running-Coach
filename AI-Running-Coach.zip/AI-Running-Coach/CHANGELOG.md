## V38 — Identidade visual simplificada
- Substituído o ícone chamativo anterior por uma composição minimalista: fundo azul-marinho, silhueta branca de corredor e um único arco ciano de movimento.
- Removidos elementos decorativos de IA/chip, GPS, satélite, batimento, cronômetro, gráficos, brilhos e textos do símbolo do launcher.
- Atualizadas as camadas adaptativas Android (fundo e primeiro plano) e as variantes quadrada/arredondada nas densidades mdpi, hdpi, xhdpi, xxhdpi e xxxhdpi.
- Atualizados os arquivos de identidade visual em `design/`; nome exibido `AI Running Coach`, lógica de treinamento, exportação e dados do atleta preservados.
- `versionCode = 38` e `versionName = V38`; nome canônico do ZIP `AI-Running-Coach.zip` preservado.
- A compilação Android completa deve ser confirmada pelo GitHub Actions.

## V37 — Correção da prescrição, periodização e adaptação à carga real
- Aplicada proteção de recuperação também na montagem inicial do calendário: a sessão de qualidade só é prescrita quando há ao menos um dia completo entre ela e o longão; quando a disponibilidade não permite, a qualidade é suprimida e a decisão fica sinalizada.
- Progressivos deixam de ser inseridos como rodagens fáceis ao lado de uma sessão-chave; strides são apenas complemento técnico ocasional, não somado em semanas com qualidade, regenerativas ou para iniciantes.
- Iniciantes e atletas em reintrodução recebem no máximo três sessões semanais estruturadas em corrida/caminhada por tempo, com pausas reais, aquecimento, desaquecimento e progressão gradual.
- Carga real usa atividades concluídas com distância medida, vinculadas à data da sessão (com fallback para a data do feedback em registros antigos). A média de 28 dias só substitui o perfil após pelo menos seis corridas distribuídas por três semanas ISO; a maior sessão dos últimos 30 dias limita a dose individual.
- O limite de 10% por sessão é tratado como guarda conservadora relacionada a tolerância recente, não como regra universal de segurança ou progressão semanal.
- A programação de qualidade agora diferencia 5 km, 10 km, meia maratona e maratona; a maratona passa a incluir bloco específico predominantemente aeróbio, evitando transformar toda sessão-chave em limiar.
- Semanas 4/8 usam redução controlada da carga semanal (alvo de 10–20% em relação à semana de desenvolvimento anterior); o longão regenerativo recebe o nome “Longão aeróbio reduzido” e mantém seu objetivo aeróbio conversável.
- Z5 passa a usar a VAM estimada como referência rápida complementar quando plausível, ou a faixa conservadora Cooper quando não; Z4/Z5 são explicitamente estimadas, sem afirmar limiar ou VO₂máx medido. Modelo de zonas atualizado para AIRC_ZONES_4.
- Biblioteca apresenta duas rotinas opcionais de fortalecimento. Elas não são inseridas automaticamente no calendário de corrida.
- Motor interno atualizado para engineVersion 31, solicitando recálculo de planos antigos ao abrir a nova revisão.
- Adicionados testes para distribuição de dias, semanas regenerativas, corrida/caminhada, carga real, Z5 estimada, especificidade por distância e fortalecimento.
- `versionCode = 37` e `versionName = V37`; nome canônico do ZIP `AI-Running-Coach.zip` preservado.

## V36 — Exportação como arquivo JSON anexado
- Corrigido o compartilhamento da prescrição: o conteúdo deixa de ser enviado por `Intent.EXTRA_TEXT` e passa a ser gravado como arquivo `.json` UTF-8 real.
- O compartilhamento Android agora usa `application/json`, `Intent.EXTRA_STREAM`, `ClipData` e concessão explícita de leitura ao aplicativo receptor.
- Adicionado `FileProvider` com acesso restrito somente à pasta temporária `cache/exports/`; nenhum acesso amplo ao armazenamento é concedido.
- Nome do arquivo: `pace-coach-workout-<sessionId>.json`, com identificador sanitizado para impedir traversal de caminhos.
- Adicionados testes unitários para extensão, MIME, conteúdo UTF-8, segurança do caminho e reexportação da mesma sessão.
- O contrato JSON Pace Coach 6.0 e os dados da prescrição permanecem inalterados.
- `versionCode = 36` e `versionName = V36`; ZIP canônico `AI-Running-Coach.zip` preservado.

## V35 — Disponibilidade semanal em tela independente
- Removido o editor completo de disponibilidade da tela principal de Perfil do atleta; o perfil mantém apenas o resumo dos dias configurados.
- Adicionada a ação “Disponibilidade semanal” dentro de “Gerenciar perfil”, com resumo da quantidade de dias e do dia preferido para o longão.
- Ao abrir a ação, a configuração é apresentada em uma tela própria, com cabeçalho e retorno ao perfil.
- Mantidas as seleções de 2 a 6 dias, a preferência do longão, o salvamento local e o aviso/ação de recálculo do plano quando a disponibilidade muda.
- Etapa de disponibilidade do onboarding preservada; nenhuma regra do motor de treinamento ou estrutura dos dados foi alterada.
- `versionCode = 35` e `versionName = V35`; ZIP canônico `AI-Running-Coach.zip` preservado.

## V34 — Compactação dos recursos gráficos
- Otimizados os PNGs da identidade visual e dos ícones Android com paleta indexada de até 256 cores, mantendo os formatos PNG, as dimensões e a transparência.
- Mantidas a arte final e a imagem de referência no diretório `design/`; a referência visual aprovada da interface foi preservada sem alteração.
- Regeneração/compactação aplicada ao primeiro plano adaptativo e às variantes legacy quadrada/arredondada nas cinco densidades Android.
- Nenhum arquivo Kotlin, motor de treinamento, tela, integração ou regra funcional foi alterado nesta revisão.
- Incrementado `versionCode = 34` e `versionName = V34`; nome do aplicativo e nome canônico do ZIP preservados.
- O APK ainda depende da execução e validação do workflow GitHub Actions.

## V33 — Ícone oficial atualizado a partir do modelo fornecido
- Substituída a arte do launcher pelo modelo visual enviado: chip AI, corredor em movimento, sinal de desempenho, GPS/satélite, métricas e wordmark “AI Running Coach”.
- Atualizadas as camadas adaptativas Android e as versões legacy quadrada/arredondada nas cinco densidades (mdpi a xxxhdpi).
- Mantidos o nome exibido `AI Running Coach`, o identificador do aplicativo e toda a lógica funcional da V32.
- Incrementado `versionCode = 33` e `versionName = V33`.
- Atualizada a arte de referência PNG/SVG em `design/`; ZIP mantido como `AI-Running-Coach.zip`.
- Compilação Android/Compose deve ser confirmada pelo GitHub Actions.

## V29 — Disponibilidade semanal, reagendamento e calendário por modalidade
- Disponibilidade habitual configurável de 2 a 6 dias; a frequência é derivada dos dias selecionados.
- Preferência de dia do longão aplicada ao motor de distribuição.
- Reagendamento pontual para um dia livre da mesma semana, inclusive como exceção à disponibilidade habitual.
- Valida colisões, competições, sessões concluídas e intervalo mínimo entre sessões exigentes.
- Preserva identidade, dose, pace, blocos e data original das sessões movidas.
- Calendário diferencia regenerativo, aeróbio, moderado, progressivo, qualidade/limiar, intervalado, fartlek, longão e prova.
- Adicionados testes do motor de agenda e disponibilidade (8 testes unitários verificados localmente e matriz de 434 combinações).
- Corrigida a edição de disponibilidade vazia no onboarding para não acessar o último dia de uma lista vazia.
- Preservadas datas de reagendamento manual também na conversão de sessões da semana corrente ajustadas por competições, quando compatíveis.
- VersionCode 29 / versionName V29.

## V28 — Correção de compilação
- Corrigido `MutableSet<Int>()`, que tentava instanciar diretamente uma interface Kotlin, usando `mutableSetOf<Int>()`.
- Preservada a identificação dos dias com competições no gráfico semanal.
- Incrementado `versionCode` para 28 e `versionName` para V28.

# Changelog

## V27 — Competições, calendário e preparação por data
- Adicionado cadastro, edição e exclusão de provas com distância, data e prioridade A/B/C.
- Data-alvo passa a ser derivada da próxima prova principal cadastrada.
- A distância da prova A (ou B quando não houver A futura) é utilizada como objetivo específico do motor.
- Janela de planejamento ajustada para incluir a semana de competição e, quando possível, uma semana de recuperação posterior.
- Prova programada dentro do ciclo substitui uma sessão semanal; a frequência configurada passa a contar treinos + provas.
- Taper pré-prova e recuperação pós-prova adicionados, com parâmetros diferentes por distância.
- Calendário mensal, semanal e diário reconstruído para apresentar treinos, competições e dias livres.
- Eventos e sinalização de recálculo persistidos localmente.
- Treinos concluídos são preservados ao gerar novo plano.
- Corrigida a seleção do objetivo do ciclo: uma prova distante, fora da janela ativa de 16 semanas, permanece no calendário, mas não altera prematuramente a distância-alvo do bloco atual.
- Mantidas as regras de distância em km e pace em mm:ss min/km.

## V26 — Modelo Cooper + teste da fala
- Faixas iniciais de Z1–Z5 baseadas na velocidade média do Cooper.
- Personalização inicial da Z2 por registros de fala confortável.
- Atualização de snapshots e contrato de sessão.


## V26 — Zonas iniciais pela velocidade do Cooper e Z2 individualizada
- Substituído o modelo de cinco zonas relativo à VAM da V25 por faixas operacionais percentuais da velocidade média do Cooper, seguindo a planilha de referência: 60–70%, 70–80%, 80–90%, 90–100% e 100–110%.
- Corrigida a nomenclatura: os percentuais são da velocidade média do Cooper, não percentuais de VO₂máx.
- VAM estimada e segundo limiar estimado permanecem como referências complementares; não determinam diretamente as fronteiras das zonas.
- Adicionada personalização conservadora de Z2 por pelo menos dois registros consistentes de pace em trechos de fala confortável durante rodagens fáceis ou longões.
- Registros de fala precisam estar associados a sessões aeróbias concluídas, com dados reais da atividade, sem dor, com esforço leve/aceitável e sensação geral boa.
- A calibração utiliza mediana dos até três registros mais recentes, tolerância máxima de 45 segundos e margem conservadora de 10 segundos; mantém fronteiras contínuas e largura mínima das zonas.
- Feedback passa a registrar pace do trecho estável em que frases completas eram confortáveis. O novo limite de Z2 pede recriação do plano; sessões passadas preservam seus snapshots.
- Rodagem fácil e longão usam Z2; recuperação entre repetições/fartlek utiliza Z1. Corridas regenerativas também recebem alvo numérico Z1, evitando divergência entre o rótulo da zona e o pace exportado.
- Quando o teste da fala personaliza Z1–Z3, os rótulos de intensidade na tela e no JSON deixam de exibir percentuais iniciais incompatíveis com as novas fronteiras.
- Atualizado contrato Pace Coach para 6.0 com base percentual explícita e metadados da calibração da Z2.
- Atualizado versionCode 26 / versionName V26.

## V25 — Modelo fisiológico estimado de zonas Cooper
- Cooper de 12 min e estimativas VAM/sVT2; modelo legado agora preservado apenas em histórico.

## V24 — Correção de compilação Android
- Corrigido erro `Unresolved reference: SecondaryButton` em dois pontos da `MainActivity.kt`.
- Adicionado botão secundário baseado em Material 3.

## V23 — Cooper, zonas Z1–Z5 e revisão inteligente
- Cooper de 12 minutos e ciclo de avaliação a cada 28 dias.
- Registro de histórico, prescrição estruturada, feedback e exportação.

## V22 e anteriores
- Ver histórico de versões e arquivos de metodologia anteriores.


## V30 — Alternativa de treino por sessão
- Incluída uma segunda opção em cada sessão futura e não concluída.
- A escolha entre opção principal e alternativa é persistida por identificador de sessão.
- A alternativa substitui a principal sem adicionar volume ou frequência.
- Qualidade: alternativa contínua moderada em Z3; longão: formato contínuo confortável; rodagem: corrida-caminhada aeróbia.
- Opções bloqueadas após conclusão da sessão; competições permanecem eventos únicos.


## V31 — Tela de sessão simplificada e troca compacta de alternativa
- A tela de sessão mostra apenas a prescrição ativa; as duas opções não ficam mais expostas simultaneamente.
- Adicionado comando compacto “Trocar treino”, que abre uma caixa de confirmação com a alternativa e permite usá-la ou manter a atual. Quando a alternativa está selecionada, a mesma ação permite voltar à recomendada.
- Removido o resumo redundante de distância/duração/pace, pois esses dados já aparecem no cartão principal da sessão.
- Ações secundárias reorganizadas: reagendar e feedback em controles compactos; exportação mantida como ação principal.
- Alternativas movidas para `WorkoutAlternativeEngine.kt`, separadas da composição visual e compartilhadas pela tela, calendário e exportação.
- Alternativa de qualidade substitui intervalos por bloco aeróbio contínuo em Z2; alternativa de longão usa corrida com pausas confortáveis em Z1; alternativas aeróbias/regenerativas usam corrida-caminhada leve em Z1.
- Ao trocar de zona, todos os blocos alterados recebem a faixa pace correspondente ao snapshot da sessão; sem calibração não é inventado pace.
- Mantidos identificador, data, semana, dose total, duração estimada, reagendamento e snapshot de calibração da sessão original. A alternativa substitui a principal e não cria sessão adicional.
- Adicionados cinco testes de domínio para dose, zonas, pace, preservação da identidade e comportamento sem calibração.
- `versionCode = 31`, `versionName = V31`.


## V32 — Ícone oficial do aplicativo
- Criado ícone do AI Running Coach a partir da identidade visual aprovada: corredor em ciano sobre azul-marinho, sem texto no símbolo.
- Adicionadas camadas de ícone adaptativo Android e versões PNG legacy para mdpi, hdpi, xhdpi, xxhdpi e xxxhdpi.
- Configurados `android:icon` e `android:roundIcon` no Manifest.
- Nome do aplicativo preservado; `versionCode = 32` e `versionName = V32`.
