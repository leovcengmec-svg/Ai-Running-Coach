# Changelog

## V25 — Modelo fisiológico estimado de zonas Cooper
- Corrigido o erro conceitual da V24: a velocidade média do Cooper não é mais usada como substituta direta da VAM.
- Adicionadas as regressões publicadas para estimar VAM e segundo limiar a partir da distância Cooper de 12 minutos.
- Recalculadas as zonas Z1–Z5 usando a proposta de cinco faixas relativas à VAM de Cerezuela-Espejo et al. (2018): R0, R1, R2, R3 e R3+.
- As faixas são contínuas por fronteiras compartilhadas, sem lacunas ou sobreposições decorrentes de arredondamento.
- Adicionados pace equivalente da VAM e pace do segundo limiar à tela de calibração, histórico e snapshot de exportação.
- Atualizado o contrato Pace Coach para 5.0.
- Planos com `AIRC_ZONES_1` são identificados como legados e exigem revisão; não são exportados como calibração atual.
- Incluídos testes de referência para Cooper de 2,10 km, continuidade das cinco zonas e localização do segundo limiar estimado dentro da Z4.
- Incrementado `versionCode` para 25 e `versionName` para V25.


## V24 — Correção de compilação Android
- Corrigido erro `Unresolved reference: SecondaryButton` em dois pontos da `MainActivity.kt`.
- Adicionado botão secundário baseado em `OutlinedButton` do Material 3.
- Ajustado o layout das ações lado a lado para dividir o espaço disponível corretamente.
- Incrementado o versionamento Android para `versionCode 24` e `versionName V24`.


## V23 — Cooper, zonas Z1–Z5 e revisão inteligente
- Cooper de 12 minutos definido como única origem oficial das zonas de pace.
- Resultado do Cooper informado apenas em km; pace médio e zonas sempre como mm:ss min/km.
- Criado modelo operacional Z1–Z5 com versão `AIRC_ZONES_1`, limites contíguos e explicação de que são estimativas de campo, não limiares medidos.
- Eliminado o uso de resultados de prova antigos V22 como fallback para novas zonas. Perfis sem Cooper válido ficam sem pace calibrado até a avaliação.
- Onboarding passou a solicitar a data real do Cooper, validar que o resultado tenha até 56 dias e usar essa data no calendário de revisão.
- Histórico Cooper passou a guardar a fotografia das cinco faixas e a versão do modelo, preservando as zonas antigas.
- Revisão programada a cada 28 dias, condicionada a recuperação; o novo teste substitui uma sessão intensa e não é somado à carga semanal.
- Evolução de distância do Cooper exibida em relação à avaliação anterior.
- Monitoramento de pace utiliza atividades reais comparáveis na janela recente; não altera zonas sem novo Cooper válido.
- Segurança do Cooper considera feedbacks recentes, sem bloquear o teste indefinidamente por registros antigos.
- Biblioteca de 11 tipos de treino e prescrição estruturada por zona, distância e duração.
- Corrigida contabilização de repetições em sessões intervaladas e fartlek para que o volume dos blocos corresponda ao total estimado da sessão.
- Contrato Pace Coach 4.0 exporta as zonas congeladas no momento em que a sessão foi criada; distâncias em km e pace como mm:ss min/km.
- Perfil e histórico persistem ritmos como texto mm:ss min/km; duração de atividade continua aceitando mm:ss ou hh:mm:ss.
- `versionCode` atualizado para 23 e `versionName` para V23.

## V22 — Correção do tempo e distribuição semanal
- Parser de referência aceitava mm:ss e hh:mm:ss.
- Separação entre pace médio de prova e pace de treinamento.
- Distribuição semanal ajustada para frequência de 2–6 dias e longão normalmente como maior sessão.

## V21 — Prescrição compatível com Pace Coach
- Separação entre alvo de execução por tempo/distância e RPE complementar.
- Inclusão de faixa de pace em min/km quando calibrada.

## V20 — Redesign Material 3 Expressive
- Reconstrução visual inspirada no Laps, preservando a identidade do produto.

## V19 e anteriores
- Correções de volume e tolerância, ciclos plurissemanas, feedback, exportação estruturada e segurança; ver commits e versões anteriores do pacote.
