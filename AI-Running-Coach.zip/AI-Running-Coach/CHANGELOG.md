# Changelog

## V26 — Zonas iniciais pela velocidade do Cooper e Z2 individualizada
- Substituído o modelo de cinco zonas relativo à VAM da V25 por faixas operacionais percentuais da velocidade média do Cooper, seguindo a planilha de referência: 60–70%, 70–80%, 80–90%, 90–100% e 100–110%.
- Corrigida a nomenclatura: os percentuais são da velocidade média do Cooper, não percentuais de VO₂máx.
- VAM estimada e segundo limiar estimado permanecem como referências complementares; não determinam diretamente as fronteiras das zonas.
- Adicionada personalização conservadora de Z2 por pelo menos dois registros consistentes de pace em trechos de fala confortável durante rodagens fáceis ou longões.
- Registros de fala precisam estar associados a sessões aeróbias concluídas, com dados reais da atividade, sem dor, com esforço leve/aceitável e sensação geral boa.
- A calibração utiliza mediana dos até três registros mais recentes, tolerância máxima de 45 segundos e margem conservadora de 10 segundos; mantém fronteiras contínuas e largura mínima das zonas.
- Feedback passa a registrar pace do trecho estável em que frases completas eram confortáveis. O novo limite de Z2 pede recriação do plano; sessões passadas preservam seus snapshots.
- Rodagem fácil e longão usam Z2; recuperação entre repetições/fartlek utiliza Z1. Corridas regenerativas também recebem alvo numérico Z1, evitando divergência entre o rótulo da zona e o pace exportado.
- Quando o teste da fala personaliza Z1–Z3, os rótulos de intensidade na tela e no JSON deixam de exibir percentuais iniciais incompatíveis com as novas fronteiras.
- Atualizado contrato Pace Coach para 6.0 com base percentual explícita e metadados da calibração da Z2.
- Atualizado versionCode 26 / versionName V26.

## V25 — Modelo fisiológico estimado de zonas Cooper
- Cooper de 12 min e estimativas VAM/sVT2; modelo legado agora preservado apenas em histórico.

## V24 — Correção de compilação Android
- Corrigido erro `Unresolved reference: SecondaryButton` em dois pontos da `MainActivity.kt`.
- Adicionado botão secundário baseado em Material 3.

## V23 — Cooper, zonas Z1–Z5 e revisão inteligente
- Cooper de 12 minutos e ciclo de avaliação a cada 28 dias.
- Registro de histórico, prescrição estruturada, feedback e exportação.

## V22 e anteriores
- Ver histórico de versões e arquivos de metodologia anteriores.
