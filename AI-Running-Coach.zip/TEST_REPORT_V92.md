# Relatório de validação — V92

**Base:** V91  
**VersionCode:** 92 · **Engine:** 81 · **Backup Schema:** 7

## Harnesses Kotlin/JVM executados

| Área | Cenário | Resultado |
|---|---|---|
| Calendário | Bandeira quadriculada em PROVA | PASS |
| Calendário | Categorias gerais e tipo TESTE | PASS |
| Calendário | Hoje/futuro pendente, passado não concluído perdido, concluído concluído | PASS |
| Identidade | Chave canônica data + tipo | PASS |
| Identidade | Correspondência por slot e rejeição de tipo diferente | PASS |
| Carga | Tendência sRPE sem histórico confiável não limita crescimento | PASS |
| Carga | RPE alto com menos de três atividades não limita crescimento | PASS |
| Carga | RPE alto com três ou mais atividades gera cautela moderada | PASS |
| Carga | Semana regenerativa reduz carga e preserva referência de construção | PASS |
| Alternativas | Alternativa equivalente de Fartlek preserva sequência ativa/recuperação | PASS |
| Alternativas | Opção mais leve remove intensidade principal e reduz o volume | PASS |
| Alternativas | Alternativa progressiva mantém zonas e dose | PASS |

## Testes JUnit adicionados/atualizados

- `WorkoutCalendarPresentationTest`: bandeira quadriculada e status/opacidade.
- `WorkoutAlternativeEngineTest`: opção mais leve, Fartlek em blocos alternados e longão progressivo equivalente.
- `SessionIdentityEngineTest`: data/tipo canônicos e fallback para IDs remapeados.
- `LoadPrescriptionEngineV63Test`: qualidade da amostra RPE/sRPE.
- `AppBackupCodecTest`: Schema 7 e leitura dos schemas antigos 1–6.

**Não executados localmente:** os testes JUnit/Gradle acima não foram executados pela suíte oficial.

## Validação estática e integração de interface

- VersionCode/Name = 92/V92; CURRENT_ENGINE_VERSION = 81; Backup Schema = 7.
- Plano, dashboard e calendário renderizam a opção de sessão escolhida a partir de uma única função de apresentação, para que o volume mostrado corresponda à alternativa selecionada.
- A opção equivalente é desativada quando sinais de segurança não permitem preservar o estímulo; a camada de estado valida novamente a seleção.
- Os painéis duplicados de calibração e atividades recentes foram removidos de Evolução; comportamento por zona permanece na tela de zonas.
- A reconciliação do backup exige correspondência única por data original e tipo quando o ID não confere.

## Build Android

`:app:testDebugUnitTest`, `:app:compileDebugKotlin` e `:app:assembleDebug` **pendentes** do GitHub Actions. Gradle CLI e Android SDK não estão instalados neste ambiente, portanto não há APK certificado nesta entrega.
