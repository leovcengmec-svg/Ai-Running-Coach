# Test Report — AI Running Coach V96

## Identificação
- VersionCode 96 / VersionName V96.
- CURRENT_ENGINE_VERSION 86.
- Backup Schema 11 (leitura schemas 1–10).
- Base: V95.

## Casos de regressão adicionados
- Reteste futuro não define protocolo nem cria blocos prematuramente.
- Cooper gera bloco TIME de 12 minutos com aquecimento/desaquecimento.
- 3 km gera bloco DISTANCE de 3 km com tempo estimado quando há referência disponível.
- Troca do método do último teste para o protocolo selecionado usa estimativa própria do protocolo, sem confundir estimativa com resultado.
- Elegibilidade do protocolo de 3 km é limitada a 18–39 anos; ambos os protocolos exigem idade adulta e referência fisiológica válida.
- Resolução de carga mantém declarado 16 km/10 km e, com histórico confiável, entrega 8,5 km/6,6 km somente à camada de planejamento.
- Histórico parcial mantém valores declarados na prescrição.
- Backup Schema 11 preserva `weeklyVolumeText`, `longestRecent` e a pendência de atualização pós-confirmação adaptativa.

## Verificação executada nesta sessão
- Harness Kotlin/JVM compilado com `kotlinc` usando os motores reais `PaceCalculator`, `ZoneCalibrationEngine`, `RunnerFitnessAssessmentEngine`, `CooperAssessmentEngine`, `RetestProtocolEngine` e `RunnerLoadSourceResolver`; somente os tipos de interface `WorkoutSegment` e `ZoneIntensityBandEngine` foram substituídos por stubs mínimos de compilação. **PASS** para reteste sem método, protocolo Cooper, protocolo 3 km, elegibilidade etária e separação 16/10 declarada versus 8,5/6,6 medida.
- Inspeção estática confirmou VersionCode 96, VersionName V96, motor 86, schema 11, leitura `1..11`, persistência do novo estado e ausência de escrita em `weeklyVolumeText`/`longestRecent` dentro de `createPlan()`.
- Integridade do pacote final: `unzip -t` **PASS** (sem erros nos dados comprimidos).

## Limite da verificação
Não há Gradle nem Android SDK instalados neste ambiente. Portanto, a suíte oficial JUnit/Gradle, a compilação Android/Compose e a geração do APK não puderam ser executadas. O harness focado não substitui essas validações.

Para certificação, executar no workflow GitHub Actions `build-apk`: `gradle -p android :app:testDebugUnitTest :app:assembleDebug --no-daemon`.
