# BUILD STATUS — AI Running Coach V80

## Identificação
- Base: V79 corrigida, com nome original do pacote preservado.
- Arquivo: `AI-Running-Coach.zip`.
- `versionCode`: 80.
- `versionName`: V80.
- `CURRENT_ENGINE_VERSION`: 70.
- Backup Schema: 4; leitura de schemas 1–4.

## Implementações
1. Revisão da biblioteca de recuperações: F01 em Z1 90–100%; recuperação aeróbia Z2 em 0–30%; Z4 por caminhada e Z5 por pausa passiva nos protocolos explícitos. RPE e gatilhos respiratórios permanecem como apoio; a duração não é automaticamente encurtada.
2. Títulos de blocos sem índices redundantes na interface, mantendo repetição/ordem internamente.
3. `ActivityZoneTimeEngine` aceita voltas explícitas e parciais reconstruídas com duração até 7.200 s; amostras GPS brutas continuam limitadas a 120 s.
4. `ActivityFileImporter` normaliza distância de atividade em quilômetros inteiros acumulados + parcial final; voltas irregulares são rateadas proporcionalmente e marcadas como agregadas. Dados ausentes permanecem sem ritmo/tempo.
5. Revisão assistida chama o inicializador de formulário de teste; a opção manter/observar registra decisão sem mexer nas zonas.
6. Estratégia de prova exportada pelo fluxo nativo Pace Coach `UserWorkoutJson`, com aquecimento, etapas com alvo sustentado por evidência e desaquecimento.
7. Exportação semanal usa o padrão `S{semana}_T{treino}_{Título}`, sem data, compartilhado entre preview/JSON/anexo.
8. Atalho de exportação ausente do perfil; exportação permanece no treino e na estratégia de prova.

## Validações executadas
- Compilação Kotlin/JVM dos arquivos de domínio, excluindo Activity Android/Compose e classes dependentes do Android: concluída.
- Harness integrado de domínio: **12 assertions aprovadas**, abrangendo faixas de recuperação Z1/Z2, F01, remoção de sufixo numérico, distribuição de intensidade, GPX irregular de 6,62 km, GPX sem timestamps, nomenclatura e exportação de estratégia.
- Revisão estática dos metadados: `versionCode 80`, `versionName V80`, motor 70, schema 4.

## Correção adicional do resumo de parciais
- A lista compacta de parciais agora termina no primeiro trecho sem cobertura contínua, evitando mostrar uma parcial residual posterior como se fosse parte de uma sequência completa de quilômetros. O detalhe expandido ainda preserva o trecho residual quando há dados válidos.
- Quando um quilômetro é formado por mais de uma volta explícita, a origem é marcada como `EXPLICIT_LAP_AGGREGATED`, mesmo que nenhuma volta individual tenha sido cortada.

## Pendente
A suíte JUnit oficial e a compilação Android/Compose completa não foram executadas aqui: o ambiente não contém Gradle CLI/Wrapper nem Android SDK. Execute no GitHub Actions:
- `:app:testDebugUnitTest`
- `:app:assembleDebug`
- Confirme o artefato `ai-running-coach-debug-apk`.

Não considerar o APK aprovado antes dessas tarefas concluírem com sucesso.
