# Relatório de correção V86 — Recuperação do Fartlek

## Causa
A V80 havia trocado as recuperações Fartlek para Z1 90–100%. A V84 acrescentou uma regra que convertia qualquer recuperação ativa em caminhada caso não existisse interseção exata com o pace do desaquecimento. A combinação tornou a recuperação do F01 excessivamente lenta e, em alguns casos, caminhada. Além disso, o builder inferia os minutos da recuperação a partir da distância estimada, podendo gerar 3 min apesar do protocolo de referência indicar 2 min.

## Correções
1. F01/F02/F04 agora recuperam com trote leve Z2, faixa individual 20–65%.
2. F01 recebe `recoveryDurationMinutes = 2`; a pausa entre variações não depende da distância estimada.
3. `ACTIVE_Z2` não precisa intersectar exatamente o desaquecimento para permanecer ativo. A política estrita permanece para recuperações Z1 de protocolos que a especificam.
4. Migração dos planos não concluídos atualiza recuperações legadas Z1 e restaura segmentos `WALK` que a V84 criou automaticamente. O reconhecimento cobre tanto a mensagem do print (“não é compatível com o desaquecimento”) quanto o texto literal do fallback do motor V84 (“não possui uma faixa ativa Z1 compatível”). Caminhadas intencionais e pausas passivas são preservadas.
5. Treinos concluídos e feedbacks históricos não são alterados.
6. `CURRENT_ENGINE_VERSION` sobe para 75, solicitando atualização dos planos anteriores pelo fluxo normal.

## Exemplo de referência
- Recuperação anterior no Pace Coach: 2 min, 7:50–8:18 min/km.
- Regra V86: 2 min em Z2 20–65%, calculada pela calibração individual. A faixa numérica varia conforme as zonas do atleta; não é fixada em 7:50–8:18 para todos.

## Critérios de validação
- F01 gera recuperações de 2 min entre blocos, sem recuperação extra no final.
- As recuperações têm `recoveryMode=ACTIVE_Z2`, zona Z2 e faixa 20–65%.
- F04 recupera em Z2 sem liberar Z4/Z5 fora dos gates de elegibilidade.
- Sessão V84 com `WALK` automático por incompatibilidade é migrada; caminhada deliberada não é.
- Segunda migração não produz novas alterações. Sessões concluídas permanecem idênticas.


## Verificação local desta entrega
- Compilado isoladamente o `ZoneIntensityBandEngine.kt` com stubs de domínio e executado harness de regressão. Resultado: aprovado para migração Z1 legada, restauração de WALK automático V84, 2 min F01, alvo Z2 calculado 7:51–8:18 no exemplo de zona 7:30–8:30, preservação de caminhada intencional, sessões concluídas, idempotência e sem gate de interseção exata com desaquecimento.
- Os testes JUnit no projeto foram atualizados para conferir também o pace calculado e a preservação de caminhada intencional. A execução Gradle/Android oficial ainda depende do GitHub Actions.
