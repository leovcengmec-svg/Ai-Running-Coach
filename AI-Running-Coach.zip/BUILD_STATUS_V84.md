# BUILD STATUS — AI Running Coach V84

## Identificação
- Base: V83.
- `versionCode`: 84
- `versionName`: V84
- `CURRENT_ENGINE_VERSION`: 74
- Backup Schema: 4 (mantido; leitor de schemas 1–4 preservado).

## Correção da recuperação
- `ZoneIntensityBandEngine.apply(PrescribedWorkout)` e `apply(Workout)` agora chamam a validação de compatibilidade da recuperação com o desaquecimento da própria sessão.
- A compatibilidade é avaliada pelos limites numéricos reais em segundos/km, e não por percentuais locais de zonas diferentes.
- Quando não existe sobreposição, ou não existe faixa numérica confiável de desaquecimento, a sessão passa a instruir caminhada e remove pace/zona da recuperação. A dose temporal e a estimativa de distância são preservadas.
- A regra alcança bandas legadas explícitas como Z1 0–50%.
- Na leitura de dados locais/backups, somente sessões ainda não concluídas são normalizadas. Treinos concluídos e registros de feedback permanecem imutáveis.
- O motor foi elevado para 74 para sinalizar necessidade de revisão/recalculo dos planos antigos.

## Correção da entrada de datas
- Criado `SmartDateOutlinedTextField`, que mantém `TextFieldValue` interno e atualiza explicitamente `selection=TextRange(formatted.length)` após cada aplicação da máscara.
- Aplicado aos campos de nascimento, data do Cooper, perfil e data de provas.
- Teclado numérico solicitado para evitar o layout alfanumérico quando o campo espera somente data.

## Testes adicionados
- Recuperação Z1 legada com pace 8:50–9:31 e desaquecimento Z2 7:57–8:10 deve ser convertida para caminhada sem pace.
- Recuperação Z1 permanece ativa se sua faixa numérica se sobrepõe à faixa do desaquecimento.
- A conversão para caminhada é idempotente.
- A máscara de data mantém o cursor ao final em datas parciais e completas.

## Validação executada e pendente
- Harness Kotlin/JVM focalizado compilou o `ZoneIntensityBandEngine.kt` real com modelos temporários e passou nos cenários: incompatibilidade Z1/Z2 -> caminhada, idempotência, compatibilidade com sobreposição e preservação de treino concluído.
- Harness de data compilou `SmartInputMask.kt` e `SmartDateOutlinedTextField.kt` contra stubs de API Compose e confirmou o cursor no final para data parcial e completa. Isso não substitui a compilação com as bibliotecas Compose reais.
- Foram adicionados 4 testes JUnit ao projeto (3 de recuperação/migração e 1 de cursor).
- Este ambiente não contém Gradle Wrapper nem Android SDK; `:app:testDebugUnitTest` e `:app:assembleDebug` precisam ser executados no GitHub Actions.
- Não declarar APK aprovado até o CI concluir ambas as tarefas.
