# Catálogo de KM-base e influência da prioridade — V75

## Regra principal
A meta define a categoria de entrada quando os campos de média das quatro semanas e maior percurso recente são deixados vazios. Quando dados reais são preenchidos, eles substituem a referência correspondente. Valores zero digitados não são convertidos silenciosamente em valores padrão.

| Distância/meta | Base semanal | Teto de construção | Capacidade contínua anterior | Frequência ref. |
|---|---:|---:|---:|---:|
| 1,61 km | 8 | 15 | 0,8 | 2 |
| 3 km | 8 | 16 | 1,6 | 3 |
| 5 km | 12 | 22,5 | 3 | 3 |
| 10 km | 15 | 27,5 | 5 | 4 |
| 15 km | 25 | 43 | 10 | 4 |
| 16,1 km | 25 | 43 | 10 | 4 |
| 20 km | 28 | 48 | 16,1 | 4 |
| 21,1 km | 30 | 51 | 16,1 | 4 |
| 25 km | 35 | 60 | 21,1 | 4 |
| 30 km | 40 | 70 | 21,1 | 4 |
| 42,2 km | 45 | 80 | 21,1 | 4 |
| 50 km | 55 | 100 | 42,2 | 5 |
| 100 km | 75 | 140 | 50 | 5 |
| 160,9 km | 90 | 160 | 100 | 6 |

Valores em km/semana, exceto capacidade contínua, que é distância de corrida concluída. Parâmetros internos do produto; não são limites médicos universais. A saúde utiliza catálogo separado: 8 km base, 16 km teto e 2 dias/semana.

## Presunção de capacidade prévia
- 5 km pressupõe 3 km contínuos.
- 10 km pressupõe 5 km contínuos.
- 15 km e 10 milhas pressupõem 10 km contínuos.
- 20 km e meia maratona pressupõem 16,1 km contínuos.
- 25 km e 30 km pressupõem 21,1 km contínuos.
- Maratona pressupõe 21,1 km contínuos.
- Ultramaratonas partem da maior distância anterior indicada na tabela.

## Modalidade de corrida
Corrida/caminhada é uma rota de adaptação, não uma alternativa genérica para quem possui VO₂máx baixo ou não importou GPX. O cadastro habilita a rota somente para um iniciante verdadeiro com meta até 5,5 km, experiência de até seis meses, declaração explícita de zero km semanal e zero maior percurso, e sem evidência de conclusão contínua de 5 km. O motor repete a trava na camada de geração: se `longestRecentKm >= 5.0`, `runWalkEligible` não habilita esse formato.

## Efeito das prioridades

| Prioridade | Longão | Rodagens | Qualidade |
|---|---|---|---|
| Completar | Contínuo Z2, estável | Aeróbias fáceis | Só quando elegível; volume e tolerância têm precedência |
| Correr continuamente | Progressivo/regressivo alternado | Construção de corrida sustentada, sem pausas planejadas | Qualidade aeróbia pode ser contínua quando apropriada |
| Recorde pessoal | Progressão e final controlado quando pronto | Acelerações/strides e progressão cíclica | Limiar/intervalos conforme volume, teste e recuperação |
| Tempo definido | Alterna regressivo/progressivo em direção à exigência da meta | Progressões orientadas ao ritmo específico | Blocos de ritmo-alvo quando compatíveis com testes e capacidade |

As prioridades também têm frações próprias de distribuição entre longão, qualidade e demais rodagens. Se a qualidade não estiver liberada, o motor mantém a assinatura de prioridade nas sessões aeróbias e no longão, sem liberar Z4/Z5 artificialmente.

## Recálculo do cadastro
A assinatura do plano inclui objetivo, prioridade, tempo-alvo, recorde, nível, frequência, dias, terreno, experiência, método/valores de teste, média semanal, maior percurso e duração do ciclo. Mudanças marcam o plano como desatualizado. Ao recalcular, só sessões futuras são regeneradas; concluídas, histórico, feedbacks e avaliações são preservados.
