# Relatório de validação — V89

**Data:** 23/11/2026  
**Base:** V88  
**Pacote:** VersionCode 89 • VersionName V89 • Engine 78  
**Backup:** Schema 4

## Validação executada localmente

O harness Kotlin/JVM focalizado foi recompilado a partir dos motores de domínio ativos e executado com sucesso. Resultado:

`PASS: adaptive 28d review, 2-3% step, 5% cap, median 2% threshold, Z4/Z5 locks, continuous bands, week-8 retest window, pace recovery/exclusion and 42d average`

Coberturas verificadas pelo harness:

- Revisão bloqueada antes de 28 dias.
- Propostas separadas para Z1–Z3 com limiar mediano de 2% e limite de até 3% por revisão.
- Limite acumulado de 5% e bloqueio de novas mudanças até teste válido.
- Z4/Z5 inalteradas e fronteiras em ordem/continuidade.
- Janela preferencial do reteste no dia 49 e referência de oito semanas no dia 56.
- Recuperação de pace ausente quando há duração e distância e contabilização da exclusão quando não há dados suficientes.
- Critério de amostra e média semanal de 42 dias.

Foram adicionados testes JUnit de domínio em `AdaptiveZoneCalibrationEngineTest`, `PerformanceMonitoringEngineTest` e `TrainingLoadEngineTest`, além de atualização dos testes de backup. A cobertura JUnit foi adicionada ao projeto, mas a suíte Gradle completa não foi executada neste ambiente.

## O que não foi certificado nesta edição

- Não foi executado `:app:testDebugUnitTest`.
- Não foi executado `:app:assembleDebug` nem `:app:assembleRelease`.
- Não foi gerado APK nesta sessão.

A limitação é ambiental: o pacote não contém Gradle Wrapper e o ambiente de edição não disponibiliza Gradle CLI nem Android SDK. O workflow `.github/workflows/android.yml` já executa `:app:testDebugUnitTest` e `:app:assembleDebug` com JDK 21, Gradle 9.6.0 e Android API 37. O status só deve ser considerado build aprovado depois de um run verde no GitHub Actions.

## Baseline V88

O relatório/documentação da V88 registrava 71/73 testes focados aprovados, com duas falhas de corrida/caminhada iniciante que também reproduziam na base V87. Esse resultado histórico não foi reexecutado como parte deste pacote; não é apresentado como aprovação da V89.
