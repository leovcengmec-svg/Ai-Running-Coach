# Auditoria técnica atualizada — AI Running Coach V81

**Pacote auditado:** `AI-Running-Coach.zip`  
**Identidade:** `versionCode 81`, `versionName V81`  
**Motor:** `CURRENT_ENGINE_VERSION = 72` (a auditoria inicial avaliou 71; a revisão de calendário/identidade o elevou para 72)  
**Backup:** schema 4, leitor declara schemas 1–4  
**Situação após correções:** motores de domínio alterados compilados isoladamente; 370 testes aprovados no harness local; build Android ainda não certificado.

## 1. Parecer executivo

A primeira auditoria identificou três problemas diretamente corrigíveis: uso incorreto de retorno anulável em teste, pace médio calculado com pausa passiva e expectativa de backup ainda fixada em V79. Também encontrou falhas de teste em cenários de prescrição e periodização que precisavam ser confrontadas com as regras atuais.

Esses itens foram tratados na própria V81. Além disso, foram corrigidos o uso de zonas Cooper calculadas na classificação de flags, a aplicação real da prontidão à dose semanal e a seleção determinística de F01/F04/I05.

**Resultado confirmado:** 370 testes aprovados e 0 falhas em 49 arquivos de teste incluídos no harness Kotlin/JVM; compilação Kotlin/JVM dos três motores de produção alterados concluída.

**Limite:** quatro arquivos de teste dependentes de Android/JSON ficaram fora do harness e não há Gradle CLI, wrapper nem Android SDK. Portanto, esta auditoria não certifica o build Compose/APK nem os fluxos reais em aparelho.

## 2. Escopo

O inventário original identificou 49 arquivos Kotlin de produção, 53 arquivos de teste e 17 rotas/telas Compose. A revisão cobriu motores de perfil e fisiologia, testes de campo, zonas Z1–Z5, prontidão e segurança, carga, prescrição, periodização, biblioteca, importação de atividades, análise de zonas, feedback por bloco, planejado versus realizado, competições, estratégia de prova, backup, exportação Pace Coach e a camada Compose.

Foram compilados os módulos de domínio compatíveis com JVM e os três motores alterados na correção. Os testes executados usaram harness Kotlin/JVM local; isso não equivale à execução de `testDebugUnitTest` via Gradle.

## 3. Falhas corrigidas

### V81-01 — teste Cooper com retorno anulável

**Arquivo:** `android/app/src/test/java/com/airunningcoach/app/PaceOnlyMethodologyV72Test.kt`  
**Correção:** resultado válido tratado por `requireNotNull`; entrada inválida verificada com `assertNull`.

### V81-02 — pace médio incluía pausa passiva

**Arquivo:** `android/app/src/main/java/com/airunningcoach/app/UnifiedPrescriptionCalculator.kt`  
**Correção:** separação entre duração total e tempo em movimento. Pausa passiva permanece na duração total e é excluída do pace médio. Sem tempo em movimento mensurável, nenhum pace é inferido a partir do tempo parado.

### V81-03 — versão errada no teste de backup

**Arquivo:** `android/app/src/test/java/com/airunningcoach/app/AppBackupCodecTest.kt`  
**Correção:** exportação nova espera `appVersion = V81`; fixture de compatibilidade passa a usar os metadados V78/schema 3. Teste não executado no harness local, pois depende de `org.json`/camada Android.

### V81-04 — prontidão não reduzia a dose efetivamente entregue

**Arquivo:** `android/app/src/main/java/com/airunningcoach/app/CoachEngine.kt`  
**Correção:** fator de prontidão aplicado ao alvo semanal entregue; `POOR` usa 0,72 e `YELLOW` 0,82. A qualidade permanece suprimida enquanto o alerta persistir; dor/segurança `RED` continua bloqueando a prescrição.

### V81-05 — flags não recebiam zonas Cooper ainda não persistidas

**Arquivo:** `android/app/src/main/java/com/airunningcoach/app/CoachEngine.kt`  
**Correção:** `buildFlags` recebe as zonas efetivamente resolvidas para o cálculo atual, em vez de depender apenas de `input.calibratedPaceZones`.

### V81-06 — seleção de formatos/protocolos precisava de critério reproduzível

**Arquivo:** `android/app/src/main/java/com/airunningcoach/app/TrainingPeriodizationEngine.kt`  
**Correção:** F01/F04 selecionados de forma determinística por intenção e disponibilidade conjunta dos dados de recuperação/fadiga; F04 não libera Z4 sem elegibilidade de limiar. A fase específica de 5 km usa I05 no ponto do ciclo que duplicava I07 do desenvolvimento.

### V81-07 — expectativas de teste divergentes das regras existentes

Foram alinhadas as expectativas dos testes de progressão com semanas regenerativas, sessões comparáveis, ritmo conservador de estratégia, distância exata de meia maratona, exigências de frequência e ausência de pace genérico sem calibração. Cenários de `CoachEngineTest` agora preenchem evidências necessárias para validar qualidade, volume e protocolo, em vez de testar atletas sem os requisitos e esperar estímulos que o gate corretamente bloqueia.

## 4. Resultado de execução

| Indicador | Resultado |
|---|---:|
| Arquivos de teste no projeto | 53 |
| Arquivos incluídos no harness | 49 |
| Testes executados | 370 |
| Aprovados | 370 |
| Falhas | 0 |

Quatro arquivos não executados por dependências Android/JSON:
`AppBackupCodecTest.kt`, `PaceCoachExporterTest.kt`, `PaceCoachJsonAttachmentTest.kt` e `RaceStrategyWorkoutExporterTest.kt`.

A compilação isolada de `CoachEngine.kt`, `TrainingPeriodizationEngine.kt` e `UnifiedPrescriptionCalculator.kt` foi bem-sucedida. Permanecem avisos de parâmetros/variáveis não utilizados em `CoachEngine`, sem falha de compilação no harness.

## 5. Matriz pós-correção dos sistemas

| Sistema | Evidência no código e testes locais | Estado pós-correção | Limite restante |
|---|---|---|---|
| Perfil, idade e experiência | Motores presentes e ligados ao estado do atleta | Implementação presente | Sem teste Compose/aparelho |
| Cooper, 3 km e pace | Calibração e testes de domínio; teste nullable corrigido | Testes locais executados | Testes oficiais Gradle pendentes |
| Zonas Z1–Z5 | Motores de calibração e bandas; flags agora recebem zonas resolvidas | Integração de domínio corrigida | Fluxo visual em Android pendente |
| Prontidão e segurança | Gates em CoachEngine; dose semanal ponderada por estado | Correção aplicada e testada | Feedback real/UX não instrumentado |
| Carga e adaptação | LoadPrescriptionEngine e adaptação usados na construção do plano | Testes de domínio aprovados | Testes de campo/aparelho pendentes |
| Prescrição e periodização | CoachEngine e TrainingPeriodizationEngine | 370 testes globais sem falhas | Build completo pendente |
| Biblioteca F01/F04 e intervalados | Seletor de protocolo e gates de Z4/VO₂; testes F01/F04 | Seleção e limites cobertos no domínio | Uso contínuo por vários ciclos em UI não testado |
| GPX/FIT/TCX | Importador e testes de domínio no projeto | Código presente; cenários locais executados dentro da bateria | Importação de arquivos reais em Android pendente |
| Parciais e zonas de atividade | ActivityZoneTimeEngine e PerformanceMonitoringEngine | Testes incluídos na bateria, sem falhas | UI/dispositivos reais pendentes |
| Feedback por bloco | WorkoutBlockFeedbackEngine e persistência observadas no código | Implementação presente | Gravar/editar feedback em aparelho não validado |
| Planejado versus realizado | PlannedVsRealizedEngine e tela Evolução | Implementação presente | UI/end-to-end pendente |
| Competições, taper e estratégia | RaceEventEngine, RaceDayGuideEngine, RaceStrategyEngine | Testes de domínio incluídos e aprovados | Fluxo Compose e exportação real pendentes |
| Backup/restauração | Codec com schema4, hash SHA-256 e merge seletivo; teste V81 atualizado | Código presente; teste de backup não executado | Restauração real e migração de backups precisam validar no Android |
| Exportação Pace Coach | Exportador comum para sessões e estratégia | Código presente | Quatro testes JSON/export fora do harness; importação no app receptor pendente |
| Interface Compose | 17 rotas identificadas no inventário | Código presente | Sem build/teste instrumentado nesta sessão |

## 6. Build Android e critérios de aceite

O ZIP não contém `gradlew`, e o ambiente não tem Gradle CLI nem Android SDK. A compilação isolada Kotlin/JVM não valida `MainActivity.kt`, Compose, Manifest, recursos Android nem a geração de APK.

Para encerrar a validação da V81, o GitHub Actions deve executar com sucesso:
1. `:app:testDebugUnitTest`;
2. `:app:assembleDebug`;
3. inspeção do artefato APK e das versões 81/72;
4. instalação em Android e validação de recálculo de plano, feedback, GPX, backup/restauração e exportação/importação Pace Coach.

## 7. Parecer final

**Falhas reproduzidas nesta auditoria: corrigidas no código e cobertas pelos testes executáveis.** A V81 permanece como V81, sem incremento de versão.

**Situação de entrega:** aprovada nos testes de domínio executados localmente (370/370); **não certificada como APK Android completo** até a execução de Gradle/GitHub Actions e testes reais no aparelho.


## 8. Revisão adicional aplicada — calendário, identidade e backup

A correção posterior aos prints do calendário e do importador foi aplicada ao mesmo pacote V81. A data 21/11/2026 com dias habituais seg/qua/sex agora ancora a primeira semana em 23/11/2026. Planos persistidos com a semana inicial realmente vazia recebem migração segura, enquanto sessões do próprio ciclo e seu histórico são preservados.

A identidade da sessão agora considera ciclo, data original e tipo. A mesclagem seletiva do backup não usa mais o `sessionId` relativo isoladamente. Registros históricos que colidem com uma sessão futura são remapeados como histórico `LEGACY-*`; sua data real não é usada como data planejada. Feedback com tipo divergente não conclui a sessão; feedback legado sem tipo só pode ser associado quando ID + data aponta para uma única sessão.

A proteção foi propagada para recalibração, reagendamento, análise planejado versus realizado, contagem de sessões na análise de zonas por bloco, substituição de sessões por provas e numeração de exportações.

**Validação focada desta revisão:** 25 verificações Kotlin/JVM passaram (0 falhas) nos motores reais de identidade, disponibilidade, migração e planejado versus realizado; um harness separado aprovou a distinção por tipo no motor de feedback por bloco. Os testes JUnit de `AppBackupCodecTest.kt` foram ampliados, mas não executados por ausência de Gradle/Android/`org.json`. A compilação Android/Compose e a restauração real continuam pendentes.

**Versões preservadas:** `versionCode = 81`, `versionName = V81`, Backup Schema 4; `CURRENT_ENGINE_VERSION = 72`.
