# Build Status — AI Running Coach V101

- VersionCode: 101
- VersionName: V101
- CURRENT_ENGINE_VERSION: 91
- Backup Schema: 14 (compatibilidade de leitura 1–14)
- Base: AI Running Coach V100
- Source set Android: `android/app/src/main/java/com/airunningcoach/app/`
- Pacote ZIP: `AI-Running-Coach.zip`

## Validação local

- Kotlin compiler: disponível (Kotlin/JVM).
- Harness focado dos módulos reais de calendário, protocolo, nomenclatura, exportador e periodização: **17 verificações PASS**.
- Verificações estáticas de integração/metadados: **16/16 PASS**.
- ZIP final: `ai_running_coach_v101/AI-Running-Coach.zip`; `unzip -t` sem erros; `versionCode=101`, `versionName=V101`, motor 91, Schema 14 e `appVersion=V101` conferidos dentro do próprio pacote.

## Build Android / JUnit

**Pendente de CI.** O ZIP de origem não contém `gradlew`/Gradle Wrapper e o ambiente não tem Gradle instalado nem Android SDK. Portanto, não foi possível executar:

```bash
gradle -p android :app:testDebugUnitTest :app:assembleDebug --no-daemon
```

O workflow `.github/workflows/android.yml` deve executar a suíte oficial JUnit e a compilação Debug. O APK só estará validado depois da conclusão bem-sucedida desse workflow e do teste real de compartilhamento/importação no Pace Coach.
