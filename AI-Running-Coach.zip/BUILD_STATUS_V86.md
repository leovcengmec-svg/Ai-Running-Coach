# Build Status — AI Running Coach V86

## Identificação
- Base: V85.
- `versionCode = 86`
- `versionName = V86`
- `CURRENT_ENGINE_VERSION = 75`
- Backup Schema 4; leitura de schemas 1–4 preservada.

## V86 — recuperação do Fartlek
- F01/F02/F04 utilizam trote leve em Z2 20–65% para recuperar entre variações. Z1 continua disponível para protocolos que a indiquem explicitamente, mas não é o padrão do Fartlek aeróbio.
- F01 usa 2 minutos explícitos por recuperação, de acordo com o treino de referência do Pace Coach; duração não depende da distância estimada.
- `ACTIVE_Z2` permanece corrida leve mesmo sem interseção numérica exata com o desaquecimento. A regra V84 foi limitada aos casos Z1 de protocolos de maior intensidade.
- A migração de sessões não concluídas restaura Fartleks legados em Z1 e estados `WALK` criados automaticamente pelas duas mensagens de incompatibilidade V84 conhecidas (texto do print e fallback literal do motor). Caminhadas deliberadas, pausas passivas, sessões concluídas e feedbacks históricos são preservados.
- A migração é idempotente.

## Testes e build
- Testes adicionados/atualizados em `CoachEngineTest` e `ZoneIntensityBandEngineTest`: F01 em Z2 20–65%, recuperação de 2 min, F04 em Z2, ausência de downgrade por falta de interseção exata, migração de Fartlek em Z1 e de WALK automático V84, idempotência e preservação de sessão concluída.
- Compilação isolada de `ZoneIntensityBandEngine.kt` com os modelos de domínio necessários: aprovada.
- Harness Kotlin/JVM focalizado: aprovado para migração de Z1 legada, restauração dos dois textos de WALK automático V84, recuperação F01 de 2 min, faixa Z2 7:51–8:18 no cenário Z2 7:30–8:30, preservação de caminhada intencional, preservação de sessão concluída, idempotência e ausência de exigência de interseção exata com o desaquecimento.
- Testes JUnit correspondentes adicionados/atualizados em `CoachEngineTest` e `ZoneIntensityBandEngineTest`; a suíte Gradle oficial ainda não foi executada neste ambiente.
- Uma tentativa de compilar todo o conjunto de fontes Kotlin fora do Gradle não é válida como build: faltam o modelo Android `Workout` (declarado em `MainActivity.kt`) e dependências `org.json`; esses erros são limitações do harness isolado, não resultado de `:app:compileDebugKotlin`.
- Build Android/Compose completo e `:app:testDebugUnitTest`/`:app:assembleDebug` dependem do GitHub Actions; não declarar APK aprovado antes do workflow.
