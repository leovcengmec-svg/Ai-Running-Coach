# AI Running Coach — Relatório de implementação V97

**Data:** 26/11/2026  
**Base:** V96  
**Versão:** V97 — `versionCode 97`, `versionName V97`  
**Motor:** 87  
**Backup Schema:** 12 (leitura de schemas 1–12)  
**Escopo:** feedback sem reconstrução involuntária, base declarada/medida, quatro semanas completas reconciliadas, distribuição do longão, piso de 5 km por sessão para objetivo de 5 km, provas e integridade do calendário.

## 1. Resultado executivo

O plano de correção da auditoria V96 foi implementado na fonte Android compilável do projeto, no módulo `android/app`. O pacote foi versionado como V97.

A alteração mais importante é a separação entre **salvar dados** e **reconstruir a prescrição**. Registrar um feedback comum não marca mais o plano inteiro como desatualizado nem dispara reconstrução da semana. A geração de um plano, quando solicitada por um fluxo explícito, preserva as sessões incompletas da semana atual; a primeira migração do motor V96 para V97 pode normalizar uma vez o calendário antigo para corrigir colisões, conservando os treinos já concluídos.

A base declarada continua sendo a fonte de prescrição até que o corredor confirme quatro semanas completas e autorize explicitamente a adoção de uma fotografia da carga medida. Essa fotografia fica persistida e continua válida depois da virada da janela móvel de segunda-feira.

Para o objetivo de 5 km, todas as sessões regulares completas em semanas normais têm piso de 5 km. O piso considera aquecimento, blocos de trabalho, recuperações e desaquecimento. Abaixo de 5 km só é permitido durante uma semana explicitamente Regenerativa ou enquanto o protocolo inicial caminhada/corrida estiver efetivamente ativo. O rótulo genérico “Iniciante” não libera a exceção.

O longão tem teto de 40% da carga semanal e deve superar a segunda maior sessão em pelo menos 0,8 km e 15% quando a combinação for viável. Em planos contínuos de 5 km, a diferença é obrigatória; se não houver uma solução válida, o motor bloqueia a geração e explica a incompatibilidade em vez de publicar um longão apenas 100–300 m maior. Para os demais perfis e para o protocolo inicial caminhada/corrida, a diferença forte é priorizada; se matematicamente inviável no limite seguro disponível, é aceita apenas a condição estrita de ser a maior sessão.

## 2. Alterações implementadas

### 2.1 Feedback e preservação da semana

- `saveFeedback()` grava conclusão, distância, duração, sensação, esforço, dor e dados importados.
- Feedback normal não marca `needsEngineRefresh` e não reconstrói o plano.
- A mensagem após o salvamento informa que a prescrição atual foi preservada.
- Calibração de ritmo pode manter uma pendência separada para revisão das zonas; isso não equivale a autorização para reconstruir toda a semana.
- Em uma revisão explícita de plano, sessões incompletas da semana em andamento são preservadas. Treinos concluídos e histórico continuam protegidos pelo merge de instâncias.
- Na primeira atualização do motor 86 para 87, o fluxo de atualização pode regenerar uma vez a semana atual para sanar defeitos herdados da V96, preservando as sessões concluídas. Isso é uma migração de versão, não um efeito do feedback.

### 2.2 Carga declarada e medida

- `TrainingLoadEngine` não marca como confiável um histórico com seis atividades em três semanas parciais.
- A confiabilidade exige confirmação explícita de quatro semanas completas e fechadas, com a data de encerramento correspondente.
- A média móvel de 28 dias e os indicadores de 30/42 dias permanecem descritivos.
- `RunnerLoadSourceResolver` mantém os valores declarados como fonte da prescrição, salvo adoção explícita.
- A confirmação salva a média das quatro semanas e o maior treino como um snapshot imutável.
- `MeasuredLoadAdoptionPolicy` valida o snapshot salvo, sem depender da janela móvel atual. A autorização pode ser feita depois da virada de segunda-feira sem invalidar uma confirmação anterior.
- A adoção passa a valer na segunda-feira do próximo bloco, não retroativamente.
- Alterar os campos declarados de volume semanal ou maior sessão invalida a confirmação/adoção anterior.

### 2.3 Distribuição do longão e objetivo de 5 km

Novo motor: `WeeklySessionDistributionEngine.kt`.

- Teto do longão: 40% do volume semanal planejado.
- Diferença de referência: pelo menos 0,8 km e 15% acima da segunda maior sessão, quando viável.
- O motor busca uma distribuição válida sem aumentar a quilometragem solicitada.
- Quando uma diferença forte puder ser alcançada com uma pequena redução explícita da carga planejada, ela é priorizada; a redução fica registrada na justificativa de cada sessão.
- Para o objetivo contínuo de 5 km em semana normal, o piso total é 5 km em cada sessão e a diferença forte do longão é obrigatória.
- Se volume, frequência, teto, progressão, limite individual e piso não permitirem uma distribuição válida, a geração falha com uma explicação. Não é publicada sessão regular de 4,4 km nem um longão apenas marginalmente maior.
- Exceções abaixo de 5 km: semana `RECOVERY`/Regenerativa ou protocolo inicial caminhada/corrida efetivamente ativo. O rótulo “Iniciante” não basta.
- O exemplo de 16 km em três dias resulta em **6 km + 5 km + 5 km**.

### 2.4 Provas e teto de 40% após substituição

- Prova preparatória curta não substitui automaticamente um longão maior.
- A sessão de qualidade ou outra sessão compatível recebe prioridade para substituição.
- Quando uma prova cai no mesmo dia de um longão maior, o motor pode deslocar o longão para o espaço da sessão substituída, preservando a data original para identidade/histórico.
- Se não houver espaço seguro, o longão é preservado e a agenda sinaliza o conflito; a validação final impede publicar duas atividades no mesmo dia.
- `TrainingCalendarIntegrityEngine` calcula o denominador semanal com treinos e provas. Assim, uma substituição que faça o longão exceder 40% do total combinado é bloqueada.

### 2.5 Integridade do calendário

A validação final é executada após geração, reagendamento manual, transformações por prova e merge de sessões. Ela rejeita:

- mais de uma sessão no mesmo dia;
- treino e prova na mesma data;
- número de compromissos acima da frequência configurada;
- mais de um longão principal na semana;
- longão acima de 40% do volume semanal incluindo provas;
- longão que não seja a maior sessão de corrida da semana.

Se a validação falhar, o plano anterior é preservado e a interface recebe uma explicação; a nova agenda inválida não é gravada como plano vigente.

### 2.6 Interface e backup

- Rótulos do perfil foram ajustados para separar carga declarada e medida.
- “Referências de entrada” foi substituído por “Requisitos para liberar a fase específica”.
- A tela mostra dados de 28/30 dias e as quatro semanas completas separadamente.
- O perfil permite confirmar a reconciliação e autorizar a adoção em ação separada.
- Backup Schema 12 persiste `loadHistoryConfirmedThroughIso`, `measuredLoadAdoptionEffectiveFromIso`, `measuredLoadAdoptionWeeklyKmText` e `measuredLoadAdoptionLongestKmText`.
- A leitura de backups dos schemas 1–11 permanece habilitada; os novos campos ausentes em backups antigos permanecem em estado conservador (sem confirmação/adoção).

## 3. Exemplo de distribuição para a situação reportada

Objetivo: 5 km; base de referência: 16 km/semana; frequência: 3 dias.

| Sessão | Distância | Participação |
|---|---:|---:|
| Longão | 6,0 km | 37,5% |
| Rodagem leve | 5,0 km | 31,25% |
| Qualidade completa | 5,0 km | 31,25% |
| **Total** | **16,0 km** | **100%** |

O total de 5 km da sessão de qualidade inclui aquecimento, blocos, recuperações e desaquecimento; não exige 5 km de estímulo intenso.

## 4. Testes de regressão

Foram executados **102 testes focados Kotlin/JVM**, sem falhas, incluindo:

- histórico parcial 2 + 3 + 1 não libera adoção da média medida;
- quatro semanas confirmadas e separação da carga declarada/medida;
- snapshot confirmado continua utilizável depois da virada da janela móvel;
- objetivo de 5 km: distribuição 6 + 5 + 5;
- sessão abaixo do piso bloqueada em semana normal;
- semana Regenerativa e caminhada/corrida mantêm suas exceções;
- longão limitado a 40% e diferença perceptível quando viável;
- longão curto não é aceito como substituto de sessão longa por prova;
- o denominador do teto de 40% inclui distância de prova;
- bloqueio de duplicidades, colisões e excesso de compromissos no calendário.

O detalhamento está em `TEST_REPORT_V97.md`.

## 5. Limites da validação

Este ambiente não possui Gradle, Gradle Wrapper no projeto nem Android SDK instalado. Por isso, **não foi possível executar a suíte oficial `:app:testDebugUnitTest`, compilar Compose/Android ou gerar o APK**. Os 102 testes aprovados pertencem ao harness Kotlin/JVM dos motores e casos de regressão focados; eles não substituem o build oficial.

O workflow `.github/workflows/android.yml` está incluído no pacote e executa no GitHub Actions:

```bash
gradle -p android :app:testDebugUnitTest :app:assembleDebug --no-daemon
```

A certificação Android final depende do resultado verde desse workflow. Também permanece necessário testar o APK instalado no aparelho Android 16, especialmente o feedback/reabertura e a restauração real de backup.

## 6. Arquivos principais alterados

- `android/app/build.gradle.kts`
- `android/app/src/main/java/com/airunningcoach/app/MainActivity.kt`
- `android/app/src/main/java/com/airunningcoach/app/AppBackupManager.kt`
- `android/app/src/main/java/com/airunningcoach/app/TrainingLoadEngine.kt`
- `android/app/src/main/java/com/airunningcoach/app/RunnerLoadSourceResolver.kt`
- `android/app/src/main/java/com/airunningcoach/app/MeasuredLoadAdoptionPolicy.kt`
- `android/app/src/main/java/com/airunningcoach/app/CoachEngine.kt`
- `android/app/src/main/java/com/airunningcoach/app/WeeklySessionDistributionEngine.kt`
- `android/app/src/main/java/com/airunningcoach/app/RacePlanningEngine.kt`
- `android/app/src/main/java/com/airunningcoach/app/TrainingCalendarIntegrityEngine.kt`
- testes correspondentes em `android/app/src/test/java/com/airunningcoach/app/`.

**Fonte compilada de referência:** o módulo Android usa o source set Gradle em `android/app/src/main/java/com/airunningcoach/app/`. Os arquivos Kotlin soltos na raiz do ZIP são snapshots históricos de versões anteriores e não integram o source set padrão do módulo Android.
