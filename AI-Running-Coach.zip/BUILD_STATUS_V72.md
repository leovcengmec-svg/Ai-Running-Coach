# Build e validação — V72

- `versionCode = 72`; `versionName = V72`; `CURRENT_ENGINE_VERSION = 57`.
- Backup Schema 3 mantido: a V72 não adiciona campos persistidos obrigatórios; exportação identifica `appVersion = V72`. Leitura dos schemas 1–3 permanece; backup V71/schema 3 continua compatível.
- Compilação Kotlin/JVM dos motores de domínio: concluída sem erros; apenas warnings não bloqueantes existentes.
- Harness de domínio: validou I07 como cinco repetições de 600 m (cada bloco no modo DISTANCE), quatro recuperações de 2 min, progressão caminhada/trote, caminhos de 5 km, protocolo-ponte RP15, calendário com data real e importação GPX que ignora FC. Validação ampliada: protocolos específicos selecionados para 5/10/15/21,1/42,2 km; prioridades Completar, Correr continuamente, Melhorar RP e Tempo-alvo alteram a escolha do estímulo; novos testes JUnit cobrem os protocolos tipados e essas seleções.
- Testes JUnit foram acrescentados/atualizados para dose e recuperação dos protocolos, caminhos de periodização, calendário, pace-only e importação sem FC. A execução completa da suíte ainda não foi realizada neste ambiente.
- Build Android/JUnit completo: depende de Gradle e Android SDK. Este ZIP não inclui Gradle Wrapper e o ambiente de edição não possui Gradle/SDK instalados; portanto, `:app:testDebugUnitTest`, `:app:assembleDebug` e `:app:assembleRelease` precisam ser verificados no GitHub Actions antes da aprovação final.
- Teste em aparelho e importação real no Pace Coach continuam necessários para validar GPS, calendário, exportação Garmin e experiência de execução.
