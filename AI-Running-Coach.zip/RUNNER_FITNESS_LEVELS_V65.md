# Perfil fisiológico e testes de campo — V65

## Objetivo

A classe fisiológica do corredor é calculada a partir do VO₂máx estimado por um teste de campo e de referências de aptidão cardiorrespiratória estratificadas por idade e referência fisiológica. Tempo praticando corrida, quilometragem semanal e consistência não mudam essa classe. Esses dados são usados separadamente para ajustar a tolerância, a dose, a recuperação e a progressão.

O resultado é uma estimativa de campo. Não substitui ergoespirometria, avaliação clínica ou limiares medidos em laboratório.

## Quatro níveis apresentados no aplicativo

| Classe no aplicativo | Agrupamento da referência publicada | Interpretação no produto |
|---|---|---|
| Iniciante | Low + Below Average; abaixo do percentil 50 | Faixa geral abaixo da mediana para idade/referência fisiológica |
| Intermediário | Above Average; percentis 50–74,9 | Faixa acima da mediana, ainda abaixo do início da faixa High |
| Performance | High; percentis 75–97,6 | Aptidão cardiorrespiratória alta na tabela de referência |
| Elite | Elite; percentil ≥97,7 | Faixa percentílica extrema da tabela, não equivalência automática a atleta profissional |

A tabela de origem é Mandsager et al., *Association of Cardiorespiratory Fitness With Long-term Mortality Among Adults Undergoing Exercise Treadmill Testing*, JAMA Network Open, 2018, Table 2. A tabela original contém cinco faixas (Low, Below Average, Above Average, High e Elite), usa METs e estratifica por idade e sexo. O aplicativo agrupa as duas faixas inferiores para apresentar quatro classes. 1 MET = 3,5 ml/kg/min.

## Limiares usados pelo motor

Cada célula abaixo mostra os três limiares do motor, em ml/kg/min, para Iniciante→Intermediário, Intermediário→Performance e Performance→Elite. Valores resultam da conversão dos limiares publicados em MET × 3,5.

| Idade | Masculino: Intermediário / Performance / Elite | Feminino: Intermediário / Performance / Elite |
|---|---:|---:|
| 18–19 | 45,5 / 49,0 / 57,1 | 38,9 / 45,5 / 52,5 |
| 20–29 | 42,0 / 48,0 / 55,0 | 35,0 / 40,3 / 50,1 |
| 30–39 | 39,2 / 45,5 / 52,5 | 32,9 / 38,2 / 48,0 |
| 40–49 | 38,5 / 43,8 / 51,5 | 31,5 / 36,4 / 46,6 |
| 50–59 | 35,0 / 39,9 / 49,0 | 28,4 / 35,0 / 45,5 |
| 60–69 | 29,8 / 35,0 / 45,5 | 24,5 / 29,8 / 38,9 |
| 70–79 | 24,5 / 29,8 / 40,3 | 21,0 / 24,5 / 35,0 |
| 80+ | 22,1 / 25,6 / 35,0 | 19,3 / 22,1 / 29,4 |

## Teste de Cooper — 12 minutos

Protocolo: cobrir a maior distância possível em 12 minutos em percurso plano, medido e seguro; registrar a distância total em quilômetros.

Equação clássica adotada:

`VO₂máx estimado = 22,351 × distância (km) − 11,288`

A estimativa depende de esforço adequado e medição precisa da distância. A literatura mostra que o erro pode variar conforme população e protocolo; por isso o aplicativo identifica o resultado como estimativa indireta.

## Teste de 3 km

Protocolo: completar 3.000 m em esforço forte e contínuo, em percurso plano, medido e seguro. Registrar o tempo em `mm:ss`.

Equações de Aandstad (2021), com velocidade média `X` em km/h:

- Homens: `VO₂máx estimado = 17,5 + 2,57 × X`
- Mulheres: `VO₂máx estimado = 14,6 + 2,48 × X`
- `X = 10.800 ÷ tempo total em segundos`

A amostra publicada incluiu 259 adultos de 18–39 anos (30 mulheres). O erro padrão de estimativa foi 3,3 ml/kg/min para homens e 2,6 ml/kg/min para mulheres. O aplicativo restringe a equação a 18–39 anos e classifica a confiança como moderada. As zonas de treino geradas pelo aplicativo convertem o VO₂ estimado em uma referência equivalente ao Cooper e são faixas operacionais estimadas, não zonas laboratoriais validadas pelo estudo.

## Metas liberadas por nível

- **Iniciante:** 3 km, 5 km e Saúde e qualidade de vida.
- **Intermediário:** milha, 3 km, 5 km, 10 km, 15 km, 10 milhas, 20 km, meia maratona e Saúde.
- **Performance:** todas as metas anteriores até maratona (incluindo 25 km e 30 km) e Saúde.
- **Elite:** catálogo completo, incluindo 50 km, 100 km e 100 milhas.

A disponibilidade da meta não significa que a carga atual já suporte sua preparação. O motor ainda exige volume, maior sessão recente, recuperação, frequência e progressão compatíveis. Uma meta longa pode exigir preparação prévia mesmo para classe Elite.

## Nível e tolerância são dimensões diferentes

- **Nível fisiológico:** determinado pela estimativa de VO₂máx e referência idade/sexo.
- **Experiência:** tempo de prática; apenas contexto, nunca rebaixa ou promove a classe.
- **Tolerância atual:** volume recente, maior sessão recente, regularidade real, feedback, dor e recuperação; define volume inicial e necessidade de corrida/caminhada.
- **Zonas:** quando há teste válido, a sessão ativa pode usar Z2 com pace individual também para classe Iniciante. Corrida/caminhada é acionada por baixa tolerância atual, não pelo nome da classe. Sem teste válido, o aplicativo não inventa pace e usa esforço percebido até calibrar.

## Referências

1. Mandsager K, et al. Association of Cardiorespiratory Fitness With Long-term Mortality Among Adults Undergoing Exercise Treadmill Testing. *JAMA Network Open*. 2018;1(6):e183605. DOI: 10.1001/jamanetworkopen.2018.3605. https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2707428
2. Aandstad A. Estimation of maximal oxygen uptake from the 3,000 m run in adult men and women. *Journal of Sports Sciences*. 2021;39(15):1746–1753. DOI: 10.1080/02640414.2021.1898106. https://pubmed.ncbi.nlm.nih.gov/33730971/
3. Cooper KH. A means of assessing maximal oxygen intake. *JAMA*. 1968;203(3):201–204. (Equação operacional do teste de 12 minutos.)
