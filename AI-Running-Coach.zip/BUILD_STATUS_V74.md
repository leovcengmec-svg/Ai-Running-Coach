# Build e validação — AI Running Coach V74

## Identificação
- `versionCode = 74`
- `versionName = V74`
- `CURRENT_ENGINE_VERSION = 61`
- Backup Schema 3; leitura de schemas 1–3 preservada.

## Verificações executadas nesta sessão
- Integridade do pacote-fonte de entrada V73 verificada antes da atualização.
- Harness funcional Kotlin/JVM já compilado no ambiente executado: 14 verificações passaram, 0 falhas. Inclui dose semanal e deload, prontidão preparatória para maratona, coerência entre base e maior corrida, influência das prioridades, recuperação parada/caminhada, preservação de volta FIT, classificação direcional de pace e distribuição de intensidade.
- O harness de smoke test foi executado com sucesso contra os artefatos Kotlin/JVM disponíveis.
- Não foi possível executar build Android/Compose nem a suíte JUnit/Gradle completa neste ambiente: Gradle Wrapper/CLI e Android SDK não estão disponíveis.
- Uma tentativa de compilação ampla sem dependências Android/JSON falhou por ausência dessas dependências; não deve ser interpretada como erro de código Kotlin. Portanto, compilação Android completa permanece não verificada.

## Matriz de aceitação para GitHub Actions e aparelho
1. `:app:testDebugUnitTest`
2. `:app:assembleDebug`
3. `:app:assembleRelease`
4. Instalar no Android 16 e validar onboarding, mudança de objetivo/prioridade, recálculo sem apagar sessões concluídas, intervalado com pausa parada/caminhada e importação de FIT com voltas + GPX sem voltas.

## Critérios funcionais cobertos pelo smoke test e pendentes de validação Android
- 42,2 km com base baixa permanece em preparação e apresenta requisitos de entrada.
- Maior corrida isolada incompatível com média semanal gera sinalização.
- Prioridades diferentes alteram os estímulos aeróbios permitidos durante a preparação.
- Deload de 25% não apaga a referência de construção.
- PASSIVE e WALK não recebem pace/distância fictícios.
- FIT Lap é preservado.
- Ritmo mais rápido em bloco de qualidade recebe classificação direcional, não falha genérica.
- Distribuição de intensidade é ponderada por tempo.
- Cards adaptáveis e detalhes recolhidos precisam de validação visual em aparelho.

## Limitações conhecidas
- FIT/TCX/GPX sem voltas estruturadas não podem garantir identificação perfeita dos blocos; a interface diferencia reconstrução estimada de voltas explícitas.
- O documento anexado é usado como referência interna de progressão, não como limiar médico ou regra universal.
- Frequência cardíaca não é usada pelo treinador; campos legados permanecem apenas para compatibilidade.
