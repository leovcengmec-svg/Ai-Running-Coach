# V94 — reteste integrado ao plano, alternativas reais e calendário

## Identificação

- Base: AI Running Coach V93 Build Fix.
- `versionCode = 94` · `versionName = V94`.
- `CURRENT_ENGINE_VERSION = 84`.
- Backup Schema 9; o importador continua aceitando schemas 1–8.

## Calendário

- Restaurado o título resumido da sessão nos quadrados do calendário mensal.
- Células mensais ampliadas para 94 dp, marcador de categoria ampliado para 27 dp e título com duas linhas.
- O calendário usa `workoutWithSelectedOption`, portanto categoria e título acompanham a opção efetivamente escolhida.

## Alternativas no dia do reteste

- O slot do reteste guarda um snapshot serializado da sessão original deslocada.
- Opção 1 restaura exatamente a sessão planejada para a semana, com tipo, objetivo, estímulo, blocos, doses e zonas originais.
- Opção 2 substitui a sessão por uma alternativa de menor exigência; quando o original é de qualidade, converte o bloco ativo para Z2 confortável e reduz a dose ativa em 15%, sem criar treino adicional nem exceder o volume do slot original.
- A sessão escolhida é refletida no calendário, agenda, plano e totais semanais.
- O cartão e o botão de registrar resultado do reteste só aparecem enquanto o slot continua sendo um reteste. Ao selecionar uma sessão substituta, o estado de reteste desaparece; voltar ao original restaura o estado de teste.
- O reteste oferece explicitamente Cooper de 12 minutos ou teste de 3 km. O método escolhido é passado ao editor de resultado; os dois protocolos permanecem distintos.

## Ciclo de reteste e adesão

- A revisão de evidências permanece em 28 dias (`CooperAssessmentEngine.REVIEW_INTERVAL_DAYS`).
- Quatro semanas completas são 28 dias; a primeira oportunidade de teste fica no dia 29, no primeiro treino de corrida programado dentro da semana seguinte.
- Depois de um teste válido, o próximo bloco de quatro semanas começa a partir da data desse teste; a sequência resultante é S1–S4, reteste S5, S6–S8, reteste S9.
- O slot substitui a primeira sessão elegível; não cria sessão nem volume extra.
- Elegibilidade: pelo menos quatro sessões programadas no bloco, presença em pelo menos três semanas ativas, mais sessões concluídas do que não realizadas e nenhum relato de dor no bloco. Sessões extras, provas e testes fisiológicos não contam como sessões de treino para a adesão.
- Quando a adesão não é suficiente ou há dor, o reteste é adiado; o plano mantém a referência fisiológica atual e segue com o treino original ou a opção leve. Não há reset da calibração acumulada até registrar um novo teste válido.
- Após o teste, o planejamento é recalculado usando o resultado e preservando sessões já concluídas e histórico.

## Persistência e compatibilidade

- O snapshot da sessão original é salvo junto ao objeto do treino e, portanto, dentro do backup JSON.
- A identidade da sessão e a data do slot permanecem estáveis; a reconciliação de adesão deduplica pela identidade do slot usando o tipo original do snapshot quando há um reteste substituindo a sessão.
- Schema 9 mantém leitura dos schemas anteriores 1–8.

## Validação

- Harness Kotlin/JVM focado compilado para `RetestCycleEngine.kt` e `WorkoutAlternativeEngine.kt`: PASS.
- Cenários executados no harness: adesão acima de 50%, empate, mais faltas que conclusões, relato de dor, histórico insuficiente, primeiro slot no dia 29, ciclo seguinte no dia 57, round-trip do snapshot e opção leve em Z2 com redução de distância: PASS.
- Atualização de testes JUnit para calendário +29 dias e novos testes `RetestCycleEngineTest` e `WorkoutAlternativeEngineTest` incluídos no pacote.
- A suíte JUnit/Gradle completa e `:app:assembleDebug` não foram executados neste ambiente: não há Gradle nem Android SDK instalados. O workflow `.github/workflows/android.yml` executa `:app:testDebugUnitTest` e `:app:assembleDebug`; a aprovação do APK depende do resultado verde no GitHub Actions.
