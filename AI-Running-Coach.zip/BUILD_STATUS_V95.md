# Build Status — AI Running Coach V95

- Base: AI Running Coach V94.
- `versionCode = 95`; `versionName = V95`.
- `CURRENT_ENGINE_VERSION = 85`.
- Backup Schema 10; leitura de schemas 1–9 mantida.
- Biblioteca revisada: regenerativo por experiência/consistência, bandas distintas para longões, progressão/regressão em 3 etapas quando a dose permite, strides individualizados e intervalos materializados bloco a bloco.
- Validação obrigatória na geração, auditoria do protocolo nomeado e gate antes da exportação Pace Coach.
- `durationSeconds` persistido em sessão/snapshot/backup e exportado como milissegundos no Pace Coach.
- Harness Kotlin/JVM de domínio: PASS em 188 sessões e cenários adicionais descritos em `TEST_REPORT_V95.md`.

## Ainda pendente
- Suíte JUnit/Gradle completa.
- Compilação Android/Compose.
- Geração e teste do APK.
- Smoke test de importação/execução em um dispositivo com Pace Coach.

Gradle e Android SDK não estão disponíveis neste ambiente; portanto, APK não está certificado nesta entrega.

## GitHub Actions
Workflow: `.github/workflows/android.yml`.

```bash
gradle -p android :app:testDebugUnitTest :app:assembleDebug --no-daemon
```

Considere a compilação aprovada somente quando o workflow `build-apk` terminar verde e publicar o artefato.
