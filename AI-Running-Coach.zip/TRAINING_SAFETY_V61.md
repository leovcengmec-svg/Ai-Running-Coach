# Segurança, carga e limitações — AI Running Coach V61

O motor combina carga externa (distância, duração, pace) e resposta interna/subjetiva (RPE, sensação, dor e recuperação). A carga real registrada é usada como referência; sessão planejada não conta como sessão tolerada.

- Dor relatada impede liberação automática de qualidade e pode bloquear uma nova prescrição de corrida segundo o estado de segurança existente.
- Cansaço/fadiga elevam a cautela e podem suprimir qualidade ou reduzir volume.
- Progressão de distância é limitada pela média recente e pela maior sessão efetivamente realizada.
- Recuperações de intervalados usam Z2 confortável; estímulos Z4/Z5 são condicionais a perfil e tolerância.
- Objetivo Saúde não injeta automaticamente sessões intensas.
- Subidas dependem de elevação/rota conhecida; pace plano não é aplicado automaticamente em aclive.
- Força é opcional e complementar; não é inserida automaticamente na frequência de corrida.

Os escores exibidos são heurísticas de treinamento, não diagnóstico médico. O aplicativo não mede sono, HRV, lactato, limiares laboratoriais ou VO₂máx diretamente. Z4/Z5 derivadas de campo devem ser tratadas como estimativas; pace não substitui RPE, respiração ou avaliação profissional.

O estudo de carga por sessão de 2025 (coorte observacional de corredores) sugere maior associação com lesões por sobrecarga quando uma sessão ultrapassa em mais de 10% a maior sessão dos 30 dias anteriores; isso não é limite universal, mas pode servir como alerta adicional. Estratégias de taper com redução progressiva de volume e manutenção da intensidade/frequência são referências para prova principal, não para toda competição preparatória.
