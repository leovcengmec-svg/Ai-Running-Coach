# Periodização — AI Running Coach V61

## Macrociclo
O motor trabalha com fases BASE, DEVELOPMENT, SPECIFIC e RECOVERY, com ciclos de 4 a 16 semanas. A fase orienta quais estímulos entram; não significa que todo atleta precise da mesma progressão temporal.

- BASE: regularidade, volume fácil e economia básica.
- DEVELOPMENT: introdução gradual de estímulos mistos/limiar quando elegíveis.
- SPECIFIC: sessões mais próximas das exigências da distância-alvo.
- RECOVERY: redução de volume e suspensão de qualidade quando a semana regenerativa ou os dados de recuperação indicam.

A semana regenerativa ocorre em blocos de quatro semanas. Os volumes são limitados pela referência semanal e pela maior sessão efetivamente tolerada, não por sessões futuras planejadas.

## Frequência semanal
A frequência definida no perfil (2–6 dias) é preservada. O número de dias não é reduzido apenas por nível; dose, corrida/caminhada, intensidade e elegibilidade mudam conforme tolerância. Uma sessão exigente só entra se houver espaço de recuperação antes do longão e volume/experiência suficientes.

## Seleção de intensidade
Guardrails atuais:
- Limiar estimado: perfil intermediário/avançado/elite, frequência ≥3, média semanal ≥16 km, maior corrida recente ≥8 km, zonas válidas, sem dor, recuperação ≥75 quando informada e fadiga <65 quando informada.
- VO₂ estimado: perfil avançado/elite, frequência ≥3, média semanal ≥24 km, maior corrida recente ≥10 km, zonas válidas, sem dor, recuperação ≥80 quando informada e fadiga <60 quando informada.
- Progressão Z3 de rodagem: perfil intermediário ou superior, volume ≥16 km/semana, maior corrida recente ≥8 km, zonas válidas, sem dor e sinais de recuperação adequados.
- Z3 em longão: avançado/elite, volume ≥25 km/semana, maior corrida recente ≥12 km, longão ≥8 km, sem dor, recuperação ≥75 e fadiga <65; Z3 ocupa no máximo 12% da parte principal.

Esses números são critérios conservadores de engenharia para limitar a liberação automática, não padrões científicos universais nem garantias de segurança.

## Distâncias-alvo
Milha, 3 km, 5 km, 10 km, 15 km, meia maratona, maratona, ultramaratona 50 km, saúde/qualidade de vida e distância customizada de 1–100 km. A escolha muda o tipo de estímulo e o teto de longão, mas a progressão ainda depende do histórico real do atleta.
