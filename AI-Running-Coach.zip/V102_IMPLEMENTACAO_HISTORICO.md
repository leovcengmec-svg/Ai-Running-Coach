# AI Running Coach V102 — relatório de implementação

## Base e versionamento

- Base: V101.
- VersionCode: 102.
- VersionName: V102.
- Motor interno: 92.
- Backup Schema: 14, sem migração de estrutura; leitura dos schemas 1–14 preservada.

## 1. Histórico reorganizado

`HistoryScreen` agora usa uma coluna estrutural fixa com três áreas superiores: título, filtro segmentado Todos/Semana/Mês/Ano e resumo compacto. Essas áreas não fazem parte da lista rolável. O conteúdo histórico utiliza `LazyColumn` com `weight(1f)` e chaves estáveis. A navegação inferior continua sob controle do shell principal do aplicativo.

A linha redundante “Sessões registradas” foi removida. Os grupos por data começam diretamente após o resumo. Ao mudar o período, a lista retorna ao início do novo conjunto; atualizações dos dados sem troca de período preservam a posição atual.

## 2. Cards compactos

Os cards recolhidos mostram modalidade/ícone, título, data/hora, status e as três medidas principais: distância real, duração e ritmo. Esforço, sensação, terreno, origem GPS, parciais, zonas, execução de blocos, dor e observações ficam dentro da expansão. O menu continua oferecendo as ações permitidas para o estado do registro.

Registros órfãos e removidos continuam visíveis em áreas próprias. Edição, vínculo, remoção, restauração e exclusão definitiva permanecem disponíveis. Sessões concluídas sem medição são exibidas sem usar valores planejados como se fossem dados realizados.

## 3. Preparação e filtragem

Foi criado `HistorySnapshotEngine.kt`. O motor constrói índices por `sessionId` e por vaga canônica de data planejada/tipo, resolve datas de atividade e prepara as listas ordenadas uma vez por mudança nas coleções de treinos/feedbacks. A preparação ocorre com `Dispatchers.Default` por meio de um produtor cancelável.

Quando o usuário seleciona Todos/Semana/Mês/Ano, a tela aplica apenas o filtro temporal sobre o snapshot preparado. A lista e o resumo recebem o mesmo resultado filtrado. O agrupamento por data é memoizado para o período atual.

As regras de segurança de vínculo permanecem conservadoras:

- correspondência exata considera ID, identidade planejada e compatibilidade de tipo;
- fallback de backup só vincula quando a vaga canônica identifica um único treino;
- ambiguidades permanecem na seção de registros sem vínculo;
- data realizada isolada não é usada como chave de vínculo;
- registros removidos não entram no resumo ativo;
- registros sem medição contam como sessão, mas não somam distância/duração.

## 4. Arquivos alterados/adicionados

- `android/app/src/main/java/com/airunningcoach/app/MainActivity.kt`
- `android/app/src/main/java/com/airunningcoach/app/HistorySnapshotEngine.kt` (novo)
- `android/app/src/test/java/com/airunningcoach/app/HistorySnapshotEngineTest.kt` (novo)
- `android/app/build.gradle.kts`
- `android/app/src/main/java/com/airunningcoach/app/AppBackupManager.kt`
- `android/app/src/test/java/com/airunningcoach/app/AppBackupCodecTest.kt`
- `CHANGELOG.md`, `PROJECT_STATUS.md`, `README.md`, `README_GITHUB_ANDROID.md`
- Documentação V102 e relatórios de validação.

## 5. Validação e limitações

O motor de snapshot e os testes focados passaram em harness Kotlin/JVM local: 7/7. As verificações estáticas da estrutura, ações, indexação e versionamento passaram: 28/28. A checagem de sintaxe isolada não apontou erros de sintaxe em `MainActivity.kt`.

Não foi possível executar Gradle/JUnit oficial, compilação Android/Compose, testes instrumentados ou APK neste ambiente, pois não há Gradle, wrapper ou Android SDK instalados. O GitHub Actions e o teste em aparelho continuam necessários para validar build, rolagem e fluidez reais.
