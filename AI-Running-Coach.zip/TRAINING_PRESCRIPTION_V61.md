# Motor de prescrição — AI Running Coach V61

## Modelo de sessão
Uma prescrição contém objetivo, estímulo, tipo, zona predominante, segmentos ordenados, pace ativo, RPE, dose por tempo/distância, repetições, recuperação, fase e justificativa. A interface, calendário e exportação consomem a mesma estrutura.

Cada segmento mantém zona, limites de pace completos, faixa ativa, dose e repetição. Os paces são ordenados em min/km (menor valor = mais rápido). O gerador não deve apresentar um segmento cuja zona do nome contradiga a zona operacional.

## Biblioteca integrada
- Regenerativo e corrida/caminhada.
- Rodagem fácil/contínua Z2.
- Progressivo e regressivo Z2, com Z3 opcional sob elegibilidade.
- Longão contínuo, progressivo ou regressivo, predominantemente Z2.
- Intervalado aeróbio Z2 e Z2–Z3.
- Intervalado misto Z3–Z4 e Z4–Z5.
- Piramidal Z3–Z5.
- Fartlek com intensidade e recuperação variáveis.
- Tempo/limiar estimado, resistência específica de maratona e ultradistância.
- Subidas permanecem condicionais a perfil de elevação/rota conhecida; strides são complemento técnico. Força é módulo opcional e não entra automaticamente na agenda de corrida.

## Recuperações e aquecimento
- Z1 é usada em aquecimento, desaquecimento, regenerativos e corrida/caminhada para iniciantes quando apropriado.
- Recuperações internas de blocos intervalados são Z2 0–20%, não a Z1 mais lenta.
- O aquecimento/desaquecimento usa Z1 80–100%, sempre orientado por conforto e sem obrigar o atleta a correr no limite rápido da banda.

## Integridade da prescrição
`TrainingPrescriptionAudit` valida:
1. Sessão com segmentos e estimativas de distância.
2. Soma dos segmentos considerando repetições.
3. Paces ordenados e contidos na zona-base.
4. Pace coerente com a faixa ativa.
5. Nome do segmento coerente com a zona indicada.
6. Recuperação sem uso acidental de Z3–Z5.

Doses por tempo podem exibir distância estimada. Doses por distância devem fechar com o total prescrito após arredondamento de décimos.
