# AI Running Coach — Relatório de implementação V99

**Versão:** V99 — `versionCode 99`, `versionName V99`  
**Motor interno:** 89  
**Base:** V98  
**Backup Schema:** 13 (mantido; leitura de schemas 1–13)

## Implementações

1. `TrainingCalendarIntegrityEngine.validate()` agora monta três conjuntos independentes: sessões concluídas/planejadas para carga, sessões futuras pendentes para conflito e datas futuras distintas para frequência.
2. Sessões com `done = true` não contam como compromisso futuro e não criam conflito de treino com prova pendente. Continuam preservadas na carga da semana quando há evidência integral.
3. Frequência conta dias distintos, não linhas; prova e treino no mesmo dia contam um dia, mas um conflito pendente continua gerando erro específico. Provas canceladas/concluídas são excluídas da frequência futura.
4. Semanas atuais parciais não calculam participação do longão sobre o saldo futuro se não houver evidência de todas as datas da frequência configurada. Se as datas esperadas estão representadas, sessões concluídas e futuras entram no cálculo integral.
5. Semanas futuras completas continuam bloqueadas quando longão >40%, ou quando não é maior que as demais sessões.
6. Erros de participação agora exibem a composição considerada (sessões, datas, estados e provas) e a meta semanal guardada no plano quando disponível. O qualificativo “incluindo provas” só aparece quando há prova planejada na semana.
7. `RaceEventEngine` calcula aviso de frequência por datas futuras distintas e ignora datas anteriores a hoje.
8. Versionamento atualizado para V99/motor 89; backup continua Schema 13 sem migração estrutural; `appVersion` no JSON de novos backups muda para V99.

9. Retestes fisiológicos futuros sem método definido continuam como compromisso de agenda, mas `distanceKm = 0.0` é tratado como placeholder válido, não como atividade inválida. Para o teto de 40%, o validador usa um limite conservador de até 5 km (máximo permitido no Cooper); se mesmo essa distância máxima não tornar o longão compatível, o bloqueio permanece com a participação mínima possível e o reteste identificado como “método a definir”. Se o limite máximo possível puder tornar a semana válida, a verificação percentual fica pendente até a escolha do protocolo. Quando Cooper/3 km for escolhido, a distância real passa a compor a carga.

## Arquivos principais

- `android/app/src/main/java/com/airunningcoach/app/TrainingCalendarIntegrityEngine.kt`
- `android/app/src/main/java/com/airunningcoach/app/RacePlanningEngine.kt`
- `android/app/src/main/java/com/airunningcoach/app/MainActivity.kt` (validação de reagendamento recebe `today` explicitamente)
- `android/app/src/main/java/com/airunningcoach/app/AppBackupManager.kt`
- `android/app/src/test/java/com/airunningcoach/app/TrainingCalendarIntegrityEngineTest.kt`
- `android/app/src/test/java/com/airunningcoach/app/AppBackupCodecTest.kt`
- `android/app/build.gradle.kts`

## Limite de diagnóstico

A composição final que originou 57,1% passa a ser mostrada na mensagem de bloqueio, incluindo o `weeklyTargetKm` persistido. Sem o arquivo JSON de backup que gerou a tela, não é possível afirmar qual sessão concreta estava ausente no caso original. A V99 evita aceitar a semana inválida e fornece o detalhe necessário para localizar a etapa que removeu/omitiu uma sessão.

**Status:** alterações aplicadas ao source set Android e pacote ZIP gerado. Harness focado passou. Compilação Gradle/JUnit e APK aguardam GitHub Actions; teste em aparelho não executado neste ambiente.
