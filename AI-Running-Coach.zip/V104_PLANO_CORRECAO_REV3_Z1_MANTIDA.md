# AI Running Coach — V104 · Plano consolidado R3

**Base:** V103 (`AI-Running-Coach.zip`)  
**Data:** 27/11/2026  
**Versão resultante:** V104 · `versionCode=104` · motor interno 94 · Backup Schema 16  
**Status:** plano aplicado ao código-fonte; build Android/JUnit oficial ainda depende do GitHub Actions.

## 1. Decisão de escopo — Z1 mantém seu lote independente

Esta revisão R3 prevalece sobre a proposta R2 que sugeria retirar Z1 das zonas de origem. A instrução explícita do usuário foi preservar o lote próprio da Z1; portanto, a V104 mantém Z1, Z2 e Z3 como origens independentes.

| Origem | Lote A | Lote B | Teto direto |
|---|---:|---:|---:|
| Z1 | até 3% | até 2% | 5% |
| Z2 | até 3% | até 2% | 5% |
| Z3 | até 3% | até 2% | 5% |

A propagação permanece em cascata:

- Z3 afeta Z3, Z2 e Z1.
- Z2 afeta Z2 e Z1.
- Z1 afeta somente Z1.

Tetos efetivos preservados: Z1=15%, Z2=10%, Z3=5%. Z4 e Z5 continuam ancoradas ao teste fisiológico.

A falta de evidências próprias de Z1 não bloqueia nem atrasa os créditos herdados de Z2/Z3. Contudo, se existirem evidências válidas de recuperação em Z1, elas continuam aptas a compor seu Lote A e Lote B próprios, respeitando os filtros de esforço, sensação, dor e tipo de sessão definidos no motor.

## 2. Correções aplicadas

### 2.1 Revisão periódica versus revisão complementar

A revisão periódica de 28 dias continua existindo para o Lote A e para o acompanhamento global. Depois que um Lote A é confirmado, o Lote B não espera mais 28 dias: assim que houver pelo menos cinco blocos válidos em pelo menos três sessões posteriores e distintas, com melhora mediana mínima de 2%, o motor gera proposta complementar de até 2%.

A data de revisão periódica continua visível, mas a interface agora a identifica explicitamente como periódica. Quando um Lote B está pronto, a tela explica que a data periódica futura não bloqueia a confirmação complementar.

Dispensar uma prévia insuficiente ou sem alteração não avança `lastReviewDateIso`; somente a aceitação de uma proposta confirmada avança a referência da última revisão aceita.

### 2.2 Livro-razão de evidências

Cada observação de bloco passa a ter `blockId` estável. A chave consumida é composta por zona de origem, sessão/data e ID do bloco. O motor:

- deduplica observações com a mesma chave antes de contar;
- seleciona cinco blocos em pelo menos três sessões distintas;
- registra as chaves efetivamente usadas e a última data incluída;
- exclui as chaves consumidas em avaliações posteriores;
- exige que o Lote B seja posterior ao marco temporal do lote anterior.

Para estados V103/Schema 15, os IDs de blocos consumidos não existem. A migração usa a data do último registro `APPLIED` da respectiva zona como corte conservador; se não houver esse registro, usa a última revisão gravada. Assim, evidências da data do lote antigo ou anteriores não são recicladas.

### 2.3 Reteste sincronizado com o calendário

A tela deixou de tratar `teste + 29 dias` como se fosse sempre uma data futura. Ela consulta a sessão futura real `PHYSIOLOGICAL_RETEST_4W` do plano:

- se houver uma sessão futura não concluída, mostra essa data;
- se não houver sessão futura e a primeira oportunidade já passou, mostra o estado em atraso e quantos dias se passaram;
- a primeira oportunidade histórica é mantida como informação de contexto, não como próxima data;
- quando o plano inserir um reteste futuro, essa sessão passa a ser a fonte exibida.

O ciclo continua contando 28 dias completos e abre a primeira oportunidade no dia seguinte (`+29`), sem alterar a regra temporal apenas para corrigir a apresentação.

### 2.4 Interface e histórico

A tela separa contribuição própria, efeito herdado e efeito total. Para cada zona de origem, apresenta o lote correspondente e o progresso real. O histórico guarda o resumo A/B, o número efetivo de blocos/sessões, as chaves consumidas e a data final das evidências.

A revisão complementar pronta recebe aviso explícito de que pode ser confirmada imediatamente, mesmo quando a próxima revisão periódica aparece no futuro.

## 3. Persistência e compatibilidade

O Backup Schema avança de 15 para 16 para persistir:

- `consumedEvidenceKeysByZone`;
- `evidenceThroughDateByZone`;
- `evidenceKeys`, `lotSummary` e `evidenceThroughDateIso` no histórico de cada auditoria.

A leitura de backups Schema 1–15 permanece aceita. Campos ausentes recebem valores padrão; para calibrações V103, o motor aplica o limite legado por data, sem apagar créditos confirmados.

## 4. Arquivos alterados

- `AdaptiveZoneCalibrationEngine.kt`: lotes rastreáveis, deduplicação, elegibilidade antecipada do Lote B, migração conservadora V103, revisão não postergada ao dispensar, apresentação temporal do reteste.
- `MainActivity.kt`: ID de bloco nas observações; persistência/restauração das chaves; progresso de lotes; distinção entre contribuição direta e herdada; reteste ligado à sessão futura real; aviso de confirmação imediata do Lote B.
- `AppBackupManager.kt`: Schema 16 e appVersion V104.
- `android/app/build.gradle.kts`: versionCode 104 e versionName V104.
- `AdaptiveZoneCalibrationEngineTest.kt`: cenários de Lote B antecipado, não reutilização, lote próprio da Z1, cascata e reteste vencido.
- `AppBackupCodecTest.kt`: expectativa de Schema 16 e leitura de Schema 14/15.

## 5. Critérios funcionais principais

1. Z1 mantém Lote A e Lote B próprios; não é removida da lista de zonas adaptativas.
2. Z1 continua recebendo créditos de Z2/Z3 mesmo sem evidência própria.
3. Z1 pode alcançar 5% próprios (3% + 2%) sem depender de créditos em Z2/Z3.
4. Z2 e Z3 também mantêm seus lotes próprios.
5. O Lote B pronto é avaliado antes da data da próxima revisão periódica.
6. Nenhum bloco consumido pode ser contado novamente.
7. A contribuição direta nunca excede 5% por zona de origem.
8. A cascata conserva os máximos efetivos Z1=15%, Z2=10%, Z3=5%.
9. Reteste vencido não aparece como próximo evento futuro.
10. Backups V103/Schema 15 preservam créditos e não reutilizam evidência antiga sem ID.

## 6. Validação e limites da entrega

A fonte real do `AdaptiveZoneCalibrationEngine.kt` foi compilada com `kotlinc` e executada em harness local com quatro verificações integradas. A classe de teste `AdaptiveZoneCalibrationEngineTest.kt` foi compilada/executada com shim JUnit local e stubs mínimos para os modelos e funções fisiológicas externos: 22/22 métodos passaram. Esses resultados validam o motor e os cenários focalizados, mas não substituem a suíte JUnit Gradle real nem a integração Android/Compose.

O ambiente desta sessão não possui Gradle, Gradle Wrapper nem Android SDK. Portanto, `:app:testDebugUnitTest`, `:app:assembleDebug` e a geração de APK precisam ser confirmados pelo workflow `.github/workflows/android.yml`.
