# V91 — Correções da auditoria funcional da V90

**Base:** AI Running Coach V90 Build Fix  
**VersionCode:** 91  
**VersionName:** V91  
**Motor interno:** 80  
**Backup Schema:** 6 (leitura compatível com schemas 1–5)

## 1. Calendário e apresentação

- Legenda reorganizada em duas colunas de largura equivalente, sem truncar nomes, incluindo os estados de conclusão.
- Cada uma das oito categorias tem um glifo próprio: Regenerativo, Rodagem, Intervalado, Fartlek, Limiar/Qualidade, Longão, Prova e Teste.
- Competições exibem o símbolo da categoria Prova, em vez de um ponto genérico.
- Sessões pendentes (hoje e datas futuras) permanecem com cor integral; concluídas mostram ✓ verde; sessões passadas sem conclusão mostram × vermelho com marcador de categoria atenuado.

## 2. Backup e recálculo

- A escolha **Manter plano importado** encerra o aviso persistente, limpa `needsEngineRefresh` e registra `engineRefreshDeferredForPlan`.
- A decisão de adiar é persistida e incluída no backup Schema 6; backups antigos sem a chave usam o padrão `false`.
- O plano mantido não é falsamente marcado como atualizado: a versão original do motor é preservada até o recálculo real.
- A tela Backup mantém uma ação explícita **Atualizar plano com o motor atual**.
- A recalibração passou a usar um ponto de entrada transacional compartilhado com a Home. Em caso de falha, restaura sessões, âncora, duração do ciclo, metas, avisos, estado/decisão do treinador e navegação anteriores; mostra o erro e preserva o plano importado.
- Em caso de sucesso, somente sessões futuras são regeneradas; treinos concluídos, feedbacks, atividades e datas reais permanecem preservados.

## 3. Reteste Cooper e quilometragem semanal

- O reteste de 12 minutos usa como estimativa de distância o último resultado Cooper válido.
- O aquecimento de 12 min e o desaquecimento de 10 min são estimados pela faixa fácil individual Z2 0–20%, quando disponível.
- A quilometragem planejada da sessão é a soma de aquecimento + distância de teste estimada + desaquecimento, contabilizada uma única vez no volume planejado.
- O protocolo permanece marcado como estimativa planejada; a distância realmente realizada continua vindo somente do registro real da atividade/feedback.
- Sem faixa Z2 individual válida, a estimativa é parcial e não inventa pace/distância para os blocos ausentes.
- O teste de 3 km mantém 3 km como distância principal e utiliza a mesma estimativa individual de aquecimento/desaquecimento.

## 4. Biblioteca e faixas de intensidade

- O bloco **Preparação em Z2** passa a usar 20–40% da Z2 individual, distinto do aquecimento experiente em 0–20%.
- `TrainingPrescriptionAudit` verifica preparações identificadas na biblioteca: a faixa deve ser 20–40% e não pode repetir a faixa do aquecimento.
- A auditoria existente de protocolos continua cobrindo consistência de zonas, progressões e recuperações Fartlek. Os testes de geração de planos por objetivos executam a validação para as sessões geradas.

## 5. Evolução e métricas

- Removido da interface o card **Contadores do período**. Os dados necessários aos cálculos permanecem no modelo de domínio.
- A média semanal dos últimos 28 dias é exibida como total válido da janela dividido por quatro; a média de 42 dias é o total válido dividido por seis.
- As médias são descritivas e aparecem com histórico parcial. Os requisitos mínimos de confiabilidade continuam separados e permanecem como condição para decisões do motor de prescrição.
- Quando não há distância válida na janela, a interface informa que não existem registros no período.

## 6. Testes adicionados/atualizados

- Estimativa Cooper 12 min: soma do último resultado e aquecimento/desaquecimento individualizados; teste 3 km; ausência de zona e estimativa parcial.
- Calendário: oito glifos exclusivos, status passado/hoje/futuro e regras de opacidade.
- Carga: médias de 28/42 dias com histórico parcial, mantendo `reliable = false` quando não há amostra suficiente.
- Backup: Schema 6 e persistência da opção de adiar; compatibilidade Schema 1, 2, 3, 4 e 5.
- Prescrição: validação de preparação Z2 20–40% e diferença em relação ao aquecimento.

## 7. Limites de validação

Os harnesses Kotlin/JVM isolados para calendário, médias de carga e estimativa de reteste foram executados e passaram. A suíte JUnit completa e o build Android/Compose não foram executados neste ambiente por ausência de Gradle/Gradle Wrapper e Android SDK. A aprovação do APK depende do workflow `build-apk` no GitHub Actions (`:app:testDebugUnitTest` e `:app:assembleDebug`).
