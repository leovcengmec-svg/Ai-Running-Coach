# Compatibilidade de recuperação — V84

1. Percentual de intensidade é local à zona; 90–100% da Z1 não significa pace mais rápido que 0–20% da Z2.
2. Recuperação ativa entre blocos só permanece com alvo numérico quando sua faixa final de pace apresenta interseção com a faixa final do desaquecimento da mesma sessão.
3. Sem interseção, ou sem dados numéricos para comprovar a compatibilidade, converter para caminhada (`recoveryMode=WALK`) e remover pace/zona da recuperação. Não inventar um ritmo.
4. Preservar duração e distância estimada já registradas; não encurtar a pausa.
5. Pausa parada (`PASSIVE`) e caminhada (`WALK`) não recebem pace de corrida.
6. Aplicar tanto a sessões novas quanto à migração de sessões planejadas ainda não concluídas. Nunca reescrever sessões concluídas ou feedbacks originais.
7. A normalização deve ser idempotente.
