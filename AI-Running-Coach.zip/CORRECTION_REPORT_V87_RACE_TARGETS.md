# Relatório de correção — V87: estratégia de prova e prioridades

## Resumo

Atualização aplicada sobre a V86. O sistema deixa de descartar o tempo-alvo de provas C e deixa de tratar o tempo-alvo apenas como texto informativo. Prioridade e estratégia de execução agora são dimensões independentes.

## Alterações aplicadas

### Motor de estratégia
- Calcula o pace médio necessário a partir do tempo e distância registrados.
- Monta fases início/meio/final com ritmos ponderados pela distância.
- Mantém a projeção calculada próxima do tempo-alvo quando este é compatível com zonas/evidências.
- Não força metas aspiracionais: mantém a estratégia baseada nas evidências e mostra o objetivo como aspiracional.
- Aceita metas conservadoras sem acelerar artificialmente os blocos.
- Quando faltam dados, mostra a referência matemática e declara validação pendente.
- Preserva diferenças de condução entre A/B/C sem permitir que B/C alterem o macrociclo.

### Planejamento e interface
- Explica A/B/C no formulário.
- Ao salvar edição de uma competição, marca o plano como desatualizado e explica a necessidade de recálculo.
- Oferece botões de recálculo nas telas de competições e estratégia.
- Mantém o fluxo de preservação das sessões concluídas, feedbacks e histórico.

### Guia e exportação
- Guia de execução usa o tempo-alvo informado pela prova, mesmo que o objetivo global do perfil seja `COMPLETE` ou outra intenção.
- Pace Coach recebe pace e distância de cada trecho, inclusive quando a fase é rotulada `ALVO`.

## Exemplo principal

Prova de 5 km com tempo-alvo de 37:00:
- tempo total: 2.220 segundos;
- pace médio necessário: 444 segundos/km = 7:24 min/km;
- início/meio/final são calculados por distância e seus tempos são somados para a projeção, em vez de usar média simples de três paces.

## Validações executadas neste ambiente

- `RaceStrategyEngineTest`: **11/11** testes executados em harness Kotlin/JVM isolado.
- `RaceDayGuideEngineTest`: **3/3** testes executados em harness Kotlin/JVM isolado.
- Exportação de trechos B/C para Pace Coach: **2/2** verificações de fumaça passaram; a ponderação foi 443,96 e 444,00 s/km, respectivamente, para a meta de 444 s/km.
- Fonte do motor e testes espelhados entre a pasta raiz de referência e `android/app/src/...`: conferidos.
- Metadados V87: conferidos (`versionCode=87`, `versionName=V87`, `CURRENT_ENGINE_VERSION=76`, Backup Schema 4).

Os harnesses usam stubs para dependências Android/dados e validam os motores isoladamente. Não equivalem à execução da suíte Gradle completa.

## Pendente

Este ambiente não contém Gradle CLI/Wrapper nem Android SDK. Portanto, não foi possível executar `:app:testDebugUnitTest` nem `:app:assembleDebug`. A compilação Android/Compose, os testes JUnit completos, o JSON de exportação no receptor Pace Coach e a atualização de um backup real precisam ser confirmados pelo GitHub Actions e pelo aparelho.
