# Build fix — V90 Kotlin unresolved reference `rememberZoneBoundaries`

**Data:** 2026-11-23  
**Base:** AI Running Coach V90  
**VersionCode / VersionName:** 90 / V90  
**CURRENT_ENGINE_VERSION:** 79  

## Diagnóstico

O workflow `build-apk` falhou em `:app:compileDebugKotlin` porque quatro chamadas a
`rememberZoneBoundaries(...)` estavam presentes em
`android/app/src/main/java/com/airunningcoach/app/MainActivity.kt` (linhas reportadas 921,
1717, 1724 e 1908), mas a função havia ficado somente na cópia de referência
`MainActivity.kt` localizada na raiz do ZIP.

O estado `lastZoneBoundarySnapshot` e a lógica `ZoneCalibrationEngine.boundaryValues(...)`
já existiam na implementação Android; faltava apenas a função privada que conecta as
chamadas ao estado existente.

## Correção

Adicionada à classe `CoachState`, no `MainActivity.kt` Android, a função:

```kotlin
private fun rememberZoneBoundaries(zones: TrainingPaceZones?) {
    if (zones != null) lastZoneBoundarySnapshot = ZoneCalibrationEngine.boundaryValues(zones)
}
```

A função ignora `null` para não apagar o último snapshot válido e atualiza o snapshot somente
quando há zonas calculadas. As quatro chamadas existentes foram preservadas.

## Verificações

- Confirmada uma única definição da função no source set Android.
- Confirmadas as quatro chamadas no source set Android.
- Confirmada a existência do estado `lastZoneBoundarySnapshot` e do método
  `ZoneCalibrationEngine.boundaryValues`.
- ZIP validado estruturalmente após a correção.
- A compilação Gradle/Android ainda precisa ser executada no GitHub Actions: este ambiente
  não possui Gradle CLI/Wrapper nem Android SDK. Não declarar APK aprovado até o workflow verde.

Nenhuma alteração de lógica da V90, esquema de backup ou numeração de versão foi necessária.
