# Implementação V104 — AI Running Coach

**Base:** ZIP real da V103.  
**Build:** versionCode 104 / versionName V104.  
**Motor interno:** 94.  
**Backup Schema:** 16.

## O que foi aplicado

### Calibração adaptativa

- Mantidas Z1, Z2 e Z3 como fontes independentes de evidência.
- Z1 preserva seu próprio Lote A (até 3%) e Lote B (até 2%); não foi retirada como zona de origem.
- A propagação continua: Z3 → Z3/Z2/Z1; Z2 → Z2/Z1; Z1 → Z1.
- Limite direto por origem permanece 5%; limites efetivos permanecem Z1=15%, Z2=10%, Z3=5%.
- Após confirmar o Lote A, o Lote B pode gerar proposta assim que tiver cinco blocos válidos em três sessões posteriores e diferentes, sem aguardar outro intervalo de 28 dias.
- Blocos já aceitos são excluídos de avaliações posteriores; observações duplicadas pela mesma chave são deduplicadas.
- A chave consumida inclui zona, sessão/data e `blockKey`; o estado guarda IDs e data final de evidência por zona.
- Para V103, sem IDs históricos, usa-se como corte a data do último crédito `APPLIED` da zona, ou a última revisão quando não há auditoria disponível.
- Prévia insuficiente ou dispensada não altera a data da última revisão confirmada.

### Reteste

- A tela consulta a sessão futura real de reteste no calendário.
- Se não houver sessão futura e a primeira oportunidade estiver vencida, apresenta o atraso em dias e não mostra a data passada como próxima oportunidade.
- A regra de 29 dias desde o teste permanece, preservando quatro semanas completas antes da primeira oportunidade.

### Interface

- Mostra contribuição própria, efeito herdado e efeito efetivo por zona.
- Mostra progresso do Lote A e Lote B.
- Distingue a próxima revisão periódica de uma proposta complementar imediata de Lote B.
- O histórico registra o resumo A/B, os blocos efetivamente consumidos e a data final utilizada.

### Backup e versão

- `CURRENT_ENGINE_VERSION = 94`.
- `SCHEMA_VERSION = 16`.
- Backups 1–15 continuam legíveis; os campos novos são restaurados quando presentes e recebem default seguro quando ausentes.

## Validação focada

- Harness Kotlin/JVM com o motor real: 4/4 verificações integradas aprovadas.
- Classe real `AdaptiveZoneCalibrationEngineTest.kt`: 22/22 métodos passaram com shim JUnit local e stubs mínimos de domínio; a suíte oficial Gradle/JUnit ainda não foi executada.
- O teste de migração reproduz a tela: referência 11/10/2026, crédito anterior em 23/11/2026, data atual 27/11/2026 e novas evidências posteriores liberando Lote B antes de 21/12/2026.

## Observação sobre evidências legadas

O Schema 15 não guardava IDs de blocos consumidos. Para não reaproveitar os mesmos treinos, a V104 trata todos os registros da mesma data ou anteriores ao último crédito confirmado como já utilizados para fins do lote complementar. Isso pode deixar evidências antigas fora da nova contagem, mas preserva os créditos existentes e evita conceder novamente o mesmo ajuste.

## Situação

Código-fonte V104 e ZIP gerados. O motor foi compilado/executado localmente; build Android/Compose e JUnit Gradle oficial ainda dependem do GitHub Actions. Nenhum APK é declarado como produzido nesta sessão.
