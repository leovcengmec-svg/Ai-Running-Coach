# Training Intelligence 5.0 — especificação e implementação V74

## Princípio
O motor tem de separar a meta da capacidade atual. A distância futura não é um volume inicial implícito. O treinador classifica primeiro a etapa de preparação e só permite uma fase específica quando volume, longão, frequência, consistência, recuperação e coerência dos dados permitem.

## Referências do material do usuário
O documento anexado apresenta: zero→5 km com corrida/caminhada em três dias e aproximadamente 7 km semanais combinando trote e caminhada; 5→10 km com base inicial de 15–18 km/semana e longão de 6 km; 10→16 km com 25–30 km/semana e longão de 10–11 km; 10/16→21 km com 30–35 km/semana e longão de 12–14 km; 21→42 km com 45–50 km/semana e longão de 16–18 km, em cinco dias. O texto propõe ondas de três semanas de construção e uma semana de descarga de 20–30%, além de longão tipicamente em 30–40% do volume, exceto nos ciclos iniciantes. São referências do documento e do produto, não mínimos universais nem regra clínica.

## Decisão de prontidão
`TrainingPeriodizationEngine.goalSpecificReadiness` constrói o conjunto de requisitos para o objetivo. Enquanto faltar algum requisito, o estado permanece `PREPARATION` e a tela explica as referências faltantes. Para 42,2 km a referência aplicada é 45 km/semana, 16 km de maior sessão e frequência 5. Para o iniciante de zero a 5 km, usa-se 7 km semanais de corrida/caminhada e 3 dias, sem exigir 5 km contínuos como pré-condição.

A coerência da base é verificada de modo adicional: se a maior corrida recente representa mais de 65% da média semanal declarada, o motor sinaliza que uma corrida isolada não comprova capacidade de sustentar aquela média. Esse é um controle de qualidade de dados e planejamento, não uma previsão médica de lesão.

## Prioridade na fase preparatória
- Completar: base aeróbia constante e construção de tolerância.
- Correr continuamente: maior proporção contínua no longão/rodagem e protocolo CC01 quando elegível.
- Melhorar recorde pessoal: reserva maior do bloco para estímulos aeróbios estruturados, sem antecipar limiar/VO₂.
- Tempo-alvo: estímulos aeróbios graduais, ritmo-alvo informativo sem substituir zonas fisiológicas.

A diferença na organização semanal não revoga os bloqueios de intensidade. Limiar e VO₂ permanecem condicionados a critérios independentes de volume, frequência, consistência e recuperação.

## Volume e ondas de carga
`LoadPrescriptionEngine` ancora a primeira semana na dose atual declarada/medida. Quando o histórico está ausente, mas existe volume semanal positivo e corrida recente, a dose não é automaticamente reduzida pela metade. A progressão pode ser bloqueada por dor, recuperação, fadiga, RPE e aumento recente da carga. A cada quatro semanas, após três de construção, aplica-se descarga de 25% sobre a última referência de construção; a base de retomada não é apagada. A soma prescrita da semana é comparada ao alvo e qualquer diferença é explicitada.

## Estrutura de recuperação
O campo `WorkoutSegment.recoveryMode` identifica `PASSIVE`, `WALK`, `ACTIVE_Z1` ou `ACTIVE_Z2`. `PASSIVE` é somente duração; não aceita pace/distância/zona. `WALK` também não recebe pace de corrida. Recuperação ativa só permanece ativa quando uma faixa é compatível com a faixa de desaquecimento; se não, o motor muda para caminhada. A recuperação é aplicada apenas entre as repetições.

## Arquivos de atividade e blocos
- FIT message 19 (`Lap`) mantém início, tempo decorrido e distância de cada volta.
- TCX usa as estruturas de volta (`Lap`) existentes.
- GPX com extensão Pace Coach usa os marcadores de volta.
- Alinhamento exato exige igualdade entre quantidade de voltas e blocos prescritos expandidos, além de compatibilidade da dose individual (tempo ou distância) e da ordem. Igualdade de contagem, isoladamente, não comprova que cada volta seja um bloco; divergências resultam em resumo agregado sem atribuição fictícia.
- GPX reconstruído usa samples temporais; amostras esparsas (menos de três ou menos de 30 segundos) não são tratadas como separação confiável.

## Avaliação de pace
`MAIS_RAPIDO_QUE_META` identifica execução mais rápida que o previsto em bloco de qualidade. `ACIMA_DA_INTENSIDADE` sinaliza que um bloco de rodagem fácil excedeu a intensidade recomendada. `MAIS_LENTO_QUE_META` identifica ritmo abaixo da faixa prescrita. `SEM_DADOS` e `SEM_ALVO` não criam falsa precisão.

## Apresentação
A tela do plano mostra distribuição planejada por tempo dos segmentos da semana selecionada, comparando os percentuais estimados com a faixa orientativa da fase/nível/objetivo. Sem minutos/pace disponíveis, os percentuais ficam ocultos. Cards de perfil são dimensionados pelo conteúdo e detalhes de análise/histórico ficam recolhidos por padrão.

## Privacidade fisiológica
FC/FCM não são usadas em prescrição, calibragem, prontidão, progressão, zonas, carga ou análise de blocos. Campos legados permanecem apenas para compatibilidade de dados.

### Validação adicional de voltas explícitas
A análise não considera a contagem de voltas como prova suficiente de correspondência. Mesmo quando FIT/TCX/GPX trazem a mesma quantidade de voltas que os blocos, o alinhamento individual só ocorre se cada volta também corresponder à dose planejada (tolerância de 25% para duração ou 20%/50 m para distância). Se as doses não coincidirem, a tela apresenta apenas o resumo agregado das voltas, sem atribuição artificial. Segmentos GPS com amostragem espaçada podem representar até 1.000 m por intervalo temporal válido; ainda assim, blocos GPX esparsos não são alinhados individualmente sem amostras suficientes.
