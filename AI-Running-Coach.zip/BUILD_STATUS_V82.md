# BUILD STATUS — AI Running Coach V82

## Identificação
- Base: V81 corrigida (Pace Coach, motor de prescrição e correções da auditoria técnica).
- Pacote de entrega: `AI-Running-Coach.zip` (nome original preservado).
- `versionCode`: 82.
- `versionName`: V82.
- `CURRENT_ENGINE_VERSION`: 73.
- Backup Schema: 4; leitura dos schemas 1–4 preservada.

## Correções integradas nesta versão

### 1. Primeira semana treinável
- `TrainingScheduleEngine.firstTrainableWeekStart()` verifica os dias habituais restantes na semana atual.
- Quando todos já passaram, a próxima segunda-feira passa a ser a âncora da Semana 1. Se sábado/domingo ainda estiver selecionado, a semana atual permanece válida.
- `RacePlanningEngine.resolvePlanWindow()` recebe a âncora efetiva; `RunnerInput.startDate`, periodização, prova A, `planStartDateIso` e resumos derivam da mesma âncora.
- `PlanMigrationEngine.rebaseEmptyFirstWeek()` corrige uma única vez planos recentes com primeira semana vazia, sem deslocar uma semana que já contenha evidência do ciclo.

### 2. Identidade das sessões e backup seletivo
- `SessionIdentityEngine` cria ID determinístico com ciclo + data + tipo. Ciclos diferentes não compartilham ID relativo.
- `originalScheduledDateIso` e `workoutOriginalDateIso` são persistidos para preservar a identidade quando o atleta reagenda a sessão.
- `CompletedActivityBackupMerger` exige ID + data original + tipo compatível para concluir sessão local.
- IDs legados coincidentes em datas distintas são remapeados para `LEGACY-*`; o feedback correspondente recebe o mesmo ID remapeado.
- `realizedDateIso` representa somente a data real da atividade e não é usada para concluir uma sessão planejada.
- Feedback sem data suficiente não conclui sessão futura por inferência; fingerprint continua sendo critério de deduplicação de atividade.

## Testes e revisão
- Regressões adicionadas em `TrainingScheduleEngineTest.kt`, `PlanMigrationEngineTest.kt`, `PlanMigrationRescheduleTest.kt`, `SessionIdentityEngineTest.kt` e `AppBackupCodecTest.kt`.
- Harness independente executado nesta revisão: **6/6 verificações aprovadas**, cobrindo 21/11/2026, domingo disponível, primeira semana rotulada 1, identidade determinística e separação de feedback por data.
- O pacote de trabalho contém ainda 25 verificações isoladas de domínio registradas no relatório da revisão do patch; não são apresentadas como execução da suíte Gradle oficial.
- `unzip -t` executado no ZIP final: integridade do arquivo aprovada.

## Limitações / aprovação pendente
- Não há Gradle Wrapper, Gradle CLI ou Android SDK neste ambiente.
- `AppBackupCodecTest.kt` e os testes dependentes de `org.json`/Android foram adicionados/atualizados, mas não foram executados nesta sessão.
- Ainda é obrigatório executar `:app:testDebugUnitTest` e `:app:assembleDebug` no GitHub Actions.
- O backup real que reproduziu as capturas não foi anexado; a colisão foi coberta por fixture equivalente. A validação final deve importar uma cópia desse backup no Android e confirmar que 23/11 permanece Planejado.

**Status:** correções aplicadas e revisão de domínio concluída; APK Android e restauração real do backup ainda não certificados.
