# Relatório de testes — AI Running Coach V103

**Data:** 27/11/2026  
**Base:** V102  
**Versão:** V103 / motor 93 / Backup Schema 15

## Harness Kotlin/JVM — 16/16 PASS

O harness compilou e executou os arquivos reais `AdaptiveZoneCalibrationEngine.kt`, `PerformanceMonitoringEngine.kt` e `LoadPrescriptionEngine.kt`, usando somente modelos mínimos auxiliares para tipos de domínio que no aplicativo Android dependem de outras bibliotecas. Cenários verificados:

1. Lotes independentes A+B, com seis sessões distintas, podem propor 5% na mesma revisão.
2. Lote A sozinho respeita limite de até 3%.
3. Teste Cooper melhor em pelo menos 2% inicia uma nova fase e zera créditos ativos.
4. Teste equivalente preserva créditos.
5. Teste pior preserva créditos e ativa trava anti-reset.
6. Mudança Cooper/3 km segura os créditos antigos sem conversão automática.
7. Edição do registro de referência não simula novo teste e preserva créditos.
8. Protocolo anterior desconhecido com créditos existentes entra em estado seguro de espera.
9. Saldo abaixo de 2% é corretamente classificado como limite atingido, sem ajuste artificial.
10. Três sessões comparáveis mostram mediana preliminar sem percentual.
11. Longão não entra na amostra de rodagem.
12. Semana regenerativa padrão usa 25%.
13. Baixa execução/cautela isolada aumenta redução para 30%.
14. Dois sinais moderados simultâneos aumentam redução para 35%.
15. Recuperação muito baixa aumenta redução para 40%.
16. Semana de prova não soma o deload periódico ao taper.

## Testes JUnit incluídos no ZIP, ainda não executados pelo Gradle

- `AdaptiveZoneCalibrationEngineTest.kt`: dois lotes em uma revisão, classificação de teste, preservação em edição e créditos pendentes por protocolo.
- `PerformanceMonitoringEngineTest.kt`: prévia com três sessões e separação de longão.
- `LoadPrescriptionEngineV63Test.kt`: deload 25/30/40 e exceção em semana de competição.
- `AppBackupCodecTest.kt`: Schema 15, compatibilidade de backup V102/Schema 14 e schema anterior.

## O que ainda não foi validado nesta sessão

- Execução da suíte JUnit por `:app:testDebugUnitTest`.
- Compilação Android/Compose por `:app:assembleDebug`.
- Instalação e teste em aparelho Android 16.
- APK assinado/publicado.

O ambiente disponível não possui Gradle instalado, o ZIP não inclui Gradle Wrapper e não há Android SDK local. O build oficial deve ser confirmado pelo workflow `.github/workflows/android.yml`. Portanto, 16/16 significa apenas os cenários do harness local, não aprovação integral do aplicativo.
