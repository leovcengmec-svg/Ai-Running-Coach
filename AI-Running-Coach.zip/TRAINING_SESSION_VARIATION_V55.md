# V55 — variação de rodagem aeróbia e longão

## Distribuição semanal

A sessão mais leve deve aparecer primeiro, a sessão de qualidade deve ficar próxima ao meio da semana e o longão deve permanecer por último, respeitando o dia preferido e a recuperação. Em uma disponibilidade segunda/quarta/sexta com longão na sexta, a distribuição resultante é: segunda rodagem leve, quarta qualidade e sexta longão. Se não houver intervalo de recuperação suficiente, o motor pode omitir a qualidade em vez de comprimir sessões exigentes.

## Rodagem aeróbia

- Contínua Z2: opção simples e previsível.
- Progressiva Z1→Z2: início leve e bloco principal confortável.
- Regressiva Z2→Z1: começa confortável e termina mais leve.
- Semana regenerativa: Z1 e volume reduzido.

A rodagem fácil permanece em Z1/Z2 para não competir com a sessão de qualidade. Ela não recebe Z3 como padrão.

## Longão

- Contínuo Z2: mantém a maior parte da distância em esforço conversável.
- Progressivo Z1→Z2: inicia em Z1 e desenvolve o bloco principal em Z2.
- Regressivo Z2→Z1: bloco principal em Z2 e final mais leve em Z1.
- Progressivo avançado Z2→Z3: aquecimento em Z1, predominância Z2 e trecho final curto em Z3, somente se o atleta for Avançado/Elite, tiver pelo menos 25 km/semana, maior corrida recente de 12 km ou mais, longão prescrito de 8 km ou mais e zonas de pace individualizadas.

O bloco Z3 ocupa aproximadamente 15% do trecho principal, nunca substitui a maior parte em Z2 e não é habilitado apenas porque o corredor melhorou o pace em uma corrida comum. Para cargas menores, o treinador permanece em Z1/Z2. A semana regenerativa reduz o volume e mantém o longão contínuo em Z2 confortável.

## Ciclo de quatro semanas

1. Adaptação: rodagem e longão contínuos, predominantemente Z2 (com aquecimento/desaquecimento em Z1).
2. Consolidação: rodagem progressiva e longão progressivo.
3. Progressão: rodagem e longão regressivos.
4. Recuperação: redução de volume e estímulo aeróbio controlado.

A programação é contextual: tolerância recente, frequência, fase, recuperação e dor podem suspender ou simplificar as variações.

## Apresentação de semanas restauradas

A tela Plano conserva semanas anteriores ainda pertencentes ao ciclo e calcula qual semana está em andamento pela data atual em relação à âncora original. Assim, após recuperar um ciclo iniciado em 09/11, a semana 09–15/11 continua sendo a semana 1 e a semana 16–22/11 passa a ser identificada como semana 2 em andamento. O Dashboard resume a semana atual; a tela Plano abre essa semana por padrão, sem esconder a semana anterior.
