# Training Prescription Audit V63

## Fonte única de verdade
Cada sessão é composta por segmentos estruturados. Calendário, tela da sessão, exportação, histórico e distribuição de intensidade devem ler os mesmos segmentos.

Cada segmento contém, quando aplicável:
- Nome e instrução.
- Zona operacional Z1–Z5.
- Pace mínimo/máximo.
- Limites completos da zona.
- Percentual ativo dentro da zona.
- Distância ou duração.
- Repetições.
- RPE.
- Pace de meta secundário, se compatível com a zona.

## Validações
- Nome, zona e instrução não podem se contradizer.
- Pace deve pertencer à faixa permitida da zona.
- Faixa ativa deve estar contida na zona completa.
- Progressivo deve ter pace progressivamente mais rápido; regressivo, progressivamente mais lento.
- Recuperação deve ser compatível com o estímulo e não pode ser mais intensa sem justificativa.
- Recuperações de intervalados são aeróbias em Z2 confortável; Z1 permanece para aquecimento, desaquecimento e sessões regenerativas.
- A soma de segmentos por distância deve fechar a distância total prescrita, respeitando o arredondamento de apresentação.
- Segmentos por tempo podem mostrar distância estimada; não devem ser apresentados como distância real.
- Pace de meta é referência secundária e somente aparece quando está dentro da faixa completa de pace do segmento.
- Blocos de trail/subida não recebem pace plano como alvo quando o terreno não permite comparação.

## Limitações
A validação estrutural detecta contradições e soma de segmentos, mas não certifica que uma sessão é fisiologicamente ótima para todos os corredores. Elegibilidade, recuperação e objetivo ainda precisam ser considerados pelo motor e confirmados pelos dados do atleta.
