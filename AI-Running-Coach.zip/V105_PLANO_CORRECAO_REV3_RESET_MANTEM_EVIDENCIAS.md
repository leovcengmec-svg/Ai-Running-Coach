# Plano de Correção e Atualização V105 — AI Running Coach

**Base auditada:** AI Running Coach V104 (ZIP real entregue na conversa)

**Data da auditoria:** 28/11/2026

**Escopo:** Competições, estratégia de execução, exportação para Pace Coach, registro de resultado/feedback, volume semanal, análise de desempenho/zonas, recordes pessoais e consistência da tela de calibração adaptativa.

**Revisão do plano:** R3 — corrige a política de evidências após redefinição: o histórico elegível permanece disponível e pode ser reprocessado no novo ciclo; não há bloqueio por data do reset.

**Status:** Auditoria concluída. Plano de implementação proposto; nenhuma alteração de código foi aplicada nesta auditoria.

---

## 1. Parecer executivo

A V104 possui componentes úteis para planejamento de provas e processamento de atividades, mas eles ainda não estão conectados como um fluxo completo de competição.

Foram confirmadas cinco falhas funcionais e duas melhorias estruturais prioritárias:

1. A prova cadastrada não possui uma ação própria para registrar o resultado e o feedback pós-prova. O formulário existente de feedback depende de uma sessão de treino previamente selecionada.
2. O exportador para Pace Coach inclui aquecimento e desaquecimento como etapas do mesmo treino competitivo. Isso faz o arquivo representar mais do que a distância oficial da prova.
3. A estratégia tem três fases predefinidas, mas o atleta não consegue escolher o estilo de execução e recalcular a distribuição dos ritmos.
4. A tela de calibração pode dizer “Lote A confirmado” quando a contribuição própria da zona ainda é 0%. É uma divergência real entre estado matemático e texto apresentado.
5. Não existe uma área de recordes por distância. O perfil guarda apenas um campo de melhor tempo associado ao objetivo atual; isso não substitui um histórico com Top 3 por distância.
6. Falta uma ação explícita para redefinir a calibração adaptativa e restaurar Z1–Z5 às zonas-base calculadas pelo último teste fisiológico válido.

Também existe uma oportunidade importante: reutilizar o modelo de feedback/histórico que já alimenta a carga medida, em vez de criar um segundo sistema isolado para resultados de prova.

**Recomendação:** desenvolver uma atualização integrada V105, com versionCode 105, motor interno 95 e Backup Schema 17. Preservar os dados e as regras existentes da V104, incluindo a calibração própria de Z1, Z2 e Z3, a propagação em cascata, a compatibilidade de backup e acrescentar uma redefinição manual segura da calibração, com confirmação explícita e restauração das zonas-base do último teste fisiológico válido. O novo ciclo deverá reavaliar o histórico elegível completo, sem descartar treinos anteriores ao reset.

---

## 2. Evidências da inspeção da V104

### 2.1 Tela de estratégia e ausência de feedback direto

Arquivo: `android/app/src/main/java/com/airunningcoach/app/MainActivity.kt`

- `RaceStrategyScreen()` apresenta estratégia, projeção, orientações e compartilhamento JSON (aprox. linhas 5481–5627).
- A tela não apresenta botão para registrar o resultado da competição nem para abrir o feedback pós-prova.
- `FeedbackScreen()` começa por `state.selectedWorkout()` e constrói o formulário a partir de uma sessão de treino selecionada (aprox. linha 6519 em diante).
- O formulário de feedback possui um campo “Resultado de prova (opcional)” que permite vincular uma atividade a um `RaceEvent`, mas isso é uma associação dentro do feedback de um treino, não um fluxo autônomo iniciado pela prova.
- `saveFeedback()` exige que `selectedWorkout()` exista e que a sessão pertença à lista `workouts`. Assim, uma prova cadastrada sem uma sessão de treino correspondente não consegue ser concluída diretamente pela tela de estratégia.

Consequência: a competição pode ficar cadastrada como evento, mas o atleta precisa encontrar outro caminho para registrar a atividade real. Isso aumenta o risco de a prova não entrar no histórico, na carga semanal ou na análise de desempenho.

### 2.2 O modelo de prova não guarda a preferência de execução

Arquivo: `RacePlanningEngine.kt`.

`RaceEvent` armazena atualmente:

- `id`, `name`, `distanceKm`, `eventDateIso`;
- `priority` A/B/C;
- `targetTime`, `location`, `notes`;
- `status` PLANNED/COMPLETED/CANCELLED.

Não existe um campo para o estilo de execução escolhido pelo atleta.

A tela de cadastro/edição de competição também não apresenta essa escolha. `RaceStrategyScreen()` constrói a estratégia chamando `RaceStrategyEngine.build()` com a intenção geral do atleta, as zonas, os eventos e as evidências recentes.

Arquivo: `RaceStrategyEngine.kt`.

- `phaseSpecs()` determina três trechos conforme a distância.
- `buildTargetPhases()` aplica pequenos offsets calculados pelo sistema, segundo prioridade e objetivo geral.
- O atleta não escolhe diretamente ritmo constante, progressivo, regressivo, final forte, conservador ou agressivo controlado.

Portanto, o comportamento observado na imagem 1 é gerado pelo motor; não é uma opção configurável pelo corredor.

### 2.3 Exportação inclui aquecimento e desaquecimento

Arquivo: `RaceStrategyWorkoutExporter.kt`.

A função `build()` cria explicitamente:

- segmento “Aquecimento pré-prova”, com duração de 10 minutos;
- segmentos das fases competitivas;
- segmento “Desaquecimento pós-prova”, com duração de 5 minutos.

A lista de segmentos exportada é `listOf(warmup) + racePhases + cooldown`.

A própria `RaceStrategyScreen()` informa que o arquivo terá “etapas competitivas + aquecimento e desaquecimento”.

A imagem 2 confirma o efeito no Pace Coach: um treino de prova de 5 km chega com aquecimento de 10 minutos, três etapas competitivas de 1,0 km + 2,9 km + 1,1 km e desaquecimento de 5 minutos; o resumo mostra 6,24 km e 52:00 min. Isso não corresponde ao conteúdo que o atleta deseja executar como prova.

O teste atual `RaceStrategyWorkoutExporterTest.kt` também valida o comportamento incorreto: espera cinco segmentos e afirma que o primeiro é aquecimento e o último desaquecimento. Portanto, a correção precisa alterar o exportador **e** substituir essa expectativa no teste.

### 2.4 Dados existentes que podem sustentar o resultado da prova

Arquivo: `MainActivity.kt`.

O modelo `FeedbackRecord` já guarda:

- distância e duração reais;
- ritmo médio;
- esforço, sensação e dor;
- data real da atividade;
- terreno;
- `raceEventId`;
- fingerprint da atividade importada;
- arquivo de origem, parciais, segmentos de ritmo, rota e elevação;
- registro de ritmo executado em blocos.

O importador de atividades aceita GPX, FIT e TCX pelo fluxo de feedback.

Isso oferece uma base reaproveitável para registrar resultados de prova. A limitação atual é a dependência de um `Workout` selecionado para chamar `saveFeedback()`.

### 2.5 Como os quilômetros entram na carga semanal

A função `loggedActivitiesForLoad()` percorre `activeFeedbackRecords()` e cria `LoggedRunActivity` com a data real e a distância registrada. `trainingLoadSnapshot()` entrega essas atividades ao `TrainingLoadEngine`.

Logo, um resultado de prova salvo corretamente como registro real de atividade poderá entrar na carga semanal existente, sem criar contagem paralela.

A implementação deverá garantir:

- usar a data efetiva de realização, não a data em que o usuário digitou o resultado;
- contar a distância uma única vez;
- impedir que a mesma atividade importada seja vinculada a outra sessão/prova;
- não marcar aleatoriamente um treino planejado como concluído apenas porque uma prova foi registrada.

### 2.6 Como o resultado pode contribuir para análise fisiológica

A função `performanceTestObservations()` já identifica registros com `raceEventId` como prova/teste. `PhysiologicalProfileEngine.estimateCriticalSpeed()` utiliza esforços de prova/teste quando há dados válidos.

Na V104, essa estimativa exige, entre outros critérios:

- distância de 1,5 a 20 km;
- duração de 3 a 60 minutos;
- esforço percebido de pelo menos 7;
- ausência de dor;
- dados recentes, dentro de 90 dias;
- pelo menos três esforços e diversidade de distâncias/durações para formar o modelo.

O próprio motor esclarece que velocidade crítica é uma estimativa complementar de campo e não substitui nem altera automaticamente as cinco zonas.

Para distribuição de tempo por zonas, o aplicativo possui `measuredZoneTimeFromTrack()` e `estimatedZoneTimeFromSplits()`. Portanto:

- GPX/FIT/TCX ou parciais válidas podem permitir análise por zonas;
- somente distância e tempo total permitem calcular ritmo médio, mas não reconstruir honestamente quanto tempo foi gasto em cada zona.

A interface deve deixar essa diferença explícita e nunca inventar distribuição de zonas quando não houver parciais/segmentos.

**Ponto adicional:** `RaceStrategyEngine.build()` filtra esforços classificados como “Muito pesado”/“máximo” na coleção geral de evidências de ritmo. Um resultado de prova pode justamente ser um esforço máximo. A V105 deve separar evidência de treino confortável de resultado competitivo: um esforço máximo não deve contaminar referências de rodagem fácil, mas deve permanecer válido para recordes, comparação de provas e modelos de desempenho elegíveis.

### 2.7 Recordes pessoais: capacidade atual e lacuna

A V104 armazena `personalBestTimeText`, um único campo de tempo usado no perfil e na prescrição do objetivo atual. Não existe um catálogo de recordes por distância.

`CooperAssessmentRecord` mantém histórico de testes fisiológicos Cooper/3 km, mas não substitui recordes de competição por distância.

Na seção “Gerenciar perfil” existem ações para disponibilidade, cadastro, testes, zonas, competições, biblioteca, sessões concluídas e backup, mas não há uma ação “Recordes”.

Assim, não há estrutura para Top 3 de 1 km, 3 km, 5 km, 10 km, 15 km, meia-maratona, maratona ou distância personalizada; tampouco há uma ficha de recorde com data, prova, origem e detalhes da atividade.

### 2.8 Inconsistência na mensagem do Lote A de Z3

Arquivos:

- `AdaptiveZoneCalibrationEngine.kt`, na avaliação de progresso dos lotes;
- `MainActivity.kt`, na renderização dos cartões das zonas.

A causa está na lógica de progresso antes do vencimento da revisão periódica:

- o motor encontra um conjunto `lotA` com evidências suficientes;
- define `nextLot = "B"` porque o lote candidato A foi encontrado;
- a interface interpreta qualquer `nextLot == "B"` como “Lote A confirmado”.

O estado matemático de contribuição própria, entretanto, ainda pode ser 0% porque o Lote A ainda não foi aceito/aplicado.

Isso explica a imagem 4: Z3 exibe contribuição própria 0,0%, mas o rodapé diz “Lote A confirmado”. O motor está confundindo **lote elegível/pronto para revisão** com **crédito confirmado**.

A V105 deverá separar explicitamente os estados do lote: coletando, pronto para revisão, proposta apresentada, confirmado e concluído. Somente um crédito aplicado e persistido poderá ser chamado de confirmado.

A data “21/12/2026” é apresentada como “próxima revisão periódica (28 dias)”. Ela decorre de 23/11 + 28 dias. Na imagem, Z2 mostra Lote B com 5/5 blocos, mas apenas 2/3 sessões; portanto, o lote ainda não satisfaz o critério completo de três sessões. A tela deve distinguir melhor a revisão periódica da revisão complementar imediata, mas não deve declarar uma proposta pronta antes de atingir os critérios.

A Z1 permanece com lote próprio independente e recebe a propagação de Z2/Z3, conforme a decisão anterior do usuário. **Este plano não remove nem reduz o lote próprio da Z1.**


### 2.9 A data passada pode marcar a prova como concluída sem resultado

Arquivo: `MainActivity.kt`, função `saveRaceDraft()` (aprox. linhas 769–785).

A gravação/edição do evento deriva o status apenas da data: quando `eventDateIso` é anterior a `LocalDate.now()`, o evento recebe `COMPLETED`; caso contrário, recebe `PLANNED`. Essa regra confunde “a data da prova passou” com “o atleta registrou o resultado”.

Consequências: uma prova cadastrada retroativamente ou editada depois da data pode aparecer concluída mesmo sem distância realizada, tempo final ou atividade associada. Isso pode esconder justamente a ação de registrar resultado que está faltando. Também deixa o ciclo de vida do evento dependente da data do aparelho em vez de depender do registro real da competição.

A função `markRaceCompleted()` existe, mas a inspeção não encontrou chamada ativa no fluxo atual. A V105 deve centralizar a transição para concluída no salvamento de um resultado válido, não no salvamento do cadastro.

**Regra proposta:** a data controla a disponibilidade do botão de resultado e o rótulo exibido, mas não conclui a prova por si só. Um evento passado sem resultado permanece pendente e deve ser apresentado como “Aguardando resultado”. Só pode passar para `COMPLETED` quando existir um resultado associado com distância realizada e duração válidas. Evento cancelado continua `CANCELLED`. Se o resultado válido for removido, o status deve voltar a “Aguardando resultado”/pendente, salvo se houver outro resultado ativo associado à mesma prova.

---

## 3. Plano V105 — Fluxo completo de competição

### 3.1 Criar “Registrar resultado e feedback” diretamente na prova

Adicionar um botão na `RaceStrategyScreen()` que abre uma tela própria de resultado da competição.

A ação deverá aparecer quando a data da prova já tiver chegado ou passado e a competição não estiver cancelada. Antes da data, a tela permanece orientada à preparação; depois, passa a oferecer o registro do resultado. **A data passada não poderá marcar a prova como concluída automaticamente.** Uma prova retroativa ou editada depois da data deve permanecer pendente até que o usuário salve distância realizada e duração válidas.

O estado deve ser derivado de fatos persistidos: `PLANNED` enquanto a data não chegou e não há resultado; `AWAITING_RESULT` (estado de apresentação, ou enum explícito se necessário) quando a data passou sem resultado; `COMPLETED` somente com resultado válido associado; `CANCELLED` quando cancelada. Não reutilizar `COMPLETED` como sinônimo de “data passada”. Centralizar a transição de estado no salvamento do resultado e revisar `saveRaceDraft()`/`markRaceCompleted()` para que nenhuma rota de cadastro ou edição conclua uma prova sem resultado.

Campos propostos:

1. Distância realizada (km).
2. Tempo total (mm:ss ou hh:mm:ss).
3. Importar GPX/FIT/TCX.
4. Esforço percebido.
5. Sensação geral.
6. Dor durante ou após a prova.
7. Terreno.
8. Observações.
9. Data real, preenchida pelo timestamp importado ou pela data da prova, com possibilidade de correção.

O resultado importado deverá ser apresentado em prévia antes de salvar. Métricas ausentes no arquivo permanecerão ausentes; não serão estimadas silenciosamente.

### 3.2 Usar uma única fonte de verdade

Preferência de implementação: reutilizar `FeedbackRecord` como registro canônico da atividade competitiva, identificando-a pelo `raceEventId` e por uma identidade estável própria da prova.

A nova função `saveRaceResult()` deverá:

- funcionar sem exigir um `Workout` selecionado;
- criar ou atualizar um único resultado para a competição selecionada;
- preservar o fingerprint da atividade e bloquear arquivo duplicado;
- gravar distância, duração, ritmo, data real, esforço, sensação, dor, terreno, parciais, segmentos, rota e elevação quando disponíveis;
- marcar `RaceEvent.status = COMPLETED` somente quando o resultado tiver métricas mínimas válidas de distância e duração;
- permitir editar o mesmo resultado sem criar duplicatas;
- reverter o estado da prova para planejada se o resultado for removido e não existir outro registro ativo ligado à mesma prova;
- preservar o histórico e permitir restauração do registro excluído.

O vínculo com eventual sessão de treino do mesmo dia só deverá ocorrer quando a identidade da sessão corresponder de fato à competição. Não marcar treinos não relacionados como concluídos.

### 3.3 Painel de análise pós-prova

Após salvar, apresentar uma análise específica:

- resultado final e ritmo médio;
- tempo-alvo e diferença absoluta;
- ritmo planejado versus realizado por trecho, quando houver parciais;
- classificação de execução: constante, progressiva/negative split, regressiva/positive split ou queda de ritmo;
- sensação, esforço e dor;
- distribuição de tempo em Z1–Z5, somente quando houver dados temporizados suficientes;
- qualidade da evidência e dados ausentes;
- recomendação para o próximo bloco de treinos.

Se o arquivo não tiver parciais/segmentos, o painel deverá mostrar “Distribuição por zonas indisponível — arquivo contém apenas distância e tempo total”. Não inferir o tempo em cada zona a partir do ritmo médio.

### 3.4 Efeito na carga semanal e no histórico

O resultado deverá entrar no caminho atual de `activeFeedbackRecords()` → `loggedActivitiesForLoad()` → `TrainingLoadEngine`.

Regras:

- usar a data real de conclusão;
- contar os quilômetros uma única vez;
- não somar a distância planejada e a distância realizada como se fossem duas atividades;
- não alterar semanas anteriores quando o resultado for digitado depois;
- preservar a atividade importada ao editar esforço, sensação ou observações;
- exibir a competição no histórico com identificação clara de prova.

### 3.5 Uso do resultado para as zonas e a fisiologia

O resultado competitivo deve ser tratado como evidência real de desempenho, não como substituto automático de qualquer teste fisiológico.

A V105 deverá:

- comparar o ritmo da prova com as faixas atuais Z1–Z5;
- calcular tempo por zona quando houver segmentos/parciais confiáveis;
- enviar provas elegíveis ao fluxo complementar de velocidade crítica, obedecendo aos critérios do `PhysiologicalProfileEngine`;
- separar resultados de prova de sessões fáceis ao construir evidências de ritmo para a estratégia;
- mostrar quando um resultado sugere repetir Cooper/3 km ou revisar a referência fisiológica.

Não alterar Z1–Z5 automaticamente pelo resultado isolado de uma prova de 5 km, 10 km ou outra distância. Um resultado de 3 km só poderá ser promovido a referência do protocolo de 3 km se cumprir critérios objetivos de distância, duração, esforço, ausência de dor e qualidade do registro, e após confirmação explícita do atleta. Cooper de 12 minutos continuará sendo um protocolo próprio.

---

## 4. Estratégias de execução escolhidas pelo corredor

### 4.1 Opções propostas

Adicionar uma área “Como deseja executar a prova?” na tela de estratégia.

| Opção | Comportamento |
|---|---|
| Contínuo / ritmo constante | Distribui o esforço de maneira uniforme entre início, meio e final. |
| Progressivo | Começa de forma controlada, estabiliza no meio e aumenta gradualmente no final. |
| Regressivo | Começa mais rápido e reduz progressivamente o ritmo. Deve exibir alerta de maior risco de fadiga e ser limitado pelas evidências. |
| Final forte | Mantém ritmo controlado no início e meio; acelera apenas no trecho final se houver reserva demonstrada. |
| Conservador / reduzir ritmo | Usa o lado mais sustentável das faixas; deixa explícito que a projeção de tempo poderá ficar acima da meta cadastrada. |
| Agressivo controlado / buscar ritmo | Utiliza o lado mais rápido das faixas demonstradas, sem prescrever pace mais rápido que a capacidade sustentada pelas evidências. Se o alvo for aspiracional, a interface deve avisar e não forçar ritmos não validados. |
| Automático | O motor escolhe uma distribuição inicial conforme distância, prioridade, zonas, preparação e evidências; o atleta pode substituí-la. |

“Contínuo” é uma opção de distribuição do ritmo na prova; não deve ser confundido com a meta geral “correr continuamente” do perfil do atleta.

### 4.2 Como a escolha altera o plano

O estilo selecionado deve alterar os ritmos de cada trecho e as instruções correspondentes. A tela deve atualizar a prévia imediatamente e persistir a escolha na competição.

Para uma prova com tempo-alvo validável:

- **Contínuo:** as três fases têm faixas próximas do pace-alvo.
- **Progressivo:** o primeiro trecho é um pouco mais lento, o meio fica próximo do alvo e o final acelera de forma gradual.
- **Regressivo:** o primeiro trecho é mais rápido e os posteriores ficam mais lentos; mostrar explicitamente o risco de quebra e limitar a diferença entre fases.
- **Final forte:** início e meio estáveis; apenas a fase final recebe aceleração.
- **Conservador:** todos os trechos passam a usar uma referência mais sustentável; a nova projeção deve deixar de prometer o tempo-alvo original.
- **Agressivo controlado:** usa o limite rápido das faixas já demonstradas; nunca cria valores mais rápidos que Z5/zonas ou evidências permitidas.

O cálculo deverá considerar a distância de cada trecho, e não fazer média simples dos três paces. Quando existir tempo-alvo, a média ponderada pela distância deverá ficar coerente com o tempo-alvo, exceto nas opções que explicitamente reduzem ou aumentam a ambição.

Sem evidências ou zonas suficientes, o sistema não deverá inventar ritmos. Poderá apresentar uma estratégia por sensação/esforço, deixando os paces como indisponíveis.

### 4.3 Persistência

Adicionar ao `RaceEvent` um campo como `executionMode`, com default `AUTO` para eventos antigos.

A escolha deverá:

- ser salva ao editar a prova;
- sobreviver ao fechamento e reabertura do app;
- ser incluída no backup;
- ser preservada em migrações;
- atualizar estratégia, projeção, instruções e exportação de forma consistente.

Prioridade A/B/C continua controlando o ciclo de preparação; o modo de execução controla a distribuição da prova. Uma dimensão não deverá sobrescrever a outra.

---

## 5. Corrigir a exportação para Pace Coach

### 5.1 Contrato esperado

O JSON de estratégia competitiva deverá conter **somente a distância oficial da prova**.

Para uma prova de 5 km:

- três etapas competitivas, quando a estratégia tiver três fases;
- soma das distâncias igual a 5,00 km;
- somente blocos por distância;
- ritmo apenas quando validado;
- nenhuma etapa de aquecimento;
- nenhuma etapa de desaquecimento;
- nenhum acréscimo de quilometragem ou duração por preparação pré/pós-prova.

O aquecimento e o desaquecimento continuam no guia dentro do AI Running Coach, separados da sequência exportada como prova.

### 5.2 Alterações técnicas

Arquivo: `RaceStrategyWorkoutExporter.kt`.

- Remover os segmentos `warmup` e `cooldown` do método responsável pelo arquivo competitivo.
- Construir `segments` exclusivamente a partir de `strategy.phases`.
- Validar que a soma das distâncias dos segmentos corresponda a `event.distanceKm`, dentro de tolerância numérica pequena.
- Não incluir segmento temporal na exportação competitiva.
- Definir a duração total com base apenas na projeção competitiva, quando existir; não somar 15 minutos de aquecimento/desaquecimento ao resumo competitivo.
- Não inventar pace para fases sem faixa validada.
- Atualizar a descrição da interface para dizer “Somente distância e etapas competitivas da prova”.

### 5.3 Testes existentes que precisam mudar

O teste atual `RaceStrategyWorkoutExporterTest.kt` exige cinco etapas e afirma que as etapas inicial e final são aquecimento e desaquecimento. Essa expectativa deve ser substituída.

Novas asserções:

- número de etapas igual ao número de fases competitivas;
- soma das distâncias igual à distância da prova;
- nenhuma etapa `warmup` ou `cooldown`;
- todas as etapas com término por distância;
- ausência de alvo de pace quando a fase não for validada;
- coerência entre estilo selecionado e paces exportados.

---

## 6. Nova área de Recordes no Gerenciar Perfil

### 6.1 Tela proposta

Adicionar `ProfileAction("Recordes pessoais", ...)` em “Gerenciar perfil”.

A nova tela deverá organizar os melhores resultados por distância, mostrando três posições:

| Posição | Informação principal |
|---|---|
| 1º melhor tempo | Tempo, data, ritmo médio e origem |
| 2º melhor tempo | Tempo, data, ritmo médio e origem |
| 3º melhor tempo | Tempo, data, ritmo médio e origem |

Distâncias iniciais sugeridas:

- 800 m (opcional);
- 1 km;
- 1 milha (opcional);
- 3 km;
- 5 km;
- 10 km;
- 15 km;
- 21,1 km;
- 42,2 km;
- distância personalizada.

A interface pode agrupar distâncias mais longas ou não utilizadas para continuar compacta.

### 6.2 Detalhe de um recorde

Ao tocar em uma posição, abrir o detalhe:

- distância de referência;
- tempo registrado;
- ritmo médio;
- data;
- nome da prova, quando houver;
- local/terreno, quando disponíveis;
- origem (prova registrada, atividade importada ou histórico informado manualmente);
- parciais, percurso e elevação, quando existentes;
- ação para editar ou remover registro manual;
- navegação ao registro original do histórico quando o recorde vier de uma atividade do aplicativo.

### 6.3 Inserir recordes anteriores ao aplicativo

Adicionar botão “Adicionar recorde manual”.

Campos:

- distância;
- tempo total;
- data (ou opção explícita “data não informada” para marcas antigas);
- prova/local (opcional);
- observação (opcional).

O tempo deverá ser validado em mm:ss ou hh:mm:ss. Distância e tempo não poderão ser estimados automaticamente.

O campo antigo `personalBestTimeText` deve ser preservado. Na primeira abertura da nova área, oferecer a migração assistida desse tempo para o catálogo, usando a distância do objetivo atual apenas quando ela estiver definida e permitindo ao usuário confirmar. Se a data não existir, exibir “Data não informada”; não fabricar uma data histórica.

### 6.4 Fonte dos recordes e qualidade dos dados

- Resultados de prova vinculados e registros históricos manuais podem ocupar as posições de recorde.
- Atividades de treino podem alimentar “melhores atividades registradas”, mas a interface deve identificar claramente a origem.
- Só comparar marcas dentro da mesma distância/categoria.
- Não transformar automaticamente uma atividade de distância diferente em recorde oficial por projeção matemática.
- Quando a distância medida não corresponder suficientemente à distância oficial, manter o resultado no histórico ou como estimativa, sem classificá-lo como recorde oficial.
- Impedir duplicação pelo mesmo `recordId`, `raceEventId` ou fingerprint da atividade.

Preferência técnica: gerar o Top 3 a partir dos resultados de prova já existentes em `FeedbackRecord` e de uma lista pequena de entradas manuais `PersonalRecordEntry`. Isso evita duplicar toda a atividade em outro banco de dados.

---

## 7. Animação ao conquistar um recorde

É viável implementar com recursos nativos do Jetpack Compose, sem depender de uma biblioteca externa.

Quando um resultado salvo ocupar a primeira posição de uma distância e superar o recorde anterior, mostrar uma celebração curta:

- selo “NOVO RECORDE PESSOAL”;
- distância e novo tempo;
- marca anterior e diferença;
- data e nome da prova, quando existentes;
- animação visual breve de escala/entrada e partículas/confetes.

Regras importantes:

- disparar somente depois de o registro ser salvo com sucesso;
- disparar uma única vez por `recordId`;
- não repetir por recomposição da tela, retorno da navegação ou restauração de backup;
- não exibir celebração se a marca não superar o primeiro lugar;
- opcionalmente usar mensagem menor “Novo Top 3” para entrada em 2º ou 3º lugar;
- não incluir áudio ou vibração obrigatórios;
- respeitar acessibilidade e uma apresentação sem movimento excessivo.

A animação é uma apresentação do novo recorde; não deve bloquear o usuário nem atrasar a gravação dos dados.

---

## 8. Correção da inconsistência do Lote A na calibração

Manter integralmente a arquitetura da V104:

- Z1, Z2 e Z3 como origens independentes;
- Lote A próprio de até 3% em cada zona;
- Lote B próprio de até 2% em cada zona;
- propagação Z3 → Z2/Z1 e Z2 → Z1;
- efeitos máximos Z1=15%, Z2=10%, Z3=5%;
- confirmação manual;
- proteção contra reutilização de blocos.

Corrigir apenas a semântica do progresso:

1. `lotA != null` significa que há cinco blocos em pelo menos três sessões e que o candidato pode ser avaliado. Não prova que o crédito foi aplicado.
2. “Lote A confirmado” só pode ser mostrado quando a contribuição própria persistida for maior que zero e houver auditoria `APPLIED` correspondente.
3. Com contribuição 0%, mostrar “Lote A pronto para revisão” se o candidato estiver completo, ou “Lote A em coleta” se estiver incompleto.
4. “Lote B” só começa após o Lote A ser efetivamente aceito, usando evidências posteriores e distintas.
5. Separar estado de evidência, estado da proposta e estado do crédito aplicado na estrutura de progresso.
6. Não alterar os créditos de Z1, Z2 e Z3 apenas para corrigir os textos.

A data de 21/12/2026 deve continuar identificada como próxima revisão **periódica** quando for essa a data calculada. Se um lote complementar independente ficar completo antes, a interface deverá mostrar separadamente que existe uma revisão complementar disponível agora.


### 8.1 Botão “Redefinir calibração” — requisito funcional obrigatório

Adicionar um botão visível na tela **Calibração adaptativa**, na área de ações da própria calibração, com o rótulo **“Redefinir calibração”**. Não esconder a função dentro de “Ver regras”, de menus secundários ou de configurações genéricas.

A finalidade é permitir que o atleta descarte os ajustes adaptativos ativos e volte a utilizar as zonas fisiológicas originais calculadas pelo último teste fisiológico válido. O botão não deve apagar o teste que serve de referência nem os dados históricos usados para auditoria.

#### Comportamento ao tocar no botão

A ação deverá abrir um diálogo de confirmação com o texto principal exato:

**“Resetar a calibração?”**

Explicação sugerida no diálogo:

“Todas as contribuições adaptativas ativas de Z1, Z2 e Z3 e os efeitos propagados serão zerados. As zonas Z1–Z5 voltarão aos valores-base do último teste fisiológico válido. O histórico de testes, treinos, provas e calibrações será preservado. A atualização dos treinos futuros continuará sendo uma ação separada.”

Ações disponíveis, sem ambiguidade:

- **Não:** fecha o diálogo sem alterar qualquer dado.
- **Sim:** executa a redefinição de forma transacional e persistente.

Não executar o reset ao tocar no fundo do diálogo, ao pressionar “Voltar” ou ao reabrir a tela. A confirmação “Sim” é obrigatória.

#### O que “Sim” deverá redefinir

1. Recalcular/carregar as zonas-base Z1, Z2, Z3, Z4 e Z5 diretamente do último teste fisiológico válido selecionado como referência atual, usando o mesmo protocolo e a mesma metodologia de cálculo já adotados pelo motor fisiológico.
2. Aplicar essas zonas-base como zonas atuais, removendo todos os efeitos adaptativos ativos e propagados.
3. Zerar a contribuição própria ativa de Z1, Z2 e Z3: Lote A e Lote B, incluindo valores parciais que ainda não tenham sido confirmados.
4. Zerar os efeitos recebidos por propagação em cada zona. Depois do reset, o efeito adaptativo total deverá ser 0% em Z1, Z2 e Z3; Z4 e Z5 permanecem ancoradas ao teste, sem crédito adaptativo.
5. Abrir um novo ciclo de calibração e reprocessar todo o conjunto de atividades/feedbacks elegíveis que estiver disponível no histórico, independentemente de a data da corrida ser anterior ou posterior ao reset e independentemente de o feedback ter sido cadastrado novamente depois. O reset NÃO cria uma barreira temporal que descarte treinos anteriores. O motor recalcula os candidatos do Lote A e, depois, do Lote B usando os critérios originais, ordenação cronológica e sessões distintas. Os mesmos registros podem voltar a ser considerados em um novo ciclo porque o usuário zerou intencionalmente a calibração; dentro de cada ciclo, porém, uma mesma sessão/bloco não pode ser contada duas vezes nem aparecer nos dois lotes.
6. Registrar um evento de auditoria imutável com data/hora, teste fisiológico de referência, valores de zonas anteriores, valores-base restaurados, percentuais removidos por origem, identificador do novo ciclo e confirmação do usuário. Esse timestamp não será usado para excluir evidências.
7. Atualizar a interface e o estado persistido na mesma operação, evitando mostrar 0% enquanto as zonas continuam com valores adaptativos antigos, ou o inverso.

#### O que “Sim” NÃO deverá apagar ou alterar

- resultados e histórico dos testes Cooper e 3 km;
- atividades GPX/FIT/TCX, provas, feedbacks e recordes;
- histórico de calibrações anteriores e respectivos motivos;
- sessões de treino concluídas e carga semanal histórica;
- preferências do atleta, disponibilidade e objetivo de prova;
- dados originais do backup e referências necessárias para auditoria.

A operação também não deverá excluir nem invalidar evidências antigas. Todo o histórico elegível permanece disponível para o novo ciclo. A data/hora do reset é somente um marco de auditoria da ação, não um filtro de elegibilidade das atividades.

#### Política de evidências após o reset — revisão R3

A redefinição zera os ajustes adaptativos aplicados, não o histórico que comprova a evolução do corredor. Por isso, fica expressamente proibido usar a data/hora do reset como corte para excluir atividades antigas.

Após a confirmação, o motor deverá:

1. Criar um novo `calibrationCycleId` e manter o ciclo anterior no histórico de auditoria.
2. Limpar o ledger de evidências consumidas **somente para o novo ciclo**. Não apagar os IDs, fingerprints nem os vínculos de auditoria dos ciclos anteriores.
3. Recarregar o conjunto atual de atividades e feedbacks elegíveis, incluindo corridas realizadas antes do reset, registros importados antes do reset e feedbacks que forem recadastrados depois de uma limpeza/restauração do histórico.
4. Recalcular candidatos do Lote A e Lote B usando os mesmos requisitos técnicos de qualidade, comparabilidade, esforço controlado, ausência de dor incompatível, distância mínima e número de blocos/sessões. A data da atividade continua sendo relevante para ordenar cronologicamente as sessões e assegurar que o Lote B use sessões posteriores às do Lote A; ela não será comparada com a data do reset.
5. Dentro de cada novo ciclo, atribuir cada sessão/bloco a no máximo um lote. Uma atividade repetida por reimportação ou por novo feedback deve ser reconhecida pela identidade canônica/fingerprint e não poderá gerar crédito duplicado no mesmo ciclo.
6. Permitir que atividades do histórico voltem a sustentar uma nova proposta após o reset, porque o usuário solicitou reiniciar a calibração e deseja que o treinador reavalie os dados disponíveis. A proposta continuará sujeita à confirmação manual; o reset, por si só, não reaplica créditos.
7. Se o histórico completo já satisfizer os critérios, a tela poderá mostrar `0% aplicado — Lote A pronto para revisão` ou `Lote B pronto para revisão`, conforme a sequência e os estados efetivamente persistidos. Isso não é falha: significa que as zonas foram restauradas, mas há evidências antigas suficientes para uma nova proposta.

Se o usuário apagar todo o histórico e depois cadastrar/importar novamente os feedbacks, os registros recriados deverão participar normalmente do novo ciclo. A deduplicação deve impedir duplicatas no ciclo atual, não bloquear o uso de uma evidência só porque ela existiu num ciclo de calibração anterior.

#### Caso não exista teste fisiológico válido

Não restaurar zonas genéricas, defaults arbitrários ou zonas inferidas de um treino comum. O botão deverá ficar desabilitado ou, ao ser acionado, mostrar uma explicação: “Não existe teste fisiológico válido para restaurar as zonas originais. Registre um teste Cooper ou 3 km válido antes de redefinir a calibração.” Nenhum dado será alterado.

#### Relação com os treinos futuros

A redefinição das zonas atuais e a reescrita dos treinos já prescritos são operações distintas. O reset deverá atualizar as zonas usadas como referência daqui em diante, mas não modificar silenciosamente o conteúdo dos treinos futuros já salvos. Após o reset, disponibilizar uma ação separada e explícita para “Atualizar treinos futuros com as zonas redefinidas”, com prévia das sessões afetadas e confirmação do usuário.

#### Consistência, concorrência e falhas

- Executar a redefinição em transação única: zonas atuais, estado dos lotes, marco de evidências e evento de auditoria são gravados juntos.
- Se qualquer etapa falhar, reverter a operação inteira; nunca deixar zonas e percentuais em estados divergentes.
- Desabilitar temporariamente o botão enquanto a operação estiver em andamento para impedir toques duplicados.
- Após concluir, mostrar confirmação discreta com a data do reset e as zonas restauradas.
- Fazer com que o mesmo reset não seja aplicado duas vezes por toque repetido ou reprocessamento de evento.
- Preservar a ação no backup e no histórico de auditoria.


---

## 9. Backup, migração e versões

### V105 sugerida

| Campo | Valor |
|---|---:|
| versionCode | 105 |
| versionName | V105 |
| Motor interno | 95 |
| Backup Schema | 17 |

Schema 17 é recomendado porque será introduzida uma lista persistente de recordes manuais e novos metadados de execução da prova. Os eventos antigos deverão receber `executionMode = AUTO` na leitura.

### Regras de compatibilidade

- Backups Schema 1–16 continuam legíveis.
- Preservar histórico de sessões, atividades importadas, resultados de prova e calibração.
- Não apagar nem zerar recordes ao atualizar.
- Preservar o campo legado `personalBestTimeText` até a migração ser confirmada.
- Persistir o marco temporal e o evento de auditoria de cada redefinição manual da calibração, incluindo zonas-base restauradas e créditos zerados.
- Persistir `calibrationCycleId` e os ledgers de consumo por ciclo; o timestamp do reset é auditoria, não filtro de data das evidências.
- Permitir reprocessar o histórico elegível completo em novo ciclo, inclusive feedbacks recriados depois de uma limpeza/restauração, com deduplicação por identidade canônica/fingerprint dentro do ciclo atual.
- Não duplicar resultados de prova na migração.
- Garantir que exportação e restauração mantenham `executionMode`, recordes manuais e vínculos com os resultados.
- Não usar a alteração de versão para recalcular ou sobrescrever zonas automaticamente.

---

## 10. Matriz de testes de aprovação V105

Planejar **52 cenários de aprovação**, agrupados assim:

| Área | Cenários | Principais verificações |
|---|---:|---|
| Resultado/feedback de prova | 11 | Registro direto, importação, edição, exclusão/restauração, data real, vínculo, duplicidade, contagem semanal e prova passada sem resultado não concluída |
| Exportação Pace Coach | 7 | Somente fases competitivas, distância exata, nenhuma etapa temporal, nenhum aquecimento/desaquecimento, sem pace inventado |
| Modos de execução | 8 | Constante, progressivo, regressivo, final forte, conservador, agressivo controlado, automático e persistência por prova |
| Recordes | 10 | Cadastro manual, Top 3, ordenação, distâncias, atualização, exclusão, detalhe, origem, prevenção de duplicidade e migração do PB legado |
| Animação | 3 | Novo primeiro lugar, não repetir em recomposição/restauração e modo acessível sem movimento |
| Calibração | 10 | Z3 com 0% não aparece como confirmado; elegível versus aplicado; Lote B só depois de A confirmado; histórico e auditoria dos ciclos anteriores preservados; diálogo Sim/Não; “Não” não altera dados; “Sim” restaura as cinco zonas-base e zera os créditos aplicados; histórico elegível completo reprocessado no novo ciclo; treinos anteriores e feedbacks recadastrados continuam elegíveis; Lote B usa sessões cronologicamente posteriores às do Lote A; deduplicação por fingerprint dentro do ciclo |
| Backup | 3 | Schemas antigos, round-trip Schema 17 e preservação dos dados de competição |
| **Total** | **52** | |

### Cenários de aceitação especialmente importantes

**Prova de 5 km:**

- exportar três etapas competitivas;
- distância total exportada = 5,00 km;
- o Pace Coach não recebe aquecimento nem desaquecimento nesse arquivo;
- a orientação de aquecimento permanece disponível apenas no AI Running Coach.

**Estado do evento:**

- cadastrar uma prova com data passada e sem resultado: deve permanecer “Aguardando resultado”, não `COMPLETED`;
- editar uma prova passada sem resultado: não pode concluí-la automaticamente;
- registrar distância realizada e duração válidas: somente então concluir a prova;
- cancelar a prova: manter `CANCELLED`, sem abrir fluxo de resultado como se estivesse pendente.

**Resultado pós-prova:**

- importar atividade de 5 km com tempo, parciais e data;
- registrar feedback;
- marcar a prova como concluída;
- contar os 5 km uma única vez na semana da atividade;
- mostrar análise de ritmo e parciais;
- mapear zonas somente quando houver dados temporizados;
- criar/atualizar o recorde da distância sem duplicar o resultado.

**Modo progressivo:**

- a primeira fase deve ser mais lenta que a última;
- a distância das fases deve continuar somando exatamente a prova;
- o tempo projetado deve ser coerente com a média ponderada;
- valores não podem ultrapassar os limites suportados por zonas/evidências.

**Calibração:**

- Z3 com contribuição 0% e Lote A apenas candidato não pode exibir “Lote A confirmado”;
- Z1 mantém o lote próprio e a propagação herdada;
- nenhum crédito existente é perdido.

**Redefinição manual da calibração:**

- o botão fica visível na tela Calibração adaptativa;
- tocar no botão abre “Resetar a calibração?” com “Sim” e “Não”;
- escolher “Não” ou fechar o diálogo não altera zonas, percentuais, lotes ou histórico;
- escolher “Sim” restaura Z1–Z5 às zonas-base do último teste válido, zera créditos próprios e propagados e cria um novo `calibrationCycleId`; o timestamp do reset serve apenas para auditoria, sem cortar a elegibilidade por data;
- testes, treinos, provas e auditorias anteriores continuam preservados;
- atividades anteriores ao reset permanecem elegíveis para o novo ciclo, desde que cumpram os critérios de evidência;
- feedbacks históricos cadastrados novamente após uma limpeza/restauração do histórico podem ser reavaliados no novo ciclo;
- uma atividade reimportada ou feedback duplicado não pode contar duas vezes dentro do mesmo ciclo, usando identidade canônica/fingerprint;
- o mesmo histórico pode ser reavaliado em um ciclo posterior iniciado por um reset confirmado, sem duplicar registros no histórico; se já houver evidência suficiente, o motor pode gerar novamente uma proposta, que dependerá de confirmação manual;
- se não houver teste fisiológico válido, o sistema não inventa zonas de restauração;
- atualização dos treinos futuros permanece separada e exige confirmação própria.

---

## 11. Ordem recomendada de implementação

### Fase 1 — Corrigir o que pode gerar dado errado

1. Corrigir o exportador para Pace Coach e os testes correspondentes.
2. Criar o registro direto de resultado da prova com integração ao histórico e à carga semanal.
3. Corrigir o ciclo de vida da prova: data passada sem resultado fica “Aguardando resultado”; só resultado válido conclui.
4. Corrigir a associação/estado da competição, evitando duplicidade e conclusão indevida de treinos.
5. Corrigir a semântica de Lote A na calibração.
6. Implementar “Redefinir calibração”, confirmação Sim/Não, restauração das zonas-base do último teste válido, marco do novo ciclo e auditoria persistente.

### Fase 2 — Nova estratégia de execução

6. Adicionar os modos de execução.
7. Conectar a seleção ao cálculo dos trechos, projeção e arquivo exportado.
8. Persistir a escolha por competição e cobrir com testes.

### Fase 3 — Recordes pessoais

9. Criar o catálogo de distâncias e o Top 3.
10. Criar cadastro manual histórico e migração assistida do PB legado.
11. Vincular resultados de prova aos recordes, com abertura dos detalhes.
12. Adicionar animação de novo recorde.

### Fase 4 — Regressão, backup e homologação

13. Atualizar Schema 17 e testar backups antigos.
14. Executar toda a suíte JUnit/Gradle oficial.
15. Gerar APK pelo GitHub Actions.
16. Instalar no Android 16 e testar o percurso completo: cadastrar prova → escolher estratégia → exportar → executar → registrar resultado → atualizar volume/histórico → consultar recordes.

---

## 12. Conclusão

A V104 não precisa descartar o motor de provas. Ela precisa conectar os recursos que já possui e oferecer as ações que faltam.

A atualização V105 deve transformar a competição em um fluxo contínuo:

**Cadastrar prova → escolher como correr → exportar somente a prova → executar → registrar resultado e feedback → analisar desempenho e zonas → contabilizar a carga semanal → atualizar recordes pessoais.**

A área de recordes com Top 3 por distância e animação de conquista é plenamente viável com a arquitetura Android/Jetpack Compose do projeto.

A atualização deverá preservar a calibração própria da Z1, as zonas Z2/Z3, os limites em cascata e todos os dados existentes da V104. Também deverá incluir o botão solicitado para redefinir a calibração: “Sim” restaura Z1–Z5 ao último teste fisiológico válido e zera os créditos adaptativos ativos; “Não” cancela sem efeitos, mantendo integralmente o histórico.

**Status final:** auditoria V104 concluída; Plano de Correção V105 elaborado; implementação ainda não realizada.
