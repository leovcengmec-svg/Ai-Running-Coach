# Build e validação — AI Running Coach V78

## Identificação
- `versionCode = 78`
- `versionName = V78`
- `CURRENT_ENGINE_VERSION = 68`
- Backup Schema 3; leitura dos schemas 1–3 preservada.

## Atualização aplicada
- Removida da tela de feedback e do histórico a análise automática de blocos baseada em voltas/amostras GPX/FIT/TCX. O motor de alinhamento automático de blocos por atividade foi removido do código-fonte.
- Importação GPX/FIT/TCX permanece para métricas efetivamente disponíveis: distância, tempo, pace médio, elevação, parciais, percurso e distribuição temporal por zona quando há amostras válidas. Esses dados não são associados aos blocos prescritos.
- Removido o campo “Calibração individual da Z2” da tela de feedback. Registros legados são lidos para compatibilidade, mas o pace de teste da fala não alimenta mais a calibração Z2 nem a prescrição nova.
- Criado `WorkoutBlockFeedbackEngine`: expande repetições na ordem de execução (intervalo/recuperação intercalados), classifica o pace informado como mais rápido, dentro da faixa ou mais lento e preserva os limites prescritos no momento da sessão.
- Cada bloco de corrida com entrada de pace pode ser registrado independentemente. Pausa passiva e recuperação caminhando não exigem pace; blocos sem faixa de pace não recebem comparação artificial.
- Novos registros são persistidos em `feedbackRecords` e exportados/restaurados pelo backup Schema 3. Sessões antigas sem feedback de blocos continuam válidas.
- Painel “Comportamento por zona” acumula evidências Z1–Z5, distingue ritmo rápido/preciso/lento e combina os resultados com esforço, sensação e dor. O painel informa tendências; não altera automaticamente limites de zona com base em um único registro.
- Prescrição original e faixa-alvo são congeladas no registro do bloco para impedir que recalibrações futuras alterem o histórico.

## Testes direcionados executados
- 37 testes de domínio direcionados passaram com compilação Kotlin/JVM e um runner local compatível com as asserções JUnit.
- Incluídos os testes de comparação/expansão de blocos, corrida-caminhada, inteligência multi-sessão, calibração Z1/Z3, ignorar dados legados de fala na Z2, faixas Cooper/3 km e registros Cooper.
- Harnesses isolados também passaram para os motores de feedback por bloco e calibração de zonas.

## Limitação de validação do ambiente
- A suíte Gradle oficial e o build Android/Compose/APK não foram executados: o ZIP não contém Gradle Wrapper e este ambiente não possui Gradle CLI nem Android SDK.
- A compilação isolada de `MainActivity.kt` não é possível sem Android/Compose SDK; a checagem de sintaxe não apresentou diagnósticos de parser, mas isso não substitui a compilação Android.
- O workflow GitHub Actions permanece configurado para executar `:app:testDebugUnitTest` e `:app:assembleDebug`. A aprovação do build e a validação em aparelho precisam ser confirmadas após o push.
