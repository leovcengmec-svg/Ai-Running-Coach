# V89 — Especificação de calibração adaptativa e monitoramento

**Aplicativo:** AI Running Coach  
**Base:** V88  
**VersionCode:** 89  
**VersionName:** V89  
**Motor interno:** 78  
**Backup:** Schema 4, com leitura dos schemas 1–4

## 1. Objetivo

Fazer com que as faixas de ritmo acompanhem evidências repetidas dos treinos, sem incremento fixo de 1%, sem acelerar zonas por uma sessão isolada e sem substituir testes fisiológicos por atividades comuns. A camada V89 funciona sobre as zonas calculadas pelo teste de campo já registrado.

Os percentuais de 2%, 3% e 5% são limites iniciais de engenharia definidos para esta implementação. Não são limites fisiológicos universais nem garantias de desempenho.

## 2. Calibração adaptativa Z1–Z3

- **Revisão:** uma vez a cada 28 dias, contados da última revisão ou da referência do teste válido.
- **Evidência:** feedback manual do pace executado em cada bloco prescrito, comparado ao intervalo-alvo congelado no momento do treino.
- **Amostragem mínima por zona:** cinco blocos válidos distribuídos por pelo menos três sessões distintas dentro da janela móvel dos últimos 28 dias.
- **Sinal mínimo:** melhora mediana de pelo menos 2% sobre o ponto médio do intervalo-alvo.
- **Teto por revisão:** até 3% por zona.
- **Teto acumulado:** 5% por zona desde o último teste de campo válido.
- **Sem ajuste mínimo artificial:** o motor não aplica +1% ou qualquer incremento fixo quando a evidência não atinge o limiar.

A evidência é filtrada por validade de ritmo, esforço percebido, sensação, ausência de dor e tipo de sessão. Para Z1, só são aceitos blocos de recuperação/regenerativos. O motor não usa feedback com dor, sensação de fadiga ou esforço incompatível com o filtro da zona. O resultado por zona é calculado independentemente; uma zona pode receber proposta enquanto outra permanece sem alteração por falta de evidência.

A proposta de cada zona aplica o menor valor entre a melhora mediana observada, 3% por revisão e o saldo restante até 5%. Se o saldo for inferior a 2%, nenhuma microalteração abaixo do mínimo é aplicada; a interface explica que é necessário novo teste válido para reiniciar o acumulado.

## 3. Continuidade das faixas e proteção de Z4–Z5

Z4 e Z5 continuam ancoradas às referências do teste fisiológico e não recebem calibração adaptativa baseada em feedback comum. A implementação mantém as cinco bandas ordenadas e contíguas. Como zonas adjacentes compartilham uma fronteira numérica, uma fronteira compartilhada usa o maior deslocamento acumulado aceito entre as duas zonas vizinhas; portanto, a avaliação/elegibilidade é independente por zona, mas um limite comum não pode se mover de modo incompatível para cada lado. Essa regra preserva continuidade e evita sobreposição/inversão artificial.

## 4. Revisão, confirmação e histórico

A tela de zonas apresenta, por zona, a evidência, a faixa anterior, a faixa proposta, a melhora estimada, o percentual aplicado, o acumulado e a justificativa. Zonas sem proposta também exibem a razão: janela ainda não vencida, falta de dados, melhora abaixo de 2% ou limite acumulado atingido.

A prévia não altera o plano. A aplicação exige confirmação explícita e o motor refaz a avaliação no momento da confirmação. Se o teste de referência ou as evidências tiverem mudado, a proposta antiga é recusada.

Cada ajuste aceito é salvo com data, referência do teste, zona, faixa anterior/nova, melhora estimada, variação aplicada, acumulado e quantidades de blocos/sessões. O histórico recente é mantido até 100 decisões.

## 5. Testes e calendário

- O intervalo de treinamento considerado é de 6–8 semanas.
- A janela preferencial de reteste começa no dia 49 (início da oitava semana) e vai até o dia 56.
- O reteste usa o mesmo método do último teste válido (Cooper de 12 minutos ou teste de 3 km), para facilitar a comparação.
- Quando há uma sessão futura de qualidade elegível na janela, o calendário substitui essa sessão pelo reteste. Não cria um treino adicional nem soma volume por uma sessão extra.
- Se não houver vaga de qualidade na janela preferencial, o motor procura a primeira sessão de qualidade elegível a partir do dia 56. Se não houver nenhuma vaga elegível, não força a substituição de sessão fácil, concluída, opcional extra ou reagendada manualmente.
- Sessões concluídas e reagendamentos manuais são protegidos.
- Um novo teste válido reinicia o acumulado adaptativo; apenas abrir a tela do teste ou recalcular o plano não deve reiniciá-lo.

## 6. Monitoramento de desempenho e carga

### Ritmo — 28 dias

O monitor usa uma janela móvel fechada de 28 dias. Se o pace não estiver preenchido, ele é recuperado por tempo total e distância válida. A comparação usa pelo menos quatro sessões fáceis comparáveis, com filtragem por tipo de sessão, terreno, distância, esforço, fadiga e dor. As exclusões ficam contadas e explicadas, incluindo registros fora da janela, pace indisponível, distância curta, tipo não comparável e esforço/fadiga/dor.

O monitor de tendência é descritivo. Ele não modifica zonas automaticamente e não substitui Cooper ou teste de 3 km.

### Volume — 28 e 42 dias

A média semanal de 28 dias exige pelo menos seis atividades medidas distribuídas por três semanas ISO ativas. A média semanal de 42 dias também exige seis atividades em pelo menos três semanas ISO ativas e divide o volume total da janela por seis semanas. A interface mostra o número de atividades e semanas que sustentam a média; sem amostra suficiente, apresenta “Histórico insuficiente”, em vez de extrapolar uma média frágil.

### Contadores separados

A tela Evolução separa feedbacks/registros armazenados, sessões identificadas, atividades com medição, blocos registrados e blocos com pace. Esses contadores não são intercambiáveis: um feedback pode conter vários blocos, e um registro sem medição não deve ser apresentado como atividade medida.

## 7. Persistência e compatibilidade

O estado adaptativo é persistido em uma chave JSON opcional. O Schema 4 foi mantido; backups anteriores que não contenham essa chave continuam válidos e iniciam a camada adaptativa sem acumulado anterior. O histórico de treinos, feedbacks, atividades e datas existentes não é reclassificado retroativamente pela nova zona.

Ao confirmar a calibração, o plano é reconstruído pelo fluxo de migração existente, preservando sessões concluídas e histórico e atualizando somente as sessões futuras elegíveis. A flag de edição de teste em andamento é transitória e não entra no arquivo de backup.

## 8. Critérios de aceite

1. Nenhuma proposta antes da revisão de 28 dias.
2. Nenhuma proposta com melhora mediana abaixo de 2%.
3. Nenhum ajuste superior a 3% por revisão e zona.
4. Nenhum acumulado superior a 5% por zona entre testes válidos.
5. Z1, Z2 e Z3 avaliadas com evidências próprias.
6. Z4 e Z5 permanecem vinculadas ao teste de campo.
7. Evidências insuficientes, exclusões e limites são explicados na interface.
8. Pace ausente é calculado apenas quando tempo e distância estão disponíveis e válidos.
9. Médias de 28/42 dias exibem critérios e amostras suficientes.
10. Reteste da semana 8 substitui uma sessão intensa elegível, sem sessão adicional.
11. Prévia exige confirmação e é revalidada antes de aplicar.
12. Histórico, feedbacks e treinos concluídos permanecem preservados.
13. Backups Schema 1–4 continuam legíveis.
14. O pacote identifica VersionCode 89, VersionName V89 e motor interno 78.

## 9. Limites da validação

Os testes de domínio localizados verificam as fórmulas, janelas, limites, recuperação de pace, exclusões e amostras de volume. A compilação completa do aplicativo Android/Compose, a suíte Gradle oficial e a geração de APK precisam ser confirmadas pelo GitHub Actions; o ambiente desta edição não possui Gradle CLI/Wrapper nem Android SDK.
