# Integridade de agenda e reagendamento — V77

## Regra de identidade
- `sessionId` é a identidade estável da sessão, independente da data atual.
- Uma data concluída não é um bloqueio global para outras sessões. A migração remove apenas a mesma identidade que já está concluída.
- Sessões pendentes com `manuallyRescheduled=true` reaplicam sua data escolhida antes de ajuste de provas e antes de filtros de conclusão.
- O reagendamento é mantido se continuar dentro da mesma semana de calendário e não estiver no passado.
- Se uma sessão manualmente movida não for recriada pelo motor atual, o registro salvo é preservado como fallback, em vez de ser descartado silenciosamente.
- Provas não substituem sessões protegidas manualmente reagendadas. Se não houver sessão livre para substituir, o motor emite aviso de conflito.

## Regressão reproduzida
Agenda original: segunda, quarta, sexta.
Agenda manual: quarta, sexta, domingo.
A V77 mantém os três `sessionId` e as três datas, mesmo quando existe um treino concluído em quarta-feira. O filtro de concluídos compara identidade da sessão, não apenas igualdade de data.

## Limites
- Reagendamentos continuam limitados à mesma semana, conforme regra da agenda.
- Se uma alteração de disponibilidade deslocar a sessão para outra semana, o motor não move automaticamente a sessão; preserva a data original se válida e requer revisão em conflito.
