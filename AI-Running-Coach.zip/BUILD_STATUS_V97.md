# Build Status — AI Running Coach V97

- Base: V96.
- VersionCode: 97.
- VersionName: V97.
- Motor interno: 87.
- Backup Schema: 12; leitura compatível de schemas 1–12.
- Implementação V97 e testes focados incorporados ao source set Android.
- Harness Kotlin/JVM focado: 102 testes aprovados, 0 falhas.
- Integridade do ZIP será verificada após o empacotamento.

## Build Android

**Pendente de CI.** Este ambiente não tem Gradle, wrapper `gradlew` nem Android SDK instalados, portanto não foi possível executar JUnit/Gradle, compilação Compose nem produzir APK.

O workflow `.github/workflows/android.yml` está incluído e executa:

```bash
gradle -p android :app:testDebugUnitTest :app:assembleDebug --no-daemon
```

A V97 somente deve ser considerada APK-validada depois de o workflow `build-apk` finalizar sem erros e publicar o artefato.
