# Test matrix — V62 Runner Readiness

## Matriz do cadastro
- Todos os objetivos fixos: milha, 3 km, 5 km, 10 km, 15 km, meia maratona, maratona e ultra 50 km.
- Milha/3 km e 5 km têm faixas de volume separadas; objetivos personalizados usam o grupo de distância correspondente.
- Saúde e Qualidade de Vida usa faixa própria.
- Níveis Iniciante, Intermediário, Avançado e Elite.
- Elite auto declarado sem evidência recebe guardrails Avançados.
- Duração de experiência ajusta temporariamente os guardrails de níveis que excedam o tempo de prática informado.

## Volume e consistência
- Média 0 km + 0 semanas → reintrodução.
- Média positiva + 0 semanas → inconsistência de cadastro e bloqueio de avanço na tela de entrada.
- Média menor que referência → ponto de partida permanece na média real, sem salto para o mínimo.
- Média dentro da referência → ponto de partida permanece na média real.
- Média acima da referência → não reduz automaticamente a carga histórica.
- Semanas ativas 1–2 → estado inconsistente e qualidade fica mais restrita.
- Semanas ativas 3–4 → elegibilidade ainda depende dos demais critérios do motor.
- Backups antigos sem campos novos → dados desconhecidos; restauração não é bloqueada.
- Se pelo menos seis atividades medidas abrangem três ou mais semanas distintas, o número observado de semanas ativas prevalece sobre a estimativa declarada.

## Frequência
- Recomendação varia por objetivo/nível.
- Frequência efetivamente escolhida entre 2–6 dias sempre permanece.
- Frequência abaixo/acima da referência gera aviso e adaptação, não substituição da escolha.
- Experiência mínima operacional: intermediário 12 meses, avançado 36 meses, Elite 60 meses mais evidência de carga.

## Critérios de aprovação
- Referência de volume e frequência existe para toda combinação suportada, com exceção documentada de ultramaratona iniciante (preparação prévia).
- A faixa de referência nunca força aumento do volume inicial.
- Z3/limiar/VO₂ não são liberados automaticamente com 0–2 semanas ativas quando essa evidência está disponível.
- O motor gera recomendações explicáveis de compatibilidade, condição atual e confiança.
- Backup V61/schema 2 continua restaurável; V62 persiste e restaura `runningExperienceDuration` e `activeWeeksLast4`.

## Execução local adicional
- Compilação Kotlin/JVM do conjunto de motores de domínio (com modelo `Workout` de suporte para isolar dependências Android): aprovada.
- 39 testes de quatro classes executados por harness local de assertions: `RunnerReadinessEngineTest`, `TrainingPeriodizationEngineTest`, `TrainingLoadEngineTest` e `TrainingScheduleEngineTest`.
- A suíte Gradle/JUnit oficial e a compilação Android completa ainda devem ser executadas no GitHub Actions.

## Regressões adicionais de legado e consistência (V62)
- Perfil V61 intermediário sem `runningExperienceDuration`: duração permanece desconhecida; prescrição usa guardrail de Iniciante e mostra explicação, sem inventar meses.
- Perfil V61 avançado sem duração: prescrição usa guardrail de Intermediário.
- Elite com 12–35 meses: usa Intermediário; Elite com 36–59 meses: usa Avançado; Elite ≥60 meses só mantém Elite com carga, consistência e maior sessão compatíveis.
- Semanas ativas desconhecidas e sem histórico medido confiável: sessão de qualidade é suprimida; nenhuma sessão Z3/Z4/Z5 é liberada por suposição.
- Semanas ativas desconhecidas, mas histórico confiável (≥6 atividades distribuídas por ≥3 semanas): a consistência medida pode liberar a avaliação normal, ainda sujeita aos demais guardrails.
- 1–2 semanas ativas: qualidade permanece restrita e a confiança é baixa.
- 160 cenários de plano (8 objetivos × 4 níveis × 5 frequências), oito semanas por cenário, foram executados com verificação da frequência selecionada e da soma dos segmentos.
