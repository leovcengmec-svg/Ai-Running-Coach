# CHANGELOG

## V79 — Entrada inteligente, métricas unificadas, carga adaptativa e estratégia individual de prova
- `SmartInputMask`: datas com barras automáticas, ritmos e durações com separadores automáticos, distância com ponto/vírgula e apresentação decimal brasileira; aplicada ao cadastro, testes, perfil, feedback e provas.
- `UnifiedPrescriptionCalculator`: centraliza os cálculos de distância, duração e pace para prescrições por tempo, distância ou ritmo. Cartões de sessões concluídas passam a usar somente métricas reais do mesmo registro; sessões programadas usam somente métricas previstas. Métricas não calculáveis permanecem indisponíveis, sem ritmo genérico inventado.
- Importador GPX/FIT/TCX: preserva voltas explícitas, parciais GPS e trecho final fracionado. Quando o total declarado supera a distância coberta por dados GPS, a diferença é apresentada como trecho sem detalhamento GPS/estimado, sem fingir que houve medição GPS. A cobertura e a origem de cada trecho ficam visíveis.
- Distribuição semanal: aloca longão e qualidade com precisão de 0,1 km em vez de arredondamento de 0,5 km. O longão participa da progressão quando volume, histórico, fase e recuperação permitem; teto individual, semanas regenerativas e bloqueios por dor/fadiga permanecem ativos. Não há aumento obrigatório em todas as semanas.
- Painel de zonas: “candidata a revisão” abre uma avaliação assistida com quantidade de blocos/sessões e justificativa. A ação apenas mantém/observa ou encaminha para novo teste; não altera automaticamente os limites das zonas.
- Novo `RaceStrategyEngine`: estratégia em Início/Meio/Final, com trechos, zonas e faixas de ritmo por distância (5 km, 10 km, 10 milhas, meia-maratona, maratona e distâncias personalizadas), prioridade A/B/C, tempo-alvo condicionado à compatibilidade e evidências de atividades/blocos sustentados. Repetições curtas não são extrapoladas como ritmo de prova. Sem zonas/evidências suficientes, não se inventa ritmo.
- Gerenciamento de competições simplificado para cadastro, edição e exclusão; orientação removida da tela de cadastro. Agenda, plano e card da próxima prova abrem uma tela exclusiva de estratégia.
- `Screen.RACE_STRATEGY` foi acrescentada ao final do enum para preservar os ordinais das telas V78 persistidos no aparelho. `selectedRaceId` é estado transitório e não entra no backup.
- Backup Schema 4 passa a gravar a versão V79 e continua lendo schemas 1–4, incluindo Schema 3 da V78. `versionCode = 79`, `versionName = V79`, `CURRENT_ENGINE_VERSION = 69`.
- Independência de frequência cardíaca/FCM preservada em cadastro, prescrição, feedback, zonas e estratégia de prova.
- Validação Kotlin/JVM isolada: 10 verificações de máscaras/calculadora; 16 verificações de estratégia de prova; cenários GPX com voltas+GPS e GPS incompleto preservando 6,62 km. Testes unitários adicionais foram incluídos. Build Gradle/Android completo permanece pendente do GitHub Actions, pois este ambiente não contém Gradle CLI/Wrapper nem Android SDK.

## V78 — Feedback por bloco e inteligência de execução por zona
- Correção de compilação reportada no GitHub Actions: `RaceEventEngine.applyToPlan` passa a receber `remainingCycleSessions` (símbolo previamente declarado), corrigindo o `Unresolved reference: manuallyPlacedSessions` em `MainActivity.kt:881`. Identidade V78 e Backup Schema 3 preservados.
- Removida a associação automática entre voltas/amostras GPX/FIT/TCX e blocos prescritos da tela de feedback/histórico. O motor de reconstrução automática de blocos pela atividade foi removido; importação de métricas gerais, parciais, percurso e distribuição temporal por zona continua.
- Removido o campo “Calibração individual da Z2” por ritmo confortável. Registros legados continuam legíveis no backup, mas não são usados para calibrar Z2 nem para alimentar a prescrição.
- Novo formulário apresenta os blocos, zona e faixa originalmente proposta, com entrada opcional de pace realizado em cada ocorrência. Repetições de trabalho/recuperação são expandidas e intercaladas na ordem real.
- Comparação usa os limites prescritos congelados: pace mais rápido que o limite rápido = mais rápido; dentro da faixa = preciso; acima do limite lento = mais lento. Blocos passivos/caminhada não exigem pace e ausência de alvo não gera comparação fictícia.
- Novo painel de comportamento Z1–Z5 consolida frequência de execuções rápidas/precisas/lentas, sessões distintas, esforço, sensação e dor. Sinais de revisão exigem múltiplos registros e não mudam as zonas automaticamente.
- Novos registros incorporados a `feedbackRecords`, preservando Backup Schema 3 e compatibilidade com schemas 1–3. `versionCode = 78`, `versionName = V78`, `CURRENT_ENGINE_VERSION = 68`; sem dependência de FC/FCM.
- Testes: classificação de comparação, expansão ordenada das repetições, ausência de comparação sem alvo e limiar mínimo de evidência multi-sessão.

## V77 — Periodização estável, reagendamento íntegro e Race Day Intelligence
- Prontidão temporária separada da fase macro de periodização: um único feedback de cansaço produz estado moderado, não alerta amarelo; alertas de fadiga exigem evidência repetida/mais forte. Ajustes de qualidade por alerta ficam concentrados na semana corrente, sem transformar o ciclo inteiro em recuperação.
- Reagendamentos pendentes reaplicados por `sessionId` antes da aplicação de provas e antes de qualquer filtro de calendário. A filtragem de sessões concluídas passou a usar identidade da sessão, não apenas coincidência de data. Sessões manualmente movidas que não reapareçam no plano regenerado são preservadas; provas não removem sessões protegidas e geram aviso de conflito.
- Novo `RaceDayGuideEngine`: orientação pré-prova, aquecimento, largada, estratégia durante a prova, trecho final, hidratação/energia e recuperação, ajustada à distância, prioridade A/B/C e prioridade do atleta. Orientações são exibidas em cada prova futura cadastrada.
- Ritmo previsto do card calculado pela média ponderada de todos os segmentos com ritmo-alvo, em vez de copiar um único bloco. Pausas passivas ficam fora do cálculo; treino concluído mostra o ritmo real salvo no feedback quando disponível.
- Dashboard distingue quilometragem agendada, quilometragem restante e meta semanal planejada.
- `versionCode = 77`, `versionName = V77`, `CURRENT_ENGINE_VERSION = 67`; Backup Schema 3 e leitura dos schemas 1–3 preservados. Sem dependência de FC/FCM.

## V76 — Adaptive Pace Zones & Workout Engine
- Faixas ativas livres: qualquer intervalo percentual válido de 0–100% dentro da zona operacional, interpretado como posição do pace dentro da zona (0% mais lento; 100% mais rápido), não percentual de VO₂máx/FC.
- Corredores com pelo menos seis meses de experiência recebem aquecimento e desaquecimento em Z2 0–20% quando há calibração individual válida; sem calibração, não é inventado pace numérico.
- Recuperações PASSIVE tornam-se exclusivamente por tempo e sem distância/pace/zona; WALK não recebe pace/zona; ACTIVE_Z2 usa 0–20% da Z2. Protocolos fortes usam pausa parada em Z5 e caminhada em Z4, com demais recuperações ativas conforme a estrutura do protocolo.
- Alternativas de sessões saudáveis mantêm família do estímulo, dose, zonas e ordem; progressões preservam os estágios originais. Sessão reduzida é usada quando sinais de saúde/recuperação indicam que manter qualidade não é adequado.
- Exportação mantém pace calculado de cada faixa; passos passivos/caminhada são exportados sem alvo de pace.
- Restauração completa de backup oferece decisão explícita para recalibrar o ciclo futuro pelo motor atual ou manter o plano importado; histórico concluído, feedbacks, atividades e datas reais permanecem preservados.
- `versionCode = 76`, `versionName = V76`, `CURRENT_ENGINE_VERSION = 66`; Backup Schema 3 e leitura schemas 1–3 preservados. Sem dependência de FC/FCM.
- Validação: domínio Kotlin/JVM passou; runner focado passou 26/26 testes; harness confirmou Z2 0–20 para transições experientes. Runner amplo de CoachEngine mantém 21 falhas já existentes na base V75. JUnit/Android build completos pendentes de Gradle/SDK.


## V75 — Training Intelligence 5.1: bases por objetivo e prioridade adaptativa
- Criado catálogo único de KM-base, teto semanal de construção, capacidade contínua anterior presumida e frequência recomendada por objetivo; 42,2 km presume 21,1 km anteriores e meia maratona presume 16,1 km.
- Cadastro em branco agora usa os valores do objetivo. Um zero digitado permanece declaração explícita de ausência de volume/percurso recente; campos vazios ou histórico GPS ausente não são tratados como zero.
- Metas até maratona liberadas para categorias fisiológicas Iniciante e Intermediário; o nível fisiológico calibra ritmo/estímulo, não bloqueia a distância escolhida.
- Caminhada/corrida comum exige iniciante real, experiência inferior a seis meses, ambos os campos explicitamente zerados e ausência de evidência de 5 km contínuos. Corredor que já demonstrou 5 km não recebe esse caminho.
- Elegibilidade da fase específica alinhada ao catálogo. Frequência recomendada é orientação; três dias passam a ser o piso do planejador para não transformar quatro dias em barreira absoluta.
- Prioridades completude, continuidade, recorde pessoal e tempo-alvo têm diferenças na distribuição semanal, longão e seleção de protocolos. Mudanças no cadastro invalidam o plano e recalculam sessões futuras sem apagar sessões concluídas.
- Acrescentado `RunWalkEligibilityEngine` e testes dedicados para ausência de dados, 5 km contínuos, verdadeiro iniciante e objetivos acima de 5 km.
- Motor atualizado para `CURRENT_ENGINE_VERSION = 64`; `versionCode = 75`, `versionName = V75`; Backup Schema 3 preservado.
- Sem dependência de FC/FCM. Ver `TRAINING_INTELLIGENCE_V75.md` e `BUILD_STATUS_V75.md`.


## V75 — Goal Load Catalog & Priority-Aware Training
- Adicionado catálogo fixo por objetivo com KM-base semanal, teto de construção, distância contínua anterior presumida e frequência de referência, incluindo meia maratona, maratona e ultradistâncias.
- Campos de média das quatro semanas e maior percurso tornaram-se opcionais: campos vazios carregam a base/capacidade presumida do objetivo; zero digitado permanece explícito.
- Maratona presume 21,1 km contínuos prévios; meia maratona presume 16,1 km; 10 km presume 5 km.
- Corrida/caminhada fica restrita ao iniciante real com objetivo até 5,5 km e capacidade abaixo de 5 km. A trava também é aplicada dentro do motor, evitando que uma flag indevida gere caminhada/corrida para quem já concluiu 5 km.
- Prioridades COMPLETAR, CONTINUOUS, PERSONAL_BEST e TARGET_TIME ganham distribuição/estilo distintos em longão e rodagens, mesmo quando qualidade mais intensa ainda não é elegível.
- Mudanças em objetivo, prioridade, tempo-alvo, recorde pessoal, experiência, teste e carga do cadastro marcam o plano como desatualizado. A regeneração mantém treinos concluídos e histórico.
- Fluxo de migração/restore deixa de exigir que média e maior percurso estejam preenchidos; catálogo supre ausências.
- Incremento `versionCode = 75`, `versionName = V75`, `CURRENT_ENGINE_VERSION = 64`; Backup Schema 3 mantido, `appVersion = V75`.
- Preservada a independência de FC/FCM na prescrição, progressão, prontidão e análise.
- Compilação de domínio Kotlin/JVM e harness funcional executados; JUnit/Android build ficam pendentes do GitHub Actions por falta de Gradle/SDK no ambiente local.

# CHANGELOG

## V77 — Periodização estável, reagendamento íntegro e Race Day Intelligence
- Prontidão temporária separada da fase macro de periodização: um único feedback de cansaço produz estado moderado, não alerta amarelo; alertas de fadiga exigem evidência repetida/mais forte. Ajustes de qualidade por alerta ficam concentrados na semana corrente, sem transformar o ciclo inteiro em recuperação.
- Reagendamentos pendentes reaplicados por `sessionId` antes da aplicação de provas e antes de qualquer filtro de calendário. A filtragem de sessões concluídas passou a usar identidade da sessão, não apenas coincidência de data. Sessões manualmente movidas que não reapareçam no plano regenerado são preservadas; provas não removem sessões protegidas e geram aviso de conflito.
- Novo `RaceDayGuideEngine`: orientação pré-prova, aquecimento, largada, estratégia durante a prova, trecho final, hidratação/energia e recuperação, ajustada à distância, prioridade A/B/C e prioridade do atleta. Orientações são exibidas em cada prova futura cadastrada.
- Ritmo previsto do card calculado pela média ponderada de todos os segmentos com ritmo-alvo, em vez de copiar um único bloco. Pausas passivas ficam fora do cálculo; treino concluído mostra o ritmo real salvo no feedback quando disponível.
- Dashboard distingue quilometragem agendada, quilometragem restante e meta semanal planejada.
- `versionCode = 77`, `versionName = V77`, `CURRENT_ENGINE_VERSION = 67`; Backup Schema 3 e leitura dos schemas 1–3 preservados. Sem dependência de FC/FCM.

## V74 — Training Intelligence 5.0: objetivo adaptativo, carga e reconhecimento de blocos
- Separados objetivo final e capacidade atual. Fase específica bloqueada até requisitos de volume, maior sessão, frequência, consistência, recuperação e coerência entre média semanal e maior corrida.
- Requisitos de entrada derivados das transições do documento de progressão anexado; 42,2 km usa como referência interna 45 km/semana, longão 16 km e 5 dias. Iniciante de 0–5 km usa referência de aproximadamente 7 km de corrida/caminhada na semana e três dias.
- Prioridades passam a modificar organização da semana e estímulos aeróbios seguros durante a base preparatória.
- Carga semanal registra target, volume realmente distribuído e variância. Deload de referência reduz 25% após três semanas de construção e preserva a referência de retomada.
- Recuperações passam a ser tipadas como parada, caminhada ou ativas. Pausas paradas não têm distância/pace; recuperação ativa não é mais lenta que o desaquecimento, ou vira caminhada.
- Importador FIT preserva voltas explícitas (`Lap`); TCX e GPX estruturado mantêm suas voltas. Alinhamento 1:1 exige quantidade igual e dose de cada volta compatível com o bloco; divergências geram resumo sem mapeamento artificial.
- GPX com poucos pontos não gera análise de blocos enganosa; amostras temporais espaçadas podem representar intervalos GPS até 1.000 m quando plausíveis. Ritmo é classificado direcionalmente (mais rápido, acima de intensidade leve, mais lento).
- Distribuição de intensidade por tempo dos segmentos exibida na tela do plano; percentuais ocultados quando os dados são insuficientes.
- Cards de perfil adaptáveis e análise/histórico recolhidos por padrão. Alterações relevantes de objetivo, prioridade, calendário ou base recalculam o ciclo futuro sem apagar sessões concluídas.
- Migração do motor 60 → 61. Backup Schema 3 preservado; exportação identifica V74; sem dependência de FC/FCM.
- Compilação Kotlin/JVM de domínio e 52 métodos de regressão selecionados aprovados em runner local. Build Android/JUnit completo pendente de Gradle/SDK/GitHub Actions.

## V73 — Correções pós-auditoria V72
- Diferenciação de estímulos de qualidade por distância também nos objetivos “Completar” e “Correr continuamente”, sem liberar limiar/VO₂ sem os critérios de carga e recuperação já existentes.
- Integração efetiva da distribuição planejada: relatório ponderado por tempo e faixa orientativa por fase passam a compor o resultado e a explicação do plano.
- Mantidos pace/Z1–Z5, RPE e teste da fala como referências; frequência cardíaca não participa da prescrição.
- Mantida a estrutura de backup Schema 3 e compatibilidade legada.
- Correção incremental baseada nos achados da auditoria V72; ver BUILD_STATUS_V73.md para limitações de validação.

## V72 — Adaptive Training Intelligence 4.0 (19/11/2026)

- Atualizada a versão para `versionCode = 72`, `versionName = V72` e `CURRENT_ENGINE_VERSION = 57`; Backup Schema 3 permanece compatível com backups V71/schema 3 e schemas 1–3.
- Biblioteca reorganizada em tipos de sessão, protocolos com dose tipada e regras de periodização. Padronizados nomes de Rodagem e Longão sem códigos técnicos em títulos.
- Protocolos por distância mantêm exatamente a distância de cada repetição; protocolos por tempo mantêm exatamente sua duração. I07 passa a representar 5 × 600 m, com quatro recuperações de 2 min; se a dose não couber no orçamento seguro, o nome de intervalo é removido e a sessão vira aeróbia, sem conversão silenciosa.
- Adicionada progressão caminhada/trote inspirada nos programas 5K/10K Sem Parar, diferenciando corredores que já mantêm corrida contínua daqueles que ainda precisam construir essa capacidade.
- Periodização usa as referências O2 Corre, BR Corrida e Nike Run Club para 5 km, 10 km, meia maratona e maratona; inclui uma ponte própria de 15 km, identificada como metodologia do aplicativo porque os anexos não trazem plano específico dessa distância.
- Prioridade (completar, correr continuamente, melhorar RP ou tempo-alvo), nível, distância, volume, maior sessão, disponibilidade e recuperação influenciam a escolha de sessões.
- Zonas e prescrição são exclusivamente por pace; percepção de esforço e teste da fala são complementares. FC/FCM não é requisito e não é utilizada pelos motores de zonas, carga, prontidão, adaptação ou análise de blocos. Novas importações GPX/FIT/TCX ignoram dados cardíacos; valores já existentes em backups antigos podem permanecer apenas para compatibilidade histórica, sem exibição ou consumo pelo treinador.
- Calendário passa a agrupar atividades concluídas pela data real, preservando a data programada como referência secundária. Botões de backup e cards do resumo do atleta foram padronizados; prioridade aparece no resumo do Plano.
- Análise GPX por blocos permanece baseada em timestamp, distância, duração, pace, zonas de ritmo e cadência quando disponível, identificando reconstruções estimadas e dados insuficientes.
- Validação local: motores Kotlin/JVM compilados; harness confirmou I07 em cinco blocos de 600 m e quatro recuperações. Gradle/JUnit completo, APKs e teste em aparelho/Pace Coach permanecem pendentes por ausência de Gradle/Android SDK no ambiente.

## V71 — Athlete Experience & GPX Intelligence 2.0 (18/11/2026)

- Atualiza `versionCode = 71`, `versionName = V71` e `CURRENT_ENGINE_VERSION = 56`. Backup passa ao Schema 3 e identifica `appVersion = V71`; a leitura continua aceitando schemas 1 e 2.
- Reformula `ProfileScreen`: identificação do atleta, resumo de métricas, dados pessoais, avaliação fisiológica, objetivos, rotina/carga e gerenciamento em seções independentes; remove o painel de prontidão da sequência de ações do perfil.
- Centraliza a demografia. Data de nascimento é a fonte preferencial, a idade atual e a idade na data do teste são calculadas por calendário; perfis antigos sem nascimento continuam usando `ageYearsText`. Referência fisiológica é configurada no perfil e reutilizada; perfil V70 pode recuperar a referência a partir do último teste salvo. A interface deixa de solicitar idade e referência a cada avaliação e remove a linha redundante de idade do teste no perfil.
- Reformula `EvolutionScreen` com filtros 7/28/90 dias, cards compactos, barras de volume diário/semanal, aderência, distribuição de intensidade baseada somente em amostras medidas, carga, evolução de ritmo, zonas e histórico recente. Elevação acumulada é exibida em metros.
- GPX: timestamp dos Trackpoints prevalece sobre metadata de exportação; metadata fica como fallback. TCX: Trackpoint prevalece, seguido por Activity/Id e início da primeira volta. FIT preserva o horário de Session quando disponível. A origem temporal é persistida (`TRACK_POINT`, `SESSION`, `LAP`, `METADATA`).
- Identifica TrackSegments/Tracks independentes e não soma linha reta entre segmentos separados. Lacunas acima de 120 s, distâncias implausíveis e saltos são excluídos da série temporizada. Distâncias TCX que reiniciam por Track são rebaseadas no acumulado global. Parciais de km não são interpoladas atravessando segmentos desconectados ou pausas longas.
- `ActivityPaceSegment` agora persiste offset em segundos, distância inicial/percorrida e médias de FC/cadência quando medidas. Dados legados continuam sendo lidos com fallback estimado.
- Adiciona `ActivityBlockAnalysisEngine`: alinha amostras ao tempo/distância prescritos, expande pares de repetição e informa ritmo, tempo no alvo/zona, FC/cadência disponíveis, confiança e aderência do bloco. A interface avisa quando a análise é reconstruída e estimada porque o arquivo não tem volta explícita.
- O histórico apresenta data real e hora local da execução quando o arquivo fornece timestamp, mantendo a data planejada como metadado secundário. `ActivityDateResolver` prioriza o timestamp da atividade para GPX/FIT/TCX.
- Testes acrescentados para demografia por data de nascimento, GPX metadata versus Trackpoint, TrackSegments descontínuos, prevenção de parciais inventadas, data real e comparação de blocos/repetições.
- Validação local: compilação e execução do harness Kotlin/JVM de parser/datas/análise de blocos passaram. A suíte Gradle/JUnit completa, APK Debug/Release e os testes reais no Pace Coach permanecem pendentes do GitHub Actions/aparelho; esta edição não possui Gradle nem Android SDK.
- Nota de migração: backups V70 não guardam necessariamente os timestamps originais dos Trackpoints. Registros antigos cuja data já foi gravada a partir da metadata precisam ser reimportados do arquivo original para recuperar a data/hora correta.

## V70 — Training Intelligence 3.1 e correções da auditoria V69 (18/11/2026)

- Incrementa `versionCode = 70`, `versionName = V70` e `engineVersion = 55`; backup Schema 2 passa a gravar `appVersion = V70`. O schema permanece 2 porque os novos campos de perfil são opcionais e os registros de sessão existentes não mudam de estrutura.
- Separa restauração completa (substitutiva) da importação seletiva de histórico. O modo seletivo valida integridade/manifesto, aceita backup sem âncora de ciclo, mescla somente treinos concluídos e atividades/feedbacks relacionados, deduplica por fingerprint ou sessão e grava apenas `workouts`, `feedbackRecords` e a sinalização de recálculo; perfil e plano local são preservados.
- Corrige a trajetória semanal: a semana regenerativa reduz temporariamente a carga sem se tornar a nova referência de construção. O limite inferior da faixa de volume por objetivo passa a orientar a evolução explicada, sem impor saltos de carga.
- Substitui o teto fixo de longão em 110% do maior treino recente por uma liberação planejada progressiva ao longo das semanas, limitada ao teto da distância-alvo e bloqueada quando dor/recuperação/fadiga não permitem progredir. A semana regenerativa continua reduzindo a sessão.
- Completa a intenção `PERSONAL_BEST` com campo de RP atual na distância escolhida, validação independente do tempo-alvo e uso como referência suplementar de pace apenas quando compatível com zona, fase, terreno e prontidão.
- Títulos de sessões deixam de concatenar códigos internos de protocolo; títulos legados são higienizados ao carregar e a exportação usa o título amigável. Códigos permanecem em metadados internos do estímulo.
- Intervalados protocolados passam a gerar um par explícito `Intervalo`/`Recuperação` com `repeatCount`, permitindo estrutura compacta e grupo Garmin de repetição, em vez de blocos avulsos com repetição 1.
- Corrige o JSON Pace Coach: etapas isoladas têm `groupId` próprio sem `parentGroupId`; filhos de repetição têm identificadores próprios e apontam para o grupo pai. O valor `endConditionValue` de distância é serializado em centímetros, mantendo unidade/display em metros; recuperação permanece `stepTypeKey = recovery`.
- Centraliza a idade atual na primeira tela e no perfil. Remove campos repetidos de idade das telas de teste e impede preencher idade histórica ausente com a idade atual; para completar teste antigo, solicita a idade que o atleta tinha naquela data.
- Atualiza README, guia de GitHub Actions e status do projeto. Testes de regressão foram adicionados para backup seletivo, deduplicação, progressão após deload, teto de longão, grupos Garmin, conversão de distância e higienização de títulos.
- Validação local: inspeção estática dos fontes e estrutura. Gradle/JUnit, APK Debug/Release e importação no Pace Coach não foram executados nesta edição porque o ZIP não possui Gradle Wrapper e o ambiente local não dispõe de Gradle/Android SDK; estes gates permanecem no GitHub Actions e no teste em aparelho.

## V69 — correção de interoperabilidade Pace Coach e versionamento consolidado
- Incrementa `versionCode = 69`, `versionName = V69` e `engineVersion = 54`; backups passam a identificar `appVersion = V69`. O schema de backup permanece 2 porque a estrutura persistida não foi alterada.
- A exportação de blocos repetidos mantém o grupo `repeat` e seus filhos agrupados, com ordem sequencial e identificadores de grupo/pai consistentes.
- Etapas de recuperação agora são exportadas com `stepTypeKey = recovery` (em vez de `rest`), alinhadas ao JSON real de importação do Pace Coach fornecido como referência. Incluído `coachRhythm = 1` em cada etapa.
- Aquecimento, intervalo, recuperação e desaquecimento continuam exportados como etapas distintas; o grupo repete somente o par de blocos configurado, sem duplicar manualmente a sequência.
- Adicionado teste de contrato para Aquecimento → Repetir 4x (Intervalo + Recuperação) → Desaquecimento, além dos testes existentes de IDs, ordem, unidades, alvos de ritmo e envelope `UserWorkoutJson`.
- A validação Gradle/JUnit e a geração do APK ainda dependem do GitHub Actions; este ambiente não possui Gradle instalado e, portanto, não declara build Android aprovado.

# Changelog

## V74 — Training Intelligence 5.0: objetivo adaptativo, carga e reconhecimento de blocos
- Separados objetivo final e capacidade atual. Fase específica bloqueada até requisitos de volume, maior sessão, frequência, consistência, recuperação e coerência entre média semanal e maior corrida.
- Requisitos de entrada derivados das transições do documento de progressão anexado; 42,2 km usa como referência interna 45 km/semana, longão 16 km e 5 dias. Iniciante de 0–5 km usa referência de aproximadamente 7 km de corrida/caminhada na semana e três dias.
- Prioridades passam a modificar organização da semana e estímulos aeróbios seguros durante a base preparatória.
- Carga semanal registra target, volume realmente distribuído e variância. Deload de referência reduz 25% após três semanas de construção e preserva a referência de retomada.
- Recuperações passam a ser tipadas como parada, caminhada ou ativas. Pausas paradas não têm distância/pace; recuperação ativa não é mais lenta que o desaquecimento, ou vira caminhada.
- Importador FIT preserva voltas explícitas (`Lap`); TCX e GPX estruturado mantêm suas voltas. Alinhamento 1:1 exige a mesma quantidade de blocos; divergências geram resumo sem mapeamento artificial.
- GPX com poucos pontos não gera análise de blocos enganosa. Ritmo é classificado direcionalmente (mais rápido, acima de intensidade leve, mais lento).
- Distribuição de intensidade por tempo dos segmentos exibida na tela do plano; percentuais ocultados quando os dados são insuficientes.
- Cards de perfil adaptáveis e análise/histórico recolhidos por padrão.
- Migração do motor 60 → 61. Backup Schema 3 preservado; exportação identifica V74; sem dependência de FC/FCM.
- Compilação Kotlin/JVM do domínio aprovada. Build Android/JUnit completos pendentes de Gradle/SDK/GitHub Actions.

## V68
- Corrigido o build Kotlin: `SecondaryButton` agora aceita `enabled` e encaminha o estado ao `OutlinedButton`.
- `versionCode = 68`, `versionName = V68`; `engineVersion = 53` e Backup Schema 2 permanecem inalterados.


## V67 — correção de compilação Android (17/11/2026)
- Corrigido erro Kotlin em `MainActivity.kt`: o painel “Zonas e calibração” utilizava `latestTest` sem declarar a variável no escopo do composable. Agora o registro fisiológico mais recente é obtido de `state.cooperAssessments` antes da apresentação.
- Os erros de inferência de tipo e a incompatibilidade aparente da chamada `InfoRow` eram consequências da referência não resolvida; a expressão continua entregando `String` ao componente `InfoRow(label: String, value: String)`.
- Incrementado o app para `versionCode = 67` e `versionName = V67`. `engineVersion = 53` e Backup Schema 2 permanecem inalterados porque esta entrega corrige a tela/build e não modifica a lógica de prescrição.
- `AppBackupManager` e teste do manifesto passam a identificar `appVersion = V67`.
- Próxima verificação obrigatória no GitHub Actions: `:app:testDebugUnitTest` e `:app:assembleDebug`.


## V66 — refinamento da prescrição por objetivo, fase e tolerância (17/11/2026)

- Motor de prescrição conectado à matriz de sessões da planilha MOTOR V11: objetivo e intenção (completar, correr continuamente, recorde pessoal ou tempo-alvo), fase e elegibilidade individual agora selecionam protocolos nomeados. A distância isolada não escolhe a sessão.
- Sequência de 5 km com intenção de recorde pessoal e três dias/semana validada em 10 semanas: Fartlek (F01/F04), Tempo Run (T01), intervalado 3 min (I04), Tempo intervalado (T04), ritmo específico 5 km (RP05) e intervalado 600 m (I07), com semanas regenerativas 4 e 8. As sessões fáceis e longões são mantidos entre estímulos.
- Corrigido F01: os blocos ativos variam em Z2–Z3 e as recuperações ficam em Z1, conforme PROTOCOLOS. Não é convertido em Fartlek forte Z3–Z4. F02 e F04 mantêm critérios próprios de elegibilidade; F03 piramidal Z3–Z5 só entra com maior frequência, volume e recuperação.
- O rótulo fisiológico (Iniciante/Intermediário/Performance/Elite) não bloqueia automaticamente estímulos ativos. Qualidade aeróbia/limiar usa volume recente, maior sessão, frequência, consistência, dor, fadiga, recuperação, zonas válidas e terreno. Z4/Z5 exigem critérios adicionais; um corredor fisiologicamente Iniciante pode receber Z3 ou limiar inicial quando sua carga/tolerância realmente sustentam.
- Distribuição planejada agora muda com a fase: base, desenvolvimento, específico, recuperação e taper. As referências são faixas ajustáveis, não metas de intensidade obrigatórias. Sem tempo segmentado suficiente, o relatório não exibe 0% artificiais.
- Biblioteca: 23 modalidades têm status explícito (automático, condicional ou complementar) e explicação de integração; removida a mensagem interna genérica de “uso ainda não classificado” para protocolos já mapeados. Modalidades ainda não automáticas aparecem como “Não integrado — referência”, sem fingir integração.
- Perfil: removido campo duplicado de volume; adicionados quilômetros e corridas realmente registrados em 28 dias, semanas com atividade e média real. Nome continua vindo do cadastro salvo e pode ser editado; não existe nome fixo no código.
- Objetivo: Iniciante e Intermediário têm as mesmas distâncias compatíveis até meia maratona; o que diferencia a prescrição é a combinação entre intenção, fase, carga, consistência, terreno e tolerância — não um bloqueio por rótulo. A tela mostra explicitamente nível e VO₂ estimado.
- Teste antigo sem idade/referência pode receber os dados demográficos retrospectivamente sem repetir o teste. Ao anexar a referência, a classificação é recalculada e o plano futuro é marcado para revisão. A tela de teste exibe os limites de cada faixa para a idade/referência escolhidas.
- A instalação detecta planos do motor 52 e pede recálculo ao atualizar para 53. Sessões concluídas, feedbacks, registros e âncora do ciclo são preservados; apenas o que ainda será treinado é regenerado quando o usuário confirmar.
- Versionamento: `versionCode = 66`, `versionName = V66`, `engineVersion = 53`, Backup Schema 2 e `appVersion = V66`.
- Validação local: compilação Kotlin/JVM dos motores de domínio e harness com perfil de 5 km/recorde pessoal, 16 km/semana, maior sessão 10 km, 3 dias e Cooper 2,1 km. A compilação Android/Gradle/JUnit completo ainda depende do GitHub Actions.

# CHANGELOG — AI Running Coach

## V65 — cadastro fisiológico, metas por nível e prescrição coerente (17/11/2026)

- O onboarding passa a seguir seis etapas: (1) teste de campo, idade e referência fisiológica; (2) meta liberada pelo resultado; (3) tempo de prática; (4) dias disponíveis e terreno; (5) volume semanal real; (6) maior corrida recente. A pergunta manual sobre semanas ativas foi removida; consistência é calculada pelo histórico confiável de atividades.
- O nível deixa de ser selecionado/ajustado por tempo de prática. Cooper de 12 minutos ou teste de 3 km estima VO₂máx; uma única avaliação fisiológica por idade e referência usada na equação define Iniciante, Intermediário, Performance ou Elite. Experiência, quilometragem e semanas ativas afetam somente tolerância, dose, confiança e segurança, nunca rebaixam a classe fisiológica.
- A tabela etária/sexo foi adaptada de Mandsager et al. (JAMA Network Open, 2018), Tabela 2. O grupo abaixo da mediana (Low + Below Average) é apresentado como Iniciante; Above Average como Intermediário; High como Performance; Elite (≥97,7º percentil) como Elite. Os limites originais são METs convertidos por 3,5 para ml/kg/min. São referências gerais de aptidão cardiorrespiratória de adultos submetidos a teste em esteira, não faixas de ranking competitivo, diagnóstico ou garantia de desempenho.
- Cooper mantém a equação de campo VO₂máx = 22,351 × distância em km − 11,288. A entrada exige distância mensurável, idade, referência fisiológica e data recente; a estimativa não é uma medição laboratorial.
- Adicionada opção de teste de 3 km em mm:ss. Usa Aandstad (Journal of Sports Sciences, 2021): homens 17,5 + 2,57 × velocidade média em km/h; mulheres 14,6 + 2,48 × velocidade. O estudo incluiu adultos de 18–39 anos; a opção é bloqueada fora dessa faixa. Erro padrão de estimativa publicado: 3,3 e 2,6 ml/kg/min, respectivamente. As zonas operacionais do aplicativo são derivadas por equivalência matemática com a referência Cooper e permanecem estimativas de treino, não limiares medidos.
- O catálogo de metas é filtrado pela classe: Iniciante (3 km, 5 km, saúde), Intermediário (milha a meia maratona e saúde), Performance (até maratona e saúde), Elite (inclui ultradistâncias). “Outro objetivo” não é oferecido no novo onboarding; rótulos antigos continuam sendo lidos para compatibilidade de backup, mas só podem ser usados após revisão para meta permitida.
- A prescrição separa nível fisiológico de tolerância atual. O formato corrida/caminhada depende de volume real e maior sessão recente, não do rótulo Iniciante. Com teste válido, o bloco ativo usa faixa individual de Z2, com recuperação caminhando e aquecimento/desaquecimento Z1. Sem teste válido, não inventa pace e usa orientação por esforço até a calibração.
- Iniciante sem histórico pode deixar volume semanal e maior corrida em branco: dose inicial conservadora de 2 km por dia disponível (limitada a 4–8 km/semana) e maior sessão de referência de 2 km. O motor aumenta a dose apenas conforme a tolerância registrada. Outros níveis podem informar 0 km explicitamente quando estiverem sem corrida recente.
- Removidos do fluxo visível os códigos técnicos de atenção e os parágrafos de diagnóstico duplicados. O perfil mostra resumo curto; a tela Plano não repete a justificativa integral; quando uma instalação V64 aguarda recálculo, a leitura antiga é ocultada até que a prescrição seja atualizada.
- Migração de V64: perfis com avaliação de campo sem idade/referência anexadas podem reutilizar os dados atuais do perfil para classificar a avaliação mais recente; sem dados suficientes, exibem “Aguardando teste”. Se a nova classe bloquear a meta antiga, o aplicativo direciona à revisão de meta antes de recalcular. Histórico, feedbacks, treinos concluídos e âncora do ciclo são preservados; somente sessões futuras são regeneradas.
- `versionCode = 65`, `versionName = V65`, `engineVersion = 51`, Backup Schema 2; `AppBackupManager` grava `appVersion = V65`. A migração marca planos V64 (engineVersion 50) para revisão/recálculo.
- Testes adicionados/atualizados para tabela etária e limites, método 3 km, parser mm:ss, metas por nível, experiência sem alteração de classe, distribuição de Performance e corrida ativa Z2 para iniciante com teste válido. Gradle/JUnit completo e APK Android ainda dependem do GitHub Actions; não são declarados aprovados neste pacote local.


## V64 — correções de integração pós-auditoria da V63 (17/11/2026)

- Separadas a data planejada da sessão e a data real da atividade. GPX/FIT/TCX com timestamp alimentam carga, prontidão, velocidade crítica, calibração e evolução pela data local real; resultados manuais vinculados a prova usam a data oficial dela. Ao substituir um arquivo, metadados e segmentos ausentes no novo arquivo não reaproveitam valores antigos; registros legados continuam com fallback compatível sem sobrescrever a data planejada.
- Painel planejado versus realizado agora usa a data efetiva da atividade para os quilômetros reais, preservando a data do calendário apenas para a parte planejada/aderência.
- Cada feedback permite confirmar o terreno efetivo da sessão (rua, pista, trilha ou misto); o terreno persistido alimenta carga, monitoramento e comparações. Registros antigos sem esse campo são mantidos como mistos, sem inferência retrospectiva.
- Feedback permite vincular explicitamente uma atividade a uma prova cadastrada. O vínculo só é aceito com distância e duração reais, marca a prova como concluída, usa a data oficial da prova quando o resultado é informado manualmente sem timestamp e torna a observação elegível como evidência de prova/teste; o motor fisiológico ainda aplica os critérios de esforço, dor, recência, distância, duração e diversidade antes de usar o resultado.
- Corrigido o mapeamento sRPE: a opção atual de feedback “Ok” agora corresponde a RPE 5 (moderado), sem quebrar a compatibilidade com registros antigos salvos como “Moderado”.
- Importador GPX/FIT/TCX gera segmentos de pace com base em distância e timestamps consecutivos válidos. O tempo medido em zonas é persistido com a faixa usada no momento do registro e agregado separadamente das estimativas baseadas em parciais; lacunas de dados permanecem desconhecidas.
- Importação e entrada manual aceitam duração até 48 horas, alinhadas ao limite do motor de carga, para não descartar ultradistâncias longas.
- Restauração de backup aceita macrociclos de 4 a 52 semanas. Testes atualizados para `appVersion = V64` e adicionados casos de 4/8/16/20/36/52 semanas, rejeitando 53 semanas.
- `versionCode = 64`, `versionName = V64`, `engineVersion = 50` e Backup Schema 2. A instalação V64 identifica planos salvos em engineVersion 49 e sinaliza a necessidade de atualização; quando o corredor solicita o recálculo, somente sessões de hoje em diante são regeneradas, preservando treinos concluídos, feedbacks, histórico e âncora do ciclo. Os novos campos são opcionais e restauráveis; dados anteriores continuam preservados.
- Testes de regressão adicionados para resolução de data real (incluindo migração legada), alocação de segmentos temporizados e atividades de 48 horas. A execução Gradle/JUnit e o build Android completo continuam dependentes do GitHub Actions, não disponíveis no ambiente desta edição. Foi acrescentada regressão explícita para a migração de engineVersion 49→50.

## V63 — inteligência integrada de treinamento, carga e desempenho (17/11/2026)

- Evoluída a camada fisiológica com estimativa de velocidade crítica de campo baseada em pelo menos três esforços/provas recentes, diferentes e comparáveis. A estimativa é complementar, não substitui limiares laboratoriais e não altera zonas automaticamente.
- Adicionada projeção de tempo-alvo por desempenho recente, com limite de extrapolação de distância e uso exclusivamente secundário; a referência de pace só aparece quando cabe na faixa completa da zona do segmento e nunca substitui o alvo fisiológico.
- `LoadPrescriptionEngine` passa a combinar consistência das últimas quatro semanas, confiabilidade de histórico, recuperação, fadiga, RPE médio, tendência sRPE e teto de volume de referência. Progressões são guardrails de produto, não percentuais universais; a carga inicial permanece baseada no volume real. O teto não força redução de uma base já superior à referência.
- `TrainingLoadEngine` integra duração, RPE×duração, frequência cardíaca, cadência, elevação e tempo em zonas medido/estimado em janelas de 7, 28 e 42 dias. Tempo em zonas derivado de parciais é identificado como estimativa.
- `PerformanceMonitoringEngine` compara rodagens por tipo e terreno e considera elevação quando há amostra suficiente. Tendências de pace são sinais de revisão, não recalibração automática.
- `TrainingPeriodizationEngine` mantém períodos de até 52 semanas, com fase e objetivo específicos; provas A comandam o macrociclo/taper, enquanto provas B/C não desmontam a preparação principal.
- `EvolutionScreen` recebeu painel planejado versus realizado em 28 dias, quilômetros efetivamente registrados, sessões concluídas e aderência por sessão. Conclusão sem distância real não infla o volume realizado.
- Campos de intenção do objetivo, tempo-alvo e terreno passam pela geração do plano; terreno trail evita pace plano. Os campos novos permanecem opcionais e compatíveis com backup Schema 2.
- App `versionCode = 63`, `versionName = V63`, `engineVersion = 49`; `AppBackupManager` grava `appVersion = V63`. A migração recalcula somente sessões futuras e preserva histórico, feedback e ciclo.
- Validação no ambiente de edição: compilação Kotlin/JVM dos motores de domínio; harness integrado confirmou velocidade crítica estimada, teto de carga, métricas de 7/28/42 dias e geração de plano de 12 semanas/36 sessões com conferência de segmentos. Gradle/JUnit oficial e build Android completo ainda devem ser executados no GitHub Actions.

## V62 — matriz integrada de prontidão, frequência e volume (16/11/2026)

- Adicionado `RunnerReadinessEngine`, que conecta objetivo (milha/3 km e 5 km, 10 km, 15 km, meia maratona, maratona, ultra 50 km e Saúde), nível declarado, duração de prática regular, frequência escolhida, média real semanal, maior corrida recente e semanas ativas nas últimas quatro semanas.
- Criada matriz explícita de referência de volume e frequência por objetivo e nível. As faixas são referências de engenharia informadas por padrões observacionais, não mínimos fisiológicos universais ou metas obrigatórias.
- O primeiro volume prescrito permanece no histórico real; a matriz nunca força o corredor a saltar para o limite inferior da faixa. Volume zero e zero semanas ativas entram em reintrodução por dose baixa/tempo.
- O cadastro distingue experiência acumulada de condição atual. Intermediário exige pelo menos 12 meses regulares; Avançado, 36 meses; Elite exige 60 meses e evidência adicional de consistência, volume e maior sessão recente. Quando a duração não é conhecida em perfis legados V61, o motor aplica um nível operacional abaixo do declarado; quando a duração é conhecida, usa o maior nível compatível com os meses informados. Elite sem evidência de carga nunca recebe a faixa Elite.
- A frequência selecionada de 2–6 dias permanece como decisão do corredor. A matriz informa a frequência de referência e gera explicações quando a escolha está abaixo/acima dela, sem alterar silenciosamente os dias. Quando seis atividades medidas abrangem pelo menos três semanas distintas, o histórico também prevalece sobre a autoavaliação de semanas ativas.
- Consistência desconhecida em backup antigo permanece desconhecida, não é preenchida por suposição. Sem semanas ativas declaradas ou histórico medido confiável (ao menos seis atividades em três semanas distintas), o motor não libera sessões de qualidade, Z3, limiar ou VO₂; mantém sessões aeróbias e a frequência escolhida. Uma a duas semanas ativas reduzem a confiança da avaliação e mantêm os estímulos de qualidade restritos.
- A recomendação de volume diferencia a média real de entrada da dose efetiva de reintrodução. Quando o histórico é zero, a mensagem explica a reintrodução por tempo/dose baixa e não afirma que o primeiro volume semanal seja zero nem que a matriz de objetivo deva ser atingida imediatamente.
- Onboarding atualizado dentro das etapas existentes: duração de prática regular, semanas ativas das últimas quatro semanas, recomendação de frequência/volume e resumo da avaliação de prontidão antes da criação do plano.
- `CoachEngine` recebe o nível operacional avaliado; `TrainingPeriodizationEngine` restringe estímulos de limiar/VO₂ quando a consistência conhecida é inferior a três semanas ativas, preservando os demais critérios de volume, distância recente, zona e recuperação.
- `AppBackupCodec` persiste `runningExperienceDuration` e `activeWeeksLast4`; Schema 2 permanece inalterado. Backups anteriores sem os campos continuam válidos e mantêm os dados ausentes como desconhecidos.
- Migração `engineVersion = 47` e app `versionCode = 62`, `versionName = V62`; sessões futuras podem ser recalculadas sem reiniciar o ciclo, alterar treinos concluídos, histórico ou feedbacks.
- Motores Kotlin de domínio compilados em conjunto com Kotlin/JVM, isolando Android/Compose e usando modelo `Workout` de suporte porque o modelo de UI está declarado em `MainActivity.kt`; harness adicional percorreu 160 combinações (8 objetivos × 4 níveis × 5 frequências), com geração de oito semanas e conferência da soma de distâncias de cada sessão. Também foram verificados os guardrails para experiência legada desconhecida e a restrição de qualidade quando a consistência não é comprovada. A suíte Gradle/JUnit oficial e o APK Android completo dependem do GitHub Actions.

## V61 — motor integrado de periodização e prescrição específica (16/11/2026)

- Adicionado catálogo de objetivos por distância: milha, 3 km, 5 km, 10 km, 15 km, meia maratona, maratona, ultramaratona de 50 km, saúde/qualidade de vida e distância personalizada de 1 a 100 km. Rótulos antigos permanecem compatíveis com backups anteriores.
- Adicionado motor de macrociclo com fases BASE, DEVELOPMENT, SPECIFIC e RECOVERY. A escolha de sessões considera objetivo, distância, fase, nível, frequência, volume semanal, maior corrida recente, recuperação, fadiga e dor.
- Ampliada a biblioteca/geração de estímulos: intervalado aeróbio Z2, Z2–Z3, misto Z3–Z4, misto Z4–Z5, piramidal Z3–Z5, fartlek, tempo/limiar, resistência específica de maratona e ultradistância. Subidas continuam condicionais a percurso/elevação conhecida; strides são complementares e força permanece opcional, sem inclusão automática no calendário.
- Intervalados gerados usam recuperações aeróbias em Z2 (faixa ativa 0–20%); blocos Z4/Z5 são limitados a perfis experientes com volume, maior sessão recente e recuperação documentados. Z4/Z5 continuam estimativas de campo e não são apresentadas como LT2/VO₂máx medidos.
- Objetivo Saúde e Qualidade de Vida passa a ser categoria própria: mantém a frequência selecionada, prioriza sessões fáceis e não aciona automaticamente limiar, VO₂ ou Z3 de qualidade.
- Longão específico por distância é limitado por histórico recente e teto de objetivo; ultradistância prioriza tempo em movimento, Z2 sustentável e estratégia corrida/caminhada, sem adicionar alta intensidade automaticamente.
- Prioridades competitivas A/B/C aplicadas em todos os caminhos: somente A define o macrociclo e pode acionar taper/recuperação pós-prova; B substitui uma sessão na semana do evento sem taper ou recuperação automática; C entra como evento de treinamento e substitui uma sessão sem desmontar o ciclo. Migração/restauração também considera somente A como prova principal.
- Corrigida a consistência de paces e segmentos em taper e recuperação pós-prova: o pace numérico agora corresponde à faixa ativa Z1 80–100%, e não à zona inteira.
- `TrainingPrescriptionAudit` agora verifica soma de distâncias, faixa de pace, limites da zona, coerência entre nome e zona do segmento, correspondência entre faixa percentual e pace apresentado e uso indevido de alta intensidade em recuperações.
- Atualizados os fluxos de objetivo, periodização e exportação; backup Schema 2 permanece inalterado. `versionCode = 61`, `versionName = V61`, `engineVersion = 46`. A migração atualiza sessões futuras, preservando âncora, semanas, histórico, feedbacks e sessões concluídas.
- Teste de execução Kotlin dos motores centrais: 8 objetivos × 8 semanas (256 sessões) com validação de segmentos; frequências 2–6; provas A/B/C; fartlek; intervalados mistos; objetivo de saúde; alternativas de sessão. Resultado: aprovado. Compilação Android completa ainda depende do workflow GitHub Actions.


## V60 — Estrutura integral das sessões e recuperação coerente (16/11/2026)

- A tela de sessão apresenta todos os blocos, sem limitar a prévia aos quatro primeiros; aquecimento, recuperações e desaquecimento deixam de ficar ocultos.
- Blocos-alvo por tempo exibem também a distância estimada total e, quando repetidos, a distância estimada por repetição.
- A tela exibe a soma estimada dos segmentos ao lado da distância total prescrita para facilitar a conferência.
- Recuperações de fartlek, limiar e VO2 passam de Z1 para a faixa confortável Z2 0–20%, mantendo Z1 reservada ao aquecimento/desaquecimento e às sessões regenerativas.
- A duração dos blocos por tempo passa a ser calculada pelo pace médio da faixa ativa real, não pelo pace médio da zona completa.
- Fartlek ajusta número de repetições ao nível e ao orçamento de distância, com cerca de 40% do bloco principal em estímulo e 60% em recuperação aeróbia; o alvo de recuperação não fica mais lento que o desaquecimento Z1.
- Corrida sustentada e sessão específica de maratona só introduzem Z3 quando os critérios de experiência, volume, corrida recente e recuperação permitem; sem elegibilidade, permanecem em Z2.
- Metadados `stimulus` de corrida sustentada e resistência específica agora acompanham a zona realmente prescrita (Z2 ou Z2–Z3); o estado interno não indica Z3 quando os segmentos não a contêm.
- versionCode/versionName passam a 60/V60; engineVersion passa a 45 para recalcular apenas sessões futuras, sem reiniciar semanas, alterar sessões concluídas ou feedbacks.
- Backup identifica `appVersion = V60`; Schema 2 preservado.

## V59 — progressões/regressões Z2–Z3 e faixas ativas revisadas

- `versionCode = 59`, `versionName = V59`; `engineVersion = 44` força a regeneração das sessões futuras com o novo modelo, preservando histórico, âncora e duração do ciclo. Backup permanece schema 2.
- Progressivos e regressivos deixam de usar Z1 como bloco principal. A parte principal passa a usar exclusivamente Z2 e, quando houver elegibilidade, Z3. A Z1 permanece para aquecimento, desaquecimento e sessões regenerativas; os blocos corrida/caminhada de iniciantes seguem por tempo e esforço percebido.
- Progressivo elegível: Z2 confortável (0–20% da zona) → faixa mais rápida de Z2 (20–100%) → Z3 controlada (0–40%). Regressivo: sequência inversa Z3 → Z2 rápida → Z2 confortável. Quando Z3 não é elegível, os blocos progridem/regredem dentro da Z2, sem forçar intensidade.
- Em rodagens aeróbias, Z3 pode entrar a partir de perfil intermediário, volume recente ≥16 km/semana, maior corrida recente ≥8 km, zonas válidas e ausência de dor/fadiga ou sinal de recuperação desfavorável. Sem os requisitos, a variação permanece em Z2.
- No longão, mantém-se o gate mais restritivo: Avançado/Elite, volume ≥25 km/semana, maior corrida recente ≥12 km, longão planejado ≥8 km, zonas válidas e recuperação adequada. Quando liberada, Z3 ocupa no máximo 12% da parte principal; a maior parte segue em Z2.
- Aquecimento e desaquecimento em Z1 passam a usar a extremidade mais rápida da zona (80–100%). A faixa de transição mais confortável da Z2 (0–20%) é aplicada ao início/final dos progressivos e regressivos. A escala permanece interna à zona e não representa %VO₂máx.
- As bandas ativas explícitas de cada etapa são preservadas pelo `ZoneIntensityBandEngine`, inclusive ao reabrir/selecionar uma sessão. Semana de recuperação continua limitando os blocos principais, sem deslocar aquecimento/desaquecimento Z1 para o lado lento.
- A divisão por etapas distribui a distância em décimos de quilômetro e atribui o último restante ao último bloco, garantindo que a soma corresponda à distância principal prescrita. Progressivos/regressivos com distância principal curta demais permanecem contínuos, sem criar blocos inviáveis.
- A sessão de qualidade do tipo progressivo também utiliza o novo construtor Z2/Z3, evitando manter um caminho legado com faixas completas de zona.
- Adicionados/atualizados testes para progressão monotônica de pace, regressão monotônica, continuidade nas fronteiras Z2/Z3, Z1 80–100% no aquecimento/desaquecimento, ausência de Z1 na parte principal, restrição de Z3, soma exata das distâncias e migração engine 43→44.

## V58 — importação de backup na tela inicial

- A tela de abertura agora oferece duas ações explícitas: **Começar Novo Plano** e **Importar Backup**.
- O seletor de arquivos usa Android Storage Access Framework (`OpenDocument`) e aceita JSON de backup.
- Antes de restaurar, apresenta confirmação clara de que os dados locais serão substituídos.
- Reutiliza `AppBackupManager.restore` e `AppBackupCodec`: valida formato, assinatura SHA-256, manifesto, contagem dos registros e compatibilidade do schema antes de gravar.
- Em caso de arquivo inválido, mantém o usuário na tela inicial e apresenta o erro; em caso de sucesso, abre o aplicativo com o backup restaurado e a mensagem de resultado na tela de Backup.
- Mantém o botão de importação existente em Backup e restauração para uso posterior.
- `versionCode = 58`, `versionName = V58`; `engineVersion = 43` e backup `schemaVersion = 2` permanecem inalterados porque esta revisão altera somente o fluxo de entrada/importação.

## V57 — recálculo fiel do ciclo, frequência selecionada e prontidão atualizada

- `versionCode = 57`, `versionName = V57`, `engineVersion = 43`; schema do backup permanece 2 e o backup passa a identificar `appVersion = V57`.
- Recalcular com plano existente preserva a âncora original e a duração do ciclo. O motor atualiza zonas e sessões a partir de hoje, mantém as sessões históricas/concluídas e renumera semanas em relação à segunda-feira original. Um novo ciclo só começa quando não existe plano ou o ciclo anterior expirou.
- Dashboard e tela Plano usam a mesma função de semana atual. O cartão inicial deixa de exibir o rótulo fixo “semana 1” e informa a semana calculada pela âncora do ciclo.
- A frequência de 2 a 6 dias marcada pelo corredor é mantida também para iniciantes/reentrada. O nível altera dose, formato corrida/caminhada e elegibilidade de intensidade, mas não reduz silenciosamente a quantidade de dias prescritos. Racional e flags antigas de “máximo três sessões” foram corrigidos.
- “Consultar treinador para esse dia” e opções de treino extra aparecem somente em datas livres/descanso; a camada de domínio também recusa consulta/inclusão em dia ocupado ou de competição. Nenhum treino é adicionado automaticamente.
- Opções extras passam a considerar volume semanal, maior corrida recente, feedback de dor/fadiga e sessão exigente próxima. Quando volume de referência ≥14 km/semana e maior corrida recente ≥7 km, podem chegar a 3–5 km mesmo em perfil identificado como iniciante, mantendo corrida/caminhada e duração mais conservadora quando aplicável. Dor, fadiga e proximidade de qualidade reduzem a distância sugerida e elevam o alerta; a decisão continua com o corredor.
- Cards Recuperação e Segurança são calculados ao vivo com até os três feedbacks mais recentes dos últimos 14 dias: esforço/RPE, sensação e dor. Um único feedback bom não basta para declarar “Boa / Sem alerta”; são necessárias pelo menos duas observações confortáveis. Um sinal de cansaço/esforço alto gera estado moderado e atenção amarela; duas sessões afetadas geram recuperação baixa/amarelo; qualquer dor gera alerta vermelho. São heurísticas subjetivas, não diagnóstico e não estimam sono, HRV ou FC de repouso.
- Feedback e recálculo mantêm calibração independente: Z1 exige três sessões regenerativas válidas em até 42 dias; Z2 exige três observações válidas do teste da fala; Z3 exige dois testes Cooper separados por pelo menos 14 dias e consistentes. O recálculo aplica somente zonas com evidências suficientes às sessões de hoje em diante; atividade comum não vira teste Cooper.
- Adicionados testes para semana 2 após backup, preservação do ciclo ao recalcular, frequência de iniciantes entre 2 e 6 dias, opções de 3–5 km com base suficiente, redução por dor/fadiga/sessão exigente, dia ocupado e prontidão.

## V56 — compatibilidade do parser XML Android

- Corrige a compilação Kotlin removendo referências diretas a `XMLConstants.ACCESS_EXTERNAL_DTD` e `XMLConstants.ACCESS_EXTERNAL_SCHEMA`, ausentes em alguns Android SDK stubs.
- Mantém a proteção XML com rejeição explícita de DOCTYPE, desativação best-effort de entidades externas e resolvedor de entidades vazio; propriedades JAXP opcionais passam a usar URIs literais compatíveis com a compilação Android.
- Preserva importação GPX/FIT/TCX, distribuição semanal, variação aeróbia, restauração de backup e calibração Z1–Z3 da V55.
- `versionCode = 56`, `versionName = V56`; `engineVersion = 42` e schema do backup permanecem inalterados.

## V55 — correção do importador RunnerUp, ordem semanal e variedade aeróbia

- `versionCode = 55`, `versionName = V55`, `engineVersion = 42`; backup passa a identificar `appVersion = V55`. O schema do backup permanece 2 porque a estrutura dos registros não mudou.
- Corrigida a falha GPX em Android: a configuração `disallow-doctype-decl` deixou de ser obrigatória no provedor XML. Recursos de segurança opcionais são aplicados quando suportados, a declaração `DOCTYPE` é rejeitada explicitamente e entidades externas são bloqueadas pelo resolver.
- Compatibilidade específica com exportações RunnerUp/PaceCoach: leitura dos totais oficiais `pacecoach:activity` (distância e duração), horário de início em `metadata/time` e parciais de quilômetro `pacecoach:lap`. Pontos GPS continuam sendo usados para percurso e elevação; FC/cadência só são preenchidas quando o arquivo realmente contém esses campos.
- Validação com os dois GPX anexados: atividade de 11/11 = 4,970 km, 37:03, pace médio 7:27 min/km e elevação positiva estimada de 90,5 m; atividade de 13/11 = 6,616 km, 49:27, pace médio 7:28 min/km e elevação positiva estimada de 119,5 m. Os dois arquivos não contêm FC nem cadência, portanto esses campos permanecem vazios.
- Ordem semanal corrigida: com disponibilidade segunda/quarta/sexta e longão na sexta, a rodagem leve fica na segunda, a qualidade vai para quarta e o longão permanece na sexta. O desempate antigo que colocava qualidade na segunda foi removido.
- Rodagens aeróbias alternam, conforme o microciclo, contínua Z2, progressiva Z1→Z2 e regressiva Z2→Z1; semanas regenerativas mantêm intensidade reduzida em Z1.
- Longões deixam de ser sempre contínuos: alternam contínuo Z2, progressivo Z1→Z2 e regressivo Z2→Z1. Um bloco final curto em Z3 (predominância Z2, com aquecimento/desaquecimento em Z1) é condicional a atleta avançado/elite, volume semanal ≥25 km, maior corrida recente ≥12 km, longão prescrito ≥8 km e zonas individualizadas disponíveis. Para os demais perfis, Z3 não é introduzida no longão.
- Semana corrente na interface é calculada pela distância entre a segunda-feira original do ciclo e a data atual. A tela Plano abre por padrão a semana atual e não marca a semana 1 histórica como "em andamento"; o Dashboard resume a semana corrente.
- Restauração: o backup passa a ser a fonte autoritativa do passado. A migração mantém sessões históricas que realmente existem no arquivo e regenera somente hoje e datas futuras dentro do ciclo original. Uma sessão passada ausente do backup não é inventada; a âncora e a numeração das semanas continuam preservadas.
- Adicionados testes de regressão para a exportação RunnerUp, rejeição de DOCTYPE, qualidade no meio da semana, variações de rodagem/longão, gate de Z3 e restauração sem criar treino passado ausente.

## V54 — restauração integral do ciclo e autonomia na inclusão de treinos extras

- Incrementa `versionCode = 54`, `versionName = V54` e `engineVersion = 41`.
- Ao importar backup V53/V52/V51, a migração preserva a segunda-feira original de início do ciclo. A semana anterior não é descartada nem rebatizada como se o plano tivesse começado na data de importação.
- A reconstrução do backup regenera o calendário completo do ciclo original (incluindo sessões prescritas de semanas anteriores que estejam ausentes), mantém feedbacks e sessões concluídas/pendentes já salvas e normaliza `week` pela data em relação à âncora original.
- Se `planStartDateIso` já tiver sido reancorado, a âncora é inferida pelas datas e semanas das sessões (inclusive com fallback para duas sessões na semana imediatamente anterior); a duração original de `planWeeks` é preservada. Taper/substituições de prova não reescrevem sessões históricas.
- Backup passa ao schema 2 com manifesto de integridade SHA-256 e contagens de sessões, feedbacks, avaliações Cooper e competições. Arquivos schema 1 continuam aceitos; arquivos schema 2 incompletos/alterados são recusados antes de limpar as preferências locais.
- A consulta de treino extra não bloqueia por sessão futura pendente, limite semanal, treino extra prévio, proximidade de sessão exigente, dor ou fadiga. Datas futuras distantes também continuam disponíveis com aviso de menor precisão; somente datas passadas ficam fora do agendamento. Exibe os fatores como alertas/riscos; a inclusão é voluntária e não substitui nem apaga sessões principais.
- A opção de sessão extra também pode ser consultada em datas que já possuem compromisso, com aviso de que será uma segunda sessão no dia.
- Dor recente e fadiga elevada aparecem como alertas de risco alto; competição, frequência semanal e sessões próximas aparecem como riscos moderados. Datas futuras além de 14 dias continuam disponíveis, acompanhadas de aviso de que a recomendação é preliminar; datas passadas não podem receber novas sessões.
- Testes adicionados para restauração da âncora, reconstrução/numeração das semanas, manifesto de backup, hash anti-alteração e recomendações sem bloqueios indevidos.

## V53 — correção de compilação Kotlin (roundToInt)
- Corrigido o erro `Unresolved reference: roundToInt` em `MainActivity.kt`, adicionando a importação explícita `kotlin.math.roundToInt` usada na exibição do ganho de elevação da atividade importada e no histórico do feedback.
- Os cálculos e os dados de elevação não foram alterados; apenas a resolução da extensão Kotlin foi corrigida.
- `versionCode = 53`, `versionName = V53`, `engineVersion = 39`; mantém integralmente as funcionalidades e a migração de dados da V52.

## V52 — importação de atividades e calibração independente Z1–Z3
- Adicionado importador offline por sessão para GPX, FIT e TCX, com distância, duração/pace quando calculáveis, elevação, percurso, parciais e métricas de FC/cadência quando presentes.
- Métricas ausentes permanecem vazias; GPX sem timestamps pode fornecer percurso/distância, mas não recebe duração ou pace inventados. FIT valida assinatura e tamanho declarado antes de interpretar mensagens.
- A conclusão da sessão mantém feedback subjetivo separado dos dados importados. Metadados da atividade, fingerprint SHA-256 e rota compactada são persistidos no histórico e no backup; duplicatas da mesma atividade em outra sessão são bloqueadas.
- Z1 passa a usar ao menos três sessões regenerativas recentes, sem dor e consistentes (incluindo os rótulos Recuperação, Regenerativa e RECOVERY); Z2 exige três observações válidas do teste da fala; Z3 exige dois Cooper separados por 14 dias ou mais e com variação máxima de 8%. Corridas comuns não são tratadas como testes máximos.
- Adicionados estados por zona (INITIAL, OBSERVATION, CALIBRATED, REVIEW, UNSTABLE), continuidade obrigatória entre Z1–Z5 e suavização persistida de até 15 s por fronteira a cada atualização.
- Dor tem prioridade na orientação do feedback, bloqueia progressão automática de carga/intensidade e exclui a observação de calibração.
- Adicionada documentação `PACE_ZONE_METHODOLOGY_V52.md` e testes para GPX/TCX/FIT, dados ausentes, FIT com campos de desenvolvedor, rejeição de FIT inválido/truncado, calibração independente e limite de 15 s. Correções manuais de distância/tempo são aplicadas; reabrir feedback sem alterar os campos preserva a precisão integral importada.
- `versionCode = 52`, `versionName = V52`, `engineVersion = 39`; base V51 mantida e ZIP canônico `AI-Running-Coach.zip` preservado.

## V51 — padronização responsiva dos cartões e campos de competição
- Cartões de métricas passaram a usar hierarquia vertical uniforme (ícone, rótulo em até duas linhas, valor e complemento), eliminando truncamento horizontal dos títulos "Programadas", "Concluídas" e outros rótulos em telas estreitas.
- Campos de distância/data e tempo-alvo/local usam larguras equivalentes e rótulos mais claros; observações têm área maior para leitura e edição.
- Seletores de prioridade A/B/C foram redesenhados como cartões equivalentes com código e descrição em linhas separadas, sem texto abreviado/cortado.
- Cartões das competições cadastradas passaram a separar nome, prioridade/status, distância/data, tempo/local e ações em blocos consistentes; nomes e locais quebram linha em vez de serem truncados.
- Pílulas de status aceitam duas linhas e centralizam o texto para evitar cortes em dispositivos estreitos.
- Nenhuma regra de competições, calendário, prescrição ou dados persistidos foi modificada; alteração exclusivamente visual.
- `versionCode = 51`, `versionName = V51`, `engineVersion = 38`; backup identifica `appVersion` V51. ZIP canônico `AI-Running-Coach.zip` preservado.

## V50 — correção de migração, opções contextuais e modernização de competições
- A versão do motor foi incrementada para 38, garantindo que backups gerados na V49/engine 37 acionem a migração do plano para as regras atualizadas.
- Na regeneração, todas as sessões com data anterior a hoje são preservadas no calendário/histórico mesmo quando um backup legado não registrou corretamente `done` ou o feedback. Sessões com feedback continuam sendo marcadas como concluídas; sessões sem confirmação não são falsamente marcadas como realizadas.
- Se um backup legado tiver somente o rótulo textual da sessão (por exemplo, "Sexta-feira, 13/11") e não tiver `scheduledDateIso`, a data é reconstruída usando o início do plano para que a sessão histórica continue aparecendo na agenda.
- A sessão de sexta-feira não é descartada durante a migração do plano; as sessões futuras são regeneradas sem sobrescrever o histórico.
- A consulta de dia livre apresenta duas escolhas quando os dados permitem: opção leve Z1/RPE 2–3 e rodagem aeróbia normal Z2/RPE 3–4. O corredor escolhe explicitamente; a opção normal informa a carga e os riscos adicionais. Nenhuma sessão é adicionada automaticamente.
- Treinos anteriores não concluídos não são transferidos nem usados como prova de carga realizada, mas também não bloqueiam automaticamente uma opção voluntária. Sessões futuras anteriores à data consultada ainda precisam ser registradas; dor, fadiga elevada, prova, sessão exigente recente e limite semanal continuam protegidos.
- A evolução substitui rótulos ISO opacos (ex.: S46) pelo intervalo real de segunda a domingo (ex.: 09–15/11), inclusive em semanas que cruzam mês ou ano.
- A tela de competições foi reorganizada com resumo compacto, campos padronizados, agrupamento consistente de data/distância e tempo/local, hierarquia visual e cards uniformes para provas cadastradas; ações de edição, conclusão e exclusão foram preservadas.
- Adicionados testes para retenção de sessões históricas, opções leve/normal em semana de baixo volume e rótulos de semana por intervalo de datas.
- `versionCode = 50`, `versionName = V50`, `engineVersion = 38`; backup identifica `appVersion` V50. ZIP canônico `AI-Running-Coach.zip` preservado.

## V49 — migração de backup e adaptação contextual em dias livres
- Ao importar backup de V48/engineVersion 36 ou anterior, o aplicativo carrega primeiro todos os dados e, quando o perfil está completo, regenera automaticamente somente o planejamento futuro com o motor atualizado.
- Sessões concluídas (incluindo as identificadas por feedback, mesmo que o flag `done` legado esteja falso), feedbacks, Cooper, competições e preferências permanecem preservados.
- A migração evita duplicar sessões em datas que já contenham treinos concluídos ou extras opcionais.
- Calendário: ação "Consultar treinador para este dia" em datas livres atuais/futuras. A recomendação avalia semana de segunda a domingo, sessões previstas/concluídas, atividade recente, feedback, dor, fadiga, prova, volume semanal e maior corrida recente.
- Política conservadora: não repõe treino perdido; não sugere qualidade no dia extra; dor, fadiga elevada, treino exigente ou longão dentro de dois dias de calendário (margem conservadora porque o horário exato não é armazenado), prova, três sessões na semana ou ausência de referência de carga resultam em recomendação de descanso.
- Quando elegível, cria somente uma sessão adicional curta em Z1/RPE 2–3, com confirmação explícita. A sessão recebe identidade `isOptionalExtra`, entra no histórico/calendário e é preservada em futuras recalibrações.
- Adicionados testes para a sugestão no cenário de duas sessões semanais, sinais de dor/fadiga, prova, proximidade de qualidade, limite de frequência e preservação de duas sessões concluídas após migração.
- `versionCode = 49`, `versionName = V49`, `engineVersion = 37`; backup identifica `appVersion` V49. ZIP canônico `AI-Running-Coach.zip` preservado.

## V48 — correção da área segura do ícone Android
- Corrigida a proporção do ícone adaptativo: corredor e arco ciano agora ficam centralizados dentro da área segura, evitando cortes em máscaras circulares, arredondadas e em lançadores de fabricantes.
- Aplicada a mesma escala segura nas versões raster quadrada e arredondada em mdpi, hdpi, xhdpi, xxhdpi e xxxhdpi.
- Atualizadas as referências PNG de design para refletir a versão com margem segura.
- Mantidos fundo azul-marinho, corredor branco, arco ciano, nome do aplicativo e identidade minimalista.
- Nenhuma lógica de treino ou dado do usuário foi alterado.
- `versionCode = 48`, `versionName = V48`, `engineVersion = 36`; o backup passa a identificar `appVersion` V48.

## V47 — correção de compilação da calibração Cooper
- Corrigida a referência não resolvida `previousCooperDistance` em `MainActivity.kt`, que impedia o `:app:compileDebugKotlin` da V46.
- Centralizada a busca do Cooper imediatamente anterior à avaliação atual em `CooperAssessmentEngine.previousAssessmentDistance`, considerando histórico fora de ordem e excluindo o resultado do mesmo dia.
- Reutilizada a mesma regra na geração do plano, na prévia das zonas, na leitura atual das zonas e no salvamento de novo Cooper.
- Adicionado teste de regressão para histórico fora de ordem, exclusão da avaliação atual e ausência de resultado anterior.
- `versionCode = 47`, `versionName = V47`, `engineVersion = 36`; backup identifica `appVersion` V47. ZIP canônico `AI-Running-Coach.zip` preservado.

## V46 — persistência do feedback e calibração progressiva das zonas
- Feedback de esforço, sensação, dor e observações é salvo como registro mesmo quando distância/tempo reais não são informados; o commit é síncrono e falhas restauram o estado anterior em memória.
- A tela Evolução lista todos os feedbacks salvos; gráficos de volume e pace usam somente métricas reais preenchidas.
- O pace do teste da fala pode ser salvo sem distância ou duração total; só observações de rodagem aeróbia/longão, confortáveis, com boa sensação e sem dor refinam a Z2.
- A Z2 usa a mediana dos até três registros recentes e consistentes; a atualização exige pelo menos dois e aplica limites conservadores para evitar saltos bruscos. A calibração precisa ser aplicada explicitamente ao plano.
- A prévia do Cooper usa o mesmo suavizador de até 15 s por fronteira que será gravado e aplicado ao plano; avaliações do mesmo dia não são usadas como referência anterior.
- Faixas percentuais ativas permanecem por sessão: escala linear dentro da zona, 100% = pace mais rápido e 0% = pace mais lento. Não representam percentuais de VO₂máx.
- Alternativas limpam metadados da zona anterior antes de aplicar a nova faixa ativa.
- `versionCode = 46`, `versionName = V46`, `engineVersion = 36`; backup identifica `appVersion` V46. ZIP canônico `AI-Running-Coach.zip` preservado.

## V45 — biblioteca auditável e backup/restore completo
- Corrigido layout da biblioteca: texto longo de orientação não ocupa mais a coluna lateral do título; cartões e cabeçalhos foram reorganizados para largura total e leitura em blocos.
- Adicionado status de uso real por tipo: automático, condicional, complementar ou não integrado. A tela deixa claro que subida ainda não é gerada pelo motor.
- Incluída resistência específica de maratona na biblioteca, alinhada ao ramo `MARATHON_SPECIFIC` já existente em `CoachEngine`.
- Criado backup JSON versionado para todos os dados locais persistidos em SharedPreferences, mantendo tipos primitivos e conjuntos de strings.
- Exportação por `CreateDocument`; restauração por `OpenDocument`, com validação anterior à substituição, confirmação e retorno à tela de Perfil.
- Adicionados testes de codec para round-trip, tipos, exclusão de estado transitório, app incorreto e JSON interno inválido.
- `versionCode = 45`, `versionName = V45`, `engineVersion = 35`; ZIP canônico `AI-Running-Coach.zip` preservado.

## V44 — modernização visual do onboarding e sessão
- Tela inicial substitui a seta decorativa pela arte oficial do AI Running Coach em drawable bitmap (1024×1024), reutilizando a mesma identidade visual do launcher sem alterar o launcher.
- Cabeçalho do onboarding compactado em marca horizontal para liberar espaço útil nas etapas.
- Disponibilidade semanal reorganizada em botões de dia com seleção azul consistente, hierarquia simplificada e preferência do longão separada visualmente; regras de seleção e persistência preservadas.
- Etapa do Cooper reorganizada em painel compacto com campos, prévia de métricas, zonas e aviso de segurança resumido; controles, validação, cálculos e data do teste preservados.
- Cartão principal da sessão refeito em três métricas de largura igual (distância, tempo estimado e pace), com rótulos e valores alinhados; sem alteração dos cálculos.
- `versionCode = 44`, `versionName = V44`; `engineVersion = 35` (alteração exclusivamente visual). ZIP canônico `AI-Running-Coach.zip` preservado.

## V43 — precisão da duração e unidade explícita
- Removido piso artificial de 15 minutos: o tempo exibido agora corresponde à soma dos blocos, repetições e respectivos alvos.
- Blocos DISTANCE usam a faixa de pace para estimar a duração; blocos TIME contam somente a duração prescrita, sem duplicar a distância informativa.
- Tela da sessão exibe `~NN min` e o rótulo `Tempo estimado`.
- Migração de sessões estruturadas salvas mantém a recalculação do tempo.
- Histórico de navegação e `BackHandler` Android retornam à tela anterior; rotas de fallback cobrem telas restauradas sem histórico em memória.
- `versionCode = 43`, `versionName = V43`, `engineVersion = 35`; ZIP canônico `AI-Running-Coach.zip`.

## V42 — Tempo estimado por blocos e navegação Android

- Corrigido cálculo do tempo total: soma os tempos explícitos das etapas TIME e estima etapas DISTANCE por distância × pace-alvo médio, considerando repetições.
- Segmentos TIME com distância estimada para carga semanal não são contados duas vezes.
- Planos V41 já salvos têm a duração recalculada no carregamento, sem exigir recriação imediata do plano.
- Rótulo da sessão alterado para “Tempo estimado”; cartões e alternativas usam a mesma nomenclatura.
- Alternativas de treino recalculam o tempo a partir de seus próprios blocos.
- Botão Voltar do Android passa a retornar à tela anterior real; inclui rotas de fallback para telas restauradas e navegação de etapas do onboarding.
- `versionCode = 42`, `versionName = V42`, `engineVersion = 34`; nome canônico do ZIP preservado: `AI-Running-Coach.zip`.

## V41 — Numeração da semana e identificação amigável das exportações
- A semana parcial atual passa a ser sempre Semana 1; as semanas seguintes mantêm a numeração sequencial 2..N. Eliminado o índice de apresentação Semana 0.
- Sessões concluídas da semana corrente são preservadas com `week = 1`; eventos/provas usam a mesma numeração do plano.
- Instalações V40 (`engineVersion = 32`) migram os índices salvos imediatamente (semana 0→1, semana 1→2 etc.) e solicitam recálculo, preservando sessões concluídas.
- A identificação da exportação passa a seguir `S{semana}_T{número do treino}_{nome do treino}_{dd.MM}`.
- O mesmo identificador amigável é exibido na tela de compartilhamento, gravado como `workoutName` no UserWorkoutJson e usado no nome físico do anexo `.json`.
- Nomes de arquivo mantêm acentos e espaços, removendo apenas caracteres reservados de caminho/arquivo.
- Adicionados testes para semana parcial, mapeamento de numeração, nome da exportação e nome do anexo JSON.
- `versionCode = 41`, `versionName = V41`; ZIP canônico `AI-Running-Coach.zip` preservado.

## V40 — Exportação no formato nativo Pace Coach UserWorkoutJson
- Substituído o contrato proprietário `pace-coach-workout` 6.0 pelo envelope `com.garmin.connect.workout.json.UserWorkoutJson`, igual ao modelo do arquivo de treino exportado pelo Pace Coach fornecido como referência.
- O JSON agora possui metadados `workoutId`, `workoutName`, `createdDate`, `updatedDate`, `ownerId`, `sportTypeKey` e lista `workoutSteps`.
- Blocos por tempo são serializados em milissegundos (`endConditionUnitPk=41`, `endConditionUnitKey=ms`); blocos por distância são convertidos para metros.
- Alvos de pace são convertidos para `centimetersPerMillisecond`, mantendo limites de pace em ordem compatível com velocidade crescente.
- Repetições são representadas por `repeat` e etapas filhas com `groupId`/`parentGroupId`; aquecimento, intervalo, recuperação e desaquecimento recebem `stepTypeKey` e `intensityTypeKey` nativos.
- Atualizados testes para validar estrutura compatível, conversão de unidades, pace, repetição e sequência das etapas.
- `versionCode = 40`, `versionName = V40`; ZIP canônico `AI-Running-Coach.zip` preservado.

## V39 — Correção da semana atual na agenda

- O ciclo agora começa na segunda-feira da semana corrente, inclusive quando o plano é criado após segunda-feira.
- Sessões anteriores à data atual não são recriadas nem transferidas para outros dias; somente as sessões ainda futuras da semana permanecem na agenda.
- A semana parcial corrente é exibida como `SEMANA EM ANDAMENTO` (índice 0); semanas completas seguintes passam a ser numeradas a partir de 1.
- Eventos de competição já ocorridos deixam de comandar a nova prescrição; provas hoje ou no futuro continuam podendo ajustar as sessões restantes.
- O seletor de eventos na tela de plano acompanha a nova numeração das semanas.
- `engineVersion = 32` solicita a regeneração dos planos salvos para instalações V38.
- `versionCode = 39`, `versionName = V39`; nome do aplicativo e ZIP canônico `AI-Running-Coach.zip` preservados.

## V38 — Identidade visual simplificada
- Substituído o ícone chamativo anterior por uma composição minimalista: fundo azul-marinho, silhueta branca de corredor e um único arco ciano de movimento.
- Removidos elementos decorativos de IA/chip, GPS, satélite, batimento, cronômetro, gráficos, brilhos e textos do símbolo do launcher.
- Atualizadas as camadas adaptativas Android (fundo e primeiro plano) e as variantes quadrada/arredondada nas densidades mdpi, hdpi, xhdpi, xxhdpi e xxxhdpi.
- Atualizados os arquivos de identidade visual em `design/`; nome exibido `AI Running Coach`, lógica de treinamento, exportação e dados do atleta preservados.
- `versionCode = 38` e `versionName = V38`; nome canônico do ZIP `AI-Running-Coach.zip` preservado.
- A compilação Android completa deve ser confirmada pelo GitHub Actions.

## V37 — Correção da prescrição, periodização e adaptação à carga real
- Aplicada proteção de recuperação também na montagem inicial do calendário: a sessão de qualidade só é prescrita quando há ao menos um dia completo entre ela e o longão; quando a disponibilidade não permite, a qualidade é suprimida e a decisão fica sinalizada.
- Progressivos deixam de ser inseridos como rodagens fáceis ao lado de uma sessão-chave; strides são apenas complemento técnico ocasional, não somado em semanas com qualidade, regenerativas ou para iniciantes.
- Iniciantes e atletas em reintrodução recebem no máximo três sessões semanais estruturadas em corrida/caminhada por tempo, com pausas reais, aquecimento, desaquecimento e progressão gradual.
- Carga real usa atividades concluídas com distância medida, vinculadas à data da sessão (com fallback para a data do feedback em registros antigos). A média de 28 dias só substitui o perfil após pelo menos seis corridas distribuídas por três semanas ISO; a maior sessão dos últimos 30 dias limita a dose individual.
- O limite de 10% por sessão é tratado como guarda conservadora relacionada a tolerância recente, não como regra universal de segurança ou progressão semanal.
- A programação de qualidade agora diferencia 5 km, 10 km, meia maratona e maratona; a maratona passa a incluir bloco específico predominantemente aeróbio, evitando transformar toda sessão-chave em limiar.
- Semanas 4/8 usam redução controlada da carga semanal (alvo de 10–20% em relação à semana de desenvolvimento anterior); o longão regenerativo recebe o nome “Longão aeróbio reduzido” e mantém seu objetivo aeróbio conversável.
- Z5 passa a usar a VAM estimada como referência rápida complementar quando plausível, ou a faixa conservadora Cooper quando não; Z4/Z5 são explicitamente estimadas, sem afirmar limiar ou VO₂máx medido. Modelo de zonas atualizado para AIRC_ZONES_4.
- Biblioteca apresenta duas rotinas opcionais de fortalecimento. Elas não são inseridas automaticamente no calendário de corrida.
- Motor interno atualizado para engineVersion 31, solicitando recálculo de planos antigos ao abrir a nova revisão.
- Adicionados testes para distribuição de dias, semanas regenerativas, corrida/caminhada, carga real, Z5 estimada, especificidade por distância e fortalecimento.
- `versionCode = 37` e `versionName = V37`; nome canônico do ZIP `AI-Running-Coach.zip` preservado.

## V36 — Exportação como arquivo JSON anexado
- Corrigido o compartilhamento da prescrição: o conteúdo deixa de ser enviado por `Intent.EXTRA_TEXT` e passa a ser gravado como arquivo `.json` UTF-8 real.
- O compartilhamento Android agora usa `application/json`, `Intent.EXTRA_STREAM`, `ClipData` e concessão explícita de leitura ao aplicativo receptor.
- Adicionado `FileProvider` com acesso restrito somente à pasta temporária `cache/exports/`; nenhum acesso amplo ao armazenamento é concedido.
- Nome do arquivo: `pace-coach-workout-<sessionId>.json`, com identificador sanitizado para impedir traversal de caminhos.
- Adicionados testes unitários para extensão, MIME, conteúdo UTF-8, segurança do caminho e reexportação da mesma sessão.
- O contrato JSON Pace Coach 6.0 e os dados da prescrição permanecem inalterados.
- `versionCode = 36` e `versionName = V36`; ZIP canônico `AI-Running-Coach.zip` preservado.

## V35 — Disponibilidade semanal em tela independente
- Removido o editor completo de disponibilidade da tela principal de Perfil do atleta; o perfil mantém apenas o resumo dos dias configurados.
- Adicionada a ação “Disponibilidade semanal” dentro de “Gerenciar perfil”, com resumo da quantidade de dias e do dia preferido para o longão.
- Ao abrir a ação, a configuração é apresentada em uma tela própria, com cabeçalho e retorno ao perfil.
- Mantidas as seleções de 2 a 6 dias, a preferência do longão, o salvamento local e o aviso/ação de recálculo do plano quando a disponibilidade muda.
- Etapa de disponibilidade do onboarding preservada; nenhuma regra do motor de treinamento ou estrutura dos dados foi alterada.
- `versionCode = 35` e `versionName = V35`; ZIP canônico `AI-Running-Coach.zip` preservado.

## V34 — Compactação dos recursos gráficos
- Otimizados os PNGs da identidade visual e dos ícones Android com paleta indexada de até 256 cores, mantendo os formatos PNG, as dimensões e a transparência.
- Mantidas a arte final e a imagem de referência no diretório `design/`; a referência visual aprovada da interface foi preservada sem alteração.
- Regeneração/compactação aplicada ao primeiro plano adaptativo e às variantes legacy quadrada/arredondada nas cinco densidades Android.
- Nenhum arquivo Kotlin, motor de treinamento, tela, integração ou regra funcional foi alterado nesta revisão.
- Incrementado `versionCode = 34` e `versionName = V34`; nome do aplicativo e nome canônico do ZIP preservados.
- O APK ainda depende da execução e validação do workflow GitHub Actions.

## V33 — Ícone oficial atualizado a partir do modelo fornecido
- Substituída a arte do launcher pelo modelo visual enviado: chip AI, corredor em movimento, sinal de desempenho, GPS/satélite, métricas e wordmark “AI Running Coach”.
- Atualizadas as camadas adaptativas Android e as versões legacy quadrada/arredondada nas cinco densidades (mdpi a xxxhdpi).
- Mantidos o nome exibido `AI Running Coach`, o identificador do aplicativo e toda a lógica funcional da V32.
- Incrementado `versionCode = 33` e `versionName = V33`.
- Atualizada a arte de referência PNG/SVG em `design/`; ZIP mantido como `AI-Running-Coach.zip`.
- Compilação Android/Compose deve ser confirmada pelo GitHub Actions.

## V29 — Disponibilidade semanal, reagendamento e calendário por modalidade
- Disponibilidade habitual configurável de 2 a 6 dias; a frequência é derivada dos dias selecionados.
- Preferência de dia do longão aplicada ao motor de distribuição.
- Reagendamento pontual para um dia livre da mesma semana, inclusive como exceção à disponibilidade habitual.
- Valida colisões, competições, sessões concluídas e intervalo mínimo entre sessões exigentes.
- Preserva identidade, dose, pace, blocos e data original das sessões movidas.
- Calendário diferencia regenerativo, aeróbio, moderado, progressivo, qualidade/limiar, intervalado, fartlek, longão e prova.
- Adicionados testes do motor de agenda e disponibilidade (8 testes unitários verificados localmente e matriz de 434 combinações).
- Corrigida a edição de disponibilidade vazia no onboarding para não acessar o último dia de uma lista vazia.
- Preservadas datas de reagendamento manual também na conversão de sessões da semana corrente ajustadas por competições, quando compatíveis.
- VersionCode 29 / versionName V29.

## V28 — Correção de compilação
- Corrigido `MutableSet<Int>()`, que tentava instanciar diretamente uma interface Kotlin, usando `mutableSetOf<Int>()`.
- Preservada a identificação dos dias com competições no gráfico semanal.
- Incrementado `versionCode` para 28 e `versionName` para V28.

# Changelog

## V27 — Competições, calendário e preparação por data
- Adicionado cadastro, edição e exclusão de provas com distância, data e prioridade A/B/C.
- Data-alvo passa a ser derivada da próxima prova principal cadastrada.
- A distância da prova A (ou B quando não houver A futura) é utilizada como objetivo específico do motor.
- Janela de planejamento ajustada para incluir a semana de competição e, quando possível, uma semana de recuperação posterior.
- Prova programada dentro do ciclo substitui uma sessão semanal; a frequência configurada passa a contar treinos + provas.
- Taper pré-prova e recuperação pós-prova adicionados, com parâmetros diferentes por distância.
- Calendário mensal, semanal e diário reconstruído para apresentar treinos, competições e dias livres.
- Eventos e sinalização de recálculo persistidos localmente.
- Treinos concluídos são preservados ao gerar novo plano.
- Corrigida a seleção do objetivo do ciclo: uma prova distante, fora da janela ativa de 16 semanas, permanece no calendário, mas não altera prematuramente a distância-alvo do bloco atual.
- Mantidas as regras de distância em km e pace em mm:ss min/km.

## V26 — Modelo Cooper + teste da fala
- Faixas iniciais de Z1–Z5 baseadas na velocidade média do Cooper.
- Personalização inicial da Z2 por registros de fala confortável.
- Atualização de snapshots e contrato de sessão.


## V26 — Zonas iniciais pela velocidade do Cooper e Z2 individualizada
- Substituído o modelo de cinco zonas relativo à VAM da V25 por faixas operacionais percentuais da velocidade média do Cooper, seguindo a planilha de referência: 60–70%, 70–80%, 80–90%, 90–100% e 100–110%.
- Corrigida a nomenclatura: os percentuais são da velocidade média do Cooper, não percentuais de VO₂máx.
- VAM estimada e segundo limiar estimado permanecem como referências complementares; não determinam diretamente as fronteiras das zonas.
- Adicionada personalização conservadora de Z2 por pelo menos dois registros consistentes de pace em trechos de fala confortável durante rodagens fáceis ou longões.
- Registros de fala precisam estar associados a sessões aeróbias concluídas, com dados reais da atividade, sem dor, com esforço leve/aceitável e sensação geral boa.
- A calibração utiliza mediana dos até três registros mais recentes, tolerância máxima de 45 segundos e margem conservadora de 10 segundos; mantém fronteiras contínuas e largura mínima das zonas.
- Feedback passa a registrar pace do trecho estável em que frases completas eram confortáveis. O novo limite de Z2 pede recriação do plano; sessões passadas preservam seus snapshots.
- Rodagem fácil e longão usam Z2; recuperação entre repetições/fartlek utiliza Z1. Corridas regenerativas também recebem alvo numérico Z1, evitando divergência entre o rótulo da zona e o pace exportado.
- Quando o teste da fala personaliza Z1–Z3, os rótulos de intensidade na tela e no JSON deixam de exibir percentuais iniciais incompatíveis com as novas fronteiras.
- Atualizado contrato Pace Coach para 6.0 com base percentual explícita e metadados da calibração da Z2.
- Atualizado versionCode 26 / versionName V26.

## V25 — Modelo fisiológico estimado de zonas Cooper
- Cooper de 12 min e estimativas VAM/sVT2; modelo legado agora preservado apenas em histórico.

## V24 — Correção de compilação Android
- Corrigido erro `Unresolved reference: SecondaryButton` em dois pontos da `MainActivity.kt`.
- Adicionado botão secundário baseado em Material 3.

## V23 — Cooper, zonas Z1–Z5 e revisão inteligente
- Cooper de 12 minutos e ciclo de avaliação a cada 28 dias.
- Registro de histórico, prescrição estruturada, feedback e exportação.

## V22 e anteriores
- Ver histórico de versões e arquivos de metodologia anteriores.


## V30 — Alternativa de treino por sessão
- Incluída uma segunda opção em cada sessão futura e não concluída.
- A escolha entre opção principal e alternativa é persistida por identificador de sessão.
- A alternativa substitui a principal sem adicionar volume ou frequência.
- Qualidade: alternativa contínua moderada em Z3; longão: formato contínuo confortável; rodagem: corrida-caminhada aeróbia.
- Opções bloqueadas após conclusão da sessão; competições permanecem eventos únicos.


## V31 — Tela de sessão simplificada e troca compacta de alternativa
- A tela de sessão mostra apenas a prescrição ativa; as duas opções não ficam mais expostas simultaneamente.
- Adicionado comando compacto “Trocar treino”, que abre uma caixa de confirmação com a alternativa e permite usá-la ou manter a atual. Quando a alternativa está selecionada, a mesma ação permite voltar à recomendada.
- Removido o resumo redundante de distância/duração/pace, pois esses dados já aparecem no cartão principal da sessão.
- Ações secundárias reorganizadas: reagendar e feedback em controles compactos; exportação mantida como ação principal.
- Alternativas movidas para `WorkoutAlternativeEngine.kt`, separadas da composição visual e compartilhadas pela tela, calendário e exportação.
- Alternativa de qualidade substitui intervalos por bloco aeróbio contínuo em Z2; alternativa de longão usa corrida com pausas confortáveis em Z1; alternativas aeróbias/regenerativas usam corrida-caminhada leve em Z1.
- Ao trocar de zona, todos os blocos alterados recebem a faixa pace correspondente ao snapshot da sessão; sem calibração não é inventado pace.
- Mantidos identificador, data, semana, dose total, duração estimada, reagendamento e snapshot de calibração da sessão original. A alternativa substitui a principal e não cria sessão adicional.
- Adicionados cinco testes de domínio para dose, zonas, pace, preservação da identidade e comportamento sem calibração.
- `versionCode = 31`, `versionName = V31`.


## V32 — Ícone oficial do aplicativo
- Criado ícone do AI Running Coach a partir da identidade visual aprovada: corredor em ciano sobre azul-marinho, sem texto no símbolo.
- Adicionadas camadas de ícone adaptativo Android e versões PNG legacy para mdpi, hdpi, xhdpi, xxhdpi e xxxhdpi.
- Configurados `android:icon` e `android:roundIcon` no Manifest.
- Nome do aplicativo preservado; `versionCode = 32` e `versionName = V32`.
