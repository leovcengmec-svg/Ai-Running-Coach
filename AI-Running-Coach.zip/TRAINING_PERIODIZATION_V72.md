# Periodização adaptativa — V72

## Entradas do plano

- Distância: 5 km, 10 km, 15 km, 21,1 km ou 42,2 km.
- Nível e experiência demonstrada.
- Prioridade: completar, correr continuamente, melhorar RP ou alcançar tempo-alvo.
- Carga recente: volume, frequência, maior sessão, consistência e sessões concluídas.
- Testes e calibração de pace.
- Dias disponíveis, frequência semanal, terreno, dor, fadiga e recuperação percebida.

## Fases

1. Base/adaptação: consistência, caminhada/corrida quando necessária e volume tolerável.
2. Desenvolvimento: resistência, ritmo moderado e qualidade introduzida conforme critérios individuais.
3. Específica: ritmo e sessões próprias da distância/prioridade, mantendo recuperação suficiente.
4. Taper/prova: redução de carga e preservação seletiva de estímulos, sem acumular fadiga.

Semanas regenerativas reduzem temporariamente a carga; não apagam a referência de construção. O limite de longão avança por etapas e depende de prontidão/carga, sempre limitado pelo objetivo.

## Matrizes de distância

- 5 km: iniciante usa progressão caminhada/trote quando não corre continuamente; intermediário trabalha base e ritmo sustentado; avançado pode utilizar velocidade, intervalos e ritmo específico.
- 10 km: iniciante constrói resistência a partir de 5 km; intermediário combina rodagem, ritmo sustentado e intervalos; avançado utiliza limiar, repetições e ritmo específico.
- 15 km: ponte desenvolvida pelo aplicativo entre 10 km e meia maratona; não há planilha específica de 15 km nos anexos.
- 21,1 km: resistência, longões, ritmo específico, limiar e recuperação ao longo de ciclo de referência de 14 semanas.
- 42,2 km: volume, longões, ritmo de maratona, recuperação e taper, usando o programa de 18 semanas como referência; atletas com base menor podem precisar de preparação mais longa antes da fase específica.

As durações são defaults de referência, não garantias nem prescrições universais. O motor acrescenta preparação quando volume/maior sessão atuais não sustentam o ciclo de referência. O plano avançado O2 de 5 km com quatro semanas é interpretado como bloco específico de afiação, não como preparação completa para quem não possui base.

## Prioridades

- Completar distância: resistência e tolerância, sem meta de ritmo artificial.
- Correr continuamente: aumentar o tempo corrido e reduzir pausas conforme resposta.
- Melhorar RP: usar o recorde atual na distância escolhida, quando cadastrado, e sessões compatíveis com a capacidade atual.
- Tempo-alvo: calcular o pace-alvo e usá-lo como referência secundária apenas quando for compatível com as zonas atuais; nunca forçar pace irreal.

A quantidade de dias disponíveis determina a montagem do microciclo. Sessões de velocidade e longões não devem ser colocados em sequência sem recuperação adequada.
