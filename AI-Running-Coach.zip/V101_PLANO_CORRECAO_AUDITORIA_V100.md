# AI Running Coach — Plano de Correção V101
## Auditoria da V100: exportação Pace Coach, nomenclatura e distribuição dos estímulos de qualidade

**Status:** auditoria concluída; implementação pendente  
**Base:** V100  
**Versão proposta:** V101  
**VersionCode:** 101  
**Motor interno:** 91  
**Backup Schema:** 14 (manter; as correções propostas não exigem novo campo persistido)  
**Compatibilidade:** schemas 1–14

---

## 1. Resumo executivo

A inspeção das cinco capturas e do código-fonte V100 confirmou:

1. **Crash ao exportar:** `PaceCoachExporter.workoutToJson()` chama `TrainingProtocolCatalog.validateNamedProtocol()` e transforma divergências de título em `IllegalArgumentException`. O botão em `MainActivity.ExportScreen` não captura a exceção. O stack trace do aparelho aponta `PaceCoachExporter.kt:37` e `MainActivity.kt:7917`.
2. **Nomenclatura extensa e inconsistente:** `WorkoutExportNaming` utiliza o título sanitizado integral da sessão. Não há um código curto de modalidade confiável no nome exportado.
3. **Classificação excessivamente genérica:** `WorkoutCalendarCategory.resolve()` envia qualquer sessão com `type == "Qualidade"` para `INTERVALADO_QUALIDADE`; também considera `TEMPO` como intervalado. O teste `WorkoutCalendarPresentationTest` confirma esse comportamento ao classificar `TEMPO_RUN_ESTIMATED` como INT.
4. **Distribuição de estímulos condicionada por fase e prontidão:** `TrainingPeriodizationEngine.selectProtocolCode()` usa um ciclo de quatro semanas (`(week - 1) % 4`), a fase do plano, a prioridade selecionada e os gates de qualidade/limiar/VO₂. Quando o gate de limiar está liberado, o seletor tende a escolher `T01`, `T04/T05`, `Ixx` ou `RPxx` em vários pontos do ciclo, reduzindo a frequência de Fartlek.

A proposta V101 corrige a exportação sem enfraquecer a auditoria estrutural, separa Tempo Run contínuo de intervalados, padroniza nomes e torna a distribuição de estímulos explícita, rastreável e testável.

---

## 2. Diagnóstico detalhado do crash de exportação

### 2.1 Evidência do aparelho

O stack trace exibido na imagem contém a sequência:

- `java.lang.IllegalArgumentException`
- `PaceCoachExporter.workoutToJson(PaceCoachExporter.kt:37)`
- `MainActivity.ExportScreen` no callback do botão (`MainActivity.kt:7917`)

A mensagem informa que o título visível da sessão não corresponde ao descritor esperado pelo protocolo, embora ambos representem `Tempo intervalado 2 × 10 min`.

### 2.2 Causa no código

Em `PaceCoachExporter.kt`, a exportação identifica o protocolo pelo `stimulus` e executa:

`TrainingProtocolCatalog.validateNamedProtocol(protocolCode, workout.segments, workout.title)`

Em seguida, `require(protocolErrors.isEmpty())` lança uma exceção quando a lista contém qualquer divergência.

Em `TrainingProtocolCatalog.kt`, a validação do título compara strings completas. Diferenças de:

- ponto médio, bullet ou ausência de separador;
- símbolo `×` ou letra `x`;
- espaços repetidos;
- acentos ou normalização Unicode;
- nome canônico versus nome amigável salvo;

podem reprovar a sessão mesmo quando a dose e os blocos estão corretos.

O callback de `ExportScreen` chama o exportador diretamente, sem `try/catch` ou `runCatching`. Assim, a `IllegalArgumentException` sai do callback e derruba a Activity/aplicativo.

### 2.3 Correção proposta

**Separar a integridade do protocolo da apresentação do nome.**

A validação obrigatória deverá verificar:

- código/família do protocolo;
- número de repetições executáveis;
- duração ou distância de cada estímulo;
- duração e quantidade das recuperações;
- ordem aquecimento → preparação → estímulos/recuperações → desaquecimento;
- ausência de blocos ausentes ou extras;
- alvos de ritmo válidos quando presentes.

O título não será condição de validade estrutural. O nome será normalizado apenas para apresentação. Quando necessário, a exportação usará o nome canônico derivado do código e da dose real.

**Não remover:** validação de repetições, distâncias, durações, recuperações, limites de ritmo e sequência. Essas proteções são importantes e devem continuar bloqueando JSON incorreto.

### 2.4 Proteção da interface

O botão de compartilhar deverá:

1. validar e montar o JSON em uma operação protegida;
2. criar o arquivo temporário somente após a validação bem-sucedida;
3. abrir o seletor Android somente quando o arquivo estiver pronto;
4. em caso de erro, manter o usuário na tela e exibir uma mensagem acionável;
5. registrar o erro técnico em log de diagnóstico sem expor stack trace ao corredor.

Mensagem sugerida: **“Não foi possível preparar este treino para exportação. A estrutura foi preservada. Revise os blocos ou tente novamente.”**

---

## 3. Nomenclatura curta de treinos e arquivos

### 3.1 Contrato

Adotar o padrão:

`S{semana}_T{número}_{SIGLA}_{VARIANTE}`

Exemplos:

| Sessão | Identificador proposto |
|---|---|
| Semana 3, treino 2, tempo intervalado 2 × 10 min | `S3_T2_INT_2x10min` |
| Semana 3, treino 3, longão progressivo Z2 | `S3_T3_LNG_ProgressivoZ2` |
| Semana 4, treino 1, Fartlek variável | `S4_T1_FAR_VariavelZ2Z3` |
| Semana 4, treino 2, Tempo Run contínuo | `S4_T2_TMP_ContinuoZ3` |
| Semana 5, treino 1, rodagem progressiva | `S5_T1_ROD_ProgressivaZ2Z3` |

### 3.2 Regras de construção

- A semana vem de `workout.week` persistida no ciclo, não do número da semana do calendário civil.
- O número do treino é calculado pela ordem cronológica das sessões reais daquela semana, preservando a identidade estável da sessão.
- A sigla vem da modalidade estruturada/protocolo, não de busca genérica no texto `type == "Qualidade"`.
- A variante é curta, normalizada, sem acentos, espaços, símbolos de multiplicação ou pontuação ambígua.
- A dose usa convenção consistente: `2x10min`, `5x600m`, `3x1000m`.
- O nome interno do arquivo, `workoutName` do JSON e nome apresentado na tela devem ser derivados da mesma função.
- Alterar o texto de apresentação não pode alterar o `sessionId` nem criar uma nova sessão.

### 3.3 Compatibilidade

A nomenclatura é uma projeção de dados já existentes (`week`, `sessionId`, `stimulus`, título e segmentos). Não precisa alterar o formato de backup. Arquivos já exportados continuam válidos; a V101 apenas passa a produzir novos nomes padronizados.

---

## 4. Separação correta dos tipos de treino de qualidade

### 4.1 O que já existe no motor

O código já possui distinções internas:

- `T01` → `TEMPO_RUN`;
- `T04` e `T05` → família `TEMPO`, montados em blocos de tempo;
- `I04` a `I10` → família `INTERVAL`;
- `RP05`, `RP10`, `RP15`, `RP21` → ritmos específicos de prova em blocos;
- `F01` a `F04` → Fartlek.

Entretanto, a apresentação do calendário perde parte dessa distinção. `WorkoutCalendarCategory.resolve()` classifica `type == "Qualidade"` como INT e também trata qualquer `TEMPO` como INT. O teste atual inclusive exige que `Tempo Run` seja classificado como `INTERVALADO_QUALIDADE`.

### 4.2 Taxonomia V101

| Modalidade | Código de calendário/arquivo | Regra de classificação |
|---|---|---|
| Iniciação corrida/caminhada | `INI` | Apenas protocolo explícito RUN_WALK |
| Regenerativo | `REG` | Tipo/estímulo recovery explícito |
| Rodagem | `ROD` | Rodagem fácil, progressiva ou regressiva contínua |
| Fartlek | `FAR` | Protocolos `F01`–`F04` e família FARTLEK |
| Tempo Run contínuo | `TMP` | `T01` ou família TEMPO_RUN sem blocos intervalados |
| Intervalado | `INT` | `I04`–`I10`, `T04/T05` (tempo fracionado), e protocolos RP fracionados |
| Longão | `LNG` | Família LONG_RUN / sessão longa |
| Prova | `PRV` | Evento competitivo |
| Teste | `TES` | Cooper, 3 km ou outro teste fisiológico |

A nova sigla `TMP` é necessária para distinguir Tempo Run contínuo do intervalado. O exemplo `S3_T2_INT_2x10min` continua usando INT porque é um treino fracionado em repetições, embora sua família fisiológica seja TEMPO/limiar.

### 4.3 Ordem de prioridade do classificador

O classificador não pode mais usar `type == "Qualidade"` como decisão final. Prioridade proposta:

1. evento de prova/teste explícito;
2. protocolo e código de estímulo;
3. família estruturada do treino;
4. tipo legado + título normalizado como fallback;
5. `ROD` como fallback seguro.

Exemplos obrigatórios:

- `TEMPO_RUN_ESTIMATED` + `Tempo Run` → `TMP`;
- `T04` + `Tempo intervalado 2 × 10 min` → `INT`;
- `I07` + `Intervalado 5 × 600 m` → `INT`;
- `F04` + `Fartlek variável` → `FAR`;
- `PROGRESSIVE_RUN` + `Rodagem progressiva` → `ROD`.

---

## 5. Por que apareceu somente um Fartlek e quatro sessões marcadas como INT?

### 5.1 O motor usa uma seleção determinística em ciclo de quatro semanas

Em `TrainingPeriodizationEngine.selectProtocolCode()`, a posição do estímulo é calculada por:

`cycle = (week - 1) mod 4`

A escolha depende de quatro fatores:

- semana dentro do ciclo de quatro;
- fase (BASE, DEVELOPMENT ou SPECIFIC);
- prioridade/objetivo (por exemplo, melhorar recorde, completar ou atingir tempo);
- elegibilidade para qualidade aeróbia, limiar e potência aeróbia.

Portanto, o motor não sorteia Fartlek e intervalado. Ele percorre uma tabela de estímulos por fase e objetivo.

### 5.2 Gates que favorecem Tempo/Intervalado

A elegibilidade de limiar (`thresholdEligible`) exige, no código atual:

- objetivo diferente de saúde;
- zonas de ritmo disponíveis;
- frequência de pelo menos 3 dias;
- volume semanal de pelo menos 16 km;
- maior sessão de pelo menos 8 km;
- ausência de dor;
- recuperação de pelo menos 75 quando informada;
- fadiga abaixo de 65 quando informada;
- evidência de consistência recente;
- terreno diferente de trilha.

Quando esses requisitos são cumpridos, vários pontos da tabela podem selecionar `T01`, `T04/T05`, `Ixx` ou `RPxx`, em vez de `F01/F04`.

A elegibilidade de VO₂ é ainda mais restrita: frequência mínima de 4 dias, volume de 24 km, maior sessão de 10 km, recuperação mais alta, fadiga menor e consistência. Com 3 dias por semana, esse gate não é liberado; isso não impede, porém, Tempo/limiar se o gate anterior estiver atendido.

### 5.3 O que as imagens permitem afirmar

- A captura de exportação confirma uma sessão de **Tempo intervalado 2 × 10 min** em 26/11. Ela é uma sessão fracionada de tempo/limiar, não um Fartlek.
- A grade de novembro mostra um Fartlek em 20/11 e uma sessão de qualidade em 26/11.
- A grade seguinte mostra marcadores INT em semanas futuras de dezembro.
- O calendário atual agrega modalidades de qualidade. Por isso, o marcador INT sozinho não revela se a sessão subjacente é `T01` Tempo Run, `T04/T05` Tempo intervalado, `Ixx` intervalado clássico ou `RPxx` ritmo específico.

**Conclusão:** o padrão de um Fartlek e quatro sessões marcadas como INT é compatível com a tabela determinística de periodização quando a elegibilidade de limiar está liberada. Porém, a apresentação atual exagera o número de “intervalados clássicos”, porque também coloca Tempo Run contínuo na categoria INT. Para afirmar o protocolo exato das três sessões de dezembro, a auditoria de execução precisa registrar o `stimulus` e o `protocolCode` de cada sessão, não apenas o ícone do calendário.

### 5.4 Ajuste proposto à variedade da qualidade

A V101 deverá tornar a variedade uma regra explícita, e não um efeito colateral do ciclo de quatro semanas:

- manter no máximo uma sessão de qualidade por semana para o perfil de três dias, respeitando a recuperação entre qualidade e longão;
- alternar modalidades de estímulo ao longo do bloco, sempre condicionadas à prontidão;
- não permitir quatro semanas seguidas do mesmo padrão de intervalado intenso apenas porque o gate de limiar está aberto;
- incluir Fartlek em semanas apropriadas como estímulo variável, sem forçar Fartlek quando a recuperação ou a fase não permitir;
- separar Tempo Run contínuo, Tempo intervalado, intervalado clássico e ritmo específico de prova na lógica e no relatório;
- manter semanas regenerativas e taper sem qualidade intensa;
- registrar a razão da escolha e da não escolha de cada protocolo.

A matriz final de distribuição deve respeitar o objetivo, fase, número de dias, base semanal, maior sessão, zonas, recuperação e histórico. Não se deve impor uma quota universal fixa de Fartlek: a rotação é uma diretriz de variedade subordinada à elegibilidade e à recuperação.

---

## 6. Auditoria de transparência da periodização

Adicionar um relatório técnico por sessão/semana com:

- número da semana e fase;
- ciclo de quatro semanas (`cycle 0–3`);
- objetivo/prioridade selecionada;
- `thresholdEligible` e motivo;
- `vo2Eligible` e motivo;
- código de protocolo selecionado;
- modalidade apresentada (`FAR`, `TMP`, `INT`, etc.);
- motivo da ausência de qualidade, quando ocorrer;
- identificação de semana regenerativa/taper.

Uma tela compacta “Por que este treino?” deverá exibir explicação curta, por exemplo:

“Selecionado: INT 5 × 600 m. Fase específica; limiar liberado; VO₂ não liberado por frequência inferior a 4 dias.”

O relatório detalhado deve ficar disponível para auditoria, não ocupar o card principal do calendário.

---

## 7. Versão e arquivos envolvidos

| Item | V101 |
|---|---:|
| VersionCode | 101 |
| Motor interno | 91 |
| Backup Schema | 14 (mantido) |
| Compatibilidade | Schemas 1–14 |

Arquivos principais:

- `PaceCoachExporter.kt` — normalização do título, validação semântica e montagem protegida do JSON.
- `TrainingProtocolCatalog.kt` — validação estrutural sem igualdade literal de título.
- `WorkoutExportNaming.kt` — padrão `Sx_Ty_SIGLA_VARIANTE`.
- `WorkoutTitleSanitizer.kt` — normalização segura de nomes e variantes.
- `TrainingPeriodizationEngine.kt` — tipagem por família/protocolo e auditoria da sequência de estímulos.
- `WorkoutCalendarPresentation.kt` — nova categoria TMP e resolução por código/família.
- `MainActivity.kt` — tratamento de erro no compartilhamento e nomes curtos nas telas.
- testes de exportação, nomenclatura, taxonomia e periodização.

Nenhuma alteração é proposta para apagar ou substituir histórico de treinos, backups, feedbacks ou a identidade do ciclo de oito semanas. As correções devem preservar integralmente as proteções já introduzidas na V100.

---

## 8. Testes obrigatórios de aprovação

### Exportação

1. Exportar `Tempo intervalado 2 × 10 min` com separador `•`, `·` e sem separador.
2. Exportar quando a variante do título usa `x` ou `×`.
3. Validar o mesmo protocolo com título amigável diferente, mas blocos idênticos.
4. Rejeitar dose errada (número de repetições, duração, distância ou recuperação incorreta).
5. Rejeitar bloco ausente, repetição duplicada ou ordem inválida.
6. Garantir que falha de validação exiba mensagem e não feche o aplicativo.
7. Garantir que falha não crie arquivo parcial nem abra chooser.
8. Abrir chooser e compartilhar JSON válido pelo Android Sharesheet.
9. Importar o JSON no Pace Coach e confirmar nome, ordem, unidades, ritmo e repetições.

### Nomenclatura

10. Gerar `S3_T2_INT_2x10min`.
11. Gerar `S3_T3_LNG_ProgressivoZ2`.
12. Tratar acentos, espaços, símbolos e títulos longos.
13. Manter o mesmo nome entre prévia, `workoutName` do JSON e arquivo anexado.
14. Garantir que o nome curto não altere `sessionId`.

### Classificação

15. `T01` deve aparecer como TMP.
16. `T04/T05` devem aparecer como INT (Tempo intervalado fracionado).
17. `I04–I10` devem aparecer como INT.
18. `F01–F04` devem aparecer como FAR.
19. `RPxx` devem ser classificados explicitamente como trabalho de ritmo específico, sem cair em Fartlek.
20. Rodagem progressiva deve permanecer ROD.
21. Longão progressivo/regressivo deve permanecer LNG.
22. Prova e teste não podem ser confundidos com qualidade comum.

### Distribuição dos estímulos

23. Simular ciclo de 8 semanas por prioridade e fase.
24. Garantir no máximo uma sessão principal de qualidade por semana no perfil de 3 dias.
25. Garantir que semanas regenerativas/taper não recebam qualidade intensa.
26. Verificar alternância entre FAR, TMP, INT e ritmo específico quando os gates permitirem.
27. Demonstrar que não ocorre repetição automática de intervalado intenso em semanas consecutivas sem justificativa registrada.
28. Testar atleta com limiar elegível e VO₂ não elegível por frequência de 3 dias.
29. Testar atleta sem limiar elegível: Fartlek/aeróbio apenas quando indicado pela fase e prontidão.
30. Confirmar que o relatório identifica por que cada protocolo foi selecionado.

### Regressão

31. Preservar semana atual e ciclo de 8 semanas da V100.
32. Preservar todos os treinos concluídos e feedbacks.
33. Preservar teto de 40% do longão e piso de sessão para objetivo de 5 km.
34. Preservar integração do backup Schema 14.
35. Executar testes de domínio, JUnit oficial, build Android e teste real em aparelho.

---

## 9. Critérios de aceite

A V101 só será considerada concluída quando:

- a exportação do treino da imagem funcionar sem crash;
- o Pace Coach receber um JSON válido e executar as etapas corretas;
- os nomes curtos forem determinísticos e consistentes;
- Tempo Run contínuo não aparecer como intervalado;
- Tempo intervalado e intervalado clássico forem distinguíveis dos demais estímulos;
- a quantidade de Fartlek/Tempo/Intervalado for explicável pelo relatório de periodização;
- a rotação de qualidade evitar repetição injustificada;
- o ciclo de oito semanas e os dados históricos da V100 permanecerem intactos.

**Parecer:** priorizar o crash de exportação, pois é uma falha funcional direta. Em paralelo, corrigir a taxonomia para que o calendário mostre a modalidade real, e aprimorar a periodização para explicar e controlar a variedade dos estímulos. Não classificar toda sessão de qualidade como INT.

## 10. Reconstrução provável da sequência que aparece nas capturas

Considerando o plano de 8 semanas mostrado no histórico anterior (objetivo de 5 km, prioridade de recorde pessoal, 3 dias por semana, base declarada próxima de 16 km e maior sessão de 10 km), a sequência visível é compatível com o ramo `PERSONAL_BEST` do seletor, caso o gate de limiar esteja liberado e o atleta não esteja elegível para VO₂:

| Data visível | Semana/fase provável | Protocolo escolhido pelo seletor | Modalidade real | Como a V100 classifica no calendário |
|---|---|---|---|---|
| 20/11 | Semana 2 · BASE · ciclo 1 | F04 (ou F01 conforme disponibilidade dos scores de recuperação/fadiga) | Fartlek variável/aeróbio | FAR |
| 26/11 | Semana 3 · DEVELOPMENT · ciclo 2 | T04, se limiar elegível | Tempo intervalado 2 × 10 min | INT |
| 09/12 | Semana 5 · DEVELOPMENT · ciclo 0 | T01, se limiar elegível | Tempo Run contínuo/controlado | INT (classificação genérica incorreta) |
| 16/12 | Semana 6 · SPECIFIC · ciclo 1 | I07, se limiar elegível e VO₂ não elegível | Intervalado 5 × 600 m | INT |
| 23/12 | Semana 7 · SPECIFIC · ciclo 2 | T01, se limiar elegível | Tempo Run contínuo/controlado | INT (classificação genérica incorreta) |

A semana 4 é regenerativa e por isso não recebe protocolo de qualidade. Essa sequência explica o padrão de **um Fartlek e quatro marcadores INT**: os quatro marcadores não representam necessariamente quatro intervalados clássicos. Pelo código, o conjunto provável é um Tempo intervalado (T04), dois Tempo Run (T01) e um intervalado clássico (I07).

Essa reconstrução é condicionada ao ramo `PERSONAL_BEST` e ao gate de limiar ativo. O código real (`stimulus`) de cada treino deve ser incluído no relatório V101 para confirmar ou refutar a hipótese com dados da sessão, sem depender da aparência do calendário.

### Consequência para a distribuição

Mesmo após corrigir a sigla TMP, permanece uma decisão de periodização a revisar: após a semana regenerativa, o algoritmo pode selecionar qualidade em três semanas consecutivas (semanas 5, 6 e 7). A V101 deverá avaliar a sequência das últimas semanas, não apenas o score de recuperação do dia atual.

Regra proposta: não prescrever três semanas consecutivas com protocolo de demanda moderada/alta sem uma semana de descarga ou uma sessão de menor demanda entre elas. A terceira semana deve ser convertida em Fartlek aeróbio/moderado ou progressão contínua, quando apropriado, ou ficar sem estímulo de qualidade se os indicadores pedirem redução. A decisão deve ser explicável e não pode forçar Fartlek em atleta sem prontidão.
