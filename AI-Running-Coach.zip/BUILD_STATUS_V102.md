# Build status — AI Running Coach V102

- VersionCode: `102`
- VersionName: `V102`
- Motor interno: `92`
- Backup Schema: `14` (leitura compatível de schemas 1–14)
- Fonte Android principal: `android/app/src/main/java/com/airunningcoach/app/`

## Alterações principais

- Histórico com cabeçalho, filtros e resumo fixos; somente a lista abaixo usa `LazyColumn` vertical.
- Linha “Sessões registradas” removida.
- Cards compactos com ícone, atividade, data/hora e métricas essenciais; detalhes e ações continuam acessíveis.
- `HistorySnapshotEngine` pré-indexa relações entre sessões e feedbacks fora da thread principal; os filtros reaproveitam o snapshot.
- Fallback de vínculo exige vaga canônica única; data realizada sozinha nunca cria vínculo.
- Schema de backup e dados persistidos não foram alterados.

## Validação

- `HistorySnapshotEngineTest`: 7/7 aprovados no harness Kotlin/JVM local.
- Verificações estáticas: 28/28 aprovadas.
- ZIP: integridade validada com `unzip -t`.
- **Build Android/Gradle não executado localmente.** Não há Gradle instalado, wrapper Gradle incluído ou Android SDK configurado neste ambiente. A compilação, os testes JUnit oficiais e a geração de APK devem ser confirmados no GitHub Actions.
