# Test Report — AI Running Coach V98

## Versão e ambiente

- VersionCode 98 · VersionName V98 · motor 88 · Backup Schema 13.
- Host: JRE 21; `kotlinc-jvm 1.9.0` disponível.
- Gradle, `gradlew` e Android SDK não estão instalados neste ambiente.

## Verificações executadas

- **16/16 verificações estáticas focadas passaram**, cobrindo versionamento, schema 13, isolamento do formulário de teste, protocolo de 3 km, persistência de identidade/tombstones, compatibilidade schema 12 e histórico sem card duplicado.

| Verificação | Resultado |
|---|---|
| Harness Kotlin/JVM da gestão real de avaliações | PASS — 5 cenários |
| Geração/migração de IDs de testes antigos | PASS |
| Última avaliação ativa ignora avaliação removida | PASS |
| Exclusão lógica e restauração preservam ID/resultado | PASS |
| Edição por ID não altera outros registros | PASS |
| Compilação isolada dos motores de domínio Cooper/3 km | PASS usando stubs de dependências externos |
| Parser Kotlin de `MainActivity.kt` | Sem erro sintático reportado; referências Android/Compose não resolvidas sem classpath |
| Busca estática: `createPlan()` não salva rascunho de teste | PASS |
| Busca estática: `createPlan()` não recria teste ao final | PASS |
| Leitura de avaliação 3 km usa `calculateThreeKm()` | PASS |
| Persistência e leitura de `recordId`, `deletedAtIso`, `updatedAtIso` | PASS |
| Backup Schema 13 e faixa de compatibilidade 1–13 | PASS em verificação estática |
| Integridade do ZIP final | PASS — `unzip -t`, sem erros |
| Card único para sessão concluída com feedback associado | PASS em verificação estática |
| Testes JUnit `:app:testDebugUnitTest` | NÃO EXECUTADO — falta Gradle/SDK |
| Build Android `:app:assembleDebug` e APK | NÃO EXECUTADO — falta Gradle/SDK |

## Testes acrescentados/atualizados

- `CooperAssessmentManagementEngineTest.kt`: cinco testes JUnit cobrindo migração de IDs, filtragem de removidos, remoção/restauração, substituição pelo ID e isolamento de registros não relacionados.
- `AppBackupCodecTest.kt`: schema 13/V98, leitura de schema 12/V97 e preservação de `recordId`/`deletedAtIso`/`updatedAtIso` no JSON de avaliações.
- Os testes existentes de Cooper, 3 km e backup histórico permanecem no source set.

## Pendências do CI

Executar no workflow `.github/workflows/android.yml`:

```bash
gradle -p android :app:testDebugUnitTest :app:assembleDebug --no-daemon
```

Somente após o workflow concluir sem erros e publicar o APK será possível marcar a V98 como compilada e aprovada em Android. A validação funcional de backup, diálogos e histórico ainda precisa de teste no aparelho.
