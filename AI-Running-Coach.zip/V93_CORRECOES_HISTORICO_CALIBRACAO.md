# V93 — histórico corrigível, calibração acumulada e reteste

**Base:** AI Running Coach V92  
**VersionCode:** 93  
**VersionName:** V93  
**Motor interno Android:** 83  
**Backup Schema:** 8 (leitura dos schemas 1–7)

## 1. Diagnóstico e decisões

A V93 consolida a correção de registros órfãos após restaurações, oferece ações explícitas de manutenção do histórico, substitui a calibração independente por contribuições acumuladas em cascata e harmoniza a revisão de quatro semanas com a janela de reteste fisiológico.

A inspeção do source set Android da V92 encontrou `CURRENT_ENGINE_VERSION = 82`, embora a documentação V92 registrasse 81. A V93 avança o motor real para 83 para que planos/backups produzidos pelo código V92 sejam reconhecidos como anteriores ao motor atual.

## 2. Histórico de treinos

Cada `FeedbackRecord` mantém `recordId` estável e estado `deleted`. A tela Histórico oferece:

- **Editar:** data realizada para registros manuais, distância, duração, pace, esforço, sensação, dor e observações. Se distância ou duração forem alteradas sem edição explícita do pace, o pace é recalculado a partir dos dados inseridos. Registros importados preservam a data/hora de origem e os detalhes brutos do percurso.
- **Vincular:** associa um registro sem vínculo à sessão correta e marca a sessão como concluída. A seleção usa data agendada/original e tipo normalizado compatível; a chave canônica salva é usada para recuperar slots antigos. A data real da atividade, isoladamente, nunca é suficiente para vincular sessões.
- **Remover:** soft-delete; o registro deixa de alimentar carga, médias e evidências, mas fica na seção Registros removidos para restauração.
- **Restaurar:** recupera o registro removido e seu vínculo, quando inequívoco.
- **Excluir definitivamente:** ação disponível somente depois de remover, com uma segunda confirmação. Exclui o feedback dos próximos backups, sem apagar outras sessões.

A normalização cobre aliases históricos de rodagem/aeróbio, longão, qualidade/limiar, recuperação, prova e teste. Se houver mais de um candidato, o corredor escolhe; o motor não decide por data sozinha.

## 3. Calibração acumulada

Cada zona de origem tem uma contribuição direta independente, limitada a 5% desde o último teste fisiológico válido.

| Zona calibrada | Z1 recebe | Z2 recebe | Z3 recebe |
|---|---:|---:|---:|
| Z3 | +5% | +5% | +5% |
| Z2 | +5% | +5% | — |
| Z1 | +5% | — | — |
| **Máximo efetivo** | **15%** | **10%** | **5%** |

Os ajustes são aplicados nas fronteiras compartilhadas das faixas para manter a continuidade Z1–Z5. Z4 e Z5 continuam ancoradas ao teste fisiológico. A calibração é bloqueada se as fronteiras saírem dos limites operacionais ou se qualquer zona ficar com menos de 10 segundos de largura.

Parâmetros preservados:
- melhora mediana mínima para propor ajuste: 2%;
- máximo aplicado por revisão: 3% por zona de origem;
- máximo acumulado: 5% por zona de origem;
- revisão das evidências: a cada 28 dias;
- mínimo de evidência: 5 blocos válidos em 3 sessões distintas por zona;
- confirmação explícita antes da aplicação.

Um novo teste válido reinicia as contribuições diretas para Z1, Z2 e Z3. O histórico anterior permanece como auditoria, mas não interfere no novo ciclo.

## 4. Aplicação ao plano

A confirmação recalcula o plano usando as zonas atuais. A aplicação se restringe às sessões futuras ainda não iniciadas; sessões concluídas, feedbacks, atividades importadas e datas reais permanecem preservados.

A nova zona é propagada aos blocos que usam aquela faixa. A estrutura principal do treino é mantida: blocos baseados em tempo conservam o tempo e recalculam distância estimada; blocos baseados em distância conservam a distância e recalculam duração. Aquecimento, preparação, trabalho, recuperação e desaquecimento mantêm sua função e ordem.

## 5. Revisão e reteste fisiológico

A revisão de 28 dias é uma revisão das evidências de execução, não uma obrigação de fazer outro teste máximo. A janela preferencial para reteste de campo passa a ser entre os dias 49 e 56 (semanas 7–8) após o último teste válido. O reteste substitui uma sessão intensa elegível e não é adicionado como carga extra.

O Cooper de 12 minutos e o teste de 3 km permanecem protocolos separados; a evolução é comparada apenas com resultados do mesmo método. As condições de teste devem ser tão consistentes quanto possível.

## 6. Compatibilidade

- Backup Schema 8.
- Decoder aceita schemas 1–8.
- Os campos de `sourceContributionPercent` preservam a contribuição direta por zona; backups anteriores usam `appliedChangePercent` como fallback para o histórico de auditoria.
- O campo `recordId` de registros legados recebe ID determinístico durante a leitura quando ausente.
- O campo `deleted` é opcional e assume `false` em backups antigos.

## 7. Limitações de validação

O harness Kotlin/JVM direcionado para calibração/identidade foi compilado e executado com sucesso. A suíte JUnit completa, compilação Compose/Kotlin Android e `assembleDebug` não foram executados neste ambiente porque Gradle e Android SDK não estão disponíveis. O workflow `.github/workflows/android.yml` deve confirmar `:app:testDebugUnitTest` e `:app:assembleDebug` antes de declarar o APK aprovado.
