# Alternativas de treino e recalibração de backup — V76

## Substituição de sessão
Uma alternativa não deve ser uma sessão adicional e deve manter identificador, data programada, semana, fase, conclusão e histórico da sessão original.

- Com recuperação/saúde adequadas, preservar família do estímulo, zona de trabalho, sequência dos blocos e dose principal.
- Progressões e sessões mistas preservam ordem, distância e zonas de cada etapa; a alternativa pode variar a faixa ativa dentro da mesma zona.
- Intervalados homogêneos podem redistribuir repetições, mas preservam dose total de trabalho e relação de recuperação válida.
- Longão continua sendo sessão contínua de resistência; rodagem fácil permanece corrida aeróbia.
- Corrida/caminhada só pode ser alternativa de sessão quando a sessão original já pertence a plano de iniciante elegível e o perfil atende a regra de elegibilidade.
- Com recuperação ruim, fadiga elevada ou sinal de saúde relevante, pode-se substituir qualidade por carga menor. O motivo precisa ser descrito na sessão.

## Recuperação usada pelas alternativas
Pausas PASSIVE continuam cronometradas e sem distância/pace. Caminhada não recebe alvo de pace. Recuperação ativa preserva a faixa Z2 prescrita.

## Restauração de backup completo
Após restauração completa com atividades/sessões, o aplicativo oferece duas opções explícitas:
1. Recalibrar o plano futuro com o motor atual.
2. Manter o plano importado sem recalibração.

Ao recalibrar, recalcular zonas/faixas quando houver teste válido, bases semanais por objetivo, carga, periodização, semanas, protocolos, distribuição semanal e sessões futuras. Quando faltar teste para recalcular zonas, manter a zona/pace anterior como provisório e atualizar o restante do plano, sinalizando a necessidade de novo teste; não inventar calibração.

Treinos concluídos, feedbacks, atividades importadas, sessões com datas reais e histórico permanecem preservados. Backup Schema 3 continua lendo schemas 1–3. A decisão de manter ou recalibrar não altera a importação seletiva de atividades concluídas, que permanece separada.
