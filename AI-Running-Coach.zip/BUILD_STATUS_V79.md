# BUILD STATUS — AI Running Coach V79

## Identificação
- Base: AI Running Coach V78 corrigida.
- `versionCode`: 79.
- `versionName`: V79.
- `CURRENT_ENGINE_VERSION`: 69.
- Backup Schema: 4; leitura de schemas 1 a 4, incluindo Schema 3 da V78.

## Implementações incluídas
1. Máscaras de entrada para nascimento, ritmo, duração e distância, com normalização de ponto/vírgula decimal.
2. Calculadora unificada para relacionar distância, duração e pace, respeitando o tipo de prescrição e sem fabricar métricas indisponíveis.
3. Cards de sessão: sessões programadas mostram métricas previstas; sessões concluídas mostram métricas reais do mesmo registro, sem combinar valores de origens diferentes.
4. Importação GPX/FIT/TCX com voltas explícitas, parciais GPS, frações e trecho residual declarado quando a cobertura dos pontos GPS é menor que a distância total declarada. Trechos residuais são identificados como estimados/sem detalhe GPS.
5. Distribuição semanal com precisão de 0,1 km e participação do longão na progressão quando histórico, fase, recuperação e limites individuais permitem. Não existe aumento obrigatório do longão em toda semana.
6. Revisão assistida de zonas: tendência de execução abre explicação das evidências e opções para manter/observar ou solicitar teste; não há alteração automática de zonas.
7. Motor de estratégia individual de prova para 5 km, 10 km, 10 milhas, meia-maratona, maratona e distâncias personalizadas; fases de início, meio e final, com zonas/ritmos somente quando sustentados por evidências. Prioridades A/B/C são tratadas separadamente.
8. Gerenciamento de competições simplificado e tela exclusiva de estratégia, acessível pela agenda, plano e card da próxima prova.
9. Compactação dos cards semanais e do cabeçalho do plano; linhas de sessão e agenda de prova mais eficientes.
10. Backup Schema 4 e preservação da leitura dos backups anteriores.

## Correção posterior ao primeiro build do GitHub Actions
- O workflow reportou `Unresolved reference: KeyboardOptions` em `MainActivity.kt` (importação e chamadas dos campos). A causa era o pacote importado incorretamente. Corrigido para `androidx.compose.foundation.text.KeyboardOptions` e adicionada a dependência direta `androidx.compose.foundation:foundation`, alinhada ao Compose BOM 2026.09.00.
- Identidade V79 mantida; a correção não altera dados, prescrição ou backups.

## Validações executadas neste ambiente
- **10 verificações** de máscaras e calculadora unificada: aprovadas.
- **Cenários de estratégia** para 5 km, 10 km, 10 milhas, meia-maratona, maratona e ausência de evidências: aprovados no harness Kotlin/JVM.
- **Importador de atividades**: voltas explícitas + GPS e trilha GPS incompleta com distância declarada maior; ambos preservaram a cobertura total declarada de 6,62 km, distinguindo trechos medidos e residuais estimados.
- **Compilação dos motores de domínio Kotlin/JVM** (excluindo a Activity Android/Compose e classes de backup/exportação que dependem da camada Android): concluída na validação anterior à correção de import.
- **Correção estática Compose**: import `KeyboardOptions` revisado para `androidx.compose.foundation.text.KeyboardOptions`; dependência Foundation declarada diretamente. A Activity Android/Compose ainda precisa de compilação no GitHub Actions.
- **Carga semanal**: validação demonstrou aumento do longão de 7,2 km para 7,4 km ao passar a meta semanal de 18,0 km para 18,5 km, com precisão de décimos.


## Correção posterior: erros de tipos e escopo em TrainingWeekCard
- `MainActivity.kt:3820–3821`: `SecondaryButton.horizontalPadding` é `Int`; removidos os sufixos `.dp` nas chamadas Editar/Excluir.
- `MainActivity.kt:4359`: removido o acesso a `state` inexistente dentro de `TrainingWeekCard`. O componente agora recebe `onRaceStrategy: (RaceEvent) -> Unit`, fornecido pelo `PlanScreen`.
- Validado que o único call site de `TrainingWeekCard` fornece o callback e que não há outros `horizontalPadding` com tipo `Dp` na Activity.
- Reexecutados os harnesses JVM: 10 verificações de máscaras/calculadora, importador 6,62 km, estratégia de prova (cinco distâncias + guarda para evidência insuficiente) e distribuição de carga; todos aprovados.
- A compilação Android/Compose completa ainda depende do GitHub Actions; não declarar APK aprovado antes de `:app:testDebugUnitTest` e `:app:assembleDebug` concluírem com sucesso.

## Pendência obrigatória
A compilação Android/Compose completa e a suíte oficial `:app:testDebugUnitTest` **não foram executadas neste ambiente**. O ambiente de edição não possui Gradle CLI/Wrapper nem Android SDK. Os testes/harnesses Kotlin/JVM acima não substituem o build Android completo.

O workflow `.github/workflows/android.yml` está configurado para JDK 21, Android Platform 37, Build Tools 36.0.0 e Gradle 9.6.0. Após enviar o conteúdo deste ZIP ao repositório, execute o workflow `build-apk` e confirme:
- `:app:testDebugUnitTest`
- `:app:assembleDebug`
- Artefato `ai-running-coach-debug-apk`

Não instalar/distribuir o APK antes dessa confirmação.
