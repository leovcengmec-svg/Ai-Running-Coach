# Auditoria da estrutura dos treinos — V60

## Problemas corrigidos

1. A tela de sessão mostrava somente os quatro primeiros segmentos, escondendo o desaquecimento em sessões com cinco etapas. Agora mostra a estrutura completa.
2. Segmentos prescritos por tempo mantinham distância estimada internamente, mas a interface não a mostrava. Agora cada bloco por tempo exibe minutos e distância estimada total, além da estimativa por repetição quando aplicável.
3. A duração de blocos por tempo era estimada usando o pace médio da zona inteira, mesmo quando a faixa ativa da sessão era mais estreita. Agora usa o ponto médio da faixa ativa explícita.
4. Recuperações de fartlek e intervalados utilizavam Z1 ampla e podiam parecer mais lentas que o desaquecimento Z1 80–100%. Agora usam a transição confortável Z2 0–20%, com RPE auxiliar 2–3.
5. Fartlek tinha quatro repetições fixas e recuperação em Z1. O número de repetições agora varia entre 2 e 5 conforme nível e distância disponível; a distribuição reservada é 40% para os trechos fortes e 60% para recuperação aeróbia, sem ultrapassar o orçamento da sessão.
6. Corrida sustentada e sessão específica de maratona podiam colocar Z3 sem passar pela mesma elegibilidade das demais sessões aeróbias. Z3 agora depende dos critérios do motor; sem elegibilidade, a sessão permanece em Z2.
7. Os metadados internos `stimulus` também foram alinhados à prescrição real: `STEADY_RUN_Z2` e `MARATHON_ENDURANCE_Z2` quando Z3 não está liberada; variantes Z2–Z3 somente quando há bloco Z3 real.

## Convenções de intensidade

- Z1: aquecimento/desaquecimento (faixa ativa 80–100%) e sessões regenerativas dedicadas.
- Z2 0–20%: recuperação aeróbia muito confortável/transição entre repetições.
- Z2 20–65%: rodagem aeróbia convencional.
- Z3: estímulo moderado opcional, condicionado a experiência, carga recente, maior corrida e recuperação.
- Z4/Z5: mantidas apenas para sessões de qualidade específicas e com orientação por esforço; não são usadas para transformar uma rodagem em prova.

## Distância e interface

Os segmentos conservam sua distância estimada interna mesmo quando o alvo principal é tempo. O cálculo da sessão soma `distanceKm * repeatCount`. A interface mostra todos os segmentos, a soma dos blocos e a distância total da sessão. A estimativa de distância em segmentos por tempo é informativa, não substitui o alvo de tempo.

## Migração

`versionCode = 60`, `versionName = V60`, `engineVersion = 45`, `schemaVersion = 2`. Ao atualizar, somente sessões futuras são regeneradas pelo motor; semanas passadas, sessões concluídas e feedbacks permanecem preservados.

## Limitações de validação

A validação nesta sessão cobre compilação Kotlin de componentes puros e 110 testes direcionados do motor (110 aprovados, 0 falhas). A compilação Android completa deve ser confirmada no GitHub Actions.
