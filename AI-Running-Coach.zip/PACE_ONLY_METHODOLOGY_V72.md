# Metodologia de intensidade sem sensor cardíaco — V72

O AI Running Coach funciona com celular/GPS e não exige cinta, relógio com sensor cardíaco ou outro acessório. Nenhuma etapa de cadastro, teste, prescrição, calibração, análise de carga ou evolução depende de FC/FCM.

## Referência principal: ritmo individual

As zonas Z1–Z5 são faixas de pace em min/km, construídas a partir de testes e desempenho recente. A calibração pode usar Cooper 12 minutos, teste de 3 km, resultado recente de 5 km/10 km e evidência de atividades GPX com qualidade suficiente. Mudanças de faixa são graduais e devem respeitar a consistência dos resultados.

- Z1: recuperação/corrida muito leve.
- Z2: base aeróbia.
- Z3: moderado e sustentado.
- Z4: limiar/ritmo elevado estimado.
- Z5: estímulos intensos e curtos, somente quando elegíveis.

## Complementos sem equipamento

A percepção de esforço (RPE), o teste da fala, a respiração, a sensação de recuperação e a capacidade de sustentar o ritmo ajudam a interpretar o pace. São complementos, não uma conversão para frequência cardíaca. Em calor, subida, fadiga ou sono ruim, o atleta pode reduzir o ritmo para preservar o esforço pretendido.

## Dados cardíacos em arquivos importados

Alguns FIT/TCX/GPX exportados por relógios podem conter amostras cardíacas. Novas importações GPX/FIT/TCX ignoram os campos cardíacos: não os extraem nem calculam. Valores já existentes em backups antigos permanecem apenas para compatibilidade histórica. A V72 não os usa para calcular zonas, distribuição de intensidade, prontidão, carga, análise de bloco, progressão ou recomendação e não os exibe como requisito de treino.

## Fontes e distinção de metodologia

Os anexos 5K Sub 30 e 10K Sem Parar apresentam zonas e ajustes de pace baseados em resultados recentes e testes. O NRC também trata os paces como faixas de orientação, considerando esforço e variações das condições. As tabelas de FC/FCM de outros anexos são deliberadamente excluídas da implementação conforme decisão de produto do usuário.
