# Test report — V88

## Domain compilation
- `kotlinc` compilation of 48 non-Android domain Kotlin production files: PASS.
- MainActivity/Compose, Android backup manager, PaceCoachExporter and Android date field were excluded from the isolated JVM harness.

## Focused tests
- `ZoneIntensityBandEngineTest`: 23/23 PASS (including V84 auto-WALK migration, Fartlek active-Z2 recovery, progression migration, idempotency and preserved completed history).
- `CoachEngineTest` + `TrainingPrescriptionAuditTest`: 48 PASS, 2 FAIL.
- Combined: 71 PASS, 2 FAIL out of 73.

## Remaining baseline failures
The following two beginner run/walk tests also fail against the unmodified V87 baseline with the same assertion result; they are not introduced by V88:
- `iniciante com muitos dias disponiveis preserva frequencia escolhida em corrida caminhada`
- `iniciante com teste de campo recebe corrida ativa em Z2 mesmo no formato corrida caminhada`

The V87 baseline also had failing Fartlek distance-reconciliation checks; those pass in V88 after recovery-distance reallocation.

## Not run
- Full Gradle `:app:testDebugUnitTest`
- Android `:app:assembleDebug`
- Device/Compose UI tests

These require the Android Gradle environment and must be completed by GitHub Actions before treating the APK as approved.
