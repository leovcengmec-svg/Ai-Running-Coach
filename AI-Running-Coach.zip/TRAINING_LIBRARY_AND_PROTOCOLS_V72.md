# Biblioteca de treinos e protocolos — V72

## Estrutura

A biblioteca está organizada em três camadas: (1) tipos de sessão, (2) protocolos tipados de blocos e (3) programas de periodização. O tipo descreve a sessão (Rodagem, Longão, Tempo Run, Fartlek, Intervalado); o objetivo descreve a execução (leve, moderada, progressiva, regressiva ou específica).

## Tipos de sessão

- Rodagem: leve, moderada, regenerativa, contínua, progressiva, regressiva e com final forte.
- Longão: contínuo, progressivo, regressivo, com blocos ou com ritmo específico.
- Qualidade: intervalos por distância, intervalos por tempo, Tempo Run, limiar, Fartlek, piramidal, subida, repetições curtas/longas e ritmo específico.
- Caminhada/corrida: alternância, trote, corrida leve, aumento dos blocos corridos e redução das pausas.
- Preparação: caminhada, ativação, aquecimento progressivo, acelerações controladas e desaquecimento.

## Protocolos nomeados

`TrainingProtocolCatalog` mantém um contrato de dose para cada protocolo: modalidade DISTANCE ou TIME, tamanho exato do estímulo, quantidade de repetições e recuperação. A validação exige também a quantidade correta de recuperações (uma a menos que o número de repetições de trabalho).

Exemplos atualmente tipados: I04 = 4 × 3 min; I05 = 6 × 400 m; I06 = 4 × 800 m; I07 = 5 × 600 m; I08 = 5 × 800 m; I09 = 3 × 1.000 m; I10 = 3 × 1.600 m. T04/T05 são Tempo Run intervalados; RP05/RP10/RP15/RP21 são blocos de ritmo específico.

Uma sessão chamada `Intervalado 5 × 600 m` deve conter cinco blocos de 600 m e quatro recuperações. O código só é mostrado em metadados internos e testes; não compõe o título visível. Se a dose nomeada não couber no orçamento de segurança, o motor deve trocar para uma sessão aeróbia e retirar o nome do intervalo, nunca converter silenciosamente distância em duração.

## Referências fornecidas pelo usuário

- O2 Corre: 5 km iniciante (8 semanas), intermediário (8) e avançado (4); 10 km iniciante (12), intermediário (8) e avançado (8). Os quadros mostram alternância semanal de rodagem, intervalos e sessões mais longas.
- BR Corrida, 5K Sem Parar: programa de 12 semanas com caminhada/trote, redução gradual das pausas, blocos corridos mais longos e transição para corrida contínua. A leitura da planilha descreve aquecimento de caminhada, bloco principal e desaquecimento.
- BR Corrida, 10K Sem Parar: programa de 12 semanas com transição a partir dos 5 km, blocos por distância e sessões de resistência.
- BR Corrida, 5K Sub 30: programa de 8 semanas com ritmos por zonas, intervalos por distância e testes de 5 km para recalibrar os ritmos.
- Nike Run Club, meia maratona: programa de 14 semanas que combina velocidade, resistência, recuperação, intervalos, Fartlek, subidas, Tempo Run e longões.
- Nike Run Club, maratona: programa de 18 semanas com corridas de recuperação, velocidade, longões, dias de descanso e redução antes da prova.

As tabelas de FC/FCM presentes em algumas planilhas não são implementadas. A V72 não converte essas tabelas, não cria zonas cardíacas e não depende de sensor cardíaco.

## Referência própria do aplicativo: 15 km

Os anexos não fornecem uma planilha específica de 15 km. A V72 trata essa distância como uma ponte própria entre 10 km e meia maratona: base e resistência sustentada, blocos de ritmo, limiar quando elegível e longões progressivos. O protocolo RP15 é uma heurística da aplicação (3 × 6 min), não uma cópia de uma planilha de origem.
