# Status de build — AI Running Coach V105

- `versionCode = 105`
- `versionName = V105`
- `CURRENT_ENGINE_VERSION = 95`
- Backup Schema `17`; decoder compatível com schemas `1–17`.
- Base: ZIP V104 íntegro.

## Estado

- Código-fonte V105 integrado e pacote ZIP a validar após geração.
- Harness Kotlin/JVM focalizados: 17/17 assertions aprovadas (3 PersonalRecords, 10 calibração e 4 estratégia/exportação).
- Verificação de delimitadores em doze arquivos críticos: aprovada.
- Testes JUnit foram atualizados no projeto, mas não executados oficialmente pelo Gradle nesta sessão.
- APK não gerado: `gradle` indisponível, nenhum `gradlew` incluído no projeto e Android SDK não configurado neste ambiente.

## CI obrigatório

O workflow `.github/workflows/android.yml` deve executar:

```bash
gradle -p android :app:testDebugUnitTest :app:assembleDebug --no-daemon
```

A homologação exige workflow verde, publicação do APK pelo workflow e teste no aparelho, principalmente de registro de prova, compartilhamento JSON no Pace Coach, backup/restauração e redefinição com reavaliação do histórico.
