package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class RaceStrategyEngineTest {
    private val today = LocalDate.of(2026, 11, 20)
    private val zones = PaceCalculator.calculateCooper(2.6)

    private fun evidence(distance: Double, pace: Int, zone: String = "Z3", index: Int = 0) = RacePaceEvidence(
        date = today.minusDays(index.toLong() + 1), distanceKm = distance, paceSecondsPerKm = pace,
        effort = "Ok", feeling = "Bem", painPresent = false, source = "ACTIVITY",
        workoutType = if (distance >= 10.0) "LONGÃO" else "RODAGEM", sessionId = "session-$index"
    )

    @Test fun `estrategia possui tres fases e cobre distancia da prova de cinco km`() {
        val event = RaceEvent("5k", "Corrida 5 km", 5.0, today.plusDays(30).toString(), "A", "25:00")
        val result = RaceStrategyEngine.build(event, TrainingGoalIntent.PERSONAL_BEST, zones, listOf(
            evidence(5.0, 330, index = 0), evidence(5.0, 328, index = 1), evidence(5.0, 332, index = 2)
        ), today)
        assertEquals(3, result.phases.size)
        assertEquals(5.0, result.phases.sumOf { it.distanceKm }, 0.0001)
        assertEquals("Estratégia de 5 km", result.title)
        assertTrue(result.phases.all { it.fastestPaceSecondsPerKm == null || it.slowestPaceSecondsPerKm!! >= it.fastestPaceSecondsPerKm!! })
    }

    @Test fun `estrategias diferenciam distancias curtas meia e maratona`() {
        fun build(distance: Double) = RaceStrategyEngine.build(
            RaceEvent("race-$distance", "Evento", distance, today.plusDays(40).toString()),
            TrainingGoalIntent.COMPLETE, zones,
            listOf(evidence(15.0, 390, index = 0), evidence(18.0, 395, index = 1), evidence(16.0, 392, index = 2)), today
        )
        val five = build(5.0)
        val tenMiles = build(16.09)
        val half = build(21.1)
        val marathon = build(42.195)
        assertEquals("Z4", five.phases[1].zone)
        assertEquals("Z3", tenMiles.phases[1].zone)
        assertEquals("Z3", half.phases[1].zone)
        assertEquals("Z2", marathon.phases[1].zone)
        assertNotEquals(five.title, marathon.title)
        assertNotNull(marathon.readinessNote)
    }

    @Test fun `prioridade C recebe orientacao de prova de treinamento`() {
        val event = RaceEvent("c", "Prova treino", 10.0, today.plusDays(20).toString(), "C", "50:00")
        val result = RaceStrategyEngine.build(event, TrainingGoalIntent.COMPLETE, zones, listOf(evidence(10.0, 360)), today)
        assertTrue(result.pacingNotes.any { it.contains("estímulo de treinamento") })
    }

    @Test fun `bloco curto nao vira referencia direta de ritmo para a prova`() {
        val event = RaceEvent("short", "10 km", 10.0, today.plusDays(30).toString(), "A", "")
        val shortInterval = RacePaceEvidence(
            date = today.minusDays(1), distanceKm = 0.4, paceSecondsPerKm = 250,
            effort = "Ok", feeling = "Bem", painPresent = false, source = "BLOCK",
            zone = "Z4", sessionId = "interval-session", durationSeconds = 100
        )
        val withoutEvidence = RaceStrategyEngine.build(event, TrainingGoalIntent.COMPLETE, zones, emptyList(), today)
        val withShortInterval = RaceStrategyEngine.build(event, TrainingGoalIntent.COMPLETE, zones, listOf(shortInterval), today)
        assertEquals(withoutEvidence.phases[1].fastestPaceSecondsPerKm, withShortInterval.phases[1].fastestPaceSecondsPerKm)
        assertEquals(0, withShortInterval.evidenceCount)
    }

    @Test fun `bloco sustentado pode contribuir para a estrategia na sua zona`() {
        val event = RaceEvent("sustained", "10 km", 10.0, today.plusDays(30).toString(), "A", "")
        val sustainedBlock = RacePaceEvidence(
            date = today.minusDays(1), distanceKm = 1.2, paceSecondsPerKm = 300,
            effort = "Ok", feeling = "Bem", painPresent = false, source = "BLOCK",
            zone = "Z4", sessionId = "tempo-session", durationSeconds = 420
        )
        val result = RaceStrategyEngine.build(event, TrainingGoalIntent.COMPLETE, zones, listOf(sustainedBlock), today)
        assertEquals(1, result.evidenceCount)
        assertEquals(304, (result.phases[1].fastestPaceSecondsPerKm!! + result.phases[1].slowestPaceSecondsPerKm!!) / 2)
    }

    @Test fun `tempo alvo isolado sem zonas nem treinos nao vira prescricao de ritmo`() {
        val event = RaceEvent("sem-evidencia", "Prova sem histórico", 10.0, today.plusDays(30).toString(), "A", "50:00")
        val result = RaceStrategyEngine.build(event, TrainingGoalIntent.COMPLETE, null, emptyList(), today)
        assertTrue(result.phases.all { it.fastestPaceSecondsPerKm == null && it.slowestPaceSecondsPerKm == null })
        assertTrue(result.targetAssessment.contains("referência matemática ainda não validada"))
        assertNull(result.estimatedTimeMinSeconds)
    }

    @Test fun `meta muito mais rapida que evidencias nao vira ritmo garantido`() {
        val event = RaceEvent("fast", "Meta agressiva", 5.0, today.plusDays(30).toString(), "A", "10:00")
        val result = RaceStrategyEngine.build(event, TrainingGoalIntent.PERSONAL_BEST, zones, listOf(
            evidence(5.0, 360), evidence(5.0, 355, index = 1), evidence(5.0, 358, index = 2)
        ), today)
        assertTrue(result.targetAssessment.contains("mais rápida") || result.targetAssessment.contains("acima"))
        assertTrue(result.pacingNotes.any { it.contains("aspiracional") && it.contains("não foi imposto") })
    }
    @Test fun `tempo alvo de 37 minutos orienta estrategia tambem para prioridade C`() {
        val event = RaceEvent("c-37", "Prova treino", 5.0, today.plusDays(30).toString(), "C", "37:00")
        val recent = listOf(
            evidence(5.0, 450, index = 0),
            evidence(5.0, 448, index = 1),
            evidence(5.0, 452, index = 2)
        )
        val result = RaceStrategyEngine.build(event, TrainingGoalIntent.PERSONAL_BEST, zones, recent, today)
        assertEquals(444, result.targetPaceSecondsPerKm)
        assertTrue(result.targetPaceDriven)
        assertEquals("COMPATIBLE", result.targetStatus)
        assertTrue(result.phases.all { it.fastestPaceSecondsPerKm != null && it.slowestPaceSecondsPerKm != null })
        val weightedCenter = result.phases.sumOf { phase ->
            phase.distanceKm * ((phase.fastestPaceSecondsPerKm!! + phase.slowestPaceSecondsPerKm!!) / 2.0)
        } / 5.0
        assertTrue("Pace médio ${weightedCenter}s deveria ficar próximo de 444s", kotlin.math.abs(weightedCenter - 444.0) <= 1.0)
        assertTrue(result.estimatedTimeMinSeconds!! <= 37 * 60)
        assertTrue(result.estimatedTimeMaxSeconds!! >= 37 * 60)
        assertTrue(result.pacingNotes.any { it.contains("Prioridade C") && it.contains("tempo-alvo") })
        assertFalse(result.targetAssessment.contains("apenas como informação"))
    }

    @Test fun `prioridades A B e C preservam tempo alvo e mudam o tom da estrategia`() {
        val recent = listOf(evidence(5.0, 450), evidence(5.0, 448, index = 1), evidence(5.0, 452, index = 2))
        fun build(priority: String) = RaceStrategyEngine.build(
            RaceEvent("race-$priority", "Prova", 5.0, today.plusDays(30).toString(), priority, "37:00"),
            TrainingGoalIntent.PERSONAL_BEST, zones, recent, today
        )
        val a = build("A")
        val b = build("B")
        val c = build("C")
        listOf(a, b, c).forEach { result ->
            assertTrue(result.targetPaceDriven)
            assertEquals(444, result.targetPaceSecondsPerKm)
            assertEquals(5.0, result.phases.sumOf { it.distanceKm }, 0.0001)
        }
        assertNotEquals(a.phases.first().fastestPaceSecondsPerKm, b.phases.first().fastestPaceSecondsPerKm)
        assertNotEquals(b.phases.first().fastestPaceSecondsPerKm, c.phases.first().fastestPaceSecondsPerKm)
        assertTrue(a.pacingNotes.first().contains("Prioridade A"))
        assertTrue(b.pacingNotes.first().contains("Prioridade B"))
        assertTrue(c.pacingNotes.first().contains("Prioridade C"))
    }

    @Test fun `meta conservadora permanece como ritmo de execucao sem acelerar para a zona`() {
        val event = RaceEvent("conservative", "Prova controlada", 5.0, today.plusDays(30).toString(), "B", "40:00")
        val recent = listOf(evidence(5.0, 400), evidence(5.0, 398, index = 1), evidence(5.0, 402, index = 2))
        val result = RaceStrategyEngine.build(event, TrainingGoalIntent.PERSONAL_BEST, zones, recent, today)
        assertEquals(480, result.targetPaceSecondsPerKm)
        assertEquals("CONSERVATIVE", result.targetStatus)
        assertTrue(result.targetPaceDriven)
        assertTrue(result.targetAssessment.contains("mais conservador"))
        assertTrue(result.phases.all { it.fastestPaceSecondsPerKm != null })
    }

    @Test fun `meta sem zonas nem evidencias mostra pace matematico mas nao inventa fases`() {
        val event = RaceEvent("unverified", "Prova sem dados", 5.0, today.plusDays(30).toString(), "B", "37:00")
        val result = RaceStrategyEngine.build(event, TrainingGoalIntent.PERSONAL_BEST, null, emptyList(), today)
        assertEquals(444, result.targetPaceSecondsPerKm)
        assertEquals("UNVERIFIED", result.targetStatus)
        assertFalse(result.targetPaceDriven)
        assertTrue(result.phases.all { it.fastestPaceSecondsPerKm == null })
        assertTrue(result.targetAssessment.contains("referência matemática ainda não validada"))
    }

}
