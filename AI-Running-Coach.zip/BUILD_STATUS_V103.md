# Build status — AI Running Coach V103

- VersionCode: `103`
- VersionName: `V103`
- Motor interno: `93`
- Backup Schema: `15` (leitura compatível dos schemas `1–15`)
- Fonte Android principal: `android/app/src/main/java/com/airunningcoach/app/`

## Situação

O código-fonte e a documentação V103 foram atualizados. O ZIP de origem preserva a estrutura de projeto Android e o workflow de build. Não foi possível produzir APK neste ambiente: o ZIP não contém `gradlew`/Gradle Wrapper, não há Gradle instalado e não há Android SDK configurado.

## Comando CI

O workflow `.github/workflows/android.yml` configura JDK 21, Android SDK (platform 37/build-tools 36.0.0) e Gradle 9.6.0, então executa:

```bash
gradle -p android :app:testDebugUnitTest :app:assembleDebug --no-daemon
```

O artefato APK é publicado pelo job `build-apk` após os testes JUnit e `assembleDebug` terminarem com sucesso.

## Validação realizada localmente

- 16 cenários de motor executados com sucesso no harness Kotlin/JVM, compilando os arquivos reais `AdaptiveZoneCalibrationEngine.kt`, `PerformanceMonitoringEngine.kt` e `LoadPrescriptionEngine.kt` com modelos mínimos de domínio para isolar dependências Android.
- Os testes JUnit do projeto foram ampliados, mas **não foram executados pelo Gradle oficial** nesta sessão.
- A validação do harness não equivale a compilação Android/Compose, execução JUnit oficial ou APK aprovado.
