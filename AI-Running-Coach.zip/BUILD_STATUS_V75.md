# Build e validação — AI Running Coach V75

## Identificação
- `versionCode = 75`
- `versionName = V75`
- `CURRENT_ENGINE_VERSION = 64`
- Backup Schema 3; leitura de schemas 1–3 preservada.

## Verificações executadas
- `kotlinc` compilou os arquivos de domínio Kotlin, exceto `MainActivity.kt`, `AppBackupManager.kt` e `PaceCoachExporter.kt` (dependências Android/JSON ausentes), usando stub temporário para `Workout`; compilação aprovada com warnings não bloqueantes.
- Harness independente: catálogo de KM-base/teto/capacidade presumida, base de 45 km/semana para maratona sem histórico, deload e progressão, distinção entre quatro prioridades e bloqueio de walk/run com 5 km realizados aprovados.
- Testes de regressão adicionados/atualizados em `TrainingPlanReferenceCatalogTest.kt`, `LoadPrescriptionEngineV63Test.kt`, `CoachEngineTest.kt` e `AppBackupCodecTest.kt`.
- `unzip -t` do pacote de entrada será executado após a montagem do ZIP de saída.

## Não executado neste ambiente
- Suíte JUnit completa via Gradle.
- Compilação Android/Compose e APK debug/release.
- Teste em aparelho físico.

Motivo: este ambiente não possui Gradle Wrapper, Gradle CLI nem Android SDK. O workflow `.github/workflows/build-apk.yml` instala JDK 21, Android SDK e Gradle 9.6.0; deve executar `:app:testDebugUnitTest` e `:app:assembleDebug` no GitHub Actions.

## Cenários de aceite no aparelho
1. 42,2 km com os campos de volume e maior percurso vazios: apresentar base 45 km/semana, teto 80 km e capacidade presumida de 21,1 km.
2. 21,1 km sem os dois campos: apresentar base 30 km/semana e capacidade presumida de 16,1 km.
3. Corredor com 5 km contínuos: nenhuma sessão completa de corrida/caminhada, inclusive nas alternativas/rest day.
4. Iniciante real com meta até 5 km e sem capacidade contínua: caminho de corrida/caminhada.
5. Alternar Completar, Contínuo, Recorde Pessoal e Tempo-alvo: plano marca recálculo e altera a estratégia, preservando treinos concluídos.
6. Importar backup V71/V72/V73/V74 e confirmar restauração sem perda de sessões concluídas, feedbacks e avaliações.
