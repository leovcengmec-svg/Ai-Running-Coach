# AI Running Coach — Relatório de implementação V98

**Base:** V97  
**Versão:** V98 — `versionCode 98`, `versionName V98`  
**Motor interno:** 88  
**Backup Schema:** 13, compatível com leitura de schemas 1–12  
**Data:** 26/11/2026

## Implementação realizada

### 1. Backup e avaliações fisiológicas

- `createPlan()` não chama mais `saveCurrentFieldTestToHistory()` e não grava testes ao criar/recalcular o plano.
- A geração do plano usa a avaliação fisiológica ativa já salva; rascunhos transitórios vazios não são validados nem promovidos a histórico.
- Removido também o segundo caminho que recriava um registro Cooper ao final de `createPlan()`.
- O modo provisório `NONE` não promove o último teste guardado a uma referência selecionada para o novo plano.
- A leitura de snapshots antigos reconstrói zonas conforme o protocolo real: Cooper a partir de distância, 3 km a partir do tempo e referência fisiológica.
- Avaliações ganharam `recordId`, `deletedAtIso` e `updatedAtIso`, com migração de IDs legados determinística.
- Leituras de revisão, comparações e escolha de último teste ativo excluem registros removidos.
- Adicionadas operações de editar, remover logicamente e restaurar testes, com reancoragem da referência fisiológica quando o teste mais recente muda.
- A edição permite corrigir registros históricos anteriores a 56 dias; o limite de recência continua sendo aplicado à entrada de novos testes.
- A edição/exclusão/restauração não recalcula automaticamente o plano; apenas marca a necessidade de revisão quando há um plano salvo.
- A tela distingue consulta do teste salvo e formulário explícito de novo teste. Cada teste tem ações discretas no menu de três pontos.

### 2. Histórico de treinos

- Para sessões concluídas com feedback vinculado, removida a composição duplicada `WorkoutCard()` + `FeedbackHistoryDetails()`.
- O card único expansível mostra data/horário, distância, duração, ritmo médio e estado; detalhes, parciais, zonas, blocos, percurso e observações ficam dentro da própria superfície.
- Ações contextuais passaram para menu discreto, preservando edição, vínculo, remoção, restauração e exclusão definitiva com confirmação.
- Filtros Todos/Semana/Mês/Ano e resumo por sessões, distância e duração medida foram mantidos/organizados no mesmo histórico.

### 3. Interface do cadastro

- As referências automáticas do objetivo agora são identificadas como estimativas padrão e aplicadas somente quando o campo declarado está vazio.
- O volume e a maior sessão declarados são mostrados separadamente dos dados medidos; a cópia anterior que sugeria adoção automática pelo histórico foi removida.

### 4. Versionamento e backup

- `versionCode = 98`, `versionName = V98`, motor 88 e Backup Schema 13.
- A leitura dos schemas anteriores 1–12 permanece habilitada.
- O JSON de cada avaliação inclui identidade, estado de remoção e timestamp de atualização; o backup preserva também os registros removidos, para restauração posterior.

## Limites da validação nesta entrega

- O harness Kotlin/JVM isolado que compila a implementação real de `CooperAssessmentManagementEngine` passou cinco cenários de ciclo de vida: migração de IDs, seleção do último teste ativo, exclusão lógica, restauração e substituição por ID.
- A checagem estática confirmou a remoção dos dois caminhos de gravação de teste de dentro de `createPlan()`, a serialização/reidratação dos campos novos, o fallback de 3 km pelo cálculo específico, o uso de avaliações ativas e a remoção do card duplicado quando há feedback associado.
- O parser Kotlin foi executado sobre `MainActivity.kt` sem erros sintáticos reportados. A compilação sem classpath do Android/Compose retornou símbolos não resolvidos, como esperado, e não substitui a compilação Gradle.
- Os testes JUnit de gestão do teste e de codec/compatibilidade de backup foram adicionados ou atualizados, mas não puderam ser executados aqui.
- Não foi possível executar `:app:testDebugUnitTest` nem `:app:assembleDebug`: este ambiente não tem Gradle, wrapper `gradlew` nem Android SDK. A aprovação de compilação e APK depende do workflow GitHub Actions.

## Arquivos principais alterados

- `android/app/src/main/java/com/airunningcoach/app/MainActivity.kt`
- `android/app/src/main/java/com/airunningcoach/app/CooperAssessmentEngine.kt`
- `android/app/src/main/java/com/airunningcoach/app/CooperAssessmentManagementEngine.kt` (novo)
- `android/app/src/main/java/com/airunningcoach/app/AppBackupManager.kt`
- `android/app/build.gradle.kts`
- `android/app/src/test/java/com/airunningcoach/app/CooperAssessmentManagementEngineTest.kt` (novo)
- `android/app/src/test/java/com/airunningcoach/app/AppBackupCodecTest.kt`

**Conclusão:** as correções da V98 foram incorporadas ao source set Android do projeto V97 e empacotadas. A validação de compilação Android/JUnit oficial permanece pendente do CI.
