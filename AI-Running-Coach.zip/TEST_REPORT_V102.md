# Relatório de testes — AI Running Coach V102

Data da validação: 2026-11-27

## Resultado

- **7/7 testes focados do `HistorySnapshotEngineTest` aprovados** em harness Kotlin/JVM local.
- **28/28 verificações estáticas aprovadas** para versão, layout, rolagem, indexação, vínculo, ações e compatibilidade de backup.
- **Integridade do ZIP:** será registrada após o empacotamento final.

## Testes focados executados

1. Vínculo exato por identidade de sessão e soma apenas de medidas reais.
2. Compatibilidade de ID antigo por vaga canônica única.
3. Vagas canônicas ambíguas permanecem sem vínculo.
4. Data realizada isolada não cria vínculo.
5. Registros removidos permanecem separados e fora do resumo ativo.
6. Filtros Semana/Mês/Ano usam a mesma janela na lista e no resumo.
7. Volume de 1.000 sessões mantém chaves únicas e reutiliza o snapshot para filtros.

## Verificações estáticas

Foram conferidos: `versionCode=102`, `versionName=V102`, motor 92, Backup Schema 14, `HistoryScreen` sem `verticalScroll`, `LazyColumn` ocupando o espaço restante, cabeçalho fora da lista, filtros segmentados, remoção de “Sessões registradas”, chaves estáveis, montagem do snapshot em `Dispatchers.Default`, preservação de registros órfãos/removidos, ações de edição/remoção/restauração, detalhes recolhidos e expansão, ícone da modalidade, fallback canônico único e ausência de vínculo por data realizada isolada.

Também foi conferido que a troca de período reposiciona a lista no topo de forma previsível e que o rótulo do filtro semanal termina na data atual, coerente com a janela filtrada.

## Limitações da validação local

- O harness usa o código real de `HistorySnapshotEngine.kt`, `SessionIdentityEngine.kt`, `ActivityDateResolver.kt` e os testes V102, com modelos mínimos e shim JUnit local. Portanto, **não substitui** a execução do JUnit oficial do Android.
- A checagem de sintaxe isolada de `MainActivity.kt` não encontrou diagnósticos de sintaxe, mas a compilação Kotlin interrompeu por ausência das dependências Android/Compose no classpath.
- Não foi possível executar `:app:testDebugUnitTest`, `:app:assembleDebug`, testes instrumentados Compose ou gerar APK: este ambiente não tem Gradle instalado, wrapper Gradle no pacote ou Android SDK configurado.
- O tempo de resposta e a fluidez visual precisam de validação final em aparelho Android, com histórico real e volume elevado.

## Parecer

Os testes focados e estáticos sustentam a integridade lógica do snapshot e a estrutura proposta. A aprovação da compilação Android e da experiência visual final permanece condicionada ao GitHub Actions e ao teste no aparelho.
