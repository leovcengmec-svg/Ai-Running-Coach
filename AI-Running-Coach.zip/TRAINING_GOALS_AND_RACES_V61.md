# Objetivos e competições — AI Running Coach V61

## Objetivos
O catálogo inclui milha, 3 km, 5 km, 10 km, 15 km, meia maratona, maratona, ultramaratona de 50 km, saúde/qualidade de vida e objetivo personalizado entre 1 e 100 km. Os rótulos de distância de versões anteriores continuam aceitos.

O objetivo Saúde é uma categoria distinta: mantém o volume e frequência dentro da tolerância, prioriza esforço fácil e não libera automaticamente limiar, VO₂ ou progressões de qualidade em Z3. Objetivos competitivos usam a distância-alvo para selecionar a especialização do macrociclo.

## Prioridades de competição
- A — prova principal: pode definir o horizonte do macrociclo, taper e bloco de recuperação pós-prova.
- B — preparatória: substitui uma sessão na semana do evento, sem taper e sem recuperação pós-prova automática.
- C — evento de treinamento: também substitui uma sessão, sem alterar o macrociclo.

Apenas eventos A podem alterar a janela do ciclo e assumir a distância-alvo principal. Essa regra também se aplica à restauração e ao recálculo de ciclos existentes.

Taper e recuperação pós-prova são ajustes automáticos apenas para A. A recuperação real ainda deve ser observada por feedback, dor, esforço e atividades registradas.

## Limitações explícitas
O tempo-alvo registrado para uma prova permanece no cadastro e no calendário do evento; nesta revisão, ele ainda não é convertido automaticamente em pace-alvo de cada sessão. O pace de treino continua baseado nas zonas individualizadas e no RPE. Não se deve interpretar um objetivo temporal como limiar fisiológico medido.
