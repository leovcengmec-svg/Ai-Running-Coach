# Build status — AI Running Coach V90

- Base: V89
- `versionCode = 90`
- `versionName = V90`
- `CURRENT_ENGINE_VERSION = 79`
- Backup Schema 5; leitura de schemas 1–5 preservada.

## Implementado

- Progressão de carga semanal graduada: alertas moderados reduzem para 1–2%; sinais severos mantêm a carga; dor mantém bloqueio.
- Semana regenerativa mantém a referência anterior de construção.
- Limite progressivo do longão não congela por cautela moderada isolada.
- Justificativa de carga e percentual planejado persistidos opcionalmente por sessão e exibidos nas semanas.
- Gráfico e cards usam a mesma consolidação de semanas (treinos + provas válidas).
- Calendário com oito categorias, cores padronizadas, ✓ concluído, × não realizado e pendente para hoje/futuro.
- Campos novos com defaults legados e Schema 5; leitores antigos seguem compatíveis.

## Build/validação oficial

- Testes unitários novos foram adicionados ao projeto.
- `:app:testDebugUnitTest`: pendente de GitHub Actions.
- `:app:assembleDebug`: pendente de GitHub Actions.
- APK: não foi gerado nesta sessão; não declarar build Android aprovado antes do workflow verde.

O ZIP mantém os workflows `.github/workflows/android.yml` e `release-apk.yml`.

## Correção de build após log do GitHub Actions

- Corrigido no source set Android o símbolo `rememberZoneBoundaries`, ausente apesar das quatro chamadas no `MainActivity.kt`.
- A função grava `ZoneCalibrationEngine.boundaryValues(zones)` em `lastZoneBoundarySnapshot` e não limpa o snapshot em chamada com `null`.
- Mantidos VersionCode 90, VersionName V90, motor 79 e Backup Schema 5.
- A correção estática do símbolo foi verificada; a compilação Gradle/Android e a suíte JUnit oficiais ainda devem ser confirmadas no GitHub Actions.
- Detalhes em `BUILD_FIX_V90_KOTLIN_REMEMBER_ZONE_BOUNDARIES.md`.
