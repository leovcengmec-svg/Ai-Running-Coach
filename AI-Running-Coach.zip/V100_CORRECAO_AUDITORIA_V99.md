# AI Running Coach V100 — Relatório de implementação

**Base:** V99  
**VersionCode:** 100  
**VersionName:** V100  
**Motor interno:** 90  
**Backup Schema:** 13 (mantido; leitura compatível de schemas 1–13)

## 1. Recalibração e orçamento do reteste

- `TrainingCalendarIntegrityEngine.validate()` agora recebe a última avaliação fisiológica ativa, quando disponível.
- Retestes futuros sem método continuam sendo compromissos de agenda e não são tratados como sessões de 0 km.
- A distância reservada para o reteste usa esta precedência:
  1. `RetestOriginalSessionSnapshot.distanceKm` válido, da sessão original substituída;
  2. para backups sem snapshot, maior estimativa **completa** entre os protocolos elegíveis, calculada a partir da avaliação ativa com `RetestDistanceEstimator`;
  3. sem snapshot válido e sem estimativa completa, a verificação exata da participação e da dominância do longão fica pendente até a escolha do protocolo, sem inventar 5 km.
- Quando Cooper/3 km é escolhido, a sessão montada e sua distância total passam a compor a semana; o snapshot não é somado novamente.
- A comparação usa o valor integral e aceita 40,0%; somente valores acima de 40% são bloqueados.
- A mensagem de bloqueio identifica a distância reservada e a origem do orçamento, além da composição semanal.
- As duas chamadas de validação em `MainActivity.kt` fornecem a avaliação fisiológica ativa, permitindo fallback em backups antigos sem snapshot.

## 2. Calendário compacto

- `WorkoutCalendarGrid.monthDates()` gera somente 4, 5 ou 6 linhas conforme o mês, em semana iniciada na segunda-feira.
- A célula mensal foi reduzida de 94 dp para 68 dp.
- A grade mostra dia e até duas siglas; compromissos adicionais aparecem como `+N`.
- Cada sessão recebe categoria canônica única e código: REG, ROD, INT, FAR, LIM, LNG, PRV ou TST.
- A grade não usa mais o título original da sessão, evitando rótulos como “Rodagem aeróbia” e “Longão aeróbio”.
- Agenda do dia/semana usa linha compacta com sigla, estado e distância; o título e os blocos completos continuam acessíveis ao abrir a sessão.
- A legenda usa siglas e nomes completos em layout de quatro colunas quando a largura permite, ou duas colunas em telas estreitas. ✓ e × permanecem disponíveis como estados explícitos.

## 3. Compatibilidade e preservação

- Backup Schema 13 mantido: a V100 reutiliza o snapshot já persistido e não cria campos novos.
- Tipos e títulos antigos permanecem nos dados para compatibilidade; a normalização é aplicada apenas à apresentação do calendário.
- Nenhuma mudança na lógica de carga declarada, piso de sessão de 5 km, semana Regenerativa, protocolo caminhada/corrida ou teto de 40% fora da correção do orçamento do reteste.

## 4. Arquivos alterados

- `android/app/src/main/java/com/airunningcoach/app/TrainingCalendarIntegrityEngine.kt`
- `android/app/src/main/java/com/airunningcoach/app/WorkoutCalendarPresentation.kt`
- `android/app/src/main/java/com/airunningcoach/app/MainActivity.kt`
- `android/app/src/test/java/com/airunningcoach/app/TrainingCalendarIntegrityEngineTest.kt`
- `android/app/src/test/java/com/airunningcoach/app/WorkoutCalendarPresentationTest.kt`
- `android/app/build.gradle.kts`
- `README.md`, `README_GITHUB_ANDROID.md`, `CHANGELOG.md`, `PROJECT_STATUS.md`

## 5. Validação executada

- Harness Kotlin/JVM isolado com os dois arquivos de teste: **34 aprovados / 0 falhas**.
- Cobertura incluída: snapshot 5,1 km = 40,0%; snapshot 5,0 km permanece acima de 40%; sem snapshot/sem estimativa não inventa orçamento; método escolhido não duplica snapshot; fallback completo por avaliação; siglas; meses de 4/5/6 semanas.
- Integridade ZIP verificada após empacotamento.
- Gradle/JUnit oficial, `:app:assembleDebug` e APK não foram executados neste ambiente porque não há Gradle CLI/Wrapper nem Android SDK instalados. A aprovação Android depende do GitHub Actions.
