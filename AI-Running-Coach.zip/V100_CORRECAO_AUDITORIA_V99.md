# AI Running Coach V100 — Relatório de implementação

**Base:** V99  
**Versão:** VersionCode 100 · VersionName V100  
**Motor interno:** 90  
**Backup Schema:** 14 (leitura compatível dos schemas 1–13)  
**Data:** 26/11/2026

## 1. Preservação do ciclo de oito semanas

Implementado em `PlanMigrationEngine.kt` e integrado em `MainActivity.kt`:

- Estado persistido `TrainingCycleState`, com identidade, âncora de segunda-feira, duração, status, assinatura do objetivo, assinatura pendente, prova principal, snapshot do perfil e sessões explicitamente encerradas.
- Snapshot congela objetivo, intenção, tempos-alvo, nível, frequência, dias disponíveis, dia preferido do longão, terreno, experiência, base semanal, maior sessão e referência fisiológica usada no início do ciclo.
- Alterações no perfil durante um ciclo são registradas como pendentes para o próximo ciclo; não mudam as referências do ciclo ativo.
- Migração do motor preserva a âncora e a numeração original das semanas; falha fechada quando não consegue recuperar com segurança uma janela ativa.
- Semanas anteriores permanecem como histórico do backup; a semana atual é mantida integralmente; somente sessões de hoje em diante nas semanas futuras do mesmo ciclo são candidatas a atualização.
- Um ciclo não pode ser substituído por outro automaticamente. Novo ciclo exige oito semanas transcorridas e ação explícita de encerramento/início.
- Para backups antigos sem `cycleId`, a âncora é inferida pelos pares data/semana. Evidência ambígua leva a `RECOVERY_REQUIRED`, mantendo o plano importado e solicitando confirmação.

## 2. Distribuição semanal e teto do longão

- `WeeklySessionDistributionEngine` continua conectado ao gerador de sessões (`CoachEngine`) e usa décimos de quilômetro para alocação determinística.
- Mantido o limite máximo de 40% do volume semanal, longão como maior sessão e diferença significativa quando viável.
- Para objetivo contínuo de 5 km, o piso de 5 km vale para a sessão completa nas semanas regulares; as exceções existentes continuam limitadas à iniciação explícita/caminhada-corrida e à semana regenerativa.
- O caso de 17 km é aprovado como 6,8 + 5,1 + 5,1 km: 17,0 km no total, com o longão exatamente em 40%.
- A validação final continua incluindo provas e sessões pendentes. Retestes sem protocolo permanecem compromissos, não são tratados como sessões de 0 km; quando o slot original está disponível, sua distância é reservada até a escolha do protocolo.
- Quando não há distribuição válida, o motor reduz a carga apenas conforme as regras já existentes ou bloqueia com justificativa; não aumenta silenciosamente a meta.

## 3. Calendário compacto

- Grade mensal reduzida de 94 dp para 68 dp por célula.
- Quantidade de dias da grade calculada dinamicamente em blocos de 4, 5 ou 6 semanas.
- Cada item mostra número do dia, ícone vetorial colorido e sigla curta; até dois marcadores por dia e `+N` para os demais.
- Dia com prova e treino pode mostrar ambos; tocar no dia abre a agenda detalhada.
- Ícones vetoriais próprios usam a mesma família visual para regenerativo, rodagem, fartlek, qualidade, longão, prova, teste e iniciação. A bandeira é desenhada no mesmo conjunto, sem emoji de fonte.
- Taxonomia do calendário: INI, REG, ROD, FAR, INT, LNG, PRV e TES. A legenda usa as mesmas categorias, códigos e ícones.
- A mudança é de apresentação; os títulos e detalhes originais persistidos das sessões não são reescritos.

## 4. Backup e versionamento

- `AppBackupCodec.SCHEMA_VERSION = 14`.
- `trainingCycle` é serializado como preferência tipada e validado como documento JSON.
- O decoder aceita schemas 1–14; os schemas 1–13 continuam legíveis e podem ter a identidade do ciclo recuperada a partir das evidências do plano salvo.
- `versionCode = 100`, `versionName = V100`, `CURRENT_ENGINE_VERSION = 90`.

## 5. Arquivos Android modificados

- `android/app/build.gradle.kts`
- `android/app/src/main/java/com/airunningcoach/app/AppBackupManager.kt`
- `android/app/src/main/java/com/airunningcoach/app/MainActivity.kt`
- `android/app/src/main/java/com/airunningcoach/app/PlanMigrationEngine.kt`
- `android/app/src/main/java/com/airunningcoach/app/TrainingCalendarIntegrityEngine.kt`
- `android/app/src/main/java/com/airunningcoach/app/WorkoutCalendarPresentation.kt`
- Testes relacionados a backup, ciclo, integridade do calendário, distribuição semanal e taxonomia do calendário.

## 6. Limitações de validação

A implementação foi validada com dois harnesses Kotlin/JVM focalizados que compilaram os motores de domínio reais (`TrainingCalendarIntegrityEngine`, `WorkoutCalendarPresentation`, `WeeklySessionDistributionEngine` e `PlanMigrationEngine`) com modelos/compatibilidade mínimos de teste. Os dois harnesses passaram.

Não foi possível executar `gradle :app:testDebugUnitTest :app:assembleDebug` nem gerar APK neste ambiente: o ZIP de origem não contém Gradle Wrapper e o ambiente não possui Gradle nem Android SDK. A suíte JUnit/Compose oficial e a compilação Android permanecem para o GitHub Actions.
