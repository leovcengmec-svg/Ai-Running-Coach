> **Status:** aplicado na V88 (versionCode 88, motor 77). Validação de domínio registrada em `TEST_REPORT_V88.md`; build Android permanece pendente do GitHub Actions.

# Auditoria da biblioteca de treinos — V87

## Parecer executivo

A V87 tem uma regressão comprovável no uso das faixas ativas. Os dois exemplos dos prints são reproduzíveis pelo código atual:

1. No Fartlek, os blocos de trabalho Z2 e as recuperações Z2 recebem exatamente a mesma faixa ativa `20–65%`. Como a faixa percentual representa posição dentro da zona (0 = borda lenta; 100 = borda rápida), o recuperativo não fica mais leve que o bloco de trabalho quando ambos usam a mesma zona.
2. Na progressão do longão para corredor experiente, o aquecimento é convertido para Z2 `0–20%`; o primeiro bloco principal também recebe Z2 `0–20%`. Portanto, o bloco de trabalho repete exatamente o ritmo/faixa do aquecimento. A progressão só começa no bloco seguinte.

Não é apenas uma impressão visual: os construtores e os testes da V87 codificam essas faixas iguais. A tela está apresentando fielmente uma prescrição inconsistente.

## Evidências no código V87

### 1. Fartlek: recuperação com a mesma faixa do esforço Z2

- `android/app/src/main/java/com/airunningcoach/app/ZoneIntensityBandEngine.kt`, linhas 18–21:
  - `z2ActiveRecoveryBand = ActiveZoneBand(0, 30)`;
  - `fartlekActiveRecoveryBand = ActiveZoneBand(20, 65)`.
- `CoachEngine.kt`, linha 1138, passa `fartlekActiveRecoveryBand` a `buildIntervalSequence()` para F01/F02/F04.
- `CoachEngine.kt`, linhas 1494–1505, usa a faixa escolhida diretamente na recuperação.
- `ZoneIntensityBandEngine.kt`, linhas 110–130, aplica a mesma faixa `fartlekActiveRecoveryBand` também na normalização/migração das recuperações antigas.
- `CoachEngineTest.kt`, linhas 695 e 724, exige que as recuperações F01/F04 tenham `20–65%`. Os testes, portanto, estavam aprovando a mesma faixa do esforço em Z2.
- `TRAINING_RECOVERY_COMPATIBILITY_V86.md` documenta `20–65%` para recuperações Fartlek, perpetuando a divergência.

### 2. Divergência com a metodologia anterior

A regra atual não está alinhada com os registros anteriores da própria biblioteca:

- `TRAINING_STRUCTURE_AUDIT_V60.md`: recuperação de Fartlek/intervalado em Z2 `0–20%`.
- `PACE_ZONE_METHODOLOGY_V61.md`: recuperação de intervalados em Z2 confortável `0–20%`.
- `PACE_ACTIVE_BANDS_V76.md`: `ACTIVE_Z2` em Z2 `0–20%`.
- O Kotlin atual usa `0–30%` para recuperação Z2 genérica e `20–65%` para Fartlek.

A V87 acabou criando três políticas diferentes para o mesmo conceito de recuperação ativa em Z2, e a política Fartlek coincide exatamente com a faixa padrão de rodagem Z2.

### 3. Longão progressivo: primeiro bloco repete o aquecimento

- `ZoneIntensityBandEngine.kt`, linhas 245–260: para atletas com pelo menos seis meses, o aquecimento e o desaquecimento passam para Z2 `0–20%`.
- `CoachEngine.kt`, linhas 800–804: no longão progressivo elegível para Z3, o primeiro bloco principal também usa `z2EasyTransitionBand` (`0–20%`).
- `CoachEngine.kt`, linhas 810–817: na progressão sem Z3, o primeiro bloco principal igualmente usa `0–20%`; o bloco final só então muda para `20–65%`.
- `createLongRun()` aplica essa construção ao longão progressivo, em `CoachEngine.kt`, linhas 1572–1575.

Isso reproduz a imagem 4: aquecimento e primeiro bloco principal ficam com o mesmo alvo, por exemplo Z2 `0–20%` / `7:57–8:10 min/km`; apenas o bloco seguinte acelera para `20–65%` / `7:30–7:57 min/km`.

### 4. Cobertura insuficiente dos testes

- Os testes de F01/F04 afirmam a faixa `20–65%` para a recuperação, não comparam o pace da recuperação com o esforço imediatamente anterior.
- Os testes de progressão verificam continuidade/contiguidade entre blocos principais, mas não exigem que o primeiro bloco principal seja diferente do aquecimento.
- `TrainingPrescriptionAudit` valida coerência entre zona, pace e distância, mas não valida semântica/ordem das faixas entre aquecimento, esforço, recuperação e progressão.

## Regras corretas propostas

### A. Recuperação ativa Z2

1. Unificar a recuperação ativa Z2 em uma faixa mais lenta e confortável: `0–20%` da Z2 individual, tanto em Fartlek aeróbio como em protocolos intervalados que indiquem trote Z2.
2. A faixa de trabalho aeróbio Z2 permanece `20–65%` quando a sessão prescrever rodagem/variação Z2 padrão.
3. Em blocos que usam Z2 como esforço e também recuperam em Z2, a recuperação tem que ser estritamente mais lenta: não pode reutilizar a mesma banda/paces do esforço anterior.
4. Em Fartlek com esforço Z3, a recuperação segue em Z2 `0–20%`; não deve ser convertida automaticamente em caminhada só por não coincidir com o aquecimento/desaquecimento.
5. Caminhada e pausa passiva continuam possíveis quando forem explicitamente escolhidas pelo protocolo, prontidão/segurança ou incapacidade de manter trote confortável. Não devem ser o fallback automático para uma faixa Z2 válida.
6. Manter o F01 com 2 minutos entre variações e sem recuperação depois do último bloco de trabalho. F02/F04 mantêm sua dose original, a menos que a definição tipada do protocolo determine outro tempo.
7. RPE 2–3 e controle respiratório complementam o pace, mas não substituem um alvo Z2 válido quando houver calibração.

**Resultado esperado no caso do print:** o bloco Fartlek Z2 `20–65%` continua em `7:30–7:57`; a recuperação passa para Z2 `0–20%`, com pace mais lento/confortável (usando a zona individual congelada no snapshot). Assim, esforço e recuperação não terão o mesmo ritmo.

### B. Progressão dentro da Z2 e do longão

1. O aquecimento de corredor experiente permanece Z2 `0–20%`.
2. O primeiro bloco principal de uma progressão Z2 não pode repetir `0–20%`; deve avançar para `20–40%`.
3. O bloco seguinte progride para `40–65%`.
4. Quando Z3 estiver liberada pelos critérios existentes, o desenho pode avançar de Z2 `20–40%` para Z2 `40–65%` (ou faixa intermediária maior conforme duração) e terminar em Z3 de entrada controlada. A elegibilidade Z3 não deve ser relaxada.
5. Em progressões curtas demais para vários segmentos, manter um único bloco Z2 `20–65%`, sem criar etapas artificiais.
6. Em sessões regressivas, aplicar a ordem inversa de forma contínua: iniciar na faixa mais rápida permitida e reduzir gradualmente para a faixa confortável; não repetir a mesma faixa em etapas sucessivas sem justificativa.
7. A faixa do desaquecimento permanece uma etapa terminal confortável. Se o bloco final já estiver exatamente na mesma faixa, a interface/racional deve deixar claro que é uma continuidade de redução, ou a faixa do desaquecimento deverá ser mais leve quando a calibração permitir. Não transformar isso em aceleração.

**Resultado esperado no caso do print:**
- Aquecimento: Z2 `0–20%`.
- Bloco inicial do longão: Z2 `20–40%`.
- Bloco final progressivo: Z2 `40–65%`.

O pace numérico é calculado a partir da zona individual e dos percentuais; não deve ser fixado em minutos/km universais.

## Plano de implementação — próxima versão

### P0 — Corrigir fonte única das faixas

1. Em `ZoneIntensityBandEngine.kt`, alinhar `z2ActiveRecoveryBand` e `fartlekActiveRecoveryBand` à política comum Z2 `0–20%`, evitando constantes contraditórias.
2. Atualizar `normalizeFartlekRecoveries()` para gerar pace/instrução/percentuais usando a política única `0–20%`.
3. Atualizar `buildIntervalSequence()` e o texto da instrução para não mencionar `20–65%` como recuperação; garantir que protocolos Fartlek e intervalados recebam a faixa correta.
4. Preservar modalidades `PASSIVE` e `WALK` sem pace/zona. Não converter `ACTIVE_Z2` válido em caminhada por comparação exata com o desaquecimento.

### P0 — Corrigir progressão da biblioteca

1. Em `buildProgressionRegressionSegments()` (`CoachEngine.kt`), substituir a primeira etapa progressiva Z2 `0–20%` por `20–40%` quando houver aquecimento separado em Z2 `0–20%`.
2. Dividir a progressão restante em bandas ordenadas e distintas (por padrão `20–40%` → `40–65%` para Z2-only).
3. No ramo Z2→Z2→Z3, revisar os intervalos atualmente `0–20%` → `20–100%` → Z3 `0–40%`; criar estágios contíguos e graduais sem salto excessivo nem repetição do aquecimento.
4. Aplicar a mesma lógica à rodagem progressiva e ao longão progressivo, pois ambos usam `buildProgressionRegressionSegments()`.
5. Preservar a progressão regressiva, mas criar testes para garantir ordem descendente e faixas distintas.

### P0 — Corrigir testes que atualmente validam a regressão

Atualizar:
- `CoachEngineTest.kt` F01/F04: substituir expectativas `20–65%` para recuperação por `0–20%`.
- Acrescentar comparação dos limites de pace: recuperação Z2 deve ser mais lenta (valores mm:ss maiores) que o bloco de trabalho Z2 imediatamente anterior; se esforço anterior for Z3, ainda deve permanecer Z2.
- Longão progressivo Z2-only: exigir aquecimento `0–20%`, bloco inicial `20–40%`, bloco final `40–65%`.
- Progressão Z2–Z3: exigir faixas principais graduais e diferentes do aquecimento, além da elegibilidade Z3 existente.
- Regressão: validar ordem inversa das faixas, sem duplicação acidental.
- Biblioteca completa: gerar amostras de F01/F02/F04, intervalados Z2/Z3/Z4/Z5, rodagem progressiva/regressiva e longões com/sem Z3; auditar o par esforço-recuperação e o primeiro bloco após aquecimento.

### P1 — Migração de planos existentes

1. Incrementar `CURRENT_ENGINE_VERSION` para invalidar a prescrição antiga e solicitar recálculo dos planos ativos.
2. Migrar apenas sessões futuras/pendentes com recuperação Fartlek `ACTIVE_Z2` em `20–65%` para `0–20%`, preservando a duração e recalculando a distância estimada a partir da nova faixa.
3. Migrar apenas progressões futuras reconhecíveis cujo primeiro bloco principal repita a faixa do aquecimento, atualizando as bandas para a nova sequência.
4. Não alterar sessões concluídas, feedbacks, dados importados ou histórico.
5. Tornar a migração idempotente; não migrar caminhadas intencionais nem pausas passivas.
6. Se não houver snapshot de calibração confiável, manter o bloco sem pace numérico até nova calibração, sem inventar faixa em min/km.

### P1 — Auditoria semântica da prescrição

Expandir `TrainingPrescriptionAudit` para verificar:
- recuperação ativa na mesma zona do esforço: banda e pace devem ser mais fáceis;
- recuperação entre zonas: zona de recuperação deve ser fisiologicamente inferior à zona de trabalho;
- Fartlek Z2/Z3: recuperação Z2 0–20%, esforço Z2 usual 20–65% ou Z3 conforme protocolo;
- progressão: bandas/ritmos devem avançar progressivamente, sem duplicar aquecimento no primeiro bloco principal;
- regressão: bandas/ritmos devem reduzir progressivamente;
- o ritmo calculado corresponde exatamente aos percentuais e ao snapshot individual;
- a soma das distâncias e repetições permanece igual ao total da sessão.

## Matriz de testes de aceitação

| ID | Cenário | Resultado obrigatório |
|---|---|---|
| F01-01 | Fartlek F01 com esforço Z2 20–65% | Recuperação Z2 0–20%, 2 min |
| F01-02 | Fartlek F01 com esforço Z3 0–20% | Recuperação Z2 0–20%, 2 min; pace mais lento que Z3 |
| F01-03 | Três recuperações previstas | Exatamente uma recuperação entre cada par de esforços; nenhuma após o último |
| F02-01 | F02 com bloco forte elegível | Recuperação Z2 0–20%, preservando dose do protocolo |
| F04-01 | F04 com Z4 elegível | Recuperações Z2 0–20%; Z4 somente quando os gates atuais liberarem |
| INT-01 | Intervalado com trabalho Z2 | Recuperação Z2 mais lenta que o trabalho; sem banda idêntica |
| INT-02 | Intervalado Z3/Z4/Z5 | Modalidade Z2, Z1, caminhada ou pausa passiva conforme protocolo; sem alterar dose arbitrariamente |
| LR-01 | Longão progressivo Z2-only, corredor experiente | Aquecimento 0–20; bloco 1 20–40; bloco 2 40–65 |
| LR-02 | Longão progressivo Z2–Z3 elegível | Progressão distinta do aquecimento; Z3 preserva elegibilidade e trecho curto |
| LR-03 | Longão regressivo | Bandas em ordem inversa, contínuas e sem repetição acidental |
| EASY-01 | Rodagem progressiva | Mesma regra de diferenciação entre aquecimento e parte principal |
| REC-01 | Semana regenerativa | Não acelerar para cumprir progressão; manter a política de recuperação e o volume reduzido |
| MIG-01 | Plano salvo com Fartlek antigo 20–65 | Somente pendentes migram para 0–20 |
| MIG-02 | Plano com sessões concluídas/feedbacks | Conteúdo concluído e histórico permanecem byte a byte/semanticamente inalterados |
| MIG-03 | Recalcular/migrar duas vezes | Segunda execução não modifica novamente os dados |
| AUD-01 | Auditoria global da biblioteca | Nenhum par trabalho-recuperação com a mesma faixa quando ambos representam intensidades diferentes |

## Versionamento sugerido

- Próxima versão do aplicativo: V88 (`versionCode = 88`, `versionName = V88`).
- Próximo motor de prescrição: 77 (incremento a partir do `CURRENT_ENGINE_VERSION = 76` informado no status V87).
- Backup Schema: manter 4, pois a alteração é de regras/metadados de segmentos e não requer novo formato de backup, desde que os campos existentes sejam suficientes.
- Atualizar `CHANGELOG.md`, `PROJECT_STATUS.md`, `BUILD_STATUS_V88.md`, `TRAINING_RECOVERY_COMPATIBILITY_V88.md` e documentação das faixas ativas.

## Critérios para aprovar a atualização

1. F01/F02/F04 não exibem recuperação com o mesmo pace/faixa do esforço anterior quando a recuperação é do tipo ACTIVE_Z2.
2. A recuperação Fartlek usa Z2 0–20%, e o F01 preserva 2 minutos.
3. Aquecimento e primeiro bloco de trabalho da progressão não são iguais quando há faixa suficiente para diferenciá-los.
4. Longões progressivos e rodagens progressivas usam faixas ordenadas na mesma lógica.
5. Os testes não apenas conferem valores percentuais: também comparam paces resolvidos, direção da progressão, dose e segurança.
6. Migração preserva treinos concluídos e feedbacks.
7. `:app:testDebugUnitTest` e `:app:assembleDebug` passam no GitHub Actions; depois, validar os exemplos no aparelho e no Pace Coach.

## Limitações da auditoria

A análise foi feita sobre o código e a documentação contidos no pacote V87 disponível nesta sessão e sobre os quatro prints fornecidos. Não foi executada uma nova compilação Android nem teste de dispositivo nesta auditoria. O plano descreve as correções a aplicar; nenhum código foi alterado nesta etapa.
