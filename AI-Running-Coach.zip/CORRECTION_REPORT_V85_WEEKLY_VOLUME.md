# Relatório de Correção V85 — volume semanal com provas

## Defeito
O card somava `trainingKm + raceKm` para mostrar o total e para desenhar a barra, mas usava somente `trainingKm` para comparar com a meta. Assim, provas apareciam no total mas eram ignoradas no déficit/superávit e na cor do indicador.

## Correção
Criado `WeeklyVolumeSummary` como fonte única de cálculo. O card passa a usar a consolidação para o estado do indicador e para a mensagem expandida. A lista de provas continua excluindo eventos cancelados, como antes.

## Exemplo reproduzido
- Treinos: 5,8 + 5,1 = 10,9 km
- Prova: 5,0 km
- Total previsto: 15,9 km
- Meta: 17,0 km
- Déficit correto: 1,1 km

## Regras preservadas
- Prova B continua substituindo sessão conforme a regra atual.
- Nenhum quilômetro adicional é forçado pelo cálculo visual.
- Prioridades A/B/C, taper, motor de prescrição e backup schema não foram alterados.
- `CURRENT_ENGINE_VERSION` permanece 74 porque não houve mudança na lógica de geração do plano.

## Validação
- 5/5 cenários focalizados passaram no harness Kotlin/JVM com o helper de produção.
- Build Android/Compose e suíte Gradle completa precisam ser confirmados no GitHub Actions.
