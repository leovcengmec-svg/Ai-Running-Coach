# Test Report — AI Running Coach V95

## Identificação
- VersionCode 95 / VersionName V95.
- CURRENT_ENGINE_VERSION 85.
- Backup Schema 10 (compatibilidade de leitura 1–9).
- Base: V94.

## Harness Kotlin/JVM focado — PASS
Matriz executada sobre motores de domínio, isolando os componentes Compose/Android e utilizando um modelo de apoio para `Workout`, que está declarado no `MainActivity.kt`.

Resultado: **188 sessões geradas e auditadas** em sete perfis/objetivos.

Cobertura de cenários:
- iniciante caminhada/corrida;
- corredor experiente regular;
- corredor experiente com objetivo de recorde;
- intermediário com objetivo contínuo;
- avançado com tempo-alvo;
- avançado com recorde e cinco dias disponíveis;
- intermediário com recorde sem teste recente.

As 188 sessões passaram por:
- `TrainingPrescriptionAudit.validate()`;
- `TrainingPrescriptionAudit.validateExportStructure()`;
- reconciliação entre soma dos segmentos e distância da sessão, tolerância de 0,11 km.

Verificações adicionais no harness:
- 10 longões progressivos e 10 regressivos com três etapas principais quando o volume permite;
- 2 sessões reais de strides com oito blocos, três acelerações e duas recuperações individuais;
- protocolo I05 / 6 × 400 m com 14 blocos (aquecimento, preparação, 6 trabalhos, 5 recuperações e desaquecimento);
- alternativa equivalente de strides preserva oito blocos e tempos em segundos;
- alternativa mais leve remove acelerações e gera três blocos aeróbios executáveis.

Saída do harness: `V95 matrix PASS: 188 sessions; 10 progressive long runs; 10 regressive long runs; 2 stride sessions; I05=14 blocks; stride alternatives validated`.

## Código de testes incluído
- `TrainingPrescriptionAuditTest.kt`
- `TrainingProtocolCatalogTest.kt`
- `PaceCoachExporterTest.kt`
- `WorkoutAlternativeEngineTest.kt`
- `RetestCycleEngineTest.kt` (inclui round-trip de `durationSeconds` no snapshot de reteste)

## Limitação de validação
A suíte JUnit/Gradle completa e a compilação Android/Compose não foram executadas neste ambiente porque Gradle e Android SDK não estão instalados. Os testes Android/JUnit estão incluídos no ZIP e devem ser executados pelo GitHub Actions.

O harness Kotlin/JVM cobre os motores de domínio; não substitui a compilação Android completa nem a verificação de integração no dispositivo/Pace Coach real.
