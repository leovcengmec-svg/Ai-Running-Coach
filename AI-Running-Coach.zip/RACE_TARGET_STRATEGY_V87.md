# Estratégia de prova orientada por tempo-alvo — V87

## Objetivo

Separar duas dimensões que antes eram acopladas de forma inadequada:

1. **Prioridade da prova (A/B/C):** controla o impacto sobre o macrociclo e sobre a substituição de sessões.
2. **Tempo-alvo:** controla a estratégia de execução da própria prova, quando existe evidência suficiente para orientar a prescrição.

## Regras de prioridade preservadas

- **A — Principal:** pode definir a janela do ciclo, taper e recuperação pós-prova.
- **B — Preparatória:** substitui uma sessão na semana da prova e permite ensaiar ritmo/estratégia; não ativa taper automático.
- **C — Treino:** substitui uma sessão, mantém o macrociclo e não ativa taper. Um tempo-alvo preenchido ainda pode orientar a execução como referência opcional.

B/C não passam a comandar o macrociclo. Somente A define a prova-alvo principal.

## Cálculo do tempo-alvo

Para tempo total em segundos `T` e distância `D` em quilômetros:

`pace médio necessário = T / D`

Exemplo: 5 km em 37:00 = 2.220 s / 5 = 444 s/km = **7:24 min/km**.

A estratégia divide a distância em três partes (início, meio e final). Os ritmos das fases são ponderados pelas distâncias, não por média simples. Quando o alvo é considerado utilizável, os splits mantêm a projeção matemática próxima do tempo solicitado. A prioridade A pode adotar pequena largada controlada e compensação no final se o histórico de longões e o objetivo do corredor permitirem; B/C usam estratégia mais estável.

## Compatibilidade e segurança

- **COMPATIBLE:** alvo compatível com as zonas/evidências disponíveis. É uma estimativa, não uma garantia.
- **CONSERVATIVE:** alvo mais lento que o ritmo recente; é mantido sem acelerar artificialmente para alcançar uma zona mais rápida.
- **ASPIRATIONAL:** alvo muito mais rápido que os limites/evidências atuais. O alvo matemático é exibido, mas os trechos continuam baseados no desempenho demonstrado.
- **UNVERIFIED:** há alvo matemático, mas faltam dados suficientes para afirmar que ele é sustentável. O app mostra o pace necessário sem inventar validação fisiológica.
- **NONE:** nenhum tempo-alvo informado.

Uma fase pode receber o rótulo `ALVO` quando o pace-alvo não coincide com uma faixa Z1–Z5. O pace continua sendo explícito e exportável; `ALVO` não equivale a uma zona fisiológica.

## Integrações

- Tela de cadastro/edição apresenta a função de cada prioridade.
- Alterar prioridade, data, distância ou tempo-alvo marca o plano como desatualizado.
- A tela de competições e a tela de estratégia oferecem ação explícita para recalcular as sessões futuras.
- O guia do dia da prova utiliza o tempo-alvo da própria prova, independentemente da intenção global do perfil.
- A exportação Pace Coach preserva os alvos por trecho e as distâncias de cada fase.
- O recálculo usa o fluxo normal de preservação das sessões concluídas, feedbacks e histórico.

## Arquivos centrais

- `RaceStrategyEngine.kt`
- `RacePlanningEngine.kt`
- `RaceDayGuideEngine.kt`
- `RaceStrategyWorkoutExporter.kt`
- `MainActivity.kt`
- Testes: `RaceStrategyEngineTest.kt`, `RaceEventEngineTest.kt`, `RaceDayGuideEngineTest.kt` e `RaceStrategyWorkoutExporterTest.kt`.

## Testes de regressão adicionados

1. 5 km / 37:00 / prioridade C: 7:24 min/km, splits ponderados e projeção em torno de 37:00.
2. Prioridades A/B/C mantêm o tempo-alvo e mudam a orientação de execução.
3. Meta conservadora continua disponível e não impõe aceleração.
4. Meta agressiva permanece aspiracional e não é imposta aos ritmos.
5. Sem zonas/evidências: pace matemático visível, sem fases fisiológicas inventadas.
6. Guia B/C usa o tempo-alvo mesmo com intenção global `COMPLETE`.
7. Exportação B/C para Pace Coach preserva pace nos três trechos.
8. Alterar C para A faz a prova passar a comandar a janela do macrociclo após o recálculo.

## Limites conhecidos

Os valores são referências de execução derivadas dos dados disponíveis. Clima, altimetria, percurso, sono, sensação e resposta do corredor podem exigir ajuste. O app não deve apresentar projeção matemática como garantia de tempo final.
