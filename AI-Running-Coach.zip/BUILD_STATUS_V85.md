# Build Status — AI Running Coach V85

## Identificação
- Base: V84.
- `versionCode = 85`
- `versionName = V85`
- `CURRENT_ENGINE_VERSION = 74` (inalterado; a correção não modifica prescrição nem motor de geração).
- Backup Schema 4; leitura de schemas 1–4 preservada.

## Correção V85 — volume semanal e competições
- `TrainingWeekCard` já exibia o total `trainingKm + raceKm`, porém comparava `weeklyTargetKm` apenas com `trainingKm`.
- A comparação incorreta foi substituída por `WeeklyVolumeSummary`, que consolida sessões + provas não canceladas.
- O indicador de meta, a mensagem de déficit/superávit e o total do card usam a mesma base de cálculo.
- No caso reproduzido: treinos 5,8 + 5,1 = 10,9 km; prova 5 km; volume total 15,9 km; meta 17 km; déficit correto 1,1 km (não 6,1 km).
- A prova B continua substituindo a sessão conforme a regra existente. Nenhum volume é acrescentado artificialmente e nenhuma regra de taper/prioridade A/B/C foi alterada.
- Correção de apresentação/consolidação apenas; não invalida planos nem altera backups.

## Testes
- Adicionado `WeeklyVolumeSummaryTest.kt` com cinco casos: déficit incluindo prova, déficit sem prova, meta atingida, volume acima da meta e meta ausente.
- Harness Kotlin/JVM compilou o helper real e executou cinco cenários focados: 5/5 aprovados.
- `:app:testDebugUnitTest` e `:app:assembleDebug` não foram executados neste ambiente; confirmar ambos no GitHub Actions antes de declarar APK aprovado.
