package com.airunningcoach.app

import java.time.LocalDate
import java.time.DayOfWeek
import java.time.temporal.ChronoUnit
import java.time.temporal.TemporalAdjusters

/** Pure migration helpers so restored legacy plans can be regenerated without losing history. */
internal object PlanMigrationEngine {
    fun requiresMigration(storedEngineVersion: Int, currentEngineVersion: Int, hasSavedPlan: Boolean): Boolean =
        hasSavedPlan && storedEngineVersion < currentEngineVersion

    /** A repaired empty first week starts a genuinely new anchor; do not infer the old cycle from archived dates. */
    fun shouldPreserveRestoredCycle(shouldPreserveCycleAnchor: Boolean, emptyFirstWeekRebased: Boolean): Boolean =
        shouldPreserveCycleAnchor && !emptyFirstWeekRebased

    data class EmptyFirstWeekMigration(
        val migrated: Boolean,
        val startDate: LocalDate?,
        val workouts: List<Workout>
    )

    /**
     * Repairs a just-created cycle whose first calendar week had no remaining available
     * training day. It never shifts a week containing a scheduled/realized session,
     * feedback date, optional/manual session, or any completed activity.
     */
    fun rebaseEmptyFirstWeek(
        savedStartDateIso: String,
        today: LocalDate,
        availableDays: List<DayOfWeek>,
        workouts: List<Workout>
    ): EmptyFirstWeekMigration {
        val savedAnchor = runCatching { LocalDate.parse(savedStartDateIso) }.getOrNull()
            ?.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            ?: return EmptyFirstWeekMigration(false, null, workouts)
        if (savedAnchor != today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))) {
            return EmptyFirstWeekMigration(false, savedAnchor, workouts)
        }
        val effectiveStart = TrainingScheduleEngine.firstTrainableWeekStart(today, availableDays)
        if (!effectiveStart.isAfter(savedAnchor)) return EmptyFirstWeekMigration(false, savedAnchor, workouts)
        val firstWeekEnd = savedAnchor.plusDays(6)
        fun inFirstWeek(raw: String): Boolean {
            val date = runCatching { LocalDate.parse(raw) }.getOrNull() ?: return false
            return date in savedAnchor..firstWeekEnd
        }
        // A historical workout from a previous macrocycle may share this calendar
        // week. It only blocks migration when its stored week number agrees with this
        // cycle's anchor; otherwise it remains historical evidence, not use of week 1.
        val hasWeekEvidence = workouts.any { workout ->
            if (workout.isOptionalExtra) return@any false
            val identityDate = workout.originalScheduledDateIso.takeIf { it.isNotBlank() }
                ?: workout.scheduledDateIso
            if (!inFirstWeek(identityDate)) return@any false
            val date = runCatching { LocalDate.parse(identityDate) }.getOrNull() ?: return@any false
            workout.week == TrainingScheduleEngine.weekNumberForDate(savedAnchor, date)
        }
        // Feedback tied to a real session is represented by that session in workouts
        // and therefore blocks this migration through hasWeekEvidence. An orphaned
        // activity from another cycle must not consume this cycle's first week merely
        // because its realized date falls in the same civil week.
        if (hasWeekEvidence) return EmptyFirstWeekMigration(false, savedAnchor, workouts)
        val hasUpcomingCoreSession = workouts.any { workout ->
            !workout.isOptionalExtra && runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull()
                ?.isAfter(firstWeekEnd) == true
        }
        if (!hasUpcomingCoreSession) return EmptyFirstWeekMigration(false, savedAnchor, workouts)

        val rebased = workouts.map { workout ->
            val date = runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull()
                ?: return@map workout
            if (date.isBefore(effectiveStart)) workout
            else workout.copy(week = TrainingScheduleEngine.weekNumberForDate(effectiveStart, date))
        }
        return EmptyFirstWeekMigration(true, effectiveStart, rebased)
    }

    /** Exact, date-aware key used when historical feedback is related to a plan instance. */
    fun sessionInstanceKey(sessionId: String, scheduledDateIso: String, type: String = ""): String {
        val base = "${sessionId.trim()}|${scheduledDateIso.trim()}"
        val normalizedType = type.trim().uppercase(java.util.Locale.ROOT).replace(Regex("\\s+"), " ")
        // Keep the two-part form readable for legacy, type-less feedback records.
        return if (normalizedType.isBlank()) base else "$base|$normalizedType"
    }

    fun feedbackMatchesInstance(
        sessionId: String,
        date: String,
        workoutType: String,
        feedbackInstanceKeys: Set<String>,
        allowUntypedFallback: Boolean = true
    ): Boolean {
        val typed = sessionInstanceKey(sessionId, date, workoutType)
        val legacyUntyped = sessionInstanceKey(sessionId, date)
        return typed in feedbackInstanceKeys ||
            (allowUntypedFallback && legacyUntyped in feedbackInstanceKeys)
    }

    fun sessionSlotKey(scheduledDateIso: String, type: String): String =
        SessionIdentityEngine.slotKey(scheduledDateIso, type)



    /**
     * Infers the original cycle Monday from the date/week pairs stored in each session.
     * This repairs backups where planStartDateIso was already rebased to the import week,
     * while older sessions still carry their original cycle week numbers.
     */
    fun inferRestoredCycleAnchor(savedStartDateIso: String, workouts: List<Workout>): LocalDate? {
        val savedAnchor = runCatching { LocalDate.parse(savedStartDateIso) }.getOrNull()
            ?.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val eligible = workouts.filter { !it.isOptionalExtra && !it.manuallyRescheduled }
        val datedSessions = eligible.mapNotNull { workout ->
            runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull()
                ?.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        }
        val evidence = eligible.asSequence()
            .filter { it.week in 1..52 }
            .mapNotNull { workout ->
                val date = runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull() ?: return@mapNotNull null
                val monday = date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
                monday.minusWeeks((workout.week - 1).toLong())
            }
            .groupingBy { it }
            .eachCount()
        val strongest = evidence.entries.sortedWith(
            compareByDescending<Map.Entry<LocalDate, Int>> { it.value }
                .thenBy { if (it.key == savedAnchor) 0 else 1 }
                .thenBy { it.key }
        ).firstOrNull()
        if (savedAnchor != null) {
            val candidate = strongest?.key
            val candidateCount = strongest?.value ?: 0
            val savedCount = evidence[savedAnchor] ?: 0
            val candidateIsPlausible = candidate != null && candidate.isBefore(savedAnchor) &&
                ChronoUnit.WEEKS.between(candidate, savedAnchor) in 1L..52L
            if (candidateIsPlausible && candidateCount >= 2 && candidateCount > savedCount) return candidate
            // Fallback for older records whose week field is missing/shifted: two or
            // more core sessions in the immediately preceding Monday-to-Sunday block,
            // outnumbering sessions in the saved anchor week, are strong evidence that
            // the stored start date was rebased one week too late.
            val previousMonday = savedAnchor.minusWeeks(1)
            val previousDateCount = datedSessions.count { it == previousMonday }
            val savedDateCount = datedSessions.count { it == savedAnchor }
            if (previousDateCount >= 2 && previousDateCount > savedDateCount) return previousMonday
            return savedAnchor
        }
        if (strongest != null && strongest.value >= 2) return strongest.key
        return datedSessions.minOrNull()
    }

    /**
     * Restores an in-progress cycle from its saved Monday anchor instead of silently
     * restarting it at the import date. This is valid only while the saved cycle is active.
     */
    fun restoredPlanWindow(
        savedStartDateIso: String,
        savedWeeks: Int,
        events: List<RaceEvent>,
        today: LocalDate
    ): PlanWindow? {
        val savedStart = runCatching { LocalDate.parse(savedStartDateIso) }.getOrNull() ?: return null
        val anchor = savedStart.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val weeks = savedWeeks.coerceIn(4, 52)
        if (anchor.isAfter(today.plusDays(7)) || !today.isBefore(anchor.plusWeeks(weeks.toLong()))) return null
        val endExclusive = anchor.plusWeeks(weeks.toLong())
        // A restored cycle is anchored only by a primary A race. Preparatory B and
        // training C events are calendar entries and must never hijack the macrocycle.
        val primary = events.asSequence()
            .filter { it.status == "PLANNED" && it.priority == "A" }
            .mapNotNull { event -> event.dateOrNull()?.let { event to it } }
            .filter { (_, date) -> !date.isBefore(anchor) && !date.isBefore(today) && date.isBefore(endExclusive) }
            .minByOrNull { it.second }
        val raceWeek = primary?.second?.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            ?.let { (ChronoUnit.DAYS.between(anchor, it) / 7L).toInt() + 1 }
        return PlanWindow(
            startDate = anchor,
            weeks = weeks,
            primaryRaceId = primary?.first?.id,
            raceWeek = raceWeek,
            raceInsideWindow = primary != null,
            note = "Ciclo original restaurado a partir de ${anchor}. A numeração das semanas foi preservada; provas B/C apenas substituem uma sessão e não ativam taper."
        )
    }


    /**
     * A backup is authoritative for the past. Regenerate only sessions scheduled on
     * or after today; past sessions remain visible only when they actually exist in
     * the restored backup. When an original cycle window is supplied, keep candidates
     * inside that window as well.
     */
    fun currentAndFutureCycleSessions(
        sessions: List<PrescribedWorkout>,
        today: LocalDate,
        cycleStart: LocalDate? = null,
        cycleWeeks: Int? = null
    ): List<PrescribedWorkout> {
        val anchor = cycleStart?.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val endExclusive = if (anchor != null && cycleWeeks != null) anchor.plusWeeks(cycleWeeks.coerceIn(4, 52).toLong()) else null
        return sessions.filter { session ->
            val date = runCatching { LocalDate.parse(session.scheduledDateIso) }.getOrNull() ?: return@filter false
            !date.isBefore(today) && (anchor == null || (!date.isBefore(anchor) && (endExclusive == null || date.isBefore(endExclusive))))
        }
    }


    /** Excludes only the same completed session identity, never every session on its date. */
    fun excludeCompletedSessionIdentities(
        regenerated: List<PrescribedWorkout>,
        completed: List<Workout>
    ): List<PrescribedWorkout> {
        return regenerated.filterNot { prescribed ->
            val plannedDate = prescribed.scheduledDateIso
            completed.any { saved ->
                val sameDate = plannedDate in SessionIdentityEngine.workoutDates(
                    saved.scheduledDateIso, saved.originalScheduledDateIso
                )
                val sameType = SessionIdentityEngine.slotKey(plannedDate, saved.type) ==
                    SessionIdentityEngine.slotKey(plannedDate, prescribed.type)
                val exactIdentity = saved.sessionId == prescribed.sessionId && sameDate && sameType
                // Legacy relative IDs change when a plan is regenerated with cycle-scoped
                // identities. Original date + type safely identifies the same calendar slot.
                val sameLegacyInstance = !saved.isOptionalExtra && sameDate && sameType
                exactIdentity || sameLegacyInstance
            }
        }
    }

    /**
     * Reapplies the athlete's pending manual dates to regenerated sessions by stable
     * session identity. It deliberately runs before race replacement and before any
     * filtering against completed calendar dates.
     */
    fun reapplyManualRescheduleDates(
        sessions: List<PrescribedWorkout>,
        previousManual: Map<String, Workout>,
        today: LocalDate
    ): List<PrescribedWorkout> = sessions.map { prescribed ->
        val slotKey = sessionSlotKey(prescribed.scheduledDateIso, prescribed.type)
        // The calendar slot is stronger than a legacy relative ID: an old ID can
        // repeat in another cycle, while the original date + type identifies this instance.
        val saved = previousManual[slotKey] ?: previousManual[prescribed.sessionId]
            ?: previousManual[SessionIdentityEngine.dateSlotKey(prescribed.scheduledDateIso)]
            ?: return@map prescribed
        val movedDate = runCatching { LocalDate.parse(saved.scheduledDateIso) }.getOrNull() ?: return@map prescribed
        val generatedDate = runCatching { LocalDate.parse(prescribed.scheduledDateIso) }.getOrNull() ?: return@map prescribed
        val sameWeek = movedDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)) ==
            generatedDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        if (movedDate.isBefore(today) || !sameWeek) return@map prescribed
        val label = "${movedDate.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, java.util.Locale.forLanguageTag("pt-BR")).replaceFirstChar { it.uppercase(java.util.Locale.forLanguageTag("pt-BR")) }}, ${movedDate.format(java.time.format.DateTimeFormatter.ofPattern("dd/MM"))}"
        prescribed.copy(
            date = label,
            scheduledDateIso = movedDate.toString(),
            day = movedDate.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, java.util.Locale.forLanguageTag("pt-BR")),
            originalScheduledDateIso = saved.originalScheduledDateIso.ifBlank { saved.scheduledDateIso }
        )
    }

    /** Rebuilds week numbers from the saved cycle anchor, not from the import date. */
    fun normalizeCycleWeekNumbers(workouts: List<Workout>, planStartDate: LocalDate): List<Workout> {
        val anchor = planStartDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        return workouts.map { workout ->
            val date = runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull() ?: return@map workout
            val monday = date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            if (monday.isBefore(anchor)) workout
            else workout.copy(week = (ChronoUnit.DAYS.between(anchor, monday) / 7L).toInt() + 1)
        }
    }

    fun preserveCompleted(workouts: List<Workout>, feedbackSessionIds: Set<String>): List<Workout> =
        workouts.filter { it.done || it.sessionId in feedbackSessionIds }
            .map { workout -> if (workout.sessionId in feedbackSessionIds) workout.copy(done = true) else workout }

    fun preserveCompletedInstances(workouts: List<Workout>, feedbackInstanceKeys: Set<String>): List<Workout> =
        workouts.filter { workout ->
            val identityDate = SessionIdentityEngine.identityDate(workout.scheduledDateIso, workout.originalScheduledDateIso)
            val uniqueLegacySlot = workouts.count { candidate ->
                candidate.sessionId == workout.sessionId &&
                    SessionIdentityEngine.identityDate(candidate.scheduledDateIso, candidate.originalScheduledDateIso) == identityDate
            } == 1
            workout.done || feedbackMatchesInstance(
                workout.sessionId, identityDate, workout.type, feedbackInstanceKeys, uniqueLegacySlot
            )
        }.map { workout ->
            val identityDate = SessionIdentityEngine.identityDate(workout.scheduledDateIso, workout.originalScheduledDateIso)
            val uniqueLegacySlot = workouts.count { candidate ->
                candidate.sessionId == workout.sessionId &&
                    SessionIdentityEngine.identityDate(candidate.scheduledDateIso, candidate.originalScheduledDateIso) == identityDate
            } == 1
            if (feedbackMatchesInstance(workout.sessionId, identityDate, workout.type, feedbackInstanceKeys, uniqueLegacySlot)) {
                workout.copy(done = true)
            } else workout
        }

    /** Keep every past calendar entry during a plan upgrade, even when a legacy backup
     * did not persist its done flag/feedback consistently. Past entries remain pending
     * or completed exactly as recorded; they are never silently discarded. */
    fun preserveHistoryAndCompleted(
        workouts: List<Workout>,
        feedbackSessionIds: Set<String>,
        today: LocalDate
    ): List<Workout> = workouts.filter { workout ->
        val date = runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull()
        workout.done || workout.sessionId in feedbackSessionIds || date == null || date.isBefore(today)
    }.map { workout ->
        if (workout.sessionId in feedbackSessionIds) workout.copy(done = true) else workout
    }

    fun preserveHistoryAndCompletedInstances(
        workouts: List<Workout>,
        feedbackInstanceKeys: Set<String>,
        today: LocalDate
    ): List<Workout> = workouts.filter { workout ->
        val identityDate = SessionIdentityEngine.identityDate(workout.scheduledDateIso, workout.originalScheduledDateIso)
        val date = runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull()
        val uniqueLegacySlot = workouts.count { candidate ->
            candidate.sessionId == workout.sessionId &&
                SessionIdentityEngine.identityDate(candidate.scheduledDateIso, candidate.originalScheduledDateIso) == identityDate
        } == 1
        workout.done || feedbackMatchesInstance(
            workout.sessionId, identityDate, workout.type, feedbackInstanceKeys, uniqueLegacySlot
        ) || date == null || date.isBefore(today)
    }.map { workout ->
        val identityDate = SessionIdentityEngine.identityDate(workout.scheduledDateIso, workout.originalScheduledDateIso)
        val uniqueLegacySlot = workouts.count { candidate ->
            candidate.sessionId == workout.sessionId &&
                SessionIdentityEngine.identityDate(candidate.scheduledDateIso, candidate.originalScheduledDateIso) == identityDate
        } == 1
        if (feedbackMatchesInstance(workout.sessionId, identityDate, workout.type, feedbackInstanceKeys, uniqueLegacySlot)) {
            workout.copy(done = true)
        } else workout
    }

    fun pendingOptionalExtras(
        workouts: List<Workout>,
        today: LocalDate,
        feedbackSessionIds: Set<String>
    ): List<Workout> = workouts.filter { workout ->
        workout.isOptionalExtra && !workout.done && workout.sessionId !in feedbackSessionIds &&
            (runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull()?.isBefore(today) == false)
    }

    fun pendingOptionalExtraInstances(
        workouts: List<Workout>,
        today: LocalDate,
        feedbackInstanceKeys: Set<String>
    ): List<Workout> = workouts.filter { workout ->
        workout.isOptionalExtra && !workout.done &&
            !feedbackMatchesInstance(
                workout.sessionId,
                workout.originalScheduledDateIso.ifBlank { workout.scheduledDateIso },
                workout.type,
                feedbackInstanceKeys,
                workouts.count { candidate ->
                    candidate.sessionId == workout.sessionId &&
                        SessionIdentityEngine.identityDate(candidate.scheduledDateIso, candidate.originalScheduledDateIso) ==
                        workout.originalScheduledDateIso.ifBlank { workout.scheduledDateIso }
                } == 1
            ) &&
            (runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull()?.isBefore(today) == false)
    }

    fun merge(
        completed: List<Workout>,
        pendingExtras: List<Workout>,
        regeneratedFutureSessions: List<Workout>
    ): List<Workout> = (completed + pendingExtras + regeneratedFutureSessions)
        // Relative legacy IDs may repeat in separate cycles. Deduplicate only the same
        // scheduled instance; never discard historical sessions by ID alone.
        .distinctBy { workout ->
            val date = SessionIdentityEngine.identityDate(workout.scheduledDateIso, workout.originalScheduledDateIso)
            "${sessionInstanceKey(workout.sessionId, date, workout.type)}|${SessionIdentityEngine.slotKey(date, workout.type)}"
        }
        .sortedBy { it.scheduledDateIso }
}
