# Relatório de correções — AI Running Coach V81

**Pacote:** `AI-Running-Coach.zip`  
**Identidade preservada:** `versionCode = 81`, `versionName = V81`  
**Motor:** `CURRENT_ENGINE_VERSION = 72`  
**Backup:** Schema 4; leitura declarada dos schemas 1–4  
**Escopo:** correção das falhas reproduzidas na auditoria técnica e, na revisão adicional, dos defeitos de calendário/backup, sem criar V82.

## Parecer

As falhas de domínio reproduzíveis foram corrigidas na própria V81. Os motores alterados compilam isoladamente em Kotlin/JVM e o harness executável terminou com **370 testes aprovados e 0 falhas**, cobrindo 49 dos 53 arquivos de teste.

Isso não significa que o APK Android esteja certificado. Quatro arquivos de teste dependentes de Android/JSON não entraram no harness local e não há Gradle CLI, Gradle Wrapper (`gradlew`) nem Android SDK neste ambiente. Build Compose, APK, backup/restauração em Android e importação real no Pace Coach continuam pendentes de execução no GitHub Actions/aparelho.

## 1. Correções de produção

### 1.1 Pace médio previsto e pausas passivas
**Arquivo:** `android/app/src/main/java/com/airunningcoach/app/UnifiedPrescriptionCalculator.kt`

- Separados `totalSeconds` e `movingSeconds`.
- A duração total da sessão continua somando trabalho e pausas passivas.
- O pace médio usa apenas o tempo em movimento; pausa passiva não acrescenta distância nem tempo de movimento.
- Quando não existe tempo de movimento mensurável e há pausa passiva, o motor não fabrica um pace dividindo pelo tempo decorrido.
- A duração de fallback só funciona como proxy de movimento quando não há pausa passiva prescrita.

**Regressão verificada:** treino misto com 2.460 s de duração total mantém essa duração, mas o pace correto passa a ser calculado com 405 s/km em vez de 461 s/km. O caso simples de 1 km a 6:00/km com dois minutos de pausa também permanece 6:00/km.

### 1.2 Prontidão aplicada à dose real do plano
**Arquivo:** `android/app/src/main/java/com/airunningcoach/app/CoachEngine.kt`

- O fator inicial de prontidão agora entra no alvo de cada semana, em vez de afetar somente a flag de volume limitado.
- Recuperação `POOR`: fator 0,72.
- Segurança `YELLOW`: fator 0,82.
- Enquanto `POOR` ou `YELLOW` persistir, as sessões de qualidade ficam suspensas em todas as semanas afetadas; semanas regenerativas continuam respeitadas.
- A redução não substitui os limites de carga e de segurança já existentes. Dor com estado `RED` continua bloqueando a geração de sessões.

### 1.3 Flags usam as zonas efetivamente calculadas
**Arquivo:** `android/app/src/main/java/com/airunningcoach/app/CoachEngine.kt`

- `buildFlags` agora recebe `paceZones`, inclusive quando calculadas a partir do teste Cooper durante a geração.
- A classificação de elegibilidade deixa de depender exclusivamente de uma zona já persistida no cadastro.
- Isso corrige a flag de supressão de qualidade em perfis que têm Cooper válido, mas ainda não salvaram a calibração no campo de zonas.

### 1.4 Seleção F01/F04 e variedade no ciclo de 5 km
**Arquivo:** `android/app/src/main/java/com/airunningcoach/app/TrainingPeriodizationEngine.kt`

- Em objetivo de recorde pessoal, a primeira posição BASE seleciona F04 quando recuperação e fadiga foram informadas em conjunto; sem o par, usa F01.
- A posição seguinte BASE pode selecionar F04.
- F04 só inclui Z4 se `thresholdEligible` permitir; sem isso, permanece em Z2/Z3 e não inclui Z4/Z5.
- Na fase específica de 5 km, I05 substitui a repetição de I07 no ponto do ciclo que antes duplicava o estímulo do desenvolvimento. F03 continua condicionado à elegibilidade VO₂.
- A seleção continua determinística, com base em intenção, fase, carga, prontidão, consistência e zonas calibradas.

## 2. Correções de testes e metadados

| Arquivo | Ajuste |
|---|---|
| `PaceOnlyMethodologyV72Test.kt` | Trata o retorno anulável de `calculateCooper` e testa Cooper inválido. |
| `AppBackupCodecTest.kt` | A expectativa do novo backup foi atualizada para V81; a fixture de migração identifica V78/schema 3. |
| `UnifiedPrescriptionCalculatorTest.kt` | Pace esperado corrigido para o tempo em movimento; duração total continua incluindo a pausa. |
| `CoachEngineTest.kt` | Cenários de qualidade agora fornecem evidência mínima de consistência, zonas e prontidão; comparações de progressão isolam semanas regenerativas; protocolo I04 valida as quatro repetições e as três recuperações entre elas. |
| `TrainingPeriodizationEngineTest.kt` | Expectativas alinhadas à seleção I07/I05, ao feedback de recuperação/fadiga e ao piso de frequência do planejador. |
| `PerformanceMonitoringEngineV63Test.kt` | Contagem esperada ajustada ao filtro de sessões comparáveis. |
| `RaceStrategyEngineTest.kt` | Centro da faixa esperado alinhado à margem conservadora produzida pelo motor. |
| `TrainingGoalCatalogTest.kt` | Meia maratona validada com 21,0975 km, em vez de 21,1 km com tolerância incompatível. |
| `WorkoutDurationEstimatorTest.kt` | Sem pace calibrado nem fallback explícito, não espera uma estimativa genérica de 7:00/km. |

As asserções foram ajustadas para refletir as regras já implementadas e documentadas, sem remover os gates de segurança. Casos de F01/F04 continuam verificando a ausência de Z4/Z5 quando o atleta não atende aos critérios de limiar.

## 3. Resultado dos testes locais

| Item | Resultado |
|---|---:|
| Arquivos Kotlin de teste no ZIP | 53 |
| Arquivos incluídos no harness | 49 |
| Testes executados | 370 |
| Aprovados | 370 |
| Falhas | 0 |
| Arquivos não executados no harness | 4 |

Arquivos fora do harness isolado por dependências da camada Android/JSON:
- `AppBackupCodecTest.kt`
- `PaceCoachExporterTest.kt`
- `PaceCoachJsonAttachmentTest.kt`
- `RaceStrategyWorkoutExporterTest.kt`

A compilação isolada dos três arquivos de produção alterados (`CoachEngine.kt`, `TrainingPeriodizationEngine.kt` e `UnifiedPrescriptionCalculator.kt`) também foi concluída. Há avisos Kotlin de parâmetros/variáveis não utilizados em `CoachEngine`; não são erros no harness isolado.

## 4. O que ainda não está comprovado

1. `:app:testDebugUnitTest` com JUnit/Gradle oficial, incluindo os quatro arquivos fora do harness local.
2. `:app:assembleDebug` e geração do APK.
3. Navegação/estado das 17 rotas Compose em Android real.
4. Exportação e importação real no Pace Coach, incluindo 1 km, 400 m, etapa por tempo, intervalo repetido e recuperação ativa/passiva.
5. Backup completo e restauração real, inclusive backup V78/schema 3 e schemas 1–2 antigos.
6. Recalcular um plano antigo no aparelho e confirmar preservação de sessões concluídas, feedback e datas.

## 5. Critério de encerramento

A correção de domínio está concluída para as falhas reproduzidas nesta auditoria. A V81 só deve ser considerada APK aprovada quando o GitHub Actions concluir `:app:testDebugUnitTest` e `:app:assembleDebug` e os fluxos de exportação/backup forem confirmados no aparelho.

**Versão entregue permanece V81.** Nenhum incremento de versão foi feito.


## Revisão adicional — calendário e importação seletiva

As correções da primeira semana vazia, identidade por instância e colisão de IDs no backup estão documentadas em `CORRECTION_REPORT_V81_CALENDAR_BACKUP.md`. O harness isolado específico desta revisão executou 14 verificações e passou em todas. As regressões JUnit do merger JSON foram adicionadas, mas aguardam `:app:testDebugUnitTest` no GitHub Actions.
