# Metodologia operacional de zonas — V61

## Escopo
O aplicativo mantém cinco zonas operacionais de pace (Z1–Z5). Os limites iniciais são estimados pelo Teste de Cooper de 12 minutos e podem receber calibração individual por evidências. As faixas ativas da sessão representam subfaixas percentuais dentro da zona; esses percentuais não são %VO₂máx, percentual de frequência cardíaca ou limiar medido.

## Significado operacional
- Z1: corrida muito leve, aquecimento, desaquecimento e regeneração.
- Z2: esforço aeróbio confortável, rodagens e longões.
- Z3: intensidade moderada sustentada.
- Z4: referência estimada de limiar; não equivale a LT2 medido.
- Z5: alta intensidade estimada; não confirma VO₂máx medido.

## Regras de faixa ativa
- Aquecimento/desaquecimento Z1: 80–100% da zona (extremidade mais rápida, sem obrigação de atingir o limite).
- Entrada confortável Z2: 0–20% da zona.
- Rodagem Z2 padrão: 20–65% como faixa de trabalho operacional.
- Z3/Z4/Z5 recebem subfaixas próprias por modalidade; intervalos curtos em Z5 usam apenas a entrada da zona e não devem virar sprint máximo.
- Recuperações de intervalados: Z2 confortável 0–20%, com RPE e respiração como controles complementares.

## Calibração
- Cooper fornece uma referência de capacidade, não a medição de todos os limiares fisiológicos.
- Teste da fala pode refinar a fronteira aeróbia/Z2 quando há observações consistentes em sessões diferentes.
- Evidência de Z1/Z3 só altera as respectivas faixas quando os critérios independentes do motor de calibração forem atendidos.
- A mudança entre calibrações é limitada gradualmente para evitar oscilações bruscas.
- A atividade comum importada não é tratada automaticamente como prova ou teste máximo.

## Uso das zonas em sessões
A zona, o pace ativo, o RPE, a dose e o nome do segmento são armazenados no mesmo objeto de prescrição. `TrainingPrescriptionAudit` compara nome/zona, faixa ativa/paces e soma de distância para impedir que, por exemplo, um segmento chamado Z3 seja apresentado com pace de Z1.

Os critérios de elegibilidade de limiar e VO₂ são guardrails conservadores de produto (nível, frequência, volume recente, maior corrida, zonas e feedback), não limites fisiológicos universais. Quando faltam evidências, o motor reduz a complexidade e permanece em Z2/Z3 controlada.
