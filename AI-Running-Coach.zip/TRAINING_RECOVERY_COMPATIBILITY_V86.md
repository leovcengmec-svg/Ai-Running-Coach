# Compatibilidade de recuperação — V86

## Regra do Fartlek
- F01, F02 e F04 recuperam em trote leve Z2, na faixa ativa 20–65% da Z2 individual. O ritmo deve ser mais fácil que o bloco de esforço, sem exigir que a faixa seja idêntica à do aquecimento/desaquecimento.
- F01 usa 2 minutos por recuperação entre variações. Não existe recuperação depois do último bloco de trabalho.
- RPE 2–3 e controle respiratório são referências complementares. O alvo principal continua sendo o pace individual calibrado, quando disponível.

## Compatibilidade
- `ACTIVE_Z2` não é convertido em `WALK` pela ausência de interseção exata com a faixa do desaquecimento. A faixa 20–65% limita o trote à Z2 confortável.
- Recuperações Z1 explicitamente prescritas por protocolos de intensidade elevada continuam sujeitas à validação conservadora e podem ser caminhada quando não houver compatibilidade.
- `PASSIVE` permanece pausa parada sem pace/zona; `WALK` intencional permanece caminhada sem pace/zona.

## Migração de planos existentes
- Sessões Fartlek ainda não concluídas são normalizadas para recuperação ativa Z2.
- Recuperações em Z1 legadas (incluindo 0–50%) são recalculadas a partir da faixa Z2 congelada no snapshot de calibração.
- Sessões que a regra V84 converteu automaticamente em `WALK` são restauradas apenas quando identificadas pelo nome e por um dos dois motivos específicos emitidos/observados: “não é compatível com o desaquecimento” (texto da sessão observada) ou “não possui uma faixa ativa Z1 compatível” (fallback do motor V84). Caminhadas intencionais não são convertidas.
- F01 legado passa a 2 min por recuperação; F02/F04 preservam a dose temporal existente e mudam apenas a zona/modo.
- Sessões concluídas, feedbacks, atividades importadas e histórico original são imutáveis. A migração é idempotente.
