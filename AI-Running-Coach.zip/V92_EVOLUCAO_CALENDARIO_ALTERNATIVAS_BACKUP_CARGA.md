# V92 — evolução do calendário, alternativas, histórico e progressão de carga

**Base:** AI Running Coach V91  
**VersionCode:** 92  
**VersionName:** V92  
**CURRENT_ENGINE_VERSION:** 81  
**Backup Schema:** 7 (leitura compatível com schemas 1–6)

## Escopo aplicado

### 1. Calendário e identidade dos ícones

- O marcador de prova utiliza a bandeira quadriculada `🏁`, inclusive na categoria geral PROVA.
- Os marcadores de treino no mês passaram a 25 dp; ícones de sessão na agenda e no histórico usam 48 dp.
- O selo no marcador mensal mostra ✓ para concluído e × para não realizado; status não altera o significado/cor base da categoria.
- Somente sessões vencidas e não concluídas recebem opacidade reduzida. Sessões concluídas, de hoje e futuras permanecem com cor integral.
- A legenda mantém três colunas e altura mínima para rótulos em até duas linhas. O calendário mensal usa células de 80 dp e não depende de abreviações de categoria que eram cortadas.

### 2. Duas alternativas de sessão

- A primeira alternativa preserva objetivo, zonas e dose principal; para progressões e Fartlek, a ordem dos blocos ativos e das recuperações é mantida.
- Longões progressivos são tratados como sessões progressivas antes da alternativa genérica de longão, para que Z2/Z3 não sejam achatadas em Z2.
- A segunda alternativa reduz a exigência e, quando necessário, a distância/duração do bloco principal. Aquecimento, desaquecimento e recuperação não são reduzidos artificialmente.
- Ambas substituem a sessão original; mantêm `sessionId`, data, semana e ciclo. Não criam sessão adicional.
- O volume efetivo da opção escolhida é utilizado no gráfico de volume, nos cards semanais, na distribuição de intensidade e no dashboard. A meta de referência permanece visível; caso a opção leve reduza a distância, o sistema mostra o déficit em vez de compensar com quilômetros artificiais.
- Quando sinais recentes de dor/recuperação/fadiga impedem preservar estímulo de qualidade, a opção equivalente é bloqueada e a opção mais leve permanece disponível. A camada de estado também bloqueia tentativas diretas de selecionar a opção equivalente.

### 3. Tela Evolução

- Mantém métricas, volume semanal, carga e monitoramento do ritmo.
- Remove painéis duplicados de zonas/calibração e atividades recentes.
- O detalhamento de zonas e o painel “Comportamento por zona” permanecem na tela dedicada de Zonas de ritmo.

### 4. Reconciliação de backup e histórico

- Cada novo feedback persiste `canonicalWorkoutKey`, derivada da data originalmente planejada e do tipo estruturado da sessão.
- A reconciliação aceita o ID exato quando disponível; se IDs foram remapeados por migração de backup, usa data original + tipo apenas quando há uma única sessão candidata no ciclo atual.
- Correspondências ambíguas ou múltiplas não são associadas automaticamente; o registro permanece preservado como histórico órfão, sem concluir treino incorreto.
- O campo novo é armazenado dentro do JSON dos feedbacks; backups antigos não precisam contê-lo.
- Schema 7 mantém o decoder compatível com schemas 1–6.

### 5. Progressão de carga

- Tendência sRPE só limita a progressão quando o histórico medido é confiável.
- RPE médio ≥ 7,5 só é considerado sinal moderado se pelo menos três atividades medidas contribuíram para a média.
- Amostras insuficientes continuam visíveis como dados descritivos, mas não reduzem automaticamente o passo semanal.
- A progressão é reavaliada nas novas gerações do plano; cautela moderada e sinais severos continuam separados.
- Sem alteração dos limites de segurança severa nem da regra de recuperação semanal herdada da V90/V91.

## Arquivos centrais alterados

- `android/app/src/main/java/com/airunningcoach/app/MainActivity.kt`
- `android/app/src/main/java/com/airunningcoach/app/WorkoutAlternativeEngine.kt`
- `android/app/src/main/java/com/airunningcoach/app/WorkoutCalendarPresentation.kt`
- `android/app/src/main/java/com/airunningcoach/app/SessionIdentityEngine.kt`
- `android/app/src/main/java/com/airunningcoach/app/LoadPrescriptionEngine.kt`
- `android/app/src/main/java/com/airunningcoach/app/CoachEngine.kt`
- `android/app/src/main/java/com/airunningcoach/app/AppBackupManager.kt`
- `android/app/build.gradle.kts`

## Critérios de aceitação

1. Nenhum ícone/rótulo de categoria fica cortado nos marcadores/legenda.
2. A prova exibe bandeira quadriculada no calendário, cards e legenda.
3. Status só atenua treino passado não concluído; hoje/futuro e concluídos têm opacidade integral.
4. A primeira alternativa preserva estímulo e sequência dos blocos; a segunda reduz dose e volume quando indicado.
5. Alternativas atualizam a prescrição semanal visível sem criar nova sessão ou ultrapassar a distância original.
6. O feedback de um slot remapeado aparece com a sessão atual apenas se a data original e o tipo produzirem correspondência única.
7. Tendência sRPE e RPE sem amostra suficiente não limitam a progressão.
8. Evolução deixa de repetir painéis já disponíveis em Gerenciar perfil.
9. `:app:testDebugUnitTest` e `:app:assembleDebug` passam no GitHub Actions antes de declarar o APK aprovado.

## Limitações de validação deste pacote

Os harnesses Kotlin/JVM focalizados executados no ambiente confirmam calendário/status/identidade, regras de progressão, alternativas de qualidade/Fartlek/longão progressivo e redução de volume. A suíte JUnit completa, compilação Compose/Kotlin do módulo Android e geração de APK não foram executadas localmente: este ambiente não tem Gradle CLI nem Android SDK. O workflow `.github/workflows/android.yml` está configurado para executar `:app:testDebugUnitTest` e `:app:assembleDebug` com JDK 21 e Gradle 9.6.
