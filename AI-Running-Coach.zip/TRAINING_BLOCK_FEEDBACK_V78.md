# Training Block Feedback & Zone Execution Intelligence — V78

## Objetivo
Substituir a tentativa de reconstruir a execução dos blocos a partir de voltas/amostras do arquivo por um registro explícito do corredor, bloco a bloco. A calibração isolada da Z2 por ritmo confortável deixa de fazer parte do feedback e de produzir evidência para as zonas.

## Fluxo do corredor
1. O treino concluído é carregado com os mesmos segmentos, zonas e faixas de ritmo originalmente prescritos.
2. Cada segmento repetido é expandido em ocorrências. Quando trabalho e recuperação formam um par com a mesma contagem, a interface intercala as ocorrências: trabalho 1, recuperação 1, trabalho 2, recuperação 2 etc.
3. Para cada bloco que admite ritmo, o corredor pode inserir um pace em `mm:ss min/km`. A entrada é opcional, mas, quando preenchida, deve ser válida.
4. Pausa passiva e recuperação caminhando não exigem pace. Segmentos sem faixa numérica não recebem uma comparação inventada.
5. O feedback geral (esforço, sensação, dor, terreno, distância e tempo) continua disponível.

## Classificação de execução
Os limites congelados no registro representam a faixa originalmente prescrita:
- `actual < fastestTarget`: `FASTER_THAN_TARGET` — mais rápido que o proposto.
- `fastestTarget <= actual <= slowestTarget`: `WITHIN_TARGET` — dentro do ritmo proposto.
- `actual > slowestTarget`: `SLOWER_THAN_TARGET` — mais lento que o proposto.
- Sem pace informado: `NO_DATA`.
- Sem faixa prescrita: `NO_PACE_TARGET`.

A classificação descreve apenas a velocidade frente ao alvo. Ela não atribui automaticamente qualidade fisiológica positiva a um pace mais rápido. A interpretação considera zona, finalidade, recuperação, esforço, sensação e dor.

## Inteligência por zona
`WorkoutBlockFeedbackEngine.summary` consolida registros por Z1–Z5, com quantidade de blocos, sessões distintas e distribuição mais rápido/dentro/mais lento. A ordem original dos blocos também permite detectar início mais rápido seguido de queda, desaceleração progressiva, aceleração tardia ou execução estável dentro da mesma sessão, comparando o desvio em relação ao ponto médio da meta de cada bloco. Para essa leitura exploratória, a diferença entre terços inicial e final é considerada relevante a partir de 15 s/km; esse corte é operacional, não um limiar fisiológico validado.
- Evidência inicial: menos de cinco blocos ou menos de três sessões diferentes.
- Evidência acumulada: pelo menos cinco blocos em pelo menos três sessões sem relato de dor.
- Repetição frequente de ritmo mais rápido com esforço controlado gera candidata a revisão assistida.
- Repetição frequente de ritmo mais lento com esforço elevado orienta revisar carga/faixa antes de progredir.
- Padrões inconsistentes mantêm observação.

Esses critérios são sinais de acompanhamento, não limiares fisiológicos validados. A V78 não altera automaticamente a faixa de uma zona: um ritmo digitado isolado não é suficiente para estimar limiares ou reclassificar zonas. A recalibração continua exigindo testes de desempenho e avaliação longitudinal.

## Integridade histórica e backup
Cada ocorrência salva `segmentIndex`, `repetition`, `segmentName`, `targetZone`, `targetFastestPaceSecondsPerKm`, `targetSlowestPaceSecondsPerKm`, pace realizado, modo de alvo e modo de recuperação. A faixa original é imutável dentro do registro, ainda que o plano futuro seja recalibrado.

Os dados ficam dentro de `feedbackRecords`, exportados pelo mesmo backup Schema 3. A leitura dos registros antigos permanece compatível. Entradas de teste da fala salvas por versões anteriores podem ser lidas, mas não participam mais da calibração. Nenhum histórico antigo é apagado.

## Relação com os arquivos GPX/FIT/TCX
Os arquivos continuam úteis para preencher métricas globais realmente existentes no arquivo: distância, tempo, pace médio, elevação, parciais, percurso e distribuição temporal por zona quando há amostras suficientes. Não há alinhamento de voltas/amostras com os blocos prescritos, nem atribuição automática de ritmo GPX aos registros manuais.

## Limites
- Pace digitado por bloco é um dado autorrelatado e pode ter erro de memória; não é equivalente a um lap medido.
- Comparações entre sessões devem considerar dose, terreno, inclinação, clima, fadiga, tipo de estímulo e recuperação.
- Um ritmo mais rápido pode representar intensidade excessiva para Z1/Z2; a tela não deve incentivar aceleração indiscriminada.
- Z5 tem grande sensibilidade à duração e recuperação do esforço; não se deve inferir capacidade contínua a partir de uma repetição curta.
- A V78 registra tendências e evita ajustes automáticos. Evolução futura pode adicionar prompts de confirmação/teste de campo para validar candidatos a revisão.
