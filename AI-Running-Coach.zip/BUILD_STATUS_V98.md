# Build Status — AI Running Coach V98

- Base: V97.
- VersionCode: 98.
- VersionName: V98.
- Motor interno: 88.
- Backup Schema: 13; leitura compatível com schemas 1–12.
- Correções de backup/testes fisiológicos e histórico de treinos incorporadas ao source set Android.
- Harness Kotlin/JVM isolado da gestão de avaliações: 5 cenários PASS.
- 16/16 verificações estáticas focadas e parser Kotlin sem erro sintático reportado: PASS.
- ZIP final: `AI-Running-Coach.zip`, integridade verificada com `unzip -t` sem erros; versão 98 e schema 13 conferidos dentro do arquivo.

## Build Android

**Pendente de CI.** Este ambiente não contém Gradle, `gradlew` nem Android SDK; portanto, não foi possível executar JUnit/Gradle, compilação Compose nem produzir APK.

O workflow `.github/workflows/android.yml` está incluído e executa:

```bash
gradle -p android :app:testDebugUnitTest :app:assembleDebug --no-daemon
```

A V98 só deve ser considerada APK-validada depois de o workflow `build-apk` finalizar sem erros e publicar o artefato.
