# BUILD STATUS — AI Running Coach V81

## Identificação
- Base: `AI-Running-Coach.zip` da V80.
- Pacote de entrega: `AI-Running-Coach.zip` (nome preservado).
- `versionCode`: 81.
- `versionName`: V81.
- `CURRENT_ENGINE_VERSION`: 72.
- Backup Schema: 4; leitura dos schemas 1–4 preservada.

## Implementações da V81

### 1. Integração Pace Coach — correção crítica
- Corrigida a conversão de distância no envelope legado `com.garmin.connect.workout.json.UserWorkoutJson`.
- `endConditionValue` agora é exportado em metros reais quando `endConditionUnitKey` é `meter`: 1 km = 1.000; 1,1 km = 1.100; 400 m = 400.
- Removida a multiplicação indevida por 100, que fazia o Pace Coach interpretar 1 km como 100.000 m.
- Duração permanece em milissegundos.
- Ritmo continua no campo de velocidade/unidade já utilizado pelo contrato, com limites ordenados corretamente.
- Recuperação ativa pode transportar ritmo-alvo quando a prescrição possui os dois limites; pausa passiva permanece `no.target`.
- Valores de distância/duração inválidos e faixa de ritmo incompleta bloqueiam a exportação com mensagem explicativa, em vez de produzir JSON silenciosamente incompleto.
- Exportação de treino semanal e estratégia de prova compartilham o mesmo exportador e recebem as correções.

### 2. Testes de exportação
- Atualizado o teste de 1,25 km para esperar 1.250 metros.
- Adicionados casos de 200 m, 400 m, 600 m, 1 km, 1,1 km, 1,5 km e 5 km.
- Adicionada verificação de recuperação ativa com ritmo e pausa passiva sem ritmo.
- Mantidos testes de envelope, IDs, ordem e grupos repetitivos.

### 3. Evolução do volume planejado
- Adicionada à tela Plano a visualização de volume semanal previsto, incluindo quilômetros de provas cadastradas.
- Semana atual destacada.
- Texto diferencia explicitamente volume planejado de volume realizado; a tela Evolução continua calculando o volume real a partir das atividades concluídas e distâncias registradas.
- Removida mensagem duplicada no rodapé do Plano.

### 4. Biblioteca e periodização
- Mantidos os protocolos tipados, seleção cíclica por fase/objetivo, gates de elegibilidade, variações de Fartlek, intervalados e Tempo Run já presentes na V80.
- Mantidas as recuperações corrigidas na V80 (F01 em Z1 alta; recuperação aeróbia em Z2 lenta, conforme protocolo), sem converter pausas passivas em corrida.
- Mantida a regra de dose exata e a validação de quantidade de recuperações.

### 5. Semana de competição
- Mantido o taper da prova A: sessões na semana do evento são convertidas em ativação leve quando necessário, e a competição substitui uma sessão normal.
- Provas B/C continuam substituindo apenas uma sessão, sem taper automático.
- Preservadas as regras de recuperação pós-prova e proteção de sessões manualmente reagendadas.

## Validação e limitações deste ambiente
- Revisão estática dos pontos alterados e dos testes concluída.
- O teste de domínio da conversão foi conferido contra a leitura observada na tela do Pace Coach: 1 km deve ser lido como 1.000 m, não 100.000 m.
- A documentação oficial Garmin descreve etapas de treino com tipo/valor de duração e alvo separados; ela não substitui a validação do envelope legado específico do Pace Coach. Referência: https://developer.garmin.com/fit/articles/file-types/workout.html
- Este ambiente não possui Gradle CLI, Gradle Wrapper, Android SDK ou dependências locais para executar `:app:testDebugUnitTest` e `:app:assembleDebug`.
- Portanto, **o APK Android/Compose não está certificado nesta sessão**. É obrigatório executar no GitHub Actions:
  - `:app:testDebugUnitTest`
  - `:app:assembleDebug`
  - Conferir o artefato `ai-running-coach-debug-apk`.
- A importação real no Pace Coach também deve ser confirmada no aparelho, com pelo menos 1 km, 400 m, uma etapa por tempo e uma recuperação ativa/passiva.

Não declarar a V81 como APK aprovado até concluir o build Android e a validação real de importação.


## Correções aplicadas após auditoria técnica da V81

### Código de produção
- `UnifiedPrescriptionCalculator.kt`: tempo total da sessão continua incluindo pausas passivas; o pace médio usa somente o tempo em movimento. Quando há pausa passiva e não há tempo de movimento mensurável, o pace não é inventado a partir do tempo decorrido.
- `CoachEngine.kt`: as flags de qualidade agora recebem também as zonas efetivamente calculadas a partir do teste Cooper, mesmo quando ainda não foram persistidas no perfil. O fator de prontidão passa a reduzir a dose semanal real (0,72 para recuperação POOR; 0,82 para segurança YELLOW) e a qualidade fica suspensa enquanto a condição persistir.
- `TrainingPeriodizationEngine.kt`: a seleção F01/F04 considera a presença explícita do par de feedback de recuperação/fadiga; o toque Z4 continua bloqueado sem elegibilidade de limiar. O protocolo específico de 5 km usa I05 na posição do ciclo que antes repetia I07 do desenvolvimento.

### Testes e consistência
- Corrigido o teste de Cooper para tratar o resultado anulável de `calculateCooper()` e cobrir entrada inválida.
- Atualizados os testes do backup: a exportação identifica V81 e a fixture de compatibilidade transforma o schema 4 da V81 em schema 3/V78 antes da leitura.
- Ajustadas expectativas de pace, distância oficial da meia maratona (21,0975 km), comparação de sessões e recuperações entre repetições para refletir as regras atuais implementadas.
- Reorganizados cenários de `CoachEngineTest` para fornecer dados de elegibilidade válidos e comparar semanas de construção separadamente das semanas regenerativas.

### Validação local desta correção
- Compilação Kotlin/JVM isolada dos três motores alterados (`CoachEngine`, `TrainingPeriodizationEngine` e `UnifiedPrescriptionCalculator`): concluída.
- Harness Kotlin/JVM: **370 testes aprovados, 0 falhas**, em 49 dos 53 arquivos de teste do projeto.
- Quatro arquivos não executados no harness isolado por dependências de Android/JSON: `AppBackupCodecTest.kt`, `PaceCoachExporterTest.kt`, `PaceCoachJsonAttachmentTest.kt` e `RaceStrategyWorkoutExporterTest.kt`. Os testes de backup foram atualizados, mas não são contabilizados entre os 370 aprovados.
- Permanecem avisos Kotlin de variáveis/parâmetros não utilizados já presentes em caminhos de `CoachEngine`; não são erros de compilação no harness.

### Limites de aprovação
- O ZIP não contém `gradlew`; este ambiente não possui Gradle CLI nem Android SDK. A compilação completa Android/Compose, `:app:testDebugUnitTest`, `:app:assembleDebug`, testes de UI, restauração real de backup e importação no Pace Coach não foram executados.
- Portanto, a V81 corrigida está **aprovada nos testes de domínio executáveis localmente**, mas o APK continua **pendente de certificação Android e de validação em aparelho**.


## Correção adicional V81 — calendário, identidade de sessões e importação de histórico

### Código de produção atualizado
- `TrainingScheduleEngine.firstTrainableWeekStart()` escolhe a primeira segunda-feira que ainda pode receber os dias habituais selecionados. No cenário de sábado, 21/11/2026, com segunda/quarta/sexta, a âncora passa para 23/11/2026 e essa semana recebe o número 1. Se domingo ainda for um dia habitual e estiver disponível, a semana atual permanece como semana 1.
- `RacePlanningEngine` recebe a âncora efetiva, mantendo o início do ciclo, as fases e a semana de prova A coerentes.
- `PlanMigrationEngine.rebaseEmptyFirstWeek()` repara planos legados cuja primeira semana está comprovadamente vazia. Uma sessão concluída/planejada do próprio primeiro bloco protege a âncora; atividades órfãs de outro ciclo não consomem a semana nova.
- `SessionIdentityEngine` cria IDs determinísticos com ciclo + data programada + tipo. IDs V81 relativos continuam aceitos para migração; datas originalmente programadas permanecem imutáveis em sessões reagendadas.
- `CompletedActivityBackupMerger` associa treinos e feedbacks pela identidade e data original, e não por `sessionId` isolado. Quando um ID legado coincide com uma sessão local de outra data, o histórico importado recebe um ID `LEGACY-*` separado e seus feedbacks são remapeados. A data de realização nunca é usada como substituta da data programada para concluir uma sessão.
- A validação de reagendamento compara a instância da sessão, impedindo que IDs relativos repetidos ocultem um dia já ocupado. Na recalibração, a correspondência por data original + tipo tem prioridade sobre o ID legado.
- O feedback salvo agora preserva `workoutOriginalDateIso`, permitindo relacionar com segurança uma atividade a uma sessão que foi reagendada.

### Testes adicionados
- `TrainingScheduleEngineTest.kt`: caso de ID relativo repetido em outra instância ao validar data ocupada.
- `PlanMigrationEngineTest.kt`: migração única de semana vazia, preservação de sessão/semana com evidência do próprio ciclo e IDs relativos repetidos entre datas.
- `PlanMigrationRescheduleTest.kt`: reagendamento reaplicado após troca de ID do motor e prioridade do slot original sobre ID relativo repetido.
- `SessionIdentityEngineTest.kt`: identidade determinística por ciclo/data e associação de feedback com data original.
- `AppBackupCodecTest.kt`: histórico importado com mesmo ID em datas diferentes, colisão entre data reagendada e data original, vários registros históricos com o mesmo ID e associação de feedback sem data.

### Verificações executadas nesta revisão
- Harness Kotlin/JVM com os motores reais `SessionIdentityEngine`, `TrainingScheduleEngine`, `PlanMigrationEngine` e `PlannedVsRealizedEngine`: **25 verificações aprovadas, 0 falhas**.
- Harness separado do `WorkoutBlockFeedbackEngine`: verificação da separação de sessões com mesmo ID/data e tipos diferentes aprovada.
- Revisão estática dos fluxos de criação do plano, carregamento/migração, seleção de sessão, feedback, reagendamento e importação seletiva.
- Testes Gradle/JUnit que dependem de `org.json`/Android foram adicionados, mas não executados neste ambiente.
- `versionCode = 81`, `versionName = V81` e Backup Schema 4 foram preservados. `CURRENT_ENGINE_VERSION` evoluiu de 71 para 72 para sinalizar a atualização do motor de calendário/identidade e solicitar recálculo explícito de planos V81 anteriores.

### Pendências de validação Android
- Executar `:app:testDebugUnitTest` e `:app:assembleDebug` no GitHub Actions.
- Testar no aparelho a criação no sábado 21/11/2026 com seg/qua/sex e confirmar 23/11 como Semana 1.
- Importar uma cópia do backup que reproduziu o defeito e confirmar que 23/11 continua Planejado, enquanto as atividades históricas permanecem no histórico e na data real.
- Fazer exportação e restauração do backup após a importação seletiva.

**Status:** correções aplicadas no código e cobertas por regressões. APK Android ainda não certificado neste ambiente.


## Revisão aplicada — calendário, migração e integridade do backup

- `versionCode = 81`, `versionName = V81`, Backup Schema 4 mantidos; `CURRENT_ENGINE_VERSION = 72` sinaliza planos do motor 71 para revisão/recálculo.
- Primeira semana vazia reancorada para a próxima segunda-feira com dia de treino disponível. Para sábado 21/11/2026 com seg/qua/sex, 23/11 passa a ser Semana 1.
- IDs de sessões incluem ciclo, data original e tipo. A associação de backup usa data planejada original e tipo; colisões de ID legado são remapeadas para histórico separado.
- Recálculo preserva feedback com ID + data + tipo. Feedback sem tipo só é aceito quando há uma única instância possível.
- Correção propagada para planejado versus realizado, resumo de zonas por bloco, substituição por prova e nomes/ordem de exportação.
- Harness focado dos motores de calendário/identidade/migração/planejado versus realizado: **25 verificações aprovadas, 0 falhas**. Harness separado do feedback por bloco: **1 verificação aprovada**.
- Testes JUnit do codec/merger JSON e integração Android foram atualizados, mas não executados neste ambiente. Gradle, Android SDK e `gradlew` ausentes; APK não certificado.
