# BUILD STATUS — AI Running Coach V81

## Identificação
- Base: `AI-Running-Coach.zip` da V80.
- Pacote de entrega: `AI-Running-Coach.zip` (nome preservado).
- `versionCode`: 81.
- `versionName`: V81.
- `CURRENT_ENGINE_VERSION`: 71.
- Backup Schema: 4; leitura dos schemas 1–4 preservada.

## Implementações da V81

### 1. Integração Pace Coach — correção crítica
- Corrigida a conversão de distância no envelope legado `com.garmin.connect.workout.json.UserWorkoutJson`.
- `endConditionValue` agora é exportado em metros reais quando `endConditionUnitKey` é `meter`: 1 km = 1.000; 1,1 km = 1.100; 400 m = 400.
- Removida a multiplicação indevida por 100, que fazia o Pace Coach interpretar 1 km como 100.000 m.
- Duração permanece em milissegundos.
- Ritmo continua no campo de velocidade/unidade já utilizado pelo contrato, com limites ordenados corretamente.
- Recuperação ativa pode transportar ritmo-alvo quando a prescrição possui os dois limites; pausa passiva permanece `no.target`.
- Valores de distância/duração inválidos e faixa de ritmo incompleta bloqueiam a exportação com mensagem explicativa, em vez de produzir JSON silenciosamente incompleto.
- Exportação de treino semanal e estratégia de prova compartilham o mesmo exportador e recebem as correções.

### 2. Testes de exportação
- Atualizado o teste de 1,25 km para esperar 1.250 metros.
- Adicionados casos de 200 m, 400 m, 600 m, 1 km, 1,1 km, 1,5 km e 5 km.
- Adicionada verificação de recuperação ativa com ritmo e pausa passiva sem ritmo.
- Mantidos testes de envelope, IDs, ordem e grupos repetitivos.

### 3. Evolução do volume planejado
- Adicionada à tela Plano a visualização de volume semanal previsto, incluindo quilômetros de provas cadastradas.
- Semana atual destacada.
- Texto diferencia explicitamente volume planejado de volume realizado; a tela Evolução continua calculando o volume real a partir das atividades concluídas e distâncias registradas.
- Removida mensagem duplicada no rodapé do Plano.

### 4. Biblioteca e periodização
- Mantidos os protocolos tipados, seleção cíclica por fase/objetivo, gates de elegibilidade, variações de Fartlek, intervalados e Tempo Run já presentes na V80.
- Mantidas as recuperações corrigidas na V80 (F01 em Z1 alta; recuperação aeróbia em Z2 lenta, conforme protocolo), sem converter pausas passivas em corrida.
- Mantida a regra de dose exata e a validação de quantidade de recuperações.

### 5. Semana de competição
- Mantido o taper da prova A: sessões na semana do evento são convertidas em ativação leve quando necessário, e a competição substitui uma sessão normal.
- Provas B/C continuam substituindo apenas uma sessão, sem taper automático.
- Preservadas as regras de recuperação pós-prova e proteção de sessões manualmente reagendadas.

## Validação e limitações deste ambiente
- Revisão estática dos pontos alterados e dos testes concluída.
- O teste de domínio da conversão foi conferido contra a leitura observada na tela do Pace Coach: 1 km deve ser lido como 1.000 m, não 100.000 m.
- A documentação oficial Garmin descreve etapas de treino com tipo/valor de duração e alvo separados; ela não substitui a validação do envelope legado específico do Pace Coach. Referência: https://developer.garmin.com/fit/articles/file-types/workout.html
- Este ambiente não possui Gradle CLI, Gradle Wrapper, Android SDK ou dependências locais para executar `:app:testDebugUnitTest` e `:app:assembleDebug`.
- Portanto, **o APK Android/Compose não está certificado nesta sessão**. É obrigatório executar no GitHub Actions:
  - `:app:testDebugUnitTest`
  - `:app:assembleDebug`
  - Conferir o artefato `ai-running-coach-debug-apk`.
- A importação real no Pace Coach também deve ser confirmada no aparelho, com pelo menos 1 km, 400 m, uma etapa por tempo e uma recuperação ativa/passiva.

Não declarar a V81 como APK aprovado até concluir o build Android e a validação real de importação.
