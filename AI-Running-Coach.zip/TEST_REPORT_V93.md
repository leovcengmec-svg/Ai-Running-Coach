# Relatório de testes — AI Running Coach V93

**VersionCode:** 93 · **Engine:** 83 · **Backup Schema:** 8

## Harness Kotlin/JVM executado

Compilação do núcleo:

```bash
kotlinc \
  android/app/src/main/java/com/airunningcoach/app/RunnerFitnessAssessmentEngine.kt \
  android/app/src/main/java/com/airunningcoach/app/PaceCalculator.kt \
  android/app/src/main/java/com/airunningcoach/app/ZoneCalibrationEngine.kt \
  android/app/src/main/java/com/airunningcoach/app/AdaptiveZoneCalibrationEngine.kt \
  android/app/src/main/java/com/airunningcoach/app/SessionIdentityEngine.kt \
  validation/V93Harness.kt \
  -include-runtime -d validation/v93-core.jar
java -jar validation/v93-core.jar
```

Resultado: `V93 core harness: PASS`.

| Cenário | Resultado |
|---|---|
| Limites efetivos Z1=15%, Z2=10%, Z3=5% | PASS |
| Propagação Z3→Z2/Z1 | PASS |
| Propagação Z2→Z1 | PASS |
| Contribuição isolada Z1, Z2 e Z3 | PASS |
| Z1 altera somente Z1 | PASS (caso isolado no harness e nos testes unitários) |
| Z4/Z5 continuam ancoradas | PASS |
| Limite de largura mínima de 10 segundos | PASS |
| Proposta inválida bloqueada | PASS |
| Reset das contribuições após novo teste | PASS |
| Tipos legados de aeróbio/rodagem normalizados | PASS |
| Janela de reteste dia 49–56 | PASS |

Avisos do compilador no harness: duas inicializações redundantes já existentes em `ZoneCalibrationEngine.kt`; não impedem a execução.

## Testes JUnit adicionados/atualizados (não executados localmente)

- `AdaptiveZoneCalibrationEngineTest`: contribuições diretas, máximos acumulados, cascata, reinício, preservação de Z4/Z5 e bloqueio de faixa estreita.
- `SessionIdentityEngineTest`: aliases históricos e correspondência por slot canônico.
- `CooperAssessmentEngineTest`: revisão de 28 dias sem obrigar novo teste máximo e reteste preferencial semana 7–8.
- `AppBackupCodecTest`: Schema 8 e leitura de schemas 1–7.

## Revisões estáticas

- `versionCode=93`, `versionName=V93`, `CURRENT_ENGINE_VERSION=83`, `SCHEMA_VERSION=8`.
- UI de Histórico inclui editar, vincular, remoção reversível, restaurar e exclusão definitiva com confirmação em duas etapas.
- A reconciliação manual exige data planejada/original e tipo compatível; não usa apenas data realizada.
- O histórico de calibração persiste a contribuição de origem separadamente do efeito acumulado.

## Pendente do GitHub Actions

A suíte Gradle/JUnit, `:app:compileDebugKotlin` e `:app:assembleDebug` não foram executadas neste ambiente. Não há APK certificado nesta entrega. Rodar o workflow `build-apk` e exigir resultado verde antes de publicar o APK.

## Correção de compilação após falha do GitHub Actions

O log enviado apontou `Function invocation 'first()' expected` e `Function invocation 'last()' expected` em `MainActivity.kt`. A causa era o uso de `persistedSlot?.first` e `persistedSlot?.last` como propriedades de `List<String>`.

- Parser tipado `SessionIdentityEngine.parseCanonicalSlotKey()` adicionado.
- Testes JUnit para chave válida/inválida e split limitado adicionados (não executados via Gradle neste ambiente).
- Compilação Kotlin/JVM focalizada, incluindo a função `historyLinkCandidates()` equivalente: **PASS**.
- Harness principal `V93Harness.kt` recompilado e reexecutado após a alteração: **PASS**.
- Gradle/Android e APK: **PENDENTES** do workflow GitHub Actions.
