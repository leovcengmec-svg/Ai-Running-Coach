# Relatório de aplicação e revisão — V82

**Base:** AI Running Coach V81 corrigida.
**Entrega:** `AI-Running-Coach.zip` (nome preservado).
**Versão:** `versionCode=82`, `versionName=V82`.
**Motor:** `CURRENT_ENGINE_VERSION=73`.
**Backup:** Schema 4, leitores 1–4 preservados.

## Resultado

O plano de correção de calendário e backup foi aplicado ao código-fonte. A V82 deixa de consumir uma semana sem dias habituais disponíveis e impede que uma atividade histórica com ID relativo coincidente conclua uma sessão futura.

## Alterações principais

1. `TrainingScheduleEngine.firstTrainableWeekStart()` resolve a primeira semana realmente treinável. No cenário das capturas (sábado 21/11/2026; dias segunda, quarta e sexta), a âncora passa a 23/11/2026 e os treinos de 23, 25 e 27/11 ficam na Semana 1.
2. A âncora é passada para a janela do ciclo, periodização, prova A e persistência. Não foi corrigido apenas o rótulo do card.
3. Planos antigos com primeira semana vazia recebem migração única, condicionada à ausência de evidência real/sessão do próprio ciclo naquela semana.
4. `SessionIdentityEngine` gera identidade determinística por ciclo/data/tipo.
5. `originalScheduledDateIso` preserva a data planejada original após reagendamento.
6. O mesclador seletivo exige correspondência por ID + data original + tipo compatível. IDs legados com datas diferentes são remapeados para `LEGACY-*`, com feedbacks associados à instância histórica correta.
7. A data real da atividade não é confundida com a data planejada. Feedback sem data suficiente não conclui uma sessão futura por inferência.

## Revisão e verificações

- 6/6 verificações independentes de domínio executadas nesta revisão: âncora de sábado, domingo disponível, ID estável, IDs distintos entre ciclos, feedback incompatível por data e rótulos semanais após filtragem.
- O pacote inclui regressões JUnit para colisões do backup, datas reagendadas, múltiplas sessões históricas com o mesmo ID relativo e feedback sem data.
- O código do mesclador foi revisado estaticamente; os testes com `org.json` ainda não foram executados por ausência do ambiente Gradle/Android.
- Integridade do ZIP verificada com `unzip -t`.

## Pendências obrigatórias

- Executar `:app:testDebugUnitTest` e `:app:assembleDebug` no GitHub Actions.
- Instalar o APK e testar Agenda, Plano e Histórico.
- Importar uma cópia do backup original que reproduziu o defeito; confirmar que o treino de 23/11 permanece Planejado e que a atividade histórica fica no histórico na data real, com data planejada preservada.
- Exportar o backup após a importação e restaurá-lo em instalação limpa.

**Parecer:** correções aplicadas; testes focados de domínio aprovados; build Android e validação do backup real ainda pendentes.
