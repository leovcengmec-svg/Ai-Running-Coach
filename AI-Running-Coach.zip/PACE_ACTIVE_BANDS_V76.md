# Zonas e faixas ativas — V76

## Interpretação
- Z1–Z5 são as zonas operacionais calculadas pela calibração de ritmo.
- A escala percentual é uma posição interna dentro da zona, não um percentual direto de VO₂máx, VAM ou frequência cardíaca.
- 0% corresponde ao limite de pace mais lento da zona; 100% corresponde ao limite mais rápido.
- Cada segmento pode usar qualquer faixa válida, por exemplo 0–20%, 17–47%, 50–80% ou 80–100%. Não existe obrigação de dividir em incrementos de 20%.
- A faixa é calculada como uma interpolação linear entre os dois limites de pace da zona.

## Aquecimento e desaquecimento
Para atletas com `experienceMonths >= 6`, o motor aplica Z2 0–20% ao aquecimento e ao desaquecimento, exceto quando a sessão é explicitamente um protocolo de iniciante corrida/caminhada. O pace resulta do snapshot de calibração individual; se não houver uma zona Z2 válida, o segmento informa a faixa e aguarda calibração sem inventar pace.

Para perfis com menos de seis meses ou experiência desconhecida, mantém-se a regra conservadora anterior, salvo quando o segmento já tem uma faixa explicitamente prescrita.

## Recuperação
- `PASSIVE`: alvo por tempo; sem pace, zona ou distância.
- `WALK`: caminhada; sem pace ou zona de corrida.
- `ACTIVE_Z2`: recuperação correndo em Z2 0–20%.
- Segmentos contínuos de progressão mudam de faixa/zona sem criar recuperação artificial.

Nos protocolos explícitos do V76, trabalho em Z5 usa recuperação parada cronometrada, trabalho em Z4 usa caminhada cronometrada e esforços menos intensos podem usar recuperação ativa Z2. A escolha deve ser revista por tipo e dose do protocolo antes de ampliar a biblioteca.

## Exportação
A exportação para dispositivos recebe os limites de pace calculados para cada faixa. O percentual interno não é exportado como VO₂ ou FC. Pausas paradas e caminhadas são passos de recuperação sem alvo de pace.

## Limites e segurança
A faixa percentual não libera uma zona por si só. A elegibilidade Z3–Z5 continua sob controle de nível, objetivo, histórico, volume, prontidão, testes e fase. A calibração do Cooper é estimativa de desempenho, não medição laboratorial direta de VO₂máx ou limiar. FC/FCM não é utilizada.
