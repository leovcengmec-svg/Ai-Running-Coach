# AI Running Coach V103 — relatório de implementação

**Base:** V102 enviada pelo usuário  
**Data:** 27/11/2026  
**VersionCode:** 103  
**Motor interno:** 93  
**Backup Schema:** 15

## 1. Semana regenerativa e carga

- Mantido o ciclo de três semanas de construção e uma semana regenerativa como organização padrão.
- Referência padrão da semana regenerativa: 25% abaixo da última semana de construção, não da semana regenerativa anterior.
- Redução adaptativa: 30% diante de uma cautela moderada/baixa execução; 35% diante de pelo menos dois sinais moderados; 40% diante de recuperação muito baixa ou fadiga elevada.
- A razão de carga continua usando recuperação, fadiga, RPE, tendência de carga e proporção de sessões realizadas. A taxa final é guardrail de produto, não uma prescrição clínica universal.
- Treinos não realizados não geram compensação de distância. Semana de competição planejada não recebe o deload periódico adicional, evitando empilhar duas reduções.
- Card expandido mostra a referência da última semana de construção, percentual de redução e meta regenerativa.

## 2. Calendário e Gerenciar perfil

- Selo de status do calendário desenhado em Canvas, com check branco para concluído e X branco para não realizado. O selo conserva posição no canto superior direito e não substitui o pictograma da modalidade.
- Ações de perfil usam pictogramas vetoriais desenhados por uma família comum, tiles de 50 dp e ícones de 25 dp.

## 3. Próximo evento

- O dashboard compara a próxima sessão pendente com o evento futuro mais próximo em estado `PLANNED`.
- A prova preparatória, principal ou de treinamento aparece quando for o compromisso mais próximo; em empate no mesmo dia, a prova tem prioridade.
- Eventos concluídos/cancelados não são mostrados como próximo evento. Se não existir compromisso, aparece estado vazio.

## 4. Calibração adaptativa

### Teste como referência fisiológica

- As zonas-base são calculadas diretamente do resultado válido atual: Cooper usa distância do Cooper; 3 km usa tempo de 3 km. Removida a limitação artificial de 15 segundos em relação ao teste anterior.
- A comparação é feita apenas dentro do mesmo protocolo: Cooper com Cooper e 3 km com 3 km.
- Melhora de pelo menos 2% zera os créditos ativos e inicia uma fase nova. Resultado dentro da tolerância de ±2% preserva créditos. Resultado pior preserva créditos e ativa a trava anti-reset.
- Troca de protocolo não converte Cooper em 3 km nem o inverso: os créditos anteriores são movidos para a área pendente e deixam de ser aplicados. Um novo resultado comparável restabelece a sequência do protocolo atual sem reaplicar o crédito incompatível.
- Edição demográfica, edição de teste, restauração e exclusão são tratadas como sincronização de referência, não como novo teste fisiológico. Quando o protocolo legado não pode ser identificado com segurança, os créditos ficam em espera em vez de serem misturados.

### Evidências e limites

- Revisão a cada 28 dias. As evidências só contam após a data do teste de referência e dentro da janela de análise.
- Lote A: pelo menos 5 blocos válidos distribuídos em pelo menos 3 sessões distintas; contribuição de até 3%.
- Lote B: pelo menos 5 blocos válidos em outras 3 sessões posteriores e distintas; contribuição adicional de até 2%.
- Quando os dois lotes são demonstrados na mesma janela de revisão, pode ser apresentado até 5% antes do próximo reteste; não se reutilizam blocos/sessões do Lote A no Lote B.
- Cada zona de origem tem teto direto de 5%. Propagação para zonas mais lentas: contribuição Z3 também afeta Z2/Z1; Z2 também afeta Z1; Z1 afeta somente Z1. Teto efetivo: Z1 15%, Z2 10%, Z3 5%. Z4–Z5 permanecem ancoradas ao teste.
- Propostas continuam dependendo de confirmação manual. Limite de largura de faixa continua protegendo bandas de ritmo que ficariam estreitas demais.

### Persistência

- Novo estado salvo: protocolo e métrica de referência, classificação de comparação, trava anti-reset, suspensão, protocolo dos créditos pendentes e percentuais pendentes por zona.
- Schema 15 inclui esse estado no campo JSON já persistido `adaptiveCalibrationState`. Schemas 1–14 continuam aceitos; metadados ausentes são carregados com defaults conservadores.

## 5. Monitoramento do ritmo

- Janela de 28 dias e distância medida/calculável de pelo menos 2 km.
- A comparação formal exige quatro sessões fáceis do mesmo tipo e terreno, sem dor/fadiga incompatível e com pace medido ou calculável por tempo/distância.
- Com 1–3 sessões comparáveis, o painel oferece apenas mediana preliminar, período, tipo, terreno, datas e quantidade faltante. Não mostra percentual de evolução nem altera zonas.
- Longão não é misturado com rodagem/regenerativo. Motivos de exclusão continuam visíveis.

## 6. Arquivos-chave alterados

- `android/app/build.gradle.kts` — versão V103.
- `MainActivity.kt` — estado, backup, apresentação, dashboard, calibração e calendário.
- `AdaptiveZoneCalibrationEngine.kt` — classificação, lotes, limites e proteção anti-reset.
- `LoadPrescriptionEngine.kt` / `CoachEngine.kt` — redução regenerativa e exclusão de semana de prova do deload periódico.
- `PerformanceMonitoringEngine.kt` — prévia e critérios de comparabilidade.
- `AppBackupManager.kt` — schema 15 e compatibilidade de leitura anterior.
- Testes `AdaptiveZoneCalibrationEngineTest`, `PerformanceMonitoringEngineTest`, `LoadPrescriptionEngineV63Test` e `AppBackupCodecTest`.

## 7. Limitações da validação

O harness local passou 16 cenários focados nos três motores Kotlin reais. O ambiente não dispõe de Gradle, Gradle Wrapper no projeto nem Android SDK; por isso a compilação Android/Compose, a suíte JUnit oficial e a geração do APK continuam dependentes do GitHub Actions. Ver `TEST_REPORT_V103.md` e `BUILD_STATUS_V103.md`.
