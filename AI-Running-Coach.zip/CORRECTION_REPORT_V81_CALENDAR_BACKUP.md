# Relatório de aplicação e revisão — V81

**Pacote:** `AI-Running-Coach.zip`  
**Identidade do app:** `versionCode = 81`, `versionName = V81` (preservada)  
**Motor interno:** `CURRENT_ENGINE_VERSION = 72` (de 71 para 72)  
**Backup:** Schema 4; leitura de schemas 1–4 preservada  
**Escopo:** correção da semana inicial, identidade de instâncias de treino e importação seletiva de histórico.

## Parecer

As correções do plano foram aplicadas ao código-fonte da V81. A primeira semana agora é definida pela disponibilidade real dos dias habituais; as sessões novas têm identidade determinística por ciclo, data originalmente planejada e tipo; o histórico importado só conclui uma sessão local quando a identidade e a data original correspondem. IDs relativos legados em datas diferentes são preservados em instâncias históricas separadas.

A revisão incluiu salvaguardas extras para reagendamentos: a data original + tipo tem precedência sobre ID relativo e a data movida não é tratada como data original ao cruzar backups. O mesmo `sessionId` em outra data não pode ocupar ou concluir uma sessão diferente.

## 1. Alterações de produção

| Arquivo | Alteração |
|---|---|
| `TrainingScheduleEngine.kt` | Resolve primeira semana treinável e valida slots por identidade da instância, não por ID relativo. |
| `RacePlanningEngine.kt` | Recebe a âncora efetiva ao resolver a janela do ciclo e a semana da prova A. |
| `CoachEngine.kt` | Gera IDs novos determinísticos com ciclo + data + tipo. |
| `SessionIdentityEngine.kt` | Centraliza criação de ID, data original, slot e vínculo seguro de feedback. |
| `PlanMigrationEngine.kt` | Reancora planos antigos com semana inicial vazia; preserva histórico por ID + data; reaplica reagendamentos com preferência ao slot original. |
| `AppBackupManager.kt` | Mescla backup seletivo por ID + data original; remapeia colisões para `LEGACY-*` e move os feedbacks correspondentes. |
| `MainActivity.kt` | Usa a primeira semana treinável, preserva a data original ao salvar feedback/reagendamento e associa conclusão pela instância exata. |

## 2. Comportamento esperado para as capturas

**Criação em sábado, 21/11/2026, com segunda/quarta/sexta disponíveis:** como todos os dias selecionados daquela semana já passaram, a âncora passa para segunda-feira, 23/11/2026. Os treinos de 23, 25 e 27/11 passam a pertencer à **Semana 1**. Se domingo estiver selecionado e ainda puder receber treino, a semana atual permanece como Semana 1.

**Importação do histórico com ID legado repetido:** supondo uma sessão antiga com `W2-MONDAY-AEROBIO` em 16/11 e uma sessão local para 23/11, a atividade de 16/11 é mantida em separado com ID histórico remapeado. Seu feedback acompanha essa mesma sessão. A sessão de 23/11 continua `done = false`, visível na Agenda e no Plano como Planejado.

O importador não usa `realizedDateIso` para identificar a sessão planejada. Essa data continua representando apenas quando a atividade aconteceu.

## 3. Regressões adicionadas

- Primeira semana treinável: sábado sem dias restantes, domingo ainda disponível, semana já ocupada e migração única de plano antigo.
- Identidade: IDs determinísticos para o mesmo ciclo/data/tipo e diferentes entre ciclos.
- Feedback: associação exige ID + data original; feedback de sessão reagendada exige que a data original esteja persistida.
- Migração: histórico com ID relativo repetido em datas distintas não elimina a sessão nova.
- Reagendamento: troca de ID pelo motor não perde a data movida; o slot original prevalece sobre ID relativo repetido; uma instância de outro ciclo não esconde uma data ocupada.
- Backup: mesmo ID legado em datas diferentes, data reagendada vs. original, múltiplos históricos com ID relativo repetido e feedback sem data segura.

## 4. Validação executada

- Harness Kotlin/JVM que compila os motores reais `SessionIdentityEngine.kt`, `TrainingScheduleEngine.kt` e `PlanMigrationEngine.kt`: **25 verificações aprovadas, 0 falhas**.
- Revisão estática dos fluxos em `MainActivity`, criação/recalibração, carregamento, feedback, reagendamento e `CompletedActivityBackupMerger`.
- Testes JUnit de backup e integração foram incluídos em `AppBackupCodecTest.kt`, mas não foram executados neste ambiente porque não há Gradle/Gradle Wrapper, Android SDK nem a dependência `org.json` instalada.
- Não foi gerado APK nesta sessão. `:app:testDebugUnitTest` e `:app:assembleDebug` continuam obrigatórios no GitHub Actions.

## 5. Revisão final / riscos residuais

1. A validação de domínio cobre a âncora, migração, identidade, colisão e reagendamento, mas não substitui o teste com o arquivo de backup real que reproduziu a captura.
2. A compatibilidade com backup V78/V79/V80 e V81 depende ainda de executar os testes JUnit do codec/merger e uma restauração no Android.
3. O app permanece V81 por solicitação; o `CURRENT_ENGINE_VERSION` 72 faz planos criados pelo motor 71 serem sinalizados para recálculo/revisão.
4. O APK não deve ser tratado como aprovado até o CI e o teste real no aparelho confirmarem Agenda, Plano, Histórico e restauração.

**Conclusão:** correções de código aplicadas; 25 verificações isoladas e 1 verificação separada do feedback por bloco passaram. Build Android e validação de backup no aparelho permanecem pendentes.
