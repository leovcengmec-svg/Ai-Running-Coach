# AI Running Coach — Auditoria V94 e Plano de Correção V95

**Base analisada:** `AI-Running-Coach-V94.zip`  
**Próxima versão proposta:** VersionCode 95 · Motor interno 85 · Backup Schema 10  
**Escopo:** auditoria e revisão integral dos protocolos de treino, geração de blocos, zonas/ritmos, estimativas e exportação Pace Coach.

## 1. Resumo executivo

A revisão do código confirma problemas estruturais que explicam as oito capturas:

1. `ZoneIntensityBandEngine.applyExperiencedTransition()` usa atualmente um corte de experiência >= 6 meses para transformar aquecimento/desaquecimento em Z2 0–20%, inclusive em sessões regenerativas cuja parte principal é Z1. Isso pode deixar as transições mais rápidas que o bloco regenerativo. A V95 deve substituir essa regra genérica pela segmentação solicitada: corredor com mais de 11 meses de prática consistente faz regenerativo predominantemente em Z2 0–20% nas transições e Z2 20–50% no bloco principal; Z1 fica reservada ao iniciante em protocolo explícito de caminhada/corrida, salvo exceções justificadas de segurança/retorno.
2. A sessão de longão contínuo usa a banda padrão Z2 10–55% (`chooseBand()` para títulos com “longo”), enquanto a transição experiente usa Z2 0–20%. Há sobreposição entre 10–20% e pouca separação operacional.
3. `buildProgressionRegressionSegments()` usa apenas dois blocos Z2 quando Z3 não está liberada, com pesos de 45%/55%. Isso produz blocos muito longos como 2,3 km e 2,9 km. `normalizeProgressionBands()` também foi escrito assumindo somente duas bandas Z2.
4. `createEasy()` monta acelerações como um bloco único `4 × 0,1 km`, sem etapas de recuperação entre repetições. A instrução “recupere completamente” não possui alvo executável.
5. `buildExplicitProtocolSegments()` representa um protocolo como bloco repetido para as primeiras N−1 repetições, recuperação repetida N−1 vezes e uma última repetição separada. `PaceCoachExporter.buildWorkoutSteps()` transforma os `repeatCount` em grupos Garmin. Para 6 × 400 m, o arquivo fica compacto (aquecimento, preparação, grupo repetido, última repetição, desaquecimento) em vez de 14 etapas individuais.
6. Os validadores `TrainingPrescriptionAudit.validate()` e `TrainingProtocolCatalog.validateNamedProtocol()` existem, mas não são chamados como bloqueio obrigatório pelo fluxo de geração/exportação em produção. Os testes atuais validam contratos isolados e exemplos, mas não asseguram que toda a saída real de cada protocolo esteja estruturada bloco a bloco.
7. `WorkoutSegment` só possui `durationMin` inteiro. Isso não representa com precisão strides de 10–15 segundos ou recuperações de 60–90 segundos.

**Conclusão:** o problema não se resolve alterando apenas as sete sessões das capturas. A V95 precisa revisar o mecanismo comum que monta as sessões, atribui bandas de ritmo, expande repetições e valida o JSON exportado.

## 2. Correções específicas das capturas

### 2.1 Regenerativo — regra diferenciada por experiência (atualização solicitada)

**Observação incorporada:** não usar automaticamente Z1 para um corredor que já corre há mais de 11 meses. Para esse perfil, um regenerativo prescrito em Z1 com pace excessivamente lento (por exemplo, 8:20 min/km) pode deixar de representar uma corrida regenerativa executável para a capacidade demonstrada pelo atleta. Z1 continua apropriada para iniciantes, especialmente em protocolos estruturados de caminhada/corrida.

**Regra V95 revisada:**

- **Corredor com mais de 11 meses de prática consistente:** o regenerativo será prescrito predominantemente em Z2, não em Z1 por padrão. Usar aquecimento em **Z2 0–20%**, bloco principal regenerativo em **Z2 20–50%** e desaquecimento em **Z2 0–20%**. Os percentuais são posições dentro da faixa individual da Z2: 0% é o limite mais lento e 100% o mais rápido. A faixa do bloco principal começa acima da faixa de transição para evitar que aquecimento/desaquecimento fiquem mais rápidos que o trabalho.
- **Iniciante ou corredor em retorno sem base atual suficiente:** Z1 pode ser utilizada em um protocolo explícito de caminhada/corrida. A sessão deve indicar duração ou distância de cada trecho correndo e caminhando, com alternância executável; não pode apresentar apenas um bloco contínuo em Z1 como se fosse adequado a todos.
- **Exceções por segurança:** dor, doença, fadiga elevada, retorno após afastamento relevante ou incapacidade de manter conversa confortável podem justificar adaptação individual, caminhada ou redução da duração. A exceção deve ser explicada e não deve decorrer apenas de um pace Z1 calculado automaticamente.
- A regra anterior de converter automaticamente toda transição de atleta experiente para Z2 0–20% fica substituída por esta regra específica para regenerativos. O motor deve classificar o perfil antes de escolher a zona e as bandas.

**Nota de metodologia:** o corte de mais de 11 meses é um critério operacional solicitado para segmentar a experiência no aplicativo, não um limiar fisiológico universal demonstrado por estudos. O motor deve combiná-lo com consistência recente, interrupções, prontidão e resposta aos treinos. Não presumir que tempo de prática, isoladamente, garante tolerância a qualquer intensidade.

### 2.2 Longão contínuo e longão reduzido

**Problema:** a banda do trabalho Z2 (10–55%) sobrepõe a banda de transição Z2 (0–20%). Na semana regenerativa, a regra de redução da banda pode ampliar a sobreposição.

**Regra V95:** atribuir bandas explícitas em vez de depender de `chooseBand()` genérico. Exemplo operacional para atleta com experiência e tolerância suficientes:

- Aquecimento: Z2 0–15% (ou Z1 quando apropriado ao perfil).
- Trabalho contínuo: Z2 25–65%.
- Desaquecimento: Z2 0–15% (ou Z1, conforme perfil).

Para iniciantes e sessões de recuperação, utilizar uma faixa mais conservadora e igualmente separada, por exemplo transição 0–10% e trabalho 15–45%. Os percentuais são posições dentro da zona individual, não percentuais de VO₂máx e não novos limites fisiológicos universais. O motor deve preservar a ordem de pace e verificar que as faixas adjacentes não se sobreponham de forma material.

### 2.3 Longão progressivo

**Problema:** sem elegibilidade para Z3, a parte principal é dividida em apenas dois blocos de 45%/55% do volume principal.

**Regra V95:** usar 3 etapas por padrão, ou 4 quando o volume principal suportar blocos úteis (limite mínimo operacional recomendado de aproximadamente 0,8 km por etapa). Exemplo dentro de Z2:

1. Z2 confortável: banda inferior/intermediária.
2. Z2 moderada: banda central.
3. Z2 mais rápida: banda superior controlada.

Z3 só pode aparecer no último trecho quando critérios existentes de experiência, volume recente, maior corrida, consistência, prontidão e ausência de dor forem cumpridos. A última etapa não é sprint nem prova. Para volumes pequenos, usar 2 ou 3 blocos, nunca dividir em segmentos excessivamente curtos.

### 2.4 Longão regressivo

**Problema:** apenas dois blocos grandes e pouca gradação da regressão.

**Regra V95:** usar 3 etapas (ou 4 quando o volume suportar): começar na banda mais rápida permitida e reduzir progressivamente para as faixas centrais/confortáveis de Z2. Z3 no início só para corredores elegíveis, em trecho curto e controlado. O bloco final deverá ser claramente mais lento que o intermediário; o desaquecimento continuará mais fácil que o bloco final.

### 2.5 Rodagem com acelerações

**Problema:** `createEasy()` produz um bloco `4 × 0,1 km` com `repeatCount=4`, sem recuperações explícitas. O Pace Coach recebe a série como grupo único e não dispõe de instrução executável de recuperação entre strides.

**Estrutura solicitada para o preset V95 — 8 blocos:**

1. Aquecimento.
2. Rodagem aeróbia Z2.
3. Aceleração 1.
4. Recuperação 1.
5. Aceleração 2.
6. Recuperação 2.
7. Aceleração 3.
8. Desaquecimento.

Cada aceleração deverá ser individual, curta (por exemplo, 10–15 s ou distância equivalente), progressiva, rápida porém relaxada, sem sprint máximo e sem pace fixo obrigatório. Cada recuperação deverá ser explícita (por exemplo, 60–90 s de caminhada/trote muito leve), com duração configurada e sem depender da frase “recupere completamente”. Não há recuperação após a terceira aceleração: o desaquecimento vem em seguida. Este preset de três acelerações é uma decisão de produto solicitada, não uma regra universal para todos os corredores; iniciantes, atletas sem base suficiente, semanas regenerativas ou com dor não recebem strides automaticamente.

### 2.6 Intervalado 6 × 400 m

**Problema:** a prescrição agrega cinco repetições e cinco recuperações num grupo repetitivo, e exporta somente seis blocos. O Pace Coach deve receber uma etapa de execução por bloco.

**Estrutura V95 — 14 blocos:**

1. Aquecimento.
2. Preparação.
3. Intervalo 1 — 400 m.
4. Recuperação 1 — 2 min.
5. Intervalo 2 — 400 m.
6. Recuperação 2 — 2 min.
7. Intervalo 3 — 400 m.
8. Recuperação 3 — 2 min.
9. Intervalo 4 — 400 m.
10. Recuperação 4 — 2 min.
11. Intervalo 5 — 400 m.
12. Recuperação 5 — 2 min.
13. Intervalo 6 — 400 m.
14. Desaquecimento.

Cada repetição deverá ter `repeatCount=1` e alvo de distância exata. Cada recuperação deverá ser um bloco individual de 2 min, caminhada/trote/Z2 conforme o protocolo e capacidade do corredor. Não criar recuperação após a última repetição. Se a dose integral não couber na tolerância ou no orçamento de sessão, o motor deve selecionar uma dose menor declarada (por exemplo 4 × 400 m), atualizar o título e explicar a redução; não pode manter o título 6 × 400 m quando a dose real for menor.

## 3. Revisão integral da biblioteca — escopo obrigatório

A auditoria deve percorrer todos os itens de `TrainingTypeCatalog`, todos os códigos de `TrainingProtocolCatalog`, todos os códigos dinâmicos F01–F04/T01/CC01 e todos os estilos gerados diretamente pelo `CoachEngine`.

### Famílias e variantes a revisar

- Corrida/caminhada de iniciante e retorno após pausa.
- Regenerativo Z1.
- Rodagem contínua Z2.
- Rodagem moderada sustentada.
- Rodagem progressiva e regressiva Z2; variantes Z2–Z3 quando elegíveis.
- Longão contínuo, reduzido, progressivo e regressivo.
- Tempo Run contínuo.
- Tempo intervalado T04 (2 × 10 min) e T05 (3 × 8 min).
- Intervalado aeróbio Z2 e Z2–Z3.
- Intervalados I04–I10 (tempo/distância e recuperações de cada protocolo).
- Ritmo específico RP05/RP10/RP15/RP21.
- Fartlek F01/F02/F03/F04, incluindo alternâncias, pirâmides e recuperações.
- Strides/acelerações técnicas.
- Resistência específica de maratona e ultradistância.
- Repetições em subida: manter como condicional até existir inclinação/rota confiável; não atribuir pace plano a uma subida.
- Todos os fallbacks quando faltam teste, zona, histórico, volume, dias disponíveis ou prontidão.

Cada catálogo deve dizer claramente se o tipo é automático, condicional, complementar ou apenas referência. Nenhum tipo pode aparecer como integrado se não possuir gerador real e teste de ponta a ponta.

## 4. Regras técnicas comuns para todos os blocos

Cada `WorkoutSegment` deverá possuir, conforme o caso:

- Nome e instrução operacional inequívocos.
- Tipo de término: tempo ou distância.
- Valor exato de tempo/distância.
- Zona e faixa ativa individual quando houver corrida por pace.
- RPE complementar, nunca substituindo a faixa de pace em sessões calibradas.
- Tipo de recuperação: caminhada, trote ativo Z1/Z2 ou pausa parada.
- Identificador estável e índice sequencial.
- Distância estimada separada da distância-alvo exata quando o alvo principal for tempo.

Adicionar suporte a `durationSeconds` (ou milissegundos) no modelo de bloco, serialização, estimador de duração, interface, feedback e exportador. Isso permite representar strides de 10–15 segundos e recuperações de 60–90 segundos com precisão. Atualizar o contrato de backup para Schema 10, com leitura compatível dos schemas 1–9.

### Regras de ritmo

- Não usar sempre a borda mais lenta da zona.
- Iniciantes e corredores em retorno usam faixas conservadoras e progressão menor.
- Corredores com base consistente podem utilizar a faixa central ou superior da zona quando o propósito do treino justificar.
- Progressivos aumentam a velocidade etapa a etapa; regressivos diminuem a velocidade etapa a etapa.
- Aquecimento e desaquecimento não podem ficar mais rápidos que o primeiro/último bloco principal correspondente.
- Regenerativo de corredor com mais de 11 meses de prática consistente: Z2 0–20% no aquecimento/desaquecimento e Z2 20–50% no bloco principal; não prescrever Z1 automaticamente.
- Regenerativo de iniciante/retorno: Z1 somente em protocolo explícito de caminhada/corrida, com trechos e recuperações executáveis; não usar Z1 contínua como padrão universal.
- Recuperação entre intervalos deve ser efetivamente mais leve que o bloco de trabalho e ter duração/distância executável.
- Nenhum bloco pode ultrapassar as fronteiras calculadas das zonas individuais.
- Quando não houver calibração válida, remover ritmos numéricos antigos e usar instruções por esforço/tempo, nunca exibir pace desatualizado.

## 5. Auditoria de sequência e exportação Pace Coach

A V95 deve validar a sessão depois de gerada e novamente antes de exportar.

### Validações obrigatórias

1. Contagem dos blocos igual à sequência prevista.
2. Ordem de execução correta e sequencial.
3. Número de acelerações igual ao número de recuperações + 1, quando o protocolo não prescrever recuperação final.
4. Número de intervalos igual ao protocolo; recuperações exatamente N−1.
5. Repetições de distância mantêm a distância exata (ex.: 400 m = 0,400 km).
6. Repetições por tempo mantêm duração exata.
7. Recuperações possuem duração explícita, modo e intensidade executável.
8. Aquecimento e desaquecimento estão presentes quando exigidos pelo protocolo.
9. Soma das distâncias estimadas fecha com o total da sessão dentro da tolerância de arredondamento.
10. Faixas de pace correspondem à zona e banda ativa; progressão/regressão é monotônica.
11. Nenhum bloco de recuperação tem alvo mais rápido que o trabalho imediatamente anterior sem justificativa explícita.
12. Não existem segmentos de pace incompletos, invertidos ou fora da zona.
13. A sequência do Pace Coach contém um passo individual por bloco prescrito; sessões de intervalo e strides não podem virar grupos compactados quando a exigência é execução bloco a bloco.
14. O número de etapas do JSON exportado deve ser igual ao número de blocos executáveis exibidos na tela.

O `TrainingPrescriptionAudit` e o `TrainingProtocolCatalog.validateNamedProtocol()` devem deixar de ser usados apenas em testes isolados: a validação precisa ser chamada no fluxo de geração/salvamento e na exportação. Se a sessão falhar, o sistema deve gerar uma alternativa segura com título coerente ou impedir a exportação e mostrar o motivo. Nunca exportar silenciosamente uma sessão inválida.

## 6. Ciência e referências para orientar os critérios

As fontes sustentam os princípios de desenho, mas não estabelecem uma única distância, duração ou faixa percentual universal para todos os atletas:

- Uma revisão sistemática de 20 estudos com corredores de meio-fundo e fundo encontrou diferenças relevantes entre métodos de classificação das zonas e observou melhores resultados nos estudos com maior proporção de baixa intensidade, em abordagens piramidais/polarizadas. O artigo sugere alto volume em baixa intensidade e menor proporção em limiar/alta intensidade; isso orienta a distribuição global, não determina a prescrição individual de cada bloco. PubMed: https://pubmed.ncbi.nlm.nih.gov/34749417/
- A World Athletics informa que sessões rápidas variam conforme a prova e nível, que exemplos de intervalos usam recuperações explícitas de 2–3 min, e que sessões intensas não são introdutórias: devem ser construídas ao longo de meses e acompanhadas de recuperação. https://worldathletics.org/personal-best/performance/speed-training-endurance-runners-benefits-limits
- Uma síntese sobre características de corredores de elite descreve strides/sprints curtos (aprox. 5–15 s) com recuperação completa, e distingue intervalos de limiar, VO₂máx e tolerância ao lactato. É referência de estrutura, não prescrição automática para iniciantes. https://pmc.ncbi.nlm.nih.gov/articles/PMC8975965/
- Um estudo de 10 × 400 m com atletas de endurance treinados comparou recuperações de 60, 120 e 180 s; recuperações mais curtas elevaram o RPE. Isso demonstra que a recuperação modifica a carga interna e precisa ser explícita e adequada ao objetivo, não que exista um único intervalo obrigatório. PubMed: https://pubmed.ncbi.nlm.nih.gov/9535583/
- Um guia de progressão da Suunto descreve progressões em três partes (início fácil, transição, final planejado), podendo ter etapas de comprimentos diferentes. O final mais rápido não é automaticamente melhor: deve corresponder à meta e à capacidade atual. https://www.suunto.com/sports/News-Articles-container-page/progression-runs/

## 7. Matriz de testes de regressão V95

### Casos exatos das capturas

- Regenerativo em corredor com >11 meses de prática consistente: aquecimento Z2 0–20%, principal Z2 20–50%, desaquecimento Z2 0–20%; verificar separação das bandas e conforto.
- Regenerativo em iniciante/retorno: protocolo Z1 caminhada/corrida com cada trecho explicitamente temporizado/distanciado; nenhum bloco genérico sem instrução executável.
- Teste de fronteira: exatamente 11 meses e mais de 11 meses; verificar que o critério de produto é aplicado conforme especificação e que exceções por afastamento/prontidão são justificadas.
- Longão contínuo: trabalho Z2 sem sobreposição operacional com aquecimento/desaquecimento.
- Longão reduzido: mesma separação, com volume/intensidade compatíveis com recuperação.
- Longão progressivo: 3–4 blocos principais, pace monotonamente mais rápido, sem Z3 quando inelegível.
- Longão regressivo: 3–4 blocos principais, pace monotonamente mais lento, sem Z3 quando inelegível.
- Strides: exatamente 8 blocos (aquecimento, aeróbico, 3 acelerações, 2 recuperações, desaquecimento), com tempos individuais e sem grupo repetitivo.
- Intervalado 6 × 400 m: exatamente 14 blocos; 6 intervalos de 400 m e 5 recuperações de 2 min; exportação com 14 etapas executáveis.

### Matriz de cobertura total

Executar testes gerados para cada código/protocolo e combinações de:

- Perfil: iniciante, intermediário, experiente, avançado.
- Objetivo: completar, corrida contínua, recorde pessoal, tempo-alvo, saúde.
- Distância: 5 km, 10 km, 15 km, meia, maratona e ultradistância, onde aplicável.
- Frequência: 2, 3, 4, 5 e 6 dias.
- Fase: base, desenvolvimento, específica, regenerativa e taper.
- Zona: calibrada, parcialmente calibrada e ausente.
- Prontidão: favorável, cautela moderada, fadiga alta, dor.
- Orçamento: sessão suficiente e insuficiente para dose completa.

### Critérios de aprovação

- 100% dos protocolos ativos com estrutura válida.
- Zero recuperações vagas sem duração ou forma de execução.
- Zero blocos de aquecimento/desaquecimento mais rápidos que o estímulo principal em sessão regenerativa.
- Zero sobreposição involuntária de bandas entre transição e trabalho, salvo quando tecnicamente justificada e documentada.
- 100% das progressões/regressões monotônicas.
- 100% das sessões de intervalo exportadas com cada repetição e recuperação como etapa individual.
- JSON Pace Coach compatível e com contagem idêntica à tela.
- Nenhuma sessão concluída ou histórico alterado por migração.
- Testes Kotlin/JUnit e build APK no GitHub Actions sem erros.

## 8.1 Observação adicional incorporada — regenerativo por nível de experiência

A regra inicial da V95 que mantinha todas as sessões `RECOVERY_Z1` integralmente em Z1 foi revisada. Ela não deve ser aplicada a corredores com mais de 11 meses de prática consistente. Para esse grupo, a prescrição regenerativa padrão será Z2 0–20% nas transições e Z2 20–50% no bloco principal. Para iniciantes ou corredores em retorno sem base atual suficiente, Z1 permanece disponível por meio de protocolo caminhada/corrida, com tempos/distâncias explícitos. O critério de 11 meses é uma regra operacional de segmentação do produto, não um corte fisiológico universal; afastamento, dor, fadiga e prontidão continuam podendo modificar a decisão.

A alteração exige revisar `ZoneIntensityBandEngine.applyExperiencedTransition()` e a geração `RECOVERY_Z1` para que a zona e a banda sejam decididas pelo perfil e pela condição atual, antes de criar os blocos. Os testes devem assegurar que um atleta experiente não receba automaticamente pace Z1 excessivamente lento e que iniciantes recebam uma alternância caminhada/corrida executável.

## 9. Identificação proposta

- Aplicativo: AI Running Coach
- Versão: V95
- VersionCode: 95
- Motor interno: 85
- Backup Schema: 10
- Base: V94

A V95 deve ser entregue em um pacote único. Não deve ser considerada concluída só porque o catálogo foi alterado: a aprovação exige geração real de todas as famílias, validação dos blocos, exportação Pace Coach e execução do workflow Android.
