# Runner Intelligence V63

## Objetivo
Integrar perfil, objetivo, experiência, condição atual e dados observados sem confundir referência de treinamento com requisito fisiológico universal.

## Objetivo e intenção
O objetivo é composto por distância/categoria e intenção separada:
- Completar distância.
- Correr continuamente.
- Melhorar recorde pessoal.
- Alcançar tempo definido.
- Saúde e qualidade de vida.

A distância pode ser fixa ou personalizada entre 1 e 200 km. A intenção de saúde não seleciona automaticamente limiar, VO₂ ou sessão de alta intensidade.

## Experiência e condição atual
Experiência acumulada (meses/anos regulares) é distinta da condição atual. A condição é derivada de:
- Volume medido ou informado recente.
- Semanas ativas nas últimas quatro.
- Maior corrida em 30 dias.
- Dor, RPE, sensação e recuperação.
- Evidência de desempenho/provas.

Dados desconhecidos em perfis antigos permanecem desconhecidos. O sistema não presume consistência nem experiência e utiliza guardrails conservadores.

## Perfil fisiológico
`PhysiologicalProfileEngine` oferece:
- Estimativa de velocidade crítica de campo a partir de pelo menos três esforços ou provas recentes, sem dor, em distâncias/durações diferentes e com ajuste estatístico mínimo.
- Projeção de tempo-alvo por desempenho recente, limitada por razão de distância e explicitamente identificada como estimativa.
- Nenhuma estimativa de campo é apresentada como limiar laboratorial, VO₂máx medido ou garantia de resultado.

As cinco zonas existentes permanecem o modelo operacional do produto. A velocidade crítica e o tempo-alvo são referências complementares; não sobrescrevem zonas sem avaliação válida.

## Referência de pace da meta
A referência de pace competitivo é secundária. Só pode ser exibida em segmento específico se o pace projetado estiver dentro da faixa completa da zona daquele segmento. Se não couber na zona, não aparece para evitar prescrição contraditória.

## Limitações explícitas
- Velocidade crítica é estimativa de campo; resultados dependem da qualidade e comparabilidade dos testes.
- Projeção de tempo é exploratória, não promessa.
- O aplicativo não mede diretamente sono, HRV ou limiares laboratoriais.
- Classificações de experiência e faixas de prontidão são regras de produto e não classificação clínica ou universal.
