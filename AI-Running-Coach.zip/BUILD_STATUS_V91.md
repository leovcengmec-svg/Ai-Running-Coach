# Status de build — V91

- Base: AI Running Coach V90 Build Fix.
- `versionCode = 91` • `versionName = V91`.
- `CURRENT_ENGINE_VERSION = 80`.
- Backup Schema 6; decoder mantém leitura dos schemas 1–5.
- Correções da auditoria V90 aplicadas no source set Android.
- Harnesses Kotlin/JVM isolados de calendário, carga parcial e estimativa Cooper: aprovados.
- Testes JUnit de backup, calendário, carga e reteste foram adicionados/atualizados, mas não executados pela suíte Gradle neste ambiente.
- `:app:testDebugUnitTest`, `:app:compileDebugKotlin` e `:app:assembleDebug` continuam pendentes do GitHub Actions.
- O APK não está certificado até existir execução verde do workflow `build-apk`.

Workflow configurado: `.github/workflows/android.yml`.
