package com.airunningcoach.app

import java.time.LocalDate

fun main() {
    val base = requireNotNull(PaceCalculator.calculateCooper(2.5))
    val testDate = LocalDate.of(2026, 11, 1)
    val all = AdaptiveZoneCalibrationState(
        referenceTestDateIso = testDate.toString(),
        cumulativePercentByZone = mapOf("Z1" to 5.0, "Z2" to 5.0, "Z3" to 5.0)
    )
    check(AdaptiveZoneCalibrationEngine.cumulativePercent(all, "Z1") == 15.0)
    check(AdaptiveZoneCalibrationEngine.cumulativePercent(all, "Z2") == 10.0)
    check(AdaptiveZoneCalibrationEngine.cumulativePercent(all, "Z3") == 5.0)

    val z3Only = AdaptiveZoneCalibrationState(cumulativePercentByZone = mapOf("Z3" to 5.0))
    check(AdaptiveZoneCalibrationEngine.cumulativePercent(z3Only, "Z1") == 5.0)
    check(AdaptiveZoneCalibrationEngine.cumulativePercent(z3Only, "Z2") == 5.0)
    check(AdaptiveZoneCalibrationEngine.cumulativePercent(z3Only, "Z3") == 5.0)
    val z2Only = AdaptiveZoneCalibrationState(cumulativePercentByZone = mapOf("Z2" to 5.0))
    check(AdaptiveZoneCalibrationEngine.cumulativePercent(z2Only, "Z1") == 5.0)
    check(AdaptiveZoneCalibrationEngine.cumulativePercent(z2Only, "Z2") == 5.0)
    check(AdaptiveZoneCalibrationEngine.cumulativePercent(z2Only, "Z3") == 0.0)
    val z1Only = AdaptiveZoneCalibrationState(cumulativePercentByZone = mapOf("Z1" to 5.0))
    check(AdaptiveZoneCalibrationEngine.cumulativePercent(z1Only, "Z1") == 5.0)
    check(AdaptiveZoneCalibrationEngine.cumulativePercent(z1Only, "Z2") == 0.0)
    check(AdaptiveZoneCalibrationEngine.cumulativePercent(z1Only, "Z3") == 0.0)

    val adjusted = AdaptiveZoneCalibrationEngine.apply(base, all)
    check(adjusted.z4.range == base.z4.range && adjusted.z5.range == base.z5.range)
    check(ZoneCalibrationEngine.boundaryValues(adjusted).zipWithNext().all { (a,b) -> b-a >= 10 })

    val narrowBase = base.copy(z1 = base.z1.copy(range = PaceRange(base.z2.range.slowestPaceValue, base.z2.range.slowestPaceValue + 10)))
    val dueDate = testDate.plusDays(28)
    val range = requireNotNull(base.zone("Z1")).range
    val midpoint = (range.fastestPaceValue + range.slowestPaceValue) / 2.0
    val rows = (0 until 5).map { index ->
        AdaptiveZoneObservation(
            sessionId = "session-${index / 2}", dateIso = dueDate.minusDays(8L + index * 2L).toString(), zone = "Z1",
            actualPaceSecondsPerKm = (midpoint * 0.965).toInt(),
            targetFastestPaceSecondsPerKm = range.fastestPaceValue,
            targetSlowestPaceSecondsPerKm = range.slowestPaceValue,
            effort = "Muito leve", feeling = "Bem", painPresent = false, workoutType = "Recuperação"
        )
    }
    val state = AdaptiveZoneCalibrationEngine.resetForValidTest(AdaptiveZoneCalibrationState(), testDate.toString())
    val blocked = AdaptiveZoneCalibrationEngine.evaluate(narrowBase, rows, state, dueDate, testDate.toString())
    check(blocked.status == AdaptiveZoneCalibrationEngine.BLOCKED) { "Expected BLOCKED; got ${blocked.status}: ${blocked.explanations}" }
    check(blocked.proposals.isEmpty())

    check(SessionIdentityEngine.typesCompatible("EASY_AEROBIC_Z2_Z3_PROGRESSIVE", "Rodagem"))
    check(SessionIdentityEngine.typesCompatible("Aeróbio", "Rodagem aeróbia progressiva Z2 Z3"))
    check(SessionIdentityEngine.typesCompatible("LONG_RUN_PROGRESSIVE", "Longão"))
    check(SessionIdentityEngine.canonicalSlotKey("2026-11-18", "Aeróbio") == "2026-11-18|RODAGEM")

    val reset = AdaptiveZoneCalibrationEngine.resetForValidTest(all, testDate.plusDays(60).toString())
    check(reset.cumulativePercentByZone.values.all { it == 0.0 })
    check(reset.history == all.history)
    check(AdaptiveZoneCalibrationEngine.retestWindowStartDate(testDate.toString()) == testDate.plusDays(29))
    check(AdaptiveZoneCalibrationEngine.retestDueDate(testDate.toString()) == testDate.plusDays(29))
    println("V94 core harness: PASS")
}
