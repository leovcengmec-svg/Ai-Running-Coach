# Correção do build Android — V68

## Erro reportado

O GitHub Actions falhou em `MainActivity.kt:4373:66` com `No parameter with name 'enabled' found`.

## Causa

A chamada `SecondaryButton("Aplicar ao teste já salvo", enabled = ...)` passava um argumento nomeado não previsto pela assinatura do composable. O botão secundário não aceitava `enabled`, embora o fluxo precisasse desabilitá-lo até idade e referência fisiológica estarem válidas.

## Correção

- Adicionado `enabled: Boolean = true` à assinatura de `SecondaryButton`.
- Encaminhado `enabled = enabled` ao `OutlinedButton` do Material 3.
- Mantidos o estilo secundário e o bloqueio funcional até os dados demográficos serem válidos.
- Atualizados `versionCode/versionName` para `68/V68`; `engineVersion=53` e Backup Schema 2 mantidos.

## Validação

- Conferência estática da assinatura e da chamada: realizada.
- Atualização do appVersion no backup e teste do codec: realizada.
- Build Android/Gradle/JUnit: pendente de execução no GitHub Actions, pois o ambiente local não possui Gradle nem Android SDK.
