# AI Running Coach — Auditoria V96 e Plano de Correção V97

**Data:** 26/11/2026  
**Base analisada:** V96 — `VersionCode 96`, motor interno 86, Backup Schema 11  
**Próxima versão proposta:** V97 — `VersionCode 97`, motor interno 87, Backup Schema 12  
**Escopo:** preservação da carga semanal, feedback sem reconstrução involuntária do plano, piso de distância por sessão conforme o objetivo, distribuição dos três dias de corrida, longão, provas e integridade do calendário.
**Revisão incorporada:** observação do corredor sobre não aceitar sessões regulares abaixo de 5 km quando o objetivo é 5 km, exceto em semana Regenerativa ou no protocolo inicial caminhada/corrida.

---

## 1. Parecer executivo

A V96 ainda permite que dados parciais do histórico substituam a base declarada como entrada do motor de prescrição. Ela também permite que o plano seja reconstruído depois de um feedback, que uma prova de fim de semana substitua o longão independentemente da distância e que sessões sejam recolocadas no mesmo dia após a reaplicação de reagendamentos manuais.

O problema não é apenas visual. Os defeitos estão no fluxo de dados, nos critérios de confiança do histórico, na distribuição de volume e na ausência de uma validação final do calendário.

**Decisão recomendada:** a V97 deve preservar a base cadastrada até que exista um ciclo de quatro semanas completas, reconciliadas e explicitamente confirmado. O feedback normal deve registrar a atividade e atualizar indicadores, sem reconstruir treinos. A semana em andamento deve ser congelada. A distribuição de três dias deve reservar uma parcela real ao longão, com teto de 40% da quilometragem semanal e diferença mínima visível para a segunda maior sessão. Além disso, para objetivo de 5 km, nenhuma sessão regular de corrida em semana normal deve ter distância total inferior a 5 km; as exceções são a semana regenerativa e o protocolo inicial de caminhada/corrida.

## 2. Evidências observadas nas imagens

### Imagem 1 — Resumo do plano

- Objetivo: 5 km.
- Perfil: iniciante, três dias de corrida por semana.
- Base semanal exibida no card: **16 km**.
- Maior sessão declarada exibida no card: **10 km**.
- Duração: oito semanas.
- Texto secundário: “Referências de entrada: 12 km/semana, longão 3 km e 3 dias/semana”.
- Progressão planejada mostrada: **11,5; 16,1; 18,8; 6,7; 6,2; 9,3; 9,5; 7,1 km**.

O texto de 12 km/semana e 3 km não é o valor do cadastro. No código, ele deriva dos requisitos mínimos para liberar a fase específica do objetivo. O valor de perfil é 16 km e a maior sessão declarada é 10 km. A interface usa o rótulo ambíguo “Referências de entrada”, que dá a impressão de que a base do corredor mudou. Deve ser renomeado para **“Requisitos para liberar a fase específica”**.

### Imagem 2 — Semana 3

- Semana 3 em andamento; volume apresentado: aproximadamente **18,8 km**.
- Meta da semana: **17 km**.
- Resumo: **3 treinos + 1 prova**.
- Distribuição: leves **8,7 km**, qualidade **5,1 km**, longão **0 km**.
- Prova preparatória de 5 km no sábado, 28/11/2026.
- Treino concluído de aproximadamente 5,8 km na terça-feira, 24/11.
- Dois treinos diferentes aparecem em **quinta-feira, 26/11**: aproximadamente 5,1 km de qualidade e 2,9 km de rodagem leve.

A soma apresentada é coerente com sessões e prova: 5,8 + 5,1 + 2,9 + 5,0 = 18,8 km. Portanto, a prova entra na quilometragem planejada da semana. A tela, contudo, confirma três falhas: dois treinos no mesmo dia, quatro compromissos de corrida para uma frequência configurada em três dias e ausência de uma sessão do tipo Longo.

O volume planejado de 18,8 km excede a meta de 17 km em 1,8 km. A legenda informa que provas e alternativas escolhidas entram no gráfico e que ele representa prescrição, não distância já realizada.

## 3. Diagnóstico técnico confirmado na V96

### 3.1 O histórico passa a ser considerado confiável cedo demais

**Arquivo:** `TrainingLoadEngine.kt`  
**Fluxo relacionado:** `MainActivity.createPlan()`  
**Teste que atualmente aprova o critério:** `TrainingLoadEngineTest.kt`

A condição atual para marcar o histórico como confiável é:

- pelo menos seis atividades válidas nos últimos 28 dias; e
- atividades distribuídas por pelo menos três semanas ISO ativas.

A média é calculada como a soma dos últimos 28 dias dividida por quatro. Isso não exige quatro semanas completas, fechadas ou confirmadas. O teste automatizado atual aprova precisamente seis atividades distribuídas em apenas três semanas ativas.

No cenário relatado, 2 treinos na Semana 1 + 3 na Semana 2 + 1 na Semana 3 = **6 atividades em 3 semanas ativas**. Assim, o limiar que a V96 usa para considerar o histórico confiável pode ser atingido no começo da Semana 3, sem que quatro semanas completas tenham sido observadas.

**Consequência:** a V96 pode tratar uma amostra parcial como a nova referência do motor. Isso não altera necessariamente o texto salvo do cadastro, mas altera os valores internos usados na geração do plano.

### 3.2 O cadastro fica preservado, mas a prescrição troca de fonte

**Arquivo:** `RunnerLoadSourceResolver.kt`  
**Fluxo relacionado:** `MainActivity.createPlan()`  
**Teste atual:** `RunnerLoadSourceResolverTest.kt`

A V96 mantém os valores declarados, mas, quando `measuredHistoryReliable` é verdadeiro, escolhe `measuredWeeklyKm` e `measuredLongestKm` para `planningWeeklyKm` e `planningLongestKm`.

O teste atual documenta esse comportamento: cadastro de 16 km/10 km permanece intacto, enquanto a prescrição passa a usar 8,5 km/6,6 km se o histórico for marcado como confiável.

**Isso explica a contradição percebida:** o card continua mostrando 16 km e 10 km, mas o plano pode ser gerado usando 8,5 km e 6,6 km. A V96 resolveu a sobrescrita física dos campos de cadastro, mas não impediu a troca prematura da fonte de carga do planejamento.

### 3.3 O feedback marca o plano como desatualizado

**Arquivo:** `MainActivity.kt`, função `saveFeedback()`

Ao final de qualquer feedback, a V96 executa `needsEngineRefresh = true`. A gravação do feedback não chama sozinha `createPlan()` naquele ponto; ela salva o registro e marca o motor como necessitando atualização. A reconstrução ampla ocorre quando o fluxo de atualização/recalibração é acionado.

O problema é que o feedback comum — inclusive a conclusão normal de uma corrida — passa a sugerir que o plano deve ser recalculado. Quando a reconstrução é executada, `createPlan()` gera novamente as sessões do ciclo que ainda não foram preservadas como histórico/concluídas.

**Correção necessária:** feedback normal deve atualizar histórico, carga observada, recuperação e indicadores, mas não marcar a planilha de treinos como inválida nem reconstruir a semana em andamento.

### 3.4 A distribuição do longão não atende ao teto de 40% em todos os casos

**Arquivo:** `CoachEngine.kt`, bloco de distribuição semanal

Para três dias, a participação-alvo do longão depende do objetivo:

| Prioridade | Participação configurada na V96 |
|---|---:|
| Contínuo | **44%** |
| Completar | 40% |
| Melhorar recorde pessoal | 36% |
| Tempo-alvo | 37% |
| Padrão | 40% |

A regra de 44% para o objetivo contínuo excede o teto solicitado. Além disso, a V96 define `nonLongCap` como apenas 0,2 km abaixo do longão. Isso faz o algoritmo aceitar uma diferença muito pequena entre a maior sessão não-longão e o longão.

O teste atual de distribuição chega a permitir 42% para semanas com três ou mais sessões e 52% em alguns cenários de duas sessões ou semana regenerativa. Outro teste aceita, em determinados casos, rodagem leve com distância quase igual à do longão.

**Conclusão:** a V96 só garante que o longão seja marginalmente a maior sessão em vários casos; ela não garante que seja um longão claramente dominante nem respeita o limite universal de 40% solicitado.

### 3.5 Uma prova de sábado pode remover o longão sem comparar distâncias

**Arquivo:** `RacePlanningEngine.kt`  
**Testes atuais:** `RaceEventEngineTest.kt`

A seleção da sessão a substituir atribui prioridade ao treino na mesma data e, se a prova ocorrer no sábado ou domingo, dá prioridade ao tipo `Longo`. A regra não compara a distância da prova com a distância do longão.

Há inclusive um teste que fixa como comportamento esperado que uma prova de sábado substitua o longão de domingo.

**Consequência provável na Semana 3:** a prova preparatória de 5 km no sábado pode ter sido escolhida para substituir o longão, apesar de não ser equivalente à distância planejada para a sessão longa. A imagem confirma que a semana terminou sem sessão `Longo`; sem o backup de estado do aplicativo não é possível provar qual instância foi removida naquela execução específica.

### 3.6 O calendário não faz uma validação final suficiente após reagendamentos e provas

**Arquivos:** `PlanMigrationEngine.kt`, `RacePlanningEngine.kt` e integração em `MainActivity.createPlan()`

O fluxo reaplica datas de reagendamentos manuais às sessões regeneradas. A função de reaplicação move cada sessão, mas não resolve colisões entre datas. A mesclagem posterior identifica instâncias principalmente por identidade, data e tipo; ela não impõe uma regra global de uma sessão por dia.

No motor de provas, se uma sessão estiver protegida por reagendamento manual, o sistema pode manter a prova e as sessões existentes e apenas emitir um aviso quando o total da semana excede a frequência. O aviso não impede a agenda inválida.

**Conclusão:** o código permite a combinação de reagendamento preservado + sessão regenerada + prova, sem uma validação final que impeça duas corridas no mesmo dia ou compromissos acima da frequência. A imagem prova a colisão na quinta-feira, mas o backup seria necessário para determinar se ela veio de reagendamento manual, merge ou geração inicial.

## 4. Estudo do longão e regra proposta

### 4.1 O que o longão precisa representar no aplicativo

O longão é a sessão de maior duração/distância da semana e tem finalidade própria: acumular tempo contínuo de corrida e desenvolver a resistência aeróbia com um estímulo mais prolongado. Ele não deve ser apenas uma rodagem que recebeu um acréscimo de 200 ou 300 metros.

Em um plano de três dias, a distribuição precisa distinguir três papéis:

1. **Sessão leve:** estímulo aeróbio de menor duração, com função de construção e recuperação.
2. **Sessão de qualidade:** estímulo específico de ritmo/limiar ou qualidade aeróbia, dimensionado pela prontidão e pela fase do plano.
3. **Longão:** sessão mais longa, majoritariamente controlada por ritmo individual, sem transformar toda semana em uma sessão de intensidade alta.

Para este aplicativo, as zonas devem continuar baseadas em ritmo individualizado e percepção de esforço. Frequência cardíaca não deve ser requisito para prescrição, calibração ou validação do longão.

### 4.2 O limite de 40% deve ser tratado corretamente

Não existe evidência científica robusta que estabeleça 40% como um limite universal obrigatório para todo corredor, objetivo ou frequência semanal. Revisões sistemáticas encontraram resultados conflitantes sobre a relação entre distância semanal, frequência, intensidade e lesões; por isso, não sustentam uma percentagem única aplicável a todos os corredores.

Assim, **40% será uma regra de produto solicitada para o AI Running Coach**, não uma lei fisiológica nem uma garantia clínica. Ela é um teto conservador e verificável para a distribuição do plano de três dias.

Regra proposta:

- longão-alvo: aproximadamente **35% a 40%** do volume semanal planejado, ajustado à tolerância e à fase;
- teto absoluto: **40%** do volume semanal de corrida planejado;
- a quilometragem da prova conta no total semanal quando a prova está programada como compromisso de corrida;
- a prova só pode ser classificada como substituta do longão se realmente cumprir o papel de sessão longa segundo a distância/tolerância e a intenção competitiva; uma prova preparatória curta não substitui automaticamente o longão.

### 4.3 O longão precisa ser claramente maior

A regra atual de diferença de 0,2 km é insuficiente. Proposta para semanas normais com três sessões:

- longão deve ser a maior sessão de treinamento da semana;
- deve superar a segunda maior sessão em pelo menos **0,8 km**; e
- deve ser pelo menos **15% maior** que a segunda maior sessão;
- ambas as condições devem ser atendidas quando a distribuição e o volume total permitirem.

Esses números são critérios de qualidade do algoritmo, não limiares médicos publicados. Servem para impedir resultados como 6,5 km contra 6,8 km (que sequer deixam o longão como maior) ou diferenças residuais de 200–300 metros.

Exemplo ilustrativo com objetivo de 5 km, base semanal de 16 km e três sessões:

| Sessão | Distância total | Participação |
|---|---:|---:|
| Longão | 6,0 km | 37,5% |
| Rodagem leve | 5,0 km | 31,25% |
| Qualidade (aquecimento + blocos + recuperações + desaquecimento) | 5,0 km | 31,25% |
| **Total** | **16,0 km** | **100%** |

Este exemplo respeita o piso de 5 km por sessão, mantém o longão como a maior sessão, deixa 1 km de diferença em relação às outras sessões e mantém o longão abaixo do teto de 40%. O bloco intenso do treino de qualidade pode ser menor que 5 km; o que precisa atingir pelo menos 5 km é a sessão completa, somando aquecimento, partes de trabalho, recuperações e desaquecimento.

Se não houver uma distribuição que atenda simultaneamente ao teto de 40%, à dominância do longão, à diferença mínima e ao piso de distância de cada sessão, o algoritmo não deve esconder o problema elevando artificialmente outras sessões nem reduzir o total para menos que a soma dos pisos obrigatórios. Deve sinalizar que não existe distribuição válida e propor uma revisão explícita da meta semanal, frequência ou estrutura do bloco, sem publicar uma sessão curta como treino regular.

### 4.4 Distância mínima das sessões conforme o objetivo de prova

Foi acrescentada uma regra de prescrição solicitada pelo corredor: **quando o objetivo principal for 5 km, as sessões regulares de corrida em semanas normais não devem ser prescritas com distância total inferior a 5 km**. Uma sessão de qualidade completa com 4,4 km, por exemplo, não é adequada para esse perfil apenas porque os blocos intensos somam uma distância menor.

Regras para o motor:

1. Em semanas normais, cada sessão regular de corrida deve ter pelo menos a distância do objetivo selecionado. Para objetivo de 5 km, o piso é 5 km por sessão.
2. O piso se refere à distância total da sessão: aquecimento, blocos de trabalho, intervalos/recuperações e desaquecimento. Não exige que o bloco de intensidade isoladamente tenha 5 km.
3. A exceção é a semana identificada como **Regenerativa**, na qual a redução planejada pode gerar sessões abaixo de 5 km.
4. A segunda exceção é o protocolo inicial de **caminhada e corrida**, quando o corredor ainda está na etapa de iniciação run-walk. Essa exceção depende do protocolo efetivamente prescrito, não apenas do rótulo genérico “Iniciante” no perfil.
5. Testes e avaliações específicas devem permanecer identificados como teste, e não ser classificados como uma sessão regular curta para contornar o piso.
6. O piso não autoriza aumentar a carga de forma insegura: a sessão ainda precisa respeitar a base declarada, a maior sessão cadastrada, a progressão tolerável e os sinais de recuperação. Se as restrições entrarem em conflito, o motor deve explicar que não há distribuição válida e propor ajuste do volume/frequência ou da estrutura do bloco; não deve criar silenciosamente uma sessão regular abaixo do piso.
7. O longão continua sendo a maior sessão, limitado a 40% do volume semanal e com diferença perceptível para a segunda maior sessão. O piso de 5 km não substitui nem enfraquece as regras específicas do longão.

A regra deve ser parametrizada pelo objetivo de prova. O presente plano define explicitamente o comportamento para objetivo de 5 km; objetivos de 10 km, meia maratona e maratona devem usar seus próprios critérios de adequação e não herdar automaticamente o piso de 5 km.

### 4.5 Progressão e tolerância individual

A distribuição semanal não pode ser o único limitador. O longão deve respeitar:

- maior corrida efetivamente realizada em período recente, quando o histórico for completo e confirmado;
- maior sessão declarada no cadastro enquanto o histórico não estiver reconciliado;
- evolução do longão no próprio ciclo, evitando saltos abruptos;
- fadiga, dor, recuperação, fase regenerativa e proximidade de prova;
- descanso entre qualidade e longão.

Uma coorte de 5.205 corredores acompanhados por até 18 meses encontrou maior taxa de lesões por sobrecarga quando uma sessão isolada ultrapassava em mais de 10% a maior distância corrida nos 30 dias anteriores. O estudo não demonstra que 10% seja uma margem universalmente segura, e os dados de lesão eram autorrelatados; ele reforça a necessidade de controlar saltos em uma sessão, não apenas a soma semanal. O app deve usar isso como sinal de alerta/revisão e não como substituto de uma avaliação individual. Fonte: estudo publicado no *British Journal of Sports Medicine* em 2025. (DOI: 10.1136/bjsports-2024-109380.)

### 4.6 Semanas regenerativas e semanas com prova

- Semana regenerativa pode reduzir a distância do longão, mas deve manter a sessão identificada como `Longo`/`Longão regenerativo` quando houver longão prescrito.
- A redução deve ser explícita, com motivo, e não aparecer como `Longão 0 km` sem explicação.
- Uma prova preparatória de 5 km não deve apagar automaticamente um longão maior.
- Quando a prova substituir uma sessão, a semana deve manter o limite de compromissos compatível com a frequência.
- Se uma prova-alvo realmente substituir o longão, o card deve dizer **“Prova substitui longão nesta semana”**, apresentar o motivo e contabilizar a distância uma única vez.
- Se a prova e o longão não couberem com recuperação adequada, o plano deve reduzir/suprimir outra sessão ou classificar explicitamente a semana como exceção; não deve simplesmente apagar o longão silenciosamente.

### 4.7 Limite matemático em planos de apenas dois dias

Com apenas duas sessões, não é possível ao mesmo tempo distribuir todo o volume entre as duas, fazer o longão ser a maior sessão e limitá-lo a no máximo 40% do total semanal. Para dois dias, a V97 deve declarar a incompatibilidade e não burlar a regra. As alternativas são reduzir a quilometragem semanal prescrita ou solicitar ao corredor uma terceira disponibilidade semanal. Esse conflito não se aplica ao perfil mostrado nas imagens, que informa três dias por semana.

## 5. Plano de correção V97

### PRIORIDADE 0 — Congelar a semana em andamento

1. Ao salvar feedback, atualizar o registro de atividade, conclusão, percepção de esforço, dor, ritmo e indicadores de recuperação.
2. Não reconstruir o plano e não alterar a distância, tipo ou data das sessões restantes da semana atual.
3. Remover a marcação genérica de plano desatualizado para feedback comum.
4. Manter estados separados para: feedback salvo, alerta de dor, zonas recalibradas e necessidade de revisão explícita do plano.
5. Se houver dor, gerar aviso de segurança e impedir progressão automática de intensidade/carga; não reorganizar silenciosamente todo o calendário.
6. Se uma calibração de ritmo for confirmada, oferecer uma ação separada para aplicar as novas zonas somente às sessões futuras elegíveis.

### PRIORIDADE 1 — Corrigir a confiabilidade do histórico

1. Manter `averageWeeklyKmLast28Days` como indicador descritivo, sem promovê-lo automaticamente a base de prescrição.
2. Exigir **quatro semanas completas e fechadas** de histórico reconciliado para propor substituição da base declarada.
3. Uma semana só pode ser considerada reconciliada quando as sessões previstas estiverem marcadas como concluídas/não realizadas e o corredor confirmar que as corridas externas/importadas relevantes também foram incluídas.
4. O cálculo das quatro semanas deve usar quatro semanas completas, não uma janela que contenha uma semana atual parcial e seja dividida por quatro.
5. A média medida deve ser mostrada ao lado da base declarada, sem sobrescrevê-la.
6. Só adotar a média medida como nova referência de planejamento após confirmação explícita do corredor. A alteração deve valer a partir do próximo bloco/semana elegível, nunca retroativamente na semana atual.
7. Enquanto não houver quatro semanas confirmadas, usar 16 km/semana e 10 km de maior sessão declarada como referências do plano, ressalvados alertas de segurança individualizados e claramente explicados.

**Ajuste de teste obrigatório:** substituir o teste atual que considera seis atividades em três semanas suficientes. Um histórico de 2 + 3 + 1 atividades distribuídas em três semanas não pode liberar troca automática da base.

### PRIORIDADE 2 — Recalcular somente mediante decisão explícita

1. Separar `feedbackSaved`, `readinessChanged`, `paceCalibrationPending` e `planRevisionPending`.
2. Feedback sem dor ou alteração de zonas apenas atualiza os dados observados; não cria `planRevisionPending`.
3. Adicionar uma ação explícita como **“Revisar próximo bloco”**.
4. A revisão deve mostrar uma comparação antes/depois: volume semanal, longão, sessões afetadas, prova e datas.
5. Por padrão, preservar integralmente semanas passadas e a semana em andamento. A nova prescrição começa na próxima semana/bloco permitido.
6. Sessões futuras já concluídas, reagendadas manualmente ou vinculadas a compromissos confirmados devem ser preservadas; conflitos devem ser apresentados, não resolvidos com duplicação.
7. Não recalcular o plano inteiro por causa de uma única atividade registrada.

### PRIORIDADE 3 — Reescrever a distribuição do longão e o piso de distância por sessão

1. Remover a exceção de 44% para planos de três dias.
2. Aplicar teto universal de 40% do total semanal de corrida planejado, incluindo prova quando ela for um compromisso de corrida na mesma semana.
3. Usar faixa-alvo de 35–40% quando compatível com a tolerância e fase.
4. Exigir diferença mínima de 0,8 km e 15% sobre a segunda maior sessão, quando matematicamente viável.
5. Eliminar o cap `longKm - 0.2` como critério suficiente de dominância.
6. Para objetivo de 5 km, exigir distância total mínima de 5 km em cada sessão regular de corrida nas semanas normais.
7. Calcular a distância total da sessão somando aquecimento, blocos, recuperações e desaquecimento. Um bloco de qualidade pode ter menos de 5 km, mas a sessão completa não pode ficar abaixo do piso.
8. Permitir sessões regulares abaixo de 5 km somente na semana Regenerativa ou quando estiver ativo o protocolo inicial de caminhada/corrida. A condição “Iniciante” sozinha não concede a exceção.
9. Resolver o total semanal como um problema de distribuição com restrições: volume da semana, frequência, piso por sessão conforme objetivo, teto percentual, maior sessão, diferença mínima, disponibilidade e limites de tolerância.
10. Se não houver solução que respeite as regras, não publicar uma sessão regular abaixo do piso como se fosse normal. Sinalizar a incompatibilidade e propor ajuste explícito de volume, frequência ou estrutura do bloco, sem forçar carga insegura.
11. Manter o longão predominantemente aeróbio, por ritmo individual e sensação de esforço; progressões controladas só entram quando a prontidão permitir.
12. Em semanas regenerativas, reduzir a distância e manter a identificação da sessão longa quando ela continuar prescrita.

### PRIORIDADE 4 — Corrigir substituição por prova

1. Não substituir longão somente porque a prova ocorre no sábado/domingo.
2. Priorizar substituição da sessão de qualidade ou de outra sessão compatível, considerando data, intensidade, recuperação e objetivo da semana.
3. Uma prova curta de 5 km não substitui automaticamente um longão de distância claramente superior.
4. Prova só pode ser tratada como substituta do longão quando a distância e a carga forem compatíveis com o estímulo planejado e a estratégia competitiva autorizar isso.
5. Quando a prova substituir o longão, registrar a equivalência no tipo/descrição da semana e contabilizar a distância apenas uma vez.
6. Provas devem entrar no limite semanal de compromissos, em vez de serem acrescentadas a uma semana já cheia.

### PRIORIDADE 5 — Validar a agenda depois de todas as transformações

Executar uma validação final obrigatória depois de:

- geração do plano;
- reaplicação de datas manuais;
- ajuste por prova;
- escolha de treino alternativo;
- migração/merge de sessões;
- restauração de backup.

Invariantes:

1. No máximo uma sessão de corrida por data, salvo se o corredor habilitar expressamente treino duplo.
2. Nenhuma sessão de corrida e prova em datas duplicadas.
3. Total de compromissos de corrida na semana não pode exceder a frequência configurada sem uma autorização explícita.
4. O calendário não pode deixar a sessão de qualidade e o longão em dias consecutivos quando a regra de recuperação exigir intervalo.
5. Uma data manual não pode ser reaplicada sem validação de conflito.
6. Se um conflito não puder ser resolvido sem violar a escolha do corredor, o app deve manter o plano anterior e pedir uma decisão; não deve publicar a agenda inválida.
7. A semana em andamento deve manter sua fotografia de sessões, mesmo depois do feedback.

### PRIORIDADE 6 — Corrigir os indicadores e rótulos da interface

1. Trocar “Referências de entrada” por “Requisitos para liberar a fase específica”.
2. Mostrar em linhas separadas: base declarada, maior sessão declarada, média medida (28 dias), maior corrida medida (30 dias) e estado de confiabilidade do histórico.
3. Identificar o gráfico como quilometragem **prescrita**, incluindo prova e alternativa escolhida; mostrar o valor de treinos e provas separadamente no detalhe semanal.
4. O card deve sinalizar quando a semana exceder a meta semanal e explicar quanto vem da prova.
5. Se o longão for removido por uma exceção explícita, apresentar o motivo; semanas regulares não devem exibir Longão 0 km.
6. Exibir distintamente semana com treino duplo autorizado, em vez de permitir dois treinos no mesmo dia por acidente.
7. Em objetivo de 5 km, identificar visualmente qualquer sessão regular abaixo de 5 km como incompatibilidade de prescrição; não tratar a semana Regenerativa ou o protocolo inicial caminhada/corrida como erro quando a exceção estiver corretamente identificada.

## 6. Migração e versionamento

| Item | V97 proposta |
|---|---|
| Aplicativo | AI Running Coach |
| Base | V96 |
| VersionCode | 97 |
| Motor interno | 87 |
| Backup Schema | 12 |
| Compatibilidade | leitura dos schemas 1–11 |

Schema 12 deve adicionar, de forma opcional e retrocompatível, metadados para:

- estado de reconciliação das quatro semanas;
- data de fechamento/confirmação de cada semana;
- origem da base adotada (`DECLARED` ou `MEASURED_ACCEPTED`);
- valores medidos aceitos pelo corredor, quando houver;
- data a partir da qual a nova base passa a valer;
- versão/identificador da revisão de plano confirmada.

A restauração de backups antigos deve manter os valores declarados presentes no arquivo. Campos novos ausentes devem ser migrados para estado conservador: base declarada preservada, histórico não reconciliado e nenhuma revisão automática pendente. A migração não pode deduzir que um histórico antigo está completo apenas por conter seis atividades.

## 7. Testes obrigatórios de aprovação

### Fonte de carga

- Cadastro de 16 km/semana e maior sessão de 10 km permanece inalterado após feedback, recalibração, fechamento e reabertura do app.
- Com 2 + 3 + 1 atividades em três semanas, a média medida aparece como informação, mas não vira a base do plano.
- Seis atividades em três semanas ISO não liberam a troca da base.
- Três semanas e seis atividades + uma semana parcial também não liberam a troca.
- Somente quatro semanas completas e reconciliadas podem propor adoção da média medida.
- A adoção da média medida exige confirmação explícita e passa a valer apenas no próximo bloco.
- Importar/restaurar backup não altera os valores declarados nem a decisão de origem da carga.

### Feedback e preservação da semana

- Registrar feedback do primeiro treino da Semana 3 não altera nenhuma distância, tipo ou data dos treinos restantes da Semana 3.
- Registrar feedback sem dor não marca o plano inteiro para reconstrução.
- Atualização de indicadores de recuperação não altera a prescrição salva.
- Dor gera alerta/limite de segurança sem deslocar sessões silenciosamente.
- Calibração de ritmo confirmada oferece revisão isolada das sessões futuras; semana atual e histórico permanecem intactos.

### Longão e distância mínima por sessão

- Em toda semana regular de três sessões, existe exatamente uma sessão `Longo`.
- O longão nunca ultrapassa 40% do volume semanal planejado, incluindo provas.
- O longão é maior que a segunda maior sessão por pelo menos 0,8 km e 15%, quando viável.
- Se não for viável respeitar as restrições, o motor sinaliza incompatibilidade e solicita ajuste explícito da meta semanal/frequência/estrutura; não pode violar o piso de distância por sessão nem reduzir o total abaixo da soma desses pisos para simular uma solução.
- Nenhuma semana regular mostra `Longão 0 km`.
- Semana regenerativa reduz a dose, mas preserva o papel/identificação da sessão quando prescrita.
- Para objetivo de 5 km, nenhuma sessão regular completa em semana normal fica abaixo de 5 km.
- Uma sessão de qualidade com distância total de 4,4 km deve falhar no teste para objetivo de 5 km, mesmo que seja apresentada como treino de qualidade.
- Uma sessão cujo bloco intenso tenha menos de 5 km, mas cuja soma de aquecimento, blocos, recuperações e desaquecimento seja pelo menos 5 km, deve passar.
- Sessões abaixo de 5 km são aceitas quando a semana está explicitamente marcada como Regenerativa.
- Sessões abaixo de 5 km são aceitas durante o protocolo inicial de caminhada/corrida; o rótulo “Iniciante” sem esse protocolo ativo não libera a exceção.
- Longão não excede abruptamente a maior corrida recente confiável; progressões de sessão são sinalizadas para revisão.

### Provas e calendário

- Prova preparatória de 5 km no sábado não apaga automaticamente um longão maior.
- Prova que substitui sessão conta como um dos compromissos semanais.
- Com frequência de três dias, o plano não publica quatro compromissos ou dois treinos na mesma data.
- Reaplicação de reagendamento manual não pode criar colisão.
- Alternativas de treino não duplicam sessões nem elevam a frequência por engano.
- Backup restaurado preserva identidade, data, tipo e status das sessões sem duplicar o calendário.

### Build e distribuição

- Executar toda a suíte JUnit/Kotlin.
- Executar testes Compose/UI dos cards de semana e gráfico.
- Compilar APK debug e release.
- Executar o workflow do GitHub Actions e anexar o resultado verificável do build.
- Fazer teste de instalação/abertura, feedback, encerramento/reabertura e restauração de backup em Android 16.

## 8. Critério de aceite do caso apresentado

Com o perfil declarado de 16 km semanais, maior sessão de 10 km e três dias por semana:

1. O feedback do treino de terça-feira da Semana 3 não recalcula os treinos de quinta-feira nem desloca qualquer outra sessão.
2. A semana atual mantém sua fotografia de planejamento e não recebe um segundo treino na quinta-feira.
3. A prova preparatória de 5 km é contabilizada dentro da frequência semanal e não remove o longão por padrão.
4. A Semana 3 tem um longão prescrito ou uma exceção explícita e justificada; não pode ficar em 0 km silenciosamente.
5. O volume semanal e a distribuição são calculados a partir da base declarada até que quatro semanas completas tenham sido reconciliadas e o corredor aceite eventual mudança.
6. O longão não ultrapassa 40% do volume semanal e tem diferença visível em relação à segunda maior sessão.
7. Como o objetivo é 5 km, nenhuma sessão regular completa da Semana 3 ou de outra semana normal pode ter menos de 5 km; uma sessão de qualidade de 4,4 km deve ser rejeitada.
8. A exceção abaixo de 5 km só pode ocorrer em semana Regenerativa ou com o protocolo inicial de caminhada/corrida explicitamente ativo.

## 9. Limites desta auditoria

A análise foi realizada sobre o código-fonte da V96 e as duas capturas de tela fornecidas. Não foi fornecido backup/exportação do estado atual do aplicativo. Por isso:

- a causa estrutural que permite duas sessões na mesma data está confirmada no fluxo de reagendamento/merge, mas não é possível identificar qual registro específico originou a colisão da quinta-feira sem o estado salvo;
- a lógica de prova de fim de semana pode remover longão sem comparar distâncias, e isso é compatível com `Longão 0 km`, mas o histórico de transformação daquela sessão não está no print;
- a possibilidade de troca precoce da fonte de carga é confirmada pelo critério e pelo teste existentes; para afirmar os valores numéricos exatos usados na geração daquela Semana 3 seria necessário o snapshot/backup do app no momento da recalibração.

A auditoria de código confirma que a V96 ainda permite os defeitos descritos; não confirma que cada uma das três falhas tenha uma única origem em runtime.

## 10. Referências externas usadas no estudo

1. **Frandsen et al./coorte de 5.205 corredores (2025), British Journal of Sports Medicine.** “How much running is too much? Identifying high-risk running sessions in a 5200-person cohort study.” A análise observou associação entre aumento da distância de uma sessão isolada acima da maior sessão dos 30 dias anteriores e maior taxa de lesões por sobrecarga. Não estabelece um limite universal seguro de 10%; o desenho é observacional e o desfecho foi autorrelatado. DOI: [10.1136/bjsports-2024-109380](https://doi.org/10.1136/bjsports-2024-109380). PubMed: https://pubmed.ncbi.nlm.nih.gov/40623829/.
2. **Systematic Review (2022).** “The Association Between Running Injuries and Training Parameters.” Incluiu 36 estudos e 23.047 corredores; encontrou evidência conflitante para distância semanal, duração, frequência, intensidade e mudanças recentes, não sustentando um percentual único universal. https://pubmed.ncbi.nlm.nih.gov/34478518/.
3. **Knopp et al. (2024), Sports Medicine - Open.** “Quantitative Analysis of 92 12-Week Sub-elite Marathon Training Plans.” Analisou 92 planos recomendados para corredores sub-elite, mas não mediu eficácia desses planos. É útil como descrição de prática, não como prova de que uma proporção específica de longão causa melhores resultados. DOI: [10.1186/s40798-024-00717-5](https://doi.org/10.1186/s40798-024-00717-5). Texto integral: https://pmc.ncbi.nlm.nih.gov/articles/PMC11065819/.

---

**Observação incorporada após a auditoria:** para objetivo de 5 km, sessões regulares completas abaixo de 5 km não são aceitas em semanas normais. O exemplo de distribuição foi corrigido para 6 km + 5 km + 5 km; a exceção fica restrita à semana Regenerativa e ao protocolo inicial de caminhada/corrida.

**Parecer final:** não recomendo apenas ajustar o gráfico ou aumentar alguns quilômetros do longão. A V97 precisa corrigir a regra que promove histórico incompleto a base do plano, interromper a reconstrução automática após feedback, impedir que provas curtas apaguem a sessão longa e validar o calendário depois de todas as transformações. Sem essas quatro correções estruturais, uma alteração isolada na distribuição de quilômetros poderá voltar a ser perdida na próxima atualização do planejamento.
