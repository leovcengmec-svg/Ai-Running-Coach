# Build status — AI Running Coach V104

- VersionCode: `104`
- VersionName: `V104`
- Motor interno: `94`
- Backup Schema: `16` (leitura compatível dos schemas `1–16`)
- Fonte Android principal: `android/app/src/main/java/com/airunningcoach/app/`

## Situação

O código-fonte V104 e a documentação foram atualizados a partir do ZIP da V103. O pacote preserva o workflow Android. Não foi possível gerar APK nesta sessão porque o ambiente não possui Gradle nem Android SDK e o ZIP não contém `gradlew`/Gradle Wrapper.

## Workflow CI

O workflow `.github/workflows/android.yml` configura JDK 21, Android SDK platform 37 e Gradle 9.6.0 e executa:

```bash
gradle -p android :app:testDebugUnitTest :app:assembleDebug --no-daemon
```

O APK somente deverá ser considerado pronto quando esse job terminar com sucesso e publicar o artefato.

## Validação local

- `AdaptiveZoneCalibrationEngine.kt` real compilado com `kotlinc`.
- Harness focado: 4/4 verificações integradas aprovadas.
- `AdaptiveZoneCalibrationEngineTest.kt`: 22/22 métodos executados com shim JUnit local e stubs mínimos de domínio; não é execução oficial Gradle/JUnit.
- A suíte oficial Android/Compose, o APK e a instalação no aparelho continuam pendentes.
