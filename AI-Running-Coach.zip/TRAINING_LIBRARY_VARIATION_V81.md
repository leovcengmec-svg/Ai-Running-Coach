# Biblioteca e variedade de sessões — V81

## Princípio
A biblioteca deve variar o formato do estímulo sem trocar sua finalidade fisiológica. A escolha continua condicionada por objetivo, fase, zonas de ritmo individuais, volume recente, experiência, recuperação, dor e disponibilidade. RPE e controle respiratório são referências complementares; o aplicativo não depende de frequência cardíaca.

## Variações já existentes e preservadas
- Intervalados por tempo: 4 × 3 min e outros formatos do catálogo.
- Intervalados por distância: 6 × 400 m, 4 × 800 m, 5 × 600 m, 5 × 800 m, 3 × 1.000 m e 3 × 1.600 m.
- Tempo/limiar: 2 × 10 min e 3 × 8 min, com Z3/Z4 estimada liberada somente quando elegível.
- Fartlek: aeróbio Z2–Z3, variável Z2–Z3, controlado Z3–Z4 e piramidal para perfil elegível.
- Rodagens progressivas/regressivas, longões contínuos e específicos.

## V81: seleção determinística de formato
A seleção de F01/F04 é determinística e depende da intenção do plano e da presença de dados de prontidão, sem sorteio:
- Em objetivo de recorde pessoal, na primeira ocorrência de BASE, o motor seleciona F04 quando `recoveryScore` e `fatigueScore` estão ambos preenchidos; sem esse par de dados, usa F01 como formato-base.
- Na segunda posição do ciclo de BASE, o motor pode selecionar F04.
- Em objetivo de tempo-alvo, a primeira ocorrência de BASE seleciona F01; a seguinte pode selecionar CC01 para manter um estímulo aeróbio distinto.
- O código do protocolo é escolhido novamente nas fases de desenvolvimento e específica conforme carga, recuperação, consistência, zona calibrada e objetivo. Para 5 km, I05 é usado na posição específica de limiar para não repetir I07 do desenvolvimento; F03 continua condicionado à elegibilidade VO₂.
- F04 só contém toque Z4 quando `thresholdEligible` é verdadeiro. Sem essa elegibilidade, mantém blocos aeróbios Z2/Z3, sem Z4/Z5.

A seleção é reproduzível e não aleatória. Ela varia o desenho sem aumentar automaticamente a intensidade máxima nem o volume. A presença de feedback de recuperação/fadiga pode mudar o formato escolhido, mas não libera intensidade acima dos gates do motor.

## Como o corredor deve interpretar
1. Leia o objetivo da sessão antes de iniciar.
2. Execute os blocos na ordem exibida.
3. Respeite a duração/distância de cada bloco e a faixa de ritmo mostrada.
4. Nas recuperações, permaneça na faixa indicada; só inicie o próximo estímulo quando a respiração estiver controlada.
5. Se houver dor, perda de técnica ou esforço acima do previsto, reduza ou interrompa o bloco e registre feedback.

## Segurança e limites
- Z4 é estimada, não equivale a limiar laboratorial medido.
- Z5 é estimada e não confirma VO₂máx medido.
- Fartlek aeróbio não deve ser promovido a treino intenso apenas porque o corredor correu uma sessão recente mais rápida.
- A biblioteca não pode comprimir intervalos em doses pequenas demais; nesse caso, usa alternativa aeróbia coerente e remove o título de qualidade incompatível.
