# Biblioteca e variedade de sessões — V81

## Princípio
A biblioteca deve variar o formato do estímulo sem trocar sua finalidade fisiológica. A escolha continua condicionada por objetivo, fase, zonas de ritmo individuais, volume recente, experiência, recuperação, dor e disponibilidade. RPE e controle respiratório são referências complementares; o aplicativo não depende de frequência cardíaca.

## Variações já existentes e preservadas
- Intervalados por tempo: 4 × 3 min e outros formatos do catálogo.
- Intervalados por distância: 6 × 400 m, 4 × 800 m, 5 × 600 m, 5 × 800 m, 3 × 1.000 m e 3 × 1.600 m.
- Tempo/limiar: 2 × 10 min e 3 × 8 min, com Z3/Z4 estimada liberada somente quando elegível.
- Fartlek: aeróbio Z2–Z3, variável Z2–Z3, controlado Z3–Z4 e piramidal para perfil elegível.
- Rodagens progressivas/regressivas, longões contínuos e específicos.

## Novidade V81: rotação de formato
F01 e F04 agora alternam dois desenhos de blocos entre ciclos de quatro semanas, mantendo a mesma faixa máxima de intensidade e os mesmos critérios de elegibilidade:
- F01: alterna blocos aeróbios mais longos com duas entradas moderadas e formato de pequenas ondas Z2/Z3.
- F04: para atletas elegíveis ao limiar, alterna progressão Z2→Z3→toque curto Z4 com formato Z2→Z3→Z4 curto→retorno Z3→Z2. Para quem ainda não é elegível, alterna ondas curtas Z2/Z3 sem Z4.

A rotação é determinística, não aleatória: facilita auditoria, reprodução do plano e comparação de feedbacks. A variação não aumenta a intensidade máxima nem o volume de forma automática.

## Como o corredor deve interpretar
1. Leia o objetivo da sessão antes de iniciar.
2. Execute os blocos na ordem exibida.
3. Respeite a duração/distância de cada bloco e a faixa de ritmo mostrada.
4. Nas recuperações, permaneça na faixa indicada; só inicie o próximo estímulo quando a respiração estiver controlada.
5. Se houver dor, perda de técnica ou esforço acima do previsto, reduza ou interrompa o bloco e registre feedback.

## Segurança e limites
- Z4 é estimada, não equivale a limiar laboratorial medido.
- Z5 é estimada e não confirma VO₂máx medido.
- Fartlek aeróbio não deve ser promovido a treino intenso apenas porque o corredor correu uma sessão recente mais rápida.
- A biblioteca não pode comprimir intervalos em doses pequenas demais; nesse caso, usa alternativa aeróbia coerente e remove o título de qualidade incompatível.
