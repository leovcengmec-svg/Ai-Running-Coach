# Build Status — AI Running Coach V96

- Base: AI Running Coach V95.
- `versionCode = 96`; `versionName = V96`.
- `CURRENT_ENGINE_VERSION = 86`.
- Backup Schema 11; leitura compatível dos schemas 1–10.
- Reteste futuro mantém protocolo em aberto e só é materializado após a escolha de Cooper 12 min ou 3 km no dia da sessão.
- Cadastro de volume semanal e maior sessão preservado; medições do histórico ficam separadas.
- Calibração exige estado pendente e confirmação; ações não aparecem apenas por existirem treinos.
- Testes de regressão adicionados para os três problemas da auditoria V95.
- Harness Kotlin/JVM focado dos motores alterados: **PASS**; cobertura e limite descritos em `TEST_REPORT_V96.md`.

## Validação de build
- Compilação Android/Compose, suíte JUnit/Gradle e APK: **pendentes**.
- Gradle e Android SDK não estão instalados neste ambiente, então não foi possível certificar a compilação local.
- O workflow `.github/workflows/android.yml` executa `gradle -p android :app:testDebugUnitTest :app:assembleDebug --no-daemon` no GitHub Actions e publica o APK de debug.
