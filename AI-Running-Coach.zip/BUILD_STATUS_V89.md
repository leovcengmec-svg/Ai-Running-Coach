# Build status — AI Running Coach V89

- Aplicativo: AI Running Coach
- Base: V88
- `versionCode = 89`
- `versionName = V89`
- `CURRENT_ENGINE_VERSION = 78`
- Backup Schema 4; compatibilidade de leitura dos schemas 1–4 preservada.

## Estado da implementação

Pacote V89 integrado na base ativa Android:
- Motor de calibração adaptativa Z1–Z3 com limiar mínimo de 2%, teto de 3% por revisão e teto acumulado de 5% entre testes válidos.
- Revisão a cada 28 dias, prévia explicada, confirmação explícita, validação contra evidência atual e histórico de calibrações aceitas.
- Z4/Z5 mantidas vinculadas ao teste fisiológico; continuidade das fronteiras preservada.
- Monitor de pace com recuperação de pace por tempo/distância e explicação das exclusões.
- Contadores separados de feedbacks, sessões, atividades medidas e blocos.
- Médias de volume de 28/42 dias com critérios de amostra e contagem visível.
- Reteste da semana 8 substituindo sessão intensa elegível.
- Persistência adaptativa sem alterar o schema de backup; backups legados seguem aceitos.

## Validação

- Harness Kotlin/JVM focalizado dos motores de domínio: aprovado (ver `TEST_REPORT_V89.md`).
- Testes JUnit adicionados/atualizados: presentes no código-fonte, mas ainda não executados pela suíte Gradle oficial.
- Build Android/Compose: pendente de GitHub Actions.
- APK: não gerado nem certificado nesta entrega.

## Como concluir o build oficial

1. Enviar o conteúdo integral deste ZIP ao repositório, mantendo os diretórios.
2. Executar o workflow **build-apk** em GitHub Actions (push para `main` ou `workflow_dispatch`).
3. Confirmar que `:app:testDebugUnitTest` e `:app:assembleDebug` terminam com sucesso.
4. Baixar o artifact `ai-running-coach-debug-apk`.

O workflow de release pode ser executado separadamente por `workflow_dispatch`; ele gera um APK release sem assinatura configurada no projeto.
