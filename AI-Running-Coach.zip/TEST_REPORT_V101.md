# Test Report — AI Running Coach V101

**Base:** V100 · **VersionCode:** 101 · **Motor:** 91 · **Backup Schema:** 14

## Execução local concluída

### Harness Kotlin/JVM focado

**PASS** **17 verificações focadas** compiladas e executadas usando os arquivos reais de domínio/exportação da V101, com stubs locais mínimos para modelos Android/JSON não disponíveis no ambiente.

Cobertura executada:

1. `TEMPO_RUN_ESTIMATED` resolve para TMP.
2. `T04` / Tempo intervalado resolve para INT.
3. Tipo genérico `Qualidade` + estímulo aeróbio não força INT.
4. `F04` resolve para FAR.
5. Sigla TMP correta.
6. Nome INT `S3_T2_INT_2x10min`.
7. Nome LNG `S3_T3_LNG_ProgressivoZ2`.
8. Rótulo descritivo legado é normalizado para nome curto.
9. Nome compacto canônico é preservado.
10. Título divergente não invalida dose T04 estruturalmente correta.
11. Dose T04 incorreta continua bloqueada.
12. Exportador aceita a variação de título e deriva `workoutName` compacto.
13. Semana de desenvolvimento seleciona T01 (TMP) no cenário testado.
14. Semana específica seleciona I05 (INT) no ramo PERSONAL_BEST de 5 km.
15. Semana seguinte seleciona F04 moderado (FAR).
16. A quarta posição do ciclo não empilha nova sessão principal de qualidade.
17. Auditoria explica o protocolo, liberação de limiar e bloqueio VO₂ por frequência inferior a quatro dias.

### Verificações estáticas

**PASS** **16/16 verificações** de metadados e integração:

- VersionCode 101 / VersionName V101.
- Motor interno 91.
- Backup Schema 14 e `appVersion=V101`.
- Exportador sem comparação literal do título.
- Nome curto normalizado antes de `workoutName`.
- `ExportScreen` com captura de exceção e log.
- JSON gerado antes de criar o arquivo temporário/abrir Sharesheet.
- Categorias TMP/INT/FAR e ausência da regra genérica `type == Qualidade` → INT.
- Auditoria dos gates de limiar/VO₂ e rotação moderada na terceira semana do bloco.
- Uma única posição de sessão principal de qualidade no gerador semanal.

## Testes adicionados/atualizados, mas não executados oficialmente aqui

- `PaceCoachExporterTest`: variações de pontuação/título, nome compacto, preservação de estrutura e dose.
- `WorkoutExportNamingTest`: siglas e variantes compactas, número por semana, normalização de legados.
- `WorkoutCalendarPresentationTest`: nove modalidades, incluindo TMP, e classificação do tipo genérico.
- `TrainingProtocolCatalogTest`: título não estrutural e validação de dose/repetições.
- `TrainingPeriodizationEngineTest`: rotação TMP → INT → FAR moderado → sem protocolo intenso, gates e justificativas.
- `AppBackupCodecTest`: `appVersion=V101` e compatibilidade de schemas anteriores.

## Não executado neste ambiente

- Gradle/JUnit oficial (`:app:testDebugUnitTest`).
- Compilação Android/Compose (`:app:assembleDebug`).
- APK.
- Teste de Android Sharesheet e importação real do JSON no Pace Coach.

Motivo: o ZIP de origem não contém Gradle Wrapper e este ambiente não possui Gradle instalado nem Android SDK. Os stubs locais não são usados no projeto entregue e não substituem os testes oficiais.

## Resultado

A lógica alterada passou nos harnesses focados. A certificação de compilação e interoperabilidade real permanece condicionada ao GitHub Actions e ao teste no Android/Pace Coach.
