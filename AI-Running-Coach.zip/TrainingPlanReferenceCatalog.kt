package com.airunningcoach.app

import kotlin.math.roundToInt

/**
 * Reference-informed planning defaults derived from the supplied 5K/10K O2 Corre and BR Corrida
 * plans plus the Nike Run Club half-marathon (14-week) and marathon (18-week) programs.
 * These are starting templates, not fixed prescriptions; current load and recovery still govern.
 */
internal data class TrainingPlanReference(
    val distanceLabel: String,
    val level: String,
    val defaultWeeks: Int,
    val minimumPreparationWeeks: Int,
    val emphasis: String
)

internal data class GoalLoadReference(
    val goalKm: Double,
    val baseWeeklyKm: Double,
    val maximumBuildWeeklyKm: Double,
    val assumedPreviousContinuousDistanceKm: Double,
    val source: String = "APP_DEFAULT",
    val recommendedFrequency: Int = 3
)

internal data class RunWalkDose(
    val runMinutes: Int,
    val walkMinutes: Int,
    val repetitions: Int,
    val continuousRunMinutes: Int? = null,
    val warmupMinutes: Int = 10,
    val cooldownMinutes: Int = 5
)

internal object TrainingPlanReferenceCatalog {
    /**
     * Product planning defaults by selected distance. When the athlete leaves the
     * four-week average and recent-longest fields blank, these are the stored values
     * used to initialize the cycle. They are planning categories, not medical limits.
     */
    private val goalLoadReferences = listOf(
        GoalLoadReference(1.609, 8.0, 15.0, 0.8, recommendedFrequency = 2),
        GoalLoadReference(3.0, 8.0, 16.0, 1.6, recommendedFrequency = 3),
        GoalLoadReference(5.0, 12.0, 22.5, 3.0, recommendedFrequency = 3),
        GoalLoadReference(10.0, 15.0, 27.5, 5.0, recommendedFrequency = 4),
        GoalLoadReference(15.0, 25.0, 43.0, 10.0, recommendedFrequency = 4),
        GoalLoadReference(16.093, 25.0, 43.0, 10.0, recommendedFrequency = 4),
        GoalLoadReference(20.0, 28.0, 48.0, 16.1, recommendedFrequency = 4),
        GoalLoadReference(21.0975, 30.0, 51.0, 16.1, recommendedFrequency = 4),
        GoalLoadReference(25.0, 35.0, 60.0, 21.1, recommendedFrequency = 4),
        GoalLoadReference(30.0, 40.0, 70.0, 21.1, recommendedFrequency = 4),
        GoalLoadReference(42.195, 45.0, 80.0, 21.1, recommendedFrequency = 4),
        GoalLoadReference(50.0, 55.0, 100.0, 42.2, recommendedFrequency = 5),
        GoalLoadReference(100.0, 75.0, 140.0, 50.0, recommendedFrequency = 5),
        GoalLoadReference(160.934, 90.0, 160.0, 100.0, recommendedFrequency = 6)
    )

    fun loadReference(goalKm: Double, goalCategory: String = "PERFORMANCE"): GoalLoadReference {
        require(goalKm.isFinite() && goalKm in 1.0..200.0) { "Objetivo fora da faixa de planejamento." }
        if (goalCategory == "HEALTH") return GoalLoadReference(goalKm, 8.0, 16.0, 3.0, "HEALTH_DEFAULT", 2)
        val exact = goalLoadReferences.minByOrNull { kotlin.math.abs(it.goalKm - goalKm) }
        if (exact != null && kotlin.math.abs(exact.goalKm - goalKm) < 0.15) return exact.copy(goalKm = goalKm)
        val lower = goalLoadReferences.lastOrNull { it.goalKm < goalKm }
        val upper = goalLoadReferences.firstOrNull { it.goalKm > goalKm }
        if (lower == null) return requireNotNull(upper).copy(goalKm = goalKm)
        if (upper == null) return lower.copy(goalKm = goalKm)
        val fraction = ((goalKm - lower.goalKm) / (upper.goalKm - lower.goalKm)).coerceIn(0.0, 1.0)
        fun interpolate(a: Double, b: Double) = a + (b - a) * fraction
        return GoalLoadReference(
            goalKm = goalKm,
            baseWeeklyKm = round1(interpolate(lower.baseWeeklyKm, upper.baseWeeklyKm)),
            maximumBuildWeeklyKm = round1(interpolate(lower.maximumBuildWeeklyKm, upper.maximumBuildWeeklyKm)),
            assumedPreviousContinuousDistanceKm = round1(interpolate(lower.assumedPreviousContinuousDistanceKm, upper.assumedPreviousContinuousDistanceKm)),
            source = "INTERPOLATED_APP_DEFAULT",
            recommendedFrequency = lower.recommendedFrequency
        )
    }

    private fun round1(value: Double): Double = kotlin.math.round(value * 10.0) / 10.0

    private val references = listOf(
        TrainingPlanReference("5 km", "Iniciante", 12, 8, "Transição caminhada/trote, corrida contínua e conclusão"),
        TrainingPlanReference("5 km", "Intermediário", 8, 6, "Base, ritmo sustentado e intervalos específicos"),
        TrainingPlanReference("5 km", "Performance", 8, 4, "Velocidade, limiar e ritmo de prova; 4 semanas apenas como bloco específico"),
        TrainingPlanReference("10 km", "Iniciante", 12, 10, "Construção de resistência e transição a partir dos 5 km"),
        TrainingPlanReference("10 km", "Intermediário", 8, 8, "Resistência, ritmo moderado e intervalos"),
        TrainingPlanReference("10 km", "Performance", 8, 6, "Limiar, intervalos por distância e ritmo específico"),
        TrainingPlanReference("15 km", "Iniciante", 16, 12, "Transição gradual entre 10 km e meia maratona"),
        TrainingPlanReference("15 km", "Intermediário", 14, 10, "Resistência específica e ritmo sustentado"),
        TrainingPlanReference("15 km", "Performance", 12, 8, "Ritmo específico, limiar e longão estruturado"),
        TrainingPlanReference("21,1 km", "Iniciante", 18, 14, "Base, resistência progressiva e adaptação a longões"),
        TrainingPlanReference("21,1 km", "Intermediário", 14, 12, "Velocidade, resistência, recuperação e longões"),
        TrainingPlanReference("21,1 km", "Performance", 14, 10, "Ritmo de meia maratona, limiar e longões específicos"),
        TrainingPlanReference("42,2 km", "Iniciante", 24, 18, "Construção de base antes de volume específico de maratona"),
        TrainingPlanReference("42,2 km", "Intermediário", 20, 16, "Volume, longões, ritmo de maratona e recuperação"),
        TrainingPlanReference("42,2 km", "Performance", 18, 12, "Longões específicos, velocidade, ritmo de maratona e taper")
    )

    fun reference(goalKm: Double, level: String): TrainingPlanReference? {
        val normalizedLevel = normalizeLevel(level)
        val distanceLabel = when {
            goalKm <= 5.5 -> "5 km"
            goalKm <= 10.5 -> "10 km"
            goalKm <= 15.5 -> "15 km"
            goalKm <= 25.0 -> "21,1 km"
            goalKm <= 42.2 -> "42,2 km"
            else -> return null
        }
        return references.firstOrNull { it.distanceLabel == distanceLabel && it.level == normalizedLevel }
    }

    fun recommendedWeeks(
        goalKm: Double,
        level: String,
        weeklyVolumeKm: Double,
        longestRecentKm: Double? = null
    ): Int {
        val reference = reference(goalKm, level) ?: return 24
        val volumeAdjustment = when {
            weeklyVolumeKm <= 0.0 -> 3
            weeklyVolumeKm < 8.0 -> 2
            weeklyVolumeKm < 20.0 -> 1
            weeklyVolumeKm >= 45.0 && normalizeLevel(level) == "Performance" -> -1
            else -> 0
        }
        // The BR Corrida 5K Sem Parar is a 12-week run/walk progression. The supplied O2
        // beginner 5K plan is 8 weeks and is appropriate when the athlete already runs
        // continuously; retain both pathways rather than treating them as interchangeable.
        val continuousBeginnerFiveK = goalKm <= 5.5 && normalizeLevel(level) == "Iniciante" &&
            (longestRecentKm ?: 0.0) >= 2.5
        // The 4-week advanced 5K source is a specific sharpening block, not a safe default
        // for runners without a demonstrated endurance base.
        val advancedFiveKBlock = goalKm <= 5.5 && normalizeLevel(level) == "Performance" && weeklyVolumeKm >= 30.0
        val base = when {
            advancedFiveKBlock -> 4
            continuousBeginnerFiveK -> 8
            else -> reference.defaultWeeks
        }
        return (base + volumeAdjustment).coerceAtLeast(reference.minimumPreparationWeeks).coerceIn(4, 36)
    }

    /** Progressive walk/run stages reflect the supplied 5K/10K "sem parar" progression. */
    fun runWalkDose(
        planWeek: Int,
        totalPlanWeeks: Int,
        isLongRun: Boolean,
        recovery: Boolean,
        goalIntent: String = TrainingGoalIntent.COMPLETE
    ): RunWalkDose {
        val safeTotal = totalPlanWeeks.coerceAtLeast(1)
        val normalizedWeek = if (safeTotal <= 1) 12 else {
            (1 + ((planWeek.coerceIn(1, safeTotal) - 1) * 11.0 / (safeTotal - 1)).roundToInt()).coerceIn(1, 12)
        }
        val base = when (normalizedWeek) {
            1 -> RunWalkDose(1, 2, 7)
            2 -> RunWalkDose(1, 1, 8)
            3 -> RunWalkDose(2, 1, 6)
            4 -> RunWalkDose(2, 1, 8, continuousRunMinutes = if (isLongRun) 15 else null)
            5 -> RunWalkDose(3, 1, 7)
            6 -> RunWalkDose(3, 1, 9)
            7 -> RunWalkDose(4, 1, 6)
            8 -> RunWalkDose(4, 2, 7, continuousRunMinutes = if (isLongRun) 25 else null)
            9 -> RunWalkDose(5, 2, 6)
            10 -> RunWalkDose(6, 1, 5, continuousRunMinutes = if (isLongRun) 30 else null)
            11 -> RunWalkDose(6, 1, 6)
            else -> RunWalkDose(6, 1, 4, continuousRunMinutes = if (isLongRun) 30 else 15)
        }
        val priorityAdjusted = when (goalIntent) {
            // The continuous-running priority shifts the same session time from walking
            // toward running; it does not add extra total duration or weekly load.
            TrainingGoalIntent.CONTINUOUS -> if (normalizedWeek >= 2) base.copy(
                runMinutes = (base.runMinutes + 1).coerceAtMost(8),
                walkMinutes = (base.walkMinutes - 1).coerceAtLeast(1)
            ) else base
            // Performance/time priorities do not accelerate the beginner's load ladder.
            // Their specific pace work is unlocked only after the separate readiness gates.
            else -> base
        }
        return if (recovery) priorityAdjusted.copy(
            walkMinutes = (priorityAdjusted.walkMinutes + 1).coerceAtMost(4),
            repetitions = (priorityAdjusted.repetitions - 1).coerceAtLeast(2),
            continuousRunMinutes = null
        ) else priorityAdjusted
    }

    fun normalizeLevel(level: String): String = when (level.trim().lowercase()) {
        "iniciante", "beginner" -> "Iniciante"
        "avançado", "avancado", "advanced", "performance", "elite" -> "Performance"
        else -> "Intermediário"
    }
}
