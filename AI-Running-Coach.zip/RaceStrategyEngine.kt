package com.airunningcoach.app

import java.text.Normalizer
import java.time.LocalDate
import kotlin.math.roundToInt

internal data class RacePaceEvidence(
    val date: LocalDate,
    val distanceKm: Double,
    val paceSecondsPerKm: Int,
    val effort: String,
    val feeling: String,
    val painPresent: Boolean,
    val source: String,
    val workoutType: String = "",
    val zone: String? = null,
    val sessionId: String = "",
    val durationSeconds: Int? = null
)

internal data class RaceStrategyPhase(
    val title: String,
    val startKm: Double,
    val endKm: Double,
    val zone: String,
    val fastestPaceSecondsPerKm: Int?,
    val slowestPaceSecondsPerKm: Int?,
    val rationale: String
) {
    val distanceKm: Double get() = (endKm - startKm).coerceAtLeast(0.0)
}

internal data class RaceStrategy(
    val eventId: String,
    val title: String,
    val priorityLabel: String,
    val phases: List<RaceStrategyPhase>,
    val estimatedTimeMinSeconds: Int?,
    val estimatedTimeMaxSeconds: Int?,
    val evidenceCount: Int,
    val evidenceSessionCount: Int,
    val confidence: String,
    val targetAssessment: String,
    val readinessNote: String,
    val pacingNotes: List<String>,
    val targetTimeSeconds: Int? = null,
    val targetPaceSecondsPerKm: Int? = null,
    /** NONE, COMPATIBLE, CONSERVATIVE, ASPIRATIONAL or UNVERIFIED. */
    val targetStatus: String = "NONE",
    val targetPaceDriven: Boolean = false,
    val projectedTargetGapSeconds: Int? = null
)

/** Builds a race strategy with two independent dimensions: race priority changes the training cycle,
 * while an explicitly entered target time shapes execution for A, B and C events when it is safe to do so.
 */
internal object RaceStrategyEngine {
    private data class PhaseSpec(
        val title: String,
        val fromFraction: Double,
        val toFraction: Double,
        val zone: String,
        val explanation: String
    )

    fun build(
        event: RaceEvent,
        athleteIntent: String,
        zones: TrainingPaceZones?,
        evidence: List<RacePaceEvidence>,
        today: LocalDate = LocalDate.now()
    ): RaceStrategy {
        val distanceKm = event.distanceKm.coerceIn(1.0, 200.0)
        val recent = evidence.filter { item ->
            !item.painPresent && item.paceSecondsPerKm in 120..1800 && item.distanceKm >= 0.0 &&
                !item.date.isAfter(today) && !item.date.isBefore(today.minusDays(90)) &&
                normalize(item.effort) !in setOf("muito pesado", "maximo")
        }
        val activity = recent.filter { it.source == "ACTIVITY" && it.distanceKm > 0.0 }
        val blocks = recent.filter {
            it.source == "BLOCK" && it.zone in setOf("Z1", "Z2", "Z3", "Z4", "Z5") &&
                (it.distanceKm >= 0.8 || (it.durationSeconds ?: 0) >= 300)
        }
        val comparableActivity = activity.filter { isComparableDistance(distanceKm, it.distanceKm) }
        val longRunKm = activity.filter { normalize(it.workoutType).contains("long") }
            .maxOfOrNull { it.distanceKm } ?: 0.0

        val specs = phaseSpecs(distanceKm)
        val targetSeconds = PaceDuration.parse(event.targetTime)
        val targetPace = targetSeconds?.let { (it / distanceKm).roundToInt().coerceIn(120, 1800) }
        val targetZoneRange = zones?.zone(specs.getOrNull(1)?.zone ?: "Z3")?.range
        val distanceEvidencePaces = comparableActivity.map { it.paceSecondsPerKm }
        val comparableMedian = median(distanceEvidencePaces)
        val targetOutsideFastLimit = targetPace != null && zones != null &&
            targetPace < zones.z5.range.fastestPaceValue - 10
        // A target materially faster than recent comparable performances is aspirational.
        // A slower target is conservative; it remains usable and must not be silently discarded.
        val targetIsTooAggressive = targetPace != null && (
            targetOutsideFastLimit || (comparableMedian != null && targetPace < comparableMedian * 0.97)
        )
        val targetIsConservative = targetPace != null && comparableMedian != null && targetPace > comparableMedian * 1.08
        val hasAnyValidationEvidence = zones != null || comparableActivity.isNotEmpty() || blocks.isNotEmpty()
        val targetCanDriveStrategy = targetPace != null && !targetIsTooAggressive && hasAnyValidationEvidence

        val longRunRequired = when {
            distanceKm >= 40.0 -> 24.0
            distanceKm >= 21.0 -> 14.0
            distanceKm >= 16.0 -> 10.0
            else -> 0.0
        }
        val longRunReady = longRunRequired == 0.0 || longRunKm >= longRunRequired
        val phases = when {
            targetCanDriveStrategy -> buildTargetPhases(
                event = event,
                eventDistance = distanceKm,
                specs = specs,
                targetPace = targetPace!!,
                zones = zones,
                longRunReady = longRunReady,
                athleteIntent = athleteIntent
            )
            else -> specs.mapIndexed { index, spec ->
                buildEvidencePhase(event, distanceKm, spec, index, blocks, comparableActivity, zones, longRunReady, athleteIntent)
            }
        }

        val phaseTimes = phases.mapNotNull { phase ->
            val fast = phase.fastestPaceSecondsPerKm ?: return@mapNotNull null
            val slow = phase.slowestPaceSecondsPerKm ?: return@mapNotNull null
            ((phase.distanceKm * fast).roundToInt()) to ((phase.distanceKm * slow).roundToInt())
        }
        val timeMin = if (phaseTimes.size == phases.size) phaseTimes.sumOf { it.first } else null
        val timeMax = if (phaseTimes.size == phases.size) phaseTimes.sumOf { it.second } else null
        val projectedMid = if (timeMin != null && timeMax != null) (timeMin + timeMax) / 2 else null
        val targetGap = if (projectedMid != null && targetSeconds != null) projectedMid - targetSeconds else null

        val strategyEvidenceCount = activity.size + blocks.size
        val strategyEvidence = activity + blocks
        val sessions = strategyEvidence.map { it.sessionId.ifBlank { "${it.date}:${it.workoutType}:${it.source}" } }.distinct().size
        val relevantBlocks = blocks.filter { it.zone == (specs.getOrNull(1)?.zone ?: "Z3") }
        val confidence = when {
            zones == null -> if (comparableActivity.size >= 2) "Moderada; validar nos próximos treinos" else "Insuficiente: sem zonas individualizadas"
            comparableActivity.size >= 4 && sessions >= 3 && longRunReady -> "Boa base de evidências"
            comparableActivity.size >= 2 || relevantBlocks.size >= 4 -> "Moderada; validar nos próximos treinos"
            targetCanDriveStrategy -> "Inicial; alvo matemático orientado pelas zonas, ainda sem validação suficiente em provas/treinos comparáveis"
            else -> "Insuficiente: faltam dados de desempenho"
        }

        val targetStatus = when {
            targetPace == null -> "NONE"
            targetIsTooAggressive -> "ASPIRATIONAL"
            !hasAnyValidationEvidence -> "UNVERIFIED"
            targetIsConservative -> "CONSERVATIVE"
            comparableActivity.isEmpty() && blocks.isEmpty() -> "UNVERIFIED"
            else -> "COMPATIBLE"
        }
        val targetAssessment = when {
            targetPace == null -> if (comparableActivity.isNotEmpty() || blocks.isNotEmpty()) {
                "Sem tempo-alvo informado. A referência foi estimada a partir dos treinos e blocos por zona registrados; cada trecho respeita a zona correspondente."
            } else if (targetZoneRange != null) {
                "Sem tempo-alvo e sem treinos comparáveis suficientes. As faixas usam as zonas atuais como referência conservadora, com baixa confiança."
            } else {
                "Sem tempo-alvo e sem evidências suficientes para estimar o ritmo. Registre um teste ou mais treinos."
            }
            targetIsTooAggressive -> "Meta de ${PaceRange.format(targetPace)} min/km (${PaceRange.formatDuration(targetSeconds!!)} no total) é mais rápida que a capacidade sustentada pelas evidências/zonas atuais. A estratégia exibida permanece conservadora e baseada no desempenho demonstrado; o alvo fica como aspiracional."
            !hasAnyValidationEvidence -> "Tempo-alvo de ${PaceRange.formatDuration(targetSeconds!!)} cadastrado: exige média de ${PaceRange.format(targetPace)} min/km. É uma referência matemática ainda não validada; registre teste ou sessões recentes antes de tratar esses ritmos como prescrição."
            comparableActivity.isEmpty() && blocks.isEmpty() -> "Tempo-alvo de ${PaceRange.formatDuration(targetSeconds!!)} exige ${PaceRange.format(targetPace)} min/km. As zonas atuais permitem uma checagem inicial, mas faltam sessões recentes comparáveis para confirmar a sustentabilidade do ritmo."
            targetIsConservative -> "Tempo-alvo de ${PaceRange.formatDuration(targetSeconds!!)} exige ${PaceRange.format(targetPace)} min/km. É mais conservador que o ritmo mediano recente; a estratégia usa o alvo sem forçar aceleração. Compatibilidade fisiológica deve ser confirmada pela sensação e pelo percurso."
            targetCanDriveStrategy -> "Estratégia orientada ao tempo-alvo de ${PaceRange.formatDuration(targetSeconds!!)}: média necessária de ${PaceRange.format(targetPace)} min/km. Os trechos foram distribuídos para manter a projeção próxima da meta; isso não é garantia de resultado."
            else -> "Tempo-alvo de ${PaceRange.formatDuration(targetSeconds!!)} (${PaceRange.format(targetPace)} min/km) registrado, mas não foi possível validar sua aplicação com os dados disponíveis."
        }

        val readiness = when {
            distanceKm >= 40.0 && !longRunReady -> "Maior longão registrado: ${formatDistance(longRunKm)} km. Ainda abaixo da referência de preparação de 24 km; priorize conclusão, controle e abastecimento, sem presumir sustentação de ritmo de maratona."
            distanceKm >= 21.0 && !longRunReady -> "Maior longão registrado: ${formatDistance(longRunKm)} km. Histórico abaixo da referência de 14 km; mantenha estratégia conservadora e não force o trecho final."
            distanceKm >= 16.0 && !longRunReady -> "Longão recente abaixo da referência de 10 km para esta distância. Confirme a preparação antes de assumir o ritmo-alvo."
            zones == null -> "Registre um teste de desempenho válido para obter zonas e ritmos individualizados."
            else -> "A preparação foi avaliada com base nos treinos e testes recentes disponíveis. Reavalie após novas sessões."
        }
        val priorityGuidance = when (event.priority) {
            "A" -> "Prioridade A: prova principal do ciclo. Pode definir a janela de preparação, taper e recuperação pós-prova."
            "B" -> "Prioridade B: prova preparatória. Orienta a execução para validar ritmo e estratégia, substitui uma sessão, mas não ativa taper automático."
            else -> "Prioridade C: evento e estímulo de treinamento. O tempo-alvo informado orienta a execução como referência opcional, sem promover a prova a objetivo principal nem alterar o macrociclo."
        }
        val notes = buildList {
            add(priorityGuidance)
            if (targetSeconds != null) add("Objetivo de execução: ${PaceRange.formatDuration(targetSeconds)} (${PaceRange.format(targetPace!!)} min/km de média). A prioridade muda a preparação do ciclo, não apaga o tempo informado.")
            add("Os trechos e ritmos foram calculados para ${formatDistance(distanceKm)} km. Ajuste por altimetria, clima e percepção de esforço.")
            add("Não acelere além do que foi demonstrado em treino; interrompa a progressão se houver dor, perda de técnica ou esforço desproporcional.")
            if (targetIsTooAggressive) add("O alvo é aspiracional e não foi imposto aos trechos porque excede a capacidade demonstrada.")
            if (targetIsConservative) add("A meta é conservadora em relação às sessões recentes; mantenha a execução controlada em vez de acelerar apenas para usar zonas mais rápidas.")
            if (targetSeconds != null && !hasAnyValidationEvidence) add("O pace exibido é apenas o cálculo matemático do alvo; falta evidência para confirmar se é sustentável.")
            if (!longRunReady && longRunRequired > 0.0) add("O histórico de longões ainda não sustenta uma aceleração planejada no final desta distância.")
            if (athleteIntent == TrainingGoalIntent.COMPLETE) add("Objetivo de conclusão: priorize regularidade e controle, não uma aceleração obrigatória no final.")
        }

        return RaceStrategy(
            eventId = event.id,
            title = raceTitle(distanceKm),
            priorityLabel = event.priorityLabel(),
            phases = phases,
            estimatedTimeMinSeconds = timeMin,
            estimatedTimeMaxSeconds = timeMax,
            evidenceCount = strategyEvidenceCount,
            evidenceSessionCount = sessions,
            confidence = confidence,
            targetAssessment = targetAssessment,
            readinessNote = readiness,
            pacingNotes = notes,
            targetTimeSeconds = targetSeconds,
            targetPaceSecondsPerKm = targetPace,
            targetStatus = targetStatus,
            targetPaceDriven = targetCanDriveStrategy,
            projectedTargetGapSeconds = targetGap
        )
    }

    private fun buildTargetPhases(
        event: RaceEvent,
        eventDistance: Double,
        specs: List<PhaseSpec>,
        targetPace: Int,
        zones: TrainingPaceZones?,
        longRunReady: Boolean,
        athleteIntent: String
    ): List<RaceStrategyPhase> {
        // A-priority races may use a small negative split when the athlete is prepared.
        // B/C keep a steadier target execution: priority must not erase the entered target.
        val startOffset = when {
            event.priority == "A" && longRunReady && athleteIntent != TrainingGoalIntent.COMPLETE -> 3
            event.priority == "B" && athleteIntent != TrainingGoalIntent.COMPLETE -> 2
            else -> 0
        }
        val firstDistance = eventDistance * (specs.first().toFraction - specs.first().fromFraction)
        val lastDistance = eventDistance * (specs.last().toFraction - specs.last().fromFraction)
        val finalOffset = if (startOffset > 0 && lastDistance > 0.0) {
            (-firstDistance * startOffset / lastDistance).roundToInt()
        } else 0

        return specs.mapIndexed { index, spec ->
            val offset = when (index) {
                0 -> startOffset
                specs.lastIndex -> finalOffset
                else -> 0
            }
            val center = (targetPace + offset).coerceIn(120, 1800)
            val zone = zoneForPace(center, zones) ?: "ALVO"
            val fast = (center - 2).coerceAtLeast(120)
            val slow = (center + 2).coerceAtMost(1800)
            RaceStrategyPhase(
                title = spec.title,
                startKm = eventDistance * spec.fromFraction,
                endKm = eventDistance * spec.toFraction,
                zone = zone,
                fastestPaceSecondsPerKm = fast,
                slowestPaceSecondsPerKm = slow,
                rationale = when {
                    index == 0 && startOffset > 0 -> "Largada controlada: comece cerca de ${startOffset} s/km mais lento que a média-alvo para estabilizar a respiração."
                    index == specs.lastIndex && finalOffset < 0 -> "Trecho final: a leve progressão compensa a largada controlada; só mantenha se houver reserva e técnica estável."
                    zone == "ALVO" -> "Pace-alvo de execução. Este ritmo não coincide exatamente com uma faixa Z1–Z5; use a sensação, a respiração e os dados de desempenho como limite."
                    else -> "Mantenha a média-alvo de ${PaceRange.format(targetPace)} min/km, sem acelerar por causa de parciais isoladas."
                }
            )
        }
    }

    private fun zoneForPace(pace: Int, zones: TrainingPaceZones?): String? = zones?.all()?.firstOrNull { zone ->
        pace in zone.range.fastestPaceValue..zone.range.slowestPaceValue
    }?.id

    private fun buildEvidencePhase(
        event: RaceEvent,
        eventDistance: Double,
        spec: PhaseSpec,
        index: Int,
        blocks: List<RacePaceEvidence>,
        activity: List<RacePaceEvidence>,
        zones: TrainingPaceZones?,
        longRunReady: Boolean,
        athleteIntent: String
    ): RaceStrategyPhase {
        val zoneRange = zones?.zone(spec.zone)?.range
        val zoneBlocks = blocks.filter { it.zone == spec.zone }.map { it.paceSecondsPerKm }
        val activityMedian = activity.map { it.paceSecondsPerKm }.let(::median)
        val zoneMedian = zoneBlocks.let(::median)
        val evidenceBase = when {
            zoneMedian != null -> zoneMedian
            activityMedian != null -> activityMedian
            zoneRange != null -> (zoneRange.fastestPaceValue + zoneRange.slowestPaceValue) / 2
            else -> null
        }
        val priorityOffset = when (event.priority) { "B" -> 5; "C" -> 10; else -> 0 }
        val goalOffset = if (athleteIntent == TrainingGoalIntent.COMPLETE) 5 else 0
        val distanceOffset = when {
            index == 0 && eventDistance >= 40.0 -> 20
            index == 0 && eventDistance >= 21.0 -> 15
            index == 0 && eventDistance >= 10.0 -> 10
            index == 0 -> 6
            index == 2 && eventDistance <= 10.1 && longRunReady -> -5
            index == 2 && longRunReady -> -2
            else -> 0
        }
        val centerUnclamped = evidenceBase?.plus(priorityOffset + goalOffset + distanceOffset)
        val center = when {
            centerUnclamped == null -> null
            zoneRange != null -> centerUnclamped.coerceIn(zoneRange.fastestPaceValue, zoneRange.slowestPaceValue)
            else -> centerUnclamped.coerceIn(120, 1800)
        }
        val fast = center?.let { value ->
            val candidate = value - if (index == 0) 2 else 5
            zoneRange?.let { candidate.coerceIn(it.fastestPaceValue, it.slowestPaceValue) } ?: candidate.coerceAtLeast(120)
        }
        val slow = center?.let { value ->
            val candidate = value + if (index == 0) 8 else 5
            zoneRange?.let { candidate.coerceIn(it.fastestPaceValue, it.slowestPaceValue) } ?: candidate.coerceAtMost(1800)
        }
        val validRange = fast != null && slow != null && fast <= slow
        return RaceStrategyPhase(
            title = spec.title,
            startKm = eventDistance * spec.fromFraction,
            endKm = eventDistance * spec.toFraction,
            zone = spec.zone,
            fastestPaceSecondsPerKm = if (validRange) fast else center,
            slowestPaceSecondsPerKm = if (validRange) slow else center,
            rationale = when {
                index == 0 -> spec.explanation
                index == 2 && !longRunReady && eventDistance >= 16.0 -> "Finalize em esforço sustentável; o histórico ainda não demonstra reserva suficiente para acelerar."
                event.priority == "C" -> "Mantenha o estímulo planejado para esta prova e evite transformá-lo em esforço máximo."
                else -> spec.explanation
            }
        )
    }

    private fun phaseSpecs(km: Double): List<PhaseSpec> = when {
        km <= 5.1 -> listOf(
            PhaseSpec("Início", 0.0, 0.20, "Z3", "Largada controlada: não tente recuperar posições nos primeiros metros."),
            PhaseSpec("Meio", 0.20, 0.78, "Z4", "Sustente o ritmo de prova validado nos treinos; evite oscilações desnecessárias."),
            PhaseSpec("Final", 0.78, 1.0, "Z4", "Aumente gradualmente somente se houver reserva e técnica estável.")
        )
        km <= 10.1 -> listOf(
            PhaseSpec("Início", 0.0, 0.20, "Z3", "Estabeleça o ritmo sem largar acima da faixa demonstrada."),
            PhaseSpec("Meio", 0.20, 0.80, "Z4", "Sustente o esforço planejado e compare a sensação com os blocos específicos."),
            PhaseSpec("Final", 0.80, 1.0, "Z4", "Aumente progressivamente se a respiração, a técnica e a sensação permanecerem controladas.")
        )
        km <= 16.2 -> listOf(
            PhaseSpec("Início", 0.0, 0.18, "Z2", "Comece de forma conservadora para não antecipar a fadiga."),
            PhaseSpec("Meio", 0.18, 0.80, "Z3", "Sustente o ritmo de referência e avalie a estabilidade do esforço."),
            PhaseSpec("Final", 0.80, 1.0, "Z3", "A progressão depende da reserva observada e da preparação em longões.")
        )
        km <= 21.2 -> listOf(
            PhaseSpec("Início", 0.0, 0.15, "Z2", "Controle os primeiros quilômetros; a meia-maratona exige distribuição de esforço."),
            PhaseSpec("Meio", 0.15, 0.82, "Z3", "Mantenha ritmo sustentável, sem acelerar por causa de parciais isoladas."),
            PhaseSpec("Final", 0.82, 1.0, "Z3", "Aumente o esforço apenas se os longões e a sensação indicarem reserva suficiente.")
        )
        else -> listOf(
            PhaseSpec("Início", 0.0, 0.15, "Z2", "Largada conservadora: evite ritmo acima da capacidade aeróbica demonstrada."),
            PhaseSpec("Meio", 0.15, 0.82, "Z2", "Priorize constância, economia de esforço e estratégia de hidratação/energia."),
            PhaseSpec("Final", 0.82, 1.0, "Z3", "Só progrida se a reserva, a técnica e a tolerância estiverem preservadas; caso contrário, mantenha esforço sustentável.")
        )
    }

    private fun isComparableDistance(raceKm: Double, trainingKm: Double): Boolean = when {
        raceKm <= 5.1 -> trainingKm in 2.0..8.0
        raceKm <= 10.1 -> trainingKm in 4.0..14.0
        raceKm <= 16.2 -> trainingKm in 7.0..22.0
        raceKm <= 21.2 -> trainingKm in 9.0..30.0
        else -> trainingKm >= 15.0
    }

    private fun median(values: List<Int>): Int? {
        if (values.isEmpty()) return null
        val sorted = values.sorted()
        val middle = sorted.size / 2
        return if (sorted.size % 2 == 1) sorted[middle] else ((sorted[middle - 1] + sorted[middle]) / 2.0).roundToInt()
    }

    private fun raceTitle(km: Double): String = when {
        km <= 5.1 -> "Estratégia de 5 km"
        km <= 10.1 -> "Estratégia de 10 km"
        km >= 21.0 && km <= 21.2 -> "Estratégia de meia-maratona"
        km >= 42.0 && km <= 42.3 -> "Estratégia de maratona"
        else -> "Estratégia de ${formatDistance(km)} km"
    }

    private fun normalize(value: String): String = Normalizer.normalize(value.trim(), Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "").lowercase()

    private fun formatDistance(km: Double): String = String.format(java.util.Locale.US, "%.1f", km).trimEnd('0').trimEnd('.')
}
