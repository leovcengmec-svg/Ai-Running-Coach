# V49 — Plano contínuo e sugestão contextual em dias livres

## Migração de backup

O backup continua sendo um envelope JSON compatível com versões anteriores. O campo `engineVersion` identifica a geração do plano. Ao restaurar um arquivo anterior ao motor 37:

1. O arquivo é validado e restaurado integralmente antes de qualquer recalibração.
2. O app carrega preferências, sessões, feedbacks, Cooper e competições.
3. Sessões concluídas são reconhecidas tanto pelo campo `done` quanto pela existência de feedback associado.
4. Com perfil completo, o motor gera novamente apenas as sessões futuras a partir da semana-calendário atual.
5. Sessões concluídas, feedbacks e provas permanecem; datas já ocupadas por sessões concluídas não recebem novo treino regenerado.
6. Se o perfil estiver incompleto ou a geração for bloqueada por segurança, o backup continua restaurado e o plano anterior permanece disponível para revisão.

## Consulta em dia livre

A ação no calendário é deliberada: o atleta seleciona uma data livre, solicita análise e só então confirma a eventual inclusão. A recomendação não transfere treinos perdidos.

### Evidências consideradas

- Sessões previstas e concluídas na semana ISO (segunda a domingo).
- Sessões adicionais já incluídas na mesma semana.
- Feedback de esforço, sensação e dor nos últimos 14 dias.
- Provas na data selecionada.
- Volume semanal de referência e maior corrida recente (quando medidos).
- Distância e tipo das sessões, com atenção a qualidade e longão dentro de dois dias de calendário; como o horário exato não é armazenado, essa é uma janela conservadora de até 72 horas.

### Decisões possíveis

- **Manter descanso:** dor recente, fadiga relevante, sessão exigente ou longão recente (até dois dias de calendário), competição, três sessões na semana, sessão extra já utilizada ou ausência de referência de carga.
- **Sessão opcional:** apenas quando a semana tem espaço e os sinais recentes permitem. A sessão é curta, Z1, RPE 2–3, sem intervalos, com limite conservador de distância e confirmação explícita.

A sugestão é uma opção pontual, não uma mudança no calendário habitual nem autorização médica. Qualquer dor durante a execução exige interrupção. O cenário de duas sessões concluídas na semana foi testado: a sugestão só é liberada quando a frequência planejada ainda comporta uma sessão, não há dor/fadiga, não há sessão exigente recente e há referência de carga suficiente. Um longão na sexta mantém o domingo como recuperação quando o horário exato da atividade é desconhecido.

## Base técnica e limites da evidência

A regra não usa a conhecida "regra dos 10%" como garantia de segurança. Um estudo de coorte com 5.205 corredores encontrou associação entre sessões que excediam em mais de 10% a maior distância corrida nos 30 dias anteriores e maior taxa de lesões por sobrecarga; os autores também alertam que a progressão deve considerar recuperação e exposições sucessivas. O motor V49 adota limites conservadores de sessão, sinais subjetivos e contexto semanal, sem afirmar que elimina lesões.

Referências:
- Nielsen et al. (2025), *How much running is too much? Identifying high-risk running sessions in a 5200-person cohort study*, British Journal of Sports Medicine. https://bjsm.bmj.com/content/59/17/1203
- SPRINT injury prevention study, BMJ Open Sport & Exercise Medicine (2020), sobre equilíbrio entre carga e recuperação. https://bmjopensem.bmj.com/content/6/1/e000780


## Verificações V49

- Testes unitários adicionados: 12 para decisões em dias livres e 3 para migração/preservação de plano.
- Testes de fumaça executados com `kotlinc`: 5/5 decisões de dia livre e 3/3 verificações de migração.
- A suíte Android/Gradle e o APK precisam ser confirmados no GitHub Actions; este ambiente não contém Gradle Wrapper nem Android SDK.
