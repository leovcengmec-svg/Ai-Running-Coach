# AI Running Coach — Plano de correção V100

**Auditoria da V99 · 26/11/2026**  
**Status:** diagnóstico fundamentado no código V99 e nas quatro capturas; plano de correção elaborado. Implementação ainda não realizada.

## 1. Identificação proposta

| Item | V100 |
|---|---:|
| VersionCode | 100 |
| VersionName | V100 |
| Motor interno | 90 |
| Base | V99 |
| Backup Schema | 14 |
| Compatibilidade | Leitura de schemas 1–13 e 14 |

O Schema 14 é proposto porque o ciclo precisa ter identidade e estado persistidos, e não depender apenas de inferências de data e número da semana. A migração deve continuar lendo todos os backups das versões anteriores.

---

## 2. Resumo executivo

A V99 corrigiu a contagem de compromissos e passou a detalhar a composição semanal, mas as novas capturas mostram que dois problemas continuam:

1. A recalibração de um backup antigo ainda pode ser impedida por uma divergência mínima de 0,2 ponto percentual no teto do longão, mesmo quando a meta semanal registrada é 17 km e a composição está a apenas 100 m desse total.
2. A migração de motor ainda não tem uma garantia absoluta de preservação do macro ciclo de oito semanas. O código preserva a âncora em alguns caminhos, mas pode regenerar a semana em andamento, abandonar a âncora quando a assinatura do objetivo muda ou abrir uma nova janela quando a janela restaurada não é reconhecida.

O calendário, por sua vez, continua exibindo títulos longos e híbridos como “Rodagem aeróbia” e “Rodagem regenerativa”, usa símbolos Unicode/emoji com estilos diferentes e mantém células de 94 dp de altura. A função que já produz siglas curtas existe, mas não é utilizada na grade mensal.

A V100 deverá consolidar três frentes:

- **Ciclo de 8 semanas protegido:** atualização do motor dentro do ciclo existente, sem criar um novo bloco antes da conclusão das oito semanas.
- **Distribuição semanal reconciliada:** manter o teto estrito de 40%, mas reconciliar distâncias e metas antes de bloquear; reteste sem protocolo não deve ser tratado como distância final.
- **Calendário compacto e padronizado:** ícone vetorial colorido + sigla curta, célula menor e sem “aeróbio/aeróbia” ou rótulos híbridos.

---

## 3. Auditoria da recalibração do ciclo

### 3.1 O ciclo é preservado em alguns caminhos, mas não está protegido como entidade imutável

Arquivos examinados:

- `android/app/src/main/java/com/airunningcoach/app/MainActivity.kt`
- `android/app/src/main/java/com/airunningcoach/app/PlanMigrationEngine.kt`
- `android/app/src/main/java/com/airunningcoach/app/TrainingScheduleEngine.kt`

Em `MainActivity.createPlan()`:

- `objectiveChanged` é verdadeiro quando a assinatura atual diverge da assinatura salva.
- `shouldPreserveCycleAnchor` depende de `!objectiveChanged`.
- Portanto, mesmo a chamada de recalibração que passa `preserveCycleAnchor = true` pode perder a preservação se a assinatura tiver mudado.
- A assinatura agrega objetivo, intenção, tempo-alvo, melhor marca, nível, frequência, dias disponíveis, terreno, experiência, método/resultados fisiológicos, base semanal, maior sessão e duração do plano. Pequenas diferenças entre revisões antigas e atuais podem ser interpretadas como mudança de objetivo e não como simples atualização do motor.

O fluxo seguinte chama `RunningCoachEngine.generate(input)` para construir novamente o planejamento e depois filtra/mescla sessões. Isso preserva parte do histórico e a âncora quando reconhecida, mas não significa que a agenda do ciclo foi preservada integralmente.

Há ainda uma condição explícita:

`freezeExistingCurrentWeek = workouts.isNotEmpty() && !isEngineUpgradeMigration && !adoptionBeginsToday`

Durante uma migração de motor (`isEngineUpgradeMigration == true`), a semana atual deixa de ser congelada. Assim, uma recalibração de backup na Semana 3 pode substituir sessões pendentes da própria Semana 3, embora a interface prometa manter o plano existente e atualizar apenas sessões futuras.

Em `PlanMigrationEngine.restoredPlanWindow()`, a janela restaurada retorna `null` quando a data atual já alcançou o fim calculado do ciclo. Se isso ocorrer, `createPlan()` cai no caminho de `RaceEventEngine.resolvePlanWindow()`. Esse fallback pode abrir um novo plano sem confirmar que todas as sessões da Semana 8 foram concluídas ou explicitamente encerradas.

### 3.2 Regra obrigatória V100: um ciclo ativo não pode reiniciar por atualização do motor

Para um backup que está na Semana 3 de um plano de 8 semanas:

- Semanas 1 e 2: preservadas como histórico imutável, inclusive datas reais, feedbacks, atividades e cargas registradas.
- Semana 3: preservada integralmente, inclusive sessões futuras ainda não concluídas dentro da semana. A migração de motor não deve reescrever a semana que já está em andamento.
- Semanas 4 a 8: podem receber atualização do motor, mas permanecem dentro do mesmo ciclo, com a mesma âncora, numeração, frequência semanal, slots disponíveis, objetivo do ciclo e metas de volume aprovadas.
- O motor pode atualizar conteúdo técnico das sessões futuras — blocos, ritmo, zonas, instruções e justificativas — sem deslocar datas ou inventar uma nova periodização de oito semanas.
- Se a nova versão não conseguir atualizar uma sessão com segurança, a sessão original deve permanecer, com diagnóstico, sem apagar ou recriar o ciclo.

**A atualização de versão não é autorização para iniciar um ciclo novo.**

### 3.3 Quando um novo ciclo poderá ser gerado

A V100 deve persistir um estado explícito de ciclo:

- `cycleId`
- `cycleStartDateIso`
- `cycleDurationWeeks` (8 para o ciclo deste caso)
- `cycleStatus` (`ACTIVE`, `COMPLETED`, `ARCHIVED`)
- `cycleCompletedAtIso` (quando aplicável)
- assinatura do objetivo vigente no início do ciclo e assinatura pendente para o próximo ciclo

Um ciclo só passa a `COMPLETED` quando:

1. As oito semanas do ciclo tiverem transcorrido integralmente, de segunda a domingo, a partir da âncora original.
2. A Semana 8 estiver encerrada; sessões restantes devem estar concluídas ou explicitamente marcadas como não realizadas/dispensadas. Uma sessão ainda futura ou pendente impede o encerramento.
3. Histórico, feedbacks e atividades estiverem reconciliados com as sessões planejadas.

Depois disso, a interface poderá oferecer **“Iniciar novo ciclo”**. Não deverá iniciar automaticamente um novo ciclo apenas porque a data calculada ultrapassou `cycleStart + 8 semanas`.

Alterações de objetivo, frequência, dias disponíveis ou terreno feitas durante o ciclo ficam registradas como mudanças pendentes para o próximo ciclo. Uma incompatibilidade fisiológica ou de segurança pode exigir redução/bloqueio de uma sessão futura, mas não pode reiniciar o macro ciclo silenciosamente.

### 3.4 Recuperação de backups antigos

A V100 deve migrar backups de motores antigos (incluindo o motor 83 mostrado na imagem) sem exigir que o backup tenha `cycleId`.

Ordem de recuperação:

1. Usar `cycleStartDateIso` e `cycleDurationWeeks` quando existirem.
2. Para schemas antigos, inferir a âncora pela combinação de `planStartDateIso`, data das sessões e número de semana salvo.
3. Usar a maioria consistente dos pares data/semana; sessões concluídas, feedbacks e sessões manuais são evidências para a âncora, não motivo para reiniciar o ciclo.
4. Se a evidência for ambígua, preservar o backup como está e solicitar decisão do corredor. Não substituir o plano por uma nova janela presumida.
5. `engineVersion` antigo deve ativar migração in-place, não `newCycle`.

---

## 4. Auditoria do bloqueio de 40,2% do longão

### 4.1 Números visíveis na imagem

A mensagem da V99 mostra a semana de **07/12/2026** com:

| Sessão | Distância considerada |
|---|---:|
| Reteste fisiológico sem método | até 5,0 km (limite provisório do Cooper) |
| Fartlek variável | 5,1 km |
| Longão regressivo Z2 | 6,8 km |
| **Máximo total calculado** | **16,9 km** |
| Meta semanal registrada | **17,0 km** |

Com o denominador de 16,9 km, a participação do longão é:

`6,8 / 16,9 = 40,2367%` (aproximadamente 40,2%).

Com o total-alvo de 17,0 km:

`6,8 / 17,0 = 40,0%`.

Portanto, o bloqueio de 40,2% é matematicamente coerente com a composição provisória de 16,9 km que o validador recebeu. O defeito está na reconciliação entre a meta de 17,0 km e as sessões/estimativas que compõem somente 16,9 km, além de se tentar fechar o percentual antes da escolha do protocolo do reteste.

A V100 **não deve simplesmente aceitar 40,2% nem relaxar o limite de 40%**. Deve corrigir a origem da diferença de 100 m e adiar a validação final de uma sessão cujo protocolo ainda não foi escolhido.

### 4.2 Regra V100 para distribuir a diferença sem aumentar a meta

- Todos os cálculos internos de distância e participação devem usar metros inteiros (ou precisão equivalente), não valores formatados para exibição.
- A meta semanal persistida é um alvo, não deve ser somada como se fosse uma sessão adicional.
- Antes do bloqueio, o motor deve reconciliar a soma das sessões prescritas com a meta semanal e apontar qualquer diferença.
- No exemplo de 17,0 km, se o reteste Cooper utilizar 5,0 km de sessão total, o motor pode redistribuir os 100 m faltantes para uma sessão não-longão (por exemplo, Fartlek de 5,1 para 5,2 km) **sem elevar a meta de 17,0 km**. O resultado fica 5,0 + 5,2 + 6,8 = 17,0 km e o longão representa exatamente 40%.
- A redistribuição deve ocorrer antes de montar os blocos e deve respeitar as regras anteriores de carga, recuperação, piso de 5 km para objetivo de 5 km e sessões de qualidade completas. Não alterar só o `distanceKm` do resumo mantendo os blocos com outro total.
- Se não houver sessão não-longão que possa absorver o ajuste sem quebrar as regras, reduzir o longão à maior distância permitida pelo total real (ou apresentar distribuição inviável), em vez de superar 40%.

### 4.3 Reteste sem método definido

Um reteste sem seleção Cooper/3 km continua ocupando um dia do calendário, mas não possui distância final conhecida.

V100 deve manter uma faixa provisória e estado `PENDING_PROTOCOL`:

- Não transformar o reteste em 0 km.
- Não assumir 5,0 km como se fosse a sua distância final.
- Não bloquear toda a migração do ciclo por uma pequena diferença de arredondamento enquanto o método ainda não foi escolhido, quando a semana pode ser reconciliada dentro da meta.
- Preservar o slot, data e instrução para escolher Cooper ou 3 km no dia programado.
- Depois da escolha, usar a distância total prescrita da sessão (aquecimento + protocolo + recuperações/desaquecimento, quando fizerem parte do treino), e não apenas a distância cronometrada do teste, para validar o volume semanal.
- Se o protocolo escolhido deixar o longão acima de 40%, redistribuir dentro da meta semanal e dos dias já configurados; se não existir distribuição válida, informar o conflito específico antes de aplicar a semana.

A recalibração do motor não deve depender da escolha antecipada do protocolo futuro: pode preservar o reteste pendente e atualizar as demais semanas/sessões permitidas dentro do ciclo, deixando a validação final daquele bloco condicionada à escolha.

### 4.4 Diagnóstico mais útil

A mensagem ao corredor deve ser curta e orientada à ação, por exemplo:

“Semana de 07/12: a meta é 17,0 km, mas as sessões estimadas somam 16,9 km antes da definição do reteste. O motor vai reconciliar os 100 m dentro da carga já aprovada. O limite do longão permanece 40%.”

Quando não houver distribuição válida, apresentar as distâncias efetivas, o total calculado, a meta e qual sessão não pode ser ajustada. Não repetir uma lista extensa de IDs no modal principal; manter detalhes técnicos em log de diagnóstico.

---

## 5. Modernização do calendário

### 5.1 Causas confirmadas no código

Arquivos examinados:

- `android/app/src/main/java/com/airunningcoach/app/MainActivity.kt`
- `android/app/src/main/java/com/airunningcoach/app/WorkoutCalendarPresentation.kt`
- `android/app/src/main/java/com/airunningcoach/app/TrainingTypeCatalog.kt`
- `android/app/src/test/java/com/airunningcoach/app/WorkoutCalendarPresentationTest.kt`

Na grade mensal:

- Cada célula tem altura fixa de **94 dp**.
- A célula mostra data, pictograma e título com até duas linhas (8,5 sp).
- `calendarWorkoutTitle()` ainda pode devolver o título legado, incluindo “Rodagem aeróbia” ou “Longão aeróbio”.
- `CoachEngine` e `TrainingTypeCatalog` ainda usam títulos híbridos como “Rodagem regenerativa”.
- A função `calendarCategoryShort()` já produz abreviações como REG, ROD, FAR e INT, mas **não é usada pela grade mensal**; também retorna categorias separadas LIM, LONG e não trata PROVA/TESTE de forma padronizada.
- Os ícones são caracteres Unicode (`☾`, `◉`, `ϟ`, `∿`, `⌁`, `➚`) enquanto a prova usa emoji (`🏁`). Não pertencem ao mesmo conjunto visual de ícones.
- Quando existe prova em uma data, a grade mostra somente o marcador de prova e oculta o marcador do treino daquele mesmo dia.
- Quando existem vários treinos no mesmo dia, mostra somente o primeiro e um contador `+N`.

Esses pontos explicam a aparência esticada, os nomes indesejados e a diferença de estilo entre os ícones.

### 5.2 Taxonomia única de calendário

A V100 deverá usar uma família por sessão, sem nomes compostos ou termos “aeróbio/aeróbia” na apresentação do calendário.

| Código | Família exibida | Regra de classificação |
|---|---|---|
| INI | Iniciação | Somente protocolo explícito de caminhada/corrida |
| REG | Regenerativo | Recuperação/regenerativo; nunca “Rodagem regenerativa” |
| ROD | Rodagem | Fácil, contínua, progressiva ou regressiva sem estímulo de qualidade |
| FAR | Fartlek | Qualquer variação de fartlek |
| INT | Intervalado/qualidade | Intervalos, limiar, tempo run e demais sessões de qualidade |
| LNG | Longão | Longo, progressivo, regressivo ou reduzido |
| PRV | Prova | Competição cadastrada |
| TES | Teste | Cooper ou teste de 3 km |

“Limiar/Qualidade” e “Intervalado” devem ser reunidos em INT para o calendário. A classificação interna e o conteúdo detalhado do treino permanecem preservados; somente a representação do calendário é simplificada.

“INI” só deve ser usado quando o treino for realmente do protocolo de iniciação/caminhada-corrida. Ser classificado como iniciante não transforma automaticamente qualquer sessão em INI.

### 5.3 Layout compacto da grade mensal

Proposta:

- Reduzir célula de 94 dp para **66–70 dp** (altura fixa e uniforme).
- Número do dia no topo, ícone colorido central de aproximadamente 24 dp e sigla de 3 letras abaixo, em uma única linha.
- Remover títulos longos e descrições do interior da célula mensal.
- Usar `REG`, `ROD`, `FAR`, `INT`, `LNG`, `PRV`, `TES` e `INI`.
- Em dias com vários itens, mostrar até dois ícones e um `+N`; tocar no dia abre a lista completa.
- Em dia com prova e treino, mostrar ambos (bandeira + ícone do treino), sem esconder um deles.
- Calcular dinamicamente se o mês precisa de 4, 5 ou 6 linhas, em vez de reservar sempre 42 dias quando a grade não precisar de seis semanas.
- Reduzir espaçamento vertical entre semanas e entre a grade e o detalhe do dia.
- Manter o modo Semana e os detalhes completos do treino ao tocar; o resumo curto é exclusivo da grade mensal.

### 5.4 Conjunto de ícones coloridos próprio

Substituir glyphs Unicode/emoji por ícones vetoriais próprios em um único padrão visual:

- mesmo canvas, dimensões, contorno, espessura e fundo arredondado;
- cada família com cor própria e contraste acessível;
- bandeira da prova desenhada no mesmo estilo vetorial, não como emoji de fonte;
- teste com alvo/cronômetro vetorial;
- regenerativo com lua vetorial;
- rodagem com corredor/pegada;
- fartlek com percurso ondulado;
- intervalado com raio/cronômetro;
- longão com corredor e seta de distância;
- iniciação com combinação caminhada/corrida.

Os estados Concluído e Não realizado devem ser pequenos marcadores sobrepostos no canto do ícone (✓ verde e × coral), sem mudar o tamanho ou a altura da célula.

A legenda deve usar os mesmos ícones e as siglas; nomes completos podem aparecer como descrição acessível/tooltip, sem ocupar as células do mês.

### 5.5 Normalização de título sem alterar histórico

- A grade mensal nunca deve usar `workout.title` bruto como fallback visual.
- Resolver categoria a partir de `type` e `stimulus` estruturados; só usar título legado como último recurso de classificação.
- Normalizar títulos legados “Rodagem aeróbia”, “Rodagem progressiva aeróbia”, “Longão aeróbio” e “Rodagem regenerativa” para as siglas correspondentes.
- Não alterar o texto original salvo no backup nem o conteúdo detalhado do treino; a mudança é de apresentação do calendário.
- Os rótulos “Aeróbio” e “Aeróbia” não devem aparecer na grade mensal nem na legenda.

---

## 6. Escopo técnico por arquivo

| Arquivo | Alteração prevista |
|---|---|
| `MainActivity.kt` | Não deixar assinatura do objetivo derrubar ciclo ativo; congelar semana em andamento durante migração do motor; separar migração de motor de criação de ciclo; reduzir/encurtar rótulos no calendário; passar estado e sessões ao grid compacto |
| `PlanMigrationEngine.kt` | Estado explícito do ciclo, recuperação de âncora de backups antigos e decisão de completar ciclo somente após Semana 8 fechada |
| `RunningCoachEngine.kt` / `CoachEngine.kt` | Atualizar conteúdo de sessões futuras dentro dos slots do ciclo existente; não criar novo ciclo em migração de versão |
| `TrainingCalendarIntegrityEngine.kt` | Validar volume em metros e somente após reconciliação do total semanal; reconhecer reteste pendente sem distância final |
| `WeeklySessionDistributionEngine.kt` | Distribuir a meta semanal exata antes de validar 40%, com ajuste interno não-longão quando possível |
| `RacePlanningEngine.kt` | Manter frequência/dias/slots do ciclo; prova substitui apenas uma sessão compatível; não redefinir ciclo |
| `WorkoutCalendarPresentation.kt` | Unificar as oito famílias, siglas, descrição acessível e resolução de títulos legados |
| `MainActivity.kt` (composables) | Célula compacta, ícones vetoriais coloridos, múltiplos marcadores por dia e legenda padronizada |
| `AppBackupManager.kt` / `AppBackupCodec.kt` | Schema 14, persistência e migração de `cycleId`, âncora, duração e estado |
| Testes Kotlin | Regressão de ciclo, distribuição, migração e apresentação compacta |

---

## 7. Testes obrigatórios V100

### Ciclo e backup

1. Restaurar backup motor 83 na Semana 3 de ciclo de 8 semanas: manter a âncora e `planWeeks = 8`.
2. Preservar integralmente semanas 1 e 2, feedbacks e atividades realizadas.
3. Preservar integralmente a Semana 3, inclusive sessões pendentes dentro da semana.
4. Atualizar apenas conteúdo de sessões futuras das semanas 4–8, mantendo datas, dias, frequência e metas semanais do ciclo.
5. Motor antigo + assinatura de objetivo antiga/diferente não pode iniciar novo ciclo durante migração.
6. Mudança de objetivo no meio do ciclo fica pendente para o próximo ciclo; não altera a âncora atual.
7. Backup legado sem `cycleId`: inferir ciclo por datas/números de semana sem reiniciar quando houver evidência consistente.
8. Backup com âncora ambígua: preservar o plano e pedir decisão, sem gerar ciclo novo automaticamente.
9. Semana 7 ou anterior: novo ciclo indisponível.
10. Semana 8 com sessões futuras pendentes: novo ciclo indisponível.
11. Após encerramento completo da Semana 8: oferecer início do próximo ciclo, sem apagar o anterior.
12. Falha durante migração: restaurar transacionalmente todos os campos e o plano original.

### Longão e volume

13. Reproduzir 6,8 + 5,1 + reteste Cooper de sessão 5,0 km, meta 17 km: reconciliar os 100 m dentro da meta e aprovar 6,8/17,0 = 40,0%, se a dose e o estímulo forem compatíveis.
14. Nunca aceitar uma proporção real superior a 40%, mesmo que a tela mostre somente uma casa decimal.
15. Todos os cálculos internos devem usar metros inteiros; a formatação da interface não pode alterar o resultado.
16. Reteste sem método permanece pendente e não gera bloqueio definitivo por distância provisória.
17. Depois de selecionar Cooper/3 km, usar a distância total da sessão e validar a semana.
18. Se a distribuição dentro da meta não for possível, manter o longão até o teto e explicar a incompatibilidade sem elevar a carga total.
19. Objetivo 5 km: piso de 5 km nas sessões regulares continua válido, exceto semana Regenerativa e protocolo inicial caminhada/corrida.
20. Longão continua sendo a maior sessão da semana e não pode ser removido por prova curta.

### Calendário

21. Nenhuma célula mensal exibe “aeróbio” ou “aeróbia”.
22. Sessão regenerativa exibe apenas `REG`, nunca “Rodagem regenerativa”.
23. Rodagem progressiva/regressiva exibe `ROD`.
24. Fartlek exibe `FAR`.
25. Intervalado/limiar/qualidade exibe `INT`.
26. Iniciação caminhada/corrida exibe `INI` somente quando o protocolo estiver ativo.
27. Longão, prova e teste exibem `LNG`, `PRV` e `TES`.
28. Células têm altura uniforme entre 66–70 dp e label de uma linha.
29. Mês com cinco linhas não reserva uma sexta linha vazia; mês que exige seis linhas mantém seis.
30. Dia com prova e treino mostra os dois ícones; múltiplos treinos mostram `+N` sem ocultar categoria.
31. Ícones usam vetores coloridos, com mesma geometria visual e estados de conclusão consistentes.
32. Modo Semana e detalhe do dia continuam exibindo título completo, distância, horário e status.

### Build e compatibilidade

33. Schema 14 restaura backups 1–14.
34. Exportar backup V100 e restaurar em uma instalação limpa preserva ciclo, estado, semanas, treinos e testes.
35. Gradle/JUnit oficial, `assembleDebug` e GitHub Actions aprovados.
36. Testar visualmente em Android 16, incluindo telas estreitas e meses com quatro, cinco e seis linhas.

---

## 8. Critérios de aprovação

A V100 só será considerada concluída quando:

- um backup da Semana 3 continuar sendo o mesmo ciclo de oito semanas após atualizar o motor;
- a Semana 3 permanecer inalterada durante a migração;
- as semanas futuras forem atualizadas dentro do mesmo ciclo, sem alterar âncora ou frequência;
- nenhum novo ciclo for criado antes da conclusão efetiva da Semana 8;
- a diferença de 100 m do exemplo de 17 km for reconciliada sem ultrapassar a meta nem o teto de 40%;
- o reteste sem método permanecer pendente, não definitivo;
- o calendário mensal usar ícones vetoriais coloridos, siglas curtas e células compactas;
- “aeróbio/aeróbia” e “Rodagem regenerativa” não aparecerem na grade mensal/legenda;
- os backups antigos continuarem restauráveis;
- CI e build Android forem aprovados.

## 9. Parecer final

O erro de recalibração não deve ser resolvido removendo o limite de 40%. A imagem mostra uma composição provisória máxima de 16,9 km frente a uma meta registrada de 17,0 km; a V100 precisa reconciliar os 100 m dentro da carga aprovada e aguardar a definição do reteste para validar sua distância final.

O problema maior é de ciclo: a V99 pode preservar a âncora em condições específicas, mas a geração do plano ainda pode reescrever sessões da semana atual durante a migração do motor, e a assinatura do objetivo pode impedir a preservação. A V100 deve transformar o ciclo de oito semanas em uma entidade persistida e protegida.

No calendário, a correção é objetiva: a grade mensal deve deixar de exibir títulos longos. Cada dia terá o número, um ou mais ícones próprios e siglas; o detalhe completo fica ao tocar no dia. Os tipos serão INI, REG, ROD, FAR, INT, LNG, PRV e TES.

**Status:** auditoria V99 concluída; plano V100 elaborado; implementação ainda não realizada.
