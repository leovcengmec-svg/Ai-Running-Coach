# AI Running Coach — Plano de correção V100

**Auditoria da V99 · 26/11/2026**  
**Status:** causas identificadas no código e plano de correção elaborado. A implementação V100 ainda não foi realizada.

## 1. Identificação da próxima versão

| Item | Proposta |
|---|---:|
| VersionCode | 100 |
| VersionName | V100 |
| Motor interno | 90 |
| Base | V99 |
| Backup Schema | 13 (manter) |
| Compatibilidade | Leitura dos schemas 1–13 |

A correção do reteste e a modernização do calendário não exigem novos dados persistidos. O `RetestOriginalSessionSnapshot` já guarda a sessão substituída, incluindo `distanceKm`. O calendário também já possui a classificação canônica e a função de siglas. Portanto, a V100 deve reutilizar esses dados e ajustar os fluxos de validação/apresentação, sem criar migração de backup desnecessária.

---

## 2. Imagens 1 e 2 — Recalibração do backup antigo continua bloqueada

### O que a captura comprova

O diálogo informa:
- motor do backup: 83;
- motor atual da V99: 89;
- recalibração recusada para preservar o plano importado;
- semana de 07/12/2026 com longão de 6,8 km;
- reteste fisiológico ainda sem método;
- Fartlek de 5,1 km;
- meta semanal registrada de 17,0 km;
- composição conhecida informada de 11,9 km;
- participação mínima calculada: 40,2%.

A restauração do arquivo não está falhando. O backup é lido, o plano anterior fica preservado e a operação de recalibração é recusada pela validação final. A causa precisa ser corrigida na composição da semana, não no parser geral de backup.

### Causa confirmada no código

Arquivos envolvidos:
- `android/app/src/main/java/com/airunningcoach/app/MainActivity.kt`
- `android/app/src/main/java/com/airunningcoach/app/RetestCycleEngine.kt`
- `android/app/src/main/java/com/airunningcoach/app/TrainingCalendarIntegrityEngine.kt`

No fluxo `scheduleFourWeekRetest()`, o motor substitui uma sessão planejada pelo reteste sem método. Antes da substituição, ele guarda a sessão original em:

`RetestOriginalSessionSnapshot.from(original)`

O snapshot já preserva, entre outros campos:
- título e tipo da sessão original;
- estímulo;
- `distanceKm`;
- duração;
- blocos/segmentos;
- instruções e justificativa.

Entretanto, em `TrainingCalendarIntegrityEngine.validate()`, quando o reteste ainda não tem protocolo, o orçamento de distância é estimado com uma constante:

`maximumPendingRetestKm = undecidedRetests.size * 5.0`

O cálculo ignora `workout.retestOriginalSession.distanceKm`, apesar de esse valor representar exatamente a sessão substituída. O valor fixo de 5,0 km é tratado como distância da sessão completa, embora o limite de distância do Cooper seja referente ao bloco de 12 minutos; a prescrição total também contempla aquecimento e desaquecimento.

### Reconstrução da inconsistência da imagem

A semana apresenta:

| Componente | Distância |
|---|---:|
| Longão regressivo | 6,8 km |
| Fartlek variável | 5,1 km |
| Sessão original substituída pelo reteste (snapshot) | 5,1 km |
| **Total reservado** | **17,0 km** |

Com o orçamento correto do slot substituído:

`6,8 / (6,8 + 5,1 + 5,1) = 40,0%`

Com a constante usada atualmente pela V99:

`6,8 / (6,8 + 5,1 + 5,0) = 40,2367%`, exibido como `40,2%`.

A evidência da captura é compatível com essa divergência de 0,1 km. A V100 deve confirmar o valor concreto do snapshot durante o teste de regressão, usando um backup de reprodução. Não deve assumir que toda sessão de reteste vale 5,1 km: deve recuperar o valor que foi realmente substituído em cada backup.

### Correção V100 — orçamento real do slot substituído

A validação deve determinar a distância reservada do reteste pendente com esta precedência:

1. **Snapshot original válido:** usar `retestOriginalSession.distanceKm`, se for finito e maior que zero. É a fonte preferencial, pois o reteste substitui aquele slot e não acrescenta uma sessão.
2. **Protocolo já escolhido:** usar `distanceKm` da sessão efetivamente montada pelo `RetestProtocolEngine`, incluindo aquecimento, bloco principal e desaquecimento estimados.
3. **Backup antigo sem snapshot:** estimar a distância total da sessão para os protocolos elegíveis com `RetestDistanceEstimator` e `RetestProtocolEngine`, usando a avaliação fisiológica ativa mais recente. Não usar o limite de distância do bloco de teste como se fosse a distância total da sessão.
4. **Sem estimativa confiável:** preservar o reteste como compromisso de agenda com distância pendente e adiar somente a verificação exata de participação do longão até a escolha do protocolo. Não tratar como 0 km, nem inventar 5 km.

Regras adicionais:
- Cada reteste substitui um único slot original; nunca somar o snapshot e a sessão de reteste como duas sessões.
- Em semanas com mais de um reteste pendente, cada orçamento deve ser vinculado ao seu próprio ID/slot e deduplicado por instância.
- Quando o método for selecionado, o orçamento do snapshot deixa de ser usado; passa a valer a distância completa da sessão montada pelo protocolo escolhido.
- Se o backup antigo não tiver snapshot e houver distância estimada parcial, registrar a incerteza e não bloquear o plano por uma constante genérica.
- O motor pode recalibrar as demais semanas futuras, preservando a sessão de teste pendente e a semana atual congelada conforme as regras existentes.

### A regra de 40% não será enfraquecida

A V100 deve manter o teto de 40% para cada semana futura completa. Também deve manter:
- longão como maior sessão;
- no máximo um longão principal por semana;
- prova contabilizada uma única vez;
- sessão substituída não pode continuar somada ao lado da prova ou do reteste;
- piso de 5 km para sessões regulares em plano contínuo com objetivo de 5 km, exceto semana Regenerativa e protocolo inicial caminhada/corrida;
- sem aumento silencioso do volume semanal.

O limite exato de 40,0% deve ser aceito; valores realmente acima de 40,0% continuam bloqueados. Os cálculos devem usar os valores completos, sem arredondar para uma casa decimal antes da comparação. A formatação de 40,0%/40,1% deve ocorrer apenas na mensagem.

### Diagnóstico curto ao corredor e detalhes técnicos

Mensagem ao usuário deve explicar o problema de forma útil, sem despejar IDs longos:

- semana e intervalo;
- distância do longão;
- distância total planejada/reservada;
- participação calculada;
- status do reteste (slot original preservado ou protocolo pendente);
- orientação concreta para prosseguir.

O relatório técnico/log deve conter:
- `sessionId` do reteste;
- `retestOriginalSession.distanceKm`;
- valor de fallback, quando houver;
- distância depois da escolha do protocolo;
- lista final das sessões únicas da semana;
- meta semanal registrada;
- total considerado e percentual sem arredondamento.

Não mostrar uma composição conhecida de 11,9 km como se fosse o volume final de 17,0 km. Distinguir “quilometragem conhecida” de “quilometragem reservada para o reteste”.

---

## 3. Imagens 3 e 4 — Calendário alto e com títulos extensos

### Causas confirmadas no código V99

Arquivo: `android/app/src/main/java/com/airunningcoach/app/MainActivity.kt`.

Na função `CalendarScreen()`:
- a grade mensal cria sempre 42 datas (`0 until 42`), resultando em seis linhas mesmo quando um mês precisa de quatro ou cinco;
- cada célula usa altura fixa `94.dp`;
- cada célula pode mostrar ícone e o texto de `calendarWorkoutTitle()` com até duas linhas;
- `calendarWorkoutTitle()` reutiliza trechos de títulos completos, que podem conter “Rodagem aeróbia”, “Longão aeróbio” ou nomes progressivos/regenerativos.

A função `calendarCategoryShort()` já existe, com abreviações REG, ROD, INT, FAR, LIM, LONG, PROVA e TESTE, mas não é utilizada na grade mensal.

A legenda já contém as oito famílias canônicas do calendário. Portanto, o problema não é falta de categorias; é a grade deixar de usar a categoria normalizada e exibir o título de origem do treino.

### Regra de apresentação V100

O calendário deve trabalhar exclusivamente com as oito famílias já definidas em `WorkoutCalendarCategory.resolve()`:

| Sigla no calendário | Categoria canônica |
|---|---|
| REG | Regenerativo |
| ROD | Rodagem |
| INT | Intervalado |
| FAR | Fartlek |
| LIM | Limiar/Qualidade |
| LNG | Longão |
| PRV | Prova |
| TST | Teste |

A sessão recebe **uma única categoria**. Exemplos:
- uma sessão de recuperação é REG;
- uma sessão aeróbia comum é ROD;
- uma sessão longa é LNG;
- um fartlek é FAR;
- uma sessão intervalada é INT.

Não exibir “Rodagem aeróbia”, “Longão aeróbio” ou combinação “Rodagem regenerativa” dentro das células do calendário. Os termos internos antigos podem continuar existindo nos dados e nos motores para compatibilidade; a camada de apresentação deve traduzi-los para a categoria única.

### Grade mensal compacta

Proposta de layout:
- reduzir a altura das células de 94 dp para aproximadamente 66–70 dp;
- mostrar somente o número do dia e siglas curtas;
- remover o título completo e o ícone grande da célula mensal;
- usar uma pequena cápsula colorida por categoria, com REG/ROD/INT/FAR/LIM/LNG/PRV/TST;
- estado concluído: pequeno ✓;
- estado não realizado: pequeno ×;
- pendente: sem selo extra;
- quando houver mais de um compromisso no mesmo dia, mostrar até duas siglas e `+N`, sem expandir a altura da semana;
- prova e teste devem usar PRV e TST, mantendo cores distintas.

A altura sugerida é uma meta de implementação, não um novo dado do domínio. Deve ser validada em telas estreitas, fontes maiores e acessibilidade Android.

### Número de linhas do mês

Substituir a lista fixa de 42 dias por uma grade dinâmica que use 4, 5 ou 6 semanas conforme o mês e o primeiro dia da semana. Novembro de 2026 exige seis linhas; nesse mês, a compactação de cada linha é especialmente importante.

### Dia selecionado e visualização semanal

- O toque em uma data continua abrindo a agenda daquele dia.
- A linha do treino deve começar com a sigla/categoria curta e mostrar distância e estado de forma compacta.
- O título operacional completo pode aparecer ao abrir os detalhes da sessão, não deve dominar a grade mensal.
- A visualização semanal deve usar a mesma classificação curta, sem voltar a exibir “Aeróbio/Aeróbia” como tipo do calendário.
- Manter o toque para abrir o treino, editar feedback e consultar blocos.

### Legenda

Manter as oito categorias da legenda atual, mas torná-la compacta e coerente com as siglas:

- REG — Regenerativo
- ROD — Rodagem
- INT — Intervalado
- FAR — Fartlek
- LIM — Limiar/Qualidade
- LNG — Longão
- PRV — Prova
- TST — Teste

Organizar em grade equilibrada (preferencialmente quatro colunas por duas linhas em celulares que comportem; caso contrário, duas colunas), com a sigla em destaque e nome completo menor. Manter a legenda de status ✓ Concluído e × Não realizado.

A cor não pode ser o único identificador: sigla e descrição semântica devem continuar disponíveis para acessibilidade.

---

## 4. Arquivos e componentes envolvidos

| Arquivo/componente | Alteração V100 |
|---|---|
| `TrainingCalendarIntegrityEngine.kt` | usar distância reservada do snapshot original do reteste pendente; fallback por protocolo completo; cálculo sem arredondamento prematuro |
| `RetestCycleEngine.kt` | reutilizar e validar `RetestOriginalSessionSnapshot`; garantir distância original disponível nos backups já suportados |
| `RetestProtocolEngine.kt` | estimar a distância total dos dois protocolos elegíveis, incluindo aquecimento e desaquecimento |
| `CooperAssessmentEngine.kt` / `RetestDistanceEstimator` | fornecer estimativas por método sem converter distância do bloco principal em distância total da sessão |
| `MainActivity.kt` / `createPlan()` | validar a composição final após migração, preservando a transação e sessões concluídas |
| `MainActivity.kt` / `CalendarScreen()` | grade compacta, dinâmica e com siglas |
| `WorkoutCalendarPresentation.kt` | expor siglas canônicas, categoria única, acessibilidade e status |
| `WorkoutCalendarPresentationTest.kt` | testar siglas, categorias e nomes apresentados |
| `TrainingCalendarIntegrityEngineTest.kt` | adicionar os casos de orçamento retido do slot e restauração de backups antigos |
| `AppBackupCodecTest.kt` / `PlanMigrationEngineTest.kt` | round-trip de snapshot e migração sem perda da distância original |

---

## 5. Testes obrigatórios V100

### Recalibração e reteste

1. Backup V83 com reteste pendente e snapshot de sessão original de 5,1 km: usar 5,1 km, não o limite fixo de 5,0 km.
2. Semana com longão 6,8 km + Fartlek 5,1 km + slot de reteste 5,1 km: total 17,0 km; aprovar exatamente 40,0%.
3. Mesmo cenário com orçamento do slot 5,0 km e volume real 16,9 km: bloquear como acima de 40%, sem tolerância indevida.
4. Sessão substituída não pode ser somada junto ao reteste.
5. Snapshot com distância zero, negativa, NaN ou ausente: ignorar como orçamento inválido e utilizar fallback explícito.
6. Backup antigo sem snapshot: estimar sessão completa Cooper e 3 km, usando somente métodos elegíveis.
7. Estimativa parcial sem base fisiológica suficiente: manter o reteste pendente e adiar somente a validação exata, sem convertê-lo em 0 km.
8. Depois da seleção Cooper: usar a distância total estimada/registrada do aquecimento + 12 minutos + desaquecimento.
9. Depois da seleção 3 km: usar aquecimento + 3 km + desaquecimento.
10. A seleção do protocolo substitui o orçamento original, sem somá-lo ao treino definitivo.
11. Backup motor 83 restaurado no motor 90: atualizar apenas sessões futuras e preservar concluídos, feedbacks, atividades, datas reais, provas e avaliações fisiológicas.
12. Se uma semana futura completa realmente exceder 40%, bloquear com diagnóstico claro e preservar o plano importado.
13. A semana atual parcial não pode ser bloqueada pela composição remanescente.
14. Longão continua sendo a maior sessão e não pode existir mais de um longão principal na mesma semana.
15. Provas entram uma única vez na composição semanal; sessões substituídas não permanecem duplicadas.

### Calendário

16. Categoria REG apresenta apenas REG na célula, nunca “Rodagem regenerativa”.
17. Categoria ROD apresenta apenas ROD, nunca “Rodagem aeróbia”.
18. Longão apresenta LNG, nunca “Longão aeróbio”.
19. Fartlek, intervalado, limiar, prova e teste apresentam FAR, INT, LIM, PRV e TST.
20. Cada sessão recebe exatamente uma das oito categorias canônicas.
21. Mês que ocupa quatro, cinco e seis semanas renderiza o número correto de linhas.
22. Células mensais mantêm altura compacta em telas estreitas e com escala de fonte ampliada.
23. Dois treinos na mesma data mostram siglas compactas e `+N`, sem aumentar a linha.
24. ✓ e × permanecem distinguíveis em célula compacta.
25. Toque na data continua exibindo as sessões correspondentes.
26. Toque na sigla/linha abre o detalhe correto da sessão.
27. Visualização mensal, semanal e agenda do dia usam a mesma categoria abreviada.
28. Legenda apresenta os oito códigos com seus nomes completos e status.

---

## 6. Critérios de aprovação

A V100 somente será considerada concluída quando:

- a restauração de backup antigo e a recalibração pelo motor atual forem aprovadas no cenário V83 → V90;
- o slot original do reteste for usado na validação enquanto o método estiver pendente;
- o caso 6,8 + 5,1 + 5,1 km resultar em 40,0% e não for bloqueado;
- um caso verdadeiramente acima de 40% continuar bloqueado;
- protocolo escolhido substituir o orçamento provisório sem duplicidade;
- nenhuma sessão concluída ou feedback for alterado;
- o calendário usar siglas e não exibir “Aeróbio/Aeróbia” nem nomes compostos de categoria nas células;
- o calendário mensal usar células compactas e linhas de semana sem altura exagerada;
- os 28 testes acima passarem;
- `:app:testDebugUnitTest` e `:app:assembleDebug` passarem no GitHub Actions;
- o APK for instalado e verificado no Android 16.

---

## 7. Parecer final

O bloqueio da recalibração V99 tem uma explicação concreta no código: o snapshot da sessão substituída pelo reteste já guarda a distância original, mas o validador utiliza 5,0 km fixos para representar toda a sessão pendente. A captura mostra uma semana cuja meta é 17,0 km e cuja composição parece reservar 5,1 km para o slot substituído; a constante de 5,0 km reduz o denominador para 16,9 km e transforma 40,0% em 40,2%. A V100 deve corrigir a fonte do orçamento, não relaxar o teto.

O calendário também tem causa objetiva: altura fixa de 94 dp, 42 dias sempre renderizados e título completo na célula; `calendarCategoryShort()` existe, mas não é usada. A V100 deve utilizar as oito categorias já definidas, exibir somente as siglas nas células e reduzir a altura da grade.

**Recomendação:** tratar a V100 como uma atualização integrada de validação de reteste + apresentação do calendário. Não alterar o Backup Schema 13 e não reescrever tipos internos antigos: corrigir a distância reservada usando o snapshot persistido e normalizar os nomes somente na camada visual.

**Status:** auditoria V99 concluída; plano V100 elaborado; implementação ainda não realizada.
