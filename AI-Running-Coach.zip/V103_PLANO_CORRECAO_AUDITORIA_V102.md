# AI Running Coach — Plano V103 aplicado

**Origem:** auditoria da V102 e revisão 3 do plano de calibração  
**Data:** 27/11/2026  
**Status:** implementado no código-fonte; build Android pendente de CI

## Escopo fechado

1. Semana regenerativa: 25% de referência, adaptável a evidências de recuperação/fadiga/RPE/carga/execução; base sempre a última semana de construção; não compensar sessões perdidas; não empilhar com taper da competição. A tela expandida explicita volume-base, percentual e meta regenerativa.
2. Status no calendário: check verde/branco para concluído, X coral/branco para não realizado, selo maior e vetorial, sem ocultar modalidade.
3. Gerenciar perfil: ícones vetoriais de uma família única, dimensões consistentes e tiles compactos.
4. Próximo evento: união cronológica de treinos pendentes e provas planejadas (preparatórias, principais ou classificadas como treino); cancelar/concluir remove da seleção.
5. Calibração: comparação apenas entre testes do mesmo protocolo; teste melhora ≥2% inicia nova fase; resultado equivalente preserva; resultado pior preserva e ativa trava; protocolo incomparável põe créditos em espera. Zona-base vem do resultado do teste atual, sem ajuste artificial de 15 segundos.
6. Acúmulo pré-reteste: Lote A = 5 blocos / 3 sessões / até 3%; Lote B = outros 5 blocos / 3 sessões posteriores / até 2%; os lotes independentes podem ser reconhecidos na mesma revisão de 28 dias. Teto de origem 5% e limites efetivos Z1 15%, Z2 10%, Z3 5%. Confirmação manual preservada.
7. Monitoramento: mínimo formal 4 sessões comparáveis; 1–3 sessões mostram prévia descritiva sem percentuais; datas, janela, tipo, terreno e exclusões são expostos; longão separado; nenhum ajuste automático de zonas.

## Backup e migração

Schema 15 acrescenta metadados da calibração no JSON já persistido. Backups 1–14 permanecem legíveis. Não existe migração destrutiva; propriedades ausentes usam defaults seguros. Dados de histórico, treinos concluídos, feedbacks e ciclos permanecem no formato anterior.

## Critérios de aceite desta entrega

- 16 cenários no harness local passaram.
- Testes JUnit de regressão foram adicionados ao source set Android.
- O código-fonte está atualizado para V103.
- Build Gradle/Android e APK ficam pendentes do workflow GitHub Actions; não são declarados como aprovados nesta execução.
