# Training Periodization V63

## Horizonte
A duração recomendada é específica do objetivo, nível e volume atual e pode chegar a 52 semanas. Um ciclo mais longo não é comprimido automaticamente em 8–16 semanas.

## Fases
- BASE: consistência e capacidade aeróbia.
- DEVELOPMENT: desenvolvimento de resistência, limiar e intervalados elegíveis.
- SPECIFIC: estímulos direcionados ao objetivo e à prova principal.
- RECOVERY: redução de carga para consolidação ou necessidade observada.
- TAPER: polimento antes de prova A.
- POST_RACE: transição/retorno após prova A, conforme resposta registrada.

Percentuais das fases são heurísticas de planejamento, não modelos fisiológicos universais.

## Objetivos
O catálogo suporta milha, 3 km, 5 km, 10 km, 15 km, 10 milhas/20 km, 20–30 km, meia maratona, maratona, ultradistâncias até 200 km, saúde e objetivo personalizado.

O objetivo de saúde prioriza movimento, regularidade e atividade confortável. Não ativa automaticamente estímulos de limiar/VO₂.

## Seleção de sessões
`TrainingPeriodizationEngine` seleciona sessões por distância, fase, nível operacional, frequência, volume, maior corrida recente, zonas, consistência, dor e recuperação. Tipos existentes incluem contínuos, progressivos/regressivos, longões, intervalados aeróbios/mistos, limiar, fartlek, piramidal, maratona e ultra.

Treinos de subida dependem de terreno e elevação conhecidos. Força está disponível como complemento opcional e não é inserida automaticamente na frequência de corrida.

## Competições A/B/C
- A: única prioridade que comanda macrociclo e pode acionar taper.
- B: substitui uma sessão na semana do evento, sem taper automático ou desmontagem do ciclo.
- C: evento de treinamento; substitui sessão quando aplicável, sem comandar a preparação.

A prova B/C não deve assumir a posição da prova A durante a geração ou restauração de planos.

## Preservação
Migração V62→V63 incrementa `engineVersion` para 49. Treinos concluídos, feedbacks, histórico e âncora do ciclo são preservados; somente sessões futuras podem ser recalculadas.
