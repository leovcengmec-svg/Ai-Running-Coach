# Motor de prescrição V66 — especificação e auditoria

## Fonte de projeto: planilha do usuário

A planilha `1794785784588-8e94881f-a79e-49aa-968b-bdb2c9a962d0.xlsx` tem nove abas. As mais úteis para o produto foram:

- `TREINOS PRONTOS`: protocolos identificados por códigos (F01/F02, I01–I09, IE01/II01, T01–T05, L01/L02, CC01 e outros).
- `PROTOCOLOS`: descreve zonas de trabalho e recuperação, frequência mínima, uso e finalidade. F01 é Fartlek leve Z2–Z3 com recuperação Z1; F02 é mais intenso e requer mais frequência/base; T01/T04 descrevem Tempo Run e Cruise/Tempo intervalado.
- `MOTOR V11`: matriz de sessão por objetivo e fase (base, desenvolvimento, específico, recuperação, manutenção/taper) com vagas Q1/Q2/longão/fácil. Foi reaproveitada a arquitetura, não as fórmulas literais.
- `PISO CORRIDA`: separa zona fisiológica e locomoção corrida/caminhada, útil para evitar pace irreal em transição.
- `TESTE DE CORRIDA` e `TESTE DE VELOCIDADE CRÍTICA`: propõem avaliações adicionais; várias fórmulas aparecem com erros (#REF!, #VALUE!, #DIV/0!) e não foram usadas sem correção/validação.

A aba `TREINOS PRONTOS` tinha limites genéricos fixos de VO₂ (`<42`, `42–52`, `53–64`, `≥65`); não foi importada, pois o app usa uma referência de aptidão cardiorrespiratória por idade e sexo. A referência populacional não deve ser confundida com níveis competitivos de corrida.

## Seleção de sessões

O protocolo agora é escolhido por combinação de:

1. Distância-alvo (por exemplo 5 km, 10 km ou meia maratona).
2. Intenção: completar, correr continuamente, melhorar recorde ou atingir tempo.
3. Fase do macrociclo.
4. Dias disponíveis e preferência do longão.
5. Volume recente, maior sessão, atividade nas últimas quatro semanas, dor, fadiga e recuperação.
6. Zonas de pace válidas e adequação do terreno.

Um VO₂max mais alto não libera sozinho intervalos fortes. Da mesma forma, o rótulo Iniciante não bloqueia automaticamente Z3/Z4: a carga e a prontidão decidem.

## Exemplo de validação de motor — 5 km / recorde pessoal

Perfil: três dias por semana (segunda/quarta/sexta), 16 km/semana, maior sessão recente 10 km, três semanas ativas em quatro, teste Cooper 2,1 km e zonas calibradas; ciclo de 10 semanas. O gerador produziu:

| Semana | Fase | Sessão de qualidade, quando selecionada | Observação |
|---:|---|---|---|
| 1 | Base | — | Entrada fácil + longão |
| 2 | Base | F01 Fartlek leve | Ativo Z2–Z3, recuperação Z1 |
| 3 | Base | F04 Fartlek variável | Varia Z2–Z3; Z4 só se carga e recuperação liberarem |
| 4 | Recuperação | — | Volume reduzido |
| 5 | Desenvolvimento | T01 Tempo Run | Sustentação de ritmo |
| 6 | Desenvolvimento | I04 Intervalado 3 min | Repetições controladas |
| 7 | Desenvolvimento | T04 Tempo intervalado | Acumular tempo de qualidade |
| 8 | Recuperação | — | Descarga |
| 9 | Específica | RP05 ritmo específico 5 km | Transferência para a meta |
| 10 | Específica | I07 intervalado 600 m | Estímulo de ritmo/potência aeróbia |

Para três dias/semana, o padrão é uma sessão de qualidade, uma rodagem fácil e um longão. Não se prescreve qualidade em toda sessão; isso preserva a maior parte do tempo em baixa intensidade. A progressão ocorre por tipo de estímulo e especificidade, não pela repetição do mesmo treino.

## VO₂max por idade/referência fisiológica

A implementação converte os cortes da Tabela 2 de Mandsager et al. de MET para ml/kg/min (1 MET = 3,5). `Iniciante` agrupa Low + Below Average; `Intermediário` começa em Above Average; `Performance` começa em High; `Elite` começa em Elite. Valores são pontos de corte da classe, não faixas absolutas de performance esportiva.

| Idade | Homens: Intermediário / Performance / Elite | Mulheres: Intermediário / Performance / Elite |
|---|---:|---:|---:|
| 18–19 | 45,5 / 49,0 / 57,1 | 38,9 / 45,5 / 52,5 |
| 20–29 | 42,0 / 48,0 / 55,0 | 35,0 / 40,3 / 50,1 |
| 30–39 | 39,2 / 45,5 / 52,5 | 32,9 / 38,2 / 48,0 |
| 40–49 | 38,5 / 43,8 / 51,5 | 31,5 / 36,4 / 46,6 |
| 50–59 | 35,0 / 39,9 / 49,0 | 28,4 / 35,0 / 45,5 |
| 60–69 | 29,8 / 35,0 / 45,5 | 24,5 / 29,8 / 38,9 |
| 70–79 | 24,5 / 29,8 / 40,3 | 21,0 / 24,5 / 35,0 |
| ≥80 | 22,1 / 25,6 / 35,0 | 19,3 / 22,1 / 29,4 |

Classification rule: VO₂ below first cut = Iniciante; between first and second = Intermediário; between second and third = Performance; equal/above third = Elite. For a field estimate of 35.65, the result cannot be classified without the test-age/reference snapshot: for men 40–49 it falls below the 38.5 threshold; for men 50–59 it is above the 35.0 threshold; for women 20–29 it is above the 35.0 threshold. If an old test lacks age/reference, the UI asks to attach the correct values for the date of the test before displaying a final band.

## Evidência usada

- Aandstad (2021) generated 3 km prediction equations in 259 adults aged 18–39; SEE was 3.3 ml/kg/min for men and 2.6 for women. This is a field estimate, not a laboratory measurement. https://pubmed.ncbi.nlm.nih.gov/33730971/
- Mandsager et al. (2018) provide age- and sex-stratified treadmill CRF cutoffs. The source's five performance groups are grouped into four app labels; these are population reference bands, not race-performance levels. https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2707428
- Systematic review in runners reports substantial use of low-intensity work and smaller moderate/high-intensity portions; training zone definitions vary by method. https://pubmed.ncbi.nlm.nih.gov/34749417/
- Individual participant network meta-analysis found no universal superiority of one intensity-distribution model across all endurance athletes; recreational and competitive subgroups may respond differently. https://pubmed.ncbi.nlm.nih.gov/39888556/

## Limitações

- A planilha apresenta fórmulas quebradas em algumas abas; elas não foram importadas.
- Não foi possível provar melhoria real de tempo sem observar sessões concluídas e novo teste de campo. A simulação valida seleção/estrutura do plano, não garante resultado.
- A zona Z4 permanece estimada enquanto não houver medida de limiar (lactato/gás).
- A equação de 3 km publicada por Aandstad foi estudada em adultos de 18–39 anos; fora desta faixa, a aplicação foi bloqueada para evitar extrapolação não validada.
- O APK e a suíte Gradle/JUnit completos precisam passar no GitHub Actions e ser testados em aparelho real.
