package com.airunningcoach.app

import org.junit.Assert.assertTrue
import org.junit.Test

class RaceDayGuideEngineTest {
    @Test fun `prova de maratona orienta abastecimento e recuperacao`() {
        val event = RaceEvent("a", "Maratona", 42.195, "2026-12-20", "A", "04:00:00")
        val guide = RaceDayGuideEngine.build(event, TrainingGoalIntent.TARGET_TIME)
        assertTrue(guide.preRace.isNotBlank())
        assertTrue(guide.warmUp.isNotBlank())
        assertTrue(guide.start.contains("04:00:00"))
        assertTrue(guide.fueling.contains("carboidratos"))
        assertTrue(guide.recovery.isNotBlank())
        assertTrue(guide.targetStrategy.contains("principal"))
    }

    @Test fun `prova preparatoria nao e tratada como tentativa maxima`() {
        val event = RaceEvent("b", "Prova treino", 10.0, "2026-12-20", "C")
        val guide = RaceDayGuideEngine.build(event, TrainingGoalIntent.COMPLETE)
        assertTrue(guide.targetStrategy.contains("treinamento"))
    }
    @Test fun `prioridades B e C usam o tempo alvo no guia sem alterar o significado da prioridade`() {
        listOf("B", "C").forEach { priority ->
            val event = RaceEvent("target-$priority", "Prova", 5.0, "2026-12-20", priority, "37:00")
            val guide = RaceDayGuideEngine.build(event, TrainingGoalIntent.COMPLETE)
            assertTrue(guide.start.contains("37:00"))
            assertTrue(guide.middle.contains("37:00"))
            assertTrue(guide.targetStrategy.contains("37:00"))
            if (priority == "B") assertTrue(guide.targetStrategy.contains("preparatória"))
            else assertTrue(guide.targetStrategy.contains("treinamento"))
        }
    }

}
