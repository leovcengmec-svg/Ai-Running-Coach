# AI Running Coach — Auditoria V90 e plano de correção V91

**Base auditada:** `AI-Running-Coach-V90-BUILD-FIX.zip`  
**Identificação da base:** VersionCode 90 · VersionName V90 · motor interno 79 · Backup Schema 5  
**Escopo:** fluxos mostrados nas dez capturas e respectivos motores, persistência e testes Android.

## 1. Resumo executivo

A análise do código V90 confirmou os problemas descritos nas capturas. Não são apenas ajustes cosméticos: há defeitos de estado da restauração, contabilização de volume do reteste Cooper, cobertura incompleta da auditoria da biblioteca e critérios excessivos para exibir médias descritivas.

A próxima atualização deve ser um pacote único V91, mantendo o histórico, as sessões concluídas, o ciclo importado e a compatibilidade dos backups anteriores.

## 2. Diagnóstico por evidência

### Imagem 1 — Legenda do calendário

**Constatação:** a legenda é desenhada manualmente em quatro linhas de dois itens. Cada `LegendDot` ocupa somente a largura do próprio conteúdo; as linhas não dividem igualmente a largura disponível. Isso deixa grandes espaços vazios e enfraquece o alinhamento.

**Correção:** substituir as linhas manuais por uma grade responsiva de duas colunas com células de largura igual. Cada célula terá ícone e nome na mesma linha, alinhamento consistente e espaçamento vertical menor. Os oito nomes completos devem ficar visíveis em uma linha, sem truncamento ou corte: Regenerativo, Rodagem, Intervalado, Fartlek, Limiar/Qualidade, Longão, Prova e Teste. Adicionar uma pequena legenda de status separada para ✓ Concluído e × Não realizado.

### Imagens 2 e 3 — Marcadores apagados e ícones por categoria

**Constatação:** `CalendarWorkoutMarker` aplica `categoryColor.copy(alpha = 0.24f)` para todos os marcadores, inclusive sessões futuras e a sessão de hoje. Por isso os treinos planejados aparecem apagados. A grade mensal também usa apenas pontos genéricos; os símbolos específicos existentes em `SessionGlyph` não são utilizados no marcador mensal.

**Correção:** unificar a identidade visual numa única função de apresentação de categoria, usada no calendário mensal, nos cards e na agenda. Criar oito pictogramas distintos e consistentes:

| Categoria | Ícone sugerido |
|---|---|
| Regenerativo | lua |
| Rodagem | círculo/pegada de corrida |
| Intervalado | raio |
| Fartlek | onda |
| Limiar/Qualidade | alvo/velocímetro |
| Longão | seta de percurso |
| Prova | troféu/bandeira |
| Teste | mira/cronômetro |

Status visual:
- **Futuro e hoje:** ícone e cor de categoria em intensidade normal; hoje permanece pendente até o fim do dia.
- **Concluído:** manter a identidade da categoria e sobrepor um ✓ verde legível.
- **Data passada sem conclusão:** reduzir a opacidade apenas desse item e sobrepor X vermelho.
- A conclusão deve continuar vinculada à instância exata da sessão, não apenas ao `sessionId`.

Ajustar o tamanho mínimo do pictograma na grade mensal para que seja reconhecível em tela pequena; manter abreviação textual curta abaixo como redundância acessível.

### Imagens 4 e 5 — Restaurar backup, manter plano e recalcular

**Constatações confirmadas no código:**
1. `restoreBackup()` define `pendingBackupRecalibration` e `needsEngineRefresh` quando o motor do backup é antigo.
2. `keepRestoredBackupPlan()` limpa `pendingBackupRecalibration`, mas não limpa nem registra adiamento de `needsEngineRefresh`. Portanto, a escolha “Manter plano importado” fecha a caixa de decisão, mas a Home continua mostrando “Revisão da prescrição pendente”.
3. O botão da Home chama `createPlan()`. Essa função pode falhar por validação do perfil, meta/tempo, segurança ou erro de execução e grava o motivo em `motorError`; a Home não mostra esse erro junto ao botão. Isso pode fazer uma tentativa inválida parecer que não fez nada.
4. O botão “Recalibrar plano” do diálogo chama `recalibrateRestoredBackup()`, mas o resultado Boolean não é tratado na interface do diálogo; uma falha não apresenta ali um fluxo claro de correção e repetição.

**Correção:** separar os estados “decisão de restauração pendente”, “plano antigo mantido conscientemente”, “recalibração em andamento”, “recalibração concluída” e “recalibração bloqueada”.

- **Recalibrar agora:** usar uma única rotina de recálculo, validar pré-condições, manter plano original em caso de falha, exibir o erro específico e só fechar a decisão após sucesso.
- **Manter plano importado:** preservar exatamente o ciclo e as sessões, registrar que o usuário adiou a atualização e parar de exibir aviso persistente. Não marcar falsamente o motor antigo como atual.
- Disponibilizar ação manual explícita “Atualizar plano com o motor atual” em local previsível (Backup/Plano). Essa ação deve funcionar mesmo depois de “Manter plano importado”.
- Exibir o resultado: quantas sessões futuras foram recalculadas, quantas concluídas foram preservadas e se houve alguma sessão manualmente reagendada mantida.
- Mostrar `motorError`/motivo de bloqueio perto do botão; incluir ação de tentar novamente depois de corrigir os dados.
- Se houver dor ou bloqueio de segurança, nunca substituir o plano existente.

**Regressão obrigatória:** restaurar backup com motor 77, escolher Manter, confirmar que o plano não muda nem fica sendo nagged; depois tocar em Atualizar manualmente e confirmar que o motor recalcula sessões futuras. Repetir escolhendo Recalibrar imediatamente. Testar falhas de validação e recuperação.

### Imagens 6 e 7 — Reteste Cooper com 0 km na semana

**Constatação confirmada:** `scheduleEightWeekRetest()` cria o bloco Cooper de 12 minutos como `targetMode = TIME`, sem distância estimada nem pace; também cria aquecimento de 12 min e desaquecimento de 10 min sem distância nem faixa de pace. Em seguida grava `Workout.distanceKm = 0.0` para Cooper. O resumo de volume semanal soma o teste como zero. No print, a semana 5 apresenta meta 16,9 km, rodagem 5,7 km, reteste 0 km e longão 6,1 km: total visível 11,8 km.

**Correção:** estimar a distância planejada do reteste sem alterar a natureza do teste:

- Cooper 12 min: usar como estimativa de planejamento a distância do último Cooper válido do atleta.
- Aquecimento 12 min e desaquecimento 10 min: estimar cada trecho a partir da faixa individual fácil já prescrita para o atleta e de suas durações.
- Distância estimada da sessão = estimativa do aquecimento + distância do último Cooper + estimativa do desaquecimento.
- Manter o bloco Cooper como teste por tempo; não impor pace-alvo ao bloco de teste nem transformar estimativa em distância obrigatória.
- Para teste de 3 km, considerar os 3 km do bloco principal mais as estimativas de aquecimento/desaquecimento.
- Se não existir referência válida para estimar uma parte, não inventar ritmo genérico: sinalizar estimativa parcial/indisponível e explicar.
- Exibir `~x,x km estimados` na sessão e contar essa estimativa uma única vez no volume **planejado** da semana. Nunca somá-la aos quilômetros efetivamente realizados; quando o feedback/atividade real chegar, a carga realizada usa a distância real.
- Não aumentar a distância estimada para “fechar” a meta semanal. Se ainda houver diferença, manter o déficit explicado pelo motor.

**Testes:** conferir soma dos três blocos, total da sessão, meta do card semanal e gráfico; conferir Cooper anterior de 2,4 km com ritmos fáceis conhecidos; conferir caso sem teste prévio; conferir teste de 3 km; confirmar não duplicação após feedback/importação.

### Imagem 8 — Segundo bloco com o mesmo pace do aquecimento

**Constatação confirmada:** `buildExplicitProtocolSegments()` cria “Preparação em Z2” com `ActiveZoneBand(0, 20)`. Para corredores com pelo menos seis meses, `ZoneIntensityBandEngine.applyExperiencedTransition()` converte o aquecimento para Z2 0–20%. Assim, aquecimento e preparação passam a ter exatamente a mesma faixa e o mesmo pace. A captura mostra essa duplicação: Aquecimento leve e Preparação em Z2 apresentam 7:57–8:10 min/km e faixa 0–20%.

A auditoria atual `TrainingPrescriptionAudit` verifica progressões/regressões e alguns casos de recuperação Fartlek, mas não impõe a regra equivalente para os pares aquecimento/preparação dos protocolos intervalados/tempo.

**Correção:**
- Para sessões com bloco preparatório antes de trabalho, aquecimento e preparação devem ter funções e faixas distintas. Manter o aquecimento na faixa fácil individual; mover “Preparação em Z2” para uma faixa seguinte, inicialmente Z2 20–40%, respeitando a elegibilidade e a faixa total individual.
- Se o atleta não tiver zona/paces válidos, conservar a instrução de progressão gradual, mas não exibir dois alvos numéricos idênticos como se fossem diferentes; mostrar faixa ainda não calibrada.
- Aplicar a regra de acordo com o papel do segmento (aquecimento, transição, trabalho, recuperação, desaquecimento), não por simples posição ordinal. Não alterar caminhadas, pausas passivas, recuperação, sessão regenerativa ou contínuo fácil que legitimamente não exija aceleração.
- Fazer auditoria completa de todas as famílias e variantes da biblioteca: rodagem, progressivo/regressivo, longão, intervalados I04–I10, ritmo específico RP05/RP10/RP15/RP21, tempo T04/T05, Fartlek F01–F04, piramidais, intervalados mistos, corrida/caminhada, sessões específicas e retestes.
- Auditar o plano gerado e também as sessões futuras salvas/alternativas, aplicando migração apenas ao futuro após confirmação. Treinos concluídos e feedbacks não são reescritos.

**Testes:** gerar cada família com perfil iniciante/intermediário/experiente, com e sem zonas válidas, e validar zona, faixa percentual, pace em mm:ss, dose, distância estimada e total. Para sessões com preparação, exigir diferença real entre aquecimento e preparação; para trabalho principal em zona superior, exigir alvo coerente com a zona e a elegibilidade.

### Imagem 9 — Card “Contadores do período”

**Constatação:** a seção exibe contagens técnicas de feedbacks, sessões identificadas, atividades medidas e blocos com pace. Parte dessas informações já aparece em outros cards e não contribui diretamente para a leitura do atleta.

**Correção:** remover o card inteiro da interface Evolução. Manter os dados internos e as funções de diagnóstico caso sejam utilizados pelos motores, testes ou suporte; não apagar registros nem contagens do armazenamento.

### Imagem 10 — Médias semanais de 28 e 42 dias

**Constatação confirmada:** `TrainingLoadEngine` só preenche a média de 28 dias quando há pelo menos seis atividades em três semanas ISO ativas. A média de 42 dias usa critério equivalente. A captura mostra cinco atividades e duas semanas ativas, então ambos os campos ficam `null` e a interface imprime “Histórico insuficiente”. Os testes atuais também exigem `null` para amostras parciais.

**Correção:** separar média descritiva de confiabilidade usada para prescrição:
- Mostrar sempre a média semanal descritiva de 28 dias = total dos últimos 28 dias ÷ 4.
- Mostrar sempre a média semanal descritiva de 42 dias = total dos últimos 42 dias ÷ 6.
- Mostrar o resultado com uma casa decimal, mesmo com uma ou poucas atividades. Se não houver atividades, mostrar `0,0 km` com indicação de ausência de registros, sem “Histórico insuficiente”.
- Manter `reliable` e os mínimos de amostragem como indicadores internos para readiness, calibração e substituição da base informada. Não permitir que a remoção do mínimo visual libere prescrição automática baseada em histórico insuficiente.
- Manter, se útil, o número de atividades/semanas como contexto discreto; remover o card técnico da Imagem 9.

**Observação de nomenclatura:** a captura e o código V90 usam 28 e **42 dias**, não 48. Este plano mantém 42 dias, preservando a janela já implementada.

## 3. Ordem de implementação

1. Corrigir fluxo e estado de restauração/recalibração; incluir mensagem de sucesso/erro e teste de ponta a ponta.
2. Corrigir distância estimada do Cooper e consistência entre segmentos, sessão e resumo semanal.
3. Corrigir a faixa do bloco de preparação e completar a auditoria automatizada de toda a biblioteca.
4. Corrigir os ícones e estados do calendário; reorganizar a legenda em grade horizontal responsiva.
5. Remover o card Contadores do período sem apagar dados internos.
6. Fazer as médias 28/42 sempre visíveis e separar descrição estatística de gate de confiabilidade.
7. Atualizar documentação, migração, backup e changelog; gerar um ZIP único.

## 4. Matriz mínima de aprovação

| Área | Teste obrigatório | Aprovação |
|---|---|---|
| Calendário | Treino futuro, hoje, concluído e atrasado | Futuro/hoje com cor normal; ✓ verde; passado não feito com X vermelho e opacidade reduzida |
| Categorias | Oito famílias em mês, semana e card | Ícone e cor consistentes em todas as telas |
| Legenda | Tela Android estreita e larga | Duas colunas equilibradas; rótulos completos, sem corte/quebra indesejada |
| Backup | Restaurar motor 77 e escolher Manter | Plano preservado; aviso de decisão não fica repetindo; ação manual continua disponível |
| Backup | Recalibrar agora e recalibrar depois | Ação executa ou apresenta motivo; falha não perde plano; sucesso atualiza apenas futuro |
| Cooper | Reteste com histórico Cooper | Distância estimada inclui aquecimento + Cooper + desaquecimento e entra uma vez no planejado |
| Cooper | Atividade real posterior | Volume realizado usa distância real; estimativa não duplica a atividade |
| Biblioteca | Todas as famílias e variantes | Preparação não repete pace de aquecimento quando a sessão requer transição |
| Biblioteca | Pausa passiva/caminhada/recuperação | Sem pace falso ou aceleração inadequada |
| Evolução | Cinco atividades em duas semanas | Exibe média de 28 e 42 dias, sem remover gates internos de confiabilidade |
| Interface | Evolução | Card Contadores do período removido; demais indicadores permanecem íntegros |
| Backup | Schemas antigos 1–5 | Todos continuam legíveis; histórico, feedbacks e sessões concluídas preservados |

## 5. Integridade e migração

- Preservar sessões concluídas, feedbacks, atividades importadas, resultados Cooper, calibrações, provas e datas reais.
- Recalcular somente sessões futuras; manter sessões manualmente reagendadas quando compatíveis com o ciclo.
- Não converter distância estimada em atividade concluída nem em quilometragem realizada.
- Não duplicar provas, testes ou distâncias no gráfico/card semanal.
- Preservar o motor original registrado no backup; um adiamento consciente da recalibração não deve falsificar a versão do motor.
- Manter leitura de backups antigos. Se a decisão de adiamento ou novos metadados de estimativa forem persistidos no contrato do backup, introduzir Schema 6 com campos opcionais e migração testada; caso contrário, não aumentar schema sem necessidade.

## 6. Próxima versão proposta

- **Produto:** AI Running Coach V91
- **VersionCode:** 91
- **Motor interno:** 80
- **Backup:** Schema 6 somente se os novos estados/metadados forem adicionados ao arquivo exportado; leitura dos schemas 1–5 obrigatória.
- **Base:** V90 build-fix.
- **Entrega:** um único ZIP integrado, sem pacotes intermediários.

## 7. Limites da auditoria e validação

Foram inspecionados o ZIP V90 build-fix e os fluxos/códigos diretamente relacionados às dez capturas: `MainActivity.kt`, `WorkoutCalendarPresentation.kt`, `ZoneIntensityBandEngine.kt`, `CoachEngine.kt`, `TrainingLoadEngine.kt`, `UnifiedPrescriptionCalculator.kt`, `WeeklyVolumeSummary.kt`, `AppBackupManager.kt` e os testes associados.

Esta é uma auditoria de ponta a ponta dos módulos envolvidos nas evidências. A compilação Gradle/JUnit oficial e o teste no aparelho Android devem ser executados no GitHub Actions/aparelho após a implementação; a inspeção estática não substitui esses testes.
