# Relatório de correções — V88 Biblioteca e Faixas Ativas

## Correções aplicadas
1. Recuperação ativa Z2 consolidada em 0–20%. O trabalho aeróbio Z2 permanece em 20–65%; a recuperação não reutiliza a mesma faixa do bloco de trabalho.
2. Fartlek F01/F02/F04 aplica recuperação ativa em Z2 0–20%. F01 mantém 2 min entre variações e não adiciona recuperação após o último bloco.
3. As distâncias estimadas de Fartlek são reequilibradas após a atualização da recuperação. A distância do trote de recuperação é calculada pela duração/pacing do bloco; o orçamento restante é distribuído pelos segmentos de trabalho, mantendo o total da sessão e evitando inflação do volume semanal.
4. Progressões e regressões Z2 agora usam faixas distintas do aquecimento/desaquecimento: progressão 20–40% → 40–65%; regressão 40–65% → 20–40%. Quando elegível, o toque Z3 fica restrito à entrada 0–20%, sem alterar os critérios de elegibilidade anteriores.
5. Migração de sessões pendentes reconhece os dois textos conhecidos de conversão automática V84 para caminhada, restaura o trote leve Z2 quando apropriado e preserva caminhadas intencionais/pausas passivas.
6. Migração é idempotente; sessões concluídas, feedbacks e histórico não são reescritos.
7. `TrainingPrescriptionAudit` passou a verificar a distinção entre esforço/recuperação Fartlek, a separação aquecimento/bloco principal e a ordem das bandas em progressões e regressões.

## Verificação
- Compilação isolada Kotlin/JVM dos 48 arquivos de domínio: aprovada.
- Testes focados: 71/73 aprovados. As duas falhas restantes são preexistentes nos testes de corrida/caminhada para iniciantes e também aparecem ao executar a mesma bateria sobre a base V87 original.
- Corrigidos os casos de regressão Fartlek que apresentavam soma de segmentos acima da distância planejada; testes de auditoria de prescrição passam.
- Teste novo de migração Fartlek V84 (WALK automático → ACTIVE_Z2) confirma 2 min, Z2 0–20%, distância total preservada, histórico concluído inalterado e segunda migração sem mudanças.

## Versionamento
- VersionCode 88; VersionName V88.
- CURRENT_ENGINE_VERSION 77.
- Backup Schema 4 preservado.

## Limites
A compilação Android/Compose e a suíte Gradle completa não foram executadas neste ambiente por ausência de Gradle Wrapper/CLI e Android SDK. `:app:testDebugUnitTest`, `:app:assembleDebug` e teste em aparelho continuam pendentes no GitHub Actions.
