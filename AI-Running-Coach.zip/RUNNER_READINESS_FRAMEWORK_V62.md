# Runner Readiness Framework — AI Running Coach V62

## Finalidade

Ligar objetivo, experiência declarada, duração da prática regular, frequência escolhida, volume das últimas quatro semanas, maior corrida recente e consistência em um único diagnóstico de prontidão para a prescrição.

As faixas de volume e frequência são **referências de engenharia do produto**, informadas por padrões observacionais de treinamento e recomendações de programas públicos. Não são mínimos fisiológicos universais, metas obrigatórias, garantia de segurança ou substituto de avaliação profissional.

## Matriz de volume semanal de referência

Valores em km/semana. O motor seleciona a coluna pelo nível operacional e a linha pela distância-alvo.

| Objetivo | Iniciante | Intermediário | Avançado | Elite* |
|---|---:|---:|---:|---:|
| Milha / 3 km | 8–12 | 12–20 | 20–35 | 30–50 |
| 5 km | 8–15 | 15–25 | 25–40 | 35–55 |
| 10 km | 12–20 | 20–30 | 30–45 | 40–65 |
| 15 km | 15–25 | 25–35 | 35–50 | 45–70 |
| Meia maratona | 20–30 | 25–40 | 40–60 | 50–80 |
| Maratona | 25–35** | 35–50 | 50–75 | 60–100 |
| Ultramaratona 50 km | Preparação prévia | 40–55** | 55–85** | 60–110** |
| Saúde e qualidade de vida | 6–15 | 10–22 | 15–30 | 20–40 |

* A faixa Elite só é usada pelo motor quando existe evidência compatível de prática regular (≥60 meses), pelo menos 3 semanas ativas nas últimas 4, volume próximo à referência Elite e maior corrida recente compatível com o objetivo. O rótulo Elite auto declarado não libera automaticamente as regras Elite. Até haver evidência, são usados guardrails Avançados.

** Maratona iniciante e ultradistância são referências de base/preparação, não autorização para começar diretamente um bloco específico de prova. A ultradistância exige planejamento especializado; a faixa não constitui recomendação individual automática.

## Frequência semanal de referência

| Objetivo | Iniciante | Intermediário | Avançado | Elite* |
|---|---:|---:|---:|---:|
| Saúde | 2–3 | 2–4 | 3–5 | 3–6 |
| Milha / 3 km | 2–3 | 3–4 | 4–5 | 4–6 |
| 5 km | 2–3 | 3–4 | 4–5 | 4–6 |
| 10 km | 3 | 3–4 | 4–5 | 4–6 |
| 15 km | 3–4 | 3–4 | 4–5 | 4–6 |
| Meia maratona | 3–4 | 3–4 | 4–5 | 5–6 |
| Maratona | 4** | 4–5 | 5–6 | 5–6 |
| Ultramaratona 50 km | 3–4** | 4–5** | 5–6** | 5–6** |

A frequência recomendada é informativa. Os 2–6 dias efetivamente selecionados pelo corredor são preservados. Se a escolha estiver abaixo ou acima da referência, o motor explica a limitação e adapta volume/intensidade; não muda silenciosamente a disponibilidade.

## Avaliação de experiência e prontidão

O onboarding mantém o nível declarado (Iniciante, Intermediário, Avançado, Elite) e acrescenta duração de prática regular:
- Menos de 6 meses → estimativa 3 meses;
- 6–12 meses → 9 meses;
- 1–3 anos → 24 meses (estimativa conservadora do intervalo);
- 3–5 anos → 48 meses;
- Mais de 5 anos → 72 meses.

A duração complementa, não substitui, a declaração. Para prescrição, um nível Intermediário com menos de 12 meses regulares usa guardrails de Iniciante; Avançado com 12–35 meses usa guardrails de Intermediário e com menos de 12 meses usa Iniciante; Elite exige pelo menos 60 meses e evidência atual de carga, consistência e maior sessão recente. Elite sem evidência suficiente usa o maior nível operacional realmente sustentado (Avançado, Intermediário ou Iniciante). Perfis legados sem essa resposta permanecem com experiência desconhecida, sem preencher dados inventados, e usam provisoriamente um guardrail abaixo do nível declarado.

## Consistência recente

O onboarding registra em quantas das quatro últimas semanas houve pelo menos uma corrida (0–4). Esse número é distinto da média semanal em km.

- 0 semanas ou volume 0: estado de reintrodução; a prescrição começa em dose muito baixa/por tempo e não tenta alcançar a faixa objetivo.
- 1–2 semanas: consistência recente baixa; as doses são conservadoras e os critérios de qualidade Z3/Z4/Z5 ficam mais restritivos.
- 3–4 semanas: histórico recente mais estável; ainda depende de volume, maior corrida recente, zonas válidas, dor e recuperação.
- Dados ausentes de backups V61 ou anteriores permanecem desconhecidos; não são inventados. Quando pelo menos seis atividades medidas abrangem três semanas distintas, as semanas ativas registradas no histórico substituem a estimativa digitada; sem essa confiabilidade, permanece o valor informado pelo atleta. Se o valor continuar desconhecido, o motor não libera limiar, VO₂ ou Z3 sem comprovação de consistência.

## Volume inicial: regra prioritária

1. A média real recente e as atividades efetivamente registradas determinam o ponto de partida.
2. A maior corrida recente limita a dose de uma sessão/longão.
3. A matriz mostra a faixa de referência para objetivo e nível, mas **nunca aumenta automaticamente** o primeiro volume até o limite inferior da faixa.
4. A faixa acima/abaixo da referência gera explicação, não uma redução ou aumento automático sem evidência.
5. Quando 6 atividades reais em pelo menos 3 semanas sustentam a média de 28 dias, a carga medida pode substituir a autodeclaração, conforme a regra existente do TrainingLoadEngine.

## Integração com qualidade

O `RunnerReadinessEngine` recomenda frequência, volume de referência, compatibilidade do objetivo, condição atual e nível operacional. O `RunningCoachEngine` recebe essa avaliação antes de escolher estímulos. Qualidade de limiar/VO₂ e Z3 de progressões exige pelo menos 3 semanas ativas nas últimas 4; quando a consistência é desconhecida, somente um histórico medido confiável (mínimo de seis atividades em pelo menos três semanas distintas) pode substituir a declaração. Sem evidência, a sessão de qualidade é suprimida; a frequência e os dias escolhidos continuam preservados. Os demais guardrails (volume, maior sessão, zonas, dor e recuperação) continuam aplicáveis.

Objetivos de meia maratona/maratona para iniciantes entram como preparação prévia; metas longas para intermediários são condicionais. Saúde e Qualidade de Vida possui matriz própria e não injeta qualidade intensa automaticamente.

## Compatibilidade e backup

- Novas preferências: `runningExperienceDuration` (String) e `activeWeeksLast4` (Int), incluídas no backup Schema 2.
- `AppBackupCodec` mantém compatibilidade com Schema 1 e 2; chaves ausentes em backups antigos são tratadas como desconhecidas.
- `versionCode = 62`, `versionName = V62`, `engineVersion = 47`.
- A migração marca planos V61 para atualização do motor, sem reiniciar a âncora, a duração do ciclo ou o histórico. Sessões concluídas e feedbacks permanecem preservados.
