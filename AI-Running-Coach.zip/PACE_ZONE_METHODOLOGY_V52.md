# AI Running Coach — metodologia de importação e calibração V52

## 1. Importação de atividades

A tela de feedback de cada sessão permite importar um arquivo GPX, FIT ou TCX. A leitura é feita localmente no dispositivo; o arquivo selecionado é analisado antes de o atleta confirmar a conclusão da sessão.

| Formato | Dados lidos quando existentes |
|---|---|
| GPX | Pontos GPS, horários, elevação e extensões de frequência cardíaca/cadência |
| TCX | Voltas, distância, duração, frequência cardíaca e trackpoints com posição, elevação, horário e cadência |
| FIT | Mensagens `record` e `session`, distância/duração totais, horários e campos de frequência cardíaca/cadência |

A distância de um percurso GPX é estimada pela soma geodésica entre pontos GPS consecutivos válidos; TCX e FIT priorizam totais/campos de distância fornecidos pelo próprio arquivo quando presentes. O ganho de elevação soma somente incrementos positivos plausíveis entre amostras. Pace médio só é calculado quando existem distância e duração válidas.

**Ausência de dado não é substituída por estimativa inventada.** Sem timestamps/duração, a importação pode guardar a distância e o percurso, mas não grava duração nem pace médio. Sem extensão/campo de FC ou cadência, essas métricas permanecem vazias. Parciais dependem de pontos/distâncias suficientes para serem calculadas.

O importador aceita arquivos de até 25 MB e valida a estrutura XML com entidades externas desabilitadas. FIT exige a assinatura `.FIT` e tamanho declarado compatível com os bytes disponíveis; arquivos truncados ou com cabeçalho inválido são rejeitados. Cada arquivo recebe fingerprint SHA-256: a mesma atividade não pode ser associada a outra sessão, e a reimportação na própria sessão substitui os metadados daquela atividade em vez de criar um segundo feedback.

A atividade importada é vinculada ao `sessionId` da sessão em edição. Distância e pace preservam a precisão do arquivo enquanto os campos exibidos (arredondados) não forem alterados; correções manuais de distância/tempo são usadas para recalcular o pace. Ao editar um feedback antigo sem reimportar o arquivo, os valores originais de precisão integral também são preservados quando os campos visíveis não mudaram. Esforço, sensação, dor e observações são informações subjetivas independentes e não são apagadas pela importação. Registros V51 sem metadados de atividade continuam válidos.

## 2. Calibração independente das zonas

O Cooper continua sendo a referência inicial de campo para as cinco zonas. Os percentuais operacionais derivados do Cooper não representam percentuais de VO₂máx. VAM e segundo limiar estimados são referências auxiliares, não medidas laboratoriais.

### Z1 — recuperação

- Evidência: pelo menos três sessões regenerativas nos últimos 42 dias, sem dor, com esforço percebido `Muito leve` ou `Leve`, sensação `Ótimo` ou `Bem`, e distância/duração reais suficientes para calcular o pace.
- As observações precisam formar uma faixa consistente: amplitude máxima de 60 s/km entre as amostras consideradas.
- O reconhecimento inclui os rótulos `Recuperação`, `Regenerativa` e `RECOVERY`, contemplando nomenclaturas atuais e legadas.
- Uma corrida comum, sem classificação/feedback regenerativo adequado, não entra nessa evidência.

### Z2 — aeróbia confortável

- Evidência: pelo menos três observações válidas do teste da fala nos últimos 42 dias, em treino elegível, com esforço/sensação compatíveis e sem dor.
- A amplitude máxima entre os paces observados é de 45 s/km.
- A mediana do pace confortável deve estar dentro da faixa Z2 resultante. Z1 e Z2 compartilham a fronteira entre si; Z2 e Z3 também permanecem contíguas.

### Z3 — moderada / desempenho

- Evidência: dois resultados de Teste de Cooper válidos, em datas distintas e separados por pelo menos 14 dias.
- A diferença entre as distâncias dos dois resultados deve ser de até 8% em relação à média.
- A fronteira operacional usa 90% da velocidade média de Cooper como âncora de desempenho. Isso não equivale a uma medida de limiar fisiológico.
- Uma atividade GPX/FIT/TCX comum nunca é promovida automaticamente a teste máximo, prova ou teste de velocidade crítica.

## 3. Estados de confiança

| Estado | Interpretação |
|---|---|
| `INITIAL` | Sem evidência suficiente; mantém a referência inicial de Cooper |
| `OBSERVATION` | Existem registros, mas ainda não atingem a quantidade mínima |
| `CALIBRATED` | Critérios de quantidade, consistência e encaixe da referência foram atendidos |
| `REVIEW` | Evidência válida está ajustando gradualmente a faixa, ou ainda não cabe com segurança na geometria atual |
| `UNSTABLE` | Os dados são contraditórios ou excedem a tolerância de consistência; a faixa não é atualizada por essa evidência |

## 4. Continuidade, progressão e segurança

As cinco zonas devem formar uma sequência contínua e ordenada de Z5 (mais rápida) a Z1 (mais lenta). Uma calibração que quebraria a continuidade é recusada e marcada para reavaliação.

Cada fronteira individual pode se deslocar no máximo 15 segundos por atualização. O último conjunto de fronteiras aplicado é salvo localmente para que a próxima atualização continue a transição de forma gradual, inclusive após fechar/reabrir o aplicativo. O Cooper também usa suavização de até 15 segundos por fronteira em relação à avaliação anterior.

Dor relatada é excluída das evidências regenerativas/teste da fala e bloqueia a progressão automática de carga/intensidade. Uma melhora isolada de pace ou uma única atividade importada não autoriza aumento automático de volume ou intensidade. O treinador pode solicitar que o plano seja recalculado explicitamente para aplicar as faixas atualizadas às próximas sessões.

## 5. Limitações

- A precisão da distância GPS depende da qualidade, frequência e continuidade dos pontos do arquivo; saltos isolados são ignorados.
- Tempo decorrido entre timestamps pode incluir pausas, conforme a forma como a plataforma exportou a atividade.
- Extensões de FC/cadência variam por plataforma; métricas ausentes permanecem nulas.
- O modelo é uma calibração operacional de campo, não substitui avaliação clínica, teste cardiopulmonar ou determinação laboratorial de limiares.
