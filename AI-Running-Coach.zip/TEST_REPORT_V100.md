# AI Running Coach V100 — Relatório de testes

**Data:** 26/11/2026  
**Base:** V99  
**Versão:** V100 / motor 90 / schema 13

## Resultado do harness isolado

<details>

- `TrainingCalendarIntegrityEngineTest` + `WorkoutCalendarPresentationTest`
- **34 testes aprovados**
- **0 falhas**

</details>

## Cenários críticos adicionados/ajustados

1. Reteste pendente com snapshot de 5,1 km: total de 17,0 km com longão 6,8 km; aceita exatamente 40,0%.
2. Reteste pendente com snapshot de 5,0 km: composição de 16,9 km; mantém bloqueio por 40,2%.
3. Reteste sem snapshot e sem avaliação fisiológica ativa: não trata a distância como zero nem inventa uma reserva fixa de 5 km; adia a participação exata.
4. Reteste com protocolo escolhido: usa a distância completa da sessão selecionada e não soma o snapshot original.
5. Backup legado com avaliação ativa elegível: usa estimativas completas dos protocolos elegíveis, incluindo aquecimento e desaquecimento.
6. Siglas canônicas: REG, ROD, INT, FAR, LIM, LNG, PRV e TST.
7. Grade mensal: meses com quatro, cinco e seis semanas; início na segunda e término no domingo.

## Limitações

O harness isolado usa um shim JUnit leve e dublês mínimos para entidades/dependências Android. Não substitui a suíte oficial Gradle/JUnit. A compilação Android/Compose e a geração de APK devem ser confirmadas pelo workflow GitHub Actions (`:app:testDebugUnitTest :app:assembleDebug`).
