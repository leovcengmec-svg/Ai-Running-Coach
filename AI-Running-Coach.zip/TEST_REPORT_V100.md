# AI Running Coach V100 — Relatório de testes

## Resultado disponível neste ambiente

**Execução local focada**

### 1. Harness principal Kotlin/JVM — PASS

Fontes reais compiladas:
- `TrainingCalendarIntegrityEngine.kt`
- `WorkoutCalendarPresentation.kt`
- `WeeklySessionDistributionEngine.kt`

Verificações executadas:
- Sessões concluídas não ocupam dias futuros na contagem de frequência.
- Semana atual parcial não recebe falso bloqueio de 100% calculado apenas sobre sessões restantes.
- Sessões concluídas continuam entrando no volume semanal quando a semana está completa.
- Reteste futuro sem protocolo é compromisso válido, não sessão de 0 km.
- Reserva do slot original do reteste é considerada quando disponível.
- Longão respeita 40%; provas e sessões entram uma única vez no volume.
- Conflito pendente entre prova e treino no mesmo dia continua detectado.
- Taxonomia e oito códigos INI/REG/ROD/FAR/INT/LNG/PRV/TES.
- Distribuição de 17,0 km: 6,8 + 5,1 + 5,1 km; longão exatamente 40%.

Saída: `V100 core harness: PASS (calendar integrity, retest reservation, 40% ceiling, taxonomy, weekly distribution)`.

### 2. Harness de ciclo Kotlin/JVM — PASS

`PlanMigrationEngine.kt` real foi compilado com modelos de domínio e stubs mínimos de dependências para exercício das funções puras.

Verificações executadas:
- Janela original de oito semanas permanece ancorada.
- Alteração no perfil vira assinatura pendente e não substitui o snapshot ativo.
- Apenas sessões de hoje em diante e dentro da âncora são candidatas a regeneração.
- Backup antigo com evidência suficiente recupera a âncora original.
- Backup ambíguo exige confirmação, sem iniciar silenciosamente outro ciclo.
- Semana 8 não pode ser encerrada antes do fim do período; sessão pendente exige encerramento explícito.

Saída: `V100 cycle harness: PASS (cycle identity, pending profile, legacy backup recovery, week window, closure gate)`.

**Nota:** o harness de ciclo usa stubs de JSON e não substitui um teste real de serialização/restore do `AppBackupCodec`.

## Não executado

- `gradle :app:testDebugUnitTest`
- `gradle :app:assembleDebug`
- Testes instrumentados Compose/Android
- Instalação e teste no aparelho Android

Motivo: não há Gradle nem Android SDK neste ambiente, e o ZIP da base não contém `gradlew`. O workflow `.github/workflows/android.yml` está configurado para executar JUnit e gerar APK no GitHub Actions.

## Conclusão

Os motores puros de domínio testados passaram nos cenários focalizados. A aprovação completa da aplicação, da migração de backup real e do APK depende da suíte Gradle/JUnit e do build Android no GitHub Actions.

## Verificação do pacote

- ZIP final testado com `unzip -t`: sem erros de integridade.
- 12 verificações internas confirmaram versionCode 100, versionName V100, motor 90, schema 14, estado persistido do ciclo, calendário compacto, taxonomia, teto de 40% e inclusão dos relatórios.
