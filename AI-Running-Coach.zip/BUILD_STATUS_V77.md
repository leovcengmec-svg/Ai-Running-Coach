# Build e validação — AI Running Coach V77

## Identificação
- `versionCode = 77`
- `versionName = V77`
- `CURRENT_ENGINE_VERSION = 67`
- Backup Schema 3; leitura schemas 1–3 preservada.

## Implementações
- Um feedback isolado de cansaço resulta em recuperação moderada e não dispara alerta amarelo sistêmico.
- Prontidão ruim/amarela ajusta a sessão corrente/semana corrente, sem marcar todas as semanas do macrociclo como recuperação. Descargas programadas permanecem separadas.
- Reagendamentos são reaplicados por identidade da sessão antes do ajuste de provas. Sessões movidas são protegidas contra substituição automática por prova; conflitos geram avisos.
- Sessões manualmente reagendadas ausentes na regeneração são preservadas em vez de descartadas.
- Guia de prova por distância, prioridade A/B/C e prioridade do atleta, com preparação, aquecimento, pacing, trecho final, hidratação/energia e recuperação.
- Ritmo previsto calculado pela média ponderada de todos os segmentos de corrida com ritmo definido; pausa passiva excluída. Ritmo real vem do feedback quando disponível.
- Dashboard distingue km agendados, km restantes e meta semanal.

## Testes adicionados
- `PlanMigrationRescheduleTest`: segunda/quarta/sexta reagendada para quarta/sexta/domingo; verifica três IDs e datas preservadas.
- `RaceDayGuideEngineTest`: orientação de maratona com tempo-alvo e prova C como treinamento.
- `AthleteReadinessEngineTest`: um feedback cansado entre observações não dispara alerta amarelo.

## Limitações de validação
- Build Android/Compose e suíte Gradle dependem de Gradle/Android SDK; não declarar APK gerado sem executar esses passos.
- O código da interface Compose requer validação pelo workflow Android/GitHub Actions e em aparelho.

## Verificações executadas neste ambiente
- Compilação Kotlin/JVM de todos os módulos de domínio não dependentes de Android/Compose: aprovada com warnings não bloqueantes.
- Harness executável: 8 cenários passaram — prontidão moderada sem contaminação do macrociclo; preservação das fases; reagendamento segunda/quarta/sexta para quarta/sexta/domingo; sessão movida de segunda para domingo preservada ao recalibrar na quarta; colisão com sessão concluída de outra identidade; proteção do reagendamento contra substituição por prova; média ponderada dos blocos excluindo pausa passiva; e guia de prova.
- Testes JUnit adicionados ao projeto, mas não executados pelo Gradle nesta sessão.
- `MainActivity.kt` e a camada Compose não foram compilados localmente; dependem do build Android oficial.
