# Training Intelligence 5.1 — especificação V75

## 1. Decisão central

A distância escolhida determina a categoria de planejamento. A base semanal, o teto de construção, a capacidade contínua anterior presumida e a frequência recomendada são carregados de um catálogo único (`TrainingPlanReferenceCatalog`). O nível fisiológico não é usado como proxy de experiência contínua; ele calibra zonas, ritmos e complexidade dos estímulos.

## 2. Catálogo de quilometragem

| Objetivo | KM-base/semana | Teto de construção/semana | Capacidade anterior presumida | Frequência recomendada |
|---|---:|---:|---:|---:|
| Milha (1,61 km) | 8 | 15 | 0,8 km | 2 |
| 3 km | 8 | 16 | 1,6 km | 3 |
| 5 km | 12 | 22,5 | 3 km | 3 |
| 10 km | 15 | 27,5 | 5 km | 4 |
| 15 km | 25 | 43 | 10 km | 4 |
| 10 milhas (16,1 km) | 25 | 43 | 10 km | 4 |
| 20 km | 28 | 48 | 16,1 km | 4 |
| 21,1 km | 30 | 51 | 16,1 km | 4 |
| 25 km | 35 | 60 | 21,1 km | 4 |
| 30 km | 40 | 70 | 21,1 km | 4 |
| 42,2 km | 45 | 80 | 21,1 km | 4 |
| 50 km | 55 | 100 | 42,2 km | 5 |
| 100 km | 75 | 140 | 50 km | 5 |
| 100 milhas (160,9 km) | 90 | 160 | 100 km | 6 |

As referências de 5, 10, 15/16, 21 e 42 km seguem os volumes-base e as progressões do documento anexado pelo usuário. As linhas de 3, 20, 25 e 30 km e de ultradistância são valores de catálogo/interpolação do produto e não números expressos literalmente naquele documento. Todos os valores são pressupostos de planejamento do aplicativo, não padrões universais de treinamento ou autorização médica.

## 3. Resolução dos dados do cadastro

A resolução é campo a campo:

- Média de 4 semanas vazia: utiliza `baseWeeklyKm` do objetivo.
- Maior corrida contínua vazia: utiliza `assumedPreviousContinuousDistanceKm` do objetivo.
- Valor positivo informado: substitui o respectivo pressuposto.
- Valor zero: é uma declaração explícita de ausência recente naquela medida; não deve ser convertido em base automática.
- Ausência de GPX/FIT/TCX não equivale a zero e não ativa caminho iniciante.

A média e o maior percurso podem ter origens diferentes. O motor não deve substituir uma informação positiva e confiável apenas porque o outro campo está vazio.

## 4. Capacidade presumida por objetivo

- 5 km presume 3 km contínuos anteriores.
- 10 km presume 5 km contínuos anteriores.
- 15–16,1 km presume 10 km contínuos anteriores.
- 20–21,1 km presume 16,1 km contínuos anteriores.
- 25–30 km presume 21,1 km contínuos anteriores.
- 42,2 km presume 21,1 km contínuos anteriores.
- Ultramaratona 50 km presume 42,2 km; 100 km presume 50 km; 100 milhas presume 100 km.

A capacidade presumida não é uma prova de aptidão clínica. Ela é o pressuposto comercial/de produto para quem escolhe a distância e deixa os campos recentes em branco. Valores positivos declarados ou medidos substituem esse pressuposto e podem deslocar a fase do plano.

## 5. Entrada na fase específica

O estágio específico compara:
- volume semanal com o KM-base do objetivo;
- maior sessão contínua com a capacidade anterior presumida;
- pelo menos três dias de treinamento disponíveis para o plano de desempenho;
- consistência declarada ou medida;
- dor, recuperação, fadiga e coerência entre volume e maior sessão.

A frequência recomendada no catálogo continua sendo orientação de distribuição. Para não tornar quatro dias uma barreira absoluta, a frequência mínima de elegibilidade da fase específica é `min(recommendedFrequency, 3)`. A ausência de requisitos mantém o plano em fase preparatória e explica o que falta.

## 6. Caminhada/corrida

O caminho comum `BEGINNER_RUN_WALK` é liberado somente quando todos estes critérios forem verdadeiros:
- objetivo entre 1 e 5,5 km;
- nível fisiológico `Iniciante`;
- experiência regular inferior a seis meses;
- média semanal explicitamente igual a zero;
- maior corrida contínua explicitamente igual a zero;
- nenhum registro ou declaração de percurso contínuo de 5 km.

Campos em branco usam o catálogo do objetivo e nunca ativam caminhada/corrida. A evidência de 5 km contínuos exclui o caminho comum de iniciante. A caminhada dentro de uma recuperação intervalada pode continuar sendo uma modalidade específica, mas não é o mesmo que prescrever a sessão inteira como corrida/caminhada.

Retorno de lesão não é inferido por dor nem ativado automaticamente: dor bloqueia/requer revisão da prescrição. Um programa específico de retorno, com triagem e critérios funcionais adequados, não foi criado nesta versão.

## 7. Como as prioridades alteram o plano

A implementação possui duas camadas complementares: a proporção da semana e a escolha do estímulo.

Para quatro dias de treino, as parcelas de referência da semana são:

| Prioridade | Longão | Orçamento de qualidade | Intenção |
|---|---:|---:|---|
| Completar | 34% | 12% | Rodagem aeróbica e longão contínuo Z2 |
| Correr continuamente | 37% | 16% | Mais tempo contínuo e progressões, reduzindo pausas planejadas |
| Melhorar recorde pessoal | 30% | 26% | Maior espaço para limiar/intervalos quando elegíveis |
| Tempo-alvo | 31% | 24% | Blocos específicos do ritmo-alvo, após verificar compatibilidade |

Esses percentuais são alvos de distribuição. O orçamento de qualidade só é aplicado se houver sessão elegível, zonas, frequência mínima, distância entre treino de qualidade e longão, recuperação e carga suficientes.

### Exemplos de estímulo em uma semana de quatro dias

| Dia | Completar | Correr continuamente | Recorde pessoal | Tempo-alvo |
|---|---|---|---|---|
| 1 | Rodagem Z2 | Rodagem contínua Z2 | Rodagem leve | Rodagem leve |
| 2 | Aeróbio controlado / fartlek leve | Progressão contínua ou CC01 | Fartlek, limiar ou intervalado | Ensaio de ritmo-alvo ou bloco sustentado |
| 3 | Regenerativo | Contínuo leve | Regenerativo | Regenerativo |
| 4 | Longão contínuo Z2 | Longão contínuo, com progressões periódicas | Longão de suporte, final controlado quando elegível | Longão com trechos específicos quando elegível |

`PERSONAL_BEST` e `TARGET_TIME` têm calendários de protocolo distintos. Recorde pessoal varia intervalos, limiar e velocidade, usando o recorde existente como referência. Tempo-alvo cria blocos no ritmo exigido e compara a meta com testes e zonas atuais. Uma meta incompatível não deve produzir ritmo prescrito fictício.

## 8. Edição do cadastro e migração

A assinatura do plano inclui objetivo, prioridade, tempo-alvo, recorde, nível, frequência, dias, terreno, experiência, média semanal, maior sessão e duração. Alterar qualquer uma dessas dimensões marca o plano como desatualizado. O recálculo conserva sessões concluídas e feedbacks, substituindo apenas sessões futuras/pendentes conforme a lógica de migração.

## 9. Referências do produto

Os valores de base de 5, 10, 15/16, 21 e 42 km foram estruturados a partir do documento anexado pelo usuário, que contém ciclos de progressão por distância, KM-base, volume de pico, semanas 3:1, longões e distribuição de sessões. As linhas intermediárias são decisões internas da tabela e devem ser reavaliadas com dados reais de uso, não confundidas com dados originais do documento.
