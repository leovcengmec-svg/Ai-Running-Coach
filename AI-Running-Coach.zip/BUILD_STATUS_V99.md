# Build Status — AI Running Coach V99

- Base: V98.
- VersionCode: 99.
- VersionName: V99.
- Motor interno: 89.
- Backup Schema: 13; leitura dos schemas 1–13 mantida.
- Correções de frequência futura, semanas parciais, carga do longão e diagnóstico semanal incorporadas.
- Reteste fisiológico sem método é tratado como compromisso de agenda com distância pendente, e não como sessão inválida de 0 km; a validação do longão usa limite conservador até a escolha Cooper/3 km.
- 23 métodos de `TrainingCalendarIntegrityEngineTest` executados localmente com runner Kotlin e shim JUnit leve.
- ZIP: integridade validada; versionCode 99, versionName V99 e schema 13 conferidos no pacote.

## Build Android

**Pendente de CI.** Este ambiente não contém Gradle, `gradlew` nem Android SDK; não foi possível executar JUnit/Gradle, compilação Compose ou gerar APK.

O workflow `.github/workflows/android.yml` deve executar `gradle -p android :app:testDebugUnitTest :app:assembleDebug --no-daemon`. A V99 só deverá ser considerada APK-validada depois do workflow finalizar sem erros e publicar o artefato.
