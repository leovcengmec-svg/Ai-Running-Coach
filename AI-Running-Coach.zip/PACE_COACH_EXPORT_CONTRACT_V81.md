# Pace Coach export contract — V81

## Envelope
The generated file retains the legacy `com.garmin.connect.workout.json.UserWorkoutJson` wrapper used by the Pace Coach importer.

## Units
- `endConditionTypeKey=time`: `endConditionValue` is milliseconds; `endConditionUnitKey=ms`.
- `endConditionTypeKey=distance`: `endConditionValue` is the real distance in meters; `endConditionUnitKey=meter`.
- Do not multiply a meter value by 100. That previous scaling caused 1 km to be read as 100,000 m by Pace Coach.
- `targetTypeKey=pace.zone` is included only when both pace bounds exist and the step kind supports a pace target.
- Pace values remain speed values in `centimetersPerMillisecond`; display fields remain min/km.
- Passive recovery is `no.target`; active recovery may carry pace when explicitly prescribed.

## Pre-export validation
- Every time step must have a positive duration.
- Every distance step must have a finite positive distance.
- Pace bounds must either both exist or both be absent.
- An invalid step blocks export and reports the step name.
- Training sessions and race strategies must call the same exporter.

## Minimum import regression set
200 m, 400 m, 600 m, 1 km, 1.1 km, 1.5 km, 5 km; 1/2/5/8-minute time steps; pace-targeted work; active recovery; passive recovery; repeat groups.
