# Test Report — AI Running Coach V97

## Identificação

- Base: V96.
- `versionCode = 97`; `versionName = V97`.
- `CURRENT_ENGINE_VERSION = 87`.
- Backup Schema 12; leitura `1..12` (inclui V96/schema 11).

## Resultado dos testes focados

**102 testes Kotlin/JVM focados aprovados; 0 falhas.**

Cobertura exercitada:

- `CoachEngineTest`
- `RaceEventEngineTest`
- `TrainingLoadEngineTest`
- `RunnerLoadSourceResolverTest`
- `WeeklySessionDistributionEngineTest`
- `TrainingCalendarIntegrityEngineTest`
- `MeasuredLoadAdoptionPolicyTest`

Os testes adicionais cobrem persistência do snapshot confirmado ao atravessar a segunda-feira, piso de 5 km em sessão completa, rejeição de diferença insignificante como longão em planos contínuos de 5 km, priorização da diferença de longão com redução explícita quando possível, e cálculo do teto de 40% incluindo provas.

## Cenários de aceitação

| Cenário | Resultado no harness |
|---|---|
| 2 + 3 + 1 atividades em três semanas não libera mudança da base | PASS |
| Cadastro declarado permanece fonte até confirmação e autorização | PASS |
| Snapshot confirmado continua válido depois da mudança da janela móvel | PASS |
| 16 km / 3 dias / objetivo 5 km gera 6 + 5 + 5 km | PASS |
| Sessão regular abaixo de 5 km é rejeitada fora das exceções | PASS |
| Regenerativa e protocolo ativo caminhada/corrida aceitam dose menor | PASS |
| Longão respeita teto de 40% | PASS |
| Prova preparatória de 5 km não apaga longão maior | PASS |
| Teto de 40% calcula treino + prova | PASS |
| Calendário rejeita sessões duplicadas, conflitos e excesso de frequência | PASS |
| Longão deve permanecer maior que as demais sessões | PASS |

## Verificações de versão e backup

- `android/app/build.gradle.kts`: VersionCode 97 / VersionName V97.
- Fonte Android `MainActivity.kt`: motor interno 87.
- `AppBackupCodec`: schema 12; decode aceita schemas 1 a 12.
- Novos campos do snapshot confirmado e adoção estão tipados como strings e incluídos na persistência/backup.
- Testes de schema 12 e compatibilidade com schema 11 estão presentes no projeto, mas não foram executados pela suíte oficial Gradle neste ambiente.

## Limitações

Não há Gradle, wrapper `gradlew` ou Android SDK instalado no ambiente. Portanto, ficaram pendentes:

- `gradle -p android :app:testDebugUnitTest`;
- compilação Compose/Android;
- `assembleDebug` e `assembleRelease`;
- instalação/execução em dispositivo Android 16;
- teste manual de exportar/importar backup na aplicação instalada.

Os 102 testes são do harness Kotlin/JVM focado e **não equivalem** à compilação APK nem à suíte completa Gradle/JUnit.

Workflow disponível: `.github/workflows/android.yml` (`build-apk`).
