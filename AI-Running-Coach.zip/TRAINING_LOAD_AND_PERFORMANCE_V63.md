# Training Load & Performance V63

## Fontes de carga
### Carga externa
- Distância real.
- Duração real.
- Elevação positiva quando disponível.
- Terreno e tipo de sessão.
- Tempo em zonas medido pelo arquivo, quando disponível.
- Tempo em zonas estimado por parciais quando não há série contínua.

### Carga interna
- RPE de sessão.
- Carga sRPE = duração em minutos × RPE, somente quando ambos existem.
- Frequência cardíaca média, quando fornecida.
- Cadência média, quando fornecida.
- Feedback de sensação e dor.

Dados ausentes permanecem ausentes. Estimativas não são apresentadas como medições do relógio.

## Janelas
`TrainingLoadEngine` sumariza:
- 7 dias: carga aguda descritiva.
- 28 dias: volume e carga recente.
- 42 dias: tendência de médio prazo.

A razão 7 dias × 4 / 28 dias é descritiva e não é um limiar universal de risco. O volume medido de quatro semanas só substitui o perfil quando há pelo menos seis atividades em três semanas ISO distintas.

## Prescrição de volume
`LoadPrescriptionEngine` utiliza:
- Volume atual como âncora.
- Semanas ativas nas quatro semanas anteriores.
- Confiabilidade do histórico.
- Recuperação e fadiga.
- RPE médio.
- Tendência sRPE recente.
- Maior corrida recente.
- Teto da faixa de referência do objetivo.

As progressões percentuais e semanas de recuperação são guardrails de engenharia testáveis, não leis universais nem garantia de prevenção de lesão. A referência de volume não é uma meta mínima. Se o atleta já estiver acima da referência, não é reduzido artificialmente apenas para entrar na tabela.

## Monitoramento de desempenho
`PerformanceMonitoringEngine` considera apenas atividades de tipos compatíveis, sem dor, esforço/fadiga altos e distância mínima. Compara o mesmo tipo de sessão e terreno. Quando há amostra suficiente, diferenças grandes de elevação por km são filtradas.

O sinal de pace mais rápido/lento serve para orientar revisão e não recalibra zonas automaticamente.

## Evolução planejado versus realizado
A tela Evolução apresenta últimos 28 dias:
- Quilômetros planejados.
- Quilômetros efetivamente registrados.
- Sessões concluídas / planejadas.
- Aderência por sessão.

Uma sessão marcada concluída sem distância real contribui para aderência, mas não para quilômetros realizados. Feedbacks com distância real podem contribuir mesmo sem um plano correspondente, mas não aumentam o denominador de sessões planejadas.
