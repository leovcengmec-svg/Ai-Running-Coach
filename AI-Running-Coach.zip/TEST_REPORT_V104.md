# Relatório de testes — AI Running Coach V104

## Testes executados nesta sessão

### Motor real de calibração — harness Kotlin/JVM

O arquivo real `AdaptiveZoneCalibrationEngine.kt` foi compilado com `kotlinc` e executado com modelos mínimos de domínio.

**4/4 verificações integradas passaram:**

1. Z1 preserva o lote próprio: Lote A concede 3% e Lote B concede mais 2%, sem depender de origem em Z2/Z3.
2. O Lote B fica disponível antes de completar os próximos 28 dias, quando existem cinco blocos válidos em três sessões posteriores.
3. Dez IDs de blocos aceitos em A/B permanecem distintos e o replay dos blocos do Lote A não gera novo crédito.
4. A cascata preserva Z1=15%, Z2=10% e Z3=5%; reteste de 11/10/2026 tem oportunidade 09/11/2026 e aparece 18 dias atrasado em 27/11 quando não há sessão futura, enquanto uma sessão futura real prevalece quando informada.

### Testes unitários da calibração

A classe real `AdaptiveZoneCalibrationEngineTest.kt` foi compilada e executada com um shim local compatível com as asserções básicas do JUnit e stubs mínimos para modelos/funções externas de domínio.

**22/22 métodos passaram.** Isso inclui os casos de preservação do lote próprio Z1, liberação do Lote B, não reutilização, limites de cascata, anti-reset, comparação de protocolo e reteste vencido.

O shim não equivale ao JUnit/Gradle oficial: os modelos de zona e a construção de registros Cooper/3 km foram substituídos por stubs de teste, enquanto o motor adaptativo e a classe de teste foram os arquivos reais do projeto.

## Verificações estáticas

- `versionCode=104` e `versionName=V104`.
- `CURRENT_ENGINE_VERSION=94`.
- Backup Schema 16; decoder aceita schemas 1–16.
- A lista de zonas adaptativas continua contendo Z1, Z2 e Z3.
- O lote direto por zona continua limitado a 5%; os efeitos acumulados continuam Z1=15%, Z2=10%, Z3=5%.
- A persistência e restauração incluem IDs consumidos, data final de evidência e dados de histórico A/B.

## Ainda pendente

- Execução oficial de `gradle -p android :app:testDebugUnitTest :app:assembleDebug --no-daemon` no GitHub Actions.
- Compilação real de Android/Compose.
- Instalação e validação visual no aparelho Android 16.
- Teste real de exportação/restauração com backup V103/Schema 15 e backup V104/Schema 16.

**Conclusão:** os cenários focais do motor adaptativo passaram localmente; a V104 ainda não está homologada como APK até o CI e o teste em aparelho serem concluídos.
