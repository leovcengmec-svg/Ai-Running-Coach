# AI Running Coach V105 — Relatório de implementação

**Base:** V104 (`versionCode=104`, motor 94, Backup Schema 16)  
**Entrega:** V105 (`versionCode=105`, motor interno 95, Backup Schema 17)  
**Data:** 2026-11-28

## Escopo implementado

### 1. Resultado e feedback próprio da competição
- Adicionada tela/rota de registro de resultado vinculada ao evento da prova, sem exigir seleção de um treino da agenda.
- Aceita distância e tempo final informados manualmente e atividade importada por GPX/FIT/TCX quando o importador fornecer esses dados.
- Salva esforço percebido, sensação, dor, terreno e observações.
- Persiste dados reais importados quando disponíveis: data/hora da atividade, parciais, segmentos de ritmo, tempo por zona calculável, rota, elevação e cadência.
- O resultado é associado à prova pelo `raceEventId` e ao histórico de feedback. A carga semanal existente usa os registros de feedback e a data real, evitando um segundo registro de quilômetros.
- Prova que passou da data sem resultado permanece “aguardando resultado”; só passa a concluída depois de salvar um resultado válido. Estados cancelados permanecem excluídos.
- O tempo isolado da prova não modifica automaticamente Z1–Z5. Evidências temporizadas podem alimentar análise por zona; Cooper e 3 km continuam sendo as referências para atualização fisiológica.

### 2. Exportação Pace Coach
- Exportador competitivo agora serializa somente os trechos da prova.
- Aquecimento e desaquecimento permanecem como orientação separada no AI Running Coach e não integram o arquivo de execução competitiva.
- Validação exige soma das distâncias dos trechos igual à distância oficial do evento (tolerância de 0,02 km) e distância positiva em todos os trechos.
- Teste de exportação atualizado para conferir exatamente três etapas, soma de 5 km no cenário de referência e ausência de etapas de aquecimento/desaquecimento.

### 3. Estilos de execução
Foram adicionados sete modos persistidos por competição: Automático, Contínuo, Progressivo, Regressivo, Final forte, Conservador e Agressivo controlado. A seleção recompõe as faixas de ritmo das três fases, recalcula a projeção ponderada pela distância e mantém os limites das zonas disponíveis. O modo fica gravado no próprio evento e é utilizado pela prévia e exportação.

### 4. Recordes pessoais
- Criada área “Recordes pessoais” acessível por Gerenciar perfil.
- Distâncias padrão: 800 m, 1 km, 1 milha, 3 km, 5 km, 10 km, 15 km, meia maratona e maratona; também há suporte a distâncias personalizadas.
- Exibe as três melhores marcas por distância, com data, ritmo médio, origem e detalhes disponíveis.
- Resultados medidos de atividades de treino e provas são elegíveis; recordes manuais anteriores ao uso do aplicativo também são aceitos.
- Data manual pode permanecer desconhecida e aparece como não informada; o app não inventa datas.
- Novo recorde é celebrado após gravação bem-sucedida, com animação temporária e sem repetir a celebração ao reabrir a tela.
- Registros manuais são persistidos em `manualPersonalRecords` e incluídos no backup.

### 5. Calibração adaptativa e reset
- Corrigido o estado visual do Lote A: evidência suficiente significa “pronto para revisão”, não “confirmado”. Confirmação só aparece quando o crédito próprio foi efetivamente aplicado.
- Z1 mantém lote próprio A/B (até 3% + 2%) e continua recebendo propagação confirmada de Z2 e Z3. Z2 mantém lote próprio e recebe Z3. Tetos efetivos continuam Z1=15%, Z2=10%, Z3=5%.
- Incluído botão “Redefinir calibração” na área de zonas, com confirmação explícita “Resetar a calibração?” e opções Sim/Não.
- Reset restaura Z1–Z5 a partir do último teste fisiológico válido, zera os ajustes adaptativos e efeitos propagados, mantém histórico de auditoria e exige ação separada para atualizar treinos futuros.
- **As atividades e feedbacks anteriores ao reset continuam elegíveis**. O motor inicia um novo ciclo de avaliação e reprocessa o histórico elegível, respeitando a referência do último teste fisiológico e os critérios de qualidade.
- A data do reset é apenas metadado de auditoria; não funciona como filtro de evidências.
- Evidências são deduplicadas por fingerprint de arquivo; para feedback manual, é gerada identidade determinística com timestamp/canonical slot (ou data/tipo/título) e métricas. O mesmo treino recadastrado não vira nova sessão apenas por ter um ID interno novo.
- Cada bloco e sessão permanece identificável para não reutilizar a mesma evidência nos lotes A e B dentro do novo ciclo.

### 6. Backup e versionamento
- `versionCode=105`, `versionName=V105`, motor interno 95.
- Backup Schema 17 adiciona a coleção `manualPersonalRecords` e a contagem correspondente no manifesto.
- O decoder aceita schemas 1–17; campos novos ausentes em backups antigos ficam vazios por compatibilidade.
- Não foi removida a coleção de feedbacks, atividades, provas, avaliações fisiológicas ou histórico anterior.

## Arquivos-chave alterados
- `MainActivity.kt`
- `AdaptiveZoneCalibrationEngine.kt`
- `RacePlanningEngine.kt`
- `RaceStrategyEngine.kt`
- `RaceStrategyWorkoutExporter.kt`
- `PersonalRecordsEngine.kt` (novo)
- `AppBackupManager.kt`
- `android/app/build.gradle.kts`
- testes de calibração, provas/estratégia, exportação, recordes e backup.

## Limitações conhecidas da entrega
A implementação de código e os harnesses focalizados foram executados localmente. A compilação Android/Compose, a suíte JUnit oficial pelo Gradle e a geração do APK ainda precisam ser confirmadas no GitHub Actions, pois esta sessão não dispõe de Gradle, Gradle Wrapper no projeto nem Android SDK.
