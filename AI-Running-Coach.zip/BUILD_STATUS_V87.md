# Build Status — AI Running Coach V87

## Identificação
- `versionCode = 87`
- `versionName = V87`
- `CURRENT_ENGINE_VERSION = 76`
- Backup Schema 4; leitura dos schemas 1–4 preservada.

## Resultado da revisão

- Estratégia por tempo-alvo aplicada às prioridades A/B/C.
- Prioridade A continua sendo a única que controla o macrociclo, taper e recuperação pós-prova.
- B/C substituem uma sessão, sem taper automático; tempo-alvo explícito passa a orientar a execução, sem promover B/C a prova principal.
- Metas agressivas são marcadas como aspiracionais e não são impostas aos blocos.
- Metas conservadoras são mantidas sem aceleração artificial.
- Sem dados suficientes, o app mostra apenas o pace matemático com validação pendente.
- Guia de prova e exportação Pace Coach recebem o tempo-alvo e os ritmos por trecho.
- Alterações da prova marcam o plano como desatualizado e expõem ação de recálculo.

## Verificações executadas

| Verificação | Resultado |
|---|---:|
| `RaceStrategyEngineTest` em harness isolado | 11/11 |
| `RaceDayGuideEngineTest` em harness isolado | 3/3 |
| Smoke test de trechos/exportação Pace Coach B/C | 2/2 |
| Conferência de versão e motor | Aprovada |
| Sincronização dos arquivos Kotlin espelhados | Aprovada |

Os harnesses isolam motores Kotlin/JVM com stubs; não substituem os testes oficiais Gradle nem executam a interface Android.

## Pendente de CI/dispositivo

- Executar `:app:testDebugUnitTest`.
- Executar `:app:assembleDebug`.
- Confirmar compilação Compose e testes JUnit de `RaceEventEngineTest` e `RaceStrategyWorkoutExporterTest` no ambiente Android.
- Instalar APK, editar alvo/prioridade A/B/C, acionar recálculo e conferir plano/agenda.
- Exportar JSON para Pace Coach e importar no aplicativo receptor.

O pacote não deve ser considerado APK certificado antes dessas etapas.
