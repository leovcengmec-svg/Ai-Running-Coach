# AI Running Coach — Plano de Correção V102
## Auditoria do histórico V101: fidelidade visual, rolagem fixa e desempenho dos filtros

**Base:** AI Running Coach V101  
**Próxima versão proposta:** V102  
**VersionCode:** 102  
**Motor interno:** 92  
**Backup Schema:** 14 (sem alteração estrutural prevista)  
**Compatibilidade:** schemas 1–14  
**Status:** auditoria concluída; implementação ainda não realizada.

---

## 1. Resumo executivo

A tela de histórico da V101 já possui informações úteis e permite expandir uma sessão, editar/remover registros e consultar períodos. Porém, a estrutura visual se afastou do modelo de referência do Pace Coach apresentado na terceira imagem. O principal desvio é a quantidade de altura ocupada por cada sessão e a falta da composição compacta com ícone à esquerda, identificação da atividade e três métricas em uma única linha visual.

Também foi identificado um problema estrutural de desempenho: a tela calcula, ordena e relaciona novamente o histórico durante a composição do `HistoryScreen`. A troca de filtro (`Todos`, `Semana`, `Mês`, `Ano`) dispara essas operações na thread de interface. O custo cresce com a quantidade de sessões e feedbacks e pode causar a sensação de travamento relatada.

A V102 deverá corrigir a tela como uma unidade, e não apenas reduzir fontes ou margens. A parte superior — título, filtros e resumo — ficará fixa. Somente a lista de sessões terá rolagem vertical. A linha redundante “Sessões registradas” será removida.

## 2. Comparação das telas: V101 x referência Pace Coach

### 2.1 Cabeçalho e título

**V101 atual**
- Apresenta a identificação “AI RUNNING COACH” e o título “Histórico de treinos”.
- O cabeçalho ocupa uma área vertical maior do que a referência.

**Referência**
- Usa o título curto “Histórico”.
- A hierarquia é direta e libera espaço para o conteúdo.

**Correção V102**
- Usar o título “Histórico”, mantendo a identidade visual do AI Running Coach sem repetir uma linha de marca desnecessária nessa tela.
- Reduzir a margem vertical do cabeçalho, sem comprometer a área de toque ou a leitura.

### 2.2 Filtros de período

**V101 atual**
- Renderiza quatro botões com fundos e bordas individuais, visualmente separados.
- O conjunto parece quatro cartões/pílulas independentes.

**Referência**
- Os quatro períodos ficam dentro de uma única cápsula horizontal.
- Somente a opção ativa recebe preenchimento azul destacado; as demais ficam integradas ao mesmo contêiner.

**Correção V102**
- Criar um seletor segmentado único, com contêiner compartilhado e quatro segmentos de largura equivalente: `Todos`, `Semana`, `Mês` e `Ano`.
- Manter a troca de seleção imediata, sem animação longa nem recálculo pesado na thread principal.
- Preservar o filtro atual e seus limites de data: semana iniciando na segunda-feira, mês corrente e ano corrente.

### 2.3 Card de resumo

**V101 atual**
- Exibe um card alto, com rótulo interno, três números em fonte grande e um parágrafo explicativo.
- A informação está correta, mas ocupa uma área desproporcional e afasta o começo da lista.

**Referência**
- Usa um resumo curto e compacto: período em destaque e uma linha com quantidade de sessões, distância e duração total.
- O resumo atua como contexto, não como outro painel analítico grande.

**Correção V102**
- Reduzir a altura e a quantidade de texto do resumo.
- Apresentar o período/resumo em uma única superfície horizontal visualmente próxima à referência.
- Manter três métricas: quantidade de sessões, distância real medida e duração real medida.
- Não incluir sessões sem distância/duração reais nos totais medidos; manter essa regra atual.
- O título e os números do resumo devem corresponder ao mesmo intervalo selecionado. Exemplos: “Todo o histórico”, “Semana 23–29 nov”, “nov. 2026” ou “2026”.
- O resumo permanece visível quando a lista é rolada.

### 2.4 Linha “Sessões registradas”

**V101 atual**
- Depois do card de resumo apresenta outra linha “Sessões registradas”, com a contagem no período.
- A quantidade já é exibida no resumo, portanto a linha duplica a informação e consome altura.

**Correção V102**
- Remover integralmente a linha “Sessões registradas”.
- A primeira informação depois do resumo deve ser o primeiro agrupamento por data e, em seguida, o card da sessão.
- Não substituir a linha por outro subtítulo redundante.

### 2.5 Cards de sessões

**V101 atual**
- Card alto, com título, data/hora/fonte, ícone de concluído, menu, métricas, esforço/sensação e uma linha “Ver detalhes da atividade”.
- O esforço/sensação e o controle de detalhes aparecem mesmo quando o card está fechado.
- Não há ícone principal da modalidade à esquerda, como na referência.
- A soma desses elementos, margens e espaçamentos deixa cada item visualmente próximo de duas vezes a altura do card compacto mostrado na referência, conforme comparação das capturas.

**Referência**
- Card mais baixo, com ícone de corrida à esquerda, nome da atividade e horário, seguido por três métricas alinhadas: distância, duração e ritmo.
- O card prioriza a leitura rápida da sessão.

**Correção V102**
- Reorganizar o card em duas áreas compactas:
  1. Cabeçalho: ícone colorido à esquerda; nome da sessão e data/hora; menu de três pontos discreto à direita.
  2. Métricas: distância, duração e ritmo médio, alinhados em três colunas.
- O estado concluído pode ser indicado por uma marca pequena, sem competir com o ícone da modalidade.
- Ocultar esforço, sensação, origem GPS, terreno, parciais, zonas, observações e outros dados enquanto o card estiver recolhido.
- Ao tocar no card (ou no controle de expansão discreto), abrir os detalhes dentro do mesmo card.
- Manter as ações existentes no menu de três pontos: editar, remover, vincular, restaurar e excluir definitivamente, conforme o tipo de registro.
- Usar uma altura recolhida de referência entre 150 e 190 dp em aparelhos comuns, ajustada pelo conteúdo e acessibilidade; não fixar altura que corte títulos ou números.
- Título em uma ou duas linhas no máximo, com reticências apenas quando necessário.
- Manter um único card por sessão e identificador estável por `recordId`/identidade de sessão.

### 2.6 Agrupamento por data

- Manter agrupamento cronológico decrescente.
- Reduzir os cabeçalhos de data: usar tipografia menor, caixa alta moderada e espaçamento vertical curto.
- Não utilizar `SectionHeading` de grande altura para cada dia.
- A separação entre datas deve ser clara, porém sem criar grandes áreas vazias.

## 3. Estrutura de rolagem solicitada

A tela atual é construída como uma única `Column` com `verticalScroll(rememberScrollState())`. Por isso, título, filtros, resumo e sessões rolam juntos.

### Nova estrutura obrigatória

```text
MainShell / Scaffold (barra inferior fixa)
└── HistoryScreen — Column(fillMaxSize)
    ├── Cabeçalho “Histórico”                         FIXO
    ├── Filtro segmentado Todos/Semana/Mês/Ano        FIXO
    ├── Resumo compacto do intervalo selecionado     FIXO
    └── LazyColumn(weight = 1f)                       ROLAGEM VERTICAL
        ├── Cabeçalho de data
        ├── Card da sessão 1
        ├── Cabeçalho de data
        ├── Card da sessão 2
        └── ...
```

Requisitos:
- Não colocar `LazyColumn` dentro de outro contêiner com rolagem vertical.
- A área de lista deverá ocupar todo o espaço restante usando `Modifier.weight(1f)`.
- O cabeçalho, filtros e resumo deverão permanecer no mesmo lugar ao rolar a lista.
- A barra de navegação inferior do `Scaffold` continuará fixa.
- Os diálogos de edição, vínculo, remoção e exclusão continuarão fora do conteúdo reciclável da `LazyColumn`, para não perder estado ao rolar.
- Usar `contentPadding` inferior suficiente para que o último item não fique escondido pela navegação.

## 4. Causa estrutural do travamento dos filtros

A inspeção do `MainActivity.kt` da V101 identificou um caminho de cálculo repetitivo dentro de `HistoryScreen`:

1. `completedWorkouts()` percorre os treinos e chama `feedbackForWorkout()` mais de uma vez para cada sessão.
2. `feedbackForWorkout()` chama `activeFeedbackRecords()`, que filtra novamente todos os feedbacks.
3. `feedbackMatchesWorkout()` pode, no caminho de compatibilidade, percorrer novamente toda a lista `workouts` para procurar uma correspondência única por data/tipo.
4. `orphanFeedbackRecords()` repete as verificações de vínculo para os feedbacks ativos.
5. `HistoryScreen` volta a chamar `feedbackForWorkout()` no filtro, na ordenação, no cálculo dos totais e durante a renderização.
6. Todas essas operações são executadas diretamente durante a composição da tela. Ao trocar o período, a tela recompõe a lista inteira.
7. A `Column.verticalScroll` compõe todos os cards de uma vez, em vez de reciclar os itens visíveis.

Esse desenho gera trabalho redundante e pode escalar de forma quadrática ou pior conforme crescem treinos e feedbacks. A V101 não possui uma lista histórica indexada e reutilizada entre filtros.

### Correção de arquitetura V102

Criar uma camada pura de preparação do histórico, preferencialmente `HistorySnapshotEngine.kt`, que receba snapshots imutáveis das listas de treinos e feedbacks e produza:

- sessões vinculadas a treinos;
- feedbacks órfãos/sem vínculo;
- registros removidos;
- data efetiva já resolvida;
- título e horário já formatados ou prontos para apresentação;
- distância, duração e ritmo reais já normalizados;
- identificador estável de cada entrada;
- listas já ordenadas por data decrescente.

Regras técnicas:
- Filtrar `feedbackRecords` ativos e removidos uma única vez por construção do snapshot.
- Construir índices de correspondência por `sessionId` e pela identidade/canonical slot da sessão.
- Preservar exatamente as regras de segurança atuais: fallback por data/tipo só pode vincular quando a correspondência for única; nunca vincular apenas pela data realizada.
- Calcular a data de atividade e os valores derivados uma única vez por registro.
- Reutilizar o snapshot quando apenas `selectedPeriod` mudar.
- Invalidar o snapshot somente quando `workouts` ou `feedbackRecords` mudar.
- Usar `Dispatchers.Default`/coroutine cancelável para montar o snapshot fora da thread principal quando o volume justificar, ou uma preparação indexada equivalente que não bloqueie a composição.
- Enquanto uma atualização estiver sendo preparada, manter a última lista consistente na tela e evitar piscar/limpar todo o histórico.
- Aplicar o filtro de período sobre a lista indexada, sem repetir o relacionamento entre feedback e treino.
- Usar `LazyColumn` com `key` estável (`recordId` ou identidade estável da sessão), nunca o índice da posição.
- Não recalcular/consultar dados de GPS ou arquivos de atividade ao trocar o filtro.

### Transição entre filtros

- A seleção visual muda imediatamente.
- O resumo e a lista atualizam juntos, sem mostrar temporariamente métricas de um período e sessões de outro.
- Preservar o deslocamento da lista quando a troca de filtro mantiver a mesma data/entrada; quando o conjunto mudar completamente, voltar ao topo de modo previsível.
- Cancelar trabalho de preparação obsoleto se os dados mudarem novamente antes da conclusão.
- Evitar animações de expansão/altura que provoquem salto excessivo; transições curtas e discretas.

## 5. Comportamento dos filtros e resumo

| Filtro | Intervalo | Resumo esperado |
|---|---|---|
| Todos | Todo o histórico ativo | Total geral de sessões, distância e duração reais |
| Semana | Segunda-feira até hoje | Total da semana atual |
| Mês | Primeiro dia do mês até hoje | Total do mês corrente, com mês/ano visíveis |
| Ano | Primeiro dia do ano até hoje | Total do ano corrente |

- Os registros removidos continuam em seção própria, sem entrar nas métricas ativas.
- Registros órfãos continuam acessíveis na seção de revisão e não podem ser somados duas vezes.
- Sessões sem medição continuam contando como sessão registrada, mas não adicionam distância/duração medidas.
- O texto do resumo deverá deixar claro quando houver dados sem medição, sem inserir um parágrafo longo dentro do card.

## 6. Arquivos envolvidos

| Arquivo | Alteração prevista |
|---|---|
| `android/app/src/main/java/com/airunningcoach/app/MainActivity.kt` | Reestruturar `HistoryScreen`, criar cabeçalho fixo, filtro segmentado, resumo compacto, `LazyColumn` e card compacto expansível |
| `android/app/src/main/java/com/airunningcoach/app/HistorySnapshotEngine.kt` | Novo motor puro para indexação, vínculo, agrupamento e métricas do histórico |
| `android/app/src/test/java/com/airunningcoach/app/HistorySnapshotEngineTest.kt` | Novos testes unitários de indexação, duplicidade, órfãos, registros removidos e métricas |
| Testes Compose existentes/novos | Validar rolagem fixa, filtros e interação dos cards |
| `CHANGELOG.md`, `README.md`, `PROJECT_STATUS.md` | Registrar V102 |

Não há necessidade de alterar `AppBackupCodec`, `Backup Schema` ou dados persistidos para esta atualização de interface/desempenho. Se a implementação descobrir necessidade de novo campo persistido, deverá ser justificada separadamente; não aumentar o schema apenas por causa da nova composição visual.

## 7. Testes obrigatórios de aprovação

### Estrutura visual
1. Título, filtro e resumo aparecem fixos ao abrir o histórico.
2. Ao rolar, título, filtro e resumo permanecem visíveis.
3. Somente a lista abaixo do resumo rola verticalmente.
4. Barra inferior permanece fixa.
5. A linha “Sessões registradas” não aparece.
6. Primeiro agrupamento por data começa imediatamente após o resumo.
7. Filtro tem um único contêiner segmentado, não quatro cartões independentes.
8. Resumo compacto apresenta período, sessões, distância real e duração real.
9. Card recolhido mostra ícone, nome, data/hora e três métricas.
10. Esforço, sensação, parciais e demais informações aparecem somente ao expandir.
11. Menu de ações continua acessível sem expandir o card.
12. Cards não cortam títulos, números nem alvos de toque em telas estreitas.

### Consistência funcional
13. `Todos` mostra todos os registros ativos uma única vez.
14. `Semana` respeita segunda-feira até hoje.
15. `Mês` respeita o primeiro dia do mês até hoje.
16. `Ano` respeita o primeiro dia do ano até hoje.
17. Resumo e lista sempre usam o mesmo intervalo.
18. Registros órfãos permanecem disponíveis para vínculo.
19. Registros removidos aparecem separados e continuam restauráveis.
20. Sessões sem medição não entram na soma de distância/duração.
21. Alterar feedback atualiza o card e o resumo sem duplicar a sessão.
22. Expandir um card e trocar o filtro não transfere o estado de expansão para outro registro.
23. Editar, remover, restaurar e excluir definitivamente continuam funcionando.
24. O vínculo por fallback continua exigindo correspondência única.

### Desempenho
25. Trocar Todos → Semana → Mês → Ano → Todos dez vezes não bloqueia a interface.
26. A indexação acontece uma única vez enquanto `workouts` e `feedbackRecords` não mudarem.
27. Trocar apenas o filtro não chama novamente `feedbackForWorkout()` para cada treino.
28. `LazyColumn` mantém composição limitada aos itens visíveis e próximos da viewport.
29. Teste de volume com pelo menos 1.000 sessões e feedbacks: filtros responsivos, sem ANR e sem travamento perceptível.
30. Atualizar/importar feedback invalida o snapshot e atualiza corretamente o histórico.
31. Mudanças rápidas dos dados cancelam preparações antigas e não aplicam resultados obsoletos.

### Compatibilidade
32. Backup Schema 14 continua exportando/restaurando normalmente.
33. Nenhuma sessão ou feedback desaparece após a reconstrução do snapshot.
34. O mesmo `recordId` aparece em somente um lugar ativo (ou na seção de órfãos), sem duplicação.

## 8. Critérios de aceite

A V102 somente será considerada aprovada quando:

- a hierarquia visual estiver próxima ao modelo Pace Coach da terceira imagem;
- o cabeçalho, os filtros e o resumo permanecerem fixos;
- a lista tiver rolagem própria, fluida e virtualizada;
- a linha redundante “Sessões registradas” tiver sido removida;
- os cards recolhidos forem compactos e exibirem as três métricas principais;
- detalhes e ações continuarem disponíveis sem perder recursos;
- os filtros não refizerem o relacionamento completo entre treinos e feedbacks;
- o cenário de 1.000 registros passar no teste de desempenho;
- os testes de compatibilidade Schema 14 forem aprovados.

## 9. Parecer final

A correção não deve ser tratada como simples ajuste de margens. O histórico precisa de uma nova composição com cabeçalho fixo, resumo compacto e lista virtualizada. A causa estrutural do travamento está no cálculo repetido de vínculos entre treinos e feedbacks durante a composição, combinado à renderização eager de todos os cards dentro de `Column.verticalScroll`.

A V102 deverá preservar todas as funções já existentes do histórico, mas apresentar primeiro o que o corredor consulta com frequência: atividade, data/hora, distância, duração e ritmo. O restante ficará dentro da expansão do card. Assim, a tela ganha a fluidez e a densidade visual da referência sem perder edição, vínculo, restauração ou integridade dos registros.

**Status final:** V101 auditada; plano V102 elaborado; implementação ainda não realizada.
