# Plano de correção — V81
## Numeração da primeira semana e importação do histórico de treinos

**Status:** plano aplicado na V81; revisão técnica realizada; build Android oficial pendente  
**Versão-base:** AI Running Coach V81 (engine 71)
**Versão após aplicação:** V81 (engine 72; versionCode 81; Backup Schema 4)  
**Prioridade geral:** P0 — integridade do plano e do histórico

---

## 1. Resumo executivo

As quatro capturas mostram dois defeitos distintos, porém relacionados ao calendário e à identidade das sessões:

1. **O plano começa visualmente na semana 2 quando é criado no fim da semana e já não resta nenhum dia de treino disponível naquela semana.** No exemplo de 21/11/2026 (sábado), com disponibilidade de segunda, quarta e sexta, todos os dias de treino da semana 16–22/11 já passaram. A geração elimina as sessões passadas, mas conserva o número 2 das sessões que começam em 23/11.
2. **A importação seletiva de treinos concluídos pode marcar uma sessão futura como concluída e fazê-la desaparecer do dia planejado.** O mesclador associa o histórico ao plano atual exclusivamente por `sessionId`. Entretanto, a V81 cria IDs baseados em semana relativa + dia da semana + tipo, que podem repetir-se em ciclos diferentes. Ao marcar a sessão atual como concluída, a Agenda usa a data real da atividade e move o marcador do dia planejado para o dia histórico.

A segunda captura mostra o treino de 23/11 ainda dentro do card do plano, mas como **Concluído**. A quarta mostra o mesmo card com o estado alterado. Isso indica que a sessão não foi necessariamente apagada do armazenamento: ela foi indevidamente concluída e a Agenda passou a agrupá-la na data real do feedback.

**Nota sobre evidência:** os fluxos e as condições que permitem os dois defeitos estão presentes no código auditado. O arquivo JSON real do backup usado nas capturas não foi anexado; portanto, a colisão de ID específica dessas atividades deve ser confirmada no teste de regressão com uma cópia desse backup. A falha estrutural do mesclador, porém, é verificável independentemente desse arquivo.

---

## 2. Diagnóstico técnico — início na semana 2

### Fluxo atual

- `RaceEventEngine.resolvePlanWindow()` ancora o início na segunda-feira anterior ou igual a hoje (`RacePlanningEngine.kt`, aproximadamente linhas 103–120).
- `RunningCoachEngine` gera as semanas usando essa âncora (`CoachEngine.kt`, aproximadamente linhas 627–630).
- `TrainingScheduleEngine.keepUpcomingSessionsForCurrentWeek()` remove datas anteriores a hoje, mas só força semana 1 para datas que ainda pertencem à semana parcial atual. As sessões da próxima segunda conservam `week = 2`.
- `MainActivity.createPlan()` grava a âncora e usa essas sessões para montar o plano (`MainActivity.kt`, aproximadamente linhas 862 e 945–958).

### Reprodução com as datas das capturas

| Informação | Valor |
|---|---|
| Data de criação | sábado, 21/11/2026 |
| Semana civil atual | 16–22/11/2026 |
| Dias disponíveis ilustrados pelo plano | segunda, quarta e sexta |
| Dias disponíveis restantes em 21/11 | nenhum |
| Primeiro dia de treino possível | segunda, 23/11/2026 |
| Resultado atual | primeiro bloco visível rotulado Semana 2 |
| Resultado correto | 23/11 a 29/11 deve ser Semana 1 |

### Causa

A V81 trata a semana parcial atual como semana 1 mesmo quando já não existe qualquer dia disponível para executar uma sessão nela. A semana fica vazia para o atleta, mas continua consumindo um número do ciclo.

### Correção proposta

Criar uma resolução única da **primeira semana treinável** antes de chamar `RunningCoachEngine.generate()`:

1. Calcular a segunda-feira da semana atual.
2. Cruzar os dias habituais do atleta com as datas dessa semana que sejam iguais ou posteriores a hoje.
3. Se existir pelo menos um dia disponível restante, manter a semana atual como semana 1.
4. Se não existir nenhum dia disponível restante, avançar a âncora para a próxima segunda-feira. Essa segunda-feira será semana 1; não deve ser apenas uma troca do rótulo na interface.
5. Passar a âncora efetiva para `PlanWindow`, `RunnerInput.startDate`, motor de periodização, resumos semanais, agenda de provas e `planStartDateIso`.
6. Manter a duração solicitada do ciclo em semanas completas. Não consumir uma semana sem treino e não reduzir silenciosamente o horizonte.
7. Recalcular a semana de uma prova A em relação à nova âncora. Provas anteriores à nova âncora continuam no calendário, mas não podem deslocar a periodização de um ciclo que só começa depois delas.

**Regra de exceção:** se hoje ainda for um dia disponível (por exemplo, domingo e domingo estiver selecionado), o ciclo pode começar na semana atual. Não avançar automaticamente apenas porque hoje é sábado ou domingo.

### Migração de planos V81 já criados

Além de corrigir novas criações, tratar planos existentes cuja primeira semana ficou vazia:

- Só avançar a âncora automaticamente quando o atleta ainda estiver na primeira semana do ciclo, não houver sessão planejada/concluída nem feedback real nessa semana, e nenhum dia disponível restante puder receber treino.
- Atualizar `planStartDateIso` e regenerar as sessões a partir da nova âncora.
- Não deslocar ciclos em andamento que já tenham sessões concluídas, feedbacks ou atividades associadas à primeira semana.
- Não alterar datas de provas, atividades históricas ou sessões movidas manualmente.
- Registrar a migração para que ela seja aplicada uma única vez e não avance a âncora novamente a cada abertura do app.

---

## 3. Diagnóstico técnico — histórico importado conclui treino futuro

### Fluxo atual

- `CoachEngine.workout()` cria `sessionId` como `W<semana>-<DIA>-<TIPO>` (`CoachEngine.kt`, aproximadamente linha 1732).
- A semana é relativa ao ciclo, portanto a mesma combinação pode ocorrer em ciclos distintos. Exemplo: `W2-MONDAY-AEROBIO` pode identificar a segunda-feira da semana 2 de um ciclo antigo e também a segunda-feira da semana 2 de um ciclo novo.
- `CompletedActivityBackupMerger.merge()` indexa treinos locais só por `sessionId` e, quando encontra o mesmo texto no histórico importado, altera `done = true` sem comparar a data programada (`AppBackupManager.kt`, aproximadamente linhas 172–197).
- O mesclador também marca o treino local como concluído a partir de feedback que tenha o mesmo `sessionId` (`AppBackupManager.kt`, aproximadamente linhas 199–230).
- `MainActivity.completedWorkouts()` considera o `sessionId` suficiente para associar feedback e conclusão (`MainActivity.kt`, aproximadamente linhas 1422–1427).
- A Agenda busca o feedback pelo mesmo ID e, se o treino estiver concluído, `WorkoutCalendarDateResolver` usa a data real da atividade como data de agrupamento (`MainActivity.kt`, aproximadamente linhas 3538–3549; `WorkoutCalendarDateResolver.kt`).

### Como o defeito aparece na interface

1. O backup contém uma sessão concluída de um ciclo anterior.
2. Essa sessão compartilha um `sessionId` relativo com a sessão de segunda-feira, 23/11, do plano atual.
3. A importação seletiva encontra o ID e marca a sessão local de 23/11 como concluída.
4. O feedback histórico é recuperado pelo mesmo ID.
5. A Agenda agrupa a sessão na data real do feedback — por exemplo, 18/11 — em vez de 23/11.
6. O marcador de 23/11 desaparece da Agenda, enquanto o card do Plano continua existindo, mas apresenta “Concluído”.

### Correção proposta — identidade de sessão

Adotar uma identidade imutável por **instância de sessão**, não apenas por posição relativa na periodização.

**Para sessões novas:**

- Atualizar a geração do identificador para incluir a identidade do ciclo e a data programada original, por exemplo: `C<âncora-do-ciclo>-<data-programada>-<slot>`.
- O identificador precisa ser determinístico dentro do mesmo ciclo: recalcular o mesmo ciclo e a mesma sessão deve preservar a identidade.
- Ciclos distintos ou datas originalmente distintas precisam produzir IDs distintos, mesmo que semana, dia da semana e tipo sejam iguais.
- Reagendamento manual não deve trocar a identidade; guardar a data programada original separadamente da data movida.

**Para backups antigos:**

- Não confiar em `sessionId` legado isoladamente.
- Tentar associação por `sessionId` **e** data programada original (`originalScheduledDateIso`, quando houver) ou `scheduledDateIso`.
- Se o ID coincidir, mas as datas forem diferentes, tratar como duas sessões diferentes.
- Se o ID legado não possuir data suficiente para uma associação segura, não concluir a sessão local futura por inferência. Preservar o registro importado como histórico separado, com ID de instância sem colisão.
- Remapear o `sessionId` dos feedbacks importados para a mesma identidade da sessão histórica remapeada. Preservar `activityFingerprint`, `realizedDateIso`, `workoutDateIso`, dados de atividade, blocos e splits.
- Duplicidade de atividade deve ser decidida pelo `activityFingerprint` (quando disponível), e não pela mera igualdade do ID de sessão.

### Correção proposta — regras do mesclador

O `CompletedActivityBackupMerger` deverá trabalhar com uma chave de instância, não com `sessionId` isolado:

1. Construir índice local por identidade da instância.
2. Para cada treino concluído importado, procurar correspondência exata por ID + data original/programada.
3. Se corresponder, atualizar apenas aquela instância local.
4. Se o ID for igual e a data for diferente, acrescentar a sessão histórica em separado e remapear os feedbacks relacionados.
5. Se não houver correspondência, acrescentar o treino concluído sem substituir sessões futuras.
6. Não marcar sessão local como concluída apenas porque algum feedback importado contém o mesmo `sessionId`.
7. Só associar feedback à sessão local quando houver correspondência segura de instância. A impressão digital identifica a atividade física para deduplicação, não a sessão planejada que deve ser concluída.
8. Garantir que a importação seletiva continue preservando integralmente o perfil, o plano atual, as sessões futuras e as alternativas locais.

### Regras de conclusão em memória e na Agenda

- `completedWorkouts()`, `feedbackForSession()` e as telas que procuram feedback devem usar a identidade de instância já normalizada.
- A importação de histórico não pode transformar um treino planejado futuro em concluído sem correspondência segura.
- Se a sessão atual não foi realizada, sua data programada e seu estado `Planejado` devem continuar intactos.
- Uma atividade histórica pode aparecer na data real com a indicação da data planejada original, sem apagar ou concluir outra sessão futura.

---

## 4. Arquivos que precisam ser alterados

| Arquivo | Alteração prevista |
|---|---|
| `RacePlanningEngine.kt` | Permitir que a janela do ciclo receba a primeira semana treinável e recalcular semana da prova A a partir dessa âncora. |
| `TrainingScheduleEngine.kt` | Adicionar resolução testável da âncora efetiva e remover a regra que consome uma semana vazia. |
| `CoachEngine.kt` | Manter datas e semanas alinhadas à âncora efetiva; gerar identidade de sessão única por ciclo/data/slot. |
| `PlanMigrationEngine.kt` | Migrar apenas ciclos V81 recém-criados com primeira semana comprovadamente vazia; preservar histórico e reagendamentos. |
| `AppBackupManager.kt` | Substituir mesclagem por `sessionId` isolado por associação de instância + data; remapear IDs históricos em colisões. |
| `MainActivity.kt` | Usar a âncora resolvida na criação/recalibração; associar feedback e conclusão pela identidade da sessão; preservar a sessão futura após importação seletiva. |
| `WorkoutCalendarDateResolver.kt` | Manter a separação entre data planejada e realizada após a associação correta; evitar mover uma sessão futura por feedback de outro ciclo. |
| `TrainingScheduleEngineTest.kt` | Cobrir sábado sem dia disponível restante, domingo disponível e dias restantes na semana. |
| `RaceEventEngineTest.kt` | Cobrir cálculo de semana de prova A após avanço da âncora. |
| `PlanMigrationEngineTest.kt` | Cobrir migração única de primeira semana vazia e preservação de semanas com atividade real. |
| `AppBackupCodecTest.kt` / teste dedicado do merger | Cobrir colisão de ID, datas diferentes, datas iguais, backup legado sem data e deduplicação por fingerprint. |
| Testes de UI/integração | Validar consistência entre Agenda, Plano, Histórico e persistência depois de importar backup. |

---

## 5. Matriz obrigatória de regressão

### A. Semana 1 e calendário

| Cenário | Resultado obrigatório |
|---|---|
| Sábado 21/11/2026; dias disponíveis seg/qua/sex | Âncora 23/11; treinos 23, 25 e 27/11 são Semana 1. |
| Sábado; domingo é dia disponível | Manter a semana atual como Semana 1 e permitir sessão no domingo. |
| Quinta-feira; sexta e domingo disponíveis | Manter semana atual como Semana 1; não empurrar sessões futuras para Semana 2. |
| Segunda-feira com segunda disponível | Treino do dia e sessões seguintes permanecem na Semana 1. |
| Todos os dias disponíveis da semana já passaram | Próxima segunda vira Semana 1; não exibir uma semana inicial vazia. |
| Plano salvo com semana 1 vazia, sem concluídos/feedbacks nessa semana | Migração única para a primeira semana treinável. |
| Primeira semana com sessão concluída ou feedback real | Não deslocar âncora nem renumerar o histórico. |
| Prova A próxima da nova âncora | Semana da prova e taper coerentes com a âncora, sem contagem negativa ou uma semana de diferença. |

### B. Importação seletiva do histórico

Fixture de regressão prioritária:

- Plano local: `sessionId` legado `W2-MONDAY-AEROBIO`, `scheduledDateIso = 2026-11-23`, `done = false`.
- Backup histórico: mesmo `sessionId`, `scheduledDateIso = 2026-11-16`, `done = true`, com feedback/atividade realizada em `2026-11-18`.

Resultado obrigatório:

- A sessão de 23/11 permanece `done = false`, com status **Planejado**.
- O histórico de 16/11 permanece concluído e é exibido na data real 18/11, mantendo também sua data planejada.
- A Agenda continua mostrando o marcador do treino de 23/11.
- O Plano continua mostrando o treino de segunda-feira, 23/11, como **Planejado**.
- A importação não altera perfil, zonas, disponibilidade, volume-alvo, plano atual nem sessões futuras.
- Não há perda de feedbacks nem atividade duplicada.

Outros casos obrigatórios:

1. Mesmo ID e mesma data original: associar à mesma instância e marcar concluída.
2. Mesmo ID e datas diferentes: manter duas instâncias independentes.
3. Mesmo ID sem data no backup antigo: não concluir sessão futura por inferência.
4. Fingerprint repetida: ignorar cópia duplicada da mesma atividade.
5. Fingerprints diferentes com IDs legados iguais: preservar duas atividades distintas e remapear IDs sem colisão.
6. Backup completo: continuar restaurando exatamente o snapshot escolhido, sem aplicar as regras de mesclagem seletiva.
7. Importação seletiva: não substituir o plano atual e não recalibrá-lo automaticamente.

---

## 6. Critérios de aceite

A correção só poderá ser considerada concluída quando todos os itens abaixo forem atendidos:

- [ ] Para o caso de 21/11/2026, o primeiro card do plano passa a ser **Semana 1**, com âncora em 23/11/2026.
- [ ] As datas, quilometragens, fases, estímulos e resumos semanais são gerados a partir da nova âncora; não foi feita apenas uma alteração visual no rótulo.
- [ ] Semanas de prova, taper, recuperação e metas continuam coerentes após a mudança.
- [ ] Importar histórico antigo nunca marca uma sessão futura de outro ciclo como concluída.
- [ ] O treino de 23/11 continua visível na Agenda e no Plano como **Planejado** depois de importar o backup de histórico.
- [ ] As atividades históricas permanecem no Histórico, com a data real correta e sua data planejada preservada.
- [ ] O comportamento foi validado com o JSON de backup utilizado pelo usuário, além das fixtures artificiais.
- [ ] Exportar backup após a importação e restaurá-lo em instalação limpa mantém o resultado.
- [ ] `:app:testDebugUnitTest` passa integralmente.
- [ ] `:app:assembleDebug` gera APK sem erros.
- [ ] Teste manual no Android confirma Agenda, Plano, Histórico, conclusão de treino e nova importação.

---

## 7. Ordem de execução recomendada

### P0 — Integridade do histórico (primeiro)

1. Corrigir a identidade das instâncias e o mesclador seletivo.
2. Remapear feedbacks históricos quando houver colisão de IDs legados.
3. Adicionar testes que reproduzam a colisão entre 16/11 e 23/11.
4. Confirmar que a Agenda não desloca o treino futuro após a importação.

### P0 — Âncora da primeira semana

1. Implementar a resolução da primeira semana treinável a partir dos dias disponíveis.
2. Passar a âncora corrigida a todos os motores e resumos.
3. Implementar migração segura para planos existentes com semana inicial vazia.
4. Cobrir prova A, dias restantes e exceções de fim de semana.

### P1 — Integração e compatibilidade

1. Validar leitura de backups V78–V81 com IDs antigos.
2. Validar o backup usado nas capturas, se fornecido, sem expor dados pessoais nos logs.
3. Executar testes Gradle completos e build do APK.
4. Executar roteiro manual de importação/exportação no Android.

### P2 — Observabilidade e proteção futura

1. Registrar, no relatório da importação, quantas sessões foram associadas por identidade exata, quantas foram adicionadas como histórico e quantas ficaram sem associação segura.
2. Avisar quando um backup antigo não tiver dados suficientes para associar uma atividade a uma sessão planejada.
3. Adicionar invariantes de consistência: sessão futura não pode ser concluída por histórico com data planejada incompatível.

---

## 8. Conclusão

Os prints não indicam apenas uma preferência visual. O primeiro caso consome indevidamente a primeira semana do ciclo quando nenhum treino ainda pode ser realizado nela. O segundo compromete a integridade entre histórico e plano: uma sessão concluída de um ciclo anterior pode ser associada a uma sessão futura por igualdade de ID relativo; depois, o calendário a move para a data real antiga.

A correção deve atuar nos motores de calendário e identidade de sessão e no mesclador de backup. **Não corrigir somente os rótulos nem apagar o status de concluído na interface**, pois isso esconderia o efeito sem reparar a associação de dados.

## 9. Resultado da aplicação e revisão

O plano foi aplicado diretamente ao código da V81. A revisão incluiu também salvaguardas adicionais: identidade por data original + tipo tem prioridade sobre ID relativo ao reaplicar reagendamentos; a data reagendada não substitui a data original ao mesclar o histórico; feedback tipado não conclui uma sessão de outro tipo; feedback legado sem tipo só é associado quando existe uma única instância possível. Análises planejado/realizado, zonas por bloco, substituição por prova e numeração de exportação também passaram a distinguir instâncias por data e tipo.

**Arquivos de produção alterados nesta correção:** `TrainingScheduleEngine.kt`, `RacePlanningEngine.kt`, `PlanMigrationEngine.kt`, `SessionIdentityEngine.kt`, `MainActivity.kt`, `AppBackupManager.kt`, `PlannedVsRealizedEngine.kt`, `WorkoutBlockFeedbackEngine.kt` e `WorkoutExportNaming.kt`. As correções de motor/ritmo da auditoria técnica anterior permanecem no mesmo pacote V81.

**Arquivos de teste atualizados/adicionados:** `TrainingScheduleEngineTest.kt`, `RaceEventEngineTest.kt`, `PlanMigrationEngineTest.kt`, `PlanMigrationRescheduleTest.kt`, `SessionIdentityEngineTest.kt`, `AppBackupCodecTest.kt`, `PlannedVsRealizedEngineV63Test.kt`, `WorkoutBlockFeedbackEngineTest.kt` e `WorkoutExportNamingTest.kt`.

**Validação disponível nesta revisão:** 25 verificações Kotlin/JVM isoladas passaram com 0 falhas. Os testes JUnit do backup foram adicionados, mas não executados localmente por ausência de Gradle/Android/`org.json`. O APK ainda precisa ser compilado e validado pelo GitHub Actions e testado com o backup que reproduziu o problema.

O código mantém `versionCode = 81`, `versionName = V81` e Backup Schema 4. `CURRENT_ENGINE_VERSION` passa a 72 para que planos com o motor 71 sejam sinalizados para revisão/recálculo.

**Não declarar aprovação final do APK** antes de `:app:testDebugUnitTest`, `:app:assembleDebug` e o teste real de importação/restauração no Android.
