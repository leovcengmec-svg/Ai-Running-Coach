# Build Status — AI Running Coach V94

- Base: AI Running Coach V93 Build Fix.
- `versionCode = 94` · `versionName = V94`.
- `CURRENT_ENGINE_VERSION = 84`.
- Backup Schema 9; leitura dos schemas 1–8 mantida.
- Calendário mensal: título resumido visível, célula 94 dp e marcador 27 dp; categoria deriva da sessão selecionada.
- Reteste: revisão de evidências no dia 28; teste disponível a partir do dia 29 após quatro semanas completas, no primeiro treino da semana seguinte.
- Adesão: mínimo de 4 sessões programadas em 3 semanas ativas, mais conclusões do que faltas e ausência de dor. Se não elegível, teste adiado.
- Opção 1 de substituição recupera snapshot integral da sessão real da semana; opção 2 oferece uma sessão de menor exigência em Z2 para treinos de qualidade.
- Reteste oferece seleção Cooper 12 min ou teste de 3 km; botão de resultado e categoria do calendário dependem do estado efetivo da sessão.
- Harness Kotlin/JVM focado (`RetestCycleEngine` + `WorkoutAlternativeEngine`) passou.
- JUnit/Gradle, compilação Android/Compose e APK ainda aguardam GitHub Actions. Gradle e Android SDK não estão disponíveis neste ambiente.

Workflow: `.github/workflows/android.yml` (`gradle -p android :app:testDebugUnitTest :app:assembleDebug --no-daemon`).
