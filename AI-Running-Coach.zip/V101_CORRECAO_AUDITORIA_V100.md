# AI Running Coach V101 — Relatório de implementação

**Base:** V100  
**VersionCode:** 101  
**VersionName:** V101  
**Motor interno:** 91  
**Backup Schema:** 14 (mantido; leitura compatível com schemas 1–14)

## Resumo

Aplicado o plano V101 sobre o source set Android compilado em `android/app/src/main/java/com/airunningcoach/app/`. As alterações mantêm as proteções da V100: identidade e ciclo de oito semanas, semana atual, histórico concluído, feedbacks, limite de 40% do longão, regras de piso de sessão para o objetivo de 5 km e estrutura de backup Schema 14.

## 1. Exportação Pace Coach

- `PaceCoachExporter.workoutToJson()` deixou de passar o título de apresentação ao validador do protocolo.
- `TrainingProtocolCatalog.validateNamedProtocol()` mantém a assinatura compatível, mas não compara título completo. A validade continua dependendo de protocolo, blocos, dose, repetição, recuperação, sequência e estrutura executável.
- Corrigida a validação de dose reduzida permitida: a quantidade de índices de trabalho é comparada ao total de repetições realmente encontradas, enquanto limites e alternância continuam obrigatórios.
- `MainActivity.ExportScreen` agora executa validação e geração do JSON dentro de `try/catch`; só cria o arquivo e abre o Android Sharesheet após o JSON ficar pronto.
- Em falha, o app remove eventual arquivo temporário, registra o erro técnico no log `AIC_PaceCoachExport`, apresenta mensagem ao usuário e mantém a prescrição/histórico intactos.

## 2. Nomes de exportação

- Implementado o padrão `S{semana}_T{número}_{SIGLA}_{VARIANTE}`.
- A semana usa `workout.week`; a ordem do treino usa a ordem cronológica das sessões da mesma semana e a identidade original da sessão.
- `WorkoutExportNaming.normalizeForExport()` só aceita nome proposto que já esteja no contrato compacto. Rótulos longos legados são substituídos por nome derivado do protocolo/segmentos.
- Prévia da tela, `UserWorkoutJson.workoutName` e arquivo anexado usam a mesma função/identificador.
- Exemplos cobertos: `S3_T2_INT_2x10min`, `S3_T3_LNG_ProgressivoZ2` e `S4_T1_TMP_ContinuoZ3`.
- A nomenclatura não altera `sessionId` nem grava novos dados no backup.

## 3. Classificação do calendário

- Adicionada a família `TEMPO_RUN`, sigla `TMP`, cor própria e ícone vetorial de esforço contínuo.
- `T01` / `TEMPO_RUN_ESTIMATED` passa a ser `TMP`.
- `T04/T05`, `I04–I10` e `RPxx` fracionados permanecem `INT`.
- `F01–F04` permanecem `FAR`; `CC01` e progressões contínuas permanecem `ROD`.
- Prova, teste, iniciação, regenerativo e longão mantêm prioridade de classificação.
- Removida a regra genérica que classificava qualquer `type == "Qualidade"` como `INT`. Sem protocolo/estímulo de intervalo, o tipo genérico não pode sobrepor a modalidade real.

## 4. Periodização e variedade

- Em blocos de construção, a sequência de maior demanda fica limitada a dois estímulos mais exigentes antes de uma semana aeróbia/moderada ou sem protocolo intenso.
- Na terceira semana do bloco, quando a prontidão permite, o seletor prefere `F04` moderado (ou `CC01` aeróbio conforme o gate), em vez de empilhar mais um treino de limiar/intervalado.
- A quarta posição do ciclo não recebe protocolo principal de qualidade intenso; fases regenerativa/taper/pós-prova continuam sem qualidade intensa.
- Mantida uma única sessão principal de qualidade na semana quando a frequência é de três dias; a seleção continua subordinada a fase, objetivo, zonas, volume, maior sessão, recuperação, fadiga, dor e consistência.
- Não foi criada quota fixa de Fartlek. A variedade continua condicionada à prontidão e à fase.
- `protocolSelectionAudit()` agora registra fase, ciclo, protocolo, modalidade, estado de limiar/VO₂ e razões específicas que bloquearam cada gate (ex.: frequência menor que quatro dias, volume insuficiente, recuperação/fadiga ou maior sessão abaixo do requisito).

## 5. Backup e compatibilidade

- Schema 14 mantido sem novos campos.
- A propriedade informativa `appVersion` dos novos backups foi atualizada de `V100` para `V101`.
- Testes de backup ajustados para esperar `V101` nos backups recém-criados e continuar simulando/restaurando versões anteriores (V99, V92, V91, V90, V89, V78 etc.).

## Arquivos principais alterados

- `PaceCoachExporter.kt`
- `TrainingProtocolCatalog.kt`
- `WorkoutExportNaming.kt`
- `WorkoutCalendarPresentation.kt`
- `TrainingPeriodizationEngine.kt`
- `CoachEngine.kt`
- `MainActivity.kt`
- `AppBackupManager.kt`
- `android/app/build.gradle.kts`
- testes de exportação, nomenclatura, classificação, periodização e backup.

## Limitações de validação

A validação de domínio foi executada com Kotlin/JVM e stubs locais leves para tipos Android/JSON ausentes neste ambiente. Ela valida as regras e o caminho de exportação, mas não substitui a suíte JUnit com `org.json` real, a compilação Compose/Android, o Android Sharesheet nem a importação real no Pace Coach. Essas validações dependem do workflow GitHub Actions e do teste no dispositivo.
