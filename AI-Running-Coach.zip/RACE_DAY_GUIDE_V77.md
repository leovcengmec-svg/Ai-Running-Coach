# Race Day Intelligence — V77

Cada prova futura cadastrada apresenta orientação ajustada à distância, prioridade da competição (A/B/C) e prioridade do atleta.

## Conteúdo apresentado
- Preparação na véspera e logística.
- Aquecimento proporcional à distância.
- Estratégia de largada e controle do esforço.
- Orientação para a parte central e trecho final.
- Hidratação e energia conforme duração/distância, usando apenas estratégias previamente testadas.
- Recuperação após a chegada.

## Influência da prioridade do atleta
- Completar: esforço sustentável, sem perseguir outros corredores na largada.
- Correr continuamente: prioriza regularidade e continuidade, sem pausas planejadas.
- Recorde pessoal: largada controlada, parciais e aceleração final apenas se houver reserva.
- Tempo definido: usa o tempo-alvo cadastrado e recomenda validar o ritmo nos treinos; sem alvo, utiliza desempenho recente.

## Influência da prioridade da prova
- A: prova principal, integrada ao ciclo e ao taper.
- B: prova preparatória, ensaio de ritmo/equipamento/abastecimento; sem tentativa máxima automática.
- C: prova de treinamento, mantendo o propósito da sessão e sem taper completo automático.

As orientações são recomendações de execução e não aconselhamento médico. Alimentação, líquidos e intensidade devem respeitar tolerância individual, clima, duração e estratégias testadas nos treinos.
