# Contrato de backup e restauração — V54

## Escopo do backup

O arquivo inclui todas as preferências persistidas, perfil do atleta, ciclo de treinamento, sessões, feedbacks, atividades importadas, avaliações Cooper, calibração das zonas, competições, estado do treinador e dados de evolução. Navegação transitória não é restaurada.

## Integridade do arquivo

O schema 2 inclui SHA-256 sobre as preferências tipadas canonizadas e contagem de sessões, feedbacks, avaliações Cooper e competições. O aplicativo verifica o manifesto antes de executar `SharedPreferences.clear()`. Se a assinatura ou uma contagem não corresponder, a restauração é cancelada e os dados atuais ficam intactos. Schema 1 continua aceito para compatibilidade com backups antigos.

## Migração do plano

Para um backup com ciclo ativo, a segunda-feira de `planStartDateIso` é a referência inicial da semana 1. Se o campo já tiver sido reancorado por uma restauração anterior, o motor cruza as datas e os números `week` gravados em cada sessão para inferir a âncora original, desde que haja evidência consistente. A migração reconstrói o período completo armazenado em `planWeeks`, preserva sessões históricas/feedbacks existentes e completa sessões prescritas ausentes. A semana de cada sessão é normalizada pela distância em semanas entre sua segunda-feira e a âncora. Um ciclo encerrado não é reaberto; nesse caso, o motor inicia um ciclo novo.

## Inclusão de sessões extras

A consulta oferece uma sessão leve e, quando os dados sustentam, uma sessão aeróbia moderada. Sessões pendentes, limite de frequência, extras já incluídas, sessões exigentes próximas, competição, dor e fadiga aparecem como avisos de risco. A inclusão exige ação explícita. Datas futuras distantes permanecem disponíveis, com aviso de que a recomendação é preliminar; datas passadas não recebem novas sessões. Uma sessão extra tem identidade própria e não remove, substitui ou transfere sessões do plano principal.
