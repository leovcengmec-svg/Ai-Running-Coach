# Correção de compilação — AI Running Coach V78

## Erro reportado no GitHub Actions

O workflow `build-apk` falhou em `:app:compileDebugKotlin` com:

`MainActivity.kt:881:28 Unresolved reference: manuallyPlacedSessions`

## Causa

O fluxo de reconstrução do plano cria `manuallyPlacedFullPlan` (plano regenerado com as datas de reagendamento manual reaplicadas) e, em seguida, `remainingCycleSessions` (somente sessões de hoje e futuras). A chamada de `RaceEventEngine.applyToPlan` utilizava um identificador inexistente, `manuallyPlacedSessions`.

## Correção

Substituído o argumento por `remainingCycleSessions`. Essa é a lista correta para a etapa de ajustes de competições: as datas manuais já foram restauradas e as sessões passadas já foram filtradas antes de aplicar taper/substituições. O conjunto `previousManualDates.keys` continua protegido em `protectedSessionIds`.

## Escopo e compatibilidade

- Correção localizada em `MainActivity.kt`; não altera a lógica dos novos registros por bloco.
- Preserva `versionCode = 78`, `versionName = V78` e `CURRENT_ENGINE_VERSION = 68`; trata-se da correção de build da mesma versão ainda não publicada.
- Não altera o formato nem a compatibilidade do Backup Schema 3.

## Validação local

- Confirmado que `manuallyPlacedSessions` não permanece no código-fonte.
- Confirmado que `remainingCycleSessions` é declarado imediatamente antes da chamada e tem o tipo esperado (`List<PrescribedWorkout>`).
- O build Android completo precisa ser executado no GitHub Actions, pois este ambiente não possui Gradle CLI/Wrapper nem Android SDK.
