> Histórico da V69, substituída pela revisão consolidada V70.

# V69 — correções e validação

## Base
Pacote de entrada: `v68_release_AI-Running-Coach.zip`.

## Correção implementada nesta revisão
- Exportação Pace Coach: o grupo repetitivo é representado por uma etapa `repeat` com filhos associados ao mesmo `groupId`/`parentGroupId`.
- Recuperação: `stepTypeKey` passa a ser `recovery`, de acordo com o JSON de importação fornecido.
- Cada etapa recebe `coachRhythm = 1`.
- Versionamento: versionCode 69, versionName V69, engineVersion 54, Backup Schema 2.
- Backup exportado identifica V69; compatibilidade de schema é mantida.

## Testes adicionados
`PaceCoachExporterTest`: sequência de aquecimento, grupo 4x intervalo/recuperação e desaquecimento, ordem, tipo das etapas, contagem e vínculos de grupo.

## Limitação de validação
Não foi possível executar `:app:testDebugUnitTest` nem `:app:assembleDebug` neste ambiente: Gradle não está instalado e o pacote não contém Gradle Wrapper. O workflow existente executa ambos no GitHub Actions. A aprovação final depende do CI e da importação/execução em aparelho com Pace Coach.
