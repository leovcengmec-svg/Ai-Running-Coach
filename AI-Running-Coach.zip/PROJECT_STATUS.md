# Project Status — AI Running Coach V70

## Estado atual

- Versão de origem: V70 (`versionCode 70`, `versionName V70`).
- Motor: `engineVersion 55`.
- Backup: Schema 2, exportado com `appVersion V70`.
- Base: código-fonte V69 fornecido pelo usuário; correções consolidadas em uma única revisão.

## Entregas da V70

- Importação seletiva de atividades concluídas com mesclagem de workouts/feedbacks, deduplicação por impressão digital ou sessão e preservação do plano/perfil local.
- Restauração integral mantida como uma operação distinta e substitutiva.
- Progressão de volume com referência de construção separada da semana de recuperação; referência mínima por distância é usada como direção, sem saltos forçados.
- Longão com limite progressivo no ciclo e bloqueio de progressão quando há dor, recuperação insuficiente ou fadiga elevada.
- Campo de recorde pessoal atual para a intenção de melhorar RP, separado do tempo-alvo.
- Identificadores técnicos removidos dos títulos exibidos e dos nomes usados para exportação.
- Exportação Pace Coach com `groupId` único por etapa, `parentGroupId` somente para filhos de repetição e distância em centímetros no valor de contrato, com exibição em metros.
- Idade atual centralizada no perfil; idade histórica do teste separada e sem ser preenchida por inferência a partir da idade atual.
- Documentação e changelog atualizados para V70.

## Validação pendente

- Gradle/JUnit e APK Debug/Release no GitHub Actions.
- Teste em aparelho para importação seletiva e restauração integral.
- Teste de ponta a ponta da importação e execução de intervalados no Pace Coach instalado.

O ZIP de origem não traz Gradle Wrapper e o ambiente local não tem Gradle/Android SDK. A integridade do código-fonte/ZIP será verificada localmente; não declarar os itens acima como aprovados sem execução do pipeline e teste real.
