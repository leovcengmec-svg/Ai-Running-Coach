# Status atual — V46

- Feedback subjetivo é persistido e exibido no histórico mesmo sem distância/tempo; gráficos e carga usam somente métricas reais informadas.
- O pace do teste da fala pode ser salvo sem distância ou duração total; apenas observações elegíveis, confortáveis e sem dor participam da calibração Z2.
- A Z2 usa registros recentes consistentes, mediana e limites conservadores; aplicação ao plano é explícita e não eleva a carga automaticamente.
- Faixas ativas são percentuais internos de cada zona: 100% equivale ao pace mais rápido e 0% ao mais lento; não representam %VO₂máx.
- Alternativas redefinem os metadados de zona antes de aplicar a faixa ativa.
- Biblioteca redesenhada, com status real de uso no motor e 13 modalidades; repetições em subida continuam identificadas como não geradas automaticamente.
- Backup completo em JSON versionado cobre os dados persistidos no SharedPreferences, com validação prévia e confirmação antes da restauração; o arquivo não é criptografado.
- `versionCode = 46`, `versionName = V46`, `engineVersion = 36`; nome canônico do ZIP `AI-Running-Coach.zip`.

## Histórico — status V42

## V40 — Exportação compatível com o formato nativo do Pace Coach
- A exportação deixa de usar o envelope proprietário `pace-coach-workout` 6.0.
- Adota a chave raiz `com.garmin.connect.workout.json.UserWorkoutJson`, conforme arquivo real de referência fornecido pelo usuário.
- Gera `workoutId`, `workoutName`, datas GMT, `ownerId=0`, `sportTypeKey=running` e `workoutSteps`.
- Etapas por tempo são convertidas para milissegundos; etapas por distância para metros; pace é convertido para `centimetersPerMillisecond` com os dois limites numéricos ordenados.
- Segmentos repetidos adjacentes são exportados como grupo `repeat` com filhos referenciados por `groupId`/`parentGroupId`; aquecimento, intervalos, recuperação e desaquecimento recebem tipos nativos.
- Testes atualizados para validar envelope, campos, conversões de unidade, pace, grupos, IDs e ordenação.
- `versionCode = 40`, `versionName = V40`; nome canônico do ZIP preservado.

## V39 — Semana atual mantida na agenda

- O início do ciclo passa a usar a segunda-feira da semana corrente (`previousOrSame`), não a próxima segunda-feira.
- Em geração/recalculo durante a semana, sessões com data anterior a hoje são omitidas; sessões a partir de hoje continuam na semana corrente, sem realocação artificial.
- A semana parcial corrente recebe índice 0 e aparece como “SEMANA EM ANDAMENTO”; as semanas completas seguintes são reindexadas a partir de 1.
- Competições anteriores a hoje não interferem no plano; provas de hoje ou futuras continuam elegíveis para ajuste.
- Eventos apresentados por semana no plano respeitam a nova numeração.
- `engineVersion = 32`; `versionCode = 39`, `versionName = V39`.

## Regras permanentes
- Nome fixo do ZIP: `AI-Running-Coach.zip`; nunca renomear.
- AI Running Coach prescreve e acompanha; Pace Coach executa e registra.
- Distâncias exclusivamente em km.
- Todo pace apresentado ou exportado como `mm:ss min/km`.
- Tempo decorrido pode ser `mm:ss` ou `hh:mm:ss`; não confundir com pace.

## Base preservada da V26
- Teste de Cooper de 12 minutos, zonas Z1–Z5 e refinamento inicial da Z2 pelo teste da fala.
- O Cooper e as zonas permanecem estimativas de campo, não limiares medidos em laboratório.
- Registro de feedback, histórico de calibração, snapshots de zonas e exportação de sessões continuam preservados.

## V27 — Competições e periodização por data
- Nova entidade `RaceEvent`: nome, distância em km, data, prioridade A/B/C, tempo-alvo opcional, local, observações e estado.
- Cadastro, edição, exclusão e marcação de competição realizada.
- A prova A futura orienta o ciclo; se não existir A, uma prova B futura pode ser usada como referência. A distância da prova principal passa a ser o objetivo específico do motor.
- A janela do plano é resolvida com base na prova. Até 16 semanas de planejamento são geradas; a semana de prova e, quando possível, uma semana posterior ficam incluídas.
- Cada competição planejada dentro do horizonte substitui uma sessão do número semanal configurado. Para provas no sábado/domingo, o longão é priorizado para substituição; em outros dias, a sessão mais próxima é removida.
- Provas A/B acionam redução de carga pré-prova e recuperação pós-prova. Provas C substituem uma sessão, mas não acionam taper automaticamente.
- Taper: redução progressiva em 7–21 dias conforme distância da prova; a última semana elimina os estímulos fortes e mantém apenas ativações leves.
- Recuperação pós-prova: 5–21 dias conforme a distância; sessões afetadas são reduzidas, leves e condicionadas à ausência de dor/recuperação adequada.
- Calendário reconstruído com visualização mensal, semanal e por dia. Competições e treinos aparecem como compromissos distintos.
- Mudanças nos eventos sinalizam necessidade de recálculo; treinos concluídos são preservados. A partir da V39, o ciclo inclui desde a segunda-feira da semana corrente e conserva apenas sessões ainda futuras; sessões passadas não são recriadas.
- Eventos além do horizonte de 16 semanas permanecem visíveis no calendário, enquanto o ciclo atual desenvolve a base; uma prova distante não substitui o objetivo do bloco atual.

## Limitações conhecidas
- Taper e recuperação são regras conservadoras de planejamento, não protocolo individual validado clinicamente. Devem ser avaliados com histórico e feedback real.
- Evento é armazenado e mostrado no AI Running Coach; o contrato de exportação atual não envia um objeto de competição ao Pace Coach. A sincronização automática de eventos depende de um receptor correspondente no Pace Coach.
- Quando o cadastro de prova muda depois da geração do plano, é necessário selecionar explicitamente `Recalcular preparação`.
- Provas já ocorridas permanecem no histórico/calendário e não comandam a nova prescrição.

## Validação V27
- Componentes de domínio Kotlin (motor e eventos) compilados isoladamente.
- 20 smoke tests de eventos executados: validação estrita de dados/datas, janela de plano, substituição de sessão, taper, recuperação, eventos cancelados/fora do horizonte, múltiplas provas na mesma semana e frequências de 2 a 6 dias.
- 13 testes JUnit correspondentes adicionados em `RaceEventEngineTest.kt`.
- Sintaxe da MainActivity inspecionada pelo parser Kotlin; compilação Android/Compose completa ainda precisa ser confirmada pelo GitHub Actions.


## V28 — Correção de compilação Android
- Corrigido o construtor inválido `MutableSet<Int>()` em `SevenDayBreakdown`; substituído por `mutableSetOf<Int>()`, implementação mutável válida da interface `MutableSet`.
- Mantida a lógica do gráfico semanal: identifica os dias com competições para aplicar a apresentação visual correspondente.
- `versionCode = 28` e `versionName = V28`.
- A compilação Android completa deve ser confirmada pelo workflow GitHub Actions.

## Revisão V29
- Disponibilidade semanal individual persistida (2–6 dias) e recebida pelo motor.
- Preferência de dia de longão aplicada ao gerador.
- Reagendamento pontual na mesma semana com validação de colisão, prova, conclusão e recuperação entre sessões exigentes.
- Calendário identifica tipos específicos de sessão com cores/abreviações.
- Testes de domínio adicionados em `TrainingScheduleEngineTest.kt`.
- A compilação Android completa ainda precisa ser confirmada no GitHub Actions.


## V29 — Agenda configurável
- Perfil e onboarding permitem selecionar os dias habituais de corrida e o dia preferido do longão.
- Perfis V28 são migrados usando os dias padrão correspondentes à frequência anterior; o atleta pode alterar antes do próximo recálculo.
- Motor recebe a lista de dias e agenda exatamente nesses dias, mantendo o dia escolhido para o longão.
- Sessões não concluídas podem ser movidas para outro dia livre da mesma semana; o dia extra é tratado como exceção pontual, sem modificar a disponibilidade habitual.
- Reagendamento bloqueia data passada, semana diferente, colisões, prova e sessões exigentes próximas; treinos concluídos não podem ser movidos.
- O histórico de sessão, dose, pace e blocos permanece inalterado; data original e novo agendamento são persistidos.
- Calendário usa cores/abreviações específicas para modalidades.
- 8 testes unitários do motor de agenda verificados localmente e matriz de 434 combinações de disponibilidade/dia preferido aprovada.
- Preferência de longão limpa com segurança quando o atleta está editando uma disponibilidade ainda incompleta no onboarding.
- Reagendamentos manuais preservados durante ajustes da semana corrente provocados por eventos, quando a identidade e a semana da sessão permanecem compatíveis.
- Compilação Android/Compose completa ainda depende do GitHub Actions.


## V31 — Apresentação compacta e alternativas coerentes
- A tela de sessão apresenta somente a prescrição selecionada, com botão compacto “Trocar treino”. A alternativa é exibida em AlertDialog apenas quando solicitada; é possível escolher a alternativa ou retornar à principal.
- Removido o resumo duplicado de distância/duração/pace, já apresentados no cartão principal. Ações de reagendamento e feedback ficaram em botões secundários compactos; exportação é a ação primária.
- Alternativas isoladas em `WorkoutAlternativeEngine.kt` para reutilização na tela de sessão, calendário e exportação.
- Alternativa de sessão de qualidade troca os intervalos por corrida aeróbia contínua em Z2; longão ganha formato com pausas confortáveis em Z1; sessões comuns/regenerativas recebem formato corrida-caminhada leve em Z1.
- Ritmos dos blocos são recalculados pela zona presente no snapshot da sessão; sem snapshot de calibração, os campos numéricos de pace permanecem vazios.
- Identidade, data, semana, distância, duração, reagendamento e snapshot da sessão são preservados. A escolha continua armazenada em `selectedOption`; calendário e exportação usam a mesma sessão ativa.
- Cinco testes JUnit adicionados em `WorkoutAlternativeEngineTest.kt`.
- `versionCode = 31`, `versionName = V31`.
- Compilação Android/Compose completa ainda precisa ser confirmada pelo GitHub Actions.


## Revisão V32 — Ícone do aplicativo
- Criada identidade de launcher baseada no símbolo de corredor já aprovado para o AI Running Coach, com paleta azul-ciano e azul-marinho.
- Incluídos ícones adaptativos do Android (camadas de fundo e primeiro plano), versões legacy por densidade e variante round.
- Manifest atualizado com `android:icon` e `android:roundIcon`; nome exibido do app permanece `AI Running Coach`.
- `versionCode = 32` e `versionName = V32`.
- O ZIP permanece com o nome fixo `AI-Running-Coach.zip`.
- Testes de compilação Android/Compose devem ser confirmados no GitHub Actions.


## Revisão V33 — Atualização do ícone
- Arte do launcher substituída pelo modelo visual fornecido: chip AI, corredor, arco dinâmico, waveform, satélite/GPS e indicadores de desempenho, com o nome “AI Running Coach”.
- Recursos adaptativos e legacy atualizados, incluindo variações quadradas e arredondadas em mdpi, hdpi, xhdpi, xxhdpi e xxxhdpi.
- Nome do app preservado em `strings.xml`: `AI Running Coach`.
- `versionCode = 33` e `versionName = V33`.
- Não foram alterados motores de treino, telas, dados, integrações ou contratos funcionais da V32.
- O build Android/Compose permanece sujeito à validação do GitHub Actions.


## Revisão V34 — Compactação dos recursos gráficos
- PNGs do ícone oficial e da referência visual compactados com paleta indexada de até 256 cores, mantendo dimensões e transparência.
- Ícones adaptativos e variantes legacy/round mantidos em PNG para compatibilidade Android, com tamanhos reduzidos.
- Imagem aprovada da interface preservada sem alteração; nenhum arquivo de código funcional foi modificado.
- `versionCode = 34` e `versionName = V34`; rótulo Android `AI Running Coach` e ZIP `AI-Running-Coach.zip` preservados.
- Compilação Android/Compose permanece sujeita à confirmação pelo GitHub Actions.


## Revisão V35 — Disponibilidade semanal em tela independente
- O editor “Minha disponibilidade semanal” foi removido da tela principal de Perfil do atleta.
- O resumo da disponibilidade continua visível no cartão de perfil; a edição agora é acessada por uma ação própria em “Gerenciar perfil”.
- Criada a tela independente “Minha disponibilidade semanal”, com retorno ao perfil, seleção de 2 a 6 dias e escolha do dia preferido para o longão.
- Aviso e botão para recalcular o plano aparecem nessa tela quando a alteração exige redistribuição das sessões futuras; sessões concluídas continuam preservadas pelo fluxo existente.
- Onboarding, persistência local e regras do motor de agenda permanecem inalterados.
- `versionCode = 35` e `versionName = V35`; ZIP fixo `AI-Running-Coach.zip`.
- Compilação Android/Compose deve ser confirmada pelo GitHub Actions.


## Revisão V36 — Compartilhamento de prescrição como arquivo JSON
- Corrigido o fluxo Android de compartilhamento: a V35 passava o JSON em `Intent.EXTRA_TEXT`, o que o apresentava como texto mesmo com MIME `application/json`.
- A V36 materializa a prescrição em cache como `pace-coach-workout-<sessionId>.json` (UTF-8) e compartilha o URI de conteúdo por `Intent.EXTRA_STREAM`.
- Adicionados MIME `application/json`, `ClipData` e `FLAG_GRANT_READ_URI_PERMISSION`; o receptor pode abrir o anexo por `ContentResolver`.
- `FileProvider` configurado com escopo restrito a `cache/exports/`, sem expor caminhos ou armazenamento geral.
- Testes cobrem extensão `.json`, MIME, conteúdo UTF-8, sanitização de identificador e atualização do arquivo da mesma sessão.
- Contrato Pace Coach 6.0 e estrutura de dados da prescrição não foram modificados.
- `versionCode = 36` e `versionName = V36`; ZIP fixo `AI-Running-Coach.zip`.
- Compilação Android/Compose completa deve ser confirmada pelo GitHub Actions.


## Revisão V37 — Correções do motor esportivo
- Base: V36 oficial.
- Versão Android: `versionCode = 37`, `versionName = V37`; `engineVersion = 31`. Instalações anteriores com plano salvo passam a solicitar recálculo pela nova lógica.
- Calendário inicial usa a mesma proteção de recuperação entre qualidade e longão que já existia no reagendamento manual. Quando o espaçamento mínimo não existe, a sessão de qualidade é removida em vez de encaixada em dias consecutivos.
- Iniciante/reintrodução: a disponibilidade continua podendo ter 2–6 dias, mas o motor limita a prescrição a até três sessões de corrida/caminhada, com blocos por tempo e intervalos de caminhada reais.
- A carga usa distâncias de feedback vinculadas à data da sessão. Histórico é considerado suficiente para estimativa de média apenas com pelo menos seis sessões medidas em três semanas distintas nos últimos 28 dias; registros legados sem data da sessão usam data de salvamento.
- Limite por sessão usa a maior corrida realizada nos últimos 30 dias acrescida de margem de tolerância de até 10%. É um guarda conservador, não regra universal de progressão nem garantia contra lesão.
- Sessões de qualidade selecionadas conforme distância-alvo. Maratona recebe estímulo específico predominantemente Z2, com possível final moderado Z3, sem converter a sessão em treino de limiar.
- Semanas de recuperação têm redução planejada de aproximadamente 10–20% em relação à semana de desenvolvimento anterior, condicionada aos limites de carga e à distribuição possível.
- Z5 usa a estimativa de VAM como referência auxiliar para delimitar a faixa alta quando plausível; todas as zonas permanecem estimativas de campo. A interface deixa claro que não substituem medição de limiar ou VO₂máx.
- Biblioteca oferece duas rotinas de força opcionais, sem inserção automática no calendário de corrida.
- Testes acrescentados/atualizados em `CoachEngineTest`, `TrainingScheduleEngineTest`, `TrainingLoadEngineTest`, `PaceCalculatorTest` e `TrainingTypeCatalogTest`.
- Compilação Android completa não foi executada localmente; confirmar APK no workflow GitHub Actions.

## V38 — Ícone minimalista
- Launcher atualizado para fundo azul-marinho, corredor branco e arco ciano simples.
- Camadas adaptativas e ícones legados atualizados em cinco densidades.
- Identidade funcional, motor de treinamento e nome AI Running Coach preservados.
- `versionCode = 38`, `versionName = V38`.
