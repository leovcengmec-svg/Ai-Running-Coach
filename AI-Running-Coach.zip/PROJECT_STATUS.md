# Project Status — AI Running Coach V80

- `versionCode`: 80
- `versionName`: V80
- `CURRENT_ENGINE_VERSION`: 70
- Backup Schema: 4; leitura de schemas 1–4 preservada.
- Recuperação: Fartlek F01 usa a parte superior da Z1 (90–100%); recuperações aeróbias Z2 usam 0–30% da Z2; intervalos Z4 mantêm caminhada nos protocolos explícitos e Z5 mantém pausa passiva.
- Biblioteca: títulos de estágios repetidos não exibem sufixos numéricos redundantes; identidade/repetição interna continua preservada.
- Distribuição de intensidade: voltas explícitas e parciais agregadas de vários minutos entram no cálculo Z1–Z5; amostras GPS brutas acima de 120 s continuam descartadas para evitar preencher lacunas.
- GPX: atividades são apresentadas em quilômetros acumulados e uma parcial final fracionada. Voltas irregulares podem ser rateadas proporcionalmente; cobertura insuficiente permanece desconhecida, sem pace/tempo inventado.
- Revisão de zonas: abertura de teste usa inicialização completa do formulário; “Manter e observar” registra a decisão sem alterar as faixas automaticamente.
- Estratégia de prova: exportação ao Pace Coach via formato `UserWorkoutJson`, com etapas suportadas por evidência e sem metas de ritmo inventadas.
- Exportação semanal: nome `S{semana}_T{treino}_{Título}`, sem data, idêntico na prévia, no JSON e no nome do anexo.
- Perfil: não contém atalho de exportação de sessão.
- Sem dependência de frequência cardíaca, FCM ou sensores cardíacos para cadastro, prescrição, feedback, calibração ou estratégia.

## Validação executada

- Compilação Kotlin/JVM dos motores de domínio (excluídas Activity Android/Compose e classes Android/JSON dependentes de plataforma): concluída, com avisos preexistentes de parâmetros/asserções não utilizados.
- Harness integrado Kotlin/JVM: 12 verificações aprovadas cobrindo recuperação Z1/Z2, F01, títulos, distribuição por zona, GPX 6,62 km com voltas irregulares, GPX sem timestamps, nomes de exportação e estratégia de prova.
- Testes de domínio focados extraídos dos testes do projeto: 46 aprovados/0 falhas; dois testes focados de recuperação no `CoachEngine`: 2 aprovados/0 falhas.
- A bateria ampla de `CoachEngineTest` mantém 20 falhas que também foram reproduzidas ao executar a mesma classe contra a base V79 original; não são atribuídas às mudanças V80. Os testes de recuperação alterados foram executados separadamente e passaram.
- ZIP final: validado com `unzip -t` após empacotamento.

## Pendência de build Android

Este ambiente não possui Gradle CLI/Wrapper nem Android SDK. Portanto, não foi executada a compilação Android/Compose completa nem `:app:testDebugUnitTest`. O GitHub Actions deve confirmar `:app:testDebugUnitTest` e `:app:assembleDebug` antes de considerar o APK aprovado.
