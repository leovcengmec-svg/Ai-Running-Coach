# V57 — recálculo fiel e prontidão atualizada

# Status atual — V57

- Base funcional: V56 (`versionCode = 56`, `engineVersion = 42`).
- Entrega atual: V57 (`versionCode = 57`, `versionName = V57`, `engineVersion = 43`).
- Recálculo de plano existente preserva a âncora e a duração do ciclo; mantém semanas passadas/concluídas e regenera somente hoje e datas futuras. Novo ciclo somente quando o anterior expira ou não há plano salvo.
- Dashboard e Plano compartilham cálculo da semana corrente, removendo discrepância entre o card inicial e a lista de semanas.
- Frequência de 2–6 dias selecionada pelo atleta é respeitada também nos perfis iniciantes/reentrada; intensidade e dose continuam adaptadas ao histórico.
- Consulta de treino adicional limitada a dias livres/descanso, com proteção de domínio contra dia ocupado ou competição. Opções de 3–5 km quando volume semanal e maior corrida recente oferecem referência suficiente; carga ajustada por feedback e sessão exigente próxima.
- Cards de Recuperação/Segurança são recalculados ao vivo a partir de até três feedbacks dos últimos 14 dias, usando esforço, sensação e dor.
- Regras de calibração preservadas: Z1 (três sessões regenerativas válidas), Z2 (três testes de fala) e Z3 (dois testes Cooper separados por 14 dias). O recálculo aplica as zonas qualificadas somente ao futuro.
- Backup schema 2 preservado. Nenhum campo de persistência foi alterado; backup identifica `appVersion = V57`.
- Testes de lógica adicionados/atualizados; a compilação Android completa ainda deve ser confirmada pelo GitHub Actions, pois este ambiente não possui Gradle/Android SDK.
