# Status atual — AI Running Coach V58

- Entrega atual: V58 (`versionCode = 58`, `versionName = V58`, `engineVersion = 43`).
- Tela de boas-vindas oferece duas opções: **Começar Novo Plano** e **Importar Backup**.
- A opção Importar Backup abre o seletor de documentos do Android para arquivos JSON e confirma explicitamente a substituição dos dados locais antes de restaurar.
- A importação reutiliza `AppBackupManager.restore` e `AppBackupCodec`; valida formato, aplicativo de origem, tamanho, schema, assinatura SHA-256, manifesto, contagem de sessões/feedbacks/avaliações/competições e JSON interno antes de gravar.
- Se a validação falhar, permanece na tela inicial, mostra a mensagem de erro e não limpa os dados locais. Se for bem-sucedida, abre a tela Backup e restauração com o resultado e o perfil/plano restaurado.
- O fluxo de importação existente em Mais → Backup e restauração permanece disponível.
- `engineVersion = 43` e `schemaVersion = 2` permanecem inalterados: esta revisão é de entrada/UX e não altera o motor de treinamento nem o formato persistido.
- Teste de compilação Android completa: pendente de GitHub Actions; este ambiente não possui Gradle/Android SDK.
