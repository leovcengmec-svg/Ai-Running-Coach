# Status do projeto — AI Running Coach V105

- **Versão:** `versionCode=105`, `versionName=V105`.
- **Motor interno:** 95.
- **Backup:** Schema 17; leitura compatível de schemas 1–17.
- **Base:** pacote V104, preservado e atualizado.
- **Código Android:** `android/app/src/main/java/com/airunningcoach/app/`.

## Atualização V105 aplicada

- Competição possui fluxo próprio para registrar resultado e feedback; associação direta ao evento, sem exigir treino previamente selecionado. Resultado real entra no histórico e na carga semanal uma única vez, usando a data efetiva da atividade. A data da prova por si só não a conclui.
- Exportação para Pace Coach inclui apenas as etapas competitivas cuja soma corresponde à distância oficial. Aquecimento e desaquecimento ficam fora do arquivo competitivo.
- Sete modos de execução persistidos por prova: Automático, Contínuo, Progressivo, Regressivo, Final forte, Conservador e Agressivo controlado. A escolha atualiza as fases e a projeção ponderada por distância.
- Nova área de Recordes pessoais apresenta top 3 para 800 m, 1 km, milha, 3 km, 5 km, 10 km, 15 km, meia e maratona; aceita distâncias personalizadas e cadastro manual de marcas antigas. Atividades medidas de treino e prova podem gerar recordes. Celebração aparece após gravação bem-sucedida.
- Calibração diferencia lote pronto de lote confirmado. Z1 preserva contribuição própria A/B (3%+2%) e recebe propagação de Z2/Z3; tetos efetivos permanecem Z1=15%, Z2=10%, Z3=5%.
- Botão de redefinição pede confirmação, restaura zonas do último teste fisiológico válido e zera os efeitos adaptativos sem apagar histórico. As atividades e feedbacks anteriores ao reset permanecem elegíveis para reavaliação; fingerprint/identidade determinística evitam duplicar a mesma sessão recadastrada.
- Backup Schema 17 persiste recordes manuais e mantém leitura compatível com schemas anteriores.

## Validação e build

- Harnesses Kotlin/JVM focalizados: **17/17 assertions aprovadas** (3 recordes, 10 calibração, 4 estratégia/exportação).
- Verificação lexical de delimitadores: **12/12 arquivos críticos aprovados**.
- JUnit/Gradle oficial não executado nesta sessão. `gradle` e `gradlew` indisponíveis e Android SDK não configurado; **APK não gerado**.
- CI obrigatório: `gradle -p android :app:testDebugUnitTest :app:assembleDebug --no-daemon` no GitHub Actions, seguido de instalação e teste no aparelho.

Relatórios: `V105_IMPLEMENTACAO.md`, `TEST_REPORT_V105.md`, `BUILD_STATUS_V105.md` e `V105_PLANO_CORRECAO_REV3_RESET_MANTEM_EVIDENCIAS.md`.

---

