# Project Status — AI Running Coach V78
- versionCode: 78
- versionName: V78
- CURRENT_ENGINE_VERSION: 68
- Backup Schema: 3 (leitura schemas 1–3)
- Atualização: feedback manual por bloco da prescrição, comparação de pace por faixa, histórico congelado da prescrição e inteligência de tendências por zona Z1–Z5.
- Removida a atribuição automática de blocos por voltas/amostras GPX da tela de feedback e histórico. Importação continua preenchendo somente métricas reais da atividade.
- Removido o formulário de calibração individual Z2 por ritmo confortável. Entradas antigas permanecem legíveis em backups, mas não participam mais da calibração.
- Sem dependência de FC/FCM na prescrição, comparação, análise por zona ou progressão.
