# Status atual — V55

- Pacote oficial: `AI-Running-Coach.zip`.
- Base funcional: V54 (`versionCode = 54`, `engineVersion = 41`).
- Entrega atual: V55 (`versionCode = 55`, `versionName = V55`, `engineVersion = 42`).
- Importação offline GPX/FIT/TCX mantida; parser GPX passa a reconhecer os metadados RunnerUp/PaceCoach (`pacecoach:activity`, `pacecoach:lap`) e tolera provedores XML Android que não implementam recursos opcionais de hardening. DTDs e entidades externas continuam bloqueados.
- Os dois GPX reais de 11/11 e 13/11 foram lidos: 4,970 km/37:03 (7:27/km) e 6,616 km/49:27 (7:28/km). Os arquivos não contêm FC nem cadência; o aplicativo mantém esses campos vazios.
- Agenda corrigida: rodagem fácil na primeira sessão da semana; qualidade posicionada perto do meio, com recuperação antes do longão; longão permanece no último dia preferido disponível. Para segunda/quarta/sexta, a distribuição fica segunda leve, quarta qualidade, sexta longão.
- Rodagens aeróbias alternam Z2 contínua, progressiva Z1→Z2 e regressiva Z2→Z1. Longões alternam Z2 contínua, progressiva Z1→Z2 e regressiva Z2→Z1; somente atletas avançados/elite com ≥25 km/semana, maior corrida recente ≥12 km, longão prescrito ≥8 km e zonas individualizadas recebem bloco final curto Z3.
- Semana atual na Dashboard e no Plano é calculada a partir da âncora original, não por assumir que a semana 1 ainda está em andamento. A tela Plano abre a semana corrente por padrão e mantém as semanas anteriores visíveis.
- Restauração do backup: passado é autoritativo; preserva todas as sessões históricas existentes, mas não inventa sessões prescritas em datas passadas ausentes do backup. Regenera apenas hoje e datas futuras dentro do ciclo restaurado, mantendo âncora, duração e numeração das semanas.
- O schema 2 do backup, SHA-256, manifesto, histórico, feedback, sessões concluídas, atividades importadas e calibração Z1–Z3 são preservados.
- Verificações: compilação das fontes Kotlin puras concluída; parser executado nos dois GPX anexados; harness do motor confirmou ordem dos dias, blocos progressivos/regressivos e gate da Z3. Não há Gradle/Android SDK neste ambiente: a compilação Android final e a suíte JUnit continuam pendentes do GitHub Actions.

## Contratos atuais

1. O backup é a fonte de verdade para sessões passadas: ausência no arquivo significa que a sessão não deve ser recriada retroativamente.
2. A semana 1 permanece ancorada na segunda-feira original do ciclo recuperado.
3. Somente a partir de hoje o motor pode recalcular sessões, sempre dentro da janela de `planWeeks` restaurada.
4. A sessão extra é voluntária e apresenta riscos; não substitui sessão principal.
5. Z3 no longão é excepcional e condicionada a alta tolerância documentada; rodagem fácil permanece Z1/Z2.

## Build Android

Workflow: `gradle -p android :app:testDebugUnitTest :app:assembleDebug --no-daemon`.
