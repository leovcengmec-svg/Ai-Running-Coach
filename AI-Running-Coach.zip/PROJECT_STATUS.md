# Status atual — V50

- Pacote oficial: `AI-Running-Coach.zip`.
- `versionCode = 50`, `versionName = V50`, `engineVersion = 38`.
- Backup V49/engine 37 aciona migração para o motor 38.
- A migração mantém sessões passadas e concluídas; feedbacks identificam conclusões mesmo quando o flag legado está ausente.
- Dia livre elegível oferece opção leve Z1 e rodagem aeróbia Z2, com riscos explícitos e escolha do corredor.
- A evolução exibe intervalo de datas de segunda a domingo; a tela de competições foi modernizada.
- Testes adicionados para migração histórica, opções extras e rótulos semanais.
- A suíte Gradle/compilação Android deve ser confirmada no GitHub Actions; o ambiente desta revisão não possui Gradle/Android SDK configurados.

## Base anterior

V49 (`versionCode = 49`, `engineVersion = 37`) é a base imediatamente anterior. O histórico detalhado permanece em `CHANGELOG.md`.
