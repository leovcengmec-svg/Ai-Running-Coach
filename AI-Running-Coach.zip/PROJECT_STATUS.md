# Status do projeto — AI Running Coach V104

- **Versão:** `versionCode=104`, `versionName=V104`.
- **Motor interno:** 94.
- **Backup:** Schema 16; leitura compatível de schemas 1–16, incluindo V103/15 e V102/14.
- **Fonte Android principal:** `android/app/src/main/java/com/airunningcoach/app/`.

## Atualização V104 aplicada

- Revisão periódica de 28 dias separada da revisão complementar: Lote B fica pronto para confirmação assim que suas evidências novas e independentes estão completas, sem esperar a próxima revisão periódica.
- Z1, Z2 e Z3 continuam como zonas de origem independentes. Z1 mantém o próprio Lote A (até 3%) e Lote B (até 2%), além de receber propagação de Z2 e Z3. Nenhum lote próprio de Z1 foi removido.
- Contribuições diretas continuam limitadas a 5% por origem; efeitos acumulados em cascata mantêm Z1=15%, Z2=10%, Z3=5%; Z4–Z5 permanecem ancoradas ao teste.
- Evidências aceitas passam a ser identificadas por zona, sessão/data e ID de bloco; o histórico guarda IDs, resumo do lote e data final. Evidências já consumidas não podem voltar a pontuar.
- Estados importados da V103/Schema 15 sem IDs usam como corte conservador a data do último crédito confirmado, sem apagar os créditos já conquistados.
- Reteste passa a ser apresentado pela sessão futura real do plano; oportunidade vencida é mostrada como atraso, nunca como próxima data futura.
- Dispensar uma revisão sem proposta não avança a data da última revisão confirmada e não cria novo bloqueio de 28 dias.
- Backup Schema 16 preserva os novos dados e continua aceitando schemas 1–15.

## Validação e build

- Harness Kotlin/JVM compilando o motor real de calibração: **4 verificações integradas aprovadas**, incluindo Lote A/B próprio de Z1, liberação de B antes dos 28 dias, 10 IDs distintos consumidos e propagação máxima em cascata.
- Cenário de reteste: 11/10/2026 → primeira oportunidade 09/11/2026; em 27/11/2026 apresenta 18 dias de atraso quando não há sessão futura, e prefere uma sessão futura real quando existe.
- `AdaptiveZoneCalibrationEngineTest.kt`: **22/22 métodos** passaram em execução local com shim JUnit e stubs mínimos de domínio. Isso não equivale ao JUnit/Gradle oficial.
- Testes JUnit do projeto atualizados, mas **não executados pelo Gradle oficial** nesta sessão.
- **APK não foi gerado nesta sessão:** o ZIP não inclui Gradle Wrapper e o ambiente não possui Gradle/Android SDK. O workflow `.github/workflows/android.yml` mantém `:app:testDebugUnitTest` e `:app:assembleDebug` no GitHub Actions.

Relatórios: `V104_IMPLEMENTACAO.md`, `TEST_REPORT_V104.md`, `BUILD_STATUS_V104.md` e `V104_PLANO_CORRECAO_REV3_Z1_MANTIDA.md`.
