# Status do projeto — AI Running Coach V103

- **Versão:** `versionCode=103`, `versionName=V103`.
- **Motor interno:** 93.
- **Backup:** Schema 15; leitura compatível de schemas 1–15, inclusive backups Schema 14 da V102.
- **Fonte Android principal:** `android/app/src/main/java/com/airunningcoach/app/`.

## Atualização V103 aplicada

- Semana regenerativa explicável e adaptativa; referência de construção preservada, sem compensação de sessões ausentes e sem dupla redução em semana de competição.
- Calendário com selo vetorial de status maior; perfil com família única de pictogramas vetoriais.
- “Próximo evento” combina provas `PLANNED` e treinos pendentes pela data.
- Calibração por protocolo, com zonas-base vindas do resultado bruto atual; comparação Cooper/Cooper ou 3 km/3 km; reset apenas após melhora de pelo menos 2%; preservação em resultado equivalente/pior; créditos de protocolo diferente ficam em espera.
- Dois lotes independentes podem conceder até 3% + 2% por zona de origem dentro do período de evidências; limites efetivos em cascata Z1=15%, Z2=10%, Z3=5%; confirmação manual obrigatória.
- Monitoramento de ritmo oferece prévia com 1–3 sessões e exige quatro sessões comparáveis para tendência formal; longão separado de rodagem/regenerativo.

## Validação e build

- Harness local de motores reais com modelos mínimos: **16/16 cenários aprovados**.
- Testes JUnit Android foram atualizados, mas a suíte oficial ainda precisa ser executada pelo Gradle.
- **APK não foi gerado nesta sessão:** o ZIP não inclui Gradle Wrapper e o ambiente não possui Gradle/Android SDK. O workflow `.github/workflows/android.yml` executa `:app:testDebugUnitTest` e `:app:assembleDebug` no GitHub Actions.

Relatórios: `V103_IMPLEMENTACAO.md`, `TEST_REPORT_V103.md`, `BUILD_STATUS_V103.md` e `V103_PLANO_CORRECAO_AUDITORIA_V102.md`.
