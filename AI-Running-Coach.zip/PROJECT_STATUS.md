# Project Status — AI Running Coach V82

- `versionCode`: 82
- `versionName`: V82
- `CURRENT_ENGINE_VERSION`: 73
- Backup Schema: 4; leitura de schemas 1–4 preservada.
- Recuperação: Fartlek F01 usa a parte superior da Z1 (90–100%); recuperações aeróbias Z2 usam 0–30% da Z2; intervalos Z4 mantêm caminhada nos protocolos explícitos e Z5 mantém pausa passiva.
- Biblioteca: títulos de estágios repetidos não exibem sufixos numéricos redundantes; identidade/repetição interna continua preservada.
- Distribuição de intensidade: voltas explícitas e parciais agregadas de vários minutos entram no cálculo Z1–Z5; amostras GPS brutas acima de 120 s continuam descartadas para evitar preencher lacunas.
- GPX: atividades são apresentadas em quilômetros acumulados e uma parcial final fracionada. Voltas irregulares podem ser rateadas proporcionalmente; cobertura insuficiente permanece desconhecida, sem pace/tempo inventado.
- Revisão de zonas: abertura de teste usa inicialização completa do formulário; “Manter e observar” registra a decisão sem alterar as faixas automaticamente.
- Estratégia de prova: exportação ao Pace Coach via formato `UserWorkoutJson`, com etapas suportadas por evidência e sem metas de ritmo inventadas.
- Exportação semanal: nome `S{semana}_T{treino}_{Título}`, sem data, idêntico na prévia, no JSON e no nome do anexo.
- Perfil: não contém atalho de exportação de sessão.
- Exportação Pace Coach corrigida: 1 km = 1.000 m, com validação de duração, distância e alvos de ritmo.
- Pace médio previsto usa somente tempo em movimento; a duração total inclui pausas passivas.
- Flags de elegibilidade usam zonas Cooper calculadas mesmo antes de persistir a calibração no perfil.
- Prontidão POOR/YELLOW reduz o volume semanal entregue e mantém a qualidade suspensa enquanto o alerta persistir.
- Recuperações ativas exportam ritmo quando prescrito; pausas passivas continuam sem alvo.
- Fartlek F01/F04 usam seleção determinística condicionada à intenção e à presença de feedback de recuperação/fadiga; F04 só libera Z4 com elegibilidade de limiar.
- Tela Plano exibe evolução do volume semanal planejado, incluindo provas cadastradas.
- Primeira semana do plano passa a iniciar na próxima segunda quando todos os dias habituais da semana atual já passaram; domingo selecionado e ainda disponível mantém a semana atual.
- IDs de sessão novos são únicos por ciclo/data/tipo; reagendamento preserva data originalmente planejada.
- Importação seletiva de histórico exige correspondência por ID + data original, remapeia colisões legadas e não conclui sessões futuras de outro ciclo.
- Sem dependência de frequência cardíaca, FCM ou sensores cardíacos para cadastro, prescrição, feedback, calibração ou estratégia.

## Validação executada após as correções da V82

- Compilação Kotlin/JVM isolada dos motores de domínio alterados: concluída.
- Harness Kotlin/JVM: 370 testes aprovados/0 falhas, cobrindo 49 dos 53 arquivos de teste do projeto.
- Quatro arquivos dependentes de Android/JSON não foram executados no harness isolado: `AppBackupCodecTest.kt`, `PaceCoachExporterTest.kt`, `PaceCoachJsonAttachmentTest.kt` e `RaceStrategyWorkoutExporterTest.kt`.
- O teste de backup foi atualizado para identificar a versão V81 e verificar a leitura do schema 3/V78; sua execução ainda depende do ambiente Gradle/Android do projeto.
- ZIP final: validação estrutural e integridade com `unzip -t` após o empacotamento.

## Pendência de build Android

Este ambiente não possui Gradle CLI/Wrapper nem Android SDK. Portanto, não foi executada a compilação Android/Compose completa nem `:app:testDebugUnitTest`. O GitHub Actions deve confirmar `:app:testDebugUnitTest` e `:app:assembleDebug` antes de considerar o APK aprovado.


Consulte `BUILD_STATUS_V82.md`, `PACE_COACH_EXPORT_CONTRACT_V81.md` e `TRAINING_LIBRARY_VARIATION_V81.md` para a revisão atual.


## Revisão de calendário e backup aplicada à V81
- Migração de primeira semana vazia: aplicada na criação e no carregamento de planos salvos, sem renumerar semanas com sessão do próprio ciclo.
- Identidade de sessão: ciclo + data programada + tipo; ID legado sozinho não é chave suficiente.
- Importação seletiva: sessões antigas com ID igual e data diferente permanecem em separado com ID histórico; feedback acompanha o ID remapeado.
- Reagendamento: comparação por instância e prioridade do slot original + tipo na migração.
- Verificação isolada nesta revisão: 25 verificações Kotlin/JVM aprovadas, 0 falhas, mais 1 verificação separada do motor de feedback por bloco.
- Build Android/Compose e testes Gradle oficiais ainda precisam ser executados pelo GitHub Actions; esta revisão não declara APK certificado.


## Correção V81 — agenda e backup
- Âncora da primeira semana corrigida para o primeiro bloco com dia habitual ainda disponível.
- Colisões de ID legado separadas por data original e tipo; históricos não concluem treinos futuros de outro ciclo.
- Recalibração usa a rotina de preservação por instância e mantém feedback sem tipo apenas quando o slot é único.
- Integridade aplicada também às métricas planejado/realizado, feedback por bloco, eventos e exportações.
- 25 verificações focadas e 1 verificação isolada do feedback por bloco aprovadas; testes oficiais Gradle/Android permanecem pendentes.


## Correção V82 — âncora do ciclo e integridade do histórico

- A primeira semana agora começa na primeira semana civil que ainda contém ao menos um dia habitual de treino disponível. No caso de 21/11/2026 com segunda/quarta/sexta, a âncora efetiva é 23/11/2026.
- A identidade de sessão é determinística por ciclo/data/tipo; reagendamentos mantêm a data original imutável.
- A importação seletiva associa sessões por ID + data original + tipo compatível. IDs relativos antigos em datas diferentes são remapeados para identidade `LEGACY-*`; o feedback acompanha a instância histórica.
- O feedback sem data suficiente não pode concluir uma sessão futura por inferência.
- `CURRENT_ENGINE_VERSION = 73` solicita revisão/recálculo de planos salvos pelo motor anterior; backup schema 4 permanece compatível com schemas 1–4.
- Harness independente executado nesta revisão: 6/6 verificações de âncora, numeração semanal, estabilidade de ID e proteção de feedback aprovadas.
- As regressões JUnit de mesclagem JSON estão no pacote, mas ainda dependem da execução da suíte Gradle/Android no GitHub Actions. APK não certificado nesta sessão.
