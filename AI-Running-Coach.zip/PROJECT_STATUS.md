# Project Status — AI Running Coach V71

## Estado atual

- Versão: V71 (`versionCode 71`, `versionName V71`).
- Motor: `CURRENT_ENGINE_VERSION 56`.
- Backup: Schema 3, exportado com `appVersion V71`; schemas 1 e 2 continuam legíveis.
- Base: pacote-fonte V70, atualizado em uma única revisão consolidada.

## Entregas da V71

- Perfil do atleta reorganizado em áreas menores, com resumo de dados e ações de gerenciamento separadas.
- Avaliação de prontidão removida da sequência de ações do perfil.
- Data de nascimento como fonte preferencial, idade atual e idade histórica calculadas por data, fallback compatível para perfis antigos que só possuem idade.
- Referência fisiológica centralizada no perfil e recuperada do último teste em perfis V70 quando possível.
- Tela Evolução reformulada com filtros 7/28/90 dias, indicadores compactos, volume por dia/semana, aderência e distribuição de intensidade medida.
- GPX prioriza timestamps de pontos de trilha; TCX usa Trackpoint/Activity/Id/StartTime; FIT mantém o horário de sessão.
- Tracks/TrackSegments separados não criam deslocamento artificial entre pontos nem parciais por quilômetro atravessando pausas; pausas e amostras implausíveis são excluídas da avaliação de ritmo.
- Amostras temporizadas enriquecidas com offsets de tempo/distância e FC/cadência quando disponíveis.
- Novo `ActivityBlockAnalysisEngine` compara blocos e repetições prescritos com a execução e explicita confiança/ausência de dados.
- Histórico exibe data real da execução e hora local quando o arquivo fornece timestamp; data planejada fica como referência secundária.
- Backup schema 3 e testes de regressão de dados demográficos, datas, segmentos GPX e comparação de blocos.

## Validação já executada

- Harness Kotlin/JVM compilado com os motores de parser/datas/análise de blocos.
- Cenário executado com sucesso: GPX metadata posterior não substitui o primeiro timestamp da atividade; dois TrackSegments não são unidos; offsets temporais preservados; seis blocos/repetições comparados com a prescrição.
- Integridade do ZIP e CRC de todos os arquivos verificados na geração final.

## Validação ainda pendente

- `:app:testDebugUnitTest` completo.
- APK Debug e Release via GitHub Actions.
- Testes de UI no Android.
- Importação real de GPX/FIT/TCX de relógios diferentes.
- Teste ponta a ponta no Pace Coach.

Limitação: o ZIP-fonte não contém Gradle Wrapper e o ambiente desta edição não possui Gradle/Android SDK. O harness de domínio não substitui build Android/JUnit completo.

## Limitação de migração das atividades antigas

Atividades V70 cujos campos `activityStartedAtIso` e `realizedDateIso` já foram gravados com o timestamp incorreto de metadata não contêm necessariamente os timestamps originais dos Trackpoints no backup. Para corrigir com certeza data e hora nesses registros, reimporte o GPX/FIT/TCX original na V71. Atividades novas importadas na V71 usam a fonte de horário corrigida.
