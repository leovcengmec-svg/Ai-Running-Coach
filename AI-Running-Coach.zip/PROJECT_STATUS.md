# Status atual — V54

- Pacote oficial: `AI-Running-Coach.zip`.
- Base: V53 (`versionCode = 53`, `engineVersion = 39`).
- Entrega atual: V54 (`versionCode = 54`, `versionName = V54`, `engineVersion = 41`).
- Importação local/offline de atividades GPX, FIT e TCX permanece preservada.
- Calibração individual de Z1–Z3, snapshots e proteção contra saltos bruscos permanecem preservados.
- Restauração do backup mantém a âncora original do ciclo. Quando `planStartDateIso` já foi reancorado, a migração infere a segunda-feira original cruzando datas e números de semana gravados nas sessões; reconstrói o ciclo, recompõe sessões ausentes e renumera todas as semanas pela âncora recuperada. A duração `planWeeks` é preservada e ajustes de taper não reescrevem sessões passadas.
- Feedbacks, sessões concluídas e sessões anteriores ainda sem confirmação são preservados; nenhum treino perdido é transferido para outra data.
- Backup schema 2 inclui SHA-256 e manifesto com contagens de atividades, feedbacks, avaliações Cooper e competições. Schema 1 legado continua aceito.
- A inclusão de treino extra agora apresenta opções, volume adicional e alertas de risco sem bloquear por limite semanal, sessão pendente ou fadiga/dor; a escolha é do corredor. Datas futuras distantes também podem ser selecionadas, com aviso de que a recomendação é preliminar. O aplicativo não altera a programação principal.
- Testes focados adicionados para integridade do backup, restauração da semana original e decisões de treino extra sem proibições automáticas.
- O pacote ainda precisa da validação final `:app:testDebugUnitTest` e `:app:assembleDebug` pelo GitHub Actions; este ambiente não possui Gradle/Android SDK instalados.

## Regras de restauração

1. A semana 1 continua sendo a semana que contém a data original de início do ciclo.
2. A importação não reancora o ciclo na data atual.
3. Sessões salvas e feedbacks são mantidos. Sessões prescritas faltantes dentro do ciclo original são reconstruídas a partir do plano e perfil do backup.
4. O backup é validado antes de apagar qualquer preferência local.
5. Importações antigas continuam aceitas, mas apenas o schema 2 oferece o manifesto de integridade e contagem de registros.

## Regras para sessões extras

- O treinador calcula uma opção leve e, quando há dados suficientes, uma opção aeróbia moderada.
- Sessões não concluídas, volume semanal, treinos próximos, competições, dor e fadiga aparecem nos alertas.
- O atleta escolhe se deseja adicionar. A sessão extra é criada com ID próprio e nunca substitui nem apaga a sessão principal.
- Dor recente/fadiga elevada geram alerta alto; não são tratados como sinal verde para treinar.

## Entrega

Manter o nome canônico `AI-Running-Coach.zip`. Workflow: `gradle -p android :app:testDebugUnitTest :app:assembleDebug --no-daemon`.
