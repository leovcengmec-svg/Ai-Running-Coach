# Status atual — V52

- Pacote oficial: `AI-Running-Coach.zip`.
- Base: V51 (`versionCode = 51`, `engineVersion = 38`).
- Entrega: V52 (`versionCode = 52`, `versionName = V52`, `engineVersion = 39`).
- Importação local/offline de atividades GPX, FIT e TCX pela tela de feedback de cada sessão.
- Métricas de origem são preenchidas somente quando presentes ou calculáveis; tempo e pace permanecem ausentes quando o arquivo não traz timestamps/duração.
- A atividade importada mantém percurso, parciais disponíveis, elevação, FC e cadência; fingerprint SHA-256 impede a mesma atividade de ser vinculada a outra sessão.
- Feedback subjetivo (esforço, sensação, dor e observações) permanece separado dos dados medidos e é preservado ao editar o registro.
- Z1 usa ao menos três sessões regenerativas recentes, sem dor e com evidência consistente; Z2 usa ao menos três observações válidas do teste da fala; Z3 usa dois testes Cooper independentes, separados por pelo menos 14 dias e com variação de até 8%.
- As fronteiras individuais evoluem em passos de até 15 segundos por atualização, com snapshot persistido; zonas permanecem contínuas e ordenadas.
- Dor recente bloqueia a progressão automática de carga/intensidade e também é excluída da evidência de calibração.
- Testes de lógica executados manualmente: 38 aprovados. A suíte Android/Gradle e a geração de APK ainda precisam ser confirmadas no GitHub Actions; este ambiente não possui Gradle/Android SDK configurados.

## Compatibilidade e migração

O `engineVersion` passa de 38 para 39. As preferências e os registros V51 são carregados com valores padrão para os novos campos; o histórico existente não é descartado. A nova chave de snapshot de fronteiras é opcional e criada na primeira atualização de calibração. Backups anteriores continuam sem exigir esses campos.

## Entrega

Manter o nome canônico do pacote `AI-Running-Coach.zip`. O workflow `.github/workflows` compila o APK debug e executa `:app:testDebugUnitTest` e `:app:assembleDebug` no GitHub Actions.
