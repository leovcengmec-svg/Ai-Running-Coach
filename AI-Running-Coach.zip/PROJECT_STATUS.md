# Status do projeto — AI Running Coach V73

- Versão: V73
- `versionCode`: 73
- `versionName`: V73
- `CURRENT_ENGINE_VERSION`: 58
- Backup Schema: 3 (`appVersion = V73`)
- Base: V72

## Atualizações V73
- Periodização de objetivos “Completar” e “Correr continuamente” com escolha de estímulo conforme distância.
- Distribuição de intensidade planejada calculada por tempo efetivo e retornada com faixa orientativa por fase.
- Nenhuma dependência de FC/FCM.
- Compatibilidade de backups anteriores mantida; sem migração destrutiva de histórico.

## Validação
Compilação Kotlin/JVM parcial dos motores de domínio executada com sucesso. Build Android e JUnit integrais não executados neste ambiente por ausência de Gradle/Wrapper/SDK. Consultar `BUILD_STATUS_V73.md`.
