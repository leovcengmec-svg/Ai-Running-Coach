# Status do projeto — AI Running Coach V76

- Versão: V76
- `versionCode`: 76
- `versionName`: V76
- `CURRENT_ENGINE_VERSION`: 66
- Backup Schema: 3 (`appVersion = V76`)
- Base: V75; entrega atual: V76

## Atualizações V76
- Faixas ativas livres dentro das zonas: qualquer intervalo válido entre 0% e 100%, com 0% mais lento e 100% mais rápido. Percentual é posição dentro da zona, não percentagem de VO₂máx ou FC.
- Corredores com seis meses ou mais de experiência usam Z2 0–20% no aquecimento/desaquecimento, a partir do snapshot de calibração.
- Recuperação passiva exige tempo e não possui pace/distância; caminhada não recebe pace; recuperação ativa Z2 usa a faixa 0–20%.
- Protocolos explícitos escolhem recuperação por tipo de estímulo: Z5 pausa parada; Z4 caminhada; intensidades menores podem usar recuperação ativa.
- Alternativas preservam o estímulo, zonas e dose quando prontidão está adequada; progressões mantêm a ordem e a distância de cada etapa. Exigência reduzida só quando indicadores de saúde/recuperação não recomendam qualidade.
- Restauração completa do backup mostra escolha explícita entre recalibrar o plano futuro pelo motor atual e manter o plano importado. Recalibração preserva histórico, feedbacks, atividades e datas reais.
- Backup Schema 3, compatibilidade de leitura com schemas 1–3. Sem dependência de FC/FCM.

## Validação local
- Compilação Kotlin/JVM dos módulos de domínio: aprovada com warnings não bloqueantes, usando stub temporário para `Workout` (dependência da interface Android).
- Testes direcionados (`ZoneIntensityBandEngineTest`, `WorkoutAlternativeEngineTest` e novos casos de experiência no `CoachEngineTest`) com runner local e stub leve de JUnit: 26 aprovados, 0 falhas.
- Harness de geração: 32 sessões; aquecimento/desaquecimento de corredor experiente em Z2 0–20%.
- Teste ampliado de `CoachEngineTest`: 21 falhas legadas idênticas às já observadas na base V75; 46 aprovações na V76. Essas falhas não foram declaradas aprovadas.
- Testes oficiais via Gradle e build Android/Compose/APK não executados: ambiente sem Gradle Wrapper/CLI e Android SDK. Ver `BUILD_STATUS_V76.md`.
