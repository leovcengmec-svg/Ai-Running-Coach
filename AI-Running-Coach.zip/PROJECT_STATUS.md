# Status do projeto — V97

- VersionCode 97 / VersionName V97; motor interno 87. Backup Schema 12 com leitura dos schemas 1–12.
- Feedback normal salva dados e conclusão sem reconstruir a prescrição. Semana atual é preservada em revisões usuais; migração do motor V96→V97 pode normalizar uma vez o plano antigo sem apagar sessões concluídas.
- Média medida só pode ser adotada depois de quatro semanas completas reconciliadas e confirmação explícita; snapshot persiste através da virada semanal. A base declarada permanece protegida.
- Longão: máximo 40% do volume total incluindo provas; diferença de 0,8 km e 15% priorizada quando viável.
- Objetivo 5 km: sessões normais completas de pelo menos 5 km. Exceções: semana Regenerativa e protocolo inicial caminhada/corrida efetivamente ativo.
- Provas preparatórias curtas preservam o longão maior; validação do calendário bloqueia duplicidades, conflitos, excesso de frequência, longão acima de 40% e longão que não seja a maior sessão.
- Harness Kotlin/JVM focado: 102 testes PASS. Gradle/JUnit, compilação Compose e APK dependem do GitHub Actions.

---

# Status do projeto — V96

- VersionCode 96 / VersionName V96.
- Motor interno: 86. Backup Schema 11; leitura de schemas 1–10 mantida.
- Biblioteca revisada: regenerativo de iniciante com Z1 caminhada/corrida; corredor com mais de 11 meses de prática consistente usa Z2 0–20% nas transições e Z2 20–50% na parte principal, condicionado a ausência de dor e recuperação adequada.
- Longões contínuos, reduzidos, progressivos e regressivos têm bandas separadas; progressivos/regressivos são divididos em três etapas quando a distância permite.
- Strides com oito blocos explícitos (3 acelerações + 2 recuperações); acelerações 10–15 s, recuperações 60–90 s, individualizadas.
- Intervalado I05 6 × 400 m: 14 blocos executáveis no Pace Coach. `durationSeconds` preservado em snapshot/backup e convertido corretamente para milissegundos na exportação.
- Auditoria estrutural e fisiológica bloqueia prescrições inválidas antes da exibição/exportação.
- Harness Kotlin/JVM: 188 sessões aprovadas em sete perfis/objetivos; 10 progressivos, 10 regressivos, 2 strides e I05 com 14 etapas verificados. Gradle/JUnit/Android APK dependem do GitHub Actions.

---

# Status do projeto — V94

- VersionCode 94 / VersionName V94.
- Motor interno: 84. Backup Schema 9; leitura de schemas 1–8.
- Reteste: revisão no dia 28; slot de teste a partir do dia 29, no primeiro treino da semana posterior a quatro semanas completas. Elegibilidade exige >=4 sessões previstas, >=3 semanas ativas, mais conclusões do que faltas e ausência de dor.
- Reteste pode utilizar Cooper de 12 minutos ou teste de 3 km.
- A sessão original deslocada fica preservada em snapshot; opção 1 restaura a sessão semanal real e opção 2 oferece alternativa leve. O calendário e a tela da sessão acompanham o estado escolhido.
- Harness Kotlin/JVM focado: PASS. Gradle/JUnit completo e APK aguardam GitHub Actions.

---

# Status do projeto — V93

- Build Fix V93: parser de chave canônica corrigido após erro Kotlin em `first`/`last`; harness Kotlin/JVM focalizado e core harness passaram. Gradle/Android APK aguardam GitHub Actions.

- VersionCode 93 / VersionName V93.
- Motor de prescrição: 83. Backup Schema 8, compatível para leitura com schemas 1–7.
- Histórico: edição de dados de execução, vínculo de registros órfãos a sessões por data original + tipo compatível, remoção reversível, restauração e exclusão definitiva sob confirmação explícita.
- Calibração acumulada: contribuições de origem Z1/Z2/Z3 até 5% cada; propagação Z3→Z2/Z1 e Z2→Z1; limites efetivos 15%/10%/5%; reinício após novo teste fisiológico válido.
- Z4/Z5 seguem protegidas pelo teste; faixas adaptativas com menos de 10 segundos de largura bloqueiam a proposta.
- Reteste: revisão de evidências em 28 dias e janela preferencial entre 49 e 56 dias, substituindo sessão intensa.
- Harness Kotlin/JVM isolado aprovado. JUnit/Gradle, compilação Compose e APK aguardam GitHub Actions.

---

# Status do projeto — V92

- VersionCode 92 / VersionName V92.
- Motor de prescrição: 81. Backup Schema 7, com leitura de schemas 1–6.
- Calendário: ícones maiores, bandeira quadriculada para prova, legenda em três colunas; somente treinos vencidos e não realizados ficam opacos/translúcidos.
- Alternativas: equivalente e mais leve; ambas substituem a sessão original e atualizam os volumes do plano/dashboard/calendário sem criar sessões extras.
- Histórico: feedbacks persistem chave canônica por data original + tipo; fallback após remapeamento de ID exige correspondência única.
- Evolução: removidos painéis duplicados de zonas/calibração e atividades recentes; comportamento por zona permanece em Zonas de ritmo.
- Carga: sRPE só limita crescimento com histórico confiável; RPE médio alto requer pelo menos três atividades medidas.
- Harnesses Kotlin/JVM focados passaram. JUnit/Gradle, compilação Compose e APK aguardam GitHub Actions.

---

# Status do projeto — V90

- VersionCode 90 / VersionName V90.
- Motor de prescrição: 79. Backup Schema 5, compatível com schemas 1–5.
- Carga semanal: cautela moderada reduz progressão a 1–2%; somente recuperação <50, fadiga ≥75 ou dor bloqueiam progressão.
- Justificativas de carga preservadas por sessão; gráfico e cards consolidados por `WeeklyVolumeSummary`.
- Calendário com oito categorias e estados ✓/×/pendente.
- Testes de domínio focalizados precisam ser executados; Gradle/Android build/APK aguardam GitHub Actions.

- Aplicativo: AI Running Coach.
- Base de implementação: V88.
- VersionCode 89 / VersionName V89.
- Motor de prescrição: 78. Backup Schema 4, compatível com schemas 1–4.
- Calibração adaptativa Z1–Z3 por blocos e feedbacks reais; sem incremento fixo de 1%; limiar 2%, máximo 3% por revisão e 5% acumulados desde o último teste válido.
- Z4/Z5 permanecem vinculadas aos testes fisiológicos; revisão a cada 28 dias, com prévia, confirmação e histórico.
- Monitoramento de pace recupera ritmo ausente usando duração/distância, explica exclusões e diferencia feedbacks, sessões, atividades medidas e blocos.
- Médias de volume de 28 e 42 dias condicionadas a amostra mínima; reteste preferencial na semana 8 substitui sessão intensa elegível.
- Harness Kotlin/JVM focalizado aprovado. A suíte Gradle oficial/build Android e APK ainda dependem do GitHub Actions; ver `TEST_REPORT_V89.md` e `BUILD_STATUS_V89.md`.

## Histórico recente preservado
## Registro histórico — V88

- Validação de domínio V88: 48 arquivos Kotlin compilados; 71/73 testes focados passaram. As duas falhas restantes são de corrida/caminhada iniciante e também reproduzem na base V87. Build Gradle/APK pendente.

- Aplicativo: AI Running Coach.
- VersionCode 88 / VersionName V88.
- Motor de prescrição: 77. Backup Schema 4.
- Foco desta versão: corrigir a repetição da faixa de trabalho nas recuperações Fartlek e a repetição do aquecimento no primeiro bloco progressivo.
- Recuperação ativa Z2: 0–20%; trabalho Z2: 20–65%.
- Longões/rodagens progressivas: Z2 20–40% → Z2 40–65%, com Z3 de entrada apenas se elegível. Regressões usam sequência inversa.
- Migração idempotente corrige apenas sessões pendentes e preserva treinos concluídos/feedbacks.
- Build Android e suíte Gradle ainda dependem do GitHub Actions.

# Project Status — AI Running Coach V87
- V87: sistema de prova atualizado. Tempo-alvo explícito orienta a estratégia de execução A/B/C; a prioridade A continua sendo a única que define macrociclo, taper e recuperação pós-prova. B/C substituem uma sessão, sem taper automático.
- A estratégia calcula pace médio necessário e gera splits ponderados; meta agressiva é marcada como aspiracional e fica fora dos ritmos impostos, meta conservadora é aceita sem forçar intensidade e dados insuficientes são sinalizados como não validados.
- Guia de execução no dia da prova também utiliza automaticamente o tempo-alvo cadastrado. A exportação Pace Coach preserva pace alvo e distância em cada trecho.
- Tela de competições explica A/B/C e apresenta ação de recálculo após alterações. O recálculo atualiza sessões futuras, preservando treinos concluídos, feedbacks e histórico.
- `versionCode`: 87
- `versionName`: V87
- `CURRENT_ENGINE_VERSION`: 76
- Backup Schema: 4; leitura de schemas 1–4.
- Harnesses Kotlin/JVM focalizados: `RaceStrategyEngineTest` 11/11, `RaceDayGuideEngineTest` 3/3 e smoke test de exportação Pace Coach B/C 2/2 aprovados. A exportação preservou pace ponderado de 443,96/444,00 s/km para a meta de 444 s/km.
- Build Android/Compose e suíte Gradle completa ainda dependem da execução no GitHub Actions; APK não certificado nesta entrega.

## Histórico recente preservado
- V85: `versionCode=85`, `versionName=V85`, `CURRENT_ENGINE_VERSION=74`; volume total/meta/déficit usam treinos + provas não canceladas e compartilham `WeeklyVolumeSummary`.
- Backup Schema 4; leitura de schemas 1–4 preservada.
- V84: recuperações entre blocos eram validadas por interseção exata com o desaquecimento; essa regra foi substituída em V86 para `ACTIVE_Z2`, mantendo validação conservadora para Z1.
- V84: campos de data usam `TextFieldValue` controlado e reposicionam a seleção no fim após cada aplicação da máscara; cobre nascimento, testes e provas.
- Biblioteca: títulos de estágios repetidos não exibem sufixos numéricos redundantes; identidade/repetição interna continua preservada.
- Distribuição de intensidade: voltas explícitas e parciais agregadas de vários minutos entram no cálculo Z1–Z5; amostras GPS brutas acima de 120 s continuam descartadas para evitar preencher lacunas.
- GPX: atividades são apresentadas em quilômetros acumulados e uma parcial final fracionada. Voltas irregulares podem ser rateadas proporcionalmente; cobertura insuficiente permanece desconhecida, sem pace/tempo inventado.
- Revisão de zonas: abertura de teste usa inicialização completa do formulário; “Manter e observar” registra a decisão sem alterar as faixas automaticamente.
- Estratégia de prova: exportação ao Pace Coach via formato `UserWorkoutJson`, com etapas suportadas por evidência e sem metas de ritmo inventadas.
- Exportação semanal: nome `S{semana}_T{treino}_{Título}`, sem data, idêntico na prévia, no JSON e no nome do anexo.
- Perfil: não contém atalho de exportação de sessão.
- Exportação Pace Coach corrigida: 1 km = 1.000 m, com validação de duração, distância e alvos de ritmo.
- Pace médio previsto usa somente tempo em movimento; a duração total inclui pausas passivas.
- Flags de elegibilidade usam zonas Cooper calculadas mesmo antes de persistir a calibração no perfil.
- Prontidão POOR/YELLOW reduz o volume semanal entregue e mantém a qualidade suspensa enquanto o alerta persistir.
- Recuperações ativas exportam ritmo quando prescrito; pausas passivas continuam sem alvo.
- Fartlek F01/F04 usam seleção determinística condicionada à intenção e à presença de feedback de recuperação/fadiga; F04 só libera Z4 com elegibilidade de limiar.
- Tela Plano exibe evolução do volume semanal planejado, incluindo provas cadastradas.
- Primeira semana do plano passa a iniciar na próxima segunda quando todos os dias habituais da semana atual já passaram; domingo selecionado e ainda disponível mantém a semana atual.
- IDs de sessão novos são únicos por ciclo/data/tipo; reagendamento preserva data originalmente planejada.
- Importação seletiva de histórico exige correspondência por ID + data original, remapeia colisões legadas e não conclui sessões futuras de outro ciclo.
- Sem dependência de frequência cardíaca, FCM ou sensores cardíacos para cadastro, prescrição, feedback, calibração ou estratégia.

## Validação executada após as correções da V82

- Compilação Kotlin/JVM isolada dos motores de domínio alterados: concluída.
- Harness Kotlin/JVM: 370 testes aprovados/0 falhas, cobrindo 49 dos 53 arquivos de teste do projeto.
- Quatro arquivos dependentes de Android/JSON não foram executados no harness isolado: `AppBackupCodecTest.kt`, `PaceCoachExporterTest.kt`, `PaceCoachJsonAttachmentTest.kt` e `RaceStrategyWorkoutExporterTest.kt`.
- O teste de backup foi atualizado para identificar a versão V81 e verificar a leitura do schema 3/V78; sua execução ainda depende do ambiente Gradle/Android do projeto.
- ZIP final: validação estrutural e integridade com `unzip -t` após o empacotamento.

## Pendência de build Android

Este ambiente não possui Gradle CLI/Wrapper nem Android SDK. Portanto, não foi executada a compilação Android/Compose completa nem `:app:testDebugUnitTest`. O GitHub Actions deve confirmar `:app:testDebugUnitTest` e `:app:assembleDebug` antes de considerar o APK aprovado.


Consulte `BUILD_STATUS_V82.md`, `PACE_COACH_EXPORT_CONTRACT_V81.md` e `TRAINING_LIBRARY_VARIATION_V81.md` para a revisão atual.


## Revisão de calendário e backup aplicada à V81
- Migração de primeira semana vazia: aplicada na criação e no carregamento de planos salvos, sem renumerar semanas com sessão do próprio ciclo.
- Identidade de sessão: ciclo + data programada + tipo; ID legado sozinho não é chave suficiente.
- Importação seletiva: sessões antigas com ID igual e data diferente permanecem em separado com ID histórico; feedback acompanha o ID remapeado.
- Reagendamento: comparação por instância e prioridade do slot original + tipo na migração.
- Verificação isolada nesta revisão: 25 verificações Kotlin/JVM aprovadas, 0 falhas, mais 1 verificação separada do motor de feedback por bloco.
- Build Android/Compose e testes Gradle oficiais ainda precisam ser executados pelo GitHub Actions; esta revisão não declara APK certificado.


## Correção V81 — agenda e backup
- Âncora da primeira semana corrigida para o primeiro bloco com dia habitual ainda disponível.
- Colisões de ID legado separadas por data original e tipo; históricos não concluem treinos futuros de outro ciclo.
- Recalibração usa a rotina de preservação por instância e mantém feedback sem tipo apenas quando o slot é único.
- Integridade aplicada também às métricas planejado/realizado, feedback por bloco, eventos e exportações.
- 25 verificações focadas e 1 verificação isolada do feedback por bloco aprovadas; testes oficiais Gradle/Android permanecem pendentes.


## Correção V82 — âncora do ciclo e integridade do histórico

- A primeira semana agora começa na primeira semana civil que ainda contém ao menos um dia habitual de treino disponível. No caso de 21/11/2026 com segunda/quarta/sexta, a âncora efetiva é 23/11/2026.
- A identidade de sessão é determinística por ciclo/data/tipo; reagendamentos mantêm a data original imutável.
- A importação seletiva associa sessões por ID + data original + tipo compatível. IDs relativos antigos em datas diferentes são remapeados para identidade `LEGACY-*`; o feedback acompanha a instância histórica.
- O feedback sem data suficiente não pode concluir uma sessão futura por inferência.
- `CURRENT_ENGINE_VERSION = 73` solicita revisão/recálculo de planos salvos pelo motor anterior; backup schema 4 permanece compatível com schemas 1–4.
- Harness independente executado nesta revisão: 6/6 verificações de âncora, numeração semanal, estabilidade de ID e proteção de feedback aprovadas.
- As regressões JUnit de mesclagem JSON estão no pacote, mas ainda dependem da execução da suíte Gradle/Android no GitHub Actions. APK não certificado nesta sessão.


## Correção V83 — erro de compilação no build APK

- Corrigido `Unresolved reference: originalScheduledDateIso` em `MainActivity.kt`: o campo passou a existir explicitamente em `PrescribedWorkout`.
- Reagendamento propaga a data original desde `Workout` para `PrescribedWorkout`; conversões para análise/exportação também mantêm o valor.
- `RacePlanningEngine` usa `originalScheduledDateIso` para identificar a mesma instância após reagendamento, mantendo coerência com a chave usada pelo fluxo de proteção em `MainActivity`.
- Adicionados testes para a preservação da data original e para impedir que uma prova substitua sessão reagendada protegida.
- `versionCode = 83`, `versionName = V83`; motor 73 e Backup Schema 4 permanecem inalterados.
- Pendente: reexecutar `:app:testDebugUnitTest` e `:app:assembleDebug` no GitHub Actions.

## Validação V84

- Incluídos testes de regressão para recuperação ativa incompatível/compatível com o desaquecimento e para cursor ao final da data mascarada.
- `CURRENT_ENGINE_VERSION=74` solicita atualização dos planos antigos; a migração imediata modifica somente sessões não concluídas e não altera feedbacks ou sessões concluídas.
- Build Android/Compose e suíte Gradle ainda precisam ser executados no GitHub Actions.

## V90 — correção de compilação Kotlin
- O erro reportado pelo GitHub Actions era `Unresolved reference: rememberZoneBoundaries` em quatro pontos do `MainActivity.kt` Android.
- A função privada foi adicionada à classe `CoachState` no source set Android.
- VersionCode 90 / VersionName V90 / motor 79 / Backup Schema 5 permanecem inalterados.
- O ZIP corrigido está estruturalmente validado; `:app:testDebugUnitTest` e `:app:assembleDebug` ainda dependem da execução no GitHub Actions.


## Correções V96 — Auditoria V95
- Reteste futuro sem protocolo predefinido; Cooper/3 km é escolhido na data agendada e a sessão correspondente é montada e persistida.
- Cadastro declarado de volume semanal e maior sessão não é alterado pelos dados importados; carga medida fica separada e pode orientar a prescrição quando confiável.
- Ação de atualização das sessões futuras aparece apenas quando há atualização de zonas pendente; calibração adaptativa exige revisão e confirmação.
- Compatibilidade de backup ampliada para schemas 1–10.
