# Status do projeto — AI Running Coach V60

- Entrega: V60 (`versionCode = 60`, `versionName = V60`, `engineVersion = 45`).
- Base: V59; Backup Schema 2 preservado.
- Tela de sessão apresenta todos os segmentos e explicita a distância estimada dos blocos por tempo.
- Fartlek e recuperações de intervalados usam Z2 0–20%, não Z1 mais lenta que o desaquecimento.
- Duração-alvo dos segmentos por tempo calculada usando a faixa ativa real.
- Z3 em corrida sustentada/maratona sujeita à elegibilidade do atleta.
- Migração do motor recalcula somente sessões futuras, sem reiniciar o ciclo nem alterar sessões realizadas/feedbacks.
- Metadados do estímulo Z2/Z2–Z3 sincronizados com os segmentos realmente prescritos.
- Testes direcionados de JVM: 110 aprovados, 0 falhas.
- Auditoria técnica: ver `TRAINING_STRUCTURE_AUDIT_V60.md`.
- A compilação Android final ainda depende do workflow GitHub Actions.
