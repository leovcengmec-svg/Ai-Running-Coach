# Status atual — V56

- Base funcional: V55 (`versionCode = 55`, `engineVersion = 42`).
- Entrega atual: V56 (`versionCode = 56`, `versionName = V56`, `engineVersion = 42`).
- Correção pontual de compatibilidade de compilação no `ActivityFileImporter.kt`: propriedades JAXP ACCESS_EXTERNAL passam a usar URIs literais em vez de constantes ausentes em alguns Android SDK stubs.
- Segurança XML preservada por rejeição de DOCTYPE, desativação best-effort de entidades externas e EntityResolver vazio.
- Funcionalidades V55 preservadas: importação RunnerUp GPX/FIT/TCX, calendário e distribuição semanal, sessões aeróbias variáveis, backup/restauração e calibração Z1–Z3.
- Schema do backup: 2 (sem mudança de estrutura). EngineVersion: 42 (sem migração de plano necessária).
- Compilação Android completa deve ser confirmada pelo GitHub Actions; este ambiente não contém Android SDK/Gradle wrapper.
