# Project Status — AI Running Coach V79
- Correção de build: `KeyboardOptions` importado de `androidx.compose.foundation.text` e dependência direta `androidx.compose.foundation:foundation` adicionada. Build Android completo ainda aguarda confirmação do GitHub Actions.
- versionCode: 79
- versionName: V79
- CURRENT_ENGINE_VERSION: 69
- Backup Schema: 4 (leitura schemas 1–4; compatibilidade V78 Schema 3)
- Entrada inteligente: máscara de data, ritmo, tempo e distância nos principais formulários.
- Métricas: cálculo centralizado de distância/tempo/ritmo previsto e realizado; os cards não misturam os dois conjuntos.
- Importação: parciais e trechos fracionados preservados; diferença entre distância declarada e GPS incompleto fica identificada como estimada/sem detalhe GPS.
- Carga: distribuição semanal com precisão de 0,1 km; longão pode progredir se a prontidão e o limite individual permitirem, sem progressão forçada em toda semana.
- Zonas: revisão assistida por evidências, sem alteração automática da faixa.
- Competições: gerenciamento separado da estratégia; nova tela de estratégia por distância e prioridade A/B/C baseada em zonas e evidências recentes.
- `Screen.RACE_STRATEGY` foi anexada ao final do enum para preservar ordinais salvos da V78. Seleção da prova é transitória no backup.
- Sem dependência de FC/FCM na prescrição, progressão, feedback ou estratégia.
- Validação local: harnesses Kotlin/JVM focados passaram; build Android completo e suíte Gradle aguardam execução no GitHub Actions.


## Correção de compilação V79 (20/11/2026)
- Corrigidos dois argumentos `Dp` incompatíveis com `SecondaryButton.horizontalPadding: Int`.
- Encaminhado callback de abertura da estratégia de prova ao `TrainingWeekCard`, removendo referência `state` inexistente no escopo do componente.
- Harnesses Kotlin/JVM de máscaras, calculadora, importador GPX, estratégia e distribuição de carga passaram novamente.
- O APK permanece pendente de compilação integral no GitHub Actions.
