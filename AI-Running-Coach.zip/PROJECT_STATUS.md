# Status do projeto — AI Running Coach V67

- **Entrega de código:** V67 (`versionCode = 67`, `versionName = V67`, `engineVersion = 53`). Base V66; Backup Schema 2 preservado.
- **Correção de build:** declarado `latestTest` no escopo do painel “Zonas e calibração” em `MainActivity.kt`. A variável seleciona a avaliação fisiológica mais recente por `dateIso`, corrigindo a referência não resolvida que interrompia `:app:compileDebugKotlin`.
- **Versionamento do backup:** `appVersion = V67`; teste do manifesto atualizado. O motor de prescrição não mudou nesta revisão, portanto `engineVersion` permanece 53.
- **Validação:** a causa exibida na captura foi localizada e corrigida no código. O build Android/Gradle ainda precisa ser executado no GitHub Actions; não declarar APK aprovado antes da conclusão de `testDebugUnitTest` e `assembleDebug`.

---

# Status do projeto — AI Running Coach V66

- **Entrega de código:** V66 (`versionCode = 66`, `versionName = V66`, `engineVersion = 53`). Base V65; Backup Schema 2 preservado. A instalação V66 solicita recálculo de planos gerados com engineVersion 52. Quando confirmado, mantém sessões concluídas, feedbacks, histórico e âncora do ciclo; só regenera sessões futuras.
- **Prescrição orientada por objetivo:** o motor usa distância, intenção (completar, correr continuamente, recorde pessoal ou tempo-alvo), fase, disponibilidade, terreno, volume semanal, maior sessão, consistência, dor, fadiga e recuperação para selecionar protocolos nomeados da matriz MOTOR V11. A mesma meta de 5 km pode, portanto, ter sessão diferente quando o objetivo é completar versus melhorar recorde.
- **Plano validado de exemplo:** 5 km / recorde pessoal, 3 dias por semana, 16 km/semana, maior sessão recente 10 km, 3 semanas ativas, Cooper 2,1 km e zonas válidas. Em 10 semanas, a seleção por protocolo foi F01/F04 Fartlek aeróbio, T01 Tempo Run, I04 intervalado, T04 Tempo intervalado, RP05 específico de 5 km e I07 intervalado 600 m, com semanas 4 e 8 regenerativas. É uma simulação de motor, não um resultado de atleta real.
- **Regras de elegibilidade:** a classificação fisiológica não substitui a análise de tolerância. Qualidade aeróbia e limiar dependem de frequência, carga semanal, maior sessão recente, consistência, dor, recuperação, fadiga e terreno. VO₂/alta intensidade têm porta de entrada mais exigente. Treinos de qualidade não são liberados apenas por VO₂ alto nem bloqueados apenas pelo rótulo Iniciante.
- **Fartlek corrigido:** F01 alterna trabalho ativo Z2–Z3, com recuperação em Z1, conforme a aba PROTOCOLOS da planilha. F02 é mais intenso e exige maior frequência e carga; F03 piramidal Z3–Z5 exige quatro dias, maior volume e prontidão.
- **Distribuição de intensidade:** as referências ajustam-se à fase do ciclo (base, desenvolvimento, específico, recuperação/taper). As faixas não são quotas obrigatórias. A distribuição medida só será tratada como real quando houver tempos segmentados; estimativas permanecem identificadas.
- **VO₂max e níveis:** o Cooper usa `22,351 × distância (km) − 11,288`. O teste de 3 km usa equações de Aandstad (2021), validadas em adultos de 18–39 anos. A classificação em quatro níveis agrupa duas faixas inferiores da tabela de aptidão por idade/sexo de Mandsager et al. (2018): abaixo do limite de “Above Average” = Iniciante; acima desse ponto = Intermediário; a partir do limite “High” = Performance; a partir do limite “Elite” = Elite. Esta é uma referência geral de aptidão cardiorrespiratória, não um ranking competitivo nem diagnóstico. Sem idade e referência armazenadas, o app exibe “Aguardando idade/referência da avaliação”, nunca classe definitiva.
- **Metas:** Iniciante e Intermediário compartilham distâncias compatíveis até meia maratona. A diferenciação está na dose e complexidade das sessões, não na proibição artificial de objetivos. Performance libera maratona; Elite inclui ultradistâncias.
- **Interface/perfil:** a tela de meta mostra nível fisiológico e VO₂max; o perfil separa dados informados da atividade realmente registrada em 28 dias. O nome é solicitado no primeiro cadastro e editável no perfil; não está fixo no código. A biblioteca mostra status explícito para cada modalidade e explica quando entra.
- **Planos antigos:** V66 incrementa `CURRENT_ENGINE_VERSION` para 53. O plano V65 deve ser recalculado para aplicar a matriz de objetivo/fase e a seleção corrigida; sessões concluídas e dados históricos permanecem preservados.
- **Validação:** compilação isolada Kotlin/JVM e harness de geração de plano executados no ambiente de edição. A suíte completa Gradle/JUnit, APK Debug/Release e teste funcional em dispositivo Android não foram executados aqui; devem ser aprovados pelo workflow `build-apk` no GitHub Actions.

## Referências de método

- Aandstad A. *Estimation of maximal oxygen uptake from the 3,000 m run in adult men and women*. Journal of Sports Sciences, 2021. https://pubmed.ncbi.nlm.nih.gov/33730971/
- Mandsager K. et al. *Association of Cardiorespiratory Fitness With Long-term Mortality Among Adults Undergoing Exercise Treadmill Testing*. JAMA Network Open, 2018. https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2707428
- *Training-intensity distribution on middle- and long-distance runners: a systematic review*. https://pubmed.ncbi.nlm.nih.gov/34749417/
- *Which Training Intensity Distribution Intervention will Produce the Greatest Improvements in Maximal Oxygen Uptake and Time-Trial Performance in Endurance Athletes?* Systematic review and network meta-analysis of individual participant data, 2025. https://pubmed.ncbi.nlm.nih.gov/39888556/
- Planilha fornecida no projeto: abas `TREINOS PRONTOS`, `PROTOCOLOS`, `MOTOR V11`, `TESTE DE CORRIDA`, `TESTE DE VELOCIDADE CRÍTICA` e `PISO CORRIDA`. As fórmulas quebradas da planilha não foram transplantadas; foi utilizada a estrutura de matriz e a descrição dos protocolos.
