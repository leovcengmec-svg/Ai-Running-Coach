# Status do projeto — AI Running Coach V61

- Entrega de código: V61 (`versionCode = 61`, `versionName = V61`, `engineVersion = 46`).
- Base: V60. Backup Schema 2 preservado.
- Catálogo de objetivos: milha, 3 km, 5 km, 10 km, 15 km, meia maratona, maratona, ultramaratona 50 km, saúde e objetivo personalizado 1–100 km.
- Macrociclo: BASE, DEVELOPMENT, SPECIFIC e RECOVERY.
- Biblioteca: contínuo, progressivo/regressivo, intervalado aeróbio Z2/Z2–Z3, misto Z3–Z4/Z4–Z5, piramidal, fartlek, limiar, maratona e ultradistância.
- Recuperações dos intervalados em Z2 0–20%. Z1 reservada a aquecimento/desaquecimento e regenerativo.
- Provas A/B/C: A organiza ciclo/taper/recuperação; B/C substituem sessão na semana sem taper automático.
- Objetivo Saúde preserva frequência e não injeta automaticamente limiar, VO₂ ou Z3 de qualidade.
- `TrainingPrescriptionAudit` valida distância, pace, zona, banda ativa, nome e recuperação.
- Teste de execução Kotlin: 256 sessões em oito objetivos, frequências de 2 a 6, provas A/B/C, fartlek, intervalados mistos, saúde e alternativas — aprovado.
- Compilação Kotlin isolada dos motores centrais aprovada. Compilação Android completa ainda depende de GitHub Actions `build-apk`.
