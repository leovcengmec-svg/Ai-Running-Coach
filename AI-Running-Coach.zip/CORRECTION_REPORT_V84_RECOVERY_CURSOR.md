# Relatório de correção V84 — recuperação e cursor

## 1. Recuperação excessivamente lenta

A V80 definiu F01 com recuperação na parte superior da Z1 (90–100%), mas esse percentual é relativo à própria Z1. Ele não garante que o pace seja compatível com o desaquecimento, que pode estar na Z2. O `ZoneIntensityBandEngine` preservava bandas explícitas antigas e não comparava o pace absoluto entre recuperação e desaquecimento.

### Correção
- O motor calcula a faixa final de cada segmento primeiro.
- Localiza o desaquecimento (ou, como fallback, o aquecimento) e compara as faixas em segundos por quilômetro.
- Se houver sobreposição, mantém a recuperação ativa e registra `ACTIVE_Z1`/`ACTIVE_Z2` quando o modo não estava declarado.
- Sem sobreposição ou sem referência numérica, converte a recuperação para `WALK`, remove ritmo e zona, instrui caminhada e preserva a duração/distância estimada já registrada.
- O mesmo normalizador atua na saída `PrescribedWorkout`, na saída `Workout` e na migração de sessões futuras/incompletas já salvas.
- Sessões concluídas não são alteradas; feedbacks e históricos permanecem intactos.

No exemplo dos prints, recuperação Z1 8:50–9:31 e desaquecimento Z2 7:57–8:10 não se sobrepõem. Portanto, a recuperação passa a ser caminhada, sem prescrever um pace artificialmente lento nem falsificar a zona.

## 2. Cursor da data

Os campos usavam `String` e transformavam o texto para inserir `/`, deixando o IME reaproveitar um deslocamento de seleção anterior.

### Correção
- Novo componente `SmartDateOutlinedTextField`.
- Estado de entrada usa `TextFieldValue`.
- A cada mudança, aplica `SmartInputMask.date()` e fixa `selection` em `TextRange(formatted.length)`.
- Campo numérico utilizado para datas.
- Aplicado a nascimento, avaliação Cooper, perfil e cadastro de prova.

## 3. Migração e versionamento
- `versionCode=84`, `versionName=V84`.
- `CURRENT_ENGINE_VERSION=74` para sinalizar planos anteriores.
- Backup Schema 4 mantido.
- Durante o carregamento, somente sessões não concluídas são verificadas e normalizadas. A migração é idempotente.

## 4. Testes adicionados
- Recuperação antiga Z1 0–50% incompatível com desaquecimento Z2 => caminhada sem pace.
- Recuperação Z1 com sobreposição real com desaquecimento => permanece ativa.
- Reaplicar o motor não altera novamente uma recuperação já convertida.
- Campo de data parcial/completo sempre termina com cursor após o último caractere.

## 5. Limitação da validação
Os testes foram adicionados ao projeto, mas o build Android e `:app:testDebugUnitTest` não foram executados neste ambiente por ausência de Gradle Wrapper/Android SDK. O CI do GitHub precisa validar a compilação Compose e a suíte completa antes da aprovação final do APK.

## 6. Resultado dos harnesses focados
- O arquivo real `ZoneIntensityBandEngine.kt` foi compilado com modelos auxiliares isolados e executado: recuperação Z1 incompatível convertida para caminhada; reaplicação idempotente; faixa Z1 com interseção manteve modo ativo; migração não alterou o treino concluído.
- `SmartInputMask.kt` e `SmartDateOutlinedTextField.kt` foram compilados contra stubs das APIs Compose e o helper de valor/seleção foi exercitado: cursor permaneceu após o último caractere em data parcial e completa. Essa verificação não equivale a build Compose oficial.
- `:app:testDebugUnitTest` e `:app:assembleDebug` permanecem pendentes no CI.
