# Relatório de correção do build — V83

## Falha recebida
O GitHub Actions interrompeu `:app:compileDebugKotlin` com:

`MainActivity.kt:1029:63 Unresolved reference: originalScheduledDateIso`

## Causa raiz
`originalScheduledDateIso` fazia parte do modelo `Workout`, mas o código de proteção contra substituição por provas acessava essa propriedade em `PrescribedWorkout`. A propriedade não existia nesse modelo. A V82, portanto, não poderia compilar o módulo Android.

## Correção aplicada
1. Acrescentado `originalScheduledDateIso: String = ""` ao final de `PrescribedWorkout`, evitando quebrar construtores posicionais existentes.
2. A migração de reagendamentos copia para a prescrição a data original registrada na sessão salva (ou a data salva como fallback).
3. Os dois adaptadores `Workout -> PrescribedWorkout` preservam a data original.
4. O motor de ajuste de provas usa `SessionIdentityEngine.identityDate(scheduledDateIso, originalScheduledDateIso)` ao criar a chave da sessão, para a chave protegida ser consistente com o fluxo principal.
5. Testes adicionados: preservação da data original ao reaplicar reagendamento e proteção da sessão reagendada contra substituição por prova.

## Versão
- ZIP: `AI-Running-Coach.zip` (nome preservado).
- `versionCode = 83`; `versionName = V83`.
- `CURRENT_ENGINE_VERSION = 73`; Backup Schema 4 sem alteração.

## Estado da validação
A revisão de código confirma que o símbolo ausente agora está declarado no tipo correto e que seu valor é propagado pelos fluxos relevantes. O build Gradle completo ainda precisa ser executado no GitHub Actions; não foi possível afirmar aprovação do APK nesta sessão.
