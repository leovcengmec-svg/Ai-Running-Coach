# Correção de build V79 — KeyboardOptions

## Erro recebido
O GitHub Actions reportou `Unresolved reference: KeyboardOptions` em `MainActivity.kt:37` e em chamadas de campos de texto nos formulários.

## Causa
A classe foi importada de `androidx.compose.ui.text.input.KeyboardOptions`, mas a API atual do Jetpack Compose disponibiliza `KeyboardOptions` em `androidx.compose.foundation.text`. `KeyboardType` permanece em `androidx.compose.ui.text.input.KeyboardType`.

## Correção
- Alterado o import para `androidx.compose.foundation.text.KeyboardOptions`.
- Declarada explicitamente `implementation("androidx.compose.foundation:foundation")`, com versão gerenciada pelo Compose BOM 2026.09.00.
- Mantidos os campos, máscaras, tipos de teclado e comportamento de entrada existentes.
- Mantidos `versionCode = 79`, `versionName = V79`, motor 69 e Backup Schema 4.

## Verificação
- Confirmado que o import incorreto não permanece no código.
- Confirmado que a classe é importada uma única vez do pacote correto.
- Confirmado que todas as referências no `MainActivity.kt` continuam usando a mesma API.
- ZIP estruturalmente validado.

A compilação Android/Compose completa deve ser confirmada no GitHub Actions executando `:app:testDebugUnitTest` e `:app:assembleDebug`. Não declarar o APK aprovado antes dessa execução.
