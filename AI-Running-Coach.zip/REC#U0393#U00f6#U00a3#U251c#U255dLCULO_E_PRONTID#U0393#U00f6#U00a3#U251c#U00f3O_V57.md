# Recalcular plano e indicadores — V57

## Recálculo do ciclo
- Um plano existente mantém `planStartDateIso` e `planWeeks` enquanto o ciclo está ativo.
- `PlanMigrationEngine.inferRestoredCycleAnchor` repara uma âncora deslocada quando datas e números de semana fornecem evidência consistente.
- As sessões passadas, concluídas e com feedback permanecem preservadas. A prescrição é regenerada somente para hoje e datas futuras; as semanas são recalculadas em relação à segunda-feira original.
- Se não houver plano salvo ou se a data atual já estiver fora da janela original, começa um novo ciclo.
- A frequência `frequency` e `availableTrainingDays` escolhida no cadastro (2–6) deve corresponder e é mantida em todos os níveis. Em iniciantes/reentrada, as sessões são de menor dose/corrida-caminhada e qualidade intensa fica suprimida até haver pré-requisitos.

## Feedback e zonas
- O feedback de cada sessão salva sensação, esforço/RPE, dor e métricas reais informadas/importadas. `needsEngineRefresh` solicita recalcular.
- Z1: três sessões regenerativas/recuperação, recentes (42 dias), sem dor, esforço leve/muito leve, sensação Bem/Ótimo e pace real disponível.
- Z2: três observações válidas do teste da fala em treinos elegíveis, confortáveis e sem dor.
- Z3: dois testes Cooper independentes, pelo menos 14 dias separados e variação de distância até 8%; uma rodagem comum não substitui o Cooper.
- Cada fronteira muda gradualmente (até 15 s por atualização) e as zonas permanecem contíguas. O recálculo aplica as zonas resultantes às sessões não concluídas de hoje em diante; o histórico não é reescrito.

## Treinos extras
- A consulta existe somente em dia livre/descanso e em data não passada; o motor também valida dia ocupado e competição antes de permitir inclusão.
- O corredor escolhe explicitamente entre opção leve Z1 e moderada Z2. Frequência semanal excedida, sessão anterior pendente, treino exigente próximo, dor, fadiga e distância temporal são alertas, não inclusão automática.
- A faixa de 3–5 km exige referência semanal de pelo menos 14 km e maior corrida recente de pelo menos 7 km. O rótulo “iniciante” não anula evidências de carga; nesse caso, duração mais conservadora e corrida/caminhada são mantidas.
- Dor recente reduz a distância estimada em 40% e eleva alerta de risco; fadiga forte reduz em 25%, fadiga moderada em 10%; sessão exigente próxima reduz em 15%. Isso é heurística de prudência, não um limite fisiológico universal.
- Se a carga disponível não sustenta 3 km, o app oferece opção mais curta/por tempo e explica a limitação, sem inventar distância.

## Cards Recuperação e Segurança
- Usa até os três feedbacks mais recentes nos últimos 14 dias. Sem dados: “Não avaliada”. Um único feedback confortável sem dor/fadiga ainda não é suficiente para declarar boa recuperação; exige pelo menos duas observações para mostrar Boa (80/100) e Sem alerta. Uma sessão com cansaço/esforço pesado gera recuperação Moderada (60/100) e atenção amarela. Duas sessões afetadas geram recuperação Baixa (35/100) e alerta amarelo. Qualquer dor relatada gera recuperação Baixa (10/100) e alerta vermelho.
- A regra conta sessões afetadas, não campos individuais; um feedback que marque tanto “Cansado” como “Pesado” conta como uma sessão. Um único feedback bom não é considerado evidência suficiente; dor ou fadiga, porém, são sinalizadas imediatamente.
- Não são avaliação médica nem usam sono, HRV, FC repouso ou variabilidade cardíaca, pois esses dados não são coletados no fluxo atual.
