# BUILD STATUS — AI Running Coach V83

## Identificação
- Base: V82.
- `versionCode`: 83
- `versionName`: V83
- `CURRENT_ENGINE_VERSION`: 73 (sem mudança de regra de prescrição).
- Backup Schema: 4 (sem mudança de formato).

## Correção do erro reportado pelo GitHub Actions
O build V82 falhou com `Unresolved reference: originalScheduledDateIso` em `MainActivity.kt`. O campo existia em `Workout`, mas era acessado numa instância de `PrescribedWorkout`, que não o declarava.

Correção aplicada:
- Adicionado `originalScheduledDateIso` ao modelo `PrescribedWorkout` como campo opcional com valor padrão vazio, no final do construtor para preservar compatibilidade com chamadas posicionais existentes.
- `PlanMigrationEngine.reapplyManualRescheduleDates` grava a data original ao reaplicar uma sessão reagendada.
- Conversões de `Workout` para `PrescribedWorkout` mantêm o campo.
- `RacePlanningEngine` calcula a chave da sessão com a data original imutável, quando disponível.
- `PlanMigrationRescheduleTest` verifica a persistência do slot original.
- `RaceEventEngineTest` verifica que uma prova não substitui sessão reagendada protegida pela identidade original.

## Validação e pendências
- Revisão estática do erro e dos tipos: concluída; a referência passa a existir no tipo usado pela linha 1029.
- `versionCode`/`versionName`: conferidos em `android/app/build.gradle.kts`.
- `CURRENT_ENGINE_VERSION` e Backup Schema mantidos porque não houve alteração da regra de prescrição nem do contrato de backup.
- O ambiente desta execução não contém Gradle CLI/Wrapper nem Android SDK; portanto, não foi possível executar a compilação Android local.
- O próximo passo obrigatório é executar `:app:testDebugUnitTest` e `:app:assembleDebug` no GitHub Actions. Esta entrega não afirma que o CI já passou.

**Status:** causa do erro corrigida no código; validação final de build Android pendente.
