# Auditoria de faixas ativas da biblioteca — V88

## Regras globais
- Faixas ativas são posições percentuais dentro da zona individual: 0 = mais lento, 100 = mais rápido.
- Esforço aeróbio Z2 habitual: 20–65%, salvo protocolo específico.
- Recuperação ativa Z2: 0–20%; não reutilizar 20–65% do trabalho.
- Aquecimento/desaquecimento experiente: Z2 0–20%; o primeiro bloco principal progressivo deve avançar para 20–40%.
- Z3/Z4/Z5 continuam condicionadas aos mesmos gates de perfil, carga e prontidão; V88 não libera zonas mais altas.

## Biblioteca revisada
- F01/F02/F04: recuperações entre blocos recebem Z2 0–20%; duração específica do protocolo preservada.
- Intervalados Z2: recuperação ativa Z2 0–20%, distinta do trabalho Z2 20–65%.
- Intervalados Z3/Z4: recuperação permanece conforme definição do protocolo (Z2 fácil, Z1, caminhada ou pausa passiva), sem transformar automaticamente recuperação WALK/PASSIVE em corrida.
- Longão/rodagem progressiva Z2-only: 20–40% → 40–65%.
- Progressão elegível Z2→Z3: Z2 20–40% → Z2 40–65% → Z3 0–20%.
- Regressão Z2-only: 40–65% → 20–40%; regressão elegível Z3→Z2: Z3 0–20% → Z2 40–65% → Z2 20–40%.
- Sessões curtas ou regenerativas não são aceleradas só para cumprir uma sequência progressiva.

## Auditoria automática
`TrainingPrescriptionAudit` valida: recuperação Fartlek ACTIVE_Z2 0–20%; diferença entre recuperação e esforço Z2; primeiro bloco principal diferente do aquecimento; ordem das bandas Z2 em progressões/regressões; e coerência entre pace calculado, faixa percentual e snapshot individual.
