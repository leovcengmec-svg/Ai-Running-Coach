# AI Running Coach — Plano de correção V99

**Auditoria da V98 · 26/11/2026**  
**Status:** causas de validação confirmadas no código; plano de correção elaborado. A implementação V99 ainda não foi realizada.

## 1. Identificação da próxima versão

| Item | Proposta |
|---|---:|
| VersionCode | 99 |
| VersionName | V99 |
| Motor interno | 89 |
| Base | V98 |
| Backup Schema | 13 (sem alteração estrutural) |
| Compatibilidade | Leitura dos schemas 1–13 |

A correção não exige novos campos persistidos. O schema 13 deve ser mantido para evitar migração de backup desnecessária; somente a lógica de validação e a rastreabilidade de geração serão ajustadas.

---

## 2. O que as duas imagens demonstram

### Imagem 1 — restauração de backup e recalibração

A tela informa:

- motor do backup: 83;
- motor atual: 88;
- semana de 23/11/2026 a 29/11/2026: 4 compromissos para uma frequência de 3 dias;
- semana de 07/12/2026: longão de 6,8 km representando 57,1% do volume semanal.

A restauração preserva o plano e oferece recalibração posterior. O bloqueio acontece durante a validação da proposta recalculada, e não significa que o arquivo não tenha sido restaurado.

### Imagem 2 — criação de plano novo

A mensagem informa:

- semana de 23/11/2026: longão de 6,0 km representando 100,0% do volume considerado;
- semana de 07/12/2026: longão de 6,8 km representando 57,1% do volume considerado.

O aviso de 100% mostra que a validação está calculando a participação do longão sobre apenas a parte da semana que restou no calendário. Como a captura foi feita na quinta-feira, 26/11, sessões dos dias anteriores podem já ter sido filtradas da primeira semana, enquanto o validador continua tratando o resultado como uma semana completa.

A participação de 57,1% implica um denominador de aproximadamente 11,9 km (6,8 / 0,571). Portanto, a lista final que chega ao validador nessa semana está somando aproximadamente 11,9 km. Para uma semana futura completa de um plano configurado para três dias, é necessário descobrir por que a composição final contém apenas esse volume/essas sessões, ou se uma prova substituta não está sendo contabilizada no total. O screenshot não contém a lista completa de sessões nem o JSON de backup; por isso, não é possível atribuir com segurança essa perda a uma única etapa sem instrumentar a geração ou examinar o backup real.

---

## 3. Causas confirmadas no código V98

### 3.1 Sessões concluídas são contadas como compromissos futuros

Arquivo: `android/app/src/main/java/com/airunningcoach/app/TrainingCalendarIntegrityEngine.kt`  
Função: `validate()`.

O código atual cria `activeWorkouts` a partir de toda sessão cuja data não seja anterior à segunda-feira da semana atual. Ele **não exclui `workout.done == true`**. Depois, `commitmentCount` é calculado pelo tamanho da lista de datas, somando também as provas.

Consequência: um treino realizado na segunda ou terça continua sendo contado como compromisso da semana, mesmo que não possa mais ocupar um dia futuro. Ao recalibrar um backup, a lista mescla sessões concluídas preservadas com sessões futuras e provas; a frequência pode parecer excedida quando, na realidade, só existem três dias futuros ou menos.

A contagem também usa o número de elementos, não o número de datas distintas. Treino e prova na mesma data podem inflar a contagem além do aviso separado de conflito no mesmo dia.

**Correção obrigatória:** frequência deve contar somente compromissos principais ainda não concluídos e futuros (data >= hoje), agrupados por data distinta. Provas planejadas contam como um dia de corrida. Treinos concluídos permanecem no histórico e podem contribuir para a carga real da semana, mas nunca para a frequência futura.

### 3.2 O teto de 40% está sendo aplicado a uma semana parcial

Arquivo: `TrainingCalendarIntegrityEngine.kt`, função `validate()`.  
Fluxo relacionado: `TrainingScheduleEngine.keepUpcomingSessionsForCurrentWeek()` e `MainActivity.createPlan()`.

A validação da participação do longão usa a soma das sessões existentes em cada semana, mas não sabe se aquela semana está completa. No fluxo de criação de plano novo, `keepUpcomingSessionsForCurrentWeek()` remove sessões com data anterior a hoje. Se a primeira semana do ciclo for a semana atual, a validação pode receber somente uma sessão futura — por exemplo, o longão de domingo — e calcular `6,0 / 6,0 = 100%`.

Isso não prova que a distribuição semanal original estivesse errada: o denominador foi reduzido porque a semana já começou.

**Correção obrigatória:** não bloquear plano por participação do longão calculada somente sobre sessões remanescentes de uma semana parcial. A primeira semana deve ser validada com a distribuição integral originalmente gerada (incluindo sessões já concluídas quando disponíveis) ou, se não houver dados completos, deve ser marcada como parcial e não entrar no bloqueio percentual. O teto de 40% continua obrigatório para semanas futuras completas.

### 3.3 A distribuição de 40% acontece antes das transformações finais

Arquivos:
- `CoachEngine.kt`, `buildWeek()`;
- `WeeklySessionDistributionEngine.kt`;
- `RacePlanningEngine.kt`, `applyToPlan()`;
- `PlanMigrationEngine.kt`, funções de exclusão, preservação e merge;
- `MainActivity.kt`, montagem de `proposedWorkouts` e chamada final do validador.

`WeeklySessionDistributionEngine` limita a participação do longão antes de as provas, sessões concluídas, reagendamentos manuais, sessões órfãs e sessões congeladas serem recompostas. Em seguida, `RaceEventEngine.applyToPlan()` pode substituir ou deslocar sessões; `MainActivity.createPlan()` combina o resultado com histórico e sessões preservadas; por fim, `TrainingCalendarIntegrityEngine` calcula o volume real dessa composição.

Portanto, a garantia do distribuidor inicial não é suficiente. A V98 mostra um resultado final de 57,1%, que não pode ser aceito para uma semana completa. A V99 deve verificar a composição depois de todas as transformações e, se uma sessão foi removida/duplicada ou uma prova não entrou no volume, corrigir a etapa que provocou a divergência — não relaxar o teto de 40%.

**Limitação da evidência:** o código confirma os pontos em que uma sessão pode ser substituída, filtrada ou mesclada. Sem o backup JSON real e sem a lista de sessões da semana de 07/12, não é possível dizer se a origem específica dos 11,9 km é uma substituição por prova, uma identidade marcada como concluída, um reagendamento ou uma sessão que não foi gerada. A V99 precisa registrar esses dados por semana para fechar essa causa sem suposição.

### 3.4 O validador mistura três conceitos diferentes

Hoje, o mesmo conjunto `activeWorkouts` é usado para:

1. contar frequência;
2. detectar conflito de dia;
3. calcular volume semanal e participação do longão.

Esses usos têm regras diferentes:

- Frequência: sessões ainda pendentes e futuras + provas planejadas, contadas por dia.
- Conflito: sessão pendente no mesmo dia de outra sessão ou prova planejada; sessão já concluída não gera conflito futuro.
- Carga: todas as sessões realmente realizadas na semana + sessões futuras planejadas + provas planejadas, cada evento contado uma única vez. Na semana parcial, não se pode interpretar somente o saldo futuro como o volume de uma semana completa.

A V99 deve separar explicitamente essas três coleções/medidas.

---

## 4. Plano de implementação V99

### 4.1 Refatorar `TrainingCalendarIntegrityEngine`

Substituir a lista única `activeWorkouts` por conjuntos específicos:

**Compromissos futuros**
- workouts com data válida, `date >= today`, `done == false` e não marcados como extra opcional;
- provas com `status == PLANNED` e data `>= today`;
- contagem por `distinct date`, não por item;
- detectar separadamente treino e prova no mesmo dia;
- excluir sessões concluídas da contagem e dos conflitos futuros.

**Carga semanal real/planejada**
- manter sessões concluídas da semana no total de carga quando forem parte do ciclo;
- incluir apenas sessões futuras ativas uma vez;
- incluir provas planejadas uma vez, quando substituírem uma sessão;
- impedir somar simultaneamente uma sessão removida e sua prova substituta;
- não permitir que itens opcionais ou duplicados entrem duas vezes no total.

**Longão**
- preservar teto máximo de 40% para semanas futuras completas;
- preservar a regra de ser a maior sessão;
- não verificar participação usando apenas o restante de uma semana parcial;
- quando a semana atual não tiver dados completos de sessões já realizadas, registrar estado `PARTIAL_WEEK_NOT_BLOCKING` e não gerar erro de 100%;
- se uma semana futura completa exceder 40%, bloquear a aplicação e apontar a composição que levou ao percentual.

### 4.2 Não enfraquecer a regra do longão

A V99 não deve remover o limite de 40% nem aceitar longão como 57,1% em semana futura completa.

A correção deve garantir que o conjunto final após provas e merge preserve:
- no máximo um longão principal por semana;
- longão maior que a segunda maior sessão;
- participação do longão <= 40% do volume total da semana, contando a prova que substituiu uma sessão;
- frequência máxima configurada;
- sem dois compromissos no mesmo dia.

Se a combinação de volume, frequência, prova e piso mínimo das sessões não admitir distribuição válida, o plano deve ser bloqueado com motivo específico e composição detalhada. Não aumentar quilometragem automaticamente nem produzir sessão abaixo do piso de 5 km para objetivo de 5 km fora das exceções já aprovadas (semana Regenerativa e protocolo inicial de caminhada/corrida).

### 4.3 Auditar substituição de prova

Em `RacePlanningEngine.applyToPlan()`:
- preservar exatamente uma sessão substituída por prova;
- se uma prova curta coincidir com o dia do longão, preservar o longão e transferi-lo apenas para um slot realmente liberado;
- contar a prova uma vez na carga semanal e uma vez na frequência;
- depois de cada substituição, verificar que o total de sessões de treino + provas corresponde ao número esperado para aquela semana;
- não permitir que a sessão deslocada e a sessão original permaneçam simultaneamente;
- acrescentar teste de prova com distância menor e maior que o longão.

### 4.4 Diagnóstico rastreável da composição semanal

Antes de emitir um bloqueio de 40%, montar uma explicação interna para cada semana:
- data inicial e final;
- número de sessões geradas antes de provas;
- lista de `sessionId`, tipo, data, distância, estado `done`, `isOptionalExtra` e flag de reagendamento;
- provas consideradas: ID, data, distância e status;
- sessão removida/substituída por prova;
- sessões preservadas do backup;
- total do denominador e participação do longão;
- meta semanal original (`weeklyTargetKm`), quando disponível.

A mensagem ao corredor deve ser curta e clara. O diagnóstico detalhado pode ficar no log de auditoria/teste. Exemplo: “Semana de 07/12: longão 6,8 km; rodagem 5,1 km; prova não contabilizada/ sessão ausente. Total considerado 11,9 km; participação 57,1%. Plano preservado; revise a agenda.” Não mostrar “incluindo provas” se nenhuma prova ativa entrou no denominador.

### 4.5 Corrigir todos os pontos de chamada

Aplicar as mesmas regras de validação em:
- `MainActivity.createPlan()`;
- `MainActivity.rescheduleWorkout()`;
- `MainActivity.recalculatePlanWithCurrentEngine()` via `createPlan()`;
- fluxo de restauração de backup antigo;
- criação de plano no onboarding.

A recalibração do backup deve continuar transacional: se a validação falhar em semana futura completa, o plano importado permanece preservado. Um problema de semana parcial não deve bloquear a recalibração.

---

## 5. Testes de regressão obrigatórios

1. Semana atual com dois treinos concluídos + um treino futuro + uma prova: frequência futura não pode contar os dois concluídos.
2. Semana atual com três treinos concluídos e nenhuma sessão futura: não pode bloquear por excesso de frequência.
3. Treino concluído no mesmo dia de prova futura: não gerar conflito futuro baseado em sessão já concluída.
4. Treino e prova no mesmo dia, ambos pendentes: gerar conflito explícito e contar um dia, não dois.
5. Semana parcial com apenas o longão restante de 6 km: não classificar 6/6 como 100% de uma semana completa.
6. Semana parcial com dias iniciais já realizados e volume histórico disponível: usar volume semanal integral, sem duplicar sessões concluídas.
7. Semana futura completa de três dias com 6 + 5 + 5 km: aprovar (longão = 37,5%).
8. Semana futura com 6,8 + 5,1 km e sem terceiro compromisso: bloquear e reportar sessão/volume faltante; não aceitar 57,1%.
9. Semana futura com duas sessões + uma prova substituta: contar a prova exatamente uma vez no total e na frequência.
10. Prova curta no dia do longão: preservar o longão e substituir uma sessão compatível.
11. Prova curta em outro dia: substituir uma sessão não-longão, mantendo o total semanal <= 40%.
12. Prova com status `COMPLETED` ou `CANCELLED`: não deve ser contada como compromisso futuro.
13. Evento com distância inválida legado: informar dado inválido e não criar silenciosamente volume zero.
14. Sessão opcional extra pendente: não aumentar frequência principal; política de carga deve ser explícita e sem duplicação.
15. Duas sessões com mesmo `sessionId` em semanas diferentes: não deduplicar instâncias distintas.
16. Reagendamento manual para slot liberado: não duplicar sessão original nem deslocada.
17. Backup do motor 83 recalibrado no motor 89: preservar concluídos e atualizar somente futuro sem contar concluídos como compromissos.
18. Criação de plano do zero na quinta-feira, 26/11: semana parcial não pode gerar falso bloqueio de 100%.
19. Criar plano com três dias disponíveis e semana futura: a composição final deve manter três compromissos incluindo prova substituta, salvo fase com redução explicitamente prevista.
20. O teto de 40%, a dominância do longão e o piso de 5 km nas semanas normais de objetivo 5 km continuam obrigatórios.
21. Semana Regenerativa e protocolo inicial caminhada/corrida continuam respeitando suas exceções aprovadas.
22. Reschedule validation deve usar `today` injetável e as mesmas regras de semana parcial.
23. Nenhum erro de validação pode sobrescrever o plano/backup anterior.
24. O log semanal deve explicar exatamente o denominador usado no percentual.

### Casos numéricos que devem ser reproduzidos

| Caso | Entradas | Resultado esperado |
|---|---|---|
| Semana parcial | longão restante 6,0 km; demais dias já passados | não bloquear por 100% sobre saldo parcial |
| Semana completa normal | 6 + 5 + 5 km | aprovar; 37,5% |
| Semana incompleta futura | 6,8 + 5,1 km | bloquear; 57,1%, indicar a composição faltante |
| Frequência atual | 2 concluídos + 1 futuro + 1 prova | contar 2 dias futuros, não 4 compromissos |

---

## 6. Critérios de aprovação V99

- Nenhum treino concluído conta como compromisso futuro.
- A frequência semanal é calculada por dia distinto.
- Semana parcial não recebe validação percentual de semana completa com denominador truncado.
- Semana futura completa não pode passar com longão > 40%.
- Prova substitui uma sessão exatamente uma vez.
- O plano não perde sessão durante prova, merge, reagendamento ou migração.
- O erro de composição da semana de 07/12 é reproduzido por teste e explicado pelo log.
- Backup restaurado permanece intacto se uma semana futura real continuar inválida.
- Schema 13 e leitura de schemas 1–13 preservados.
- Gradle/JUnit, APK e workflow GitHub Actions aprovados; teste final no Android 16.

## 7. Parecer final

As mensagens da V98 não são apenas problemas de texto. O validador está usando a mesma lista para compromissos futuros, conflitos de calendário e volume semanal, embora cada cálculo precise de dados diferentes.

A falha de frequência da semana 23/11 tem causa direta e confirmada: sessões concluídas não são excluídas. A falha de 100% na semana atual é compatível com a validação de uma semana parcial usando apenas sessões remanescentes. A falha de 57,1% na semana futura é um problema real na composição que chega ao validador; a causa exata da sessão/volume ausente precisa ser identificada pelo log detalhado e pelo JSON do backup, não presumida.

**Recomendação:** aplicar as três correções em conjunto na V99. Não retirar o teto de 40%, não recalcular a carga do atleta a partir de uma semana incompleta e não contar treinos concluídos como compromissos futuros.

**Status:** auditoria da V98 concluída; plano V99 elaborado; implementação ainda não realizada.
