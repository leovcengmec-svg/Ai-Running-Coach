# Compatibilidade das recuperações — V88

## Política única
- Recuperação ativa em Z2: 0–20% da Z2 individual.
- Trabalho aeróbio/variação em Z2: normalmente 20–65%, conforme o protocolo.
- O percentual indica posição dentro da zona (0 = mais lento; 100 = mais rápido), não VO₂máx ou frequência cardíaca.
- Recuperação em Z2 deve ser nitidamente mais fácil do que o bloco de trabalho Z2 anterior. Em esforços Z3/Z4, a recuperação Z2 permanece em faixa aeróbia fácil.
- Fartlek F01/F02/F04 usa recuperação Z2 0–20%; F01 mantém 2 minutos entre variações, sem recuperação após o último esforço. F02/F04 mantêm sua duração definida pelo protocolo.
- Caminhada e pausa passiva só são mantidas quando intencionais ou justificadas pelo protocolo/prontidão/segurança; não são fallback automático para incompatibilidade com aquecimento/desaquecimento.

## Migração
- Apenas sessões pendentes de biblioteca Fartlek/progressão são normalizadas.
- Fartlek legado com recuperação ACTIVE_Z2 20–65% passa para 0–20%, com pace/distância recalculados pelo snapshot individual e duração preservada (F01 = 2 min).
- Recuperações V84 automaticamente convertidas em WALK são restauradas apenas quando identificadas pelos dois textos de fallback conhecidos; caminhadas intencionais ficam intactas.
- Progressões salvas que repetem a faixa do aquecimento recebem as faixas de V88.
- Sessões concluídas, feedbacks e atividades históricas não são alterados. A migração é idempotente.
- Sem snapshot de calibração válido, as bandas semânticas são atualizadas, mas o pace numérico legado é removido até nova calibração.

## Bandas de progressão
- Progressão Z2-only: aquecimento 0–20%; trabalho 20–40% e 40–65%; desaquecimento 0–20%.
- Progressão Z2→Z3 elegível: trabalho Z2 20–40%, depois 40–65%, final de entrada Z3 0–20%. A elegibilidade Z3 permanece inalterada.
- Regressão Z2-only: 40–65% e depois 20–40%; aquecimento/desaquecimento mantêm faixas de transição próprias.
- Regressão Z3→Z2 elegível: entrada Z3 0–20%, Z2 40–65%, Z2 20–40%.
- Sessões curtas demais para dividir em blocos mantêm um único bloco contínuo; não são criadas etapas artificiais.
