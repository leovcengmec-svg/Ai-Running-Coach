# Build Status — AI Running Coach V100

- VersionCode: **100**
- VersionName: **V100**
- CURRENT_ENGINE_VERSION: **90**
- Backup Schema: **13** (mantido; leitura schemas 1–13)
- Base: **V99**

## Concluído

- Correção do orçamento de distância de retestes pendentes: snapshot da sessão substituída ou fallback por estimativa completa dos protocolos elegíveis.
- Comparação exata do teto de 40%; 40,0% é aceito e somente valores acima são bloqueados.
- Reteste pendente sem dados suficientes continua na agenda e não é transformado em 0 km nem recebe orçamento genérico.
- Grade mensal dinâmica com 4/5/6 linhas, semana iniciada na segunda-feira e células de 68 dp.
- Códigos canônicos REG/ROD/INT/FAR/LIM/LNG/PRV/TST na grade e legenda; títulos extensos saem das células.
- Agenda do dia/semana usa linhas compactas e preserva detalhes completos ao abrir a sessão.
- Harness isolado: **34 testes aprovados, 0 falhas**.
- Verificação sintática estática de MainActivity: nenhum diagnóstico de sintaxe encontrado; compilação completa depende do classpath Android/Compose.
- ZIP validado com `unzip -t`.

## Pendente

- Executar a suíte Gradle/JUnit oficial: `gradle -p android :app:testDebugUnitTest :app:assembleDebug --no-daemon` no GitHub Actions.
- Instalar e inspecionar o APK no Android 16, incluindo largura estreita e escala de fonte ampliada.

**Não declarar APK certificado antes do workflow Android terminar verde.**
