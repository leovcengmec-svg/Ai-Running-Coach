# Build Status — AI Running Coach V100

- VersionCode: 100
- VersionName: V100
- CURRENT_ENGINE_VERSION: 90
- Backup Schema: 14 (schemas 1–13 legíveis)
- Base de origem: AI Running Coach V99
- ZIP final: criado em `ai_running_coach_v100/AI-Running-Coach.zip`; `unzip -t` sem erros e 12 verificações de conteúdo/versionamento aprovadas.

## Ambiente local

- Kotlin compiler disponível: 1.9.0.
- Harness principal de calendário/distribuição/taxonomia: PASS.
- Harness de ciclo/recuperação de janela: PASS.
- Gradle: não instalado.
- Gradle Wrapper: ausente no ZIP de origem.
- Android SDK: não instalado.
- APK: não gerado neste ambiente.

## GitHub Actions

O workflow `.github/workflows/android.yml` executa:

`gradle -p android :app:testDebugUnitTest :app:assembleDebug --no-daemon`

O workflow `release-apk.yml` permite build release manual. A certificação Android/JUnit permanece pendente de execução no GitHub Actions.
