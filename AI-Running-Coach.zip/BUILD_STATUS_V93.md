# Build Status — AI Running Coach V93

- Base: AI Running Coach V92.
- `versionCode = 93` · `versionName = V93`.
- `CURRENT_ENGINE_VERSION = 83` (V92 Android source set continha 82; a documentação anterior registrava 81).
- Backup Schema 8; decoder mantém leitura dos schemas 1–7.
- Histórico: ID estável, edição de dados, vínculo manual seguro, soft-delete, restauração e exclusão definitiva em duas etapas.
- Calibração: contribuição direta de até 5% por zona de origem; cascata Z3→Z2→Z1 e Z2→Z1; máximos efetivos Z1=15%, Z2=10%, Z3=5%; reset após teste válido.
- Segurança: Z4/Z5 preservadas; largura mínima de 10 segundos por faixa adaptativa.
- Reteste: revisão de evidências em 28 dias; janela preferencial de teste entre dias 49–56, substituindo sessão intensa elegível.
- Harness Kotlin/JVM de calibração/identidade executado: PASS.
- JUnit/Gradle, compilação Android/Compose e APK: pendentes do GitHub Actions.

Workflow: `.github/workflows/android.yml`.

## Correção de compilação — 2026-11-23

- Corrigido `MainActivity.kt:1553` e `:1557`: removidas referências inválidas `List.first`/`List.last` tratadas como propriedades.
- A extração da chave canônica agora passa por `SessionIdentityEngine.parseCanonicalSlotKey()`.
- Testes JUnit de parsing foram adicionados.
- Compilação Kotlin/JVM focalizada da função de candidatos: PASS; harness principal V93: PASS.
- Gradle/JUnit completo, `:app:compileDebugKotlin`, `:app:assembleDebug` e APK continuam pendentes do GitHub Actions.
- Identificação permanece VersionCode 93 / VersionName V93.
