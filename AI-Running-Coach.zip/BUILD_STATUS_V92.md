# Status de build — AI Running Coach V92

- Base: AI Running Coach V91.
- `versionCode = 92` · `versionName = V92`.
- `CURRENT_ENGINE_VERSION = 81`.
- Backup Schema 7; decoder mantém leitura dos schemas 1–6.
- Escopo aplicado: calendário/ícones, duas alternativas de sessão, atualização de volumes após alternativa, remoção de duplicações na Evolução, reconciliação de feedbacks de backup e evidência de carga.
- Harnesses Kotlin/JVM focados de calendário/status/identidade/carga/alternativas: aprovados.
- Testes JUnit de backup, calendário, carga e alternativas: adicionados/atualizados, mas não executados pela suíte Gradle neste ambiente.
- `:app:testDebugUnitTest`, `:app:compileDebugKotlin` e `:app:assembleDebug` pendentes do GitHub Actions.
- Este pacote não contém APK e não deve ser descrito como APK aprovado até o workflow `build-apk` finalizar verde.

Workflow: `.github/workflows/android.yml` (JDK 21, Gradle 9.6; executa `gradle -p android :app:testDebugUnitTest :app:assembleDebug --no-daemon`).
