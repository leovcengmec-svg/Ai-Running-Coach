# Build e validação — AI Running Coach V76

## Identificação
- `versionCode = 76`
- `versionName = V76`
- `CURRENT_ENGINE_VERSION = 66`
- Backup Schema 3; leitura de schemas 1–3 preservada.
- `appVersion = V76` nos novos backups.

## Implementações
- Faixas percentuais ativas de qualquer largura válida (`0–100%`) dentro da zona, com interpretação 0% = limite mais lento e 100% = limite mais rápido.
- Corredores com seis meses ou mais de experiência: aquecimento e desaquecimento ajustados para Z2 0–20%, a partir da calibração individual disponível.
- Recuperação passiva normalizada para tempo, sem distância ou ritmo-alvo; caminhada não recebe pace; recuperação ativa Z2 usa 0–20%.
- Protocolos explícitos usam pausa parada para trabalho Z5, caminhada para Z4 e recuperação ativa Z2 para trabalho de menor intensidade, respeitando os tipos de segmento.
- Alternativas preservam estímulo e dose em atletas sem sinal relevante de baixa prontidão; progressões mantêm ordem, distância, zonas e etapas. Redução de exigência é usada quando o indicador de recuperação/saúde não permite manter qualidade.
- Exportação de treino recebe os limites de pace já calculados pelas faixas; blocos passivos e caminhadas são exportados sem alvo de ritmo.
- Restauração completa de backup oferece escolha explícita de recalibração pelo motor atual ou manutenção do plano importado. Recalibração atualiza o ciclo futuro e preserva sessões concluídas, feedbacks, atividades e datas reais.
- Backup Schema 3 mantido; schemas antigos 1–3 continuam legíveis.
- FC/FCM não participa de calibração, prescrição, zonas, prontidão, carga, alternativas ou análise.

## Verificações executadas
- Compilação dos módulos Kotlin/JVM de domínio com `kotlinc` (stub temporário para o modelo `Workout`, dependente da interface Android): aprovada, com warnings não bloqueantes.
- Testes direcionados executados em runner local com stub de JUnit: `PASS=26`, `FAIL=0`. Cobrem `ZoneIntensityBandEngineTest`, `WorkoutAlternativeEngineTest` e os novos testes de transição de experiência do `CoachEngineTest`.
- Harness de geração real do treinador: 32 sessões geradas; aquecimento e desaquecimento de corredor experiente apareceram em Z2 0–20%, com pace individualizado quando há snapshot de calibração.
- Teste ampliado de `CoachEngineTest` via runner local apresentou 21 falhas em V76; a mesma lista de 21 falhas já ocorria na base V75. V76 teve 46 aprovações e as mesmas 21 falhas legadas. Elas não foram ocultadas nem consideradas aprovadas; precisam ser reconciliadas no conjunto de regressão.
- ZIP final verificado com `unzip -t` e contagem de arquivos conferida após remover ferramentas e stubs temporários.

## Limitações
- Runner local usa stub leve de JUnit; não substitui a suíte oficial Gradle/JUnit.
- Suíte JUnit completa via Gradle não executada.
- `MainActivity.kt`, `AppBackupManager.kt` e `PaceCoachExporter.kt` dependem de Android/Compose/JSON e não foram compilados isoladamente neste ambiente.
- Build Android/Compose e APK não executados: ambiente sem Gradle Wrapper/CLI e Android SDK.
- Fluxos de restauração e exportação precisam da validação final no GitHub Actions e em aparelho.

## Aceitação no aparelho
1. Corredor com 6+ meses: aquecimento e desaquecimento em Z2 0–20% com pace coerente com a calibração.
2. Perfil iniciante/sem histórico: não receber automaticamente a regra de transição de corredor experiente.
3. Aplicar faixas como Z2 50–80%, Z2 80–100% e Z3 0–20% e confirmar pace correto.
4. Recuperação PASSIVE: tempo, sem pace e sem distância; WALK: sem pace; ACTIVE_Z2: faixa Z2 0–20%.
5. Trocar sessão de VO₂/limiar/progressiva com recuperação boa: preservar propósito e dose.
6. Trocar sessão com recuperação ruim: reduzir exigência de forma identificada.
7. Restaurar backup V71/V72/V73/V74/V75: exibir diálogo de recalibração; verificar preservação do histórico.
8. Confirmar que novos backups identificam V76 e continuam Schema 3.
