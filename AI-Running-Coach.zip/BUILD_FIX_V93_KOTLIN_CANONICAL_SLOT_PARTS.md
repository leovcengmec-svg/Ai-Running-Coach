# Build Fix — V93 — parser da chave canônica do histórico

## Erro observado no GitHub Actions

O workflow `build-apk` falhou em `:app:compileDebugKotlin` com:

- `MainActivity.kt:1553:44 Function invocation 'first()' expected.`
- `MainActivity.kt:1557:72 Function invocation 'last()' expected.`

## Causa

`historyLinkCandidates()` tratava `List<String>.first` e `List<String>.last` como propriedades. Em Kotlin, `first` e `last` nesse contexto são funções de extensão e precisam ser invocadas; a expressão não compilava.

## Correção aplicada

- Foi adicionado `SessionIdentityEngine.parseCanonicalSlotKey()` para interpretar a chave canônica persistida (`dataIso|type`) de forma tipada e validada.
- A função usa `split('|', limit = 2)`, rejeita componentes vazios e preserva o restante do tipo quando há separador legado.
- `MainActivity.historyLinkCandidates()` agora usa `dateIso` e `type` do resultado, sem referências ambíguas a `first`/`last`.
- Foram adicionados testes JUnit para chave válida, chave incompleta, componentes vazios e preservação do restante do tipo.

## Validação executada neste ambiente

1. Compilação Kotlin/JVM de `SessionIdentityEngine.kt` com a função de seleção de candidatos equivalente e execução de cenários: **PASS**.
2. Reexecução do harness principal `validation/V93Harness.kt`: **PASS**.
3. Verificação estática: as referências inválidas `persistedSlot?.first` e `persistedSlot?.last` foram removidas do source set Android.
4. Integridade do ZIP: validada após a geração do pacote.

## Limitação

A compilação completa Android/Compose, a suíte JUnit via Gradle e a geração do APK não foram executadas neste ambiente, pois não há Gradle/Android SDK instalados. O workflow `build-apk` no GitHub Actions ainda precisa ser executado para confirmar o APK.

A identificação do produto permanece `VersionCode 93` / `VersionName V93`; este pacote é uma correção de compilação da V93, não uma nova versão funcional.
