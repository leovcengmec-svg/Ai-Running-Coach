# Build status — AI Running Coach V88

- VersionCode: 88
- VersionName: V88
- CURRENT_ENGINE_VERSION: 77
- Backup Schema: 4

## Alterações
- Recuperação ativa Z2 unificada em 0–20%; Fartlek F01/F02/F04 mantém trabalho Z2 em 20–65% e recuperação em 0–20%.
- F01 preserva 2 minutos entre variações; F02/F04 preservam a duração definida pelo protocolo.
- Distâncias estimadas dos blocos Fartlek são reequilibradas após normalização das recuperações, sem inflar o volume total planejado.
- Longões e rodagens progressivas/regressivas diferenciam aquecimento e blocos principais, respeitando os gates de elegibilidade Z3.
- Migração idempotente atualiza apenas sessões pendentes, preservando histórico concluído, feedbacks, caminhadas intencionais e pausas passivas.
- Auditoria semântica e testes de regressão expandidos.

## Validação executada
- Compilação Kotlin/JVM dos 48 arquivos de domínio: aprovada (warnings existentes, sem erros). A UI Android/Compose e classes de backup/export Android foram excluídas do harness isolado.
- Testes focados de `ZoneIntensityBandEngineTest`, `CoachEngineTest` e `TrainingPrescriptionAuditTest`: 71 aprovados de 73; 2 falhas restantes são testes de corrida/caminhada para iniciantes e reproduzem o mesmo resultado na base V87 original.
- Em comparação, a V87 original apresentava também falhas nos testes de reconciliação de distância Fartlek; esses cenários agora passam na V88.
- O novo teste de migração de caminhada automática V84 para recuperação ativa Z2 passou, incluindo preservação do volume da sessão, histórico concluído e idempotência.
- A matriz completa Gradle ainda não foi executada.

## Pendências de validação
- `:app:testDebugUnitTest`: pendente no GitHub Actions.
- `:app:assembleDebug`: pendente no GitHub Actions.
- Teste funcional em aparelho: pendente.

Este pacote não deve ser considerado APK aprovado até que a suíte Gradle e a compilação Android concluam com sucesso.
