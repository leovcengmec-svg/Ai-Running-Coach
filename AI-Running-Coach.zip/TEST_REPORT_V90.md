# Relatório de testes — V90

**Data:** 23/11/2026  
**Base:** V89  
**VersionCode:** 90 • **VersionName:** V90 • **Engine:** 79 • **Backup:** Schema 5

## Casos adicionados/atualizados

- RPE alto isolado e tendência de carga acima de 1,35: passo moderado de 2%, com aumento acima da semana de base.
- Dois ou mais avisos moderados: passo de 1%.
- Recuperação <50 ou fadiga ≥75: progressão bloqueada e motivo explícito.
- Perfil 5 km/base 16 km: progressão de 16,0 → 16,3 → 16,6 km nas semanas de construção, preservando o deload e respeitando o teto 22,5 km.
- Calendário: oito categorias a partir do tipo/estímulo estruturado.
- Status: concluído, atrasado e pendente (hoje/futuro).
- Compatibilidade: schema4 gerado como V89 continua legível na V90.
- Gráfico e cards: ambos consomem `WeeklyVolumeSummary` para os totais semanais.

## Execução

A execução Gradle/JUnit oficial e o build Android não foram realizados porque o ambiente não possui Gradle CLI/Wrapper nem Android SDK. Os testes estão incluídos no código e devem ser executados no GitHub Actions (`:app:testDebugUnitTest` e `:app:assembleDebug`). Este relatório não declara a suíte completa aprovada.
