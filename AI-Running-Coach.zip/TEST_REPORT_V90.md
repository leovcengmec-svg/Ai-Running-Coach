# Relatório de testes — V90

**Data:** 23/11/2026  
**Base:** V89  
**VersionCode:** 90 • **VersionName:** V90 • **Engine:** 79 • **Backup:** Schema 5

## Casos adicionados/atualizados

- RPE alto isolado e tendência de carga acima de 1,35: passo moderado de 2%, com aumento acima da semana de base.
- Dois ou mais avisos moderados: passo de 1%.
- Recuperação <50 ou fadiga ≥75: progressão bloqueada e motivo explícito.
- Perfil 5 km/base 16 km: progressão de 16,0 → 16,3 → 16,6 km nas semanas de construção, preservando o deload e respeitando o teto 22,5 km.
- Calendário: oito categorias a partir do tipo/estímulo estruturado.
- Status: concluído, atrasado e pendente (hoje/futuro).
- Compatibilidade: schema4 gerado como V89 continua legível na V90.
- Gráfico e cards: ambos consomem `WeeklyVolumeSummary` para os totais semanais.

## Execução

A execução Gradle/JUnit oficial e o build Android não foram realizados porque o ambiente não possui Gradle CLI/Wrapper nem Android SDK. Os testes estão incluídos no código e devem ser executados no GitHub Actions (`:app:testDebugUnitTest` e `:app:assembleDebug`). Este relatório não declara a suíte completa aprovada.

## Correção posterior — build Android Kotlin

- Log do GitHub Actions analisado: quatro erros `Unresolved reference: rememberZoneBoundaries` em `android/app/src/main/java/com/airunningcoach/app/MainActivity.kt`.
- Causa: a função existia na cópia de referência da raiz, mas não no source set Android compilado pelo Gradle.
- Correção: helper privado adicionado à classe `CoachState` no arquivo Android; as quatro chamadas foram preservadas.
- Harnesses JVM disponíveis nesta sessão executados novamente: carga 1/1, calendário 1/1 e volume semanal 1/1 aprovados.
- Verificação estática confirmou uma definição e quatro chamadas no arquivo Android.
- A suíte `:app:testDebugUnitTest` e `:app:assembleDebug` não puderam ser executadas neste ambiente, pois não há Gradle CLI/Wrapper nem Android SDK instalados. A confirmação final da compilação segue pendente do GitHub Actions.
