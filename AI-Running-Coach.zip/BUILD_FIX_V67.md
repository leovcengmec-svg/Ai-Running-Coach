# Correção do build Android — V67

## Falha observada no GitHub Actions

A compilação `:app:compileDebugKotlin` falhou em `MainActivity.kt` na expressão que apresenta `InfoRow("Último teste", latestTest?.let { ... })`.

## Causa

`latestTest` estava declarado localmente dentro de `ProfileScreen`, mas era referenciado em outro composable (painel de monitoramento / calibração). Variáveis locais de um composable não são visíveis fora daquele escopo.

## Correção

Foi declarado no escopo do composable que renderiza o painel de zonas:

```kotlin
val latestTest = state.cooperAssessments.maxByOrNull { it.dateIso }
```

A expressão `latestTest?.let { ... } ?: "Não realizado"` retorna `String`, compatível com `InfoRow(label: String, value: String)`. Os erros de inferência de `T` e `R` reportados na mesma linha eram consequências da referência não resolvida.

## Versionamento

- `versionCode = 67`
- `versionName = V67`
- `engineVersion = 53` (sem alteração de regras de prescrição)
- Backup Schema = 2
- Backup `appVersion = V67`

## CI obrigatório

```bash
gradle -p android :app:testDebugUnitTest :app:assembleDebug --no-daemon
```

A aprovação do APK depende da execução bem-sucedida dessa etapa no GitHub Actions.
