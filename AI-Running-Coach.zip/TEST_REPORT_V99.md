# Test Report — AI Running Coach V99

- VersionCode 99 · VersionName V99 · motor 89 · Backup Schema 13 (leitura 1–13).

## Testes do validador de calendário

**23/23 métodos de `TrainingCalendarIntegrityEngineTest.kt` executados e aprovados** com compilação Kotlin/JVM local e runner que usa somente a API mínima de annotation/assert do JUnit. Isso testa o código do motor e dos casos, mas não substitui a execução pelo JUnit oficial do Gradle.

A cobertura inclui: contagem por datas distintas; exclusão de concluídos da frequência futura; conflito pendente de treino/prova; semana atual parcial; carga integral quando há evidência completa; limite de 40% em semana futura; distribuição 6+5+5; provas concluídas/canceladas; sessões duplicadas; distâncias/datas inválidas; reteste sem protocolo como compromisso com distância pendente; Cooper/3 km selecionado usando a distância real.

`RaceEventEngineTest.kt` também recebeu um caso adicional para não contar treino e prova na mesma data como dois dias de frequência. Esse caso aguarda execução no JUnit oficial.

## Verificações estáticas

- versionCode/name e motor conferidos no source.
- schema 13 preservado; novo JSON de backup identifica V99.
- Apenas V99 no manifesto atual do Android; source set localizado em `android/app/src/main/java`.
- ZIP submetido a `unzip -t` e comparação de hashes dos arquivos críticos.

## Não executado

O ambiente não possui Gradle, `gradlew`, Android SDK nem dependências JUnit baixadas. Portanto, `:app:testDebugUnitTest`, compilação Compose, APK e teste no Android 16 não foram executados. A validação oficial permanece dependente do workflow GitHub Actions.
