package com.airunningcoach.app

import java.time.LocalDate
import kotlin.math.roundToInt

/** A single execution occurrence expanded from the immutable session prescription. */
internal data class PrescribedWorkoutBlock(
    val key: String,
    val segmentIndex: Int,
    val repetition: Int,
    val segment: WorkoutSegment
)

/** Manually recorded pace for one prescribed block. The target is frozen with the record. */
internal data class WorkoutBlockPaceFeedback(
    val blockKey: String,
    val segmentIndex: Int,
    val repetition: Int,
    val segmentName: String,
    val targetZone: String?,
    val targetFastestPaceSecondsPerKm: Int?,
    val targetSlowestPaceSecondsPerKm: Int?,
    val actualPaceSecondsPerKm: Int?,
    val targetMode: String,
    val recoveryMode: String? = null
)

internal data class WorkoutBlockComparison(
    val feedback: WorkoutBlockPaceFeedback,
    val status: String,
    /** Negative means faster than the prescribed range; positive means slower. */
    val differenceSecondsPerKm: Int?
)

internal data class ZoneExecutionObservation(
    val sessionId: String,
    val dateIso: String,
    val zone: String,
    val actualPaceSecondsPerKm: Int,
    val targetFastestPaceSecondsPerKm: Int,
    val targetSlowestPaceSecondsPerKm: Int,
    val effort: String,
    val feeling: String,
    val painPresent: Boolean,
    /** Position in the prescribed block sequence, used to detect within-session pace drift. */
    val sequenceOrder: Int = 0
)

internal data class ZoneExecutionSummary(
    val zone: String,
    val observationCount: Int,
    val sessionCount: Int,
    val fasterCount: Int,
    val preciseCount: Int,
    val slowerCount: Int,
    val meanActualPaceSecondsPerKm: Int,
    val meanTargetPaceSecondsPerKm: Int,
    val sessionsWithFastStartFade: Int,
    val sessionsWithPaceFade: Int,
    val sessionsWithPaceAcceleration: Int,
    val sessionsWithStablePacing: Int,
    val confidence: String,
    val interpretation: String
)

/**
 * Converts compact repeatCount prescriptions into the actual sequence seen by the runner.
 * A repeated work segment followed by a repeated recovery segment is interleaved by lap.
 */
internal object WorkoutBlockFeedbackEngine {
    const val FASTER = "FASTER_THAN_TARGET"
    const val PRECISE = "WITHIN_TARGET"
    const val SLOWER = "SLOWER_THAN_TARGET"
    const val NO_TARGET = "NO_PACE_TARGET"
    const val NO_DATA = "NO_DATA"

    fun expand(segments: List<WorkoutSegment>): List<PrescribedWorkoutBlock> {
        if (segments.isEmpty()) return emptyList()
        val expanded = mutableListOf<PrescribedWorkoutBlock>()
        fun append(index: Int, repetition: Int) {
            val segment = segments[index]
            expanded += PrescribedWorkoutBlock(
                key = "s${index}_r$repetition",
                segmentIndex = index,
                repetition = repetition,
                segment = segment
            )
        }
        var index = 0
        while (index < segments.size) {
            val current = segments[index]
            val next = segments.getOrNull(index + 1)
            val pairedRepeat = current.repeatCount > 1 && next != null &&
                next.repeatCount == current.repeatCount && (isRecovery(current) || isRecovery(next))
            if (pairedRepeat) {
                for (repetition in 1..current.repeatCount) {
                    append(index, repetition)
                    append(index + 1, repetition)
                }
                index += 2
            } else {
                for (repetition in 1..current.repeatCount) append(index, repetition)
                index += 1
            }
        }
        return expanded
    }

    fun requiresPaceInput(block: PrescribedWorkoutBlock): Boolean {
        val segment = block.segment
        if (segment.recoveryMode in setOf("PASSIVE", "WALK")) return false
        val name = segment.name.trim().lowercase()
        if (segment.recoveryMode == null && (name.contains("caminhad") || name.contains("pausa parada"))) return false
        return true
    }

    fun from(block: PrescribedWorkoutBlock, actualPace: Int?): WorkoutBlockPaceFeedback {
        val segment = block.segment
        return WorkoutBlockPaceFeedback(
            blockKey = block.key,
            segmentIndex = block.segmentIndex,
            repetition = block.repetition,
            segmentName = segment.name,
            targetZone = segment.paceZone,
            targetFastestPaceSecondsPerKm = segment.targetPaceMinValue,
            targetSlowestPaceSecondsPerKm = segment.targetPaceMaxValue,
            actualPaceSecondsPerKm = actualPace,
            targetMode = segment.targetMode,
            recoveryMode = segment.recoveryMode
        )
    }

    fun compare(feedback: WorkoutBlockPaceFeedback): WorkoutBlockComparison {
        val actual = feedback.actualPaceSecondsPerKm
        val fastest = feedback.targetFastestPaceSecondsPerKm
        val slowest = feedback.targetSlowestPaceSecondsPerKm
        if (actual == null) return WorkoutBlockComparison(feedback, NO_DATA, null)
        if (fastest == null || slowest == null) return WorkoutBlockComparison(feedback, NO_TARGET, null)
        return when {
            actual < fastest -> WorkoutBlockComparison(feedback, FASTER, actual - fastest)
            actual > slowest -> WorkoutBlockComparison(feedback, SLOWER, actual - slowest)
            else -> WorkoutBlockComparison(feedback, PRECISE, 0)
        }
    }

    fun summary(observations: List<ZoneExecutionObservation>): List<ZoneExecutionSummary> {
        val valid = observations.filter { item ->
            item.zone.uppercase() in setOf("Z1", "Z2", "Z3", "Z4", "Z5") &&
                item.actualPaceSecondsPerKm in 120..1800 &&
                item.targetFastestPaceSecondsPerKm in 120..1800 &&
                item.targetSlowestPaceSecondsPerKm in 120..1800 &&
                item.targetSlowestPaceSecondsPerKm >= item.targetFastestPaceSecondsPerKm &&
                !item.painPresent && runCatching { LocalDate.parse(item.dateIso) }.isSuccess
        }
        return (1..5).mapNotNull { zoneIndex ->
            val zone = "Z$zoneIndex"
            val items = valid.filter { it.zone.equals(zone, ignoreCase = true) }
            if (items.isEmpty()) return@mapNotNull null
            val statuses = items.map { item ->
                compare(WorkoutBlockPaceFeedback(
                    blockKey = "", segmentIndex = 0, repetition = 1, segmentName = "",
                    targetZone = zone,
                    targetFastestPaceSecondsPerKm = item.targetFastestPaceSecondsPerKm,
                    targetSlowestPaceSecondsPerKm = item.targetSlowestPaceSecondsPerKm,
                    actualPaceSecondsPerKm = item.actualPaceSecondsPerKm,
                    targetMode = "TIME"
                )).status
            }
            val faster = statuses.count { it == FASTER }
            val precise = statuses.count { it == PRECISE }
            val slower = statuses.count { it == SLOWER }
            val sessions = items.map { it.sessionId }.distinct().size
            val meanActual = items.map { it.actualPaceSecondsPerKm }.average().roundToInt()
            val meanTarget = items.map { (it.targetFastestPaceSecondsPerKm + it.targetSlowestPaceSecondsPerKm) / 2.0 }.average().roundToInt()
            val easierFeeling = items.count { it.effort in setOf("Muito leve", "Leve", "Ok") && it.feeling in setOf("Ótimo", "Bem") }
            val hardFeeling = items.count { it.effort in setOf("Pesado", "Muito pesado") || it.feeling in setOf("Cansado", "Muito cansado") }
            val highEvidence = items.size >= 5 && sessions >= 3
            val fasterShare = faster.toDouble() / items.size
            val slowerShare = slower.toDouble() / items.size
            // Compare pace deviation from each block's own target midpoint, not raw pace,
            // so slightly different prescribed ranges can still be assessed fairly.
            data class SessionDrift(val delta: Double, val earlyDeviation: Double, val lateDeviation: Double)
            val sessionPatterns = items.groupBy { it.sessionId }.values.mapNotNull sessionPattern@{ sessionItems ->
                val ordered = sessionItems.sortedBy { it.sequenceOrder }
                if (ordered.size < 3) return@sessionPattern null
                val third = (ordered.size / 3.0).let { kotlin.math.ceil(it).toInt().coerceAtLeast(1) }
                fun deviation(item: ZoneExecutionObservation) = item.actualPaceSecondsPerKm -
                    (item.targetFastestPaceSecondsPerKm + item.targetSlowestPaceSecondsPerKm) / 2.0
                val early = ordered.take(third).map(::deviation).average()
                val late = ordered.takeLast(third).map(::deviation).average()
                SessionDrift(late - early, early, late)
            }
            val fastStartFadeSessions = sessionPatterns.count { it.earlyDeviation <= -15.0 && it.lateDeviation >= 15.0 }
            val fadeSessions = sessionPatterns.count { it.delta >= 15.0 }
            val accelerationSessions = sessionPatterns.count { it.delta <= -15.0 }
            val stableSessions = sessionPatterns.count { kotlin.math.abs(it.delta) < 15.0 }
            val interpretation = when {
                !highEvidence -> "Evidências iniciais; ainda não ajustar a zona."
                slowerShare >= 0.70 && hardFeeling >= items.size / 2.0 -> "Execuções frequentemente mais lentas com esforço elevado; revisar carga e adequação da faixa antes de progredir."
                fasterShare >= 0.70 && easierFeeling >= items.size / 2.0 -> "Execuções frequentemente mais rápidas com esforço controlado; candidata a revisão da faixa em avaliação assistida."
                fadeSessions > 0 -> "Há queda de ritmo nos blocos finais em $fadeSessions sessão(ões)" +
                    if (fastStartFadeSessions > 0) "; início acima da velocidade-alvo seguido de queda em $fastStartFadeSessions sessão(ões); revisar largada, recuperação e carga." else "; revisar recuperação e carga."
                accelerationSessions > 0 -> "O ritmo foi acelerado ao longo dos blocos em $accelerationSessions sessão(ões); verificar se o início foi conservador e o estímulo permaneceu adequado."
                else -> "Execução variável ou próxima da faixa; manter observação e comparar sessões equivalentes."
            }
            ZoneExecutionSummary(
                zone = zone,
                observationCount = items.size,
                sessionCount = sessions,
                fasterCount = faster,
                preciseCount = precise,
                slowerCount = slower,
                meanActualPaceSecondsPerKm = meanActual,
                meanTargetPaceSecondsPerKm = meanTarget,
                sessionsWithFastStartFade = fastStartFadeSessions,
                sessionsWithPaceFade = fadeSessions,
                sessionsWithPaceAcceleration = accelerationSessions,
                sessionsWithStablePacing = stableSessions,
                confidence = if (highEvidence) "Evidência acumulada" else "Em observação",
                interpretation = interpretation
            )
        }
    }

    private fun isRecovery(segment: WorkoutSegment): Boolean {
        if (segment.recoveryMode != null) return true
        val normalized = segment.name.trim().lowercase()
        return normalized.contains("recuper") || normalized.contains("pausa")
    }
}
