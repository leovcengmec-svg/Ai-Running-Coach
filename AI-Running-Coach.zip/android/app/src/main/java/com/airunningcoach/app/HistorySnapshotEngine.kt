package com.airunningcoach.app

import java.time.LocalDate
import java.time.ZoneId

/**
 * Immutable, pre-linked view of the workout history. Build this only when the source
 * workout/feedback collections change; period filters operate on this snapshot.
 */
internal object HistorySnapshotEngine {
    internal data class WorkoutEntry(
        val stableKey: String,
        val workout: Workout,
        val feedback: FeedbackRecord?,
        val activityDate: LocalDate
    )

    internal data class FeedbackEntry(
        val stableKey: String,
        val record: FeedbackRecord,
        val activityDate: LocalDate
    )

    internal data class Snapshot(
        val completed: List<WorkoutEntry>,
        val orphaned: List<FeedbackEntry>,
        val deleted: List<FeedbackEntry>
    ) {
        companion object {
            fun empty() = Snapshot(emptyList(), emptyList(), emptyList())
        }
    }

    internal data class Summary(
        val sessionCount: Int,
        val measuredDistanceKm: Double,
        val measuredDurationSeconds: Int
    ) {
        val durationLabel: String
            get() = if (measuredDurationSeconds >= 3600) {
                "${measuredDurationSeconds / 3600}h${(measuredDurationSeconds % 3600) / 60}min"
            } else {
                "${measuredDurationSeconds / 60}min"
            }
    }

    internal data class Filtered(
        val completed: List<WorkoutEntry>,
        val orphaned: List<FeedbackEntry>,
        val deleted: List<FeedbackEntry>,
        val summary: Summary
    )

    fun build(
        workouts: List<Workout>,
        feedbackRecords: List<FeedbackRecord>,
        zoneId: ZoneId = ZoneId.systemDefault()
    ): Snapshot {
        if (workouts.isEmpty() && feedbackRecords.isEmpty()) return Snapshot.empty()

        val workoutsBySessionId = workouts.indices
            .filter { workouts[it].sessionId.isNotBlank() }
            .groupBy { workouts[it].sessionId }
        val workoutsByCanonicalSlot = workouts.indices
            .mapNotNull { index ->
                val workout = workouts[index]
                val identityDate = SessionIdentityEngine.identityDate(
                    workout.scheduledDateIso,
                    workout.originalScheduledDateIso
                )
                val key = SessionIdentityEngine.canonicalSlotKey(identityDate, workout.type)
                key.takeIf { it.isNotBlank() }?.let { it to index }
            }
            .groupBy({ it.first }, { it.second })

        val latestFeedbackByWorkout = arrayOfNulls<FeedbackRecord>(workouts.size)
        val matchedRecordIds = HashSet<String>(feedbackRecords.size)

        feedbackRecords.forEach { record ->
            if (record.deleted) return@forEach

            // Fast path: exact identity (session ID + immutable planned date + compatible type).
            val exactMatches = workoutsBySessionId[record.sessionId].orEmpty().filter { index ->
                val workout = workouts[index]
                SessionIdentityEngine.feedbackMatchesWorkout(
                    feedbackSessionId = record.sessionId,
                    feedbackWorkoutDateIso = record.workoutDateIso,
                    workoutSessionId = workout.sessionId,
                    scheduledDateIso = workout.scheduledDateIso,
                    originalScheduledDateIso = workout.originalScheduledDateIso,
                    feedbackOriginalDateIso = record.workoutOriginalDateIso,
                    feedbackWorkoutType = record.workoutType,
                    workoutType = workout.type
                )
            }

            // Compatibility path for old backups whose cycle-scoped session ID was remapped.
            // It still requires one unique planned date + type slot; realized date is never used.
            val feedbackIdentityDate = record.workoutOriginalDateIso.ifBlank { record.workoutDateIso }
            val feedbackSlotKey = SessionIdentityEngine.canonicalSlotKey(feedbackIdentityDate, record.workoutType)
            val persistedSlotKey = SessionIdentityEngine.parseCanonicalSlotKey(record.canonicalWorkoutKey)
                ?.let { SessionIdentityEngine.canonicalSlotKey(it.dateIso, it.type) }
                .orEmpty()
            val feedbackSlotMatches = workoutsByCanonicalSlot[feedbackSlotKey].orEmpty()
            val persistedSlotMatches = workoutsByCanonicalSlot[persistedSlotKey].orEmpty()
            val fallbackMatch = when {
                feedbackSlotKey.isBlank() -> persistedSlotMatches.singleOrNull()
                persistedSlotKey.isBlank() || persistedSlotKey == feedbackSlotKey -> feedbackSlotMatches.singleOrNull()
                feedbackSlotMatches.isEmpty() -> persistedSlotMatches.singleOrNull()
                persistedSlotMatches.isEmpty() -> feedbackSlotMatches.singleOrNull()
                feedbackSlotMatches.size == 1 && persistedSlotMatches.size == 1 && feedbackSlotMatches.single() == persistedSlotMatches.single() -> feedbackSlotMatches.single()
                else -> null
            }

            // A record must resolve to one workout only. Ambiguous legacy matches remain
            // visible as unlinked history and can be linked explicitly by the athlete.
            val resolved = when {
                exactMatches.size > 1 -> null
                exactMatches.size == 1 && fallbackMatch != null && fallbackMatch != exactMatches.single() -> null
                exactMatches.size == 1 -> exactMatches.single()
                else -> fallbackMatch
            }
            if (resolved != null) {
                latestFeedbackByWorkout[resolved] = record
                matchedRecordIds += record.recordId
            }
        }

        val stableKeyOccurrences = HashMap<String, Int>()
        val completed = workouts.mapIndexedNotNull { index, workout ->
            val feedback = latestFeedbackByWorkout[index]
            if (!workout.done && feedback == null) return@mapIndexedNotNull null
            val activityDate = feedback?.let { activityDate(it, zoneId) }
                ?: parseDate(workout.scheduledDateIso)
                ?: LocalDate.MIN
            val baseKey = feedback?.let { "record:${it.recordId}" } ?: buildString {
                append("workout:")
                append(workout.sessionId.ifBlank { "legacy" })
                append('|')
                append(SessionIdentityEngine.identityDate(workout.scheduledDateIso, workout.originalScheduledDateIso))
                append('|')
                append(workout.scheduledDateIso)
            }
            val occurrence = stableKeyOccurrences.getOrDefault(baseKey, 0)
            stableKeyOccurrences[baseKey] = occurrence + 1
            WorkoutEntry(
                stableKey = if (occurrence == 0) baseKey else "$baseKey#$occurrence",
                workout = if (feedback != null && !workout.done) workout.copy(done = true) else workout,
                feedback = feedback,
                activityDate = activityDate
            )
        }.sortedWith(compareByDescending<WorkoutEntry> { it.activityDate }.thenByDescending { it.feedback?.savedAt ?: 0L })

        val orphaned = feedbackRecords.asSequence()
            .filter { !it.deleted && it.recordId !in matchedRecordIds }
            .map { FeedbackEntry("feedback:${it.recordId}", it, activityDate(it, zoneId)) }
            .sortedWith(compareByDescending<FeedbackEntry> { it.activityDate }.thenByDescending { it.record.savedAt })
            .toList()

        val deleted = feedbackRecords.asSequence()
            .filter { it.deleted }
            .map { FeedbackEntry("deleted:${it.recordId}", it, activityDate(it, zoneId)) }
            .sortedWith(compareByDescending<FeedbackEntry> { it.activityDate }.thenByDescending { it.record.savedAt })
            .toList()

        return Snapshot(completed, orphaned, deleted)
    }

    fun filter(snapshot: Snapshot, period: String, today: LocalDate): Filtered {
        val weekStart = today.minusDays((today.dayOfWeek.value - 1).toLong())
        val monthStart = today.withDayOfMonth(1)
        val yearStart = today.withDayOfYear(1)
        fun includes(date: LocalDate): Boolean = when (period.uppercase()) {
            "SEMANA", "WEEK" -> !date.isBefore(weekStart) && !date.isAfter(today)
            "MÊS", "MES", "MONTH" -> !date.isBefore(monthStart) && !date.isAfter(today)
            "ANO", "YEAR" -> !date.isBefore(yearStart) && !date.isAfter(today)
            else -> true
        }

        val completed = snapshot.completed.filter { includes(it.activityDate) }
        val orphaned = snapshot.orphaned.filter { includes(it.activityDate) }
        val deleted = snapshot.deleted.filter { includes(it.activityDate) }

        val measuredRecords = (completed.mapNotNull { it.feedback } + orphaned.map { it.record })
            .distinctBy { it.recordId }
        val measuredDistance = measuredRecords.sumOf { record ->
            record.actualDistanceKm?.takeIf { it.isFinite() && it > 0.0 } ?: 0.0
        }
        val measuredDuration = measuredRecords.sumOf { durationSeconds(it) ?: 0 }
        return Filtered(
            completed = completed,
            orphaned = orphaned,
            deleted = deleted,
            summary = Summary(
                sessionCount = completed.size + orphaned.size,
                measuredDistanceKm = measuredDistance,
                measuredDurationSeconds = measuredDuration
            )
        )
    }

    fun activityDate(record: FeedbackRecord, zoneId: ZoneId = ZoneId.systemDefault()): LocalDate =
        ActivityDateResolver.resolve(
            realizedDateIso = record.realizedDateIso,
            activityStartedAtIso = record.activityStartedAtIso,
            activitySourceFormat = record.activitySourceFormat,
            scheduledDateIso = record.workoutDateIso,
            savedAtMillis = record.savedAt,
            zoneId = zoneId
        )

    fun durationSeconds(record: FeedbackRecord): Int? {
        parseDuration(record.actualDuration.orEmpty())?.let { return it }
        val distance = record.actualDistanceKm?.takeIf { it.isFinite() && it > 0.0 } ?: return null
        val paceSeconds = parsePace(record.actualPaceMinKm.orEmpty()) ?: return null
        return (distance * paceSeconds).toInt().takeIf { it in 1..172_800 }
    }

    private fun parseDate(value: String): LocalDate? =
        value.takeIf { it.isNotBlank() }?.let { runCatching { LocalDate.parse(it) }.getOrNull() }

    private fun parseDuration(raw: String): Int? {
        val parts = raw.trim().split(':')
        if (parts.size !in 2..3 || parts.any { it.toIntOrNull() == null }) return null
        val values = parts.map { it.toInt() }
        val seconds = if (values.size == 3) values[0] * 3600 + values[1] * 60 + values[2]
        else values[0] * 60 + values[1]
        return seconds.takeIf { it in 1..172_800 }
    }

    private fun parsePace(raw: String): Int? {
        val parts = raw.trim().split(':')
        if (parts.size != 2) return null
        val minutes = parts[0].toIntOrNull() ?: return null
        val seconds = parts[1].toIntOrNull() ?: return null
        if (minutes !in 0..30 || seconds !in 0..59) return null
        return minutes * 60 + seconds
    }
}
