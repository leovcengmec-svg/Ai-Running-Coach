package com.airunningcoach.app

import java.security.MessageDigest
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters
import java.util.Locale
import java.text.Normalizer

/** Stable identity for one scheduled workout instance. Relative week numbers alone are not unique. */
internal object SessionIdentityEngine {
    fun create(
        scheduledDate: LocalDate,
        week: Int,
        type: String
    ): String {
        val cycleMonday = scheduledDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            .minusWeeks((week.coerceAtLeast(1) - 1).toLong())
        val dateToken = scheduledDate.toString().replace("-", "")
        val cycleToken = cycleMonday.toString().replace("-", "")
        val typeToken = type.uppercase(Locale.ROOT).replace(Regex("[^A-Z0-9]+"), "-").trim('-')
            .ifBlank { "WORKOUT" }
        return "C$cycleToken-$dateToken-$typeToken"
    }

    /** Deterministic namespace for legacy history that collides with a different local instance. */
    fun remapLegacy(sessionId: String, plannedDateIso: String, discriminator: String = ""): String {
        val source = listOf(sessionId.trim(), plannedDateIso.trim(), discriminator.trim()).joinToString("|")
        val digest = MessageDigest.getInstance("SHA-256").digest(source.toByteArray(Charsets.UTF_8))
            .take(8).joinToString("") { byte -> "%02x".format(byte) }
        return "LEGACY-$digest"
    }

    fun workoutDates(scheduledDateIso: String, originalScheduledDateIso: String = ""): Set<String> =
        setOf(scheduledDateIso.trim(), originalScheduledDateIso.trim())
            .filter { it.matches(Regex("\\d{4}-\\d{2}-\\d{2}")) }
            .toSet()

    fun identityDate(scheduledDateIso: String, originalScheduledDateIso: String = ""): String =
        originalScheduledDateIso.trim().ifBlank { scheduledDateIso.trim() }

    /** Calendar slot fallback for migrating a saved legacy ID to the new cycle-scoped ID. */
    fun slotKey(dateIso: String, type: String): String {
        val normalizedType = type.trim().uppercase(Locale.ROOT).replace(Regex("\\s+"), " ")
        return "${dateIso.trim()}|$normalizedType"
    }

    fun dateSlotKey(dateIso: String): String = "DATE|${dateIso.trim()}"

    /** Stable fallback identity for a workout slot when an older backup remaps session IDs. */
    fun normalizeWorkoutType(type: String): String {
        val ascii = Normalizer.normalize(type.trim(), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
            .uppercase(Locale.ROOT)
            .replace(Regex("[^A-Z0-9]+"), " ")
            .trim()
        return when {
            ascii.contains("LONGAO") || ascii == "LONGO" || ascii.contains("LONG RUN") || ascii.contains("LONGRUN") -> "LONGAO"
            ascii.contains("RODAGEM") || ascii.contains("AEROBIO") || ascii.contains("AEROBICA") || ascii.contains("AEROBIC") || ascii.contains("EASY RUN") -> "RODAGEM"
            ascii.contains("INTERVAL") || ascii.contains("LIMIAR") || ascii.contains("QUALIDADE") || ascii.contains("THRESHOLD") || ascii.contains("TEMPO RUN") -> "QUALIDADE"
            ascii.contains("FARTLEK") -> "FARTLEK"
            ascii.contains("REGENERAT") || ascii.contains("RECUPERAC") || ascii.contains("RECOVERY") -> "RECUPERACAO"
            ascii.contains("PROVA") || ascii.contains("COMPETICAO") || ascii.contains("RACE") -> "PROVA"
            ascii.contains("TESTE") || ascii.contains("COOPER") || ascii.contains("FIELD TEST") -> "TESTE"
            else -> ascii.replace(Regex("\\s+"), " ")
        }
    }

    fun typesCompatible(first: String, second: String): Boolean {
        if (first.isBlank() || second.isBlank()) return true
        return normalizeWorkoutType(first) == normalizeWorkoutType(second)
    }

    fun canonicalSlotKey(dateIso: String, type: String): String {
        val normalizedDate = dateIso.trim()
        val normalizedType = normalizeWorkoutType(type)
        if (!normalizedDate.matches(Regex("\\d{4}-\\d{2}-\\d{2}")) || normalizedType.isBlank()) return ""
        return "$normalizedDate|$normalizedType"
    }

    fun feedbackMatchesCanonicalSlot(
        feedbackOriginalDateIso: String,
        feedbackDateIso: String,
        feedbackType: String,
        workoutOriginalDateIso: String,
        workoutDateIso: String,
        workoutType: String,
        persistedCanonicalKey: String = ""
    ): Boolean {
        val feedbackDate = feedbackOriginalDateIso.trim().ifBlank { feedbackDateIso.trim() }
        val workoutDate = workoutOriginalDateIso.trim().ifBlank { workoutDateIso.trim() }
        val feedbackKey = canonicalSlotKey(feedbackDate, feedbackType)
        val workoutKey = canonicalSlotKey(workoutDate, workoutType)
        val persistedMatches = persistedCanonicalKey.split('|', limit = 2).takeIf { it.size == 2 }
            ?.let { canonicalSlotKey(it[0], it[1]) == workoutKey } == true
        if (persistedMatches) return true
        return feedbackKey.isNotBlank() && feedbackKey == workoutKey
    }

    fun feedbackMatchesWorkout(
        feedbackSessionId: String,
        feedbackWorkoutDateIso: String,
        workoutSessionId: String,
        scheduledDateIso: String,
        originalScheduledDateIso: String = "",
        feedbackOriginalDateIso: String = "",
        feedbackWorkoutType: String = "",
        workoutType: String = ""
    ): Boolean {
        if (feedbackSessionId.isBlank() || feedbackSessionId != workoutSessionId) return false
        if (!typesCompatible(feedbackWorkoutType, workoutType)) return false
        val workoutIdentityDate = originalScheduledDateIso.trim().ifBlank { scheduledDateIso.trim() }
        // Old feedback on a manually-rescheduled session has no immutable original date.
        // In that ambiguous legacy case, refuse to bind it to another cycle by moved date.
        val feedbackIdentityDate = feedbackOriginalDateIso.trim().ifBlank {
            if (originalScheduledDateIso.isBlank()) feedbackWorkoutDateIso.trim() else ""
        }
        if (feedbackIdentityDate.isBlank() || workoutIdentityDate.isBlank()) return false
        return feedbackIdentityDate == workoutIdentityDate
    }
}
