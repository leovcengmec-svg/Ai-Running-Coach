package com.airunningcoach.app

/** Keeps the visible feedback labels aligned with the numeric session-RPE scale. */
internal object FeedbackRpeScale {
    fun valueFor(label: String): Int? = when (label.trim()) {
        "Muito leve" -> 2
        "Leve" -> 3
        // "Ok" is the current UI label; "Moderado" is retained for older saved records.
        "Ok", "Moderado" -> 5
        "Pesado" -> 7
        "Muito pesado" -> 9
        else -> null
    }
}
