package com.airunningcoach.app

import java.time.LocalDate
import java.time.temporal.WeekFields
import kotlin.math.round

/** Completed activity. Training-load analytics use distance, duration and perceived effort only. */
internal data class LoggedRunActivity(
    val date: LocalDate,
    val distanceKm: Double,
    val durationSeconds: Int? = null,
    val rpe: Int? = null,
    val averageCadenceSpm: Int? = null,
    val elevationGainMeters: Double? = null,
    val sessionType: String = "",
    val zoneTimeSeconds: Map<String, Int> = emptyMap(),
    val estimatedZoneTimeSeconds: Map<String, Int> = emptyMap(),
    val terrain: String = RunningTerrain.ROAD
)

internal data class TrainingLoadSnapshot(
    val reliable: Boolean,
    val averageWeeklyKmLast28Days: Double?,
    val longestRunLast30DaysKm: Double?,
    val recordedRunsLast28Days: Int,
    val activeWeeksLast28Days: Int,
    val totalKmLast28Days: Double,
    val totalKmLast7Days: Double = 0.0,
    val durationMinutesLast7Days: Int? = null,
    val durationMinutesLast28Days: Int? = null,
    val sessionRpeLoadLast7Days: Int? = null,
    val sessionRpeLoadLast28Days: Int? = null,
    val averageRpeLast28Days: Double? = null,
    val averageCadenceLast28DaysSpm: Int? = null,
    val elevationGainLast28DaysMeters: Double? = null,
    val zoneTimeSecondsLast28Days: Map<String, Int> = emptyMap(),
    val loadTrend7To28: Double? = null,
    val measuredDurationActivities: Int = 0,
    val measuredRpeActivities: Int = 0,
    val totalKmLast42Days: Double = 0.0,
    val averageWeeklyKmLast42Days: Double? = null,
    val durationMinutesLast42Days: Int? = null,
    val sessionRpeLoadLast42Days: Int? = null,
    val estimatedZoneTimeSecondsLast28Days: Map<String, Int> = emptyMap(),
    val recordedRunsLast42Days: Int = 0,
    val activeWeeksLast42Days: Int = 0
)

/**
 * Summarizes external load (distance, duration, elevation) and perceived response (session-RPE).
 * Heart-rate fields from imported files are not read, summarized, or used by this engine.
 * The 7/28-day comparison is descriptive, not an injury score or a universal acute:chronic rule.
 * Display averages are descriptive even for partial histories; the independent reliability flag
 * is still gated by >=6 measured runs across >=3 ISO weeks.
 */
internal object TrainingLoadEngine {
    fun summarize(activities: List<LoggedRunActivity>, today: LocalDate = LocalDate.now()): TrainingLoadSnapshot {
        val start28 = today.minusDays(27)
        val start30 = today.minusDays(29)
        val start42 = today.minusDays(41)
        val start7 = today.minusDays(6)
        val valid = activities.filter {
            it.distanceKm.isFinite() && it.distanceKm > 0.0 && it.distanceKm <= 200.0 &&
                (it.durationSeconds == null || it.durationSeconds in 1..172_800) &&
                (it.rpe == null || it.rpe in 1..10) &&
                (it.averageCadenceSpm == null || it.averageCadenceSpm in 20..300) &&
                (it.elevationGainMeters == null || it.elevationGainMeters.isFinite() && it.elevationGainMeters >= 0.0)
        }
        val last28 = valid.filter { !it.date.isBefore(start28) && !it.date.isAfter(today) }
        val last30 = valid.filter { !it.date.isBefore(start30) && !it.date.isAfter(today) }
        val last42 = valid.filter { !it.date.isBefore(start42) && !it.date.isAfter(today) }
        val last7 = last28.filter { !it.date.isBefore(start7) }
        val activeWeeks = last28.map { activity ->
            val week = activity.date.get(WeekFields.ISO.weekOfWeekBasedYear())
            val year = activity.date.get(WeekFields.ISO.weekBasedYear())
            year * 100 + week
        }.distinct().size
        val total28 = last28.sumOf { it.distanceKm }
        val total7 = last7.sumOf { it.distanceKm }
        val activeWeeks42 = last42.map { activity ->
            val week = activity.date.get(WeekFields.ISO.weekOfWeekBasedYear())
            val year = activity.date.get(WeekFields.ISO.weekBasedYear())
            year * 100 + week
        }.distinct().size
        val total42 = last42.sumOf { it.distanceKm }
        val durationRows28 = last28.mapNotNull { it.durationSeconds }
        val durationRows7 = last7.mapNotNull { it.durationSeconds }
        val durationRows42 = last42.mapNotNull { it.durationSeconds }
        val rpeRows28 = last28.mapNotNull { activity ->
            activity.durationSeconds?.let { duration -> activity.rpe?.let { duration / 60.0 * it } }
        }
        val rpeRows7 = last7.mapNotNull { activity ->
            activity.durationSeconds?.let { duration -> activity.rpe?.let { duration / 60.0 * it } }
        }
        val rpeRows42 = last42.mapNotNull { activity ->
            activity.durationSeconds?.let { duration -> activity.rpe?.let { duration / 60.0 * it } }
        }
        val totalDuration28 = durationRows28.sum()
        val totalDuration7 = durationRows7.sum()
        val totalRpe28 = rpeRows28.sum().takeIf { rpeRows28.isNotEmpty() }?.let { round(it).toInt() }
        val totalRpe7 = rpeRows7.sum().takeIf { rpeRows7.isNotEmpty() }?.let { round(it).toInt() }
        val totalRpe42 = rpeRows42.sum().takeIf { rpeRows42.isNotEmpty() }?.let { round(it).toInt() }
        val zoneTotals = last28.flatMap { it.zoneTimeSeconds.entries }
            .groupBy({ it.key.uppercase() }, { it.value.coerceAtLeast(0) })
            .mapValues { (_, seconds) -> seconds.sum() }
            .filterKeys { it in setOf("Z1", "Z2", "Z3", "Z4", "Z5") }
        val estimatedZoneTotals = last28.flatMap { it.estimatedZoneTimeSeconds.entries }
            .groupBy({ it.key.uppercase() }, { it.value.coerceAtLeast(0) })
            .mapValues { (_, seconds) -> seconds.sum() }
            .filterKeys { it in setOf("Z1", "Z2", "Z3", "Z4", "Z5") }
        val reliable = last28.size >= 6 && activeWeeks >= 3
        val trend = if (totalRpe28 != null && totalRpe28 > 0 && totalRpe7 != null && totalRpe7 > 0) {
            (totalRpe7 * 4.0 / totalRpe28).takeIf { it.isFinite() }
        } else null
        return TrainingLoadSnapshot(
            reliable = reliable,
            // These are descriptive rolling-window averages. Reliability remains a separate
            // decision gate for prescription; partial histories must still be visible.
            averageWeeklyKmLast28Days = total28.takeIf { it > 0.0 }?.let { round1(it / 4.0) },
            longestRunLast30DaysKm = last30.maxOfOrNull { it.distanceKm }?.let(::round1),
            recordedRunsLast28Days = last28.size,
            activeWeeksLast28Days = activeWeeks,
            totalKmLast28Days = round1(total28),
            totalKmLast7Days = round1(total7),
            durationMinutesLast7Days = if (durationRows7.isNotEmpty()) (totalDuration7 / 60.0).roundToIntSafe() else null,
            durationMinutesLast28Days = if (durationRows28.isNotEmpty()) (totalDuration28 / 60.0).roundToIntSafe() else null,
            sessionRpeLoadLast7Days = totalRpe7,
            sessionRpeLoadLast28Days = totalRpe28,
            averageRpeLast28Days = last28.mapNotNull { it.rpe?.toDouble() }.averageOrNull()?.let(::round1),
            averageCadenceLast28DaysSpm = last28.mapNotNull { it.averageCadenceSpm }.takeIf { it.isNotEmpty() }?.average()?.roundToIntSafe(),
            elevationGainLast28DaysMeters = last28.mapNotNull { it.elevationGainMeters }.takeIf { it.isNotEmpty() }?.sum()?.let(::round1),
            zoneTimeSecondsLast28Days = zoneTotals,
            loadTrend7To28 = trend?.let(::round1),
            measuredDurationActivities = durationRows28.size,
            measuredRpeActivities = last28.count { it.durationSeconds != null && it.rpe != null },
            totalKmLast42Days = round1(total42),
            averageWeeklyKmLast42Days = total42.takeIf { it > 0.0 }?.let { round1(it / 6.0) },
            durationMinutesLast42Days = if (durationRows42.isNotEmpty()) (durationRows42.sum() / 60.0).roundToIntSafe() else null,
            sessionRpeLoadLast42Days = totalRpe42,
            estimatedZoneTimeSecondsLast28Days = estimatedZoneTotals,
            recordedRunsLast42Days = last42.size,
            activeWeeksLast42Days = activeWeeks42
        )
    }

    private fun List<Double>.averageOrNull(): Double? = if (isEmpty()) null else average().takeIf { it.isFinite() }
    private fun Double.roundToIntSafe(): Int = round(this).toInt().coerceAtLeast(0)
    private fun round1(value: Double): Double = round(value * 10.0) / 10.0
}
