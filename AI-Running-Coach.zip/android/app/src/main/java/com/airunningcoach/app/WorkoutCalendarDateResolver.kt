package com.airunningcoach.app

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

internal data class WorkoutCalendarDate(
    val bucketDate: LocalDate?,
    val displayLabel: String,
    val plannedDate: LocalDate?,
    val actualDate: LocalDate?
)

/** Completed sessions are bucketed by the real activity date; the planned date remains visible. */
internal object WorkoutCalendarDateResolver {
    private val labelFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale("pt", "BR"))

    fun resolve(scheduledDateIso: String, actualDate: LocalDate?, completed: Boolean): WorkoutCalendarDate {
        val planned = runCatching { LocalDate.parse(scheduledDateIso) }.getOrNull()
        val actual = actualDate.takeIf { completed }
        val bucket = actual ?: planned
        val label = when {
            actual != null && planned != null && actual != planned ->
                "Realizado ${actual.format(labelFormatter)} • planejado ${planned.format(labelFormatter)}"
            actual != null -> "Realizado ${actual.format(labelFormatter)}"
            planned != null -> planned.format(labelFormatter)
            else -> "Data não informada"
        }
        return WorkoutCalendarDate(bucket, label, planned, actual)
    }
}
