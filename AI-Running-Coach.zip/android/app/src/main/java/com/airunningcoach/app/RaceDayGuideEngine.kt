package com.airunningcoach.app

/** Athlete-facing competition guidance. It is a pacing/decision aid, not medical advice. */
internal data class RaceDayGuide(
    val title: String,
    val preRace: String,
    val warmUp: String,
    val start: String,
    val middle: String,
    val finish: String,
    val fueling: String,
    val recovery: String,
    val targetStrategy: String
)

internal object RaceDayGuideEngine {
    fun build(event: RaceEvent, athleteIntent: String): RaceDayGuide {
        val km = event.distanceKm
        val distanceLabel = when {
            km <= 5.1 -> "prova curta (até 5 km)"
            km <= 10.1 -> "10 km"
            km <= 21.2 -> "meia maratona"
            else -> "maratona ou prova longa"
        }
        val preRace = when {
            km <= 5.1 -> "Na véspera, reduza a atividade, organize número, roupa e tênis já testados. Faça refeições habituais e hidrate-se normalmente."
            km <= 21.2 -> "Nas 24–48 h anteriores, evite treino pesado, mantenha alimentação conhecida, hidratação habitual e prepare equipamento e logística. Não experimente alimentos ou suplementos novos."
            else -> "Nas 48 h anteriores, priorize descanso, alimentação familiar com carboidratos já testados, hidratação habitual, sono e logística. Não teste produtos novos."
        }
        val warmUp = when {
            km <= 5.1 -> "Faça 10–15 min de trote fácil progressivo e mobilidade dinâmica; acrescente 3–4 acelerações curtas se isso já fizer parte da sua rotina. Evite fadigar antes da largada."
            km <= 10.1 -> "Faça 8–12 min de corrida fácil, mobilidade dinâmica e 2–3 acelerações curtas opcionais. Comece a prova ainda confortável."
            else -> "Faça aquecimento breve e confortável, mobilidade dinâmica e evite volume extra. Em prova longa, preserve energia e não transforme o aquecimento em treino."
        }
        val start = when (athleteIntent) {
            TrainingGoalIntent.COMPLETE -> "Largue em esforço confortável e controlado. Não tente recuperar tempo perdido nos primeiros quilômetros."
            TrainingGoalIntent.CONTINUOUS -> "Estabeleça desde o início um esforço que consiga sustentar sem pausas planejadas; mantenha a corrida relaxada e constante."
            TrainingGoalIntent.PERSONAL_BEST -> "Comece ligeiramente conservador em relação ao esforço médio pretendido. Evite sair acima da capacidade demonstrada nos treinos."
            TrainingGoalIntent.TARGET_TIME -> if (event.targetTime.isNotBlank()) "Use ${event.targetTime} como referência global, mas faça os primeiros quilômetros de forma controlada antes de estabilizar no ritmo-alvo validado nos treinos." else "Sem tempo-alvo cadastrado, use esforço controlado e desempenho recente para definir o ritmo inicial."
            else -> "Comece em esforço confortável, sem perseguir outros corredores nem acelerar por empolgação."
        }
        val middle = when {
            athleteIntent == TrainingGoalIntent.COMPLETE -> "Mantenha esforço sustentável, observe respiração e sensação geral. Ajuste o ritmo antes de entrar em fadiga excessiva."
            athleteIntent == TrainingGoalIntent.CONTINUOUS -> "Priorize regularidade, passadas relaxadas e continuidade. Se precisar reduzir, diminua o ritmo antes de interromper a corrida."
            athleteIntent == TrainingGoalIntent.PERSONAL_BEST -> "Sustente o esforço planejado e avalie parciais. Só aumente o ritmo se a respiração, técnica e sensação permanecerem controladas."
            athleteIntent == TrainingGoalIntent.TARGET_TIME -> "Compare as parciais com o ritmo-alvo, sem reagir a oscilações pequenas de GPS. Use esforço e parciais oficiais como referência conjunta."
            else -> "Mantenha esforço confortável e regular, com liberdade para ajustar o ritmo às condições do percurso."
        }
        val finish = when (athleteIntent) {
            TrainingGoalIntent.COMPLETE -> "Se estiver bem, aumente gradualmente o esforço na parte final. O principal é concluir com controle."
            TrainingGoalIntent.CONTINUOUS -> "Mantenha a corrida contínua até a chegada. Acelere apenas se ainda conseguir sustentar a técnica e o esforço."
            TrainingGoalIntent.PERSONAL_BEST, TrainingGoalIntent.TARGET_TIME -> "Se houver reserva e a técnica continuar estável, aumente progressivamente o esforço no trecho final; evite sprint prematuro."
            else -> "Finalize em esforço controlado, respeitando sinais do corpo e as condições do dia."
        }
        val fueling = when {
            km <= 10.1 -> "Para a maioria das provas curtas, não é necessário consumir carboidrato durante a prova; siga sua rotina habitual de hidratação e as condições do evento."
            km <= 21.2 -> "Se a duração prevista passar de aproximadamente 75–90 min, use somente carboidratos e líquidos já testados nos treinos. Planeje conforme tolerância e clima."
            else -> "Planeje ingestão de carboidratos e líquidos com base no que foi testado nos longões. Distribua ao longo da prova; não estreie gel, bebida ou estratégia no dia."
        }
        val recovery = when {
            km <= 5.1 -> "Após a chegada, caminhe alguns minutos, hidrate-se conforme sede e retome a rotina leve quando estiver confortável."
            km <= 21.2 -> "Após a chegada, caminhe, reponha líquidos e alimentação habitual e evite treino intenso até recuperar bem. Registre esforço e desconfortos."
            else -> "Após a chegada, priorize alimentação, líquidos, descanso e recuperação progressiva. Não retome qualidade ou longão até recuperar a disposição e a corrida fácil."
        }
        val targetStrategy = when (event.priority) {
            "A" -> "Prova principal: estratégia específica do ciclo; o taper deve preservar a condição e chegar descansado."
            "B" -> "Prova preparatória: use para ensaiar ritmo, equipamento e alimentação; evite transformar automaticamente em tentativa máxima."
            else -> "Prova de treinamento: mantenha o objetivo da sessão e controle o esforço; não exige taper completo."
        }
        return RaceDayGuide("Orientação para $distanceLabel", preRace, warmUp, start, middle, finish, fueling, recovery, targetStrategy)
    }
}
