package com.airunningcoach.app

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/** Resolves the execution date without confusing it with the workout's scheduled date. */
internal object ActivityDateResolver {
    fun resolve(
        realizedDateIso: String,
        activityStartedAtIso: String,
        activitySourceFormat: String,
        scheduledDateIso: String,
        savedAtMillis: Long,
        zoneId: ZoneId = ZoneId.systemDefault()
    ): LocalDate {
        parseDate(realizedDateIso)?.let { return it }
        parseInstant(activityStartedAtIso, zoneId)?.let { return it }
        if (activitySourceFormat.isBlank()) {
            parseDate(scheduledDateIso)?.let { return it }
        }
        return runCatching { Instant.ofEpochMilli(savedAtMillis).atZone(zoneId).toLocalDate() }
            .getOrDefault(LocalDate.now(zoneId))
    }

    private fun parseDate(value: String): LocalDate? =
        value.takeIf { it.isNotBlank() }?.let { runCatching { LocalDate.parse(it) }.getOrNull() }

    private fun parseInstant(value: String, zoneId: ZoneId): LocalDate? =
        value.takeIf { it.isNotBlank() }
            ?.let { runCatching { Instant.parse(it).atZone(zoneId).toLocalDate() }.getOrNull() }
}
