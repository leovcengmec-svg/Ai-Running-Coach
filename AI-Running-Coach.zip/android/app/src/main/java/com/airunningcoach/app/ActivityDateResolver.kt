package com.airunningcoach.app

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/** Resolves the execution date separately from the planned workout date. */
internal object ActivityDateResolver {
    fun resolve(
        realizedDateIso: String,
        activityStartedAtIso: String,
        activitySourceFormat: String,
        scheduledDateIso: String,
        savedAtMillis: Long,
        zoneId: ZoneId = ZoneId.systemDefault()
    ): LocalDate {
        // For imported GPX/FIT/TCX, the activity timestamp is the source of truth.
        // A stale realizedDateIso may have been copied from the scheduled date by an older build.
        if (activitySourceFormat.isNotBlank()) {
            parseInstant(activityStartedAtIso, zoneId)?.let { return it }
            parseDate(realizedDateIso)?.let { return it }
        } else {
            parseDate(realizedDateIso)?.let { return it }
            parseDate(scheduledDateIso)?.let { return it }
        }
        return runCatching { Instant.ofEpochMilli(savedAtMillis).atZone(zoneId).toLocalDate() }
            .getOrDefault(LocalDate.now(zoneId))
    }

    private fun parseDate(value: String): LocalDate? =
        value.takeIf { it.isNotBlank() }?.let { runCatching { LocalDate.parse(it) }.getOrNull() }

    private fun parseInstant(value: String, zoneId: ZoneId): LocalDate? =
        value.takeIf { it.isNotBlank() }
            ?.let { runCatching { Instant.parse(it).atZone(zoneId).toLocalDate() }.getOrNull() }
}
