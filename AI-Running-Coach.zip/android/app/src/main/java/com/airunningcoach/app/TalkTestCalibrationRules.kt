package com.airunningcoach.app

/** Regras para coletar observações independentes de pace confortável (teste da fala). */
internal object TalkTestCalibrationRules {
    fun isEligibleWorkout(workoutType: String): Boolean = when (
        workoutType.trim().lowercase().replace('ó', 'o').replace('ã', 'a')
    ) {
        "aerobio", "longo", "longao" -> true
        else -> false
    }

    /** Returns a normalized mm:ss pace only for eligible easy/long sessions. */
    fun normalizeEntry(workoutType: String, paceText: String): String? {
        if (!isEligibleWorkout(workoutType)) return null
        val pace = PaceRange.parsePace(paceText) ?: return null
        return PaceRange.format(pace)
    }

    /** Only comfortable, pain-free observations may refine the aerobic boundary. */
    fun canCalibrate(effort: String, feeling: String, painPresent: Boolean): Boolean =
        !painPresent && effort in setOf("Muito leve", "Leve", "Ok") && feeling in setOf("Ótimo", "Bem")
}
