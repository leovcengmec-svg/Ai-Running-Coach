package com.airunningcoach.app

/**
 * Creates a true replacement session (not an additional workout).
 * All altered blocks receive the pace range belonging to their new zone.
 * Session identity, scheduled date, weekly dose and calibration snapshot stay intact.
 */
internal object WorkoutAlternativeEngine {
    fun createAlternative(primary: Workout): Workout {
        val isLongRun = primary.type.equals("Longo", ignoreCase = true) ||
            primary.title.contains("longão", ignoreCase = true)
        val isQuality = primary.type.equals("Qualidade", ignoreCase = true) ||
            primary.stimulus.contains("THRESHOLD", ignoreCase = true) ||
            primary.stimulus.contains("VO2", ignoreCase = true) ||
            primary.stimulus.contains("FARTLEK", ignoreCase = true) ||
            primary.stimulus.contains("PROGRESSION", ignoreCase = true) ||
            primary.stimulus.contains("TEMPO", ignoreCase = true)

        val replacement = when {
            isLongRun -> longRunAlternative(primary)
            isQuality -> qualityAlternative(primary)
            else -> easyAlternative(primary)
        }
        return replacement.copy(
            durationMin = WorkoutDurationEstimator.estimateMinutes(
                replacement.segments, replacement.distanceKm, primary.durationMin
            ).coerceAtLeast(1),
            sessionId = primary.sessionId,
            date = primary.date,
            scheduledDateIso = primary.scheduledDateIso,
            week = primary.week,
            phase = primary.phase,
            done = primary.done,
            paceCalibrationSnapshot = primary.paceCalibrationSnapshot,
            manuallyRescheduled = primary.manuallyRescheduled,
            originalScheduledDateIso = primary.originalScheduledDateIso,
            selectedOption = "ALTERNATIVE"
        )
    }

    private fun qualityAlternative(primary: Workout): Workout {
        val warmupIndex = primary.segments.indexOfFirst { it.name.contains("aquec", ignoreCase = true) }
            .takeIf { it >= 0 }
        val cooldownIndex = primary.segments.indexOfLast { it.name.contains("desaquec", ignoreCase = true) }
            .takeIf { it >= 0 && it != warmupIndex }
        val warmup = warmupIndex?.let { primary.segments[it] }
        val cooldown = cooldownIndex?.let { primary.segments[it] }
        val warmKm = warmup?.let { (it.distanceKm ?: 0.0) * it.repeatCount } ?: 0.0
        val coolKm = cooldown?.let { (it.distanceKm ?: 0.0) * it.repeatCount } ?: 0.0
        val mainKm = (primary.distanceKm - warmKm - coolKm).coerceAtLeast(0.0)
        val warmMin = warmup?.let { (it.durationMin ?: 0) * it.repeatCount } ?: 0
        val coolMin = cooldown?.let { (it.durationMin ?: 0) * it.repeatCount } ?: 0
        val mainMin = (primary.durationMin - warmMin - coolMin).coerceAtLeast(1)
        val mainSegments = primary.segments.filterIndexed { index, _ -> index != warmupIndex && index != cooldownIndex }
        val targetMode = if (mainSegments.any { it.targetMode == "DISTANCE" }) "DISTANCE" else "TIME"

        val blocks = buildList {
            warmup?.let { add(applyZone(it, primary, "Z1", "Aquecimento leve", "Comece muito confortável e aumente gradualmente, sem entrar em esforço moderado.")) }
            add(
                WorkoutSegment(
                    name = "Bloco aeróbio contínuo",
                    instruction = "Substitui os intervalos por corrida contínua confortável. Mantenha a conversa possível e não transforme a sessão em um treino de ritmo.",
                    durationMin = if (targetMode == "TIME") mainMin else null,
                    distanceKm = mainKm.takeIf { it > 0.0 },
                    intensity = "LOW",
                    rpeRange = "3-4",
                    targetMode = targetMode,
                    targetPaceMinValue = zonePace(primary, "Z2")?.first,
                    targetPaceMaxValue = zonePace(primary, "Z2")?.second,
                    paceZone = "Z2"
                )
            )
            cooldown?.let { add(applyZone(it, primary, "Z1", "Desaquecimento", "Reduza gradualmente até encerrar a sessão.")) }
        }

        return primary.copy(
            title = "Rodagem aeróbia contínua",
            detail = "Alternativa sem intervalos intensos, mantendo a dose total da sessão.",
            type = "Aeróbio",
            objective = "Manter o estímulo aeróbio com menor exigência de intensidade e sem repetições de qualidade.",
            stimulus = "ALTERNATIVE_AEROBIC_CONTINUOUS_Z2",
            intensity = "LOW",
            rpeRange = "3-4",
            rationale = "Esta opção substitui integralmente o treino de qualidade por uma rodagem contínua em Z2. A distância e a duração estimada permanecem iguais; não acrescente outro treino.",
            segments = blocks
        )
    }

    private fun longRunAlternative(primary: Workout): Workout {
        val blocks = primary.segments.map { segment ->
            when {
                segment.name.contains("aquec", ignoreCase = true) -> applyZone(segment, primary, "Z1", "Aquecimento leve", "Comece em ritmo muito confortável.")
                segment.name.contains("desaquec", ignoreCase = true) -> applyZone(segment, primary, "Z1", "Desaquecimento", "Reduza gradualmente o esforço.")
                segment.name.contains("recuper", ignoreCase = true) -> applyZone(segment, primary, "Z1", segment.name, segment.instruction)
                else -> applyZone(
                    segment, primary, "Z1", "Longão com pausas de caminhada",
                    "Mantenha o esforço muito confortável. Faça pausas breves de caminhada quando necessário, sem acelerar para compensar."
                )
            }
        }
        return primary.copy(
            title = "Longão com pausas confortáveis",
            detail = "Alternativa de menor exigência percebida, com corrida leve e pausas breves de caminhada.",
            objective = "Completar a sessão de resistência com esforço controlado e pausas planejadas quando necessário.",
            stimulus = "ALTERNATIVE_LONG_RUN_RUN_WALK_Z1",
            intensity = "LOW",
            rpeRange = "2-3",
            rationale = "Esta opção mantém a distância total do longão, mas permite pausas breves de caminhada para controlar o esforço. Não aumente a distância nem tente recuperar o tempo caminhando mais rápido.",
            segments = blocks
        )
    }

    private fun easyAlternative(primary: Workout): Workout {
        val blocks = primary.segments.map { segment ->
            when {
                segment.name.contains("aquec", ignoreCase = true) -> applyZone(segment, primary, "Z1", "Aquecimento leve", "Comece muito confortável.")
                segment.name.contains("desaquec", ignoreCase = true) -> applyZone(segment, primary, "Z1", "Desaquecimento", "Encerre gradualmente.")
                segment.name.contains("recuper", ignoreCase = true) -> applyZone(segment, primary, "Z1", segment.name, segment.instruction)
                else -> applyZone(
                    segment, primary, "Z1", "Corrida-caminhada leve",
                    "Alterne corrida confortável e caminhadas breves. Mantenha respiração tranquila e frases completas."
                )
            }
        }
        return primary.copy(
            title = "Corrida-caminhada leve",
            detail = "Alternativa leve, com pausas de caminhada e sem aumentar a dose da sessão.",
            type = if (primary.type.equals("Recuperação", ignoreCase = true)) "Recuperação" else "Aeróbio",
            objective = "Cumprir a sessão com menor exigência percebida, mantendo o movimento confortável.",
            stimulus = "ALTERNATIVE_RUN_WALK_Z1",
            intensity = "LOW",
            rpeRange = "2-3",
            rationale = "Esta opção substitui o formato original por corrida leve intercalada com caminhada. A dose total estimada é preservada e a opção não deve ser somada ao treino principal.",
            segments = blocks
        )
    }

    private fun applyZone(
        segment: WorkoutSegment,
        workout: Workout,
        zone: String,
        name: String,
        instruction: String
    ): WorkoutSegment {
        val range = zonePace(workout, zone)
        return segment.copy(
            name = name,
            instruction = instruction,
            intensity = "LOW",
            rpeRange = if (zone == "Z1") "2-3" else "3-4",
            paceZone = zone,
            targetPaceMinValue = range?.first,
            targetPaceMaxValue = range?.second,
            zoneBasePaceFastValue = range?.first,
            zoneBasePaceSlowValue = range?.second,
            zoneIntensityMinPercent = null,
            zoneIntensityMaxPercent = null
        )
    }

    private fun zonePace(workout: Workout, zone: String): Pair<Int, Int>? {
        val label = workout.paceCalibrationSnapshot?.zoneRanges?.get(zone) ?: return null
        val paceText = label.substringBefore(" min/km").trim()
        val limits = paceText.split('–', '-')
        if (limits.size != 2) return null
        val faster = PaceRange.parsePace(limits[0].trim()) ?: return null
        val slower = PaceRange.parsePace(limits[1].trim()) ?: return null
        if (slower < faster) return null
        return faster to slower
    }
}
