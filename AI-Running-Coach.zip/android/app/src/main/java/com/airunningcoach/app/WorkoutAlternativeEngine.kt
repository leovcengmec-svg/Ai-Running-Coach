package com.airunningcoach.app

/**
 * Creates a replacement session (never an additional workout). By default a healthy athlete
 * receives an alternative that preserves the original training purpose and quality zone.
 * A lower-demand option is used only when health/readiness signals explicitly disallow it.
 */
internal object WorkoutAlternativeEngine {
    fun createAlternative(
        primary: Workout,
        allowRunWalk: Boolean = false,
        preserveQualityStimulus: Boolean = true
    ): Workout {
        val isBeginnerRunWalkSession = primary.stimulus.startsWith("BEGINNER_RUN_WALK") &&
            primary.experienceMonths < 6
        val runWalkForThisSession = allowRunWalk && isBeginnerRunWalkSession
        val isLongRun = primary.type.equals("Longo", ignoreCase = true) ||
            primary.title.contains("longão", ignoreCase = true)
        val isQuality = primary.type.equals("Qualidade", ignoreCase = true) ||
            primary.stimulus.contains("THRESHOLD", ignoreCase = true) ||
            primary.stimulus.contains("VO2", ignoreCase = true) ||
            primary.stimulus.contains("FARTLEK", ignoreCase = true) ||
            primary.stimulus.contains("PROGRESSION", ignoreCase = true) ||
            primary.stimulus.contains("PROGRESSIVE", ignoreCase = true) ||
            primary.title.contains("progressiv", ignoreCase = true) ||
            primary.stimulus.contains("TEMPO", ignoreCase = true)

        val replacement = when {
            isLongRun -> longRunAlternative(primary, runWalkForThisSession)
            isQuality && preserveQualityStimulus -> equivalentQualityAlternative(primary)
            isQuality -> reducedDemandQualityAlternative(primary)
            else -> easyAlternative(primary, runWalkForThisSession)
        }
        return replacement.copy(
            durationMin = WorkoutDurationEstimator.estimateMinutes(
                replacement.segments, replacement.distanceKm, primary.durationMin
            ).coerceAtLeast(1),
            sessionId = primary.sessionId,
            date = primary.date,
            scheduledDateIso = primary.scheduledDateIso,
            week = primary.week,
            phase = primary.phase,
            done = primary.done,
            paceCalibrationSnapshot = primary.paceCalibrationSnapshot,
            experienceMonths = primary.experienceMonths,
            manuallyRescheduled = primary.manuallyRescheduled,
            originalScheduledDateIso = primary.originalScheduledDateIso,
            selectedOption = "ALTERNATIVE"
        )
    }

    /** Same stimulus family, zone and total work dose; the repetition geometry is varied. */
    private fun equivalentQualityAlternative(primary: Workout): Workout {
        val isProgression = primary.stimulus.contains("PROGRESSION", ignoreCase = true) ||
            primary.title.contains("progressiv", ignoreCase = true)
        val workZones = if (isProgression) setOf("Z2", "Z3") else setOf("Z3", "Z4", "Z5")
        val work = primary.segments.filter { segment ->
            segment.recoveryMode == null && segment.paceZone in workZones &&
                !isWarmupOrCooldown(segment.name)
        }
        if (work.isEmpty()) return primary.copy(
            title = "Variação equivalente — ${primary.title}",
            detail = "Variação da mesma sessão; mantenha o estímulo, a zona e a dose principal.",
            rationale = "A estrutura não pôde ser redistribuída automaticamente sem alterar a dose. A prescrição original foi mantida como alternativa segura."
        )

        val zones = work.mapNotNull { it.paceZone }.distinct()
        val dominantZone = zones.maxByOrNull { zoneRank(it) } ?: work.first().paceZone ?: "Z3"
        val selectedWork = work.filter { it.paceZone == dominantZone }
        val allSameZone = work.all { it.paceZone == dominantZone }
        val workDoseDistance = if (work.all { it.distanceKm != null }) work.sumOf { (it.distanceKm ?: 0.0) * it.repeatCount } else null
        val workDoseMinutes = if (work.all { it.durationMin != null && it.targetMode == "TIME" }) work.sumOf { (it.durationMin ?: 0) * it.repeatCount } else null
        val originalRepeats = selectedWork.sumOf { it.repeatCount }.coerceAtLeast(1)
        val preserveProgressionSequence = isProgression && selectedWork.size > 1
        val alternativeRepeats = when {
            originalRepeats >= 5 -> (originalRepeats - 1).coerceAtLeast(2)
            originalRepeats in 2..4 -> originalRepeats + 1
            else -> 1
        }.coerceAtMost(10)
        val template = selectedWork.first()
        val bandMin = template.zoneIntensityMinPercent ?: 25
        val bandMax = template.zoneIntensityMaxPercent ?: 65
        val shiftedBand = alternativeBand(bandMin, bandMax)
        val adjustedWork = if (!allSameZone || preserveProgressionSequence) {
            // Mixed-zone and progressive sessions keep every stage in its original order,
            // dose and zone; only the active sub-range is changed within that same zone.
            work.mapIndexed { index, segment ->
                val band = alternativeBand(segment.zoneIntensityMinPercent ?: bandMin, segment.zoneIntensityMaxPercent ?: bandMax)
                withBand(segment.copy(name = if (isProgression) "Etapa progressiva ${segment.paceZone} ${index + 1}" else "Variação ${segment.paceZone} ${index + 1}",
                    instruction = if (isProgression) "Mantenha a progressão contínua entre as faixas da zona, com nova distribuição de intensidade." else "Mantenha a sequência de zonas da sessão original, variando apenas a faixa ativa."), band, primary)
            }
        } else when {
            workDoseDistance != null -> listOf(withBand(template.copy(
                name = "Intervalo alternativo $dominantZone",
                instruction = "Repita o mesmo estímulo em $dominantZone com outra distribuição de repetições. Mantenha a técnica e o controle do esforço.",
                distanceKm = workDoseDistance / alternativeRepeats,
                durationMin = null,
                targetMode = "DISTANCE",
                repeatCount = alternativeRepeats
            ), shiftedBand, primary))
            workDoseMinutes != null -> {
                val viable = (2..10).filter { workDoseMinutes % it == 0 }
                val reps = viable.minByOrNull { kotlin.math.abs(it - alternativeRepeats) } ?: originalRepeats
                listOf(withBand(template.copy(
                    name = "Intervalo alternativo $dominantZone",
                    instruction = "Repita o mesmo estímulo em $dominantZone com outra distribuição de repetições. Mantenha a técnica e o controle do esforço.",
                    durationMin = workDoseMinutes / reps,
                    distanceKm = null,
                    targetMode = "TIME",
                    repeatCount = reps
                ), shiftedBand, primary))
            }
            else -> selectedWork.mapIndexed { index, segment ->
                val band = alternativeBand(segment.zoneIntensityMinPercent ?: bandMin, segment.zoneIntensityMaxPercent ?: bandMax)
                withBand(segment.copy(
                    name = "Variação $dominantZone ${index + 1}",
                    instruction = "Mantenha o estímulo original em $dominantZone, com nova distribuição da faixa ativa."
                ), band, primary)
            }
        }

        val firstWorkIndex = primary.segments.indexOfFirst { it in work }
        val updated = mutableListOf<WorkoutSegment>()
        var inserted = false
        primary.segments.forEach { segment ->
            when {
                segment in work -> {
                    if (!inserted) { updated += adjustedWork; inserted = true }
                }
                segment.recoveryMode != null -> {
                    // Recoveries remain attached to the same stimulus; passive rests stay time-only.
                    // Only consolidated repeated intervals change recovery repeat count.
                    val newRepeatCount = adjustedWork.firstOrNull()?.repeatCount ?: originalRepeats
                    updated += if (allSameZone && !preserveProgressionSequence && newRepeatCount > 1)
                        segment.copy(repeatCount = newRepeatCount - 1) else segment
                }
                else -> updated += segment
            }
        }
        if (!inserted && firstWorkIndex >= 0) updated.addAll(firstWorkIndex, adjustedWork)
        val newDistance = updated.sumOf { (it.distanceKm ?: 0.0) * it.repeatCount }
        val title = when {
            isProgression && dominantZone == "Z2" -> "Rodagem progressiva equivalente Z2"
            isProgression -> "Rodagem progressiva equivalente Z2–Z3"
            dominantZone == "Z5" -> "Intervalado equivalente Z5"
            dominantZone == "Z4" -> "Limiar equivalente Z4"
            else -> "Tempo equivalente Z3"
        }
        return primary.copy(
            title = title,
            detail = "Alternativa com o mesmo propósito e zona de trabalho, redistribuindo a dose principal.",
            objective = primary.objective,
            stimulus = primary.stimulus,
            intensity = primary.intensity,
            rpeRange = primary.rpeRange,
            rationale = "A alternativa preserva o propósito original (${primary.stimulus}), as zonas de trabalho e a dose principal. " +
                when {
                    preserveProgressionSequence -> "A ordem e as distâncias de cada etapa progressiva foram mantidas."
                    allSameZone -> "As repetições foram reorganizadas sem trocar qualidade por rodagem leve."
                    else -> "A sequência mista de zonas foi preservada."
                },
            segments = updated,
            distanceKm = newDistance.takeIf { it > 0.0 } ?: primary.distanceKm
        )
    }

    /** Used only when readiness/health does not allow an equivalent quality session. */
    private fun reducedDemandQualityAlternative(primary: Workout): Workout {
        val warmup = primary.segments.firstOrNull { isWarmupOrCooldown(it.name) && it.name.contains("aquec", true) }
        val cooldown = primary.segments.lastOrNull { isWarmupOrCooldown(it.name) && it.name.contains("desaquec", true) }
        val warmKm = (warmup?.distanceKm ?: 0.0) * (warmup?.repeatCount ?: 1)
        val coolKm = (cooldown?.distanceKm ?: 0.0) * (cooldown?.repeatCount ?: 1)
        val easyKm = ((primary.distanceKm - warmKm - coolKm).coerceAtLeast(0.0) * 0.8)
        val segments = buildList {
            warmup?.let { add(applyZone(it, primary, "Z2", "Aquecimento leve", "Aqueça em Z2 0–20%, sem forçar.")) }
            if (easyKm > 0.0) add(applyZone(
                WorkoutSegment("Bloco reduzido de recuperação", "A carga foi reduzida porque os sinais recentes de recuperação/saúde não permitem preservar a intensidade original.",
                    distanceKm = easyKm, targetMode = "DISTANCE", intensity = "LOW", rpeRange = "2-3"),
                primary, "Z2", "Bloco reduzido de recuperação", "Mantenha Z2 confortável; interrompa se houver dor ou piora dos sintomas."
            ).copy(zoneIntensityMinPercent = 0, zoneIntensityMaxPercent = 30))
            cooldown?.let { add(applyZone(it, primary, "Z2", "Desaquecimento leve", "Finalize em Z2 0–20%.")) }
        }
        val total = segments.sumOf { (it.distanceKm ?: 0.0) * it.repeatCount }
        return primary.copy(
            title = "Sessão reduzida por recuperação",
            detail = "Alternativa de menor exigência, aplicada porque a recuperação/saúde não recomenda manter a qualidade prevista.",
            type = "Recuperação",
            objective = "Reduzir temporariamente a exigência sem prescrever intensidade alta.",
            stimulus = "ALTERNATIVE_RECOVERY_REDUCED_Z2",
            intensity = "LOW", rpeRange = "2-3",
            rationale = "A sessão foi reduzida em aproximadamente 20% no bloco principal devido aos sinais atuais de recuperação/saúde. Não tente compensar o volume removido.",
            segments = segments,
            distanceKm = if (total > 0.0) total else primary.distanceKm * 0.8
        )
    }

    private fun longRunAlternative(primary: Workout, allowRunWalk: Boolean): Workout {
        if (allowRunWalk) return runWalkAlternative(primary, "Longão com pausas de caminhada")
        val segments = primary.segments.map { segment ->
            when {
                segment.recoveryMode != null -> segment
                isWarmupOrCooldown(segment.name) -> applyZone(segment, primary, "Z2", segment.name,
                    "Use Z2 0–20% para aquecer ou desaquecer de forma natural.")
                else -> applyZone(segment, primary, "Z2", "Longão contínuo Z2", "Mantenha corrida contínua aeróbia; a alternativa preserva o estímulo de resistência.")
            }
        }
        return primary.copy(
            title = "Longão contínuo aeróbio — variação",
            detail = "Alternativa de resistência contínua, sem pausas prescritas de caminhada.",
            objective = primary.objective,
            stimulus = primary.stimulus,
            intensity = "LOW", rpeRange = "3-4",
            rationale = "A alternativa mantém a função de longão e a distância total, ajustando os blocos para corrida contínua em Z2.",
            segments = segments
        )
    }

    private fun easyAlternative(primary: Workout, allowRunWalk: Boolean): Workout {
        if (allowRunWalk) return runWalkAlternative(primary, "Corrida-caminhada leve")
        val segments = primary.segments.map { segment ->
            when {
                segment.recoveryMode != null -> segment
                isWarmupOrCooldown(segment.name) -> applyZone(segment, primary, "Z2", segment.name, "Use Z2 0–20% na transição.")
                else -> applyZone(segment, primary, "Z2", "Rodagem aeróbia Z2", "Mantenha corrida contínua confortável dentro da Z2.")
            }
        }
        return primary.copy(
            title = "Rodagem aeróbia equivalente",
            detail = "Alternativa contínua que mantém a função aeróbia da sessão original.",
            objective = primary.objective,
            stimulus = primary.stimulus,
            intensity = "LOW", rpeRange = "3-4",
            rationale = "A alternativa mantém a dose e o propósito aeróbio em Z2, sem converter corrida contínua em caminhada/corrida.",
            segments = segments
        )
    }

    private fun runWalkAlternative(primary: Workout, title: String): Workout {
        val segments = primary.segments.map { segment ->
            when {
                isWarmupOrCooldown(segment.name) -> segment
                segment.recoveryMode != null -> segment
                else -> segment.copy(name = "Corrida/caminhada adaptada", instruction = "Alterne corrida e caminhada apenas neste plano de iniciante elegível.")
            }
        }
        return primary.copy(title = title, detail = "Alternativa corrida/caminhada reservada ao plano de iniciante elegível.", segments = segments)
    }

    private fun applyZone(segment: WorkoutSegment, workout: Workout, zone: String, name: String, instruction: String): WorkoutSegment {
        val range = zonePace(workout, zone)
        val isTransition = isWarmupOrCooldown(name)
        val band = when {
            isTransition && workout.experienceMonths >= 6 -> ZoneIntensityBandEngine.z2EasyTransitionBand
            zone == "Z2" && name.contains("Longão", true) -> ActiveZoneBand(10, 55)
            zone == "Z2" && name.contains("recuper", true) -> ZoneIntensityBandEngine.z2EasyTransitionBand
            zone == "Z2" -> ActiveZoneBand(20, 60)
            zone == "Z3" -> ActiveZoneBand(20, 60)
            zone == "Z4" -> ActiveZoneBand(25, 65)
            else -> ActiveZoneBand(20, 60)
        }
        val active = range?.let { ZoneIntensityBandEngine.activeRange(PaceRange(it.first, it.second), band) }
        return segment.copy(
            name = name, instruction = instruction,
            intensity = if (zone in setOf("Z4", "Z5")) "HIGH" else "LOW",
            rpeRange = if (zone in setOf("Z4", "Z5")) "6-8" else "3-4",
            paceZone = zone,
            targetPaceMinValue = active?.fastestPaceValue,
            targetPaceMaxValue = active?.slowestPaceValue,
            zoneBasePaceFastValue = range?.first,
            zoneBasePaceSlowValue = range?.second,
            zoneIntensityMinPercent = band.minPercent,
            zoneIntensityMaxPercent = band.maxPercent
        )
    }

    private fun zonePace(workout: Workout, zone: String): Pair<Int, Int>? {
        val label = workout.paceCalibrationSnapshot?.zoneRanges?.get(zone) ?: return null
        val paceText = label.substringBefore(" min/km").trim()
        val limits = paceText.split('–', '-')
        if (limits.size != 2) return null
        val faster = PaceRange.parsePace(limits[0].trim()) ?: return null
        val slower = PaceRange.parsePace(limits[1].trim()) ?: return null
        return if (slower >= faster) faster to slower else null
    }

    private fun withBand(segment: WorkoutSegment, band: ActiveZoneBand, workout: Workout): WorkoutSegment {
        val snapshotRange = segment.paceZone?.let { zonePace(workout, it) }
        val fast = snapshotRange?.first ?: segment.zoneBasePaceFastValue ?: segment.targetPaceMinValue ?: return segment.copy(
            zoneIntensityMinPercent = band.minPercent, zoneIntensityMaxPercent = band.maxPercent)
        val slow = snapshotRange?.second ?: segment.zoneBasePaceSlowValue ?: segment.targetPaceMaxValue ?: return segment.copy(
            zoneIntensityMinPercent = band.minPercent, zoneIntensityMaxPercent = band.maxPercent)
        val active = ZoneIntensityBandEngine.activeRange(PaceRange(fast, slow), band)
        return segment.copy(targetPaceMinValue = active.fastestPaceValue, targetPaceMaxValue = active.slowestPaceValue,
            zoneIntensityMinPercent = band.minPercent, zoneIntensityMaxPercent = band.maxPercent)
    }

    private fun alternativeBand(min: Int, max: Int): ActiveZoneBand {
        val width = (max - min).coerceIn(10, 60)
        val shiftedMin = if (max + 10 <= 100) max else (min - 10).coerceAtLeast(0)
        val shiftedMax = (shiftedMin + width).coerceAtMost(100)
        return ActiveZoneBand(shiftedMin, shiftedMax)
    }

    private fun zoneRank(zone: String): Int = zone.removePrefix("Z").toIntOrNull() ?: 0
    private fun isWarmupOrCooldown(name: String): Boolean =
        name.contains("aquec", true) || name.contains("warmup", true) ||
            name.contains("desaquec", true) || name.contains("cooldown", true)
}
