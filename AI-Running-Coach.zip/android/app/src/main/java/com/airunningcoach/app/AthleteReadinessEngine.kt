package com.airunningcoach.app

/** Minimal subjective evidence collected in a session feedback form. */
internal data class ReadinessFeedback(
    val effort: String,
    val feeling: String,
    val painPresent: Boolean
)

/**
 * Small, explainable readiness heuristic. It is not a medical assessment and does not
 * infer sleep, HRV, resting HR or injury status from unavailable data.
 */
internal data class AthleteReadinessSnapshot(
    val sampleCount: Int,
    val recoveryScore: Double?,
    val fatigueScore: Double?,
    val recoveryStatus: String,
    val safetyStatus: String,
    val painReported: Boolean
)

internal object AthleteReadinessEngine {
    fun evaluate(recentFeedback: List<ReadinessFeedback>): AthleteReadinessSnapshot {
        val samples = recentFeedback.takeLast(3)
        if (samples.isEmpty()) {
            return AthleteReadinessSnapshot(
                sampleCount = 0,
                recoveryScore = null,
                fatigueScore = null,
                recoveryStatus = "UNKNOWN",
                safetyStatus = "UNASSESSED",
                painReported = false
            )
        }

        val pain = samples.any { it.painPresent }
        // A single comfortable feedback is not enough to declare readiness good.
        // Require at least two observations unless pain/fatigue already signals risk.
        // Count affected sessions, not individual fields. A single difficult session
        // with both high RPE and tired feeling remains one observation.
        val fatigueSessions = samples.count { feedback ->
            feedback.feeling in setOf("Cansado", "Muito cansado") ||
                feedback.effort in setOf("Pesado", "Muito pesado")
        }
        if (samples.size < 2 && !pain && fatigueSessions == 0) {
            return AthleteReadinessSnapshot(
                sampleCount = samples.size,
                recoveryScore = null,
                fatigueScore = null,
                recoveryStatus = "UNKNOWN",
                safetyStatus = "UNASSESSED",
                painReported = false
            )
        }
        val recoveryScore = when {
            pain -> 10.0
            fatigueSessions >= 2 -> 35.0
            fatigueSessions == 1 -> 60.0
            else -> 80.0
        }
        val fatigueScore = when {
            pain -> 95.0
            fatigueSessions >= 2 -> 80.0
            fatigueSessions == 1 -> 65.0
            else -> 30.0
        }
        val recoveryStatus = when {
            recoveryScore >= 75.0 -> "GOOD"
            recoveryScore >= 50.0 -> "MODERATE"
            else -> "POOR"
        }
        val safetyStatus = when {
            pain -> "RED"
            fatigueSessions >= 2 || fatigueScore >= 75.0 || recoveryScore < 50.0 -> "YELLOW"
            else -> "GREEN"
        }
        return AthleteReadinessSnapshot(
            sampleCount = samples.size,
            recoveryScore = recoveryScore,
            fatigueScore = fatigueScore,
            recoveryStatus = recoveryStatus,
            safetyStatus = safetyStatus,
            painReported = pain
        )
    }
}
