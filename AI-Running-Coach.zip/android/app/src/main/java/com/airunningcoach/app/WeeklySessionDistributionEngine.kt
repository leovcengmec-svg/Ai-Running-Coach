package com.airunningcoach.app

import kotlin.math.floor
import kotlin.math.roundToInt

internal data class WeeklySessionDistribution(
    val actualWeeklyKm: Double,
    val longRunKm: Double,
    /** Distances for all non-long-run sessions, in caller-defined order. */
    val nonLongRunKm: List<Double>,
    val longRunShare: Double,
    val requestedWeeklyKm: Double,
    val wasReduced: Boolean,
    val strongDominanceSatisfied: Boolean
)

/**
 * Enforces a maximum 40% long-run share, a visibly dominant long run and per-session
 * distance floors. If the requested total cannot satisfy all constraints, it searches
 * downward by 0.1 km and returns the largest valid weekly dose; it never creates a
 * short regular session to make the requested total look aligned.
 */
internal object WeeklySessionDistributionEngine {
    private const val MAX_LONG_RUN_SHARE = 0.40
    private const val MIN_LONG_RUN_GAP_KM = 0.8
    private const val MIN_LONG_RUN_LEAD_RATIO = 1.15

    fun distribute(
        requestedWeeklyKm: Double,
        sessionCount: Int,
        maxSessionKm: Double,
        minSessionKm: Double = 0.1,
        requireStrongDominance: Boolean = false
    ): WeeklySessionDistribution {
        require(requestedWeeklyKm.isFinite() && requestedWeeklyKm > 0.0) { "O volume semanal precisa ser positivo." }
        require(sessionCount in 2..6) { "A distribuição exige de 2 a 6 sessões." }
        require(maxSessionKm.isFinite() && maxSessionKm > 0.0) { "O limite individual da sessão é inválido." }
        require(minSessionKm.isFinite() && minSessionKm >= 0.1) { "O piso individual da sessão é inválido." }

        val requestedTenths = (requestedWeeklyKm * 10.0).roundToInt().coerceAtLeast(1)
        val maxSessionTenths = floor(maxSessionKm * 10.0 + 1e-9).toInt().coerceAtLeast(1)
        val minSessionTenths = (minSessionKm * 10.0).roundToInt().coerceAtLeast(1)

        // With two days the largest of two positive sessions must account for at least
        // 50% of the total, so a 40% ceiling and a dominant long run cannot coexist.
        if (sessionCount == 2) {
            throw IllegalArgumentException(
                "Com apenas 2 dias de corrida não é possível manter o longão como maior sessão e limitar sua participação a 40%. Selecione ao menos 3 dias de corrida."
            )
        }

        val minimumTotalTenths = minSessionTenths * sessionCount + 1
        var bestWeakFallback: WeeklySessionDistribution? = null
        for (totalTenths in requestedTenths downTo minimumTotalTenths) {
            val longByShare = floor(totalTenths * MAX_LONG_RUN_SHARE + 1e-9).toInt()
            val longBySessionFloor = totalTenths - minSessionTenths * (sessionCount - 1)
            val maxLongTenths = minOf(longByShare, maxSessionTenths, longBySessionFloor)
            if (maxLongTenths <= minSessionTenths) continue

            var firstStrictlyLargest: Pair<Int, List<Int>>? = null
            var firstStronglyDominant: Pair<Int, List<Int>>? = null
            // Do not automatically push the long run to the 40% ceiling. A lower
            // value can preserve a valid 5 km + 5 km + 6 km structure at 16 km.
            for (longTenths in maxLongTenths downTo (minSessionTenths + 1)) {
                val nonLongTotal = totalTenths - longTenths
                val nonLong = splitTenthsEvenly(nonLongTotal, sessionCount - 1)
                if (nonLong.any { it < minSessionTenths || it > maxSessionTenths }) continue
                val secondLargest = nonLong.maxOrNull() ?: continue
                if (longTenths <= secondLargest) continue
                if (firstStrictlyLargest == null) firstStrictlyLargest = longTenths to nonLong

                val longKm = longTenths / 10.0
                val secondKm = secondLargest / 10.0
                val strongDominance = longKm + 1e-9 >= secondKm + MIN_LONG_RUN_GAP_KM &&
                    longKm + 1e-9 >= secondKm * MIN_LONG_RUN_LEAD_RATIO
                if (strongDominance) {
                    firstStronglyDominant = longTenths to nonLong
                    break
                }
            }
            // Prefer a meaningful long-run gap even when this requires a small, explicit
            // reduction of the planned week. Only use strict dominance as a fallback after
            // searching every safe weekly total, and never in normal continuous 5 km plans.
            val selected = firstStronglyDominant ?: firstStrictlyLargest ?: continue
            val longTenths = selected.first
            val nonLong = selected.second
            val longKm = longTenths / 10.0
            val candidate = WeeklySessionDistribution(
                actualWeeklyKm = totalTenths / 10.0,
                longRunKm = longKm,
                nonLongRunKm = nonLong.map { it / 10.0 },
                longRunShare = longKm / (totalTenths / 10.0),
                requestedWeeklyKm = requestedWeeklyKm,
                wasReduced = totalTenths < requestedTenths,
                strongDominanceSatisfied = firstStronglyDominant != null
            )
            if (candidate.strongDominanceSatisfied) return candidate
            if (!requireStrongDominance && bestWeakFallback == null) bestWeakFallback = candidate
        }
        bestWeakFallback?.let { return it }

        val floorLabel = if (minSessionTenths >= 50) " O piso de 5 km por sessão está ativo." else ""
        throw IllegalArgumentException(
            "Não existe distribuição válida dentro dos ${requestedWeeklyKm.toOneDecimal()} km solicitados para $sessionCount sessões, respeitando longão até 40%, diferença mínima quando viável, limite individual de ${maxSessionKm.toOneDecimal()} km e piso de ${minSessionKm.toOneDecimal()} km por sessão. Ajuste explicitamente o volume semanal, a frequência ou a tolerância recente.$floorLabel"
        )
    }

    private fun splitTenthsEvenly(totalTenths: Int, count: Int): List<Int> {
        if (count <= 0) return emptyList()
        val base = totalTenths / count
        val remainder = totalTenths % count
        return List(count) { index -> base + if (index < remainder) 1 else 0 }
    }

    private fun Double.toOneDecimal(): String = String.format(java.util.Locale.US, "%.1f", this)
}
