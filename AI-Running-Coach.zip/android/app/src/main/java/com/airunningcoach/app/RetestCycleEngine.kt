package com.airunningcoach.app

import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.DayOfWeek
import java.time.temporal.TemporalAdjusters

/** Immutable snapshot of the real session displaced by a physiological retest. */
internal data class RetestOriginalSessionSnapshot(
    val title: String,
    val detail: String,
    val type: String,
    val objective: String,
    val stimulus: String,
    val distanceKm: Double,
    val durationMin: Int,
    val intensity: String,
    val paceMode: String,
    val rpeRange: String,
    val rationale: String,
    val segments: List<WorkoutSegment>
) {
    fun restore(slot: Workout): Workout = slot.copy(
        title = title,
        detail = detail,
        type = type,
        objective = objective,
        stimulus = stimulus,
        distanceKm = distanceKm,
        durationMin = durationMin,
        intensity = intensity,
        paceMode = paceMode,
        rpeRange = rpeRange,
        rationale = rationale,
        segments = segments,
        selectedOption = "ALTERNATIVE",
        retestOriginalSession = null,
        retestMethod = ""
    )

    fun toJson(): JSONObject = JSONObject().apply {
        put("title", title); put("detail", detail); put("type", type)
        put("objective", objective); put("stimulus", stimulus); put("distanceKm", distanceKm)
        put("durationMin", durationMin); put("intensity", intensity); put("paceMode", paceMode)
        put("rpeRange", rpeRange); put("rationale", rationale)
        put("segments", JSONArray().apply { segments.forEach { segment -> put(segment.toSnapshotJson()) } })
    }

    companion object {
        fun from(workout: Workout) = RetestOriginalSessionSnapshot(
            title = workout.title, detail = workout.detail, type = workout.type,
            objective = workout.objective, stimulus = workout.stimulus,
            distanceKm = workout.distanceKm, durationMin = workout.durationMin,
            intensity = workout.intensity, paceMode = workout.paceMode,
            rpeRange = workout.rpeRange, rationale = workout.rationale,
            segments = workout.segments
        )

        fun fromJson(raw: JSONObject?): RetestOriginalSessionSnapshot? {
            raw ?: return null
            val segments = buildList {
                val array = raw.optJSONArray("segments") ?: JSONArray()
                for (index in 0 until array.length()) {
                    val item = array.optJSONObject(index) ?: continue
                    runCatching { add(item.toSnapshotSegment()) }
                }
            }
            val title = raw.optString("title")
            if (title.isBlank()) return null
            return RetestOriginalSessionSnapshot(
                title = title,
                detail = raw.optString("detail"),
                type = raw.optString("type", "Aeróbio"),
                objective = raw.optString("objective"),
                stimulus = raw.optString("stimulus"),
                distanceKm = raw.optDouble("distanceKm", 0.0).takeIf { it.isFinite() && it >= 0.0 } ?: 0.0,
                durationMin = raw.optInt("durationMin", 0).coerceAtLeast(0),
                intensity = raw.optString("intensity", "LOW"),
                paceMode = raw.optString("paceMode", "PACE_NOT_CALIBRATED"),
                rpeRange = raw.optString("rpeRange", "3-4"),
                rationale = raw.optString("rationale"),
                segments = segments
            )
        }
    }
}

private fun WorkoutSegment.toSnapshotJson() = JSONObject().apply {
    put("name", name); put("instruction", instruction)
    durationMin?.let { put("durationMin", it) }
    durationSeconds?.let { put("durationSeconds", it) }
    distanceKm?.let { put("distanceKm", it) }
    put("intensity", intensity); put("rpeRange", rpeRange); put("repeatCount", repeatCount); put("targetMode", targetMode)
    targetPaceMinValue?.let { put("paceFasterMinKm", PaceRange.format(it)) }
    targetPaceMaxValue?.let { put("paceSlowerMinKm", PaceRange.format(it)) }
    paceZone?.let { put("paceZone", it) }
    zoneBasePaceFastValue?.let { put("zoneBasePaceFastMinKm", PaceRange.format(it)) }
    zoneBasePaceSlowValue?.let { put("zoneBasePaceSlowMinKm", PaceRange.format(it)) }
    zoneIntensityMinPercent?.let { put("zoneIntensityMinPercent", it) }
    zoneIntensityMaxPercent?.let { put("zoneIntensityMaxPercent", it) }
    goalPaceReferenceSecondsPerKm?.let { put("goalPaceReferenceSecondsPerKm", it) }
    recoveryMode?.let { put("recoveryMode", it) }
}

private fun JSONObject.toSnapshotSegment() = WorkoutSegment(
    name = optString("name"), instruction = optString("instruction"),
    durationMin = if (has("durationMin")) optInt("durationMin") else null,
    durationSeconds = if (has("durationSeconds")) optInt("durationSeconds") else null,
    distanceKm = if (has("distanceKm")) optDouble("distanceKm") else null,
    intensity = optString("intensity", "LOW"), rpeRange = optString("rpeRange", "2-3"),
    repeatCount = optInt("repeatCount", 1),
    targetMode = optString("targetMode", if (has("durationMin") || has("durationSeconds")) "TIME" else "DISTANCE"),
    targetPaceMinValue = optString("paceFasterMinKm").takeIf { it.isNotBlank() }?.let { PaceRange.parsePace(it) },
    targetPaceMaxValue = optString("paceSlowerMinKm").takeIf { it.isNotBlank() }?.let { PaceRange.parsePace(it) },
    paceZone = optString("paceZone").takeIf { it.isNotBlank() },
    zoneBasePaceFastValue = optString("zoneBasePaceFastMinKm").takeIf { it.isNotBlank() }?.let { PaceRange.parsePace(it) },
    zoneBasePaceSlowValue = optString("zoneBasePaceSlowMinKm").takeIf { it.isNotBlank() }?.let { PaceRange.parsePace(it) },
    zoneIntensityMinPercent = if (has("zoneIntensityMinPercent")) optInt("zoneIntensityMinPercent") else null,
    zoneIntensityMaxPercent = if (has("zoneIntensityMaxPercent")) optInt("zoneIntensityMaxPercent") else null,
    goalPaceReferenceSecondsPerKm = if (has("goalPaceReferenceSecondsPerKm")) optInt("goalPaceReferenceSecondsPerKm") else null,
    recoveryMode = optString("recoveryMode").takeIf { it.isNotBlank() }
)

internal data class RetestSessionProgress(
    val scheduledDateIso: String,
    val completed: Boolean,
    val painPresent: Boolean = false,
    val optionalExtra: Boolean = false,
    val competition: Boolean = false,
    val physiologicalTest: Boolean = false
)

internal data class RetestAdherenceResult(
    val eligible: Boolean,
    val plannedSessions: Int,
    val completedSessions: Int,
    val missedSessions: Int,
    val activeWeeks: Int,
    val reason: String
)

internal object RetestCycleEngine {
    const val BLOCK_DAYS = 28L
    const val MIN_PLANNED_SESSIONS = 4
    const val MIN_ACTIVE_WEEKS = 3

    fun blockStart(referenceDate: LocalDate, blockIndex: Int): LocalDate =
        referenceDate.plusDays((blockIndex - 1L) * BLOCK_DAYS + 1L)

    fun blockEnd(referenceDate: LocalDate, blockIndex: Int): LocalDate =
        referenceDate.plusDays(blockIndex * BLOCK_DAYS)

    /** First day after the completed 28-day training block; the test replaces a planned run. */
    fun candidateWeekStart(referenceDate: LocalDate, blockIndex: Int): LocalDate =
        blockEnd(referenceDate, blockIndex).plusDays(1)

    fun evaluateAdherence(sessions: List<RetestSessionProgress>): RetestAdherenceResult {
        val valid = sessions.filterNot { it.optionalExtra || it.competition || it.physiologicalTest }
            .filter { raw -> runCatching { LocalDate.parse(raw.scheduledDateIso) }.isSuccess }
        val planned = valid.size
        val completed = valid.count { it.completed }
        val missed = planned - completed
        val activeWeeks = valid.mapNotNull { raw ->
            runCatching { LocalDate.parse(raw.scheduledDateIso).with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)) }.getOrNull()
        }.distinct().size
        val pain = valid.any { it.painPresent }
        val eligible = planned >= MIN_PLANNED_SESSIONS && activeWeeks >= MIN_ACTIVE_WEEKS &&
            completed > missed && !pain
        val reason = when {
            pain -> "Teste adiado: houve relato de dor durante o ciclo. Preserve a referência atual e retome a avaliação quando estiver recuperado."
            planned < MIN_PLANNED_SESSIONS -> "Histórico insuficiente: foram encontradas $planned sessões planejadas no ciclo; são necessárias pelo menos $MIN_PLANNED_SESSIONS para avaliar a adesão."
            activeWeeks < MIN_ACTIVE_WEEKS -> "Histórico insuficiente: as sessões registradas abrangem apenas $activeWeeks semanas ativas; aguarde um ciclo com pelo menos $MIN_ACTIVE_WEEKS semanas."
            completed <= missed -> "Teste adiado: houve $completed treino(s) concluído(s) e $missed não realizado(s). A adesão precisa ser maior que as faltas para justificar um novo teste."
            else -> "Elegível: $completed de $planned sessões foram concluídas em $activeWeeks semanas ativas."
        }
        return RetestAdherenceResult(eligible, planned, completed, missed, activeWeeks, reason)
    }
}
