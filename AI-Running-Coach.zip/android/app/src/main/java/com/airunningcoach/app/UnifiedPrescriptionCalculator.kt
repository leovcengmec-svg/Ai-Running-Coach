package com.airunningcoach.app

import kotlin.math.roundToInt

internal data class WorkoutMetricSnapshot(
    val distanceKm: Double?,
    val durationSeconds: Int?,
    val paceSecondsPerKm: Int?,
    val distanceEstimated: Boolean = false,
    val durationEstimated: Boolean = false,
    val paceEstimated: Boolean = false
)

/** One arithmetic source for planned and realized distance/time/pace consistency. */
internal object UnifiedPrescriptionCalculator {
    fun planned(
        segments: List<WorkoutSegment>,
        fallbackDistanceKm: Double = 0.0,
        fallbackDurationMinutes: Int = 0
    ): WorkoutMetricSnapshot {
        if (segments.isEmpty()) {
            val distance = fallbackDistanceKm.takeIf { it.isFinite() && it > 0.0 }
            val duration = fallbackDurationMinutes.takeIf { it > 0 }?.times(60)
            val pace = if (distance != null && duration != null) (duration / distance).roundToInt() else null
            return WorkoutMetricSnapshot(distance, duration, pace)
        }

        val calibratedDistance = segments.filter {
            it.recoveryMode != "PASSIVE" && it.targetMode == "DISTANCE" &&
                (it.distanceKm ?: 0.0) > 0.0 && it.targetPaceMinValue != null && it.targetPaceMaxValue != null
        }
        val calibratedKm = calibratedDistance.sumOf { (it.distanceKm ?: 0.0) * it.repeatCount.coerceAtLeast(1) }
        // Infer a pace only from an actual prescribed pace band in another distance
        // block. Never invent a generic 7:00/km estimate when the workout has no pace.
        val inferredPace = if (calibratedKm > 0.0) {
            calibratedDistance.sumOf { segment ->
                val pace = midpoint(segment) ?: return@sumOf 0.0
                (segment.distanceKm ?: 0.0) * segment.repeatCount.coerceAtLeast(1) * pace
            } / calibratedKm
        } else null

        var totalDistanceKm = 0.0
        var totalSeconds = 0.0
        var distanceEstimated = false
        var durationEstimated = false
        var hasUnknownDistance = false
        var hasUnknownDuration = false

        segments.forEach { segment ->
            val repeats = segment.repeatCount.coerceAtLeast(1)
            val explicitPace = midpoint(segment)
            when (segment.targetMode) {
                "TIME" -> {
                    val seconds = (segment.durationMin ?: 0).coerceAtLeast(0) * 60.0 * repeats
                    totalSeconds += seconds
                    when {
                        segment.recoveryMode == "PASSIVE" -> Unit
                        explicitPace != null && explicitPace > 0.0 -> {
                            totalDistanceKm += seconds / explicitPace
                            distanceEstimated = true
                        }
                        segment.distanceKm != null && segment.distanceKm > 0.0 -> {
                            // A distance attached to a time-based block is an existing
                            // estimate from the prescription; do not replace it with a
                            // generic pace from a different stimulus.
                            totalDistanceKm += segment.distanceKm * repeats
                            distanceEstimated = true
                        }
                        inferredPace != null && inferredPace > 0.0 -> {
                            totalDistanceKm += seconds / inferredPace
                            distanceEstimated = true
                        }
                        else -> hasUnknownDistance = true
                    }
                }
                else -> {
                    val distance = (segment.distanceKm ?: 0.0).coerceAtLeast(0.0) * repeats
                    totalDistanceKm += distance
                    when {
                        distance <= 0.0 -> hasUnknownDuration = true
                        explicitPace != null && explicitPace > 0.0 -> totalSeconds += distance * explicitPace
                        segment.durationMin != null && segment.durationMin > 0 -> {
                            totalSeconds += segment.durationMin * 60.0 * repeats
                            durationEstimated = true
                        }
                        inferredPace != null && inferredPace > 0.0 -> {
                            totalSeconds += distance * inferredPace
                            durationEstimated = true
                        }
                        else -> hasUnknownDuration = true
                    }
                }
            }
        }

        // Workout-level totals are the frozen prescription snapshot. They fill only
        // metrics that could not be reconstructed from all individual segments.
        if (fallbackDistanceKm.isFinite() && fallbackDistanceKm > 0.0 && (totalDistanceKm <= 0.0 || hasUnknownDistance)) {
            totalDistanceKm = fallbackDistanceKm
            distanceEstimated = true
        }
        if (fallbackDurationMinutes > 0 && (totalSeconds <= 0.0 || hasUnknownDuration)) {
            totalSeconds = fallbackDurationMinutes * 60.0
            durationEstimated = true
        }
        val distance = totalDistanceKm.takeIf { it > 0.0 && !hasUnknownDistance }
            ?: totalDistanceKm.takeIf { it > 0.0 }
        val duration = totalSeconds.roundToInt().takeIf { it > 0 && !hasUnknownDuration }
            ?: totalSeconds.roundToInt().takeIf { it > 0 }
        val pace = if (distance != null && duration != null) (duration / distance).roundToInt() else null
        return WorkoutMetricSnapshot(
            distanceKm = distance,
            durationSeconds = duration,
            paceSecondsPerKm = pace,
            distanceEstimated = distanceEstimated || hasUnknownDistance,
            durationEstimated = durationEstimated || hasUnknownDuration,
            paceEstimated = distanceEstimated || durationEstimated || hasUnknownDistance || hasUnknownDuration
        )
    }

    fun realized(distanceKm: Double?, durationText: String?): WorkoutMetricSnapshot {
        val distance = distanceKm?.takeIf { it.isFinite() && it > 0.0 }
        val seconds = durationText?.let(PaceCalculator::parseDuration)
        val pace = if (distance != null && seconds != null) (seconds / distance).roundToInt() else null
        return WorkoutMetricSnapshot(distance, seconds, pace)
    }

    private fun midpoint(segment: WorkoutSegment): Double? {
        val fast = segment.targetPaceMinValue ?: return null
        val slow = segment.targetPaceMaxValue ?: return null
        return (fast + slow) / 2.0
    }
}
