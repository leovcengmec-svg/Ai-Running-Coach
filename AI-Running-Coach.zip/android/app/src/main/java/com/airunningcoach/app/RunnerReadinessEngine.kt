package com.airunningcoach.app

/**
 * Converts the onboarding profile into an explainable training-readiness recommendation.
 * The reference ranges are conservative product heuristics informed by observational
 * running-plan data; they are NOT universal physiological minimums or medical clearance.
 */
internal data class RunnerReadinessInput(
    val goalKm: Double,
    val goalCategory: String,
    val declaredLevel: String,
    val experienceMonths: Int = -1,
    val selectedFrequency: Int,
    val weeklyVolumeKm: Double,
    val longestRecentKm: Double,
    /** Number of distinct weeks with running in the previous 4 weeks; -1 means unknown. */
    val activeWeeksLast4: Int = -1,
    val goalIntent: String = TrainingGoalIntent.COMPLETE,
    val targetTimeSeconds: Int? = null,
    val terrainPreference: String = RunningTerrain.ROAD
)

internal data class WeeklyVolumeReference(
    val minKm: Double?,
    val maxKm: Double?,
    val label: String
)

internal data class RunnerReadinessSnapshot(
    val goalBand: String,
    val declaredLevel: String,
    val prescriptionLevel: String,
    val recommendedFrequencyMin: Int,
    val recommendedFrequencyMax: Int,
    val selectedFrequency: Int,
    val weeklyVolumeReference: WeeklyVolumeReference,
    val currentWeeklyVolumeKm: Double,
    val initialRecommendedWeeklyKm: Double,
    val longestRecentKm: Double,
    val activeWeeksLast4: Int,
    val compatibility: String,
    val currentCondition: String,
    val eliteLoadEvidenceCompatible: Boolean,
    val confidence: String,
    val flags: List<String>,
    val recommendation: String
) {
    val frequencyRangeLabel: String
        get() = if (recommendedFrequencyMin == recommendedFrequencyMax) {
            "$recommendedFrequencyMin dia(s)/semana"
        } else "$recommendedFrequencyMin–$recommendedFrequencyMax dias/semana"

    val weeklyVolumeRangeLabel: String
        get() = weeklyVolumeReference.label
}

internal object RunnerReadinessEngine {
    /** Prefer measured distinct weeks only when the recent activity sample is reliable. */
    fun resolveActiveWeeks(reportedWeeks: Int, measuredWeeks: Int, measuredHistoryReliable: Boolean): Int {
        require(reportedWeeks == -1 || reportedWeeks in 0..4)
        require(measuredWeeks in 0..4)
        return if (measuredHistoryReliable) measuredWeeks else reportedWeeks
    }

    private data class MatrixRow(
        val beginner: Pair<Double, Double>?,
        val intermediate: Pair<Double, Double>?,
        val advanced: Pair<Double, Double>?,
        val elite: Pair<Double, Double>?,
        val beginnerDays: IntRange,
        val intermediateDays: IntRange,
        val advancedDays: IntRange,
        val eliteDays: IntRange
    )

    private val mileAndThreeKm = MatrixRow(
        beginner = 8.0 to 12.0, intermediate = 12.0 to 20.0,
        advanced = 20.0 to 35.0, elite = 30.0 to 50.0,
        beginnerDays = 2..3, intermediateDays = 3..4,
        advancedDays = 4..5, eliteDays = 4..6
    )
    private val fiveKm = MatrixRow(
        beginner = 8.0 to 15.0, intermediate = 15.0 to 25.0,
        advanced = 25.0 to 40.0, elite = 35.0 to 55.0,
        beginnerDays = 2..3, intermediateDays = 3..4,
        advancedDays = 4..5, eliteDays = 4..6
    )
    private val tenKm = MatrixRow(
        beginner = 12.0 to 20.0, intermediate = 20.0 to 30.0,
        advanced = 30.0 to 45.0, elite = 40.0 to 65.0,
        beginnerDays = 3..3, intermediateDays = 3..4,
        advancedDays = 4..5, eliteDays = 4..6
    )
    private val fifteenKm = MatrixRow(
        beginner = 15.0 to 25.0, intermediate = 25.0 to 35.0,
        advanced = 35.0 to 50.0, elite = 45.0 to 70.0,
        beginnerDays = 3..4, intermediateDays = 3..4,
        advancedDays = 4..5, eliteDays = 4..6
    )
    private val tenMileAndTwentyKm = MatrixRow(
        beginner = 18.0 to 28.0, intermediate = 25.0 to 38.0,
        advanced = 35.0 to 55.0, elite = 45.0 to 75.0,
        beginnerDays = 3..4, intermediateDays = 3..4,
        advancedDays = 4..5, eliteDays = 4..6
    )
    private val halfMarathon = MatrixRow(
        beginner = 20.0 to 30.0, intermediate = 25.0 to 40.0,
        advanced = 40.0 to 60.0, elite = 50.0 to 80.0,
        beginnerDays = 3..4, intermediateDays = 3..4,
        advancedDays = 4..5, eliteDays = 5..6
    )
    private val twentyFiveToThirtyKm = MatrixRow(
        beginner = null, intermediate = 30.0 to 45.0,
        advanced = 40.0 to 65.0, elite = 50.0 to 85.0,
        beginnerDays = 3..4, intermediateDays = 4..5,
        advancedDays = 4..6, eliteDays = 5..6
    )
    private val marathon = MatrixRow(
        beginner = 25.0 to 35.0, intermediate = 35.0 to 50.0,
        advanced = 50.0 to 75.0, elite = 60.0 to 100.0,
        beginnerDays = 4..4, intermediateDays = 4..5,
        advancedDays = 5..6, eliteDays = 5..6
    )
    private val ultra = MatrixRow(
        beginner = null, intermediate = 40.0 to 55.0,
        advanced = 55.0 to 85.0, elite = 60.0 to 110.0,
        beginnerDays = 3..4, intermediateDays = 4..5,
        advancedDays = 5..6, eliteDays = 5..6
    )
    private val ultra100 = MatrixRow(
        beginner = null, intermediate = null,
        advanced = 65.0 to 100.0, elite = 80.0 to 130.0,
        beginnerDays = 4..4, intermediateDays = 4..5,
        advancedDays = 5..6, eliteDays = 5..6
    )
    private val ultra100Miles = MatrixRow(
        beginner = null, intermediate = null,
        advanced = null, elite = 90.0 to 150.0,
        beginnerDays = 4..4, intermediateDays = 4..5,
        advancedDays = 5..6, eliteDays = 5..6
    )
    private val health = MatrixRow(
        beginner = 6.0 to 15.0, intermediate = 10.0 to 22.0,
        advanced = 15.0 to 30.0, elite = 20.0 to 40.0,
        beginnerDays = 2..3, intermediateDays = 2..4,
        advancedDays = 3..5, eliteDays = 3..6
    )

    fun evaluate(input: RunnerReadinessInput): RunnerReadinessSnapshot {
        require(input.goalKm.isFinite() && input.goalKm in 1.0..200.0)
        require(input.declaredLevel in setOf("Iniciante", "Intermediário", "Avançado", "Elite"))
        require(input.selectedFrequency in 2..6)
        require(input.weeklyVolumeKm.isFinite() && input.weeklyVolumeKm in 0.0..300.0)
        require(input.longestRecentKm.isFinite() && input.longestRecentKm in 0.0..200.0)
        require(input.activeWeeksLast4 == -1 || input.activeWeeksLast4 in 0..4)
        require(input.goalIntent in setOf(TrainingGoalIntent.COMPLETE, TrainingGoalIntent.CONTINUOUS, TrainingGoalIntent.PERSONAL_BEST, TrainingGoalIntent.TARGET_TIME, TrainingGoalIntent.HEALTH))
        require(input.targetTimeSeconds == null || input.targetTimeSeconds in 180..172_800)

        val category = if (input.goalCategory == "HEALTH") "HEALTH" else "PERFORMANCE"
        val row = matrixFor(input.goalKm, category)
        val eliteEvidence = input.declaredLevel == "Elite" &&
            input.experienceMonths >= 60 &&
            input.activeWeeksLast4 >= 3 &&
            input.weeklyVolumeKm >= (row.elite?.first ?: 60.0) * 0.80 &&
            input.longestRecentKm >= minimumRecentLongRunForElite(input.goalKm)

        // A self-selected Elite label does not automatically unlock the elite reference band.
        // Until volume consistency and long-run evidence are compatible, use Advanced guardrails.
        val prescriptionLevel = when (input.declaredLevel) {
            "Elite" -> when {
                eliteEvidence -> "Elite"
                input.experienceMonths < 0 || input.experienceMonths >= 36 -> "Avançado"
                input.experienceMonths >= 12 -> "Intermediário"
                else -> "Iniciante"
            }
            // Legacy V61 profiles do not contain experience duration. Unknown uses
            // one conservative level below the self-declared level; explicit short
            // duration is mapped to the highest level actually supported by months.
            "Avançado" -> when {
                input.experienceMonths < 0 -> "Intermediário"
                input.experienceMonths >= 36 -> "Avançado"
                input.experienceMonths >= 12 -> "Intermediário"
                else -> "Iniciante"
            }
            "Intermediário" -> if (input.experienceMonths < 0 || input.experienceMonths < 12) "Iniciante" else "Intermediário"
            else -> "Iniciante"
        }
        val volumeRange = rangeFor(row, prescriptionLevel)
        val daysRange = daysFor(row, prescriptionLevel)
        val goalBand = when {
            category == "HEALTH" -> "Saúde e qualidade de vida"
            input.goalKm <= 1.7 -> "Milha"
            input.goalKm <= 3.0 -> "3 km"
            input.goalKm <= 5.0 -> "5 km"
            input.goalKm <= 10.0 -> "10 km"
            input.goalKm <= 15.0 -> "15 km"
            input.goalKm <= 20.0 -> "10 milhas / 20 km"
            input.goalKm <= 21.1 -> "Meia maratona"
            input.goalKm <= 30.0 -> "25–30 km"
            input.goalKm <= 42.2 -> "Maratona"
            input.goalKm <= 50.0 -> "Ultramaratona 50 km"
            input.goalKm <= 100.0 -> "Ultramaratona 100 km"
            else -> "Ultramaratona 100 milhas+"
        }
        val compatibility = compatibilityFor(input.goalKm, category, prescriptionLevel)
        val belowVolumeReference = input.weeklyVolumeKm > 0.0 &&
            volumeRange.minKm != null && input.weeklyVolumeKm < volumeRange.minKm
        val aboveVolumeReference = input.weeklyVolumeKm > 0.0 &&
            volumeRange.maxKm != null && input.weeklyVolumeKm > volumeRange.maxKm
        // Consistency and volume are independent signals. Unknown consistency must not
        // be hidden by a volume-band comparison; volume remains a separate flag below.
        val condition = when {
            input.weeklyVolumeKm <= 0.0 || input.activeWeeksLast4 == 0 -> "REINTRODUCTION"
            input.activeWeeksLast4 in 1..2 -> "INCONSISTENT"
            input.activeWeeksLast4 == -1 -> "CONSISTENCY_UNKNOWN"
            belowVolumeReference -> "BELOW_REFERENCE"
            aboveVolumeReference -> "ABOVE_REFERENCE"
            else -> "WITHIN_REFERENCE"
        }
        val flags = buildList {
            if (compatibility == "PREPARATION_REQUIRED") add("GOAL_REQUIRES_PREPARATORY_BASE")
            if (compatibility == "CONDITIONAL") add("GOAL_CONDITIONAL_ON_READINESS")
            if (condition == "REINTRODUCTION") add("REINTRODUCTION_REQUIRED")
            if (condition == "INCONSISTENT") add("RECENT_WEEKS_INCONSISTENT")
            if (belowVolumeReference) add("VOLUME_BELOW_GOAL_REFERENCE")
            if (aboveVolumeReference) add("VOLUME_ABOVE_REFERENCE_RANGE")
            if (condition == "CONSISTENCY_UNKNOWN") add("CONSISTENCY_NOT_REPORTED")
            if (input.targetTimeSeconds != null) add("TARGET_TIME_SET_REQUIRES_PERFORMANCE_VALIDATION")
            if (input.terrainPreference == RunningTerrain.TRAIL) add("TRAIL_PACE_REQUIRES_EFFORT_AND_ELEVATION_CONTEXT")
            if (input.selectedFrequency < daysRange.first) add("SELECTED_FREQUENCY_BELOW_REFERENCE")
            if (input.selectedFrequency > daysRange.last) add("SELECTED_FREQUENCY_ABOVE_REFERENCE")
            if (input.declaredLevel == "Elite" && !eliteEvidence) add("ELITE_LEVEL_NOT_SUPPORTED_BY_CURRENT_LOAD_EVIDENCE")
            if (prescriptionLevel != input.declaredLevel) {
                add(if (input.experienceMonths < 0) "EXPERIENCE_DURATION_UNKNOWN_CONSERVATIVE_LEVEL" else "LEVEL_ADJUSTED_BY_RUNNING_EXPERIENCE_DURATION")
            }
        }
        val confidence = when {
            input.experienceMonths < 0 || input.activeWeeksLast4 < 0 -> "LIMITED"
            input.weeklyVolumeKm <= 0.0 || input.activeWeeksLast4 in 1..2 -> "LOW"
            else -> "MODERATE"
        }
        val recommendation = buildRecommendation(
            input = input,
            goalBand = goalBand,
            prescriptionLevel = prescriptionLevel,
            daysRange = daysRange,
            volumeRange = volumeRange,
            compatibility = compatibility,
            condition = condition,
            eliteEvidence = eliteEvidence,
            belowVolumeReference = belowVolumeReference,
            aboveVolumeReference = aboveVolumeReference
        )
        return RunnerReadinessSnapshot(
            goalBand = goalBand,
            declaredLevel = input.declaredLevel,
            prescriptionLevel = prescriptionLevel,
            recommendedFrequencyMin = daysRange.first,
            recommendedFrequencyMax = daysRange.last,
            selectedFrequency = input.selectedFrequency,
            weeklyVolumeReference = volumeRange,
            currentWeeklyVolumeKm = input.weeklyVolumeKm,
            // Never raise the first week to the matrix minimum. Actual load is the starting point.
            initialRecommendedWeeklyKm = input.weeklyVolumeKm,
            longestRecentKm = input.longestRecentKm,
            activeWeeksLast4 = input.activeWeeksLast4,
            compatibility = compatibility,
            currentCondition = condition,
            eliteLoadEvidenceCompatible = eliteEvidence,
            confidence = confidence,
            flags = flags,
            recommendation = recommendation
        )
    }

    private fun matrixFor(goalKm: Double, category: String): MatrixRow = when {
        category == "HEALTH" -> health
        goalKm <= 3.5 -> mileAndThreeKm
        goalKm <= 5.0 -> fiveKm
        goalKm <= 10.0 -> tenKm
        goalKm <= 15.0 -> fifteenKm
        goalKm <= 20.0 -> tenMileAndTwentyKm
        goalKm <= 21.1 -> halfMarathon
        goalKm <= 30.0 -> twentyFiveToThirtyKm
        goalKm <= 42.2 -> marathon
        goalKm <= 50.0 -> ultra
        goalKm <= 100.0 -> ultra100
        else -> ultra100Miles
    }

    private fun rangeFor(row: MatrixRow, level: String): WeeklyVolumeReference {
        val range = when (level) {
            "Iniciante" -> row.beginner
            "Intermediário" -> row.intermediate
            "Elite" -> row.elite
            else -> row.advanced
        }
        if (range == null) return WeeklyVolumeReference(null, null, "Preparação prévia — sem faixa direta")
        return WeeklyVolumeReference(range.first, range.second, "${format(range.first)}–${format(range.second)} km/semana")
    }

    private fun daysFor(row: MatrixRow, level: String): IntRange = when (level) {
        "Iniciante" -> row.beginnerDays
        "Intermediário" -> row.intermediateDays
        "Elite" -> row.eliteDays
        else -> row.advancedDays
    }

    private fun compatibilityFor(goalKm: Double, category: String, level: String): String = when {
        category == "HEALTH" -> "RECOMMENDED"
        goalKm <= 5.0 -> "RECOMMENDED"
        goalKm <= 10.0 -> if (level == "Iniciante") "CONDITIONAL" else "RECOMMENDED"
        goalKm <= 15.0 -> if (level == "Iniciante") "CONDITIONAL" else "RECOMMENDED"
        goalKm <= 21.1 -> when (level) {
            "Iniciante" -> "PREPARATION_REQUIRED"
            "Intermediário" -> "CONDITIONAL"
            else -> "RECOMMENDED"
        }
        goalKm <= 42.2 -> when (level) {
            "Iniciante" -> "PREPARATION_REQUIRED"
            "Intermediário" -> "CONDITIONAL"
            else -> "RECOMMENDED"
        }
        goalKm <= 50.0 -> when (level) {
            "Iniciante" -> "PREPARATION_REQUIRED"
            "Intermediário" -> "CONDITIONAL"
            else -> "RECOMMENDED"
        }
        goalKm <= 100.0 -> when (level) {
            "Iniciante", "Intermediário" -> "PREPARATION_REQUIRED"
            "Avançado" -> "CONDITIONAL"
            else -> "SPECIALIZED"
        }
        else -> when (level) {
            "Elite" -> "SPECIALIZED"
            else -> "PREPARATION_REQUIRED"
        }
    }

    private fun minimumRecentLongRunForElite(goalKm: Double): Double = when {
        goalKm <= 10.0 -> 8.0
        goalKm <= 21.1 -> 15.0
        goalKm <= 42.2 -> 22.0
        goalKm <= 50.0 -> 28.0
        goalKm <= 100.0 -> 35.0
        else -> 45.0
    }

    private fun buildRecommendation(
        input: RunnerReadinessInput,
        goalBand: String,
        prescriptionLevel: String,
        daysRange: IntRange,
        volumeRange: WeeklyVolumeReference,
        compatibility: String,
        condition: String,
        eliteEvidence: Boolean,
        belowVolumeReference: Boolean,
        aboveVolumeReference: Boolean
    ): String {
        val volumeText = volumeRange.label
        val intentText = when (input.goalIntent) {
            TrainingGoalIntent.CONTINUOUS -> " O foco é correr a distância continuamente."
            TrainingGoalIntent.PERSONAL_BEST -> " O foco é melhorar um recorde, mas o ritmo-alvo depende de prova/teste recente válido."
            TrainingGoalIntent.TARGET_TIME -> " Há um tempo-alvo informado; ele será tratado como meta de desempenho, não como limiar fisiológico medido."
            TrainingGoalIntent.HEALTH -> " O foco é saúde e regularidade, sem obrigação de ritmo competitivo."
            else -> " O foco é completar a distância com progressão compatível."
        }
        val frequencyText = if (daysRange.first == daysRange.last) "${daysRange.first}" else "${daysRange.first} a ${daysRange.last}"
        val compatibilityText = when (compatibility) {
            "PREPARATION_REQUIRED" -> "O objetivo exige uma fase preparatória antes do bloco específico."
            "CONDITIONAL" -> "O objetivo é possível, mas depende de desenvolver a base e validar a tolerância."
            "SPECIALIZED" -> "Objetivo de alta exigência; a preparação precisa ser individualizada."
            else -> "O objetivo é compatível com a estrutura de referência deste perfil."
        }
        val conditionText = when (condition) {
            "REINTRODUCTION" -> "Como não há volume recente consistente, o plano começa com reintrodução por dose baixa/tempo, sem tentar atingir a faixa de referência imediatamente."
            "INCONSISTENT" -> "Apenas ${input.activeWeeksLast4} das últimas quatro semanas tiveram corrida; a frequência escolhida será mantida, mas as doses serão conservadoras até recuperar consistência."
            "BELOW_REFERENCE" -> "O volume atual (${format(input.weeklyVolumeKm)} km/semana) está abaixo da faixa de referência (${volumeText}); o plano começa no histórico real e só aumenta com tolerância documentada."
            "ABOVE_REFERENCE" -> "O volume atual (${format(input.weeklyVolumeKm)} km/semana) está acima da faixa genérica (${volumeText}); o histórico real prevalece e a faixa não será usada para reduzir automaticamente a carga."
            "CONSISTENCY_UNKNOWN" -> "A consistência das quatro semanas não foi informada; a avaliação usa a média e a maior sessão declaradas, com confiança limitada."
            else -> "O volume atual está dentro da faixa de referência, mas continuará sendo ajustado pelo histórico real e pela recuperação."
        }
        val frequencyTextMessage = when {
            input.selectedFrequency < daysRange.first -> "Você escolheu ${input.selectedFrequency} dias, abaixo da referência de $frequencyText. A escolha será respeitada, com menos volume e estímulos mais seletivos."
            input.selectedFrequency > daysRange.last -> "Você escolheu ${input.selectedFrequency} dias, acima da referência de $frequencyText. Os dias serão respeitados, mas os dias extras não receberão intensidade automaticamente."
            else -> "Os ${input.selectedFrequency} dias escolhidos estão dentro da referência de frequência ($frequencyText)."
        }
        val volumeContext = when {
            input.weeklyVolumeKm <= 0.0 -> "Ainda não há volume recente para comparar com a faixa de referência."
            belowVolumeReference -> "A média informada (${format(input.weeklyVolumeKm)} km/semana) está abaixo da referência de ${volumeText}; isso é um contexto de objetivo, não uma indicação para aumentar a carga imediatamente."
            aboveVolumeReference -> "A média informada (${format(input.weeklyVolumeKm)} km/semana) está acima da referência genérica (${volumeText}); o histórico real prevalece e não será reduzido automaticamente."
            else -> "A média informada está dentro da faixa de referência (${volumeText})."
        }
        val eliteText = if (input.declaredLevel == "Elite" && !eliteEvidence) " O nível Elite foi informado, mas a experiência regular, a consistência, o volume e a maior corrida recente ainda não sustentam a faixa Elite; o motor usa temporariamente a referência Avançada." else ""
        val experienceText = if (prescriptionLevel != input.declaredLevel && input.declaredLevel != "Elite") " O tempo de prática informado ainda é curto para sustentar a classificação ${input.declaredLevel}; a prescrição usa guardrails de $prescriptionLevel até acumular mais histórico (intermediário: pelo menos 12 meses; avançado: pelo menos 36 meses)." else ""
        return "$compatibilityText $conditionText $frequencyTextMessage Referência semanal para $goalBand / $prescriptionLevel: $volumeText. $volumeContext O primeiro volume recomendado permanece ${format(input.weeklyVolumeKm)} km/semana; a matriz nunca força um salto até o mínimo da faixa.$eliteText$experienceText$intentText Terreno de referência: ${RunningTerrain.label(input.terrainPreference)}."
    }

    private fun format(value: Double): String = if (value % 1.0 == 0.0) value.toInt().toString() else String.format(java.util.Locale.US, "%.1f", value)
}
