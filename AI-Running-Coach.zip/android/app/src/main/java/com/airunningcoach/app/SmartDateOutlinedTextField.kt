package com.airunningcoach.app

import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldColors
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.TextRange

/**
 * Date field whose selection is deliberately moved to the end after every mask update.
 * This avoids Compose/IME restoring the previous cursor offset when '/' is inserted.
 */
@Composable
internal fun SmartDateOutlinedTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    placeholder: String? = null,
    supportingText: String? = null,
    colors: TextFieldColors? = null
) {
    var fieldValue by remember { mutableStateOf(dateTextFieldValue(value)) }

    LaunchedEffect(value) {
        if (fieldValue.text != value) fieldValue = dateTextFieldValue(value)
    }

    OutlinedTextField(
        value = fieldValue,
        onValueChange = { incoming ->
            val updated = dateTextFieldValue(incoming.text)
            fieldValue = updated
            if (updated.text != value) onValueChange(updated.text)
        },
        label = { Text(label) },
        placeholder = placeholder?.let { text -> { Text(text) } },
        supportingText = supportingText?.let { text -> { Text(text) } },
        modifier = modifier,
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        colors = colors ?: OutlinedTextFieldDefaults.colors()
    )
}

internal fun dateTextFieldValue(raw: String): TextFieldValue {
    val formatted = SmartInputMask.date(raw)
    return TextFieldValue(formatted, selection = TextRange(formatted.length))
}
