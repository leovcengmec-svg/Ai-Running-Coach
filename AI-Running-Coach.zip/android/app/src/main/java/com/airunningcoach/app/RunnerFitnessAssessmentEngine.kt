package com.airunningcoach.app

/**
 * Converts a field-test VO2 estimate into a stable physiological fitness band.
 * Reference cutoffs are adapted from Mandsager et al. (JAMA Netw Open, 2018),
 * Table 2: age/sex-stratified treadmill MET categories. METs are converted using
 * 1 MET = 3.5 mL/kg/min. Because the source cohort consisted of adults referred
 * for treadmill testing, this is a general cardiorespiratory-fitness reference,
 * not a competitive-running ranking or clinical diagnosis.
 */
internal object RunnerFitnessAssessmentEngine {
    const val MALE = "MASCULINO"
    const val FEMALE = "FEMININO"

    data class Thresholds(val intermediate: Double, val performance: Double, val elite: Double) {
        fun label(vo2Max: Double): String = when {
            vo2Max >= elite -> "Elite"
            vo2Max >= performance -> "Performance"
            vo2Max >= intermediate -> "Intermediário"
            else -> "Iniciante"
        }
    }

    data class Assessment(
        val vo2Max: Double,
        val level: String,
        val confidence: String,
        val referenceLabel: String,
        val thresholds: Thresholds
    )

    fun normalizeLevel(level: String): String = when (level.trim()) {
        "Avançado" -> "Performance" // V1–V66 compatibility
        "Performance" -> "Performance"
        "Iniciante", "Intermediário", "Elite" -> level.trim()
        else -> "Iniciante"
    }

    fun thresholds(ageYears: Int, referenceSex: String): Thresholds? {
        if (ageYears !in 18..120) return null
        val sex = referenceSex.uppercase()
        if (sex !in setOf(MALE, FEMALE)) return null
        val row = when {
            ageYears <= 19 -> 0
            ageYears <= 29 -> 1
            ageYears <= 39 -> 2
            ageYears <= 49 -> 3
            ageYears <= 59 -> 4
            ageYears <= 69 -> 5
            ageYears <= 79 -> 6
            else -> 7
        }
        // Table 2 cutoffs in METs: start of Above Average, High and Elite groups.
        val values = if (sex == FEMALE) listOf(
            Triple(11.1, 13.0, 15.0), Triple(10.0, 11.5, 14.3),
            Triple(9.4, 10.9, 13.7), Triple(9.0, 10.4, 13.3),
            Triple(8.1, 10.0, 13.0), Triple(7.0, 8.5, 11.1),
            Triple(6.0, 7.0, 10.0), Triple(5.5, 6.3, 8.4)
        ) else listOf(
            Triple(13.0, 14.0, 16.3), Triple(12.0, 13.7, 15.7),
            Triple(11.2, 13.0, 15.0), Triple(11.0, 12.5, 14.7),
            Triple(10.0, 11.4, 14.0), Triple(8.5, 10.0, 13.0),
            Triple(7.0, 8.5, 11.5), Triple(6.3, 7.3, 10.0)
        )
        val t = values[row]
        return Thresholds(t.first * 3.5, t.second * 3.5, t.third * 3.5)
    }

    fun parseDurationSeconds(value: String): Int? {
        val text = value.trim()
        if (!Regex("^\\d{1,2}:[0-5]\\d$").matches(text)) return null
        val parts = text.split(":")
        val minutes = parts[0].toIntOrNull() ?: return null
        val seconds = parts[1].toIntOrNull() ?: return null
        return minutes * 60 + seconds
    }

    fun assess(vo2Max: Double, ageYears: Int, referenceSex: String, confidence: String): Assessment? {
        if (!vo2Max.isFinite() || vo2Max !in 10.0..100.0) return null
        val thresholds = thresholds(ageYears, referenceSex) ?: return null
        return Assessment(
            vo2Max = vo2Max,
            level = thresholds.label(vo2Max),
            confidence = confidence,
            referenceLabel = "Referência de aptidão cardiorrespiratória por idade e sexo",
            thresholds = thresholds
        )
    }
}
