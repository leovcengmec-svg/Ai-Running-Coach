package com.airunningcoach.app

internal data class TrainingTypeDefinition(
    val id: String,
    val title: String,
    val zone: String,
    val objective: String,
    val structure: String,
    val use: String
)

/** Catálogo de estímulos do produto; o status de prescrição diferencia uso automático, condicional e não integrado. */
internal object TrainingTypeCatalog {
    val all = listOf(
        TrainingTypeDefinition("RUN_WALK", "Corrida/caminhada", "Z1–Z2", "Construir tolerância à corrida com pausas planejadas", "Alternância por tempo entre corrida leve e caminhada, com aquecimento e desaquecimento", "Iniciantes ou atletas retornando após pausa; respeita os 2–6 dias selecionados, com dose reduzida e recuperação planejada"),
        TrainingTypeDefinition("RECOVERY", "Rodagem regenerativa", "Z1", "Facilitar a recuperação entre sessões", "Corrida curta, contínua e muito confortável", "Após qualidade, em semana regenerativa ou quando a recuperação pedir redução"),
        TrainingTypeDefinition("EASY_AEROBIC", "Rodagem aeróbia", "Z2", "Construir consistência e base aeróbia", "Corrida contínua em Z2 ou dividida em blocos progressivos Z2→Z2 rápida→Z3 e regressivos Z3→Z2→Z2 confortável; Z1 somente no aquecimento/desaquecimento", "Sessão mais frequente do plano; as variações permanecem leves e não substituem o treino de qualidade"),
        TrainingTypeDefinition("LONG_RUN", "Longão aeróbio", "Z2", "Desenvolver resistência prolongada", "Predominância Z2, com blocos progressivos Z2→Z3 ou regressivos Z3→Z2; sem Z1 na parte principal e Z3 curto somente em atleta experiente e elegível", "Quando o histórico recente sustentar a duração; a semana regenerativa permanece leve e contínua"),
        TrainingTypeDefinition("STEADY_RUN", "Corrida moderada", "Z3", "Sustentar ritmo moderado sem atingir o limiar", "Bloco contínuo ou progressivo", "Corredores com base e recuperação adequadas"),
        TrainingTypeDefinition("TEMPO_RUN", "Tempo controlado (Z4 estimada)", "Z4", "Desenvolver tolerância ao esforço sustentado", "Aquecimento, bloco contínuo controlado e desaquecimento; pace e RPE se complementam", "Quando a carga e a experiência permitirem; Z4 não confirma LT2 medido"),
        TrainingTypeDefinition("AEROBIC_INTERVAL_Z2", "Intervalado aeróbio", "Z2", "Acumular trabalho aeróbio em blocos com recuperação leve", "Repetições de Z2 confortável e Z2 mais rápida, com recuperação Z2 muito leve", "Alternativa para variar a rodagem sem elevar para limiar; automático conforme fase e volume"),
        TrainingTypeDefinition("AEROBIC_INTERVAL_Z2_Z3", "Intervalado aeróbio misto", "Z2–Z3", "Desenvolver resistência aeróbia com mudanças controladas de intensidade", "Blocos Z2 e entradas curtas em Z3, separados por recuperação confortável em Z2", "Condicional à experiência, tolerância e recuperação"),
        TrainingTypeDefinition("MIXED_INTERVAL_Z3_Z4", "Intervalado misto de limiar", "Z3–Z4", "Desenvolver sustentação de ritmo moderado e próximo ao limiar estimado", "Blocos de Z3 alta e Z4 inicial, com recuperação aeróbia Z2", "Condicional a base, zonas estimadas e recuperação; Z4 não equivale a LT2 medido"),
        TrainingTypeDefinition("CRUISE_INTERVAL_Z3_Z4", "Cruise intervals", "Z3–Z4", "Acumular tempo de qualidade próximo ao limiar com repetições sustentáveis", "Repetições mais longas em Z3 alta/Z4 inicial, intercaladas com recuperação Z2", "Condicional à consistência, carga recente e recuperação; não representa LT2 medido"),
        TrainingTypeDefinition("MIXED_INTERVAL_Z2_Z4", "Intervalado aeróbio com estímulo de limiar", "Z2–Z4", "Combinar base aeróbia e estímulo controlado de limiar", "Blocos Z2, estímulo Z4 inicial e recuperação Z2 confortável", "Condicional a base suficiente, zona confiável e recuperação adequada"),
        TrainingTypeDefinition("MIXED_INTERVAL_Z4_Z5", "Intervalado de potência aeróbia", "Z4–Z5", "Acumular estímulos curtos de alta intensidade sem sprint máximo", "Blocos controlados Z4, entradas curtas Z5 e recuperação Z2", "Somente para atletas experientes e carga recente adequada; Z5 não confirma VO₂máx medido"),
        TrainingTypeDefinition("PYRAMID_INTERVAL_Z3_Z5", "Intervalado piramidal", "Z3–Z5", "Variar estímulos moderados e intensos de forma progressiva e regressiva", "Sequência Z3→Z4→Z5→Z4→Z3 com recuperações em Z2", "Condicional a perfil avançado/elite, volume e prontidão favoráveis"),
        TrainingTypeDefinition("FARTLEK_PYRAMID_Z3_Z5", "Fartlek piramidal", "Z3–Z5", "Alternar períodos de intensidade crescente e decrescente por tempo", "Blocos piramidais curtos em Z3/Z4/Z5 com recuperações leves em Z2", "Condicional a atleta avançado, zona estimada e recuperação adequada"),
        TrainingTypeDefinition("THRESHOLD_INTERVAL", "Intervalos controlados (Z4 estimada)", "Z3–Z4", "Acumular tempo de qualidade próximo do esforço de limiar estimado", "Repetições controladas com recuperação leve", "Alternativa ao tempo contínuo; a faixa não substitui avaliação fisiológica"),
        TrainingTypeDefinition("VO2_MAX_INTERVAL", "Intervalos de alta intensidade (Z5 estimada)", "Z4–Z5", "Desenvolver potência aeróbia com esforços curtos", "Repetições intensas e recuperações suficientes", "Somente para corredores experientes com tolerância documentada; Z5 não significa VO₂máx medido"),
        TrainingTypeDefinition("MARATHON_SPECIFIC", "Resistência específica de maratona", "Z2–Z3", "Construir resistência específica para a maratona sem excesso de intensidade", "Bloco aeróbio predominante em Z2 com final moderado opcional em Z3", "Selecionado em ciclos cujo objetivo principal é maratona, conforme a fase e a carga"),
        TrainingTypeDefinition("ULTRA_SPECIFIC", "Resistência específica de ultradistância", "Z2", "Desenvolver tempo em movimento e resistência prolongada", "Blocos longos sustentáveis em Z2, com estratégia corrida/caminhada e recuperação", "Ciclos de ultradistância; foco em duração, terreno, abastecimento e tolerância, não em velocidade máxima"),
        TrainingTypeDefinition("FARTLEK", "Fartlek", "Z2–Z4", "Variar intensidade dentro de uma corrida", "Alternância de blocos moderados/fortes e leves", "Quando houver necessidade de variar o estímulo"),
        TrainingTypeDefinition("FARTLEK_PYRAMID", "Fartlek piramidal", "Z3–Z5", "Variar intensidade em uma sequência crescente e decrescente", "Blocos progressivos e regressivos com picos curtos; recuperação leve entre blocos", "Somente quando quatro dias, carga, zonas e recuperação sustentarem o estímulo de potência aeróbia"),
        TrainingTypeDefinition("HILL_REPEATS", "Repetições em subida", "Z3–Z5 por esforço", "Desenvolver força específica, potência e mecânica em aclive", "Subidas controladas por tempo e RPE; recuperação caminhando ou trotando na descida", "Condicional a percurso com inclinação conhecida; pace plano não deve ser aplicado à subida"),
        TrainingTypeDefinition("STRIDES", "Acelerações (strides)", "Técnica", "Melhorar coordenação e economia de corrida", "Acelerações curtas, soltas e com recuperação completa; não perseguir um pace específico", "Complemento ocasional em rodagem fácil, sem sprint máximo"),
        TrainingTypeDefinition("PROGRESSION_RUN", "Corrida progressiva", "Z2–Z3", "Praticar controle de ritmo sob fadiga leve", "Aquecimento em Z1 rápida, progressão principal Z2 confortável→Z2 rápida→Z3 controlada quando elegível e desaquecimento em Z1 rápida", "Quando o atleta já controla bem o ritmo fácil")
    )

    fun find(id: String): TrainingTypeDefinition? = all.firstOrNull { it.id == id }

    /** Descreve a integração real do motor; a presença no catálogo não significa prescrição automática. */
    fun prescriptionStatus(id: String): String = when (id) {
        "RUN_WALK" -> "Automático"
        "RECOVERY" -> "Automático"
        "EASY_AEROBIC" -> "Automático"
        "LONG_RUN" -> "Automático"
        "STEADY_RUN" -> "Condicional"
        "TEMPO_RUN" -> "Condicional"
        "AEROBIC_INTERVAL_Z2" -> "Automático"
        "AEROBIC_INTERVAL_Z2_Z3" -> "Condicional"
        "MIXED_INTERVAL_Z3_Z4" -> "Condicional"
        "CRUISE_INTERVAL_Z3_Z4" -> "Condicional"
        "MIXED_INTERVAL_Z2_Z4" -> "Condicional"
        "MIXED_INTERVAL_Z4_Z5" -> "Condicional"
        "PYRAMID_INTERVAL_Z3_Z5" -> "Condicional"
        "FARTLEK_PYRAMID_Z3_Z5" -> "Condicional"
        "THRESHOLD_INTERVAL" -> "Condicional"
        "VO2_MAX_INTERVAL" -> "Condicional"
        "MARATHON_SPECIFIC" -> "Condicional"
        "ULTRA_SPECIFIC" -> "Condicional"
        "FARTLEK" -> "Condicional"
        "FARTLEK_PYRAMID" -> "Condicional — alta intensidade"
        "HILL_REPEATS" -> "Condicional — percurso"
        "STRIDES" -> "Complementar"
        "PROGRESSION_RUN" -> "Automático"
        else -> "Não integrado — referência"
    }

    fun prescriptionDetail(id: String): String = when (id) {
        "RUN_WALK" -> "Gerado para iniciantes ou reintrodução, em blocos alternados de corrida e caminhada. Mantém a frequência de 2–6 dias escolhida; ajusta a dose e a intensidade de cada sessão."
        "RECOVERY" -> "Entra em semanas regenerativas ou quando os indicadores de recuperação/fadiga pedem redução de carga."
        "EASY_AEROBIC" -> "É a sessão padrão de baixa intensidade; alterna blocos contínuos Z2, progressivos Z2 confortável (0–20%)→Z2 rápida e, quando elegível, Z2→Z3 controlada; regressivos fazem o caminho inverso. Z1 fica apenas no aquecimento e desaquecimento."
        "LONG_RUN" -> "É gerado como a maior sessão da semana, limitado pelo histórico recente e pelo objetivo. A parte principal permanece em Z2 e pode ser progressiva Z2→Z3 ou regressiva Z3→Z2; Z3 ocupa no máximo 12% da parte principal e exige perfil avançado/elite, volume semanal ≥25 km, maior corrida recente ≥12 km, longão planejado ≥8 km e recuperação adequada. Z1 é reservada ao aquecimento/desaquecimento."
        "STEADY_RUN" -> "Pode ser selecionado pelo motor conforme distância-alvo, fase do ciclo e elegibilidade para qualidade."
        "TEMPO_RUN" -> "Bloco contínuo de 10–20 minutos em Z3 controlada ou Z4 estimada conforme volume, histórico e recuperação; Z4 não representa limiar laboratorial medido."
        "AEROBIC_INTERVAL_Z2" -> "Blocos repetidos em Z2 confortável e Z2 mais rápida, com recuperação também em Z2. Serve para variar a rodagem sem entrar no limiar."
        "AEROBIC_INTERVAL_Z2_Z3" -> "Intervalos aeróbios com entradas curtas na parte baixa da Z3 e recuperação em Z2; adequado quando a resposta à carga permite intensidade moderada."
        "MIXED_INTERVAL_Z3_Z4" -> "Intervalos controlados que alternam Z3 alta e entrada de Z4 estimada, com recuperação em Z2. Para atletas com volume, tolerância e recuperação compatíveis; a zona é estimativa, não limiar laboratorial."
        "MIXED_INTERVAL_Z4_Z5" -> "Intervalos de potência aeróbia com trabalho principal em Z4 e entradas curtas em Z5 estimada. Só entram com base consistente, prontidão alta e recuperação suficiente; nunca são sprints máximos."
        "PYRAMID_INTERVAL_Z3_Z5" -> "Pirâmide progressiva e regressiva Z3→Z4→Z5→Z4→Z3, com recuperações em Z2. Requer elegibilidade avançada e dose curta; Z5 é estimada e não uma medição direta de VO₂máx."
        "CRUISE_INTERVAL_Z3_Z4" -> "Repetições mais longas em Z3 alta/Z4 inicial com recuperação Z2; pode substituir tempo contínuo em ciclos específicos."
        "MIXED_INTERVAL_Z2_Z4" -> "Combina blocos aeróbios Z2 com estímulos breves de Z4 estimada e recuperação Z2."
        "FARTLEK_PYRAMID_Z3_Z5" -> "Alterna durações e intensidades em formato piramidal; Z5 é estimada e só entra com elegibilidade avançada."
        "THRESHOLD_INTERVAL" -> "Pode substituir tempo contínuo em ciclos selecionados; a Z4 é estimada, não limiar medido."
        "VO2_MAX_INTERVAL" -> "Restrito a perfis experientes e condições de carga adequadas; Z5 estimada não confirma VO₂máx medido."
        "MARATHON_SPECIFIC" -> "Entra em ciclos de maratona nas semanas de desenvolvimento específico, com Z2 predominante e trecho Z3 opcional."
        "ULTRA_SPECIFIC" -> "Prioriza tempo em movimento, Z2 sustentável, estratégia corrida/caminhada e prática de abastecimento; o pace é secundário em terreno variável."
        "FARTLEK" -> "Alternativa de qualidade usada em ciclos selecionados, com blocos fortes e recuperações leves. A intensidade depende da dose e da recuperação."
        "FARTLEK_PYRAMID" -> "Fartlek piramidal da biblioteca: alterna Z3, Z4 e entradas breves em Z5 estimada. Só é selecionado quando a elegibilidade de potência aeróbia está cumprida (frequência mínima de quatro dias, volume e maior sessão compatíveis, consistência e recuperação favorável)."
        "HILL_REPEATS" -> "A biblioteca descreve o estímulo, mas a geração automática exige perfil de elevação/rota; até haver percurso conhecido, a indicação permanece condicional e orientada por RPE/tempo, nunca pelo pace plano."
        "STRIDES" -> "Pode ser inserido como acelerações técnicas dentro de uma rodagem fácil; não é sessão isolada."
        "PROGRESSION_RUN" -> "É selecionado como sessão de qualidade em fases iniciais de ciclos de 5 km e 10 km; a parte principal progride somente em Z2/Z3, conforme elegibilidade, enquanto Z1 fica restrita ao aquecimento e desaquecimento."
        else -> "Este estímulo está documentado na biblioteca, mas ainda não possui seleção automática neste ciclo. O treinador deve priorizar sessões compatíveis com objetivo, fase, zonas e tolerância à carga."
    }
}

internal data class StrengthRoutineDefinition(
    val title: String,
    val duration: String,
    val focus: String,
    val exercises: String,
    val guidance: String
)

/** Optional complementary work; these sessions are deliberately not inserted into the running calendar. */
internal object StrengthTrainingCatalog {
    val all = listOf(
        StrengthRoutineDefinition(
            "Força A — base e panturrilhas", "20–30 min", "Agachamento, quadril, panturrilhas e estabilidade do tronco",
            "Agachamento • avanço assistido • elevação de panturrilha • ponte de glúteos • prancha",
            "Comece com 1–2 séries por exercício, movimento controlado e margem de 2–3 repetições."
        ),
        StrengthRoutineDefinition(
            "Força B — unilateral e posterior", "20–30 min", "Estabilidade unilateral, posterior de coxa e controle pélvico",
            "Step-up baixo • levantamento terra romeno leve • panturrilha unilateral assistida • bird-dog • prancha lateral",
            "Use amplitude confortável, sem dor e sem chegar à falha. Como referência inicial: 8–12 repetições, 10–15 elevações de panturrilha e 20–30 s nas pranchas. Iniciantes podem alternar A e B em semanas diferentes."
        )
    )
}
