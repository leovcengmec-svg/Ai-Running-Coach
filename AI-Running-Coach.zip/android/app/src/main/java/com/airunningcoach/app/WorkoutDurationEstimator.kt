package com.airunningcoach.app

import kotlin.math.ceil

/** Duration facade retained for existing call sites; arithmetic is centralized in V79. */
internal object WorkoutDurationEstimator {
    fun estimateMinutes(
        segments: List<WorkoutSegment>,
        fallbackDistanceKm: Double = 0.0,
        fallbackDurationMin: Int = 0
    ): Int {
        val snapshot = UnifiedPrescriptionCalculator.planned(segments, fallbackDistanceKm, fallbackDurationMin)
        val seconds = snapshot.durationSeconds ?: return fallbackDurationMin.coerceAtLeast(0)
        return ceil(seconds / 60.0).toInt().coerceAtLeast(1)
    }
}
