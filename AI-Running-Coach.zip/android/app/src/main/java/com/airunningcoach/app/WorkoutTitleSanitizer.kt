package com.airunningcoach.app

/** Removes internal library/protocol identifiers from athlete-facing workout names only. */
internal object WorkoutTitleSanitizer {
    private val internalCode = Regex("(?i)\\b(?:FOR|INT|I)\\s*0?\\d{1,2}\\b")
    private val legacyRodCode = Regex("(?i)\\bROD\\b")
    private val separators = Regex("\\s*[·|–—:/_-]+\\s*")
    private val spaces = Regex("\\s+")
    private val redundantZoneIndex = Regex("(?i)\\b(Z[1-5])\\s+\\d+\\s*$")

    fun clean(title: String, fallback: String = "Treino"): String {
        val cleaned = title.replace(redundantZoneIndex, "$1")
            .replace(internalCode, " ").replace(legacyRodCode, " ")
            .replace(separators, " ").replace(spaces, " ").trim(' ', '-', '·', '|', '/', ':', '_')
        return cleaned.ifBlank { fallback.trim().ifBlank { "Treino" } }
    }
}
