package com.airunningcoach.app

import java.time.LocalDate
import java.time.DayOfWeek
import java.time.temporal.ChronoUnit
import java.time.temporal.TemporalAdjusters

/** Pure migration helpers so restored legacy plans can be regenerated without losing history. */
internal object PlanMigrationEngine {
    fun requiresMigration(storedEngineVersion: Int, currentEngineVersion: Int, hasSavedPlan: Boolean): Boolean =
        hasSavedPlan && storedEngineVersion < currentEngineVersion



    /**
     * Infers the original cycle Monday from the date/week pairs stored in each session.
     * This repairs backups where planStartDateIso was already rebased to the import week,
     * while older sessions still carry their original cycle week numbers.
     */
    fun inferRestoredCycleAnchor(savedStartDateIso: String, workouts: List<Workout>): LocalDate? {
        val savedAnchor = runCatching { LocalDate.parse(savedStartDateIso) }.getOrNull()
            ?.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val eligible = workouts.filter { !it.isOptionalExtra && !it.manuallyRescheduled }
        val datedSessions = eligible.mapNotNull { workout ->
            runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull()
                ?.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        }
        val evidence = eligible.asSequence()
            .filter { it.week in 1..16 }
            .mapNotNull { workout ->
                val date = runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull() ?: return@mapNotNull null
                val monday = date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
                monday.minusWeeks((workout.week - 1).toLong())
            }
            .groupingBy { it }
            .eachCount()
        val strongest = evidence.entries.sortedWith(
            compareByDescending<Map.Entry<LocalDate, Int>> { it.value }
                .thenBy { if (it.key == savedAnchor) 0 else 1 }
                .thenBy { it.key }
        ).firstOrNull()
        if (savedAnchor != null) {
            val candidate = strongest?.key
            val candidateCount = strongest?.value ?: 0
            val savedCount = evidence[savedAnchor] ?: 0
            val candidateIsPlausible = candidate != null && candidate.isBefore(savedAnchor) &&
                ChronoUnit.WEEKS.between(candidate, savedAnchor) in 1L..16L
            if (candidateIsPlausible && candidateCount >= 2 && candidateCount > savedCount) return candidate
            // Fallback for older records whose week field is missing/shifted: two or
            // more core sessions in the immediately preceding Monday-to-Sunday block,
            // outnumbering sessions in the saved anchor week, are strong evidence that
            // the stored start date was rebased one week too late.
            val previousMonday = savedAnchor.minusWeeks(1)
            val previousDateCount = datedSessions.count { it == previousMonday }
            val savedDateCount = datedSessions.count { it == savedAnchor }
            if (previousDateCount >= 2 && previousDateCount > savedDateCount) return previousMonday
            return savedAnchor
        }
        if (strongest != null && strongest.value >= 2) return strongest.key
        return datedSessions.minOrNull()
    }

    /**
     * Restores an in-progress cycle from its saved Monday anchor instead of silently
     * restarting it at the import date. This is valid only while the saved cycle is active.
     */
    fun restoredPlanWindow(
        savedStartDateIso: String,
        savedWeeks: Int,
        events: List<RaceEvent>,
        today: LocalDate
    ): PlanWindow? {
        val savedStart = runCatching { LocalDate.parse(savedStartDateIso) }.getOrNull() ?: return null
        val anchor = savedStart.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val weeks = savedWeeks.coerceIn(4, 16)
        if (anchor.isAfter(today) || !today.isBefore(anchor.plusWeeks(weeks.toLong()))) return null
        val endExclusive = anchor.plusWeeks(weeks.toLong())
        val primary = events.asSequence()
            .filter { it.status == "PLANNED" }
            .mapNotNull { event -> event.dateOrNull()?.let { event to it } }
            .filter { (_, date) -> !date.isBefore(anchor) && !date.isBefore(today) && date.isBefore(endExclusive) }
            .sortedWith(compareBy<Pair<RaceEvent, LocalDate>> {
                when (it.first.priority) { "A" -> 0; "B" -> 1; else -> 2 }
            }.thenBy { it.second })
            .firstOrNull()
        val raceWeek = primary?.second?.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            ?.let { (ChronoUnit.DAYS.between(anchor, it) / 7L).toInt() + 1 }
        return PlanWindow(
            startDate = anchor,
            weeks = weeks,
            primaryRaceId = primary?.first?.id,
            raceWeek = raceWeek,
            raceInsideWindow = primary != null,
            note = "Ciclo original restaurado a partir de ${anchor}. A numeração das semanas foi preservada."
        )
    }


    /**
     * A backup is authoritative for the past. Regenerate only sessions scheduled on
     * or after today; past sessions remain visible only when they actually exist in
     * the restored backup. When an original cycle window is supplied, keep candidates
     * inside that window as well.
     */
    fun currentAndFutureCycleSessions(
        sessions: List<PrescribedWorkout>,
        today: LocalDate,
        cycleStart: LocalDate? = null,
        cycleWeeks: Int? = null
    ): List<PrescribedWorkout> {
        val anchor = cycleStart?.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val endExclusive = if (anchor != null && cycleWeeks != null) anchor.plusWeeks(cycleWeeks.coerceIn(4, 16).toLong()) else null
        return sessions.filter { session ->
            val date = runCatching { LocalDate.parse(session.scheduledDateIso) }.getOrNull() ?: return@filter false
            !date.isBefore(today) && (anchor == null || (!date.isBefore(anchor) && (endExclusive == null || date.isBefore(endExclusive))))
        }
    }

    /** Rebuilds week numbers from the saved cycle anchor, not from the import date. */
    fun normalizeCycleWeekNumbers(workouts: List<Workout>, planStartDate: LocalDate): List<Workout> {
        val anchor = planStartDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        return workouts.map { workout ->
            val date = runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull() ?: return@map workout
            val monday = date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            if (monday.isBefore(anchor)) workout
            else workout.copy(week = (ChronoUnit.DAYS.between(anchor, monday) / 7L).toInt() + 1)
        }
    }

    fun preserveCompleted(workouts: List<Workout>, feedbackSessionIds: Set<String>): List<Workout> =
        workouts.filter { it.done || it.sessionId in feedbackSessionIds }
            .map { workout -> if (workout.sessionId in feedbackSessionIds) workout.copy(done = true) else workout }

    /** Keep every past calendar entry during a plan upgrade, even when a legacy backup
     * did not persist its done flag/feedback consistently. Past entries remain pending
     * or completed exactly as recorded; they are never silently discarded. */
    fun preserveHistoryAndCompleted(
        workouts: List<Workout>,
        feedbackSessionIds: Set<String>,
        today: LocalDate
    ): List<Workout> = workouts.filter { workout ->
        val date = runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull()
        workout.done || workout.sessionId in feedbackSessionIds || date == null || date.isBefore(today)
    }.map { workout ->
        if (workout.sessionId in feedbackSessionIds) workout.copy(done = true) else workout
    }

    fun pendingOptionalExtras(
        workouts: List<Workout>,
        today: LocalDate,
        feedbackSessionIds: Set<String>
    ): List<Workout> = workouts.filter { workout ->
        workout.isOptionalExtra && !workout.done && workout.sessionId !in feedbackSessionIds &&
            (runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull()?.isBefore(today) == false)
    }

    fun merge(
        completed: List<Workout>,
        pendingExtras: List<Workout>,
        regeneratedFutureSessions: List<Workout>
    ): List<Workout> = (completed + pendingExtras + regeneratedFutureSessions)
        .distinctBy { it.sessionId }
        .sortedBy { it.scheduledDateIso }
}
