package com.airunningcoach.app

import java.time.LocalDate

/** Pure migration helpers so restored legacy plans can be regenerated without losing history. */
internal object PlanMigrationEngine {
    fun requiresMigration(storedEngineVersion: Int, currentEngineVersion: Int, hasSavedPlan: Boolean): Boolean =
        hasSavedPlan && storedEngineVersion < currentEngineVersion

    fun preserveCompleted(workouts: List<Workout>, feedbackSessionIds: Set<String>): List<Workout> =
        workouts.filter { it.done || it.sessionId in feedbackSessionIds }
            .map { workout -> if (workout.sessionId in feedbackSessionIds) workout.copy(done = true) else workout }

    /** Keep every past calendar entry during a plan upgrade, even when a legacy backup
     * did not persist its done flag/feedback consistently. Past entries remain pending
     * or completed exactly as recorded; they are never silently discarded. */
    fun preserveHistoryAndCompleted(
        workouts: List<Workout>,
        feedbackSessionIds: Set<String>,
        today: LocalDate
    ): List<Workout> = workouts.filter { workout ->
        val date = runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull()
        workout.done || workout.sessionId in feedbackSessionIds || date == null || date.isBefore(today)
    }.map { workout ->
        if (workout.sessionId in feedbackSessionIds) workout.copy(done = true) else workout
    }

    fun pendingOptionalExtras(
        workouts: List<Workout>,
        today: LocalDate,
        feedbackSessionIds: Set<String>
    ): List<Workout> = workouts.filter { workout ->
        workout.isOptionalExtra && !workout.done && workout.sessionId !in feedbackSessionIds &&
            (runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull()?.isBefore(today) == false)
    }

    fun merge(
        completed: List<Workout>,
        pendingExtras: List<Workout>,
        regeneratedFutureSessions: List<Workout>
    ): List<Workout> = (completed + pendingExtras + regeneratedFutureSessions)
        .distinctBy { it.sessionId }
        .sortedBy { it.scheduledDateIso }
}
