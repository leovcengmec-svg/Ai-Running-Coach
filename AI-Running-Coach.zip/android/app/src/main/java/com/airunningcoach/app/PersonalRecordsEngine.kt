package com.airunningcoach.app

import java.time.LocalDate
import java.util.UUID

internal data class ManualPersonalRecord(
    val id: String = UUID.randomUUID().toString(),
    val distanceKm: Double,
    val durationSeconds: Int,
    val dateIso: String = "",
    val raceName: String = "",
    val location: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

internal data class PersonalRecordResult(
    val id: String,
    val distanceKm: Double,
    val durationSeconds: Int,
    val dateIso: String,
    val eventName: String,
    val location: String = "",
    val source: String,
    val sourceRecordId: String = "",
    val notes: String = ""
)

internal data class PersonalRecordDistance(val label: String, val distanceKm: Double, val toleranceKm: Double)

internal object PersonalRecordsEngine {
    val standardDistances = listOf(
        PersonalRecordDistance("800 m", 0.8, 0.025),
        PersonalRecordDistance("1 km", 1.0, 0.04),
        PersonalRecordDistance("1 milha", 1.609344, 0.05),
        PersonalRecordDistance("3 km", 3.0, 0.08),
        PersonalRecordDistance("5 km", 5.0, 0.12),
        PersonalRecordDistance("10 km", 10.0, 0.20),
        PersonalRecordDistance("15 km", 15.0, 0.25),
        PersonalRecordDistance("Meia maratona", 21.0975, 0.35),
        PersonalRecordDistance("Maratona", 42.195, 0.50)
    )

    fun category(distanceKm: Double): PersonalRecordDistance? = standardDistances
        .filter { kotlin.math.abs(distanceKm - it.distanceKm) <= it.toleranceKm }
        .minByOrNull { kotlin.math.abs(distanceKm - it.distanceKm) }

    fun topThree(records: List<PersonalRecordResult>, distance: PersonalRecordDistance): List<PersonalRecordResult> =
        records.filter { kotlin.math.abs(it.distanceKm - distance.distanceKm) <= distance.toleranceKm }
            .sortedWith(compareBy<PersonalRecordResult> { it.durationSeconds }.thenBy { it.dateIso.ifBlank { "9999-12-31" } })
            .distinctBy { it.durationSeconds to it.dateIso }
            .take(3)

    fun manualRecord(
        distanceKm: Double,
        durationSeconds: Int,
        dateIso: String,
        raceName: String,
        location: String,
        notes: String
    ): ManualPersonalRecord? {
        if (!distanceKm.isFinite() || distanceKm !in 0.1..200.0 || durationSeconds !in 1..172_800) return null
        if (dateIso.isNotBlank() && runCatching { LocalDate.parse(dateIso) }.isFailure) return null
        return ManualPersonalRecord(
            distanceKm = distanceKm,
            durationSeconds = durationSeconds,
            dateIso = dateIso,
            raceName = raceName.trim().take(100),
            location = location.trim().take(100),
            notes = notes.trim().take(500)
        )
    }
}
