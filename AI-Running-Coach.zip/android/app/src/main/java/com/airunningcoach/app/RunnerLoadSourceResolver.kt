package com.airunningcoach.app

/** Keeps athlete-declared profile values separate from measurements derived from the activity log. */
internal data class RunnerLoadSources(
    val declaredWeeklyKm: Double?,
    val declaredLongestKm: Double?,
    val measuredWeeklyKm: Double?,
    val measuredLongestKm: Double?,
    val planningWeeklyKm: Double,
    val planningLongestKm: Double
)

internal object RunnerLoadSourceResolver {
    fun resolve(
        declaredWeeklyKm: Double?,
        declaredLongestKm: Double?,
        fallbackWeeklyKm: Double,
        fallbackLongestKm: Double,
        measuredWeeklyKm: Double?,
        measuredLongestKm: Double?,
        measuredHistoryReliable: Boolean,
        adoptMeasuredHistory: Boolean = false
    ): RunnerLoadSources {
        val declaredWeekly = declaredWeeklyKm ?: fallbackWeeklyKm
        val declaredLongest = declaredLongestKm ?: fallbackLongestKm
        val measuredLongest = measuredLongestKm?.takeIf { it.isFinite() && it > 0.0 }
        // Measurements remain descriptive until the athlete reconciles four complete
        // weeks and explicitly schedules their adoption. Never silently downgrade or
        // upgrade a declared baseline using an incomplete imported activity log.
        val adoptionAllowed = measuredHistoryReliable && adoptMeasuredHistory
        val planningWeekly = if (adoptionAllowed) {
            measuredWeeklyKm?.takeIf { it.isFinite() && it >= 0.0 } ?: declaredWeekly
        } else declaredWeekly
        val planningLongest = if (adoptionAllowed) measuredLongest ?: declaredLongest else declaredLongest
        return RunnerLoadSources(
            declaredWeeklyKm = declaredWeeklyKm,
            declaredLongestKm = declaredLongestKm,
            measuredWeeklyKm = measuredWeeklyKm,
            measuredLongestKm = measuredLongest,
            planningWeeklyKm = planningWeekly,
            planningLongestKm = planningLongest
        )
    }
}
