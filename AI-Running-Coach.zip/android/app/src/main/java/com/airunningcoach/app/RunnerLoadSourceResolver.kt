package com.airunningcoach.app

/** Keeps athlete-declared profile values separate from measurements derived from the activity log. */
internal data class RunnerLoadSources(
    val declaredWeeklyKm: Double?,
    val declaredLongestKm: Double?,
    val measuredWeeklyKm: Double?,
    val measuredLongestKm: Double?,
    val planningWeeklyKm: Double,
    val planningLongestKm: Double
)

internal object RunnerLoadSourceResolver {
    fun resolve(
        declaredWeeklyKm: Double?,
        declaredLongestKm: Double?,
        fallbackWeeklyKm: Double,
        fallbackLongestKm: Double,
        measuredWeeklyKm: Double?,
        measuredLongestKm: Double?,
        measuredHistoryReliable: Boolean
    ): RunnerLoadSources {
        val declaredWeekly = declaredWeeklyKm ?: fallbackWeeklyKm
        val declaredLongest = declaredLongestKm ?: fallbackLongestKm
        val measuredLongest = measuredLongestKm?.takeIf { it.isFinite() && it > 0.0 }
        val planningWeekly = if (measuredHistoryReliable) {
            measuredWeeklyKm?.takeIf { it.isFinite() && it >= 0.0 } ?: declaredWeekly
        } else declaredWeekly
        val planningLongest = if (measuredHistoryReliable) {
            measuredLongest ?: declaredLongest
        } else maxOf(declaredLongest, measuredLongest ?: 0.0)
        return RunnerLoadSources(
            declaredWeeklyKm = declaredWeeklyKm,
            declaredLongestKm = declaredLongestKm,
            measuredWeeklyKm = measuredWeeklyKm,
            measuredLongestKm = measuredLongest,
            planningWeeklyKm = planningWeekly,
            planningLongestKm = planningLongest
        )
    }
}
