package com.airunningcoach.app

import java.time.LocalDate
import java.util.regex.Pattern

/** Recovers ISO dates from legacy Portuguese labels when older backups lack scheduledDateIso. */
internal object LegacyWorkoutDateMigration {
    private val dayMonthPattern = Pattern.compile("(\\d{1,2})/(\\d{1,2})(?:/(\\d{4}))?")

    fun resolve(dateLabel: String, planStartDateIso: String, today: LocalDate = LocalDate.now()): String {
        val matcher = dayMonthPattern.matcher(dateLabel)
        if (!matcher.find()) return ""
        val day = matcher.group(1)?.toIntOrNull() ?: return ""
        val month = matcher.group(2)?.toIntOrNull() ?: return ""
        val explicitYear = matcher.group(3)?.toIntOrNull()
        val planStart = runCatching { LocalDate.parse(planStartDateIso) }.getOrNull()
        val year = explicitYear ?: planStart?.year ?: today.year
        var candidate = runCatching { LocalDate.of(year, month, day) }.getOrNull() ?: return ""
        if (explicitYear == null && planStart != null && candidate.isBefore(planStart.minusDays(30))) {
            candidate = runCatching { candidate.plusYears(1) }.getOrNull() ?: candidate
        }
        return candidate.toString()
    }
}
