package com.airunningcoach.app

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.time.format.DateTimeFormatter
import java.time.format.ResolverStyle

internal data class CooperAssessmentRecord(
    val dateIso: String,
    val distanceKm: Double,
    val estimatedVo2Max: Double,
    val averagePace: String,
    val estimatedMasPace: String = "",
    val estimatedSvt2Pace: String = "",
    val zoneModelVersion: String = PaceCalculator.ZONE_MODEL_VERSION,
    /** Frozen Z1–Z5 ranges in mm:ss min/km; older assessments remain reproducible. */
    val zoneRanges: Map<String, String> = emptyMap(),
    val z2CalibrationStatus: String = ZoneCalibrationEngine.INITIAL,
    val talkTestEvidenceCount: Int = 0,
    val talkTestReferencePaceMmSs: String = "",
    val z1CalibrationStatus: String = ZoneCalibrationEngine.INITIAL,
    val z1CalibrationEvidenceCount: Int = 0,
    val z2CalibrationEvidenceCount: Int = 0,
    val z3CalibrationStatus: String = ZoneCalibrationEngine.INITIAL,
    val z3CalibrationEvidenceCount: Int = 0,
    /** COOPER_12_MIN for historical records or THREE_KM for a 3 km time trial. */
    val testMethod: String = "COOPER_12_MIN",
    val testDurationSeconds: Int? = null,
    val referenceSex: String = "",
    val ageAtTest: Int? = null,
    /** Stable identity preserved across edit, soft-delete, restore and backup round-trips. */
    val recordId: String = "",
    /** ISO timestamp; non-empty means the historical result is excluded from active physiology. */
    val deletedAtIso: String = "",
    val updatedAtIso: String = ""
)

internal data class CooperReviewStatus(
    val lastAssessmentDate: LocalDate?,
    val nextReviewDate: LocalDate?,
    val daysUntilReview: Long?,
    val isDue: Boolean,
    val message: String
)

internal object CooperAssessmentEngine {
    const val REVIEW_INTERVAL_DAYS = 28L
    const val TEST_DURATION = "12 min"
    const val MAX_ONBOARDING_RESULT_AGE_DAYS = 56L
    private val inputDateFormatter = DateTimeFormatter.ofPattern("dd/MM/uuuu").withResolverStyle(ResolverStyle.STRICT)

    fun parseAssessmentDate(text: String): LocalDate? = runCatching {
        LocalDate.parse(text.trim(), inputDateFormatter)
    }.getOrNull()

    fun isRecentAssessmentDate(date: LocalDate, today: LocalDate = LocalDate.now()): Boolean {
        return ChronoUnit.DAYS.between(date, today) in 0..MAX_ONBOARDING_RESULT_AGE_DAYS
    }

    fun createRecord(
        distanceKm: Double,
        date: LocalDate = LocalDate.now(),
        talkTestComfortPaces: List<Int> = emptyList(),
        zonesOverride: TrainingPaceZones? = null,
        referenceSex: String = "",
        ageAtTest: Int? = null
    ): CooperAssessmentRecord? {
        val zones = zonesOverride ?: PaceCalculator.calculateCooper(distanceKm, talkTestComfortPaces) ?: return null
        return CooperAssessmentRecord(
            dateIso = date.toString(),
            distanceKm = distanceKm,
            estimatedVo2Max = zones.estimatedVo2Max,
            averagePace = PaceRange.format(zones.averageTestPaceValue),
            estimatedMasPace = zones.estimatedMasPace,
            estimatedSvt2Pace = zones.estimatedSvt2Pace,
            zoneModelVersion = zones.modelVersion,
            zoneRanges = zones.all().associate { it.id to it.range.label() },
            z2CalibrationStatus = zones.z2CalibrationStatus,
            talkTestEvidenceCount = zones.talkTestEvidenceCount,
            talkTestReferencePaceMmSs = zones.talkTestReferencePace,
            z1CalibrationStatus = zones.z1CalibrationStatus,
            z1CalibrationEvidenceCount = zones.z1CalibrationEvidenceCount,
            z2CalibrationEvidenceCount = zones.z2CalibrationEvidenceCount,
            z3CalibrationStatus = zones.z3CalibrationStatus,
            z3CalibrationEvidenceCount = zones.z3CalibrationEvidenceCount,
            testMethod = "COOPER_12_MIN",
            referenceSex = referenceSex,
            ageAtTest = ageAtTest
        )
    }

    fun createThreeKmRecord(
        timeSeconds: Int,
        date: LocalDate = LocalDate.now(),
        referenceSex: String,
        ageAtTest: Int,
        zonesOverride: TrainingPaceZones? = null
    ): CooperAssessmentRecord? {
        val zones = zonesOverride ?: PaceCalculator.calculateThreeKm(timeSeconds, referenceSex) ?: return null
        return CooperAssessmentRecord(
            dateIso = date.toString(), distanceKm = 3.0,
            estimatedVo2Max = zones.estimatedVo2Max,
            averagePace = PaceRange.format(zones.averageTestPaceValue),
            estimatedMasPace = zones.estimatedMasPace,
            estimatedSvt2Pace = zones.estimatedSvt2Pace,
            zoneModelVersion = zones.modelVersion,
            zoneRanges = zones.all().associate { it.id to it.range.label() },
            z2CalibrationStatus = zones.z2CalibrationStatus,
            talkTestEvidenceCount = zones.talkTestEvidenceCount,
            talkTestReferencePaceMmSs = zones.talkTestReferencePace,
            z1CalibrationStatus = zones.z1CalibrationStatus,
            z1CalibrationEvidenceCount = zones.z1CalibrationEvidenceCount,
            z2CalibrationEvidenceCount = zones.z2CalibrationEvidenceCount,
            z3CalibrationStatus = zones.z3CalibrationStatus,
            z3CalibrationEvidenceCount = zones.z3CalibrationEvidenceCount,
            testMethod = "THREE_KM",
            testDurationSeconds = timeSeconds,
            referenceSex = referenceSex,
            ageAtTest = ageAtTest
        )
    }

    fun reviewStatus(history: List<CooperAssessmentRecord>, today: LocalDate = LocalDate.now()): CooperReviewStatus {
        val lastDate = history.asSequence().filter { it.deletedAtIso.isBlank() }
            .mapNotNull { runCatching { LocalDate.parse(it.dateIso) }.getOrNull() }.maxOrNull()
        if (lastDate == null) return CooperReviewStatus(null, null, null, false, "Registre um teste de campo para calibrar as zonas de ritmo.")
        val nextDate = lastDate.plusDays(REVIEW_INTERVAL_DAYS)
        val days = ChronoUnit.DAYS.between(today, nextDate)
        val due = days <= 0
        val message = if (due) {
            "Revisão de evidências de quatro semanas disponível. Analise as execuções recentes, o esforço e a recuperação; não é necessário repetir agora um teste máximo. O reteste é considerado após quatro semanas efetivamente concluídas, no primeiro treino da semana seguinte, desde que a adesão seja suficiente; ele substitui uma sessão planejada."
        } else {
            "Próxima revisão de evidências em $days dia(s), a partir de ${nextDate.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))}. O reteste será considerado após quatro semanas completas de treinamento e será adiado quando as faltas superarem os treinos concluídos."
        }
        return CooperReviewStatus(lastDate, nextDate, days, due, message)
    }

    /** Returns the most recent Cooper result strictly before the assessment currently being calibrated.
     * The history may arrive unsorted; ISO dates are lexicographically sortable.
     */
    fun previousAssessmentDistance(
        history: List<CooperAssessmentRecord>,
        currentAssessmentDateIso: String?,
        testMethod: String = "COOPER_12_MIN"
    ): Double? = history.asSequence()
        .filter { it.deletedAtIso.isBlank() }
        .filter { it.testMethod == testMethod }
        .filterNot { currentAssessmentDateIso != null && it.dateIso == currentAssessmentDateIso }
        .maxByOrNull { it.dateIso }
        ?.distanceKm

    /** Positive values indicate improvement: more distance for Cooper or less time for 3 km. */
    fun improvementSincePrevious(history: List<CooperAssessmentRecord>, testMethod: String = "COOPER_12_MIN"): Double? {
        val ordered = history.asSequence().filter { it.deletedAtIso.isBlank() }
            .filter { it.testMethod == testMethod }.mapNotNull { record ->
            runCatching { LocalDate.parse(record.dateIso) to record }.getOrNull()
        }.sortedBy { it.first }.map { it.second }.toList()
        if (ordered.size < 2) return null
        val previous = ordered[ordered.lastIndex - 1]
        val latest = ordered.last()
        return if (testMethod == "THREE_KM") {
            val previousTime = previous.testDurationSeconds ?: return null
            val latestTime = latest.testDurationSeconds ?: return null
            if (previousTime <= 0) return null
            (previousTime - latestTime).toDouble() / previousTime * 100.0
        } else {
            if (previous.distanceKm <= 0.0) return null
            (latest.distanceKm - previous.distanceKm) / previous.distanceKm * 100.0
        }
    }
}


/** Planning-only estimate for a scheduled field retest. It never represents realized activity. */
internal data class RetestDistanceEstimate(
    val warmupKm: Double?,
    val testKm: Double?,
    val cooldownKm: Double?,
    val totalKm: Double,
    val easyPace: PaceRange?,
    val isPartial: Boolean
)

internal object RetestDistanceEstimator {
    /** Uses the athlete's own easy Z2 edge (0–20%); no generic pace is invented. */
    fun estimate(
        assessment: CooperAssessmentRecord,
        warmupMinutes: Int = 12,
        cooldownMinutes: Int = 10,
        testMethodOverride: String = assessment.testMethod
    ): RetestDistanceEstimate {
        val testKm = when (testMethodOverride) {
            "THREE_KM" -> 3.0
            "COOPER_12_MIN" -> if (assessment.testMethod == "COOPER_12_MIN") {
                assessment.distanceKm.takeIf { it.isFinite() && it in 0.5..10.0 }
            } else {
                // A previous 3 km test can seed a Cooper estimate using its average pace;
                // this remains an estimate and never becomes the recorded Cooper result.
                PaceRange.parsePace(assessment.averagePace)?.let { 720.0 / it }
                    ?.takeIf { it.isFinite() && it in 0.5..10.0 }
            }
            else -> null
        }
        val z2 = assessment.zoneRanges["Z2"]?.let(::parseRange)
        val easyPace = z2?.let { ZoneIntensityBandEngine.activeRange(it, ActiveZoneBand(0, 20)) }
        val representativeEasyPaceSeconds = easyPace?.let { (it.fastestPaceValue + it.slowestPaceValue) / 2 }
        val warmupKm = representativeEasyPaceSeconds?.let { estimateDistance(warmupMinutes, it) }
        val cooldownKm = representativeEasyPaceSeconds?.let { estimateDistance(cooldownMinutes, it) }
        val known = listOfNotNull(warmupKm, testKm, cooldownKm)
        val total = round2(known.sum())
        return RetestDistanceEstimate(
            warmupKm = warmupKm,
            testKm = testKm,
            cooldownKm = cooldownKm,
            totalKm = total,
            easyPace = easyPace,
            isPartial = warmupKm == null || testKm == null || cooldownKm == null
        )
    }

    private fun estimateDistance(minutes: Int, paceSecondsPerKm: Int): Double? {
        if (minutes <= 0 || paceSecondsPerKm !in 120..1800) return null
        return round2(minutes * 60.0 / paceSecondsPerKm)
    }

    private fun parseRange(label: String): PaceRange? {
        val normalized = label.substringBefore(" min/km").trim().replace('–', '-')
        val parts = normalized.split('-')
        if (parts.size != 2) return null
        val fast = PaceRange.parsePace(parts[0].trim()) ?: return null
        val slow = PaceRange.parsePace(parts[1].trim()) ?: return null
        return runCatching { PaceRange(fast, slow) }.getOrNull()
    }

    private fun round2(value: Double): Double = kotlin.math.round(value * 100.0) / 100.0
}
