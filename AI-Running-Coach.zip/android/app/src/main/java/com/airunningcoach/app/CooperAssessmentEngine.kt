package com.airunningcoach.app

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.time.format.DateTimeFormatter
import java.time.format.ResolverStyle

internal data class CooperAssessmentRecord(
    val dateIso: String,
    val distanceKm: Double,
    val estimatedVo2Max: Double,
    val averagePace: String,
    val estimatedMasPace: String = "",
    val estimatedSvt2Pace: String = "",
    val zoneModelVersion: String = PaceCalculator.ZONE_MODEL_VERSION,
    /** Frozen Z1–Z5 ranges in mm:ss min/km; older assessments remain reproducible. */
    val zoneRanges: Map<String, String> = emptyMap(),
    val z2CalibrationStatus: String = "COOPER_INITIAL",
    val talkTestEvidenceCount: Int = 0,
    val talkTestReferencePaceMmSs: String = ""
)

internal data class CooperReviewStatus(
    val lastAssessmentDate: LocalDate?,
    val nextReviewDate: LocalDate?,
    val daysUntilReview: Long?,
    val isDue: Boolean,
    val message: String
)

internal object CooperAssessmentEngine {
    const val REVIEW_INTERVAL_DAYS = 28L
    const val TEST_DURATION = "12 min"
    const val MAX_ONBOARDING_RESULT_AGE_DAYS = 56L
    private val inputDateFormatter = DateTimeFormatter.ofPattern("dd/MM/uuuu").withResolverStyle(ResolverStyle.STRICT)

    fun parseAssessmentDate(text: String): LocalDate? = runCatching {
        LocalDate.parse(text.trim(), inputDateFormatter)
    }.getOrNull()

    fun isRecentAssessmentDate(date: LocalDate, today: LocalDate = LocalDate.now()): Boolean {
        return ChronoUnit.DAYS.between(date, today) in 0..MAX_ONBOARDING_RESULT_AGE_DAYS
    }

    fun createRecord(
        distanceKm: Double,
        date: LocalDate = LocalDate.now(),
        talkTestComfortPaces: List<Int> = emptyList(),
        zonesOverride: TrainingPaceZones? = null
    ): CooperAssessmentRecord? {
        val zones = zonesOverride ?: PaceCalculator.calculateCooper(distanceKm, talkTestComfortPaces) ?: return null
        return CooperAssessmentRecord(
            dateIso = date.toString(),
            distanceKm = distanceKm,
            estimatedVo2Max = zones.estimatedVo2Max,
            averagePace = PaceRange.format(zones.averageTestPaceValue),
            estimatedMasPace = zones.estimatedMasPace,
            estimatedSvt2Pace = zones.estimatedSvt2Pace,
            zoneModelVersion = zones.modelVersion,
            zoneRanges = zones.all().associate { it.id to it.range.label() },
            z2CalibrationStatus = zones.z2CalibrationStatus,
            talkTestEvidenceCount = zones.talkTestEvidenceCount,
            talkTestReferencePaceMmSs = zones.talkTestReferencePace
        )
    }

    fun reviewStatus(history: List<CooperAssessmentRecord>, today: LocalDate = LocalDate.now()): CooperReviewStatus {
        val lastDate = history.mapNotNull { runCatching { LocalDate.parse(it.dateIso) }.getOrNull() }.maxOrNull()
        if (lastDate == null) return CooperReviewStatus(null, null, null, false, "Faça seu primeiro Teste de Cooper para calibrar as zonas de pace.")
        val nextDate = lastDate.plusDays(REVIEW_INTERVAL_DAYS)
        val days = ChronoUnit.DAYS.between(today, nextDate)
        val due = days <= 0
        val message = if (due) {
            "A revisão de quatro semanas está disponível. Faça um novo Cooper somente se estiver recuperado e sem dor; o teste substitui uma sessão intensa."
        } else {
            "Próxima revisão de pace em $days dia(s), a partir de ${nextDate.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))}."
        }
        return CooperReviewStatus(lastDate, nextDate, days, due, message)
    }

    /** Returns the most recent Cooper result strictly before the assessment currently being calibrated.
     * The history may arrive unsorted; ISO dates are lexicographically sortable.
     */
    fun previousAssessmentDistance(
        history: List<CooperAssessmentRecord>,
        currentAssessmentDateIso: String?
    ): Double? = history.asSequence()
        .filterNot { currentAssessmentDateIso != null && it.dateIso == currentAssessmentDateIso }
        .maxByOrNull { it.dateIso }
        ?.distanceKm

    fun improvementSincePrevious(history: List<CooperAssessmentRecord>): Double? {
        val ordered = history.mapNotNull { record ->
            runCatching { LocalDate.parse(record.dateIso) to record }.getOrNull()
        }.sortedBy { it.first }
        if (ordered.size < 2) return null
        val previous = ordered[ordered.lastIndex - 1].second.distanceKm
        val latest = ordered.last().second.distanceKm
        if (previous <= 0.0) return null
        return (latest - previous) / previous * 100.0
    }
}
