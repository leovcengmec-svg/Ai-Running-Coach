package com.airunningcoach.app

/** Official distance goals supported by the training planner. Distances are in kilometres. */
internal data class TrainingGoalDefinition(
    val id: String,
    val label: String,
    val distanceKm: Double?,
    val focus: String,
    val terrainAware: Boolean = false
)

internal object TrainingGoalCatalog {
    val all = listOf(
        TrainingGoalDefinition("MILE", "Milha (1,61 km)", 1.609, "Velocidade, economia de corrida e capacidade aeróbia"),
        TrainingGoalDefinition("3K", "3 km", 3.0, "Velocidade aeróbia e capacidade de sustentar ritmo"),
        TrainingGoalDefinition("5K", "5 km", 5.0, "Economia de corrida, limiar e potência aeróbia"),
        TrainingGoalDefinition("10K", "10 km", 10.0, "Base aeróbia, limiar e ritmo específico"),
        TrainingGoalDefinition("15K", "15 km", 15.0, "Resistência e ritmo sustentado"),
        TrainingGoalDefinition("10MI", "10 milhas (16,1 km)", 16.093, "Resistência específica entre 15 km e meia maratona"),
        TrainingGoalDefinition("20K", "20 km", 20.0, "Resistência e sustentação de ritmo"),
        TrainingGoalDefinition("HALF", "Meia maratona (21,1 km)", 21.0975, "Resistência, limiar e ritmo específico"),
        TrainingGoalDefinition("25K", "25 km", 25.0, "Resistência prolongada e preparação para longas distâncias"),
        TrainingGoalDefinition("30K", "30 km", 30.0, "Resistência prolongada e preparação específica para maratona"),
        TrainingGoalDefinition("MARATHON", "Maratona (42,2 km)", 42.195, "Volume, longões, ritmo específico e estratégia de abastecimento"),
        TrainingGoalDefinition("ULTRA_50K", "Ultramaratona (50 km)", 50.0, "Tempo em movimento, resistência prolongada e estratégia de nutrição", true),
        TrainingGoalDefinition("ULTRA_100K", "Ultramaratona (100 km)", 100.0, "Resistência de ultradistância, terreno, abastecimento e tempo em movimento", true),
        TrainingGoalDefinition("ULTRA_100MI", "Ultramaratona (100 milhas / 160,9 km)", 160.934, "Preparação especializada de ultradistância e gestão de esforço/abastecimento", true),
        TrainingGoalDefinition("HEALTH", "Saúde e qualidade de vida", 5.0, "Regularidade, saúde e condicionamento sem obrigação competitiva"),
        TrainingGoalDefinition("CUSTOM", "Outro objetivo", null, "Distância, terreno e objetivo personalizados", true)
    )

    val labels: List<String> get() = all.filterNot { it.id == "CUSTOM" }.map { it.label }

    /** Goal availability follows the physiological level; legacy Advanced maps to Performance. */
    fun labelsForLevel(level: String): List<String> {
        val normalized = RunnerFitnessAssessmentEngine.normalizeLevel(level)
        val allowedIds = when (normalized) {
            "Iniciante" -> setOf("3K", "5K", "HEALTH")
            "Intermediário" -> setOf("MILE", "3K", "5K", "10K", "15K", "10MI", "20K", "HALF", "HEALTH")
            "Performance" -> setOf("MILE", "3K", "5K", "10K", "15K", "10MI", "20K", "HALF", "25K", "30K", "MARATHON", "HEALTH")
            else -> all.map { it.id }.filterNot { it == "CUSTOM" }.toSet()
        }
        return all.filter { it.id in allowedIds }.map { it.label }
    }

    fun distanceForLabel(label: String, customDistanceKm: Double? = null): Double? {
        val normalized = label.trim()
        if (normalized == "Outro objetivo") return customDistanceKm?.takeIf { it.isFinite() && it in 1.0..200.0 }
        all.firstOrNull { it.label == normalized }?.distanceKm?.let { return it }
        // Backward compatibility with labels already stored by V1–V62. Check long labels
        // before numeric prefixes so "10 milhas" can never be mistaken for "10 km".
        return when {
            normalized.startsWith("Milha", ignoreCase = true) -> 1.609
            normalized.startsWith("100 milhas", ignoreCase = true) -> 160.934
            normalized.startsWith("100 km", ignoreCase = true) -> 100.0
            normalized.startsWith("50 km", ignoreCase = true) -> 50.0
            normalized.startsWith("3 km", ignoreCase = true) -> 3.0
            normalized.startsWith("5 km", ignoreCase = true) || normalized == "5 km" -> 5.0
            normalized.startsWith("10 milhas", ignoreCase = true) -> 16.093
            normalized.startsWith("10 km", ignoreCase = true) -> 10.0
            normalized.startsWith("15 km", ignoreCase = true) -> 15.0
            normalized.startsWith("20 km", ignoreCase = true) -> 20.0
            normalized.startsWith("25 km", ignoreCase = true) -> 25.0
            normalized.startsWith("30 km", ignoreCase = true) -> 30.0
            normalized.startsWith("Meia", ignoreCase = true) -> 21.0975
            normalized.startsWith("Maratona", ignoreCase = true) -> 42.195
            normalized.startsWith("Ultra", ignoreCase = true) -> 50.0
            normalized.startsWith("Saúde", ignoreCase = true) -> 5.0
            else -> null
        }
    }

    fun categoryForLabel(label: String): String = when (label.trim()) {
        "Saúde e qualidade de vida" -> "HEALTH"
        "Outro objetivo" -> "CUSTOM"
        else -> "PERFORMANCE"
    }

    fun definitionForDistance(distanceKm: Double): TrainingGoalDefinition? =
        all.filter { it.distanceKm != null }.minByOrNull { kotlin.math.abs(it.distanceKm!! - distanceKm) }
            ?.takeIf { kotlin.math.abs((it.distanceKm ?: 0.0) - distanceKm) < 0.15 }
}
