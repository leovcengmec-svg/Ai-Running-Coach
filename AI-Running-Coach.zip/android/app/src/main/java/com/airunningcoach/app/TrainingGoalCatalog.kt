package com.airunningcoach.app

/** Official distance goals supported by the training planner. Distances are in kilometres. */
internal data class TrainingGoalDefinition(
    val id: String,
    val label: String,
    val distanceKm: Double?,
    val focus: String
)

internal object TrainingGoalCatalog {
    val all = listOf(
        TrainingGoalDefinition("MILE", "Milha (1,61 km)", 1.609, "Velocidade, economia de corrida e capacidade aeróbia"),
        TrainingGoalDefinition("3K", "3 km", 3.0, "Velocidade aeróbia e capacidade de sustentar ritmo"),
        TrainingGoalDefinition("5K", "5 km", 5.0, "Economia de corrida, limiar e potência aeróbia"),
        TrainingGoalDefinition("10K", "10 km", 10.0, "Base aeróbia, limiar e ritmo específico"),
        TrainingGoalDefinition("15K", "15 km", 15.0, "Resistência e ritmo sustentado"),
        TrainingGoalDefinition("HALF", "Meia maratona (21,1 km)", 21.1, "Resistência, limiar e ritmo específico"),
        TrainingGoalDefinition("MARATHON", "Maratona (42,2 km)", 42.195, "Volume, longões, ritmo específico e estratégia de abastecimento"),
        TrainingGoalDefinition("ULTRA_50K", "Ultramaratona (50 km)", 50.0, "Tempo em movimento, resistência prolongada e estratégia de nutrição"),
        TrainingGoalDefinition("HEALTH", "Saúde e qualidade de vida", 5.0, "Regularidade, saúde e condicionamento sem obrigação competitiva"),
        TrainingGoalDefinition("CUSTOM", "Outro objetivo", null, "Distância e objetivo personalizados")
    )

    val labels: List<String> get() = all.map { it.label }

    fun distanceForLabel(label: String, customDistanceKm: Double? = null): Double? {
        val normalized = label.trim()
        if (normalized == "Outro objetivo") return customDistanceKm?.takeIf { it.isFinite() && it in 1.0..100.0 }
        all.firstOrNull { it.label == normalized }?.distanceKm?.let { return it }
        // Backward compatibility with labels already stored by V1–V60.
        return when {
            normalized.startsWith("Milha") -> 1.609
            normalized.startsWith("3 km") -> 3.0
            normalized.startsWith("5") -> 5.0
            normalized.startsWith("10") -> 10.0
            normalized.startsWith("15") -> 15.0
            normalized.startsWith("Meia") -> 21.1
            normalized.startsWith("Maratona") -> 42.195
            normalized.startsWith("Ultra") -> 50.0
            normalized.startsWith("Saúde") -> 5.0
            else -> null
        }
    }

    fun categoryForLabel(label: String): String = when (label.trim()) {
        "Saúde e qualidade de vida" -> "HEALTH"
        "Outro objetivo" -> "CUSTOM"
        else -> "PERFORMANCE"
    }

    fun definitionForDistance(distanceKm: Double): TrainingGoalDefinition? =
        all.filter { it.distanceKm != null }.minByOrNull { kotlin.math.abs(it.distanceKm!! - distanceKm) }
            ?.takeIf { kotlin.math.abs((it.distanceKm ?: 0.0) - distanceKm) < 0.15 }
}
