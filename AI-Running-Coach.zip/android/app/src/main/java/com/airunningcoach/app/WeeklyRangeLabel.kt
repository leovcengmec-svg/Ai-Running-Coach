package com.airunningcoach.app

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.time.temporal.TemporalAdjusters
import java.time.DayOfWeek

/** Human-readable ISO-week interval for performance charts. */
internal object WeeklyRangeLabel {
    private val locale = Locale.forLanguageTag("pt-BR")
    fun fromActivityDate(date: LocalDate): String {
        val start = date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val end = start.plusDays(6)
        val day = DateTimeFormatter.ofPattern("dd", locale)
        val dayMonth = DateTimeFormatter.ofPattern("dd/MM", locale)
        val full = DateTimeFormatter.ofPattern("dd/MM/uuuu", locale)
        return when {
            start.year != end.year -> "${start.format(full)}–${end.format(full)}"
            start.month != end.month -> "${start.format(dayMonth)}–${end.format(dayMonth)}"
            else -> "${start.format(day)}–${end.format(dayMonth)}"
        }
    }
}
