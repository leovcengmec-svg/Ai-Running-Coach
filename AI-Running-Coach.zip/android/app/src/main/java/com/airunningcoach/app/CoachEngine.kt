package com.airunningcoach.app

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Motor de prescrição V79: cálculo unificado, distribuição decimal e periodização adaptativa. */
internal data class RunnerInput(
    val goalKm: Double,
    val level: String,
    val frequency: Int,
    /** Dias habituais escolhidos pelo atleta; lista vazia mantém compatibilidade com perfis antigos. */
    val availableDays: List<DayOfWeek> = emptyList(),
    /** Dia preferido para o longão, quando disponível. */
    val preferredLongRunDay: DayOfWeek? = null,
    /** Média semanal efetivamente corrida nas últimas quatro semanas. */
    val weeklyVolumeKm: Double,
    val longestRecentKm: Double,
    /** Explicit beginner/return-to-running pathway; never inferred from VO2 class or missing files. */
    val runWalkEligible: Boolean = false,
    val painPresent: Boolean = false,
    val recoveryScore: Double? = null,
    val fatigueScore: Double? = null,
    val planWeeks: Int = 8,
    /** Distância percorrida no Teste de Cooper de 12 minutos; unidade única: km. */
    val cooperDistanceKm: Double? = null,
    val cooperAssessmentDateIso: String? = null,
    /** Último Cooper anterior, usado para limitar mudanças bruscas entre calibrações. */
    val previousCooperDistanceKm: Double? = null,
    /** Pace da etapa estável em que frases completas permaneceram confortáveis, observado em sessões aeróbias. */
    val talkTestComfortPaceValues: List<Int> = emptyList(),
    /** Fully individualized ranges from the app state; preferred over recalculation from Cooper only. */
    val calibratedPaceZones: TrainingPaceZones? = null,
    /** Count of real activities with distance/time recorded in the previous 28 days. */
    val recentActivityCount: Int = 0,
    /** True only after enough logged sessions span at least three distinct weeks. */
    val recentActivityHistoryReliable: Boolean = false,
    /** Explicitly supplied current weekly volume and recent longest-run baseline, used only when logs are absent. */
    val profileBaselineConfirmed: Boolean = false,
    /** Months of regular running experience; -1 means a legacy profile did not record it. */
    val experienceMonths: Int = -1,
    /** Distinct active weeks in the previous 4 weeks; -1 means unknown. */
    val activeWeeksLast4: Int = -1,
    val startDate: LocalDate = LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)),
    /** HEALTH keeps the plan health-oriented and does not select quality/threshold stimuli. */
    val goalCategory: String = "PERFORMANCE",
    val goalIntent: String = TrainingGoalIntent.COMPLETE,
    val targetTimeSeconds: Int? = null,
    val personalBestTimeSeconds: Int? = null,
    val terrainPreference: String = RunningTerrain.ROAD,
    val performanceTests: List<PerformanceTestObservation> = emptyList(),
    val measuredSessionRpeLoad7Days: Int? = null,
    val measuredSessionRpeLoad28Days: Int? = null,
    val measuredDurationMinutes7Days: Int? = null,
    val measuredDurationMinutes28Days: Int? = null,
    val measuredAverageRpe28Days: Double? = null,
    /** Distinct valid activity count used to derive the 28-day RPE mean. */
    val measuredAverageRpeActivityCount28Days: Int = 0,
    val criticalSpeedPaceSecondsPerKm: Int? = null,
    val criticalSpeedStatus: String = "UNAVAILABLE"
)

internal data class MotorState(
    val fitnessConfidence: String,
    val paceConfidence: String,
    val recentVolumeKm: Double,
    val recentLongRunKm: Double,
    val recoveryStatus: String,
    val safetyStatus: String,
    val phase: String,
    val flags: List<String>,
    val criticalSpeed: CriticalSpeedSnapshot? = null,
    val goalTimeProjection: GoalTimeProjection? = null,
    val loadRpe7Days: Int? = null,
    val loadRpe28Days: Int? = null,
    val goalPreparationStage: String = "BASE",
    val goalSpecificWeeklyMinKm: Double? = null,
    val goalSpecificLongestMinKm: Double? = null,
    val goalSpecificFrequencyMin: Int = 0
)

internal data class MotorDecision(
    val action: String,
    val necessity: String,
    val stimulus: String,
    val rationale: String,
    val confidence: Double,
    val safety: String
)

internal data class WorkoutSegment(
    val name: String,
    val instruction: String,
    val durationMin: Int? = null,
    /** Exact sub-minute target for strides/recoveries; exported as milliseconds. */
    val durationSeconds: Int? = null,
    val distanceKm: Double? = null,
    val intensity: String = "LOW",
    /** RPE é uma referência complementar, nunca o alvo primário de execução. */
    val rpeRange: String = "2-3",
    val repeatCount: Int = 1,
    /** TIME ou DISTANCE, conforme o campo de dose preenchido. */
    val targetMode: String = if (durationMin != null || durationSeconds != null) "TIME" else "DISTANCE",
    /** Limites numéricos internos; UI e contrato sempre formatam como mm:ss min/km. */
    val targetPaceMinValue: Int? = null,
    val targetPaceMaxValue: Int? = null,
    /** Zona operacional Z1–Z5 associada ao bloco, quando aplicável. */
    val paceZone: String? = null,
    /** Limites completos da zona antes da seleção da faixa ativa por sessão. */
    val zoneBasePaceFastValue: Int? = null,
    val zoneBasePaceSlowValue: Int? = null,
    /** Percentual interno da zona usado no alvo desta sessão (0=lento, 100=rápido). */
    val zoneIntensityMinPercent: Int? = null,
    val zoneIntensityMaxPercent: Int? = null,
    /** Goal-pace reference is supplementary and never replaces the physiological zone target. */
    val goalPaceReferenceSecondsPerKm: Int? = null,
    /** PASSIVE, WALK, ACTIVE_Z1 or ACTIVE_Z2; null for non-recovery segments. */
    val recoveryMode: String? = null
) {
    init {
        require(targetMode == "TIME" || targetMode == "DISTANCE") { "O alvo deve ser TIME ou DISTANCE." }
        require(if (targetMode == "TIME") {
            ((durationMin != null && durationMin > 0 && durationSeconds == null) ||
                (durationSeconds != null && durationSeconds > 0 && durationMin == null))
        } else distanceKm != null && distanceKm >= 0.0) {
            "Cada etapa precisa ter uma dose compatível com o tipo de alvo."
        }
        require((targetPaceMinValue == null) == (targetPaceMaxValue == null)) { "A faixa de ritmo precisa ter os dois limites." }
        if (targetPaceMinValue != null && targetPaceMaxValue != null) {
            require(targetPaceMinValue > 0 && targetPaceMaxValue >= targetPaceMinValue) { "Faixa de ritmo inválida." }
        }
        require((zoneBasePaceFastValue == null) == (zoneBasePaceSlowValue == null)) { "A zona-base precisa ter os dois limites." }
        if (zoneBasePaceFastValue != null && zoneBasePaceSlowValue != null) {
            require(zoneBasePaceFastValue > 0 && zoneBasePaceSlowValue >= zoneBasePaceFastValue) { "Zona-base inválida." }
        }
        require((zoneIntensityMinPercent == null) == (zoneIntensityMaxPercent == null)) { "A faixa percentual precisa dos dois limites." }
        if (zoneIntensityMinPercent != null && zoneIntensityMaxPercent != null) {
            require(zoneIntensityMinPercent in 0..99 && zoneIntensityMaxPercent in 1..100 && zoneIntensityMinPercent < zoneIntensityMaxPercent) { "Percentual ativo inválido." }
        }
        require(repeatCount >= 1) { "A repetição deve ser pelo menos 1." }
        require(recoveryMode == null || recoveryMode in setOf("PASSIVE", "WALK", "ACTIVE_Z1", "ACTIVE_Z2")) {
            "Modalidade de recuperação inválida."
        }
        if (recoveryMode == "PASSIVE") {
            require(targetMode == "TIME" && (durationMin != null || durationSeconds != null) && distanceKm == null &&
                targetPaceMinValue == null && targetPaceMaxValue == null && paceZone == null) {
                "A pausa passiva deve ter duração, sem distância ou ritmo-alvo."
            }
        }
    }
}

internal data class PrescribedWorkout(
    val day: String,
    val date: String,
    val scheduledDateIso: String,
    val title: String,
    val type: String,
    val objective: String,
    val stimulus: String,
    val sessionId: String,
    val distanceKm: Double,
    val durationMin: Int,
    val intensity: String,
    val paceMode: String,
    val rpeRange: String,
    val detail: String,
    val rationale: String,
    val week: Int = 1,
    val phase: String = "BASE",
    val segments: List<WorkoutSegment> = emptyList(),
    val paceCalibrationSnapshot: PaceCalibrationSnapshot? = null,
    /** Regular-running experience captured at prescription time; -1 means legacy/unknown. */
    val experienceMonths: Int = -1,
    /** Why this week's load was increased, held, reduced or capped; empty on legacy plans. */
    val weeklyLoadRationale: String = "",
    /** Planned build increase for this week; null for legacy plans. */
    val plannedGrowthPercent: Int? = null,
    /** Immutable original calendar slot; retained when a session is manually rescheduled. */
    val originalScheduledDateIso: String = ""
)

internal data class WeeklyPlanSummary(
    val week: Int,
    val phase: String,
    val totalKm: Double,
    val workoutCount: Int,
    val isRecoveryWeek: Boolean,
    val targetKm: Double = totalKm,
    val varianceKm: Double = totalKm - targetKm
)

internal data class MotorPlan(
    val state: MotorState,
    val decision: MotorDecision,
    val workouts: List<PrescribedWorkout>,
    val weeklyKm: Double,
    val explanation: String,
    val weeklySummaries: List<WeeklyPlanSummary>,
    val intensityDistribution: IntensityDistributionReport? = null,
    val intensityDistributionTarget: IntensityDistributionTarget? = null
)

internal object RunningCoachEngine {
    fun generate(input: RunnerInput): MotorPlan {
        val readinessAssessment = RunnerReadinessEngine.evaluate(
            RunnerReadinessInput(
                goalKm = input.goalKm,
                goalCategory = input.goalCategory,
                declaredLevel = input.level,
                experienceMonths = input.experienceMonths,
                selectedFrequency = input.frequency,
                weeklyVolumeKm = input.weeklyVolumeKm,
                longestRecentKm = input.longestRecentKm,
                activeWeeksLast4 = input.activeWeeksLast4,
                goalIntent = input.goalIntent,
                targetTimeSeconds = input.targetTimeSeconds,
                terrainPreference = input.terrainPreference
            )
        )
        val criticalSpeed = PhysiologicalProfileEngine.estimateCriticalSpeed(input.performanceTests)
        val bestPerformance = input.performanceTests
            .filter {
                !it.painPresent && (it.isRaceOrTest || it.effortRating >= 9) &&
                    it.effortRating >= 7 && it.distanceKm in 1.0..42.2 && it.durationSeconds in 180..36_000 &&
                    java.time.temporal.ChronoUnit.DAYS.between(it.date, LocalDate.now()) in 0..90
            }
            .maxByOrNull { it.date }
        val goalProjection = bestPerformance?.let {
            PhysiologicalProfileEngine.projectGoalTime(it.distanceKm, it.durationSeconds, input.goalKm)
        }
        val enrichedInput = input.copy(
            level = readinessAssessment.prescriptionLevel,
            criticalSpeedPaceSecondsPerKm = criticalSpeed.criticalSpeedPaceSecondsPerKm,
            criticalSpeedStatus = criticalSpeed.status
        )
        return generateWithReadiness(enrichedInput, readinessAssessment, criticalSpeed, goalProjection)
    }

    private fun generateWithReadiness(
        input: RunnerInput,
        readinessAssessment: RunnerReadinessSnapshot,
        criticalSpeed: CriticalSpeedSnapshot,
        goalProjection: GoalTimeProjection?
    ): MotorPlan {
        require(input.frequency in 2..6) { "A frequência deve estar entre 2 e 6 dias por semana." }
        if (input.availableDays.isNotEmpty()) {
            require(input.availableDays.distinct().size == input.frequency) { "A quantidade de dias selecionados precisa corresponder à frequência semanal." }
            require(input.preferredLongRunDay == null || input.preferredLongRunDay in input.availableDays) { "O dia preferido do longão precisa estar disponível." }
        }
        require(input.goalKm in 1.0..200.0) { "O objetivo precisa estar entre 1 e 200 km." }
        require(input.weeklyVolumeKm in 0.0..300.0) { "Informe um volume semanal entre 0 e 300 km." }
        require(input.longestRecentKm in 0.0..200.0) { "O maior treino recente precisa estar entre 0 e 200 km." }

        val novice = isNovicePlan(input)
        val paceZones = input.calibratedPaceZones ?: PaceCalculator.limitCalibrationChange(
            PaceCalculator.calculateCooper(input.cooperDistanceKm, input.talkTestComfortPaceValues),
            PaceCalculator.calculateCooper(input.previousCooperDistanceKm, input.talkTestComfortPaceValues),
            maxBoundaryShiftSeconds = 15
        )
        val recovery = recoveryStatus(input.recoveryScore)
        val safety = safetyStatus(input)
        val goalReadiness = TrainingPeriodizationEngine.goalSpecificReadiness(input)
        val flags = buildFlags(input, recovery, safety, paceZones) + buildList {
            if (!goalReadiness.ready) add("GOAL_SPECIFIC_PHASE_NOT_READY")
            if (goalReadiness.frequencyBelowReference) add("FREQUENCY_BELOW_SPECIFIC_REFERENCE")
            if (goalReadiness.volumeBelowReference) add("VOLUME_BELOW_SPECIFIC_REFERENCE")
            if (goalReadiness.longRunBelowReference) add("LONG_RUN_BELOW_SPECIFIC_REFERENCE")
            if (goalReadiness.consistencyNotEstablished) add("SPECIFIC_CONSISTENCY_NOT_ESTABLISHED")
        }
        val state = MotorState(
            fitnessConfidence = when {
                input.weeklyVolumeKm < 8.0 || input.longestRecentKm < 5.0 -> "LOW"
                else -> "PARTIAL"
            },
            paceConfidence = if (paceZones != null) "ESTIMATED_FROM_COOPER" else "AWAITING_COOPER",
            recentVolumeKm = input.weeklyVolumeKm,
            recentLongRunKm = input.longestRecentKm,
            recoveryStatus = recovery,
            safetyStatus = safety,
            phase = when {
                recovery == "POOR" -> "RECOVERY"
                !goalReadiness.ready -> "PREPARATION"
                else -> "BASE_AND_BUILD"
            },
            flags = flags,
            criticalSpeed = criticalSpeed,
            goalTimeProjection = goalProjection,
            loadRpe7Days = input.measuredSessionRpeLoad7Days,
            loadRpe28Days = input.measuredSessionRpeLoad28Days,
            goalPreparationStage = goalReadiness.stage,
            goalSpecificWeeklyMinKm = goalReadiness.minimumWeeklyKm,
            goalSpecificLongestMinKm = goalReadiness.minimumLongRunKm,
            goalSpecificFrequencyMin = goalReadiness.minimumFrequency
        )

        if (safety == "RED") {
            val decision = MotorDecision(
                action = "BLOCK", necessity = "SAFETY_REVIEW", stimulus = "NONE",
                rationale = "Há relato de dor. O motor não gera sessões de corrida; procure orientação adequada antes de retomar a carga.",
                confidence = 0.99, safety = "RED"
            )
            return MotorPlan(state, decision, emptyList(), 0.0, decision.rationale, emptyList())
        }

        val weeks = input.planWeeks.coerceIn(4, 52)
        // O ponto de partida usa o histórico real quando informado; campos vazios chegam
        // hidratados pela base fixa do objetivo antes da chamada do motor.
        val loadTargets = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(
                currentWeeklyKm = input.weeklyVolumeKm,
                activeWeeksLast4 = input.activeWeeksLast4,
                measuredHistoryReliable = input.recentActivityHistoryReliable,
                recoveryScore = input.recoveryScore,
                fatigueScore = input.fatigueScore,
                weeks = weeks,
                hasPain = input.painPresent,
                longestRecentKm = input.longestRecentKm,
                recentLoadTrendRatio = input.measuredSessionRpeLoad7Days?.toDouble()?.let { recent ->
                    input.measuredSessionRpeLoad28Days?.takeIf { it > 0 }?.let { recent * 4.0 / it }
                },
                averageRpe = input.measuredAverageRpe28Days,
                averageRpeEvidenceCount = input.measuredAverageRpeActivityCount28Days,
                referenceMinKm = TrainingPlanReferenceCatalog.loadReference(input.goalKm, input.goalCategory).baseWeeklyKm,
                referenceMaxKm = TrainingPlanReferenceCatalog.loadReference(input.goalKm, input.goalCategory).maximumBuildWeeklyKm,
                profileBaselineConfirmed = input.profileBaselineConfirmed,
                goalBaseKm = TrainingPlanReferenceCatalog.loadReference(input.goalKm, input.goalCategory).baseWeeklyKm,
                explicitNoRecentTraining = input.weeklyVolumeKm <= 0.0 && input.longestRecentKm <= 0.0
            )
        )
        val baselineKm = if (input.weeklyVolumeKm == 0.0 && input.longestRecentKm == 0.0) 3.0 else if (input.weeklyVolumeKm == 0.0)
            TrainingPlanReferenceCatalog.loadReference(input.goalKm, input.goalCategory).baseWeeklyKm else input.weeklyVolumeKm
        val workouts = mutableListOf<PrescribedWorkout>()
        val calibrationDate = input.cooperAssessmentDateIso ?: input.startDate.toString()
        val calibrationSnapshot = PaceCalculator.createCalibrationSnapshot(input.cooperDistanceKm, calibrationDate, input.talkTestComfortPaceValues, paceZones)
        val summaries = mutableListOf<WeeklyPlanSummary>()
        val initialReadinessFactor = when {
            recovery == "POOR" -> 0.72
            safety == "YELLOW" -> 0.82
            else -> 1.0
        }

        for (week in 1..weeks) {
            val cycleWeek = (week - 1) % 4
            val loadTarget = loadTargets.getOrNull(week - 1)
            val isRecoveryWeek = cycleWeek == 3 || loadTarget?.phase == TrainingPeriodizationEngine.RECOVERY
            // LoadPrescriptionEngine stops progression under poor readiness; this factor
            // separately reduces the actual weekly dose while recovery/fatigue remains elevated.
            val rawTargetWeekKm = loadTarget?.targetKm ?: max(1.5, baselineKm)
            val targetWeekKm = max(1.0, rawTargetWeekKm * initialReadinessFactor)
            val weekPhase = when {
                isRecoveryWeek -> TrainingPeriodizationEngine.RECOVERY
                !goalReadiness.ready -> TrainingPeriodizationEngine.PREPARATION
                else -> TrainingPeriodizationEngine.phaseForWeek(week, weeks, false)
            }
            val weekSessions = buildWeek(
                input = input,
                targetWeekKm = targetWeekKm,
                week = week,
                phase = weekPhase,
                suppressQuality = isRecoveryWeek || recovery == "POOR" || safety == "YELLOW"
            ).map { session ->
                val bandAdjusted = ZoneIntensityBandEngine.apply(session.copy(
                    paceCalibrationSnapshot = calibrationSnapshot,
                    experienceMonths = input.experienceMonths
                ))
                val terrainAdjusted = applyTerrainConstraints(bandAdjusted, input)
                applyGoalPaceReference(terrainAdjusted, input).copy(
                    weeklyLoadRationale = loadTarget?.rationale.orEmpty(),
                    plannedGrowthPercent = loadTarget?.maxGrowthPercent
                ).also { generated ->
                    val errors = TrainingPrescriptionAudit.validate(generated).toMutableList()
                    errors += TrainingPrescriptionAudit.validateExportStructure(generated.segments, generated.stimulus)
                    val protocolCode = generated.stimulus.substringAfterLast(':')
                    if (TrainingProtocolCatalog.find(protocolCode) != null) {
                        errors += TrainingProtocolCatalog.validateNamedProtocol(protocolCode, generated.segments, generated.title)
                    }
                    require(errors.isEmpty()) {
                        "Prescrição bloqueada pela auditoria da biblioteca (${generated.title}, semana ${generated.week}): ${errors.distinct().joinToString("; ")}"
                    }
                }
            }
            workouts += weekSessions
            summaries += WeeklyPlanSummary(
                week = week,
                phase = weekPhase,
                totalKm = round1(weekSessions.sumOf { it.distanceKm }),
                workoutCount = weekSessions.size,
                isRecoveryWeek = isRecoveryWeek,
                targetKm = round1(targetWeekKm),
                varianceKm = round1(weekSessions.sumOf { it.distanceKm } - targetWeekKm)
            )
        }

        val firstWeekKm = summaries.firstOrNull()?.totalKm ?: 0.0
        val volumeWasCapped = firstWeekKm + 0.1 < baselineKm * initialReadinessFactor
        val finalState = if (volumeWasCapped) state.copy(flags = state.flags + "WEEKLY_VOLUME_CAPPED_BY_RECENT_TOLERANCE") else state
        val qualityCount = workouts.count { it.type == "Qualidade" }
        val necessity = when {
            recovery == "POOR" -> "RECOVERY_FIRST"
            !goalReadiness.ready -> "GOAL_PREPARATORY_BASE"
            input.goalKm <= 10.0 -> "AEROBIC_DEVELOPMENT"
            else -> "ENDURANCE_DEVELOPMENT"
        }
        val stimulus = when {
            recovery == "POOR" || (safety == "YELLOW" && qualityCount == 0) -> "LOW_INTENSITY_AEROBIC"
            !goalReadiness.ready -> "PREPARATORY_BASE_BUILD"
            qualityCount > 0 -> "AEROBIC_BASE_AND_CONTROLLED_QUALITY"
            else -> "AEROBIC_BASE"
        }
        val rationale = when {
            recovery == "POOR" -> "A recuperação registrada está baixa. O volume foi reduzido e os estímulos de qualidade foram suspensos."
            safety == "YELLOW" -> "Os sinais recentes de fadiga pedem redução temporária da carga e suspensão de estímulos intensos."
            volumeWasCapped -> "A média semanal informada é maior do que a dose que o histórico do maior treino recente permite distribuir com segurança na frequência escolhida. O plano fica abaixo da média informada até haver tolerância documentada."
            input.weeklyVolumeKm == 0.0 -> "Como não há corrida registrada nas últimas quatro semanas, o plano começa com reintrodução leve, independentemente do nível de experiência declarado."
            input.goalCategory == "HEALTH" -> "O objetivo selecionado é saúde e qualidade de vida. O plano prioriza regularidade e intensidade aeróbia confortável, sem sessões automáticas de limiar, VO₂ ou Z3 de qualidade. "
            input.level == "Iniciante" -> "O nível fisiológico orienta a intensidade, não obriga a caminhar. Quando há teste válido, os trechos ativos usam as faixas individuais Z1–Z2; corrida-caminhada só entra se a carga recente exigir."
            novice -> "O plano mantém os ${input.frequency} dias selecionados, com sessões leves e corrida-caminhada quando necessário. O condicionamento limita a distância e a intensidade de cada treino, não a frequência solicitada."
            !goalReadiness.ready -> "Objetivo de ${formatGoalDistance(input.goalKm)} mantido, mas a fase específica ainda não foi liberada. Base atual: ${formatKm(input.weeklyVolumeKm)} km/semana e maior sessão de ${formatKm(input.longestRecentKm)} km. Referência de entrada na fase específica: ${formatKm(goalReadiness.minimumWeeklyKm)} km/semana, longão de ${formatKm(goalReadiness.minimumLongRunKm)} km e ${goalReadiness.minimumFrequency} dias disponíveis, além de consistência e recuperação adequadas. O ciclo atual é preparatório e não simula uma preparação específica concluída."
            else -> "A primeira semana parte do volume semanal real informado. A progressão é gradual; a qualidade só aparece quando o volume, a recuperação e o espaçamento entre sessões permitem."
        }
        val decision = MotorDecision(
            action = if (recovery == "POOR" || safety == "YELLOW") "REDUCE_LOAD" else "PRESCRIBE",
            necessity = necessity,
            stimulus = stimulus,
            rationale = rationale,
            confidence = when {
                input.weeklyVolumeKm == 0.0 -> 0.25
                input.weeklyVolumeKm >= 8.0 && input.longestRecentKm >= 5.0 -> 0.68
                else -> 0.42
            },
            safety = safety
        )
        val explanation = buildString {
            append("A dose inicial respeita o volume e a maior sessão recente; a frequência escolhida é mantida. A progressão depende da tolerância registrada. ")
            if (input.recentActivityHistoryReliable) {
                append("Carga atualizada com ${input.recentActivityCount} atividades reais recentes. ")
            } else if (input.recentActivityCount > 0) {
                append("O histórico registrado ainda é parcial (${input.recentActivityCount} atividades recentes); a média informada no perfil foi mantida como referência, e as sessões já registradas entram como limite adicional de tolerância. ")
            }
            if (input.measuredSessionRpeLoad7Days != null || input.measuredDurationMinutes7Days != null) {
                append("Carga recente combinada: ${input.measuredDurationMinutes7Days ?: "tempo não informado"} min em 7 dias, sRPE ${input.measuredSessionRpeLoad7Days ?: "indisponível"}; essa tendência é descritiva e não um índice clínico de risco. ")
            }
            if (criticalSpeed.status == "FIELD_ESTIMATE") append("Velocidade crítica estimada em campo: ${criticalSpeed.paceLabel}, baseada em ${criticalSpeed.evidenceCount} esforços; é uma referência complementar e não altera as zonas automaticamente. ")
            else if (criticalSpeed.status == "CONFLICTING_EVIDENCE") append("Há resultados de desempenho conflitantes para estimar velocidade crítica; as zonas atuais foram preservadas. ")
            if (!goalReadiness.ready) {
                append(" A fase específica permanece bloqueada por enquanto: faltam ${goalReadiness.missingRequirements.joinToString(", ")}. As referências são critérios de prontidão do aplicativo, não mínimos universais nem autorização médica. ")
            }
            val volumeDifferences = summaries.filter { kotlin.math.abs(it.varianceKm) >= 0.6 }
            if (volumeDifferences.isNotEmpty()) {
                append(" A carga solicitada e a soma efetivamente distribuída diferem em ${volumeDifferences.size} semana(s), devido aos limites individuais de sessão e longão; os valores reais aparecem na auditoria semanal. ")
            }
            if (input.goalIntent == TrainingGoalIntent.PERSONAL_BEST && input.personalBestTimeSeconds != null && input.goalKm in 1.0..100.0) {
                val pbPace = (input.personalBestTimeSeconds / input.goalKm).toInt()
                append("Recorde pessoal atual informado: ${PhysiologicalProfileEngine.formatDuration(input.personalBestTimeSeconds)} para ${formatKm(input.goalKm)} km (ritmo médio matemático ${PaceRange.format(pbPace)} min/km). O valor é uma referência de desempenho, não substitui as zonas fisiológicas e será considerado em sessões específicas quando houver compatibilidade. ")
            }
            if (input.targetTimeSeconds != null) {
                val targetPace = (input.targetTimeSeconds / input.goalKm).toInt()
                append("Meta de tempo informada: ${PhysiologicalProfileEngine.formatDuration(input.targetTimeSeconds)} (ritmo médio matemático ${PaceRange.format(targetPace)} min/km). O alvo é uma meta, não uma zona fisiológica; será usado como referência em sessões específicas somente quando a distância, o terreno e a prontidão forem compatíveis. ")
                if (goalProjection?.projectedTimeSeconds != null) {
                    val targetGap = (goalProjection.projectedTimeSeconds - input.targetTimeSeconds).toDouble() / goalProjection.projectedTimeSeconds
                    when {
                        targetGap > 0.08 -> append("A meta é mais de 8% mais rápida que a projeção baseada no resultado recente (${PhysiologicalProfileEngine.formatDuration(goalProjection.projectedTimeSeconds)}). Trate-a como objetivo aspiracional e reavalie a viabilidade após um teste/prova específico. ")
                        targetGap < -0.08 -> append("A meta está mais de 8% mais lenta que a projeção recente (${PhysiologicalProfileEngine.formatDuration(goalProjection.projectedTimeSeconds)}); o treinador não precisa forçar intensidade para alcançá-la. ")
                        else -> append("A meta está próxima da projeção matemática recente; ainda exige validação em preparação específica. ")
                    }
                }
            } else if (goalProjection?.projectedTimeSeconds != null) {
                append("Projeção aproximada para ${formatKm(input.goalKm)} km: ${PhysiologicalProfileEngine.formatDuration(goalProjection.projectedTimeSeconds)}; não é garantia de resultado nem substitui bloco específico. ")
            }
            if (paceZones != null) {
                if (input.cooperDistanceKm != null) {
                    append("As zonas Z1–Z5 são faixas operacionais estimadas pelo Cooper. percepção de esforço complementa a prescrição; não é medição laboratorial.")
                } else if (input.calibratedPaceZones?.method?.contains("3 km", ignoreCase = true) == true) {
                    append("As zonas Z1–Z5 usam a estimativa do teste de 3 km e são referências operacionais, não medições laboratoriais.")
                } else {
                    append("Sem teste de campo válido, as sessões usam esforço percebido até a calibração de Z1–Z5.")
                }
            } else {
                append("Sem Teste de Cooper ou referência anterior válida, o motor não inventa ritmo: as sessões usam alvos por distância/tempo e RPE apenas como orientação temporária. Registre a distância percorrida no Cooper de 12 minutos para calibrar Z1–Z5.")
            }
        }
        val contextualWorkouts = workouts.map { it.copy(experienceMonths = input.experienceMonths) }
        val firstWeekWorkouts = contextualWorkouts.filter { it.week == 1 }
        val intensityReport = IntensityDistributionEngine.summarize(firstWeekWorkouts)
        val firstWeekPhase = summaries.firstOrNull()?.phase ?: TrainingPeriodizationEngine.BASE
        val intensityTarget = IntensityDistributionEngine.target(input.goalCategory, input.level, firstWeekPhase)
        val finalDecision = decision.copy(rationale = decision.rationale)
        val conciseExplanation = buildString {
            append(decision.rationale)
            append(" Distribuição planejada da primeira semana: ")
            append("baixa ${intensityReport.lowIntensityPercent}%, moderada ${intensityReport.moderateIntensityPercent}%, alta ${intensityReport.highIntensityPercent}%. ")
            append("Faixa orientativa para esta fase: baixa ${intensityTarget.lowMinPercent}–${intensityTarget.lowMaxPercent}%, moderada ${intensityTarget.moderateMinPercent}–${intensityTarget.moderateMaxPercent}%, alta ${intensityTarget.highMinPercent}–${intensityTarget.highMaxPercent}%. ")
            append(intensityTarget.note)
        }
        return MotorPlan(finalState, finalDecision, contextualWorkouts, firstWeekKm, conciseExplanation, summaries, intensityReport, intensityTarget)
    }

    private fun buildWeek(
        input: RunnerInput,
        targetWeekKm: Double,
        week: Int,
        phase: String,
        suppressQuality: Boolean
    ): List<PrescribedWorkout> {
        val goalReadiness = TrainingPeriodizationEngine.goalSpecificReadiness(input)
        val novice = isNovicePlan(input)
        val days = trainingDays(input)
        val dayCount = days.size
        val longDay = input.preferredLongRunDay?.takeIf { it in days } ?: days.last()
        // Long-run progression is planned across the cycle, then held/reduced for recovery.
        // It is not frozen permanently at 110% of the onboarding value.
        val sessionCap = TrainingPeriodizationEngine.plannedLongRunCap(
            goalKm = input.goalKm,
            longestRecentKm = input.longestRecentKm,
            week = week,
            recoveryAllowsProgression = !input.painPresent &&
                (input.recoveryScore == null || input.recoveryScore >= 50.0) &&
                (input.fatigueScore == null || input.fatigueScore < 75.0)
        )

        val longIndex = days.indexOf(longDay)
        val qualityDay = TrainingScheduleEngine.qualityDayWithRecoveryGap(days, longDay)
        val selectionZones = input.calibratedPaceZones ?: PaceCalculator.limitCalibrationChange(
            PaceCalculator.calculateCooper(input.cooperDistanceKm, input.talkTestComfortPaceValues),
            PaceCalculator.calculateCooper(input.previousCooperDistanceKm, input.talkTestComfortPaceValues),
            maxBoundaryShiftSeconds = 15
        )
        val selectedProtocol = TrainingPeriodizationEngine.selectProtocolCode(input, phase, selectionZones, week)
        val allowQuality = !suppressQuality && !novice && selectedProtocol != null &&
            dayCount >= 3 && targetWeekKm >= 8.0 && qualityDay != null

        // A distribuição muda com a frequência. Não existe uma fração universal do longão:
        // com poucas sessões ele ocupa uma parcela maior; com mais dias, uma parcela menor.
        // Em todas as frequências, o longão deve ser a maior sessão se o histórico permitir.
        // Each priority gets a distinct distribution profile, rather than a minor adjustment.
        // Shares are targets for distribution, not permission to exceed individual session caps.
        val longShare = when (dayCount) {
            2 -> 0.53
            3 -> when (input.goalIntent) {
                TrainingGoalIntent.CONTINUOUS -> 0.44
                TrainingGoalIntent.COMPLETE -> 0.40
                TrainingGoalIntent.PERSONAL_BEST -> 0.36
                TrainingGoalIntent.TARGET_TIME -> 0.37
                else -> 0.40
            }
            4 -> when (input.goalIntent) {
                TrainingGoalIntent.CONTINUOUS -> 0.37
                TrainingGoalIntent.COMPLETE -> 0.34
                TrainingGoalIntent.PERSONAL_BEST -> 0.30
                TrainingGoalIntent.TARGET_TIME -> 0.31
                else -> 0.34
            }
            5 -> when (input.goalIntent) {
                TrainingGoalIntent.CONTINUOUS -> 0.35
                TrainingGoalIntent.COMPLETE -> 0.32
                TrainingGoalIntent.PERSONAL_BEST -> 0.29
                TrainingGoalIntent.TARGET_TIME -> 0.30
                else -> 0.32
            }
            else -> when (input.goalIntent) {
                TrainingGoalIntent.CONTINUOUS -> 0.33
                TrainingGoalIntent.COMPLETE -> 0.30
                TrainingGoalIntent.PERSONAL_BEST -> 0.27
                TrainingGoalIntent.TARGET_TIME -> 0.28
                else -> 0.30
            }
        }
        val qualityShare = when (dayCount) {
            2 -> 0.0
            3 -> when (input.goalIntent) {
                TrainingGoalIntent.COMPLETE -> 0.15
                TrainingGoalIntent.CONTINUOUS -> 0.18
                TrainingGoalIntent.PERSONAL_BEST -> 0.30
                TrainingGoalIntent.TARGET_TIME -> 0.28
                else -> 0.15
            }
            4 -> when (input.goalIntent) {
                TrainingGoalIntent.COMPLETE -> 0.12
                TrainingGoalIntent.CONTINUOUS -> 0.16
                TrainingGoalIntent.PERSONAL_BEST -> 0.26
                TrainingGoalIntent.TARGET_TIME -> 0.24
                else -> 0.12
            }
            5 -> when (input.goalIntent) {
                TrainingGoalIntent.COMPLETE -> 0.10
                TrainingGoalIntent.CONTINUOUS -> 0.14
                TrainingGoalIntent.PERSONAL_BEST -> 0.22
                TrainingGoalIntent.TARGET_TIME -> 0.21
                else -> 0.10
            }
            else -> when (input.goalIntent) {
                TrainingGoalIntent.COMPLETE -> 0.08
                TrainingGoalIntent.CONTINUOUS -> 0.12
                TrainingGoalIntent.PERSONAL_BEST -> 0.20
                TrainingGoalIntent.TARGET_TIME -> 0.19
                else -> 0.08
            }
        }

        // Keep the long run visibly largest while avoiding the previous under-allocation
        // bug for small weekly targets (e.g. 3 km target -> 2 km actually prescribed).
        // The non-long cap is only 0.2 km below the long run; the remaining weekly dose
        // can therefore be distributed without artificially truncating every easy session.
        val averageSessionKm = targetWeekKm / dayCount.coerceAtLeast(1)
        val minimumDominantLongKm = round1(averageSessionKm + 0.2)
        // 0.1 km precision prevents small weekly increases from disappearing when a
        // long-run share is rounded to 0.5 km. The weekly cap and readiness remain authoritative.
        var longKm = min(sessionCap, max(round1(targetWeekKm * longShare), minimumDominantLongKm))
            .coerceAtLeast(min(0.5, targetWeekKm))
        var nonLongCap = (longKm - 0.2).coerceAtLeast(0.1)

        var qualityKm = if (allowQuality) {
            min(min(sessionCap, nonLongCap), round1(targetWeekKm * qualityShare))
                .coerceAtLeast(min(0.5, targetWeekKm - longKm))
        } else 0.0

        // A qualidade só entra quando há pelo menos um dia completo sem corrida
        // entre ela e o longão. Se a disponibilidade não permitir, ela é suprimida.
        val qualityIndex = if (allowQuality) days.indexOf(qualityDay) else -1
        val easyIndices = days.indices.filter { it != longIndex && (!allowQuality || it != qualityIndex) }
        // Com apenas duas corridas semanais não há sessão de qualidade: o longão precisa
        // superar a única rodagem fácil, inclusive após arredondamento em semanas leves.
        if (easyIndices.size == 1 && !allowQuality) {
            val minimumDominantLong = round1(targetWeekKm / dayCount + 0.2)
            longKm = min(sessionCap, max(longKm, minimumDominantLong))
            nonLongCap = (longKm - 0.2).coerceAtLeast(0.1)
        }
        var easyTotal = max(0.0, targetWeekKm - longKm - qualityKm)

        // Na frequência de 3 dias há apenas uma rodagem fácil além da qualidade e do longão.
        // Se a limitação histórica reduzir o longão, transferimos parte do volume para o bloco
        // de qualidade (que inclui aquecimento/recuperações/desaquecimento) antes de reduzir a semana.
        if (easyIndices.size == 1 && easyTotal > nonLongCap && allowQuality) {
            val extraNeeded = easyTotal - nonLongCap
            val qualityRoom = (nonLongCap - qualityKm).coerceAtLeast(0.0)
            val transfer = min(extraNeeded, qualityRoom)
            qualityKm = round1(qualityKm + transfer)
            easyTotal = max(0.0, targetWeekKm - longKm - qualityKm)
        }

        val easySessionCap = min(sessionCap, nonLongCap)
        val easyDistances = distributeDistance(easyTotal, easyIndices.size, easySessionCap)
        // Technical strides are assigned to one suitable easy day only, never every
        // easy session. They are omitted when a quality workout is already scheduled.
        val strideDayIndex = if (!novice && !suppressQuality && !allowQuality && dayCount >= 3) {
            easyIndices.firstOrNull { idx -> easyDistances.getOrElse(easyIndices.indexOf(idx)) { 0.0 } >= 4.0 &&
                TrainingScheduleEngine.circularGapDays(days[idx], longDay) >= 2 }
        } else null
        val progressionDayIndex = easyIndices.firstOrNull()
        var easyCursor = 0
        val startMonday = input.startDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))

        return days.mapIndexed { index, day ->
            val date = startMonday.plusWeeks((week - 1).toLong()).plusDays(day.value - 1L)
            when {
                day == longDay -> createLongRun(input, date, longKm, week, phase)
                allowQuality && index == qualityIndex -> createQuality(input, date, qualityKm, week, phase)
                else -> {
                    val km = easyDistances.getOrElse(easyCursor++) { 0.5 }
                    // Acelerações técnicas são ocasionais e só entram quando não há
                    // sessão de qualidade na semana; não são usadas em iniciantes,
                    // semanas regenerativas ou sessões próximas do longão.
                    val style = when {
                        suppressQuality -> "EASY"
                        input.goalIntent == TrainingGoalIntent.CONTINUOUS ->
                            if ((week - 1) % 4 == 2 && index == progressionDayIndex) "PROGRESSION" else "EASY"
                        input.goalIntent == TrainingGoalIntent.PERSONAL_BEST -> when ((week - 1) % 4) {
                            1 -> if (index == strideDayIndex) "STRIDES" else "EASY"
                            2 -> if (index == progressionDayIndex) "PROGRESSION" else "EASY"
                            else -> "EASY"
                        }
                        input.goalIntent == TrainingGoalIntent.TARGET_TIME -> when ((week - 1) % 4) {
                            1 -> if (index == progressionDayIndex) "PROGRESSION" else "EASY"
                            2 -> if (index == progressionDayIndex) "REGRESSION" else "EASY"
                            else -> "EASY"
                        }
                        input.goalIntent == TrainingGoalIntent.COMPLETE -> "EASY"
                        index == strideDayIndex -> "STRIDES"
                        else -> "EASY"
                    }
                    createEasy(input, date, km, week, phase, recovery = suppressQuality, style = style)
                }
            }
        }
    }

    private fun distributeDistance(totalKm: Double, count: Int, sessionCapKm: Double): List<Double> {
        if (count <= 0) return emptyList()
        var remaining = round1(totalKm.coerceAtLeast(0.0))
        return (0 until count).map { index ->
            val slotsLeft = count - index
            if (slotsLeft == 1) {
                min(sessionCapKm, remaining).coerceAtLeast(0.1).also { remaining = 0.0 }
            } else {
                val minimumForEachRemaining = if (remaining >= slotsLeft * 0.5) 0.5 else max(0.1, remaining / slotsLeft)
                val maxForCurrent = min(sessionCapKm, remaining - minimumForEachRemaining * (slotsLeft - 1))
                    .coerceAtLeast(minimumForEachRemaining)
                val desired = round1(remaining / slotsLeft)
                val allocated = round1(desired.coerceIn(minimumForEachRemaining, maxForCurrent))
                remaining = round1((remaining - allocated).coerceAtLeast(0.0))
                allocated
            }
        }
    }

    private fun createEasy(input: RunnerInput, date: LocalDate, km: Double, week: Int, phase: String, recovery: Boolean, style: String = "EASY"): PrescribedWorkout {
        val experiencedRegeneration = recovery && input.experienceMonths > 11 && !input.painPresent &&
            ((input.activeWeeksLast4 >= 3) || input.recentActivityHistoryReliable ||
                (input.recentActivityCount >= 4 && input.weeklyVolumeKm >= 5.0)) &&
            (input.fatigueScore == null || input.fatigueScore < 75.0) &&
            (input.recoveryScore == null || input.recoveryScore >= 45.0)
        if (isNovicePlan(input) && !experiencedRegeneration) return createRunWalk(input, date, km, week, phase, recovery, isLongRun = false)
        val rpe = if (recovery) "2-3" else "3-4"
        val warmupKm = round1(km * 0.2)
        val mainKm = round1(km * 0.6)
        val cooldownKm = round1((km - warmupKm - mainKm).coerceAtLeast(0.0))
        val zones = input.calibratedPaceZones ?: PaceCalculator.limitCalibrationChange(
            PaceCalculator.calculateCooper(input.cooperDistanceKm, input.talkTestComfortPaceValues),
            PaceCalculator.calculateCooper(input.previousCooperDistanceKm, input.talkTestComfortPaceValues),
            maxBoundaryShiftSeconds = 15
        )
        val effectiveStyle = when {
            style in setOf("PROGRESSION", "REGRESSION") && mainKm < 1.2 -> "EASY"
            style == "STRIDES" && km < 4.0 -> "EASY"
            else -> style
        }
        val allowZ3 = effectiveStyle in setOf("PROGRESSION", "REGRESSION") &&
            isZ3EligibleForAerobicProgression(input, zones) && mainKm >= 2.4
        val title = when {
            recovery -> "Rodagem regenerativa"
            effectiveStyle == "PROGRESSION" && allowZ3 -> "Rodagem progressiva Z2–Z3"
            effectiveStyle == "PROGRESSION" -> "Rodagem progressiva Z2"
            effectiveStyle == "REGRESSION" && allowZ3 -> "Rodagem regressiva Z3–Z2"
            effectiveStyle == "REGRESSION" -> "Rodagem regressiva Z2"
            effectiveStyle == "STRIDES" -> "Rodagem com acelerações"
            else -> "Rodagem leve"
        }
        // Non-walk/run sessions never use Z1 as a generic warm-up/cool-down.
        // Z1 remains reserved for explicit beginner run/walk prescriptions.
        val transitionZone = "Z2"
        val transitionBand = ActiveZoneBand(0, 20)
        val warmInstruction = "Aqueça em Z2 0–20%, na parte mais lenta da zona, sem acelerar antes de o corpo estar confortável."
        val warm = zoneSegment(
            "Aquecimento", warmInstruction, warmupKm, transitionZone, zones, "1-2", transitionBand
        )
        val aerobicZoneId = "Z2"
        val mainSegments = when {
            recovery && experiencedRegeneration -> listOf(zoneSegment(
                "Bloco regenerativo Z2", "Mantenha corrida regenerativa em Z2 20–50%, confortável e conversável. Não acelere além da faixa; reduza a duração se a recuperação não estiver adequada.",
                mainKm, "Z2", zones, "2-3", ActiveZoneBand(20, 50)
            ))
            recovery -> listOf(zoneSegment(
                "Bloco regenerativo Z2 confortável", "Mantenha Z2 na faixa conservadora (20–35%), acima da transição de aquecimento, sem transformar a regeneração em treino de ritmo. Reduza a sessão se a recuperação não estiver adequada.",
                mainKm, "Z2", zones, "2-3", ActiveZoneBand(20, 35)
            ))
            effectiveStyle == "PROGRESSION" || effectiveStyle == "REGRESSION" ->
                buildProgressionRegressionSegments(mainKm, effectiveStyle, zones, allowZ3, longRun = false)
            effectiveStyle == "STRIDES" -> listOf(zoneSegment(
                "Bloco aeróbio Z2", "Corrida confortável antes das acelerações; não transforme a sessão em sprint.", mainKm, "Z2", zones, "3-4"
            ))
            else -> listOf(zoneSegment(
                "Bloco aeróbio $aerobicZoneId", "Converse em frases completas; reduza o ritmo se a respiração ficar difícil.",
                mainKm, aerobicZoneId, zones, rpe
            ))
        }
        val segments = mutableListOf(warm)
        segments += mainSegments
        if (effectiveStyle == "STRIDES" && !recovery && km >= 4.0) {
            // Three individual accelerations with exactly two timed recoveries. Distances
            // attached to TIME steps are estimates for weekly-volume accounting only.
            val strideDistanceEach = 0.05
            val recoveryDistanceEach = 0.10
            val strideSeconds = 12
            val recoverySeconds = 75
            repeat(3) { index ->
                segments += WorkoutSegment(
                    name = "Aceleração ${index + 1}",
                    instruction = "Acelere por 10–15 segundos de forma rápida, relaxada e tecnicamente estável; não faça sprint máximo e não persiga pace numérico.",
                    durationSeconds = strideSeconds, distanceKm = strideDistanceEach,
                    intensity = "HIGH", rpeRange = "6-7", targetMode = "TIME"
                )
                if (index < 2) segments += WorkoutSegment(
                    name = "Recuperação ${index + 1}",
                    instruction = "Recupere por 60–90 segundos caminhando ou trotando muito leve. Só inicie a próxima aceleração quando a respiração estiver controlada.",
                    durationSeconds = recoverySeconds, distanceKm = recoveryDistanceEach,
                    intensity = "LOW", rpeRange = "1-2", targetMode = "TIME", recoveryMode = "WALK"
                )
            }
        }
        val usedKm = segments.sumOf { (it.distanceKm ?: 0.0) * it.repeatCount }
        val remainder = round1((km - usedKm).coerceAtLeast(0.0))
        if (remainder > 0.0) {
            val coolZone = "Z2"
            val coolBand = ActiveZoneBand(0, 20)
            val coolInstruction = if (recovery)
                "Desaqueça em Z2 0–20%, na parte mais lenta da zona e mais fácil que o bloco principal."
            else "Reduza gradualmente em Z2 0–20%, sem terminar mais rápido que o bloco principal."
            segments += zoneSegment("Desaquecimento", coolInstruction, remainder, coolZone, zones, "1-2", coolBand)
        }
        val total = segments.sumOf { (it.distanceKm ?: 0.0) * it.repeatCount }
        val stimulus = when {
            recovery && experiencedRegeneration -> "RECOVERY_Z2_EXPERIENCED"
            recovery -> "RECOVERY_Z2_CONSERVATIVE"
            effectiveStyle == "PROGRESSION" && allowZ3 -> "EASY_AEROBIC_Z2_Z3_PROGRESSIVE"
            effectiveStyle == "PROGRESSION" -> "EASY_AEROBIC_Z2_PROGRESSIVE"
            effectiveStyle == "REGRESSION" && allowZ3 -> "EASY_AEROBIC_Z3_Z2_REGRESSIVE"
            effectiveStyle == "REGRESSION" -> "EASY_AEROBIC_Z2_REGRESSIVE"
            effectiveStyle == "STRIDES" -> "EASY_WITH_STRIDES_Z2_Z5"
            else -> "EASY_AEROBIC_Z2"
        }
        val rationale = when {
            recovery && experiencedRegeneration -> "Regenerativo para corredor com mais de 11 meses de prática consistente: transições em Z2 0–20% e parte principal em Z2 20–50%. Z1 não é aplicada automaticamente a corredores adaptados."
            recovery -> "Regenerativo conservador em Z2 confortável, com transições Z2 0–20%. Z1 é reservado ao protocolo explícito de caminhada/corrida para iniciantes."
            effectiveStyle == "PROGRESSION" && allowZ3 -> "Progressão por etapas Z2→Z2 mais rápida→Z3 controlada. Z1 aparece somente no aquecimento e no desaquecimento; os blocos têm faixas ativas contíguas."
            effectiveStyle == "PROGRESSION" -> "Progressão dentro da Z2: começa na faixa confortável e avança gradualmente para a parte mais rápida da zona, sem introduzir Z3 antes dos requisitos."
            effectiveStyle == "REGRESSION" && allowZ3 -> "Regressão por etapas Z3 controlada→Z2→Z2 confortável. Z1 fica reservada ao aquecimento e ao desaquecimento."
            effectiveStyle == "REGRESSION" -> "Regressão dentro da Z2: começa na parte mais rápida permitida e reduz gradualmente para a faixa confortável."
            zones != null -> "Ritmo individual por zona, derivado do Cooper e das calibrações válidas. O esforço deve continuar compatível com a zona e com as condições do dia."
            else -> "Sem teste de referência: mantenha esforço confortável e use o alvo por distância/tempo até calibrar as zonas."
        }
        val priorityRationale = when {
            phase == TrainingPeriodizationEngine.PREPARATION && input.goalIntent == TrainingGoalIntent.CONTINUOUS ->
                " Prioridade corrida contínua: a sessão progride dentro da Z2 para aumentar o tempo correndo sem acrescentar carga total."
            phase == TrainingPeriodizationEngine.PREPARATION && input.goalIntent == TrainingGoalIntent.PERSONAL_BEST ->
                " Prioridade recorde pessoal: neste bloco a base é preservada; estímulos de velocidade/ritmo específico aguardam os requisitos de prontidão."
            phase == TrainingPeriodizationEngine.PREPARATION && input.goalIntent == TrainingGoalIntent.TARGET_TIME ->
                " Prioridade tempo-alvo: o ritmo-alvo ainda não é perseguido na base preparatória; primeiro será consolidada a carga que permite sessões específicas."
            phase == TrainingPeriodizationEngine.PREPARATION && input.goalIntent == TrainingGoalIntent.COMPLETE ->
                " Prioridade completar: volume confortável e consistência têm precedência sobre velocidade nesta fase."
            else -> ""
        }
        return workout(date, title, if (recovery) "Recuperação" else "Aeróbio", "Construir consistência aeróbia", stimulus,
            total, rpe, week, phase, segments, rationale + priorityRationale, "LOW")
    }

    private data class ProgressionStageSpec(
        val zone: String,
        val band: ActiveZoneBand,
        val weight: Double,
        val name: String,
        val instruction: String,
        val rpe: String
    )

    /**
     * Z1 is intentionally excluded from the main progressive/regressive blocks.
     * When Z3 is not justified, the session changes pace only within Z2. When Z3 is
     * allowed, adjacent zone boundaries create a continuous Z2→Z3 or Z3→Z2 sequence.
     */
    private fun buildProgressionRegressionSegments(
        totalKm: Double,
        direction: String,
        zones: TrainingPaceZones?,
        allowZ3: Boolean,
        longRun: Boolean
    ): List<WorkoutSegment> {
        val progressive = direction == "PROGRESSION"
        if (totalKm < 0.3) return emptyList()
        if (totalKm < 1.2) return listOf(zoneSegment(
            "Bloco Z2 contínuo", "Mantenha Z2 confortável; a distância é curta demais para dividir em etapas progressivas/regressivas úteis.",
            round1(totalKm), "Z2", zones, "3-4", ActiveZoneBand(20, 65)
        ))
        val includeZ3 = allowZ3 && zones != null && totalKm >= (if (longRun) 4.0 else 2.4)
        val specs = if (includeZ3 && longRun) {
            if (progressive) listOf(
                ProgressionStageSpec("Z2", ActiveZoneBand(20, 40), 0.44, "Bloco inicial Z2", "Progrida da transição do aquecimento para Z2 20–40%, sem repetir a faixa inicial.", "3-4"),
                ProgressionStageSpec("Z2", ActiveZoneBand(40, 65), 0.44, "Bloco intermediário Z2", "Aumente gradualmente para Z2 40–65%, sem salto brusco.", "3-4"),
                ProgressionStageSpec("Z3", ActiveZoneBand(0, 20), 0.12, "Final progressivo Z3", "Somente no trecho final, entre na entrada da Z3 de forma controlada; recue para Z2 se perder o conforto.", "5-6")
            ) else listOf(
                ProgressionStageSpec("Z3", ActiveZoneBand(0, 20), 0.12, "Início moderado Z3", "Comece com um trecho curto e controlado na entrada da Z3; não transforme o longão em prova.", "5-6"),
                ProgressionStageSpec("Z2", ActiveZoneBand(40, 65), 0.44, "Bloco intermediário Z2", "Reduza para Z2 40–65% e mantenha esforço conversável.", "3-4"),
                ProgressionStageSpec("Z2", ActiveZoneBand(20, 40), 0.44, "Final confortável Z2", "Termine em Z2 20–40%, mais confortável que o bloco anterior.", "3-4")
            )
        } else if (includeZ3) {
            if (progressive) listOf(
                ProgressionStageSpec("Z2", ActiveZoneBand(20, 40), 0.34, "Bloco inicial Z2", "Comece em Z2 20–40%, após o aquecimento; não repita a faixa de transição.", "3-4"),
                ProgressionStageSpec("Z2", ActiveZoneBand(40, 65), 0.33, "Bloco intermediário Z2", "Aumente gradualmente para Z2 40–65%, sem salto de ritmo.", "3-4"),
                ProgressionStageSpec("Z3", ActiveZoneBand(0, 20), 0.33, "Bloco final Z3", "Finalize na entrada da Z3, moderado e controlado; retorne à Z2 se perder o conforto.", "5-6")
            ) else listOf(
                ProgressionStageSpec("Z3", ActiveZoneBand(0, 20), 0.33, "Bloco inicial Z3", "Comece na entrada da Z3 controlada, sem ultrapassar a faixa prescrita.", "5-6"),
                ProgressionStageSpec("Z2", ActiveZoneBand(40, 65), 0.33, "Bloco intermediário Z2", "Reduza para Z2 40–65% e mantenha a respiração estável.", "3-4"),
                ProgressionStageSpec("Z2", ActiveZoneBand(20, 40), 0.34, "Bloco final Z2", "Termine em Z2 20–40%, reduzindo o ritmo gradualmente.", "3-4")
            )
        } else if (longRun && totalKm >= 2.4) {
            // Long runs use three meaningful stages even when Z3 is not yet allowed.
            // Each stage receives at least 0.8 km so the progression is executable,
            // not just a cosmetic split of a very long block.
            if (progressive) listOf(
                ProgressionStageSpec("Z2", ActiveZoneBand(20, 35), 0.34, "Bloco inicial Z2 confortável", "Comece na parte confortável da Z2, logo acima da transição; mantenha conversa fácil.", "3-4"),
                ProgressionStageSpec("Z2", ActiveZoneBand(35, 50), 0.33, "Bloco intermediário Z2", "Aumente gradualmente dentro da Z2, sem salto brusco de ritmo.", "3-4"),
                ProgressionStageSpec("Z2", ActiveZoneBand(50, 65), 0.33, "Bloco final Z2 mais rápido", "Termine na parte mais rápida controlada da Z2; não avance para Z3 sem elegibilidade.", "3-4")
            ) else listOf(
                ProgressionStageSpec("Z2", ActiveZoneBand(50, 65), 0.33, "Bloco inicial Z2 mais rápido", "Comece na parte mais rápida permitida da Z2, sem transformar o longão em prova.", "3-4"),
                ProgressionStageSpec("Z2", ActiveZoneBand(35, 50), 0.33, "Bloco intermediário Z2", "Reduza gradualmente para a faixa central da Z2, mantendo controle.", "3-4"),
                ProgressionStageSpec("Z2", ActiveZoneBand(20, 35), 0.34, "Bloco final Z2 confortável", "Termine na faixa confortável da Z2, mais lento que os blocos anteriores.", "3-4")
            )
        } else {
            if (progressive) listOf(
                ProgressionStageSpec("Z2", ActiveZoneBand(20, 40), 0.45, "Bloco inicial Z2 confortável", "Depois do aquecimento, avance para Z2 20–40%; o bloco principal não repete a faixa de transição.", "3-4"),
                ProgressionStageSpec("Z2", ActiveZoneBand(40, 65), 0.55, "Bloco final Z2 mais rápido", "Aumente gradualmente para Z2 40–65%, sem avançar para Z3.", "3-4")
            ) else listOf(
                ProgressionStageSpec("Z2", ActiveZoneBand(40, 65), 0.45, "Bloco inicial Z2 mais rápido", "Comece em Z2 40–65%, mantendo controle.", "3-4"),
                ProgressionStageSpec("Z2", ActiveZoneBand(20, 40), 0.55, "Bloco final Z2 confortável", "Reduza gradualmente para Z2 20–40%, antes do desaquecimento.", "3-4")
            )
        }
        val minimumStageKm = if (longRun && specs.size >= 3) 0.8 else 0.3
        val distances = allocateStageDistances(totalKm, specs.map { it.weight }, minimumStageKm)
        return specs.mapIndexed { index, spec ->
            zoneSegment(spec.name, spec.instruction, distances[index], spec.zone, zones, spec.rpe, spec.band)
        }
    }

    private fun allocateStageDistances(totalKm: Double, weights: List<Double>, minimumStageKm: Double = 0.3): List<Double> {
        require(weights.isNotEmpty() && weights.all { it > 0.0 })
        val minimumTenths = (minimumStageKm * 10.0).roundToInt().coerceAtLeast(1)
        require(round1(totalKm) + 0.001 >= weights.size * minimumTenths / 10.0) { "Volume insuficiente para dividir em etapas úteis." }
        val totalTenths = (round1(totalKm) * 10.0).roundToInt().coerceAtLeast(weights.size * minimumTenths)
        var remaining = totalTenths
        val weightTotal = weights.sum()
        return weights.mapIndexed { index, weight ->
            val slotsAfter = weights.size - index - 1
            val tenths = if (slotsAfter == 0) remaining else {
                (totalTenths * weight / weightTotal).roundToInt()
                    .coerceIn(minimumTenths, (remaining - slotsAfter * minimumTenths).coerceAtLeast(minimumTenths))
            }
            remaining -= tenths
            tenths / 10.0
        }
    }

    private fun isZ3EligibleForAerobicProgression(input: RunnerInput, zones: TrainingPaceZones?): Boolean =
        TrainingPeriodizationEngine.thresholdEligible(input, zones)

    private fun zoneSegment(
        name: String,
        instruction: String,
        distanceKm: Double,
        zoneId: String,
        zones: TrainingPaceZones?,
        rpeRange: String,
        activeBand: ActiveZoneBand? = null
    ): WorkoutSegment {
        val zone = when (zoneId.uppercase()) {
            "Z1" -> zones?.z1
            "Z2" -> zones?.z2
            "Z3" -> zones?.z3
            "Z4" -> zones?.z4
            "Z5" -> zones?.z5
            else -> null
        }
        return WorkoutSegment(
            name = name,
            instruction = instruction,
            distanceKm = distanceKm,
            intensity = when (zoneId.uppercase()) {
                "Z3", "Z4" -> "MODERATE"
                "Z5" -> "HIGH"
                else -> "LOW"
            },
            rpeRange = rpeRange,
            targetPaceMinValue = zone?.range?.fastestPaceValue,
            targetPaceMaxValue = zone?.range?.slowestPaceValue,
            paceZone = zoneId,
            zoneIntensityMinPercent = activeBand?.minPercent,
            zoneIntensityMaxPercent = activeBand?.maxPercent
        )
    }

    private fun createQuality(input: RunnerInput, date: LocalDate, km: Double, week: Int, phase: String): PrescribedWorkout {
        val zones = input.calibratedPaceZones ?: PaceCalculator.limitCalibrationChange(
            PaceCalculator.calculateCooper(input.cooperDistanceKm, input.talkTestComfortPaceValues),
            PaceCalculator.calculateCooper(input.previousCooperDistanceKm, input.talkTestComfortPaceValues),
            maxBoundaryShiftSeconds = 15
        )
        val thresholdEligible = TrainingPeriodizationEngine.thresholdEligible(input, zones)
        val vo2Eligible = TrainingPeriodizationEngine.vo2Eligible(input, zones)
        val z3Eligible = isZ3EligibleForAerobicProgression(input, zones)
        val protocolCode = TrainingPeriodizationEngine.selectProtocolCode(input, phase, zones, week)
        val requestedKind = TrainingPeriodizationEngine.protocolKind(protocolCode)
            ?: TrainingPeriodizationEngine.selectQualityKind(input, phase, zones, week)
        val kind = when (requestedKind) {
            "MIXED_INTERVAL_Z3_Z4", "THRESHOLD_INTERVAL_Z3_Z4", "CRUISE_INTERVAL_Z3_Z4", "MIXED_INTERVAL_Z2_Z4" ->
                if (thresholdEligible) requestedKind else if (z3Eligible) "AEROBIC_INTERVAL_Z2_Z3" else "AEROBIC_INTERVAL_Z2"
            "MIXED_INTERVAL_Z4_Z5", "PYRAMID_INTERVAL_Z3_Z5", "FARTLEK_PYRAMID_Z3_Z5" -> when {
                vo2Eligible -> requestedKind
                thresholdEligible -> "MIXED_INTERVAL_Z3_Z4"
                z3Eligible -> "AEROBIC_INTERVAL_Z2_Z3"
                else -> "AEROBIC_INTERVAL_Z2"
            }
            else -> requestedKind
        }

        val warmKm = round1(km * 0.20)
        val coolKm = round1(km * 0.20)
        val mainBudget = round1((km - warmKm - coolKm).coerceAtLeast(0.5))
        val segments = mutableListOf<WorkoutSegment>()
        val protocolDefinition = TrainingProtocolCatalog.find(protocolCode)
        val explicitWorkZone = when {
            protocolDefinition?.family == "TEMPO" || protocolDefinition?.family == "RACE_PACE" -> if (z3Eligible) "Z3" else "Z2"
            protocolDefinition?.targetMode == "DISTANCE" && (protocolDefinition.workDistanceMeters ?: 0) <= 600 && vo2Eligible -> "Z5"
            thresholdEligible -> "Z4"
            z3Eligible -> "Z3"
            else -> "Z2"
        }
        val explicitWorkBand = when (explicitWorkZone) {
            "Z5" -> ActiveZoneBand(0, 20)
            "Z4" -> ActiveZoneBand(0, 20)
            "Z3" -> ActiveZoneBand(80, 100)
            else -> ActiveZoneBand(20, 65)
        }
        val explicitSegments = protocolDefinition?.let { definition ->
            buildExplicitProtocolSegments(km, zones, definition, explicitWorkZone, explicitWorkBand)
        }

        if (explicitSegments != null) {
            segments += explicitSegments
        } else if (protocolDefinition != null) {
            segments += asTimeTarget(zoneSegment(
                "Aquecimento", "Comece leve em Z1 e avance gradualmente para Z2 antes da rodagem controlada.",
                warmKm, "Z1", zones, "2-3", ZoneIntensityBandEngine.z1WarmupCoolDownBand
            ), zones)
            segments += asTimeTarget(zoneSegment(
                "Rodagem leve Z2", "A dose do protocolo nomeado não cabe com segurança no orçamento desta sessão. Faça uma rodagem confortável em Z2, sem manter o título de intervalo.",
                mainBudget, "Z2", zones, "3-4", ActiveZoneBand(20, 65)
            ), zones)
            segments += asTimeTarget(zoneSegment(
                "Desaquecimento", "Reduza gradualmente e finalize em Z1 confortável.",
                coolKm, "Z1", zones, "1-2", ZoneIntensityBandEngine.z1WarmupCoolDownBand
            ), zones)
        } else {
            segments += asTimeTarget(zoneSegment(
                "Aquecimento", "Comece leve em Z1 e avance gradualmente para Z2 antes do bloco principal; não antecipe o ritmo forte.",
                warmKm, "Z1", zones, "2-3", ZoneIntensityBandEngine.z1WarmupCoolDownBand
            ), zones)

            when (kind) {
            "PROGRESSIVE_RUN" -> {
                val useZ3 = z3Eligible && mainBudget >= 2.4
                segments += buildProgressionRegressionSegments(mainBudget, "PROGRESSION", zones, useZ3, longRun = false)
            }
            "STEADY_RUN" -> {
                val useZ3 = z3Eligible && mainBudget >= 2.0
                val zone = if (useZ3) "Z3" else "Z2"
                val band = if (useZ3) ActiveZoneBand(20, 60) else ActiveZoneBand(20, 65)
                segments += asTimeTarget(zoneSegment(
                    if (useZ3) "Corrida moderada sustentada Z3" else "Corrida aeróbia sustentada Z2",
                    if (useZ3) "Mantenha Z3 estável e controlada; reduza para Z2 se perder a técnica ou o controle respiratório."
                    else "Mantenha Z2 contínua e conversável. O objetivo é resistência, não correr no limite.",
                    mainBudget, zone, zones, if (useZ3) "5-6" else "3-4", band
                ), zones)
            }
            "TEMPO_RUN" -> {
                // Limiar é liberado pela carga tolerada e recuperação, nunca pelo rótulo fisiológico.
                val zone = when {
                    thresholdEligible -> "Z4"
                    z3Eligible -> "Z3"
                    else -> "Z2"
                }
                val band = when (zone) {
                    "Z4" -> ActiveZoneBand(25, 55)
                    "Z3" -> ActiveZoneBand(20, 60)
                    else -> ActiveZoneBand(20, 65)
                }
                segments += asTimeTarget(zoneSegment(
                    if (zone == "Z4") "Tempo controlado Z4 estimada" else if (zone == "Z3") "Ritmo sustentado Z3" else "Ritmo aeróbio sustentado Z2",
                    when (zone) {
                        "Z4" -> "Sustente esforço próximo ao limiar estimado, sem transformar o bloco em prova. Z4 não representa LT2 medido; use RPE e controle respiratório."
                        "Z3" -> "Mantenha esforço moderado estável e controlado; recue para Z2 se a respiração deixar de estar sob controle."
                        else -> "Mantenha esforço aeróbio confortável em Z2; como faltam evidências para intensidade superior, não force o ritmo."
                    },
                    mainBudget, zone, zones, if (zone == "Z4") "6-7" else if (zone == "Z3") "5-6" else "3-4", band
                ), zones)
            }
            "AEROBIC_INTERVAL_Z2", "AEROBIC_INTERVAL_Z2_Z3" -> {
                val aerobicPattern = if (kind.endsWith("Z2_Z3") && z3Eligible) listOf(
                    IntervalWorkStage("Z2", ActiveZoneBand(20, 65), "Bloco aeróbio Z2", "Acumule trabalho aeróbio em Z2, com conversa confortável.", "3-4", 1.0),
                    IntervalWorkStage("Z3", ActiveZoneBand(0, 20), "Bloco moderado Z3", "Suba apenas até a entrada da Z3, mantendo controle e sem acelerar abruptamente.", "5", 0.8),
                    IntervalWorkStage("Z2", ActiveZoneBand(65, 100), "Retorno à Z2 rápida", "Retorne à Z2 e estabilize a respiração antes do próximo ciclo.", "3-4", 1.0)
                ) else listOf(
                    IntervalWorkStage("Z2", ActiveZoneBand(20, 65), "Bloco aeróbio Z2", "Acumule trabalho aeróbio em Z2, mantendo a conversa confortável.", "3-4", 1.0),
                    IntervalWorkStage("Z2", ActiveZoneBand(65, 100), "Bloco Z2 mais rápido", "Aumente somente dentro da Z2; não ultrapasse a fronteira da zona.", "4", 0.8),
                    IntervalWorkStage("Z2", ActiveZoneBand(20, 65), "Bloco aeróbio Z2", "Retorne à faixa aeróbia controlada.", "3-4", 1.0)
                )
                segments += buildIntervalSequence(mainBudget, zones, aerobicPattern, recoveryFraction = 0.22, recoveryRpe = "2-3")
            }
            "MIXED_INTERVAL_Z3_Z4", "THRESHOLD_INTERVAL_Z3_Z4", "CRUISE_INTERVAL_Z3_Z4" -> {
                val protocolReps = when (protocolCode) {
                    "I04" -> 4
                    "I05" -> 6
                    "I06" -> 4
                    "I07", "I08" -> 5
                    "I09", "I10", "RP10" -> 3
                    "RP05" -> 4
                    "RP21" -> 2
                    "T04" -> 2
                    "T05" -> 3
                    else -> 0
                }
                if (protocolReps > 0) {
                    val isTempo = protocolCode == "T04" || protocolCode == "T05" || protocolCode == "RP21"
                    // I04/I07/I08/I09 and race-pace intervals may enter the lower edge of Z4
                    // whenever individual load and recovery allow it, including physiological beginners.
                    val targetZone = when {
                        isTempo -> "Z3"
                        thresholdEligible -> "Z4"
                        else -> "Z3"
                    }
                    segments += buildRepeatedIntervalPair(
                        totalKm = mainBudget,
                        zones = zones,
                        repetitions = protocolReps,
                        workZone = targetZone,
                        workBand = if (targetZone == "Z3") ActiveZoneBand(80, 100) else ActiveZoneBand(0, 20),
                        recoveryFraction = if (isTempo) 0.24 else 0.34,
                        workRpe = if (targetZone == "Z3") "5-6" else "6-7"
                    )
                } else {
                val cruise = kind == "CRUISE_INTERVAL_Z3_Z4"
                val pattern = listOf(
                    IntervalWorkStage("Z3", ActiveZoneBand(80, 100), "Trecho moderado Z3", "Entre na parte rápida da Z3 com controle, sem transformar o início em esforço máximo.", "5-6", 1.0),
                    IntervalWorkStage("Z4", ActiveZoneBand(0, 20), "Trecho de limiar Z4 estimada", "Aproxime-se da Z4 estimada sem ultrapassar a faixa prescrita; o limiar não foi medido em laboratório.", "6-7", 0.8),
                    IntervalWorkStage("Z3", ActiveZoneBand(80, 100), "Retorno controlado Z3", "Retorne à Z3 alta e mantenha a técnica estável.", "5-6", 1.0)
                )
                segments += buildIntervalSequence(mainBudget, zones, pattern, recoveryFraction = if (cruise) 0.24 else 0.30, recoveryRpe = "2-3")
                }
            }
            "MIXED_INTERVAL_Z2_Z4" -> {
                val pattern = listOf(
                    IntervalWorkStage("Z2", ActiveZoneBand(20, 65), "Bloco aeróbio Z2", "Acumule trabalho aeróbio em Z2 antes do estímulo de limiar.", "3-4", 1.2),
                    IntervalWorkStage("Z4", ActiveZoneBand(0, 20), "Estímulo curto Z4 estimada", "Entre apenas na faixa inicial da Z4 estimada, sem transformar o bloco em esforço máximo.", "6-7", 0.55),
                    IntervalWorkStage("Z2", ActiveZoneBand(0, 20), "Recuperação aeróbia Z2", "Recupere em Z2 confortável antes de repetir; não use Z1 como recuperação de intervalo.", "2-3", 1.0)
                )
                segments += buildIntervalSequence(mainBudget, zones, pattern, recoveryFraction = 0.34, recoveryRpe = "2-3")
            }
            "MIXED_INTERVAL_Z4_Z5" -> {
                val pattern = listOf(
                    IntervalWorkStage("Z4", ActiveZoneBand(80, 100), "Intervalo forte controlado Z4", "Comece no lado rápido da Z4 estimada, mantendo técnica e margem de controle.", "6-7", 1.0),
                    IntervalWorkStage("Z5", ActiveZoneBand(0, 20), "Aceleração curta Z5 estimada", "Use apenas o trecho curto de Z5, sem sprint máximo; interrompa a aceleração se a técnica se deteriorar.", "7-8", 0.55),
                    IntervalWorkStage("Z4", ActiveZoneBand(80, 100), "Retorno Z4", "Volte à Z4 controlada antes da próxima recuperação.", "6-7", 1.0)
                )
                segments += buildIntervalSequence(mainBudget, zones, pattern, recoveryFraction = 0.36, recoveryRpe = "2-3", recoveryZone = "Z1")
            }
            "PYRAMID_INTERVAL_Z3_Z5", "FARTLEK_PYRAMID_Z3_Z5" -> {
                val pattern = listOf(
                    IntervalWorkStage("Z3", ActiveZoneBand(80, 100), "Pirâmide — Z3", "Inicie com intensidade moderada, sem antecipar o pico.", "5-6", 0.8),
                    IntervalWorkStage("Z4", ActiveZoneBand(0, 20), "Pirâmide — Z4", "Aumente para a entrada da Z4 estimada, mantendo controle.", "6-7", 1.0),
                    IntervalWorkStage("Z5", ActiveZoneBand(0, 20), "Pirâmide — Z5 curta", "Pico curto e controlado; não transforme a repetição em sprint máximo.", "7-8", 0.65),
                    IntervalWorkStage("Z4", ActiveZoneBand(80, 100), "Pirâmide — retorno Z4", "Reduza para Z4 e preserve a mecânica.", "6-7", 1.0),
                    IntervalWorkStage("Z3", ActiveZoneBand(80, 100), "Pirâmide — final Z3", "Finalize em Z3 controlada e prepare-se para o desaquecimento.", "5-6", 0.8)
                )
                segments += buildIntervalSequence(mainBudget, zones, pattern, recoveryFraction = 0.38, recoveryRpe = "2-3", recoveryZone = "Z1")
            }
            "FARTLEK" -> {
                val pattern = when (protocolCode) {
                    // F01 from the supplied workbook: freely vary Z2-Z3 and recover with an easy Z2 jog.
                    // It is deliberately not promoted to Z4 just because the athlete qualifies
                    // for threshold work elsewhere in the plan.
                    "F01" -> if (((week - 1) / 4).mod(2) == 0) listOf(
                        // Formato alternado A: blocos aeróbios mais longos com duas entradas moderadas.
                        IntervalWorkStage("Z2", ActiveZoneBand(20, 65), "Fartlek aeróbio Z2", "Mantenha um trecho conversável em Z2; o ritmo deve parecer sustentável.", "3-4", 1.0),
                        IntervalWorkStage("Z3", ActiveZoneBand(0, 20), "Variação controlada Z3", "Aumente apenas até a entrada da Z3, sem sprint e sem perder o controle respiratório.", "4-5", 0.8),
                        IntervalWorkStage("Z2", ActiveZoneBand(20, 65), "Retorno aeróbio Z2", "Retorne à Z2 confortável antes da próxima variação.", "3-4", 1.0),
                        IntervalWorkStage("Z3", ActiveZoneBand(0, 20), "Variação controlada Z3", "Repita a variação moderada; encerre se a técnica se deteriorar.", "4-5", 0.8)
                    ) else listOf(
                        // Formato alternado B: pequenas ondas de ritmo, sem elevar a zona máxima.
                        IntervalWorkStage("Z2", ActiveZoneBand(20, 65), "Fartlek contínuo Z2", "Comece em Z2 confortável e estabilize a respiração.", "3-4", 1.0),
                        IntervalWorkStage("Z3", ActiveZoneBand(0, 20), "Aceleração curta Z3", "Faça uma aceleração curta e controlada até a entrada da Z3; não sprintar.", "4-5", 0.55),
                        IntervalWorkStage("Z2", ActiveZoneBand(20, 65), "Flutuação Z2", "Retorne ao trote confortável em Z2.", "3-4", 0.75),
                        IntervalWorkStage("Z3", ActiveZoneBand(0, 20), "Aceleração curta Z3", "Repita a aceleração com a mesma sensação de controle.", "4-5", 0.55),
                        IntervalWorkStage("Z2", ActiveZoneBand(20, 65), "Fechamento aeróbio Z2", "Finalize em Z2 estável, sem tentar compensar o ritmo.", "3-4", 1.0)
                    )
                    // F02 is a higher-demand variant; it requires the same threshold gate
                    // plus at least four running days, as specified in the workbook.
                    "F02" -> if (thresholdEligible && input.frequency >= 4) listOf(
                        IntervalWorkStage("Z3", ActiveZoneBand(80, 100), "Fartlek moderado Z3", "Acelere de forma controlada, sem iniciar no máximo.", "5-6", 1.0),
                        IntervalWorkStage("Z4", ActiveZoneBand(0, 20), "Fartlek forte Z4 estimada", "Entre apenas na faixa inicial da Z4 estimada; recue se perder controle.", "6-7", 0.7),
                        IntervalWorkStage("Z3", ActiveZoneBand(80, 100), "Fartlek moderado Z3", "Retorne à Z3 controlada.", "5-6", 1.0),
                        IntervalWorkStage("Z4", ActiveZoneBand(0, 20), "Fartlek forte Z4 estimada", "Última variação curta, sem sprint máximo.", "6-7", 0.6)
                    ) else listOf(
                        IntervalWorkStage("Z2", ActiveZoneBand(20, 65), "Variação aeróbia Z2", "Mantenha a variação dentro da Z2 conversável.", "3-4", 1.0),
                        IntervalWorkStage("Z3", ActiveZoneBand(0, 20), "Entrada moderada Z3", "Entre brevemente na Z3 somente se permanecer confortável.", "4-5", 0.7),
                        IntervalWorkStage("Z2", ActiveZoneBand(20, 65), "Retorno Z2", "Recupere em Z2.", "3-4", 1.0)
                    )
                    // F04 is a variable aerobic/threshold fartlek, selected only when the
                    // phase calls for variety. Z4 appears only when thresholdEligible.
                    else -> if (thresholdEligible) {
                        if (((week - 1) / 4).mod(2) == 0) listOf(
                            IntervalWorkStage("Z2", ActiveZoneBand(20, 65), "Variação aeróbia Z2", "Comece com controle aeróbio.", "3-4", 1.0),
                            IntervalWorkStage("Z3", ActiveZoneBand(80, 100), "Variação moderada Z3", "Aumente para Z3 alta de forma progressiva.", "5-6", 1.0),
                            IntervalWorkStage("Z4", ActiveZoneBand(0, 20), "Variação forte Z4 estimada", "Entre brevemente na parte inicial da Z4 estimada, sem sprint.", "6-7", 0.6),
                            IntervalWorkStage("Z2", ActiveZoneBand(20, 65), "Retorno confortável Z2", "Volte ao esforço aeróbio confortável.", "3-4", 1.0)
                        ) else listOf(
                            IntervalWorkStage("Z2", ActiveZoneBand(20, 65), "Entrada aeróbia Z2", "Estabilize o esforço antes da progressão.", "3-4", 1.0),
                            IntervalWorkStage("Z3", ActiveZoneBand(80, 100), "Progressão moderada Z3", "Suba gradualmente até Z3 alta, sem salto brusco.", "5-6", 0.9),
                            IntervalWorkStage("Z4", ActiveZoneBand(0, 20), "Toque curto Z4 estimada", "Toque apenas a entrada da Z4 estimada e volte a reduzir.", "6-7", 0.45),
                            IntervalWorkStage("Z3", ActiveZoneBand(80, 100), "Retorno Z3", "Recupere o controle em Z3 alta, sem manter o pico.", "5-6", 0.7),
                            IntervalWorkStage("Z2", ActiveZoneBand(20, 65), "Fechamento Z2", "Finalize em Z2 confortável.", "3-4", 1.0)
                        )
                    } else if (((week - 1) / 4).mod(2) == 0) listOf(
                        IntervalWorkStage("Z2", ActiveZoneBand(20, 65), "Variação aeróbia Z2", "Varie o ritmo sem ultrapassar o esforço conversável.", "3-4", 1.0),
                        IntervalWorkStage("Z3", ActiveZoneBand(0, 20), "Variação leve Z3", "Toque brevemente a entrada da Z3, mantendo controle.", "4-5", 0.7),
                        IntervalWorkStage("Z2", ActiveZoneBand(20, 65), "Retorno confortável Z2", "Retorne à Z2 confortável.", "3-4", 1.0)
                    ) else listOf(
                        IntervalWorkStage("Z2", ActiveZoneBand(20, 65), "Bloco confortável Z2", "Mantenha conversa confortável em Z2.", "3-4", 1.0),
                        IntervalWorkStage("Z3", ActiveZoneBand(0, 20), "Variação curta Z3", "Aumente brevemente até a entrada da Z3.", "4-5", 0.55),
                        IntervalWorkStage("Z2", ActiveZoneBand(20, 65), "Flutuação Z2", "Volte à Z2 confortável.", "3-4", 0.8),
                        IntervalWorkStage("Z3", ActiveZoneBand(0, 20), "Segunda variação Z3", "Repita a entrada moderada somente se a respiração estiver controlada.", "4-5", 0.55),
                        IntervalWorkStage("Z2", ActiveZoneBand(20, 65), "Fechamento Z2", "Encerre com esforço aeróbio confortável.", "3-4", 1.0)
                    )
                }
                segments += buildIntervalSequence(
                    mainBudget, zones, pattern,
                    recoveryFraction = if (protocolCode == "F01") 0.25 else if (thresholdEligible) 0.32 else 0.38,
                    recoveryRpe = "2-3",
                    // Fartlek recoveries stay in easy Z2 for F01/F02/F04. Z1 is reserved
                    // for explicitly passive/high-intensity protocols, not aerobic Fartlek.
                    recoveryZone = "Z2",
                    recoveryBand = ZoneIntensityBandEngine.fartlekActiveRecoveryBand,
                    // Match the established F01 library dose: two minutes between variations.
                    recoveryDurationMinutes = if (protocolCode == "F01") 2 else null
                )
            }
            "MARATHON_SPECIFIC" -> {
                val z3Km = if (z3Eligible && mainBudget >= 3.0) round1(mainBudget * 0.10) else 0.0
                val easyKm = round1((mainBudget - z3Km).coerceAtLeast(0.0))
                segments += asTimeTarget(zoneSegment(
                    "Resistência específica de maratona Z2",
                    "Mantenha Z2 confortável e estável; o objetivo é acumular resistência específica, não transformar o bloco em limiar.",
                    easyKm, "Z2", zones, "3-4", ActiveZoneBand(20, 65)
                ), zones)
                if (z3Km > 0.0) segments += asTimeTarget(zoneSegment(
                    "Final moderado controlado Z3",
                    "Trecho final curto e opcional em Z3. Se houver fadiga, mantenha Z2 em todo o bloco.",
                    z3Km, "Z3", zones, "5-6", ActiveZoneBand(0, 20)
                ), zones)
            }
            "ULTRA_SPECIFIC" -> {
                // Ultra preparation emphasizes time-on-feet and sustainable Z2, not repeated hard efforts.
                val ultraPattern = listOf(
                    IntervalWorkStage("Z2", ActiveZoneBand(0, 20), "Bloco confortável Z2", "Acumule tempo em Z2 confortável; use corrida/caminhada se necessário.", "3-4", 1.0),
                    IntervalWorkStage("Z2", ActiveZoneBand(20, 55), "Bloco sustentado Z2", "Mantenha resistência aeróbia em Z2, sem procurar limiar.", "3-4", 1.0),
                    IntervalWorkStage("Z2", ActiveZoneBand(0, 20), "Bloco final confortável Z2", "Reduza o esforço e termine com reserva.", "2-3", 1.0)
                )
                segments += buildIntervalSequence(mainBudget, zones, ultraPattern, recoveryFraction = 0.15, recoveryRpe = "2-3")
            }
            else -> {
                val safePattern = listOf(
                    IntervalWorkStage("Z3", ActiveZoneBand(80, 100), "Fartlek moderado Z3", "Acelere de forma controlada em Z3, sem sprint.", "5-6", 1.0),
                    IntervalWorkStage("Z4", ActiveZoneBand(0, 20), "Fartlek forte Z4 estimada", "Aumente por um trecho curto na entrada da Z4 estimada, sem perder a técnica.", "6-7", 0.65),
                    IntervalWorkStage("Z3", ActiveZoneBand(80, 100), "Fartlek moderado Z3", "Retorne a Z3 antes da recuperação aeróbia.", "5-6", 1.0)
                )
                val effectivePattern = if (thresholdEligible) safePattern else listOf(
                    IntervalWorkStage("Z2", ActiveZoneBand(20, 65), "Fartlek aeróbio Z2", "Varie dentro da Z2, sem ultrapassar o esforço conversável.", "3-4", 1.0),
                    IntervalWorkStage("Z2", ActiveZoneBand(65, 100), "Fartlek Z2 mais rápido", "Acelere apenas dentro da Z2.", "4", 0.8),
                    IntervalWorkStage("Z2", ActiveZoneBand(20, 65), "Fartlek aeróbio Z2", "Retorne ao lado confortável da Z2.", "3-4", 1.0)
                )
                segments += buildIntervalSequence(mainBudget, zones, effectivePattern, recoveryFraction = 0.36, recoveryRpe = "2-3")
            }
        }

            segments += asTimeTarget(zoneSegment(
                "Desaquecimento", "Reduza gradualmente e termine em Z1 confortável.",
                coolKm, "Z1", zones, "1-2", ZoneIntensityBandEngine.z1WarmupCoolDownBand
            ), zones)
        }

        val titleBase = when (kind) {
            "PROGRESSIVE_RUN" -> if (z3Eligible) "Rodagem progressiva Z2–Z3" else "Rodagem progressiva Z2"
            "STEADY_RUN" -> if (z3Eligible) "Rodagem moderada sustentada Z3" else "Rodagem leve sustentada Z2"
            "TEMPO_RUN" -> when (segments.firstOrNull { it.name.contains("controlado") || it.name.contains("sustentado") }?.paceZone) {
                "Z4" -> "Tempo run Z4 estimada"
                "Z3" -> "Tempo run moderado Z3"
                else -> "Rodagem sustentada Z2"
            }
            "AEROBIC_INTERVAL_Z2", "AEROBIC_INTERVAL_Z2_Z3" -> if (segments.any { it.paceZone == "Z3" }) "Intervalado aeróbio Z2–Z3" else "Intervalado aeróbio Z2"
            "MIXED_INTERVAL_Z3_Z4", "THRESHOLD_INTERVAL_Z3_Z4" -> "Intervalado misto Z3–Z4"
            "CRUISE_INTERVAL_Z3_Z4" -> "Cruise intervals Z3–Z4"
            "MIXED_INTERVAL_Z2_Z4" -> "Intervalado aeróbio com estímulo Z4"
            "MIXED_INTERVAL_Z4_Z5" -> "Intervalado misto Z4–Z5"
            "PYRAMID_INTERVAL_Z3_Z5" -> "Intervalado piramidal Z3–Z5"
            "FARTLEK_PYRAMID_Z3_Z5" -> "Fartlek piramidal Z3–Z5"
            "MARATHON_SPECIFIC" -> "Resistência específica de maratona"
            "ULTRA_SPECIFIC" -> "Resistência específica de ultradistância"
            else -> if (thresholdEligible) "Fartlek misto Z3–Z4" else "Fartlek aeróbio Z2"
        }
        val title = when {
            explicitSegments != null && protocolDefinition != null -> explicitProtocolTitle(protocolDefinition, explicitSegments)
            protocolDefinition != null -> "Rodagem controlada"
            protocolCode != null -> TrainingPeriodizationEngine.protocolTitle(protocolCode)
            else -> WorkoutTitleSanitizer.clean(titleBase)
        }
        val objective = when (input.goalIntent) {
            TrainingGoalIntent.PERSONAL_BEST -> "Melhorar o recorde nos ${formatGoalDistance(input.goalKm)} com estímulo progressivo e recuperação suficiente"
            TrainingGoalIntent.TARGET_TIME -> "Desenvolver capacidade para aproximar-se do tempo-alvo sem substituir as zonas fisiológicas pelo ritmo de prova"
            TrainingGoalIntent.CONTINUOUS -> "Aumentar a capacidade de correr continuamente, controlando esforço e reduzindo pausas conforme a tolerância"
            TrainingGoalIntent.COMPLETE -> "Construir resistência para completar ${formatGoalDistance(input.goalKm)} com esforço sustentável"
            else -> when (kind) {
            "PROGRESSIVE_RUN" -> "Praticar progressão de ritmo sem sair do controle aeróbio"
            "STEADY_RUN" -> "Desenvolver resistência em ritmo sustentável"
            "TEMPO_RUN", "MIXED_INTERVAL_Z3_Z4", "THRESHOLD_INTERVAL_Z3_Z4", "CRUISE_INTERVAL_Z3_Z4" -> "Desenvolver tolerância ao esforço sustentado e controle de limiar estimado"
            "AEROBIC_INTERVAL_Z2", "AEROBIC_INTERVAL_Z2_Z3", "MIXED_INTERVAL_Z2_Z4" -> "Acumular trabalho aeróbio em blocos, com estímulos controlados e recuperação suficiente"
            "MIXED_INTERVAL_Z4_Z5", "PYRAMID_INTERVAL_Z3_Z5", "FARTLEK_PYRAMID_Z3_Z5" -> "Desenvolver potência aeróbia com estímulos curtos e recuperação suficiente"
            "MARATHON_SPECIFIC" -> "Desenvolver resistência específica para a maratona"
            "ULTRA_SPECIFIC" -> "Desenvolver tempo em movimento e resistência aeróbia prolongada, com intensidade sustentável"
            else -> "Desenvolver capacidade de variar intensidade e recuperar em movimento"
            }
        }
        val explicitStimulus = if (explicitSegments != null && protocolDefinition != null) {
            when (protocolDefinition.family) {
                "INTERVAL" -> if (protocolDefinition.targetMode == "DISTANCE") {
                    "INTERVAL_DISTANCE_${protocolDefinition.workDistanceMeters}M"
                } else {
                    "INTERVAL_TIME_${protocolDefinition.workDurationMinutes}MIN"
                }
                "TEMPO" -> "TEMPO_INTERVAL_${protocolDefinition.workDurationMinutes}MIN"
                "RACE_PACE" -> "RACE_PACE_${formatGoalDistance(input.goalKm)}KM"
                else -> "EXPLICIT_${protocolDefinition.family}"
            }
        } else null
        val stimulus = explicitStimulus ?: when (kind) {
            "PROGRESSIVE_RUN" -> if (segments.any { it.paceZone == "Z3" }) "PROGRESSION_RUN_Z2_Z3" else "PROGRESSION_RUN_Z2_ONLY"
            "STEADY_RUN" -> if (segments.any { it.paceZone == "Z3" }) "STEADY_RUN_Z3" else "STEADY_RUN_Z2"
            "TEMPO_RUN" -> "TEMPO_RUN_ESTIMATED"
            "AEROBIC_INTERVAL_Z2", "AEROBIC_INTERVAL_Z2_Z3" -> if (segments.any { it.paceZone == "Z3" }) "AEROBIC_INTERVAL_Z2_Z3" else "AEROBIC_INTERVAL_Z2"
            "MIXED_INTERVAL_Z3_Z4", "THRESHOLD_INTERVAL_Z3_Z4", "CRUISE_INTERVAL_Z3_Z4" -> "MIXED_INTERVAL_Z3_Z4"
            "MIXED_INTERVAL_Z2_Z4" -> "MIXED_INTERVAL_Z2_Z4"
            "MIXED_INTERVAL_Z4_Z5" -> "MIXED_INTERVAL_Z4_Z5_ESTIMATED"
            "PYRAMID_INTERVAL_Z3_Z5" -> "PYRAMID_INTERVAL_Z3_Z5_ESTIMATED"
            "FARTLEK_PYRAMID_Z3_Z5" -> "FARTLEK_PYRAMID_Z3_Z5_ESTIMATED"
            "MARATHON_SPECIFIC" -> if (segments.any { it.paceZone == "Z3" }) "MARATHON_ENDURANCE_Z2_Z3" else "MARATHON_ENDURANCE_Z2"
            "ULTRA_SPECIFIC" -> "ULTRA_ENDURANCE_Z2"
            else -> when (protocolCode) {
                "F01" -> "FARTLEK_Z2_Z3"
                "F02" -> if (thresholdEligible && input.frequency >= 4) "FARTLEK_Z3_Z4" else "FARTLEK_Z2_Z3"
                "F04" -> if (thresholdEligible) "FARTLEK_VARIABLE_Z2_Z4" else "FARTLEK_VARIABLE_Z2_Z3"
                else -> if (thresholdEligible) "FARTLEK_Z3_Z4" else "FARTLEK_Z2_Z3"
            }
        }
        val totalKm = segments.sumOf { (it.distanceKm ?: 0.0) * it.repeatCount }
        val stimulusWithProtocol = if (protocolCode != null && (protocolDefinition == null || explicitSegments != null)) "$stimulus:$protocolCode" else stimulus
        val rationale = when {
            explicitSegments != null && protocolDefinition != null -> "${protocolDefinition.purpose}. O alvo de cada repetição foi mantido no modo ${if (protocolDefinition.targetMode == "DISTANCE") "distância" else "tempo"}; a quantidade pode ser reduzida quando o orçamento de sessão não comportar a dose completa. Recuperações são contadas apenas entre repetições."
            kind == "FARTLEK" && protocolCode == "F01" -> "Fartlek aeróbio da biblioteca: variações em Z2–Z3 com recuperações leves. Não há estímulo Z4/Z5 nesta sessão."
            kind == "FARTLEK" && protocolCode == "F02" -> "Fartlek de maior demanda, liberado somente com pelo menos quatro dias de corrida, carga tolerada e recuperação favorável."
            kind == "FARTLEK" -> "Fartlek variável escolhido conforme a fase; a zona mais alta só aparece quando a carga e a recuperação permitem."
            kind == "PROGRESSIVE_RUN" && segments.any { it.paceZone == "Z3" } -> "Progressão Z2→Z2 mais rápida→Z3 controlada. Aquecimento e desaquecimento usam Z2 0–20% em sessões de corrida contínua; Z1 fica reservada ao protocolo de caminhada/corrida para iniciantes."
            kind == "PROGRESSIVE_RUN" -> "Progressão dentro da Z2, sem introduzir Z3 antes dos requisitos individuais. Aquecimento e desaquecimento seguem a experiência do corredor."
            kind == "MIXED_INTERVAL_Z4_Z5" || kind == "PYRAMID_INTERVAL_Z3_Z5" || kind == "FARTLEK_PYRAMID_Z3_Z5" -> "Sessão de intensidade mista liberada somente para perfil avançado/elite, volume e maior corrida recentes compatíveis e prontidão favorável. Z5 é estimada, não VO₂máx medido."
            kind == "MIXED_INTERVAL_Z3_Z4" || kind == "THRESHOLD_INTERVAL_Z3_Z4" || kind == "CRUISE_INTERVAL_Z3_Z4" || kind == "TEMPO_RUN" -> "Blocos de Z3/Z4 estimada, com recuperação aeróbia em Z2. Z4 não equivale a LT2 medido; RPE e controle respiratório complementam o ritmo."
            kind == "MIXED_INTERVAL_Z2_Z4" -> "Combina base Z2, estímulo breve de Z4 estimada e recuperação Z2 confortável. A intensidade superior só entra com consistência e prontidão adequadas."
            kind == "MARATHON_SPECIFIC" -> "Z2 predomina; eventual trecho Z3 é curto e condicionado à experiência e à carga tolerada."
            kind == "ULTRA_SPECIFIC" -> "A preparação de ultradistância prioriza tempo em movimento, Z2 sustentável, estratégia corrida/caminhada e recuperação; não adiciona intensidade alta automaticamente."
            else -> "Sessão selecionada conforme objetivo, fase do ciclo, experiência, carga recente e recuperação. Cada bloco tem zona, faixa ativa, dose e RPE coerentes."
        }
        val actualHighZone = segments.any { it.paceZone in setOf("Z4", "Z5") }
        return workout(date, title, "Qualidade", objective, stimulusWithProtocol, totalKm,
            if (actualHighZone) "6-7" else "4-6", week, phase, segments, rationale, "MODERATE")
    }

    private fun buildExplicitProtocolSegments(
        totalSessionKm: Double,
        zones: TrainingPaceZones?,
        protocol: TrainingProtocolDefinition,
        workZone: String,
        workBand: ActiveZoneBand
    ): List<WorkoutSegment>? {
        if (zones == null) return null
        val recoveryMode = when (workZone) {
            "Z5" -> "PASSIVE"
            "Z4" -> "WALK"
            else -> "ACTIVE_Z2"
        }
        val recoveryBand = z2ActiveRecoveryBand()
        // Active recovery stays in the comfortable 0–20% edge of Z2. High-intensity work
        // uses a time-based stop or walk according to effort. Stopped/walking
        // recovery is duration-only and adds no running distance or pace target.
        val recoveryDistanceEach = if (recoveryMode == "ACTIVE_Z2") {
            estimatedDistanceForMinutes(protocol.recoveryDurationMinutes, zones, "Z2", recoveryBand)
        } else 0.0
        val warmCoolMinimumKm = 0.70
        val workDistanceEach = protocol.workDistanceMeters?.div(1_000.0)
            ?: estimatedDistanceForMinutes(protocol.workDurationMinutes ?: return null, zones, workZone, workBand)

        val repetitions = (protocol.repetitions downTo 2).firstOrNull { reps ->
            val workTotal = workDistanceEach * reps
            val recoveryTotal = recoveryDistanceEach * (reps - 1)
            workTotal + recoveryTotal + warmCoolMinimumKm <= totalSessionKm + 0.05
        } ?: return null

        val workTotalKm = workDistanceEach * repetitions
        val recoveryTotalKm = recoveryDistanceEach * (repetitions - 1)
        val warmCoolKm = (totalSessionKm - workTotalKm - recoveryTotalKm).coerceAtLeast(warmCoolMinimumKm)
        val warmupKm = round1(warmCoolKm / 2.0)
        val cooldownKm = (totalSessionKm - workTotalKm - recoveryTotalKm - warmupKm).coerceAtLeast(0.25)
        val result = mutableListOf<WorkoutSegment>()

        // A progressive warm-up uses a short easy opening and a controlled Z2 preparation block.
        val firstWarmKm = round1(warmupKm * 0.55).coerceAtLeast(0.1)
        val finalWarmKm = (warmupKm - firstWarmKm).coerceAtLeast(0.1)
        result += asTimeTarget(zoneSegment(
            "Aquecimento leve", "Inicie em Z1 confortável, elevando gradualmente a temperatura e a cadência.",
            firstWarmKm, "Z1", zones, "1-2", ZoneIntensityBandEngine.z1WarmupCoolDownBand
        ), zones)
        result += asTimeTarget(zoneSegment(
            "Preparação em Z2", "Aproxime-se progressivamente do ritmo de trabalho, sem entrar no esforço do intervalo.",
            finalWarmKm, "Z2", zones, "2-3", ActiveZoneBand(20, 40)
        ), zones)

        val repeatedPairs = repetitions - 1
        val workName = "Intervalo"
        val workInstruction = if (protocol.targetMode == "DISTANCE") {
            "Percorra exatamente ${protocol.workDistanceMeters} metros na faixa individual de $workZone. Não substitua a distância por um tempo estimado."
        } else {
            "Mantenha exatamente ${protocol.workDurationMinutes} minutos na faixa individual de $workZone, com esforço controlado."
        }
        val recoveryInstruction = when (recoveryMode) {
            "PASSIVE" -> "Pausa parada por ${protocol.recoveryDurationMinutes} min. Permaneça parado e retome apenas quando o intervalo terminar."
            "WALK" -> "Caminhe por ${protocol.recoveryDurationMinutes} min para recuperar a respiração antes da próxima repetição."
            else -> "Recupere ${protocol.recoveryDurationMinutes} min em Z2 muito confortável; caminhe se necessário. A recuperação ocorre entre as repetições, nunca após a última."
        }

        fun workSegment(): WorkoutSegment {
            val base = zoneSegment(
                workName, workInstruction, workDistanceEach, workZone, zones,
                when (workZone) { "Z5" -> "7-8"; "Z4" -> "6-7"; "Z3" -> "5-6"; else -> "4-5" }, workBand
            )
            return if (protocol.targetMode == "DISTANCE") base.copy(
                repeatCount = 1,
                targetMode = "DISTANCE",
                durationMin = null
            ) else base.copy(
                repeatCount = 1,
                durationMin = protocol.workDurationMinutes,
                targetMode = "TIME"
            )
        }

        fun recoverySegment(): WorkoutSegment {
            if (recoveryMode == "PASSIVE") return WorkoutSegment(
                name = "Pausa parada", instruction = recoveryInstruction,
                durationMin = protocol.recoveryDurationMinutes, intensity = "LOW", rpeRange = "1-2",
                repeatCount = 1, targetMode = "TIME", recoveryMode = "PASSIVE"
            )
            val zone = if (recoveryMode == "WALK") null else "Z2"
            return if (recoveryMode == "WALK") WorkoutSegment(
                name = "Recuperação caminhando", instruction = recoveryInstruction,
                durationMin = protocol.recoveryDurationMinutes, intensity = "LOW", rpeRange = "1-2",
                repeatCount = 1, targetMode = "TIME", recoveryMode = "WALK"
            ) else zoneSegment(
                "Recuperação", recoveryInstruction, recoveryDistanceEach, zone!!, zones, "2-3", recoveryBand
            ).copy(
                repeatCount = 1, durationMin = protocol.recoveryDurationMinutes,
                targetMode = "TIME", recoveryMode = "ACTIVE_Z2"
            )
        }

        // Materialize every work interval and every inter-block recovery separately.
        // This is required by Pace Coach block-by-block execution: no compact repeat group.
        repeat(repetitions) { index ->
            result += workSegment()
            if (index < repetitions - 1) result += recoverySegment()
        }
        result += asTimeTarget(zoneSegment(
            "Desaquecimento", "Reduza gradualmente o ritmo e finalize em Z1 confortável.",
            cooldownKm, "Z1", zones, "1-2", ZoneIntensityBandEngine.z1WarmupCoolDownBand
        ), zones)
        return result
    }

    /** Easy active recovery uses the slow edge of Z2; high-intensity protocols may instead stop or walk. */
    private fun z2ActiveRecoveryBand(): ActiveZoneBand =
        ZoneIntensityBandEngine.z2ActiveRecoveryBand

    private fun estimatedDistanceForMinutes(
        durationMinutes: Int,
        zones: TrainingPaceZones,
        zoneId: String,
        band: ActiveZoneBand
    ): Double {
        val fullRange = zones.zone(zoneId)?.range ?: zones.z2.range
        val activeRange = ZoneIntensityBandEngine.activeRange(fullRange, band)
        val midpointPaceSeconds = (activeRange.fastestPaceValue + activeRange.slowestPaceValue) / 2.0
        return kotlin.math.round((durationMinutes * 60.0 / midpointPaceSeconds) * 100.0) / 100.0
    }

    private fun explicitProtocolTitle(protocol: TrainingProtocolDefinition, segments: List<WorkoutSegment>): String {
        val repetitions = segments.filter { it.name == "Intervalo" }.sumOf { it.repeatCount }
        return if (repetitions == protocol.repetitions) protocol.displayTitle else when (protocol.targetMode) {
            "DISTANCE" -> "Intervalado $repetitions × ${protocol.workDistanceMeters} m"
            else -> "Intervalado $repetitions × ${protocol.workDurationMinutes} min"
        }
    }

    private data class IntervalWorkStage(
        val zone: String,
        val band: ActiveZoneBand,
        val name: String,
        val instruction: String,
        val rpe: String,
        val weight: Double
    )

    /** Creates one work/recovery pair with a shared repeat count for compact export. */
    private fun buildRepeatedIntervalPair(
        totalKm: Double,
        zones: TrainingPaceZones?,
        repetitions: Int,
        workZone: String,
        workBand: ActiveZoneBand,
        recoveryFraction: Double,
        workRpe: String
    ): List<WorkoutSegment> {
        val repeatCount = repetitions.coerceAtLeast(1)
        val recoveryShare = recoveryFraction.coerceIn(0.15, 0.45)
        val workTotal = round1(totalKm * (1.0 - recoveryShare))
        val recoveryTotal = round1((totalKm - workTotal).coerceAtLeast(0.0))
        val workEach = round1(workTotal / repeatCount)
        val recoveryEach = round1(recoveryTotal / repeatCount)
        if (repeatCount <= 1 || workEach < 0.1 || recoveryEach < 0.1) {
            val fallback = IntervalWorkStage(
                workZone, workBand, "Intervalo",
                "Execute o bloco na zona prescrita, forte mas controlado.", workRpe, 1.0
            )
            return buildIntervalSequence(totalKm, zones, listOf(fallback), recoveryShare, "2-3")
        }
        val workInstruction = if (workZone == "Z3") {
            "Repita o intervalo em Z3, mantendo o controle respiratório e a técnica. Não acelere além da zona prescrita."
        } else {
            "Repita o intervalo em Z4 estimada, forte mas controlado. Não transforme em sprint; Z4 não confirma limiar laboratorial."
        }
        val recoveryInstruction = "Recupere em Z2 muito confortável entre os intervalos. Retome somente quando a respiração estiver controlada."
        return listOf(
            asTimeTarget(zoneSegment("Intervalo", workInstruction, workEach, workZone, zones, workRpe, workBand), zones)
                .copy(repeatCount = repeatCount),
            asTimeTarget(zoneSegment("Recuperação", recoveryInstruction, recoveryEach, "Z2", zones, "2-3", ZoneIntensityBandEngine.z2ActiveRecoveryBand), zones)
                .copy(repeatCount = repeatCount)
        )
    }

    /** Builds ordered On/Off intervals; work and recoveries are allocated from the exact main distance budget. */
    private fun buildIntervalSequence(
        totalKm: Double,
        zones: TrainingPaceZones?,
        workStages: List<IntervalWorkStage>,
        recoveryFraction: Double,
        recoveryRpe: String,
        recoveryZone: String = "Z2",
        recoveryDurationMinutes: Int? = null,
        recoveryBand: ActiveZoneBand? = null
    ): List<WorkoutSegment> {
        if (workStages.isEmpty() || totalKm < 1.2) {
            return listOf(asTimeTarget(zoneSegment(
                "Bloco aeróbio contínuo Z2", "Mantenha Z2 confortável; o volume disponível é curto demais para intervalos úteis.",
                round1(totalKm), "Z2", zones, "3-4", ZoneIntensityBandEngine.z2EasyTransitionBand
            ), zones))
        }
        val workBlocks = workStages.size
        val recoveryBlocks = workBlocks - 1
        val workKm = round1(totalKm * (1.0 - recoveryFraction.coerceIn(0.20, 0.50)))
        val recoveryKm = round1((totalKm - workKm).coerceAtLeast(0.0))
        if (workKm * 10.0 < workBlocks || recoveryBlocks > 0 && recoveryKm * 10.0 < recoveryBlocks) {
            return listOf(asTimeTarget(zoneSegment(
                "Bloco aeróbio contínuo Z2", "Mantenha Z2 confortável; não comprima intervalos em blocos pequenos demais.",
                round1(totalKm), "Z2", zones, "3-4", ActiveZoneBand(20, 65)
            ), zones))
        }
        val workDistances = allocateTenths(workKm, workStages.map { it.weight })
        val recoveryDistances = if (recoveryBlocks > 0) allocateTenths(recoveryKm, List(recoveryBlocks) { 1.0 }) else emptyList()
        val result = mutableListOf<WorkoutSegment>()
        var recoveryIndex = 0
        workStages.forEachIndexed { index, stage ->
            result += asTimeTarget(zoneSegment(
                stage.name, stage.instruction, workDistances[index], stage.zone, zones, stage.rpe, stage.band
            ), zones)
            if (index < workStages.lastIndex) {
                val selectedRecoveryBand = recoveryBand ?: if (recoveryZone == "Z1") ZoneIntensityBandEngine.z1ActiveRecoveryBand
                    else ZoneIntensityBandEngine.z2ActiveRecoveryBand
                val recoveryInstruction = if (recoveryZone == "Z1") {
                    "Recupere em Z1 na parte superior da zona (90–100%), trotando confortavelmente; caminhe apenas se necessário. Só inicie a próxima variação quando a respiração estiver controlada."
                } else if (recoveryBand != null) {
                    "Recupere com trote leve em Z2 confortável (0–20% da zona), nitidamente mais fácil que a variação. Caminhe apenas se não conseguir controlar a respiração."
                } else {
                    "Recupere em Z2 muito confortável (0–20% da zona). Mantenha o trote leve e só inicie o próximo bloco quando a respiração estiver controlada."
                }
                val recoverySegment = asTimeTarget(zoneSegment(
                    "Recuperação entre blocos $recoveryZone", recoveryInstruction,
                    recoveryDistances[recoveryIndex++], recoveryZone, zones, recoveryRpe, selectedRecoveryBand
                ), zones)
                result += if (recoveryDurationMinutes != null) recoverySegment.copy(
                    durationMin = recoveryDurationMinutes.coerceAtLeast(1), targetMode = "TIME",
                    recoveryMode = if (recoveryZone == "Z2") "ACTIVE_Z2" else "ACTIVE_Z1"
                ) else recoverySegment.copy(
                    recoveryMode = if (recoveryZone == "Z2") "ACTIVE_Z2" else "ACTIVE_Z1"
                )
            }
        }
        return result
    }

    private fun allocateTenths(totalKm: Double, weights: List<Double>): List<Double> {
        require(weights.isNotEmpty() && weights.all { it > 0.0 })
        val totalTenths = (round1(totalKm) * 10.0).roundToInt().coerceAtLeast(weights.size)
        val weightSum = weights.sum()
        var remaining = totalTenths
        return weights.mapIndexed { index, weight ->
            val slotsAfter = weights.size - index - 1
            val amount = if (slotsAfter == 0) remaining else {
                (totalTenths * weight / weightSum).roundToInt().coerceIn(1, (remaining - slotsAfter).coerceAtLeast(1))
            }
            remaining -= amount
            amount / 10.0
        }
    }

    private fun createLongRun(input: RunnerInput, date: LocalDate, km: Double, week: Int, phase: String): PrescribedWorkout {
        if (isNovicePlan(input)) return createRunWalk(input, date, km, week, phase, recovery = phase == "RECOVERY", isLongRun = true)
        val recoveryWeek = phase == "RECOVERY"
        val rpe = if (recoveryWeek) "2-3" else "3-4"
        val warmupKm = round1(km * 0.10)
        val mainKm = round1(km * 0.80)
        val cooldownKm = round1((km - warmupKm - mainKm).coerceAtLeast(0.0))
        val zones = input.calibratedPaceZones ?: PaceCalculator.limitCalibrationChange(
            PaceCalculator.calculateCooper(input.cooperDistanceKm, input.talkTestComfortPaceValues),
            PaceCalculator.calculateCooper(input.previousCooperDistanceKm, input.talkTestComfortPaceValues),
            maxBoundaryShiftSeconds = 15
        )
        val z3Eligible = input.goalCategory != "HEALTH" && zones != null && (input.level == "Performance" || input.level == "Avançado" || input.level == "Elite") &&
            input.weeklyVolumeKm >= 25.0 && input.longestRecentKm >= 12.0 && km >= 8.0 &&
            !input.painPresent && (input.recoveryScore == null || input.recoveryScore >= 75.0) &&
            (input.fatigueScore == null || input.fatigueScore < 65.0) &&
            TrainingPeriodizationEngine.hasRecentConsistencyEvidence(input)
        val cycleWeek = (week - 1) % 4
        val goalSpecificReady = TrainingPeriodizationEngine.goalSpecificReadiness(input).ready
        val style = when {
            recoveryWeek -> "STEADY_Z2"
            input.goalIntent == TrainingGoalIntent.COMPLETE -> "STEADY_Z2"
            input.goalIntent == TrainingGoalIntent.CONTINUOUS -> when (cycleWeek) {
                1 -> "PROGRESSIVE_Z2_ONLY"
                2 -> "REGRESSIVE_Z2_ONLY"
                else -> "STEADY_Z2"
            }
            input.goalIntent == TrainingGoalIntent.PERSONAL_BEST -> when (cycleWeek) {
                1 -> if (goalSpecificReady && z3Eligible) "PROGRESSIVE_Z2_Z3" else "PROGRESSIVE_Z2_ONLY"
                2 -> if (goalSpecificReady && z3Eligible) "REGRESSIVE_Z3_Z2" else "REGRESSIVE_Z2_ONLY"
                else -> "STEADY_Z2"
            }
            input.goalIntent == TrainingGoalIntent.TARGET_TIME -> when (cycleWeek) {
                1 -> if (goalSpecificReady && z3Eligible) "REGRESSIVE_Z3_Z2" else "REGRESSIVE_Z2_ONLY"
                2 -> if (goalSpecificReady && z3Eligible) "PROGRESSIVE_Z2_Z3" else "PROGRESSIVE_Z2_ONLY"
                else -> "STEADY_Z2"
            }
            else -> "STEADY_Z2"
        }
        val mainSegments = when (style) {
            "PROGRESSIVE_Z2_Z3", "PROGRESSIVE_Z2_ONLY" -> buildProgressionRegressionSegments(
                mainKm, "PROGRESSION", zones, allowZ3 = z3Eligible, longRun = true
            )
            "REGRESSIVE_Z3_Z2", "REGRESSIVE_Z2_ONLY" -> buildProgressionRegressionSegments(
                mainKm, "REGRESSION", zones, allowZ3 = z3Eligible, longRun = true
            )
            else -> listOf(zoneSegment(
                "Longão contínuo Z2", "Mantenha esforço conversável e constante em Z2. Não transforme o longão em prova.", mainKm, "Z2", zones, rpe
            ))
        }
        val segments = listOf(
            asTimeTarget(zoneSegment(
                "Aquecimento", "Comece na parte mais lenta da Z2 (0–20%), aumentando o esforço somente quando estiver confortável.",
                warmupKm, "Z2", zones, "2-3", ActiveZoneBand(0, 20)
            ), zones)
        ) + mainSegments + listOf(
            asTimeTarget(zoneSegment(
                "Desaquecimento", "Reduza gradualmente e encerre em Z2 0–20%, na parte mais lenta da zona.",
                cooldownKm, "Z2", zones, "1-2", ActiveZoneBand(0, 20)
            ), zones)
        )
        val title = when (style) {
            "PROGRESSIVE_Z2_Z3" -> "Longão progressivo Z2–Z3"
            "PROGRESSIVE_Z2_ONLY" -> "Longão progressivo Z2"
            "REGRESSIVE_Z3_Z2" -> "Longão regressivo Z3–Z2"
            "REGRESSIVE_Z2_ONLY" -> "Longão regressivo Z2"
            else -> if (recoveryWeek) "Longão reduzido" else "Longão contínuo"
        }
        val rationale = when (style) {
            "PROGRESSIVE_Z2_Z3" -> "A maior parte permanece em Z2; o final entra em Z3 por um trecho curto (até 12% da parte principal), somente com experiência, volume, longão recente e recuperação suficientes. Aquecimento e desaquecimento permanecem em Z2 0–20%; Z1 fica reservada ao protocolo de caminhada/corrida para iniciantes."
            "PROGRESSIVE_Z2_ONLY" -> "Progressão dentro da Z2, da faixa mais confortável para uma faixa mais rápida. Z3 não foi liberada pelo perfil/carga atual; Z1 fica reservada ao aquecimento e desaquecimento."
            "REGRESSIVE_Z3_Z2" -> "Comece com um trecho curto e controlado em Z3, reduza para Z2 e termine na parte confortável da Z2. Aquecimento e desaquecimento permanecem em Z2 0–20%; Z1 fica reservada ao protocolo de caminhada/corrida para iniciantes."
            "REGRESSIVE_Z2_ONLY" -> "Regressão dentro da Z2: comece na faixa mais rápida permitida e reduza gradualmente até a faixa confortável, sem entrar em Z3."
            else -> if (recoveryWeek) "Volume reduzido na semana regenerativa; mantenha esforço conversável em Z2. Aquecimento e desaquecimento são etapas próprias." else when (input.goalIntent) {
                TrainingGoalIntent.COMPLETE -> "Longão contínuo em Z2, priorizando tolerância e conclusão sustentável da distância."
                TrainingGoalIntent.CONTINUOUS -> "Longão voltado à continuidade: acumule corrida sustentada e evolua a duração sem pausas planejadas; a progressão será alternada por ciclos."
                TrainingGoalIntent.PERSONAL_BEST -> "Longão de suporte ao desempenho: mantenha a maior parte em Z2 e introduza final controlado apenas quando volume, consistência e recuperação permitirem."
                TrainingGoalIntent.TARGET_TIME -> "Longão orientado à meta de tempo: a progressão/regressão prepara a sustentação do esforço específico, sem transformar a sessão em prova."
                else -> "Longão contínuo em Z2 quando não há progressão específica nesta semana. A distância é limitada pelo maior treino recente, pela parcela semanal e pela prontidão."
            }
        }
        val stimulus = when (style) {
            "PROGRESSIVE_Z2_Z3" -> "LONG_RUN_PROGRESSIVE_Z2_Z3"
            "PROGRESSIVE_Z2_ONLY" -> "LONG_RUN_PROGRESSIVE_Z2"
            "REGRESSIVE_Z3_Z2" -> "LONG_RUN_REGRESSIVE_Z3_Z2"
            "REGRESSIVE_Z2_ONLY" -> "LONG_RUN_REGRESSIVE_Z2"
            else -> "AEROBIC_ENDURANCE"
        }
        return workout(date, title, "Longo", "Desenvolver resistência com carga compatível com a tolerância recente", stimulus,
            km, rpe, week, phase, segments, rationale, "LOW")
    }

    /** Progressive beginner/re-entry run-walk dose based on the supplied 5K/10K plans. */
    private fun createRunWalk(
        input: RunnerInput,
        date: LocalDate,
        km: Double,
        week: Int,
        phase: String,
        recovery: Boolean,
        isLongRun: Boolean
    ): PrescribedWorkout {
        val dose = TrainingPlanReferenceCatalog.runWalkDose(week, input.planWeeks, isLongRun, recovery, input.goalIntent)
        val zones = input.calibratedPaceZones ?: PaceCalculator.limitCalibrationChange(
            PaceCalculator.calculateCooper(input.cooperDistanceKm, input.talkTestComfortPaceValues),
            PaceCalculator.calculateCooper(input.previousCooperDistanceKm, input.talkTestComfortPaceValues),
            maxBoundaryShiftSeconds = 15
        )

        fun estimatedKm(minutes: Int, zone: String?): Double {
            val pace = if (zones != null && zone != null) {
                val range = zones.zone(zone)?.range ?: zones.z2.range
                (range.fastestPaceValue + range.slowestPaceValue) / 2.0
            } else if (zone == null) 720.0 else 510.0
            return kotlin.math.round((minutes * 60.0 / pace) * 100.0) / 100.0
        }

        fun timedSegment(name: String, instruction: String, minutes: Int, zone: String?, rpe: String): WorkoutSegment {
            val distance = estimatedKm(minutes, zone)
            if (zones != null && zone != null) {
                val band = ActiveZoneBand(20, 65)
                return asTimeTarget(zoneSegment(name, instruction, distance, zone, zones, rpe, band), zones)
                    .copy(durationMin = minutes, durationSeconds = null, targetMode = "TIME")
            }
            return WorkoutSegment(name, instruction, durationMin = minutes, distanceKm = distance, intensity = "LOW", rpeRange = rpe, targetMode = "TIME")
        }

        val segments = mutableListOf<WorkoutSegment>()
        segments += timedSegment(
            "Aquecimento caminhando",
            "Comece caminhando de forma confortável e aumente gradualmente a passada antes dos blocos de corrida.",
            dose.warmupMinutes, null, "1-2"
        )

        val runZone = if (zones != null) { if (recovery) "Z1" else "Z2" } else null
        val walk = timedSegment(
            "Caminhada de recuperação",
            "Caminhe até recuperar a respiração e então inicie a próxima repetição. Não elimine as pausas previstas.",
            dose.walkMinutes, null, "1-2"
        ).copy(repeatCount = dose.repetitions)
        val run = timedSegment(
            if (runZone == "Z1") "Corrida ativa Z1" else if (zones != null) "Corrida ativa Z2" else "Corrida leve",
            if (runZone == "Z1") "Nos trechos de corrida, mantenha esforço muito leve em Z1; caminhe nas recuperações e não acelere para compensar as pausas." else "Corra em ritmo leve e controlado. Mantenha a passada natural; não acelere para compensar os períodos de caminhada.",
            dose.runMinutes, runZone, "3-4"
        ).copy(repeatCount = dose.repetitions)
        // The source plans prescribe walk first, then jog, in each repeated pair.
        segments += walk
        segments += run
        dose.continuousRunMinutes?.let { minutes ->
            segments += timedSegment(
                "Corrida contínua",
                "Após os blocos alternados, mantenha corrida confortável pelo tempo indicado, sem forçar o ritmo.",
                minutes, runZone, "3-4"
            )
        }

        segments += timedSegment(
            "Desaquecimento caminhando",
            "Finalize caminhando devagar até a respiração voltar ao padrão confortável.",
            dose.cooldownMinutes, null, "1-2"
        )
        val totalKm = segments.sumOf { (it.distanceKm ?: 0.0) * it.repeatCount }
        val duration = segments.sumOf { (it.durationMin ?: 0) * it.repeatCount }
        val title = when {
            isLongRun && recovery -> "Longão leve com corrida/caminhada"
            isLongRun -> "Longão corrida/caminhada"
            recovery -> "Corrida/caminhada regenerativa"
            else -> "Corrida/caminhada progressiva"
        }
        val rationale = "Progressão baseada em alternância caminhada/trote das referências de 5 km e 10 km. A etapa atual é ${dose.repetitions} repetição(ões) de ${dose.runMinutes} min de trote + ${dose.walkMinutes} min caminhando${dose.continuousRunMinutes?.let { "; inclui ainda $it min de corrida contínua" } ?: ""}. Distâncias são estimativas para contabilização; o alvo principal desta sessão é o tempo dos blocos."
        return workout(
            date, title, if (isLongRun) "Longo" else if (recovery) "Recuperação" else "Aeróbio",
            "Desenvolver tolerância gradual à corrida e reduzir pausas conforme a capacidade demonstrada",
            if (isLongRun) "BEGINNER_RUN_WALK_LONG" else "BEGINNER_RUN_WALK",
            totalKm, if (recovery) "2-3" else "3-4", week, phase, segments, rationale, "LOW"
        ).copy(durationMin = duration)
    }

    /**
     * Com pace calibrado, aquecimento, recuperação e desaquecimento são mais naturais por tempo.
     * Sem referência recente, mantém esses blocos por distância e não presume uma velocidade.
     * distanceKm em um bloco TIME é somente a contribuição estimada para o volume semanal.
     */
    private fun asTimeTarget(segment: WorkoutSegment, zones: TrainingPaceZones?): WorkoutSegment {
        if (zones == null) return segment
        val estimatedDistance = segment.distanceKm ?: return segment
        val fullFast = segment.zoneBasePaceFastValue ?: segment.targetPaceMinValue ?: return segment
        val fullSlow = segment.zoneBasePaceSlowValue ?: segment.targetPaceMaxValue ?: return segment
        if (fullFast <= 0 || fullSlow < fullFast) return segment
        val activeRange = if (segment.zoneIntensityMinPercent != null && segment.zoneIntensityMaxPercent != null) {
            ZoneIntensityBandEngine.activeRange(
                PaceRange(fullFast, fullSlow),
                ActiveZoneBand(segment.zoneIntensityMinPercent, segment.zoneIntensityMaxPercent)
            )
        } else PaceRange(fullFast, fullSlow)
        val midpointPace = (activeRange.fastestPaceValue + activeRange.slowestPaceValue) / 2.0
        val minutes = kotlin.math.round(estimatedDistance * midpointPace / 60.0).toInt().coerceAtLeast(1)
        return segment.copy(durationMin = minutes, durationSeconds = null, targetMode = "TIME")
    }

    private fun workout(date: LocalDate, title: String, type: String, objective: String, stimulus: String, distanceKm: Double, rpe: String,
        week: Int, phase: String, segments: List<WorkoutSegment>, rationale: String, intensity: String): PrescribedWorkout {
        // The exact workout total and the visible segment total share one source of truth.
        val reconciledSegments = TrainingPrescriptionAudit.reconcileSegments(segments, distanceKm)
        val reconciledDistance = if (reconciledSegments.any { it.distanceKm != null }) {
            TrainingPrescriptionAudit.estimatedSegmentDistanceKm(reconciledSegments)
        } else distanceKm
        val duration = WorkoutDurationEstimator.estimateMinutes(reconciledSegments, reconciledDistance)
        val dayName = date.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, Locale.forLanguageTag("pt-BR"))
        val dateLabel = "${dayName.replaceFirstChar { it.uppercase(Locale.forLanguageTag("pt-BR")) }}, ${date.format(DateTimeFormatter.ofPattern("dd/MM"))}"
        val detail = formatSegments(reconciledSegments)
        val id = SessionIdentityEngine.create(date, week, type)
        return PrescribedWorkout(dayName.replaceFirstChar { it.uppercase(Locale.forLanguageTag("pt-BR")) }, dateLabel, date.toString(), title, type, objective, stimulus,
            id, round1(reconciledDistance), duration, intensity,
            if (reconciledSegments.any { it.targetPaceMinValue != null && it.targetPaceMaxValue != null }) "PACE_RANGE" else "PACE_NOT_CALIBRATED",
            rpe, detail, rationale, week, phase, reconciledSegments)
    }

    private fun applyGoalPaceReference(workout: PrescribedWorkout, input: RunnerInput): PrescribedWorkout {
        val targetSeconds = when (input.goalIntent) {
            TrainingGoalIntent.TARGET_TIME -> input.targetTimeSeconds
            TrainingGoalIntent.PERSONAL_BEST -> input.personalBestTimeSeconds
            else -> null
        } ?: return workout
        if (input.goalIntent !in setOf(TrainingGoalIntent.TARGET_TIME, TrainingGoalIntent.PERSONAL_BEST) || input.goalKm !in 1.0..42.2 ||
            input.terrainPreference == RunningTerrain.TRAIL || workout.type !in setOf("Qualidade", "Longo", "Aeróbio")
        ) return workout
        val targetPace = (targetSeconds / input.goalKm).roundToInt().takeIf { it in 120..1800 } ?: return workout
        val specificSession = workout.phase == TrainingPeriodizationEngine.SPECIFIC ||
            workout.stimulus.contains("SPECIFIC", ignoreCase = true) ||
            workout.title.contains("ritmo", ignoreCase = true) || workout.title.contains("maratona", ignoreCase = true) ||
            workout.title.contains("tempo", ignoreCase = true)
        if (!specificSession) return workout
        val isRacePaceProtocol = workout.stimulus.startsWith("RACE_PACE_")
        val updated = workout.segments.map { segment ->
            val zoneFast = segment.zoneBasePaceFastValue ?: segment.targetPaceMinValue
            val zoneSlow = segment.zoneBasePaceSlowValue ?: segment.targetPaceMaxValue
            val targetFitsZone = zoneFast != null && zoneSlow != null && targetPace in zoneFast..zoneSlow
            val namedSpecificBlock = segment.name.contains("espec", true) || segment.name.contains("ritmo", true) ||
                segment.name.contains("principal", true) || segment.name.contains("tempo", true)
            val explicitRacePaceInterval = isRacePaceProtocol && segment.name.equals("Intervalo", ignoreCase = true)
            if (segment.paceZone in setOf("Z2", "Z3", "Z4") && targetFitsZone && (namedSpecificBlock || explicitRacePaceInterval)) {
                segment.copy(goalPaceReferenceSecondsPerKm = targetPace)
            } else segment.copy(goalPaceReferenceSecondsPerKm = null)
        }
        return workout.copy(segments = updated)
    }

    private fun applyTerrainConstraints(workout: PrescribedWorkout, input: RunnerInput): PrescribedWorkout {
        if (RunningTerrain.normalize(input.terrainPreference) != RunningTerrain.TRAIL) return workout
        val adjusted = workout.segments.map { segment ->
            if (segment.paceZone == null) segment else {
                val distance = segment.distanceKm
                val estimatedMinutes = segment.durationMin ?: distance?.let { (it * 10.0).roundToInt() } ?: 1
                segment.copy(
                    instruction = segment.instruction + " Em trilha, controle por RPE, tempo e terreno; não persiga ritmo plano.",
                    durationMin = estimatedMinutes.coerceAtLeast(1),
                    targetMode = "TIME",
                    targetPaceMinValue = null,
                    targetPaceMaxValue = null,
                    zoneBasePaceFastValue = null,
                    zoneBasePaceSlowValue = null,
                    zoneIntensityMinPercent = null,
                    zoneIntensityMaxPercent = null
                )
            }
        }
        return workout.copy(
            segments = adjusted,
            paceMode = "EFFORT_TIME",
            rationale = workout.rationale + " Terreno de trilha selecionado: ritmo de rua foi removido; use esforço percebido, tempo, altimetria e condições do piso."
        )
    }

    private fun formatSegments(segments: List<WorkoutSegment>): String = segments.joinToString(" • ") { segment ->
        val estimatedKm = segment.distanceKm?.let { it * segment.repeatCount }
        val dose = when {
            segment.targetMode == "TIME" && segment.durationSeconds != null -> "${segment.durationSeconds}s${estimatedKm?.let { " • ~${formatKm(it)} km estimados" }.orEmpty()}"
            segment.targetMode == "TIME" && segment.repeatCount > 1 && segment.durationMin != null -> "${segment.repeatCount} × ${segment.durationMin} min${estimatedKm?.let { " • ~${formatKm(it)} km estimados no total" }.orEmpty()}"
            segment.targetMode == "TIME" && segment.durationMin != null -> "${segment.durationMin} min${estimatedKm?.let { " • ~${formatKm(it)} km estimados" }.orEmpty()}"
            segment.repeatCount > 1 && segment.distanceKm != null -> "${segment.repeatCount} × ${formatKm(segment.distanceKm)} km"
            segment.distanceKm != null -> "${formatKm(segment.distanceKm)} km"
            segment.durationMin != null -> "${segment.durationMin} min"
            else -> ""
        }
        val pace = when (segment.recoveryMode) {
            "PASSIVE" -> "pausa parada, sem corrida"
            "WALK" -> "caminhada, sem pace-alvo"
            "ACTIVE_Z1" -> "recuperação ativa Z1"
            "ACTIVE_Z2" -> "recuperação ativa Z2"
            else -> if (segment.targetPaceMinValue != null && segment.targetPaceMaxValue != null) {
                "ritmo ${PaceRange(segment.targetPaceMinValue, segment.targetPaceMaxValue).label()}"
            } else "ritmo não calibrado"
        }
        val zone = segment.paceZone?.let { "$it • " } ?: ""
        "${segment.name}: $dose ($zone$pace; RPE auxiliar ${segment.rpeRange})"
    }

    private fun trainingDays(input: RunnerInput): List<DayOfWeek> =
        TrainingScheduleEngine.prescribedRunningDays(
            input.availableDays, input.frequency, isNovicePlan(input), input.preferredLongRunDay
        )

    private fun isNovicePlan(input: RunnerInput): Boolean =
        input.runWalkEligible && input.goalKm <= 5.5 && input.longestRecentKm < 5.0


    private fun recoveryStatus(score: Double?): String = when {
        score == null -> "UNKNOWN"
        score >= 75.0 -> "GOOD"
        score >= 50.0 -> "MODERATE"
        else -> "POOR"
    }

    private fun safetyStatus(input: RunnerInput): String = when {
        input.painPresent -> "RED"
        input.fatigueScore != null && input.fatigueScore >= 75.0 -> "YELLOW"
        input.recoveryScore != null && input.recoveryScore < 50.0 -> "YELLOW"
        input.recoveryScore == null && input.fatigueScore == null -> "UNASSESSED"
        else -> "GREEN"
    }

    private fun buildFlags(
        input: RunnerInput,
        recovery: String,
        safety: String,
        zones: TrainingPaceZones?
    ): List<String> = buildList {
        if (input.frequency < 3) add("LOW_FREQUENCY")
        if (input.weeklyVolumeKm == 0.0) add("NO_RECENT_WEEKLY_VOLUME")
        if (input.longestRecentKm < 5.0) add("LIMITED_LONG_RUN_HISTORY")
        if (input.fatigueScore != null && input.fatigueScore >= 75.0) add("HIGH_FATIGUE")
        else if (input.fatigueScore != null && input.fatigueScore >= 65.0) add("RECOVERY_MONITORING")
        if (input.recentActivityHistoryReliable) add("RECENT_LOAD_FROM_LOGGED_ACTIVITIES")
        else if (input.recentActivityCount > 0) add("RECENT_ACTIVITY_HISTORY_PARTIAL")
        if (isNovicePlan(input)) add("BEGINNER_RUN_WALK_ADAPTED_DOSE")
        if (input.longestRecentKm > 0.0) add("SINGLE_SESSION_CAP_BASED_ON_RECENT_TOLERANCE")
        val days = trainingDays(input)
        val longDay = input.preferredLongRunDay?.takeIf { it in days } ?: days.last()
        val qualityPrerequisites = input.goalCategory != "HEALTH" && input.frequency >= 3 &&
            input.weeklyVolumeKm >= 8.0 && input.longestRecentKm >= 4.0
        if (qualityPrerequisites && !TrainingPeriodizationEngine.aerobicQualityEligible(input, zones)) {
            add("QUALITY_SUPPRESSED_BY_INSUFFICIENT_CONSISTENCY")
        } else if (qualityPrerequisites && TrainingScheduleEngine.qualityDayWithRecoveryGap(days, longDay) == null) {
            add("QUALITY_SUPPRESSED_BY_RECOVERY_SPACING")
        }
        if (recovery == "POOR") add("LOW_RECOVERY")
        if (safety == "UNASSESSED") add("READINESS_NOT_ASSESSED")
        if (safety == "RED") add("PAIN_REPORTED")
    }

    private fun formatGoalDistance(km: Double): String = when {
        kotlin.math.abs(km - 21.0975) < 0.15 -> "meia maratona"
        kotlin.math.abs(km - 10.0) < 0.15 -> "10 km"
        kotlin.math.abs(km - 5.0) < 0.15 -> "5 km"
        else -> "${formatKm(km)} km"
    }

    private fun floorHalf(value: Double): Double = kotlin.math.floor(value * 2.0) / 2.0
    private fun round1(value: Double): Double = kotlin.math.round(value * 10.0) / 10.0
    internal fun formatKm(value: Double): String = if (value % 1.0 == 0.0) value.toInt().toString() else String.format(Locale.US, "%.1f", value)
    internal fun currentWeekMonday(from: LocalDate): LocalDate = from.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
}
