package com.airunningcoach.app

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Motor de prescrição V61: periodização por objetivo, biblioteca mista de estímulos e carga individual. */
internal data class RunnerInput(
    val goalKm: Double,
    val level: String,
    val frequency: Int,
    /** Dias habituais escolhidos pelo atleta; lista vazia mantém compatibilidade com perfis antigos. */
    val availableDays: List<DayOfWeek> = emptyList(),
    /** Dia preferido para o longão, quando disponível. */
    val preferredLongRunDay: DayOfWeek? = null,
    /** Média semanal efetivamente corrida nas últimas quatro semanas. */
    val weeklyVolumeKm: Double,
    val longestRecentKm: Double,
    val painPresent: Boolean = false,
    val recoveryScore: Double? = null,
    val fatigueScore: Double? = null,
    val planWeeks: Int = 8,
    /** Distância percorrida no Teste de Cooper de 12 minutos; unidade única: km. */
    val cooperDistanceKm: Double? = null,
    val cooperAssessmentDateIso: String? = null,
    /** Último Cooper anterior, usado para limitar mudanças bruscas entre calibrações. */
    val previousCooperDistanceKm: Double? = null,
    /** Pace da etapa estável em que frases completas permaneceram confortáveis, observado em sessões aeróbias. */
    val talkTestComfortPaceValues: List<Int> = emptyList(),
    /** Fully individualized ranges from the app state; preferred over recalculation from Cooper only. */
    val calibratedPaceZones: TrainingPaceZones? = null,
    /** Count of real activities with distance/time recorded in the previous 28 days. */
    val recentActivityCount: Int = 0,
    /** True only after enough logged sessions span at least three distinct weeks. */
    val recentActivityHistoryReliable: Boolean = false,
    val startDate: LocalDate = LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)),
    /** HEALTH keeps the plan health-oriented and does not select quality/threshold stimuli. */
    val goalCategory: String = "PERFORMANCE"
)

internal data class MotorState(
    val fitnessConfidence: String,
    val paceConfidence: String,
    val recentVolumeKm: Double,
    val recentLongRunKm: Double,
    val recoveryStatus: String,
    val safetyStatus: String,
    val phase: String,
    val flags: List<String>
)

internal data class MotorDecision(
    val action: String,
    val necessity: String,
    val stimulus: String,
    val rationale: String,
    val confidence: Double,
    val safety: String
)

internal data class WorkoutSegment(
    val name: String,
    val instruction: String,
    val durationMin: Int? = null,
    val distanceKm: Double? = null,
    val intensity: String = "LOW",
    /** RPE é uma referência complementar, nunca o alvo primário de execução. */
    val rpeRange: String = "2-3",
    val repeatCount: Int = 1,
    /** TIME ou DISTANCE, conforme o campo de dose preenchido. */
    val targetMode: String = if (durationMin != null) "TIME" else "DISTANCE",
    /** Limites numéricos internos; UI e contrato sempre formatam como mm:ss min/km. */
    val targetPaceMinValue: Int? = null,
    val targetPaceMaxValue: Int? = null,
    /** Zona operacional Z1–Z5 associada ao bloco, quando aplicável. */
    val paceZone: String? = null,
    /** Limites completos da zona antes da seleção da faixa ativa por sessão. */
    val zoneBasePaceFastValue: Int? = null,
    val zoneBasePaceSlowValue: Int? = null,
    /** Percentual interno da zona usado no alvo desta sessão (0=lento, 100=rápido). */
    val zoneIntensityMinPercent: Int? = null,
    val zoneIntensityMaxPercent: Int? = null
) {
    init {
        require(targetMode == "TIME" || targetMode == "DISTANCE") { "O alvo deve ser TIME ou DISTANCE." }
        require(if (targetMode == "TIME") durationMin != null && durationMin > 0 else distanceKm != null && distanceKm >= 0.0) {
            "Cada etapa precisa ter uma dose compatível com o tipo de alvo."
        }
        require((targetPaceMinValue == null) == (targetPaceMaxValue == null)) { "A faixa de pace precisa ter os dois limites." }
        if (targetPaceMinValue != null && targetPaceMaxValue != null) {
            require(targetPaceMinValue > 0 && targetPaceMaxValue >= targetPaceMinValue) { "Faixa de pace inválida." }
        }
        require((zoneBasePaceFastValue == null) == (zoneBasePaceSlowValue == null)) { "A zona-base precisa ter os dois limites." }
        if (zoneBasePaceFastValue != null && zoneBasePaceSlowValue != null) {
            require(zoneBasePaceFastValue > 0 && zoneBasePaceSlowValue >= zoneBasePaceFastValue) { "Zona-base inválida." }
        }
        require((zoneIntensityMinPercent == null) == (zoneIntensityMaxPercent == null)) { "A faixa percentual precisa dos dois limites." }
        if (zoneIntensityMinPercent != null && zoneIntensityMaxPercent != null) {
            require(zoneIntensityMinPercent in 0..99 && zoneIntensityMaxPercent in 1..100 && zoneIntensityMinPercent < zoneIntensityMaxPercent) { "Percentual ativo inválido." }
        }
        require(repeatCount >= 1) { "A repetição deve ser pelo menos 1." }
    }
}

internal data class PrescribedWorkout(
    val day: String,
    val date: String,
    val scheduledDateIso: String,
    val title: String,
    val type: String,
    val objective: String,
    val stimulus: String,
    val sessionId: String,
    val distanceKm: Double,
    val durationMin: Int,
    val intensity: String,
    val paceMode: String,
    val rpeRange: String,
    val detail: String,
    val rationale: String,
    val week: Int = 1,
    val phase: String = "BASE",
    val segments: List<WorkoutSegment> = emptyList(),
    val paceCalibrationSnapshot: PaceCalibrationSnapshot? = null
)

internal data class WeeklyPlanSummary(
    val week: Int,
    val phase: String,
    val totalKm: Double,
    val workoutCount: Int,
    val isRecoveryWeek: Boolean
)

internal data class MotorPlan(
    val state: MotorState,
    val decision: MotorDecision,
    val workouts: List<PrescribedWorkout>,
    val weeklyKm: Double,
    val explanation: String,
    val weeklySummaries: List<WeeklyPlanSummary>
)

internal object RunningCoachEngine {
    fun generate(input: RunnerInput): MotorPlan {
        require(input.frequency in 2..6) { "A frequência deve estar entre 2 e 6 dias por semana." }
        if (input.availableDays.isNotEmpty()) {
            require(input.availableDays.distinct().size == input.frequency) { "A quantidade de dias selecionados precisa corresponder à frequência semanal." }
            require(input.preferredLongRunDay == null || input.preferredLongRunDay in input.availableDays) { "O dia preferido do longão precisa estar disponível." }
        }
        require(input.goalKm in 1.0..100.0) { "O objetivo precisa estar entre 1 e 100 km." }
        require(input.weeklyVolumeKm in 0.0..150.0) { "Informe um volume semanal entre 0 e 150 km." }
        require(input.longestRecentKm in 0.0..60.0) { "O maior treino recente precisa estar entre 0 e 60 km." }

        val novice = isNovicePlan(input)
        val paceZones = input.calibratedPaceZones ?: PaceCalculator.limitCalibrationChange(
            PaceCalculator.calculateCooper(input.cooperDistanceKm, input.talkTestComfortPaceValues),
            PaceCalculator.calculateCooper(input.previousCooperDistanceKm, input.talkTestComfortPaceValues),
            maxBoundaryShiftSeconds = 15
        )
        val recovery = recoveryStatus(input.recoveryScore)
        val safety = safetyStatus(input)
        val flags = buildFlags(input, recovery, safety)
        val state = MotorState(
            fitnessConfidence = when {
                input.weeklyVolumeKm < 8.0 || input.longestRecentKm < 5.0 -> "LOW"
                else -> "PARTIAL"
            },
            paceConfidence = if (paceZones != null) "ESTIMATED_FROM_COOPER" else "AWAITING_COOPER",
            recentVolumeKm = input.weeklyVolumeKm,
            recentLongRunKm = input.longestRecentKm,
            recoveryStatus = recovery,
            safetyStatus = safety,
            phase = if (recovery == "POOR" || safety == "YELLOW") "RECOVERY" else "BASE_AND_BUILD",
            flags = flags
        )

        if (safety == "RED") {
            val decision = MotorDecision(
                action = "BLOCK", necessity = "SAFETY_REVIEW", stimulus = "NONE",
                rationale = "Há relato de dor. O motor não gera sessões de corrida; procure orientação adequada antes de retomar a carga.",
                confidence = 0.99, safety = "RED"
            )
            return MotorPlan(state, decision, emptyList(), 0.0, decision.rationale, emptyList())
        }

        val weeks = input.planWeeks.coerceIn(4, 16)
        // Sem volume recente, o ciclo começa como reintrodução muito leve, não como intermediário/avançado.
        val baselineKm = if (input.weeklyVolumeKm == 0.0) 3.0 else input.weeklyVolumeKm
        val workouts = mutableListOf<PrescribedWorkout>()
        val calibrationDate = input.cooperAssessmentDateIso ?: input.startDate.toString()
        val calibrationSnapshot = PaceCalculator.createCalibrationSnapshot(input.cooperDistanceKm, calibrationDate, input.talkTestComfortPaceValues, paceZones)
        val summaries = mutableListOf<WeeklyPlanSummary>()
        val initialReadinessFactor = when {
            recovery == "POOR" -> 0.72
            safety == "YELLOW" -> 0.82
            else -> 1.0
        }

        for (week in 1..weeks) {
            val cycleWeek = (week - 1) % 4
            val isRecoveryWeek = cycleWeek == 3
            val blockIndex = (week - 1) / 4
            val blockFactor = (1.0 + blockIndex * 0.04).coerceAtMost(1.16)
            val progressionFactor = when (cycleWeek) {
                0 -> 1.00
                1 -> 1.04
                2 -> 1.08
                // Deload is a controlled reduction from the preceding build weeks,
                // not a drop to an arbitrary fraction of the original baseline.
                else -> 0.92
            }
            val readinessFactor = when {
                recovery == "POOR" -> 0.72
                safety == "YELLOW" -> 0.82
                else -> 1.0
            }
            val candidateWeekKm = max(1.5, baselineKm * blockFactor * progressionFactor * readinessFactor)
            val previousDeliveredKm = summaries.lastOrNull()?.totalKm
            val progressionCeiling = when {
                previousDeliveredKm == null -> candidateWeekKm
                isRecoveryWeek -> previousDeliveredKm * 0.88
                cycleWeek == 0 -> previousDeliveredKm * 1.08
                else -> previousDeliveredKm * 1.05
            }
            val targetWeekKm = min(candidateWeekKm, progressionCeiling).coerceAtLeast(1.5)
            val weekPhase = when {
                recovery == "POOR" || safety == "YELLOW" -> TrainingPeriodizationEngine.RECOVERY
                else -> TrainingPeriodizationEngine.phaseForWeek(week, weeks, isRecoveryWeek)
            }
            val weekSessions = buildWeek(
                input = input,
                targetWeekKm = targetWeekKm,
                week = week,
                phase = weekPhase,
                suppressQuality = isRecoveryWeek || recovery == "POOR" || safety == "YELLOW"
            ).map { session ->
                ZoneIntensityBandEngine.apply(session.copy(paceCalibrationSnapshot = calibrationSnapshot))
            }
            workouts += weekSessions
            summaries += WeeklyPlanSummary(
                week = week,
                phase = weekPhase,
                totalKm = round1(weekSessions.sumOf { it.distanceKm }),
                workoutCount = weekSessions.size,
                isRecoveryWeek = isRecoveryWeek || recovery == "POOR" || safety == "YELLOW"
            )
        }

        val firstWeekKm = summaries.firstOrNull()?.totalKm ?: 0.0
        val volumeWasCapped = firstWeekKm + 0.1 < baselineKm * initialReadinessFactor
        val finalState = if (volumeWasCapped) state.copy(flags = state.flags + "WEEKLY_VOLUME_CAPPED_BY_RECENT_TOLERANCE") else state
        val qualityCount = workouts.count { it.type == "Qualidade" }
        val necessity = when {
            recovery == "POOR" -> "RECOVERY_FIRST"
            input.goalKm <= 10.0 -> "AEROBIC_DEVELOPMENT"
            else -> "ENDURANCE_DEVELOPMENT"
        }
        val stimulus = when {
            recovery == "POOR" || safety == "YELLOW" -> "LOW_INTENSITY_AEROBIC"
            qualityCount > 0 -> "AEROBIC_BASE_AND_CONTROLLED_QUALITY"
            else -> "AEROBIC_BASE"
        }
        val rationale = when {
            recovery == "POOR" -> "A recuperação registrada está baixa. O volume foi reduzido e os estímulos de qualidade foram suspensos."
            safety == "YELLOW" -> "Os sinais recentes de fadiga pedem redução temporária da carga e suspensão de estímulos intensos."
            volumeWasCapped -> "A média semanal informada é maior do que a dose que o histórico do maior treino recente permite distribuir com segurança na frequência escolhida. O plano fica abaixo da média informada até haver tolerância documentada."
            input.weeklyVolumeKm == 0.0 -> "Como não há corrida registrada nas últimas quatro semanas, o plano começa com reintrodução leve, independentemente do nível de experiência declarado."
            input.goalCategory == "HEALTH" -> "O objetivo selecionado é saúde e qualidade de vida. O plano prioriza regularidade e intensidade aeróbia confortável, sem sessões automáticas de limiar, VO₂ ou Z3 de qualidade. "
            input.level == "Iniciante" -> "O plano prioriza consistência aeróbia e progressão gradual, sem estímulos intensos nesta etapa. A frequência de ${input.frequency} dias escolhida no perfil é mantida; a dose de cada sessão é adaptada ao condicionamento."
            novice -> "O plano mantém os ${input.frequency} dias selecionados, com sessões leves e corrida-caminhada quando necessário. O condicionamento limita a distância e a intensidade de cada treino, não a frequência solicitada."
            else -> "A primeira semana parte do volume semanal real informado. A progressão é gradual; a qualidade só aparece quando o volume, a recuperação e o espaçamento entre sessões permitem."
        }
        val decision = MotorDecision(
            action = if (recovery == "POOR" || safety == "YELLOW") "REDUCE_LOAD" else "PRESCRIBE",
            necessity = necessity,
            stimulus = stimulus,
            rationale = rationale,
            confidence = when {
                input.weeklyVolumeKm == 0.0 -> 0.25
                input.weeklyVolumeKm >= 8.0 && input.longestRecentKm >= 5.0 -> 0.68
                else -> 0.42
            },
            safety = safety
        )
        val explanation = buildString {
            append("A referência de volume do ciclo usa a média semanal efetivamente informada para as últimas quatro semanas, sem reduzir uma faixa inteira ao seu limite inferior. ")
            append("A experiência declarada define a elegibilidade dos estímulos, mas não substitui o histórico de carga. ")
            append("O longão é limitado pelo maior treino recente, pela parcela da semana e pela distância-alvo. ")
            append("O limite de sessão é baseado na maior corrida recente registrada; o motor não presume que sessões futuras do plano já foram concluídas. Recalcule o ciclo após registrar a carga real para liberar progressões posteriores. ")
            if (novice) append("Para iniciantes ou atletas em reintrodução, a frequência selecionada (${input.frequency} dias) é preservada; a adaptação ocorre na dose, no formato corrida-caminhada e na ausência de qualidade intensa até haver base suficiente. ")
            if (input.recentActivityHistoryReliable) {
                append("A carga de referência foi atualizada com ${input.recentActivityCount} atividades reais registradas nas últimas quatro semanas. ")
            } else if (input.recentActivityCount > 0) {
                append("O histórico registrado ainda é parcial (${input.recentActivityCount} atividades recentes); a média informada no perfil foi mantida como referência, e as sessões já registradas entram como limite adicional de tolerância. ")
            }
            if (paceZones != null) {
                if (input.cooperDistanceKm != null) {
                    append("As cinco zonas iniciais Z1–Z5 são faixas operacionais estimadas a partir do Cooper (${formatKm(input.cooperDistanceKm)} km em 12 min); não são medições laboratoriais nem percentuais de VO₂máx. Z4 e Z5 são referências de esforço estimadas, e o RPE permanece como controle complementar. Dois registros consistentes de fala confortável podem personalizar o limite da Z2.")
                } else {
                    append("O perfil anterior ainda não possui uma avaliação Cooper válida. Faça o teste de 12 minutos para calibrar as zonas Z1–Z5.")
                }
            } else {
                append("Sem Teste de Cooper ou referência anterior válida, o motor não inventa pace: as sessões usam alvos por distância/tempo e RPE apenas como orientação temporária. Registre a distância percorrida no Cooper de 12 minutos para calibrar Z1–Z5.")
            }
        }
        return MotorPlan(finalState, decision, workouts, firstWeekKm, explanation, summaries)
    }

    private fun buildWeek(
        input: RunnerInput,
        targetWeekKm: Double,
        week: Int,
        phase: String,
        suppressQuality: Boolean
    ): List<PrescribedWorkout> {
        val novice = isNovicePlan(input)
        val days = trainingDays(input)
        val dayCount = days.size
        val longDay = input.preferredLongRunDay?.takeIf { it in days } ?: days.last()
        val goalLongCap = TrainingPeriodizationEngine.longRunCapForGoal(input.goalKm)

        // Do not increase a single-session cap based on future planned sessions.
        // A new higher cap is released only after the athlete records a new tolerated run.
        val historyCap = if (input.longestRecentKm <= 0.0) 1.0
            else input.longestRecentKm * 1.10
        val sessionCap = min(historyCap, goalLongCap)

        val longIndex = days.indexOf(longDay)
        val qualityDay = TrainingScheduleEngine.qualityDayWithRecoveryGap(days, longDay)
        val allowQuality = !suppressQuality && !novice && input.goalCategory != "HEALTH" &&
            dayCount >= 3 && targetWeekKm >= 16.0 && input.longestRecentKm >= 8.0 && qualityDay != null

        // A distribuição muda com a frequência. Não existe uma fração universal do longão:
        // com poucas sessões ele ocupa uma parcela maior; com mais dias, uma parcela menor.
        // Em todas as frequências, o longão deve ser a maior sessão se o histórico permitir.
        val longShare = when (dayCount) {
            2 -> 0.53
            3 -> 0.40
            4 -> 0.32
            5 -> 0.28
            else -> 0.25
        }
        val qualityShare = when (dayCount) {
            3 -> 0.29
            4 -> 0.20
            5 -> 0.18
            else -> 0.15
        }

        var longKm = min(sessionCap, roundHalf(targetWeekKm * longShare))
            .coerceAtLeast(min(0.5, targetWeekKm))
        var nonLongCap = (longKm - 0.5).coerceAtLeast(0.5)

        var qualityKm = if (allowQuality) {
            min(min(sessionCap, nonLongCap), roundHalf(targetWeekKm * qualityShare))
                .coerceAtLeast(min(0.5, targetWeekKm - longKm))
        } else 0.0

        // A qualidade só entra quando há pelo menos um dia completo sem corrida
        // entre ela e o longão. Se a disponibilidade não permitir, ela é suprimida.
        val qualityIndex = if (allowQuality) days.indexOf(qualityDay) else -1
        val easyIndices = days.indices.filter { it != longIndex && (!allowQuality || it != qualityIndex) }
        // Com apenas duas corridas semanais não há sessão de qualidade: o longão precisa
        // superar a única rodagem fácil, inclusive após arredondamento em semanas leves.
        if (easyIndices.size == 1 && !allowQuality) {
            val minimumDominantLong = kotlin.math.ceil((targetWeekKm + 0.5) * 2.0) / 4.0
            longKm = min(sessionCap, max(longKm, minimumDominantLong))
            nonLongCap = (longKm - 0.5).coerceAtLeast(0.1)
        }
        var easyTotal = max(0.0, targetWeekKm - longKm - qualityKm)

        // Na frequência de 3 dias há apenas uma rodagem fácil além da qualidade e do longão.
        // Se a limitação histórica reduzir o longão, transferimos parte do volume para o bloco
        // de qualidade (que inclui aquecimento/recuperações/desaquecimento) antes de reduzir a semana.
        if (easyIndices.size == 1 && easyTotal > nonLongCap && allowQuality) {
            val extraNeeded = easyTotal - nonLongCap
            val qualityRoom = (nonLongCap - qualityKm).coerceAtLeast(0.0)
            val transfer = min(extraNeeded, qualityRoom)
            qualityKm = round1(qualityKm + transfer)
            easyTotal = max(0.0, targetWeekKm - longKm - qualityKm)
        }

        val easySessionCap = min(sessionCap, nonLongCap)
        val easyDistances = distributeDistance(easyTotal, easyIndices.size, easySessionCap)
        val strideDayIndex = if (!novice && !suppressQuality && !allowQuality && dayCount >= 5) {
            easyIndices.firstOrNull { idx -> easyDistances.getOrElse(easyIndices.indexOf(idx)) { 0.0 } >= 4.0 &&
                TrainingScheduleEngine.circularGapDays(days[idx], longDay) >= 2 }
        } else null
        var easyCursor = 0
        val startMonday = input.startDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))

        return days.mapIndexed { index, day ->
            val date = startMonday.plusWeeks((week - 1).toLong()).plusDays(day.value - 1L)
            when {
                day == longDay -> createLongRun(input, date, longKm, week, phase)
                allowQuality && index == qualityIndex -> createQuality(input, date, qualityKm, week, phase)
                else -> {
                    val km = easyDistances.getOrElse(easyCursor++) { 0.5 }
                    // Acelerações técnicas são ocasionais e só entram quando não há
                    // sessão de qualidade na semana; não são usadas em iniciantes,
                    // semanas regenerativas ou sessões próximas do longão.
                    val style = when {
                        index == strideDayIndex -> "STRIDES"
                        suppressQuality -> "EASY"
                        (week - 1) % 4 == 1 -> "PROGRESSION"
                        (week - 1) % 4 == 2 -> "REGRESSION"
                        else -> "EASY"
                    }
                    createEasy(input, date, km, week, phase, recovery = suppressQuality, style = style)
                }
            }
        }
    }

    private fun cycleWeekFor(week: Int): Int = (week - 1) % 4

    private fun distributeDistance(totalKm: Double, count: Int, sessionCapKm: Double): List<Double> {
        if (count <= 0) return emptyList()
        var remaining = round1(totalKm.coerceAtLeast(0.0))
        return (0 until count).map { index ->
            val slotsLeft = count - index
            if (slotsLeft == 1) {
                min(sessionCapKm, remaining).coerceAtLeast(0.1).also { remaining = 0.0 }
            } else {
                val minimumForEachRemaining = if (remaining >= slotsLeft * 0.5) 0.5 else max(0.1, remaining / slotsLeft)
                val maxForCurrent = min(sessionCapKm, remaining - minimumForEachRemaining * (slotsLeft - 1))
                    .coerceAtLeast(minimumForEachRemaining)
                val desired = round1(remaining / slotsLeft)
                val allocated = round1(desired.coerceIn(minimumForEachRemaining, maxForCurrent))
                remaining = round1((remaining - allocated).coerceAtLeast(0.0))
                allocated
            }
        }
    }

    private fun createEasy(input: RunnerInput, date: LocalDate, km: Double, week: Int, phase: String, recovery: Boolean, style: String = "EASY"): PrescribedWorkout {
        if (isNovicePlan(input)) return createRunWalk(date, km, week, phase, recovery, isLongRun = false)
        val rpe = if (recovery) "2-3" else "3-4"
        val warmupKm = round1(km * 0.2)
        val mainKm = round1(km * 0.6)
        val cooldownKm = round1((km - warmupKm - mainKm).coerceAtLeast(0.0))
        val zones = input.calibratedPaceZones ?: PaceCalculator.limitCalibrationChange(
            PaceCalculator.calculateCooper(input.cooperDistanceKm, input.talkTestComfortPaceValues),
            PaceCalculator.calculateCooper(input.previousCooperDistanceKm, input.talkTestComfortPaceValues),
            maxBoundaryShiftSeconds = 15
        )
        val effectiveStyle = if (style in setOf("PROGRESSION", "REGRESSION") && mainKm < 1.2) "EASY" else style
        val allowZ3 = effectiveStyle in setOf("PROGRESSION", "REGRESSION") &&
            isZ3EligibleForAerobicProgression(input, zones) && mainKm >= 2.4
        val title = when {
            recovery -> "Rodagem regenerativa"
            effectiveStyle == "PROGRESSION" && allowZ3 -> "Rodagem aeróbia progressiva Z2–Z3"
            effectiveStyle == "PROGRESSION" -> "Rodagem aeróbia progressiva Z2"
            effectiveStyle == "REGRESSION" && allowZ3 -> "Rodagem aeróbia regressiva Z3–Z2"
            effectiveStyle == "REGRESSION" -> "Rodagem aeróbia regressiva Z2"
            effectiveStyle == "STRIDES" -> "Rodagem aeróbia com acelerações"
            else -> "Rodagem aeróbia"
        }
        val warm = zoneSegment(
            "Aquecimento", "Comece confortável em Z1, na parte mais rápida da zona, sem acelerar além do esforço leve.",
            warmupKm, "Z1", zones, "1-2", ZoneIntensityBandEngine.z1WarmupCoolDownBand
        )
        val aerobicZoneId = if (recovery) "Z1" else "Z2"
        val mainSegments = when {
            recovery -> listOf(zoneSegment(
                "Bloco regenerativo Z1", "Mantenha esforço muito confortável em Z1; encerre mais leve se a respiração não estiver solta.",
                mainKm, "Z1", zones, "2-3"
            ))
            effectiveStyle == "PROGRESSION" || effectiveStyle == "REGRESSION" ->
                buildProgressionRegressionSegments(mainKm, effectiveStyle, zones, allowZ3, longRun = false)
            effectiveStyle == "STRIDES" -> listOf(zoneSegment(
                "Bloco aeróbio Z2", "Corrida confortável antes das acelerações; não transforme a sessão em sprint.", mainKm, "Z2", zones, "3-4"
            ))
            else -> listOf(zoneSegment(
                "Bloco aeróbio $aerobicZoneId", "Converse em frases completas; reduza o ritmo se a respiração ficar difícil.",
                mainKm, aerobicZoneId, zones, rpe
            ))
        }
        val segments = mutableListOf(warm)
        segments += mainSegments
        if (effectiveStyle == "STRIDES" && km >= 4.0) {
            val stridesKm = min(0.4, cooldownKm * 0.5)
            if (stridesKm >= 0.2) segments += WorkoutSegment("Acelerações técnicas (strides)", "Faça acelerações curtas, soltas e tecnicamente estáveis; recupere completamente. Não persiga um pace numérico.", distanceKm = stridesKm / 4.0, intensity = "HIGH", rpeRange = "6-7", repeatCount = 4)
        }
        val usedKm = segments.sumOf { (it.distanceKm ?: 0.0) * it.repeatCount }
        val remainder = round1((km - usedKm).coerceAtLeast(0.0))
        if (remainder > 0.0) segments += zoneSegment(
            "Desaquecimento", "Reduza gradualmente e termine em Z1 confortável, sem forçar o pace.", remainder, "Z1", zones, "1-2",
            ZoneIntensityBandEngine.z1WarmupCoolDownBand
        )
        val total = segments.sumOf { (it.distanceKm ?: 0.0) * it.repeatCount }
        val stimulus = when {
            recovery -> "RECOVERY_Z1"
            effectiveStyle == "PROGRESSION" && allowZ3 -> "EASY_AEROBIC_Z2_Z3_PROGRESSIVE"
            effectiveStyle == "PROGRESSION" -> "EASY_AEROBIC_Z2_PROGRESSIVE"
            effectiveStyle == "REGRESSION" && allowZ3 -> "EASY_AEROBIC_Z3_Z2_REGRESSIVE"
            effectiveStyle == "REGRESSION" -> "EASY_AEROBIC_Z2_REGRESSIVE"
            effectiveStyle == "STRIDES" -> "EASY_WITH_STRIDES_Z2_Z5"
            else -> "EASY_AEROBIC_Z2"
        }
        val rationale = when {
            recovery -> "Carga baixa em Z1 para facilitar a recuperação. Aquecimento e desaquecimento são etapas próprias; não há blocos Z1 duplicados na parte principal."
            effectiveStyle == "PROGRESSION" && allowZ3 -> "Progressão por etapas Z2→Z2 mais rápida→Z3 controlada. Z1 aparece somente no aquecimento e no desaquecimento; os blocos têm faixas ativas contíguas."
            effectiveStyle == "PROGRESSION" -> "Progressão dentro da Z2: começa na faixa confortável e avança gradualmente para a parte mais rápida da zona, sem introduzir Z3 antes dos requisitos."
            effectiveStyle == "REGRESSION" && allowZ3 -> "Regressão por etapas Z3 controlada→Z2→Z2 confortável. Z1 fica reservada ao aquecimento e ao desaquecimento."
            effectiveStyle == "REGRESSION" -> "Regressão dentro da Z2: começa na parte mais rápida permitida e reduz gradualmente para a faixa confortável."
            zones != null -> "Pace individual por zona, derivado do Cooper e das calibrações válidas. O esforço deve continuar compatível com a zona e com as condições do dia."
            else -> "Sem teste de referência: mantenha esforço confortável e use o alvo por distância/tempo até calibrar as zonas."
        }
        return workout(date, title, if (recovery) "Recuperação" else "Aeróbio", "Construir consistência aeróbia", stimulus,
            total, rpe, week, phase, segments, rationale, "LOW")
    }

    private data class ProgressionStageSpec(
        val zone: String,
        val band: ActiveZoneBand,
        val weight: Double,
        val name: String,
        val instruction: String,
        val rpe: String
    )

    /**
     * Z1 is intentionally excluded from the main progressive/regressive blocks.
     * When Z3 is not justified, the session changes pace only within Z2. When Z3 is
     * allowed, adjacent zone boundaries create a continuous Z2→Z3 or Z3→Z2 sequence.
     */
    private fun buildProgressionRegressionSegments(
        totalKm: Double,
        direction: String,
        zones: TrainingPaceZones?,
        allowZ3: Boolean,
        longRun: Boolean
    ): List<WorkoutSegment> {
        val progressive = direction == "PROGRESSION"
        if (totalKm < 0.3) return emptyList()
        if (totalKm < 1.2) return listOf(zoneSegment(
            "Bloco Z2 contínuo", "Mantenha Z2 confortável; a distância é curta demais para dividir em etapas progressivas/regressivas úteis.",
            round1(totalKm), "Z2", zones, "3-4", ActiveZoneBand(20, 65)
        ))
        val includeZ3 = allowZ3 && zones != null && totalKm >= (if (longRun) 3.0 else 2.4)
        val specs = if (includeZ3 && longRun) {
            if (progressive) listOf(
                ProgressionStageSpec("Z2", ZoneIntensityBandEngine.z2EasyTransitionBand, 0.44, "Bloco inicial Z2", "Comece na parte mais confortável da Z2 e estabilize a respiração.", "3-4"),
                ProgressionStageSpec("Z2", ActiveZoneBand(20, 100), 0.44, "Bloco intermediário Z2", "Aumente progressivamente dentro da Z2, aproximando-se da fronteira rápida sem salto brusco.", "3-4"),
                ProgressionStageSpec("Z3", ActiveZoneBand(0, 40), 0.12, "Final progressivo Z3", "Somente no trecho final, entre na parte inicial da Z3 de forma controlada; recue para Z2 se perder o conforto.", "5-6")
            ) else listOf(
                ProgressionStageSpec("Z3", ActiveZoneBand(0, 40), 0.12, "Início moderado Z3", "Comece com um trecho curto e controlado em Z3; não transforme o longão em prova.", "5-6"),
                ProgressionStageSpec("Z2", ActiveZoneBand(20, 100), 0.44, "Bloco intermediário Z2", "Reduza para Z2 e mantenha esforço conversável.", "3-4"),
                ProgressionStageSpec("Z2", ZoneIntensityBandEngine.z2EasyTransitionBand, 0.44, "Final confortável Z2", "Termine na extremidade mais leve da Z2, com respiração controlada.", "3-4")
            )
        } else if (includeZ3) {
            if (progressive) listOf(
                ProgressionStageSpec("Z2", ZoneIntensityBandEngine.z2EasyTransitionBand, 0.34, "Bloco inicial Z2", "Comece no lado confortável da Z2; não acelere antes de completar o bloco.", "3-4"),
                ProgressionStageSpec("Z2", ActiveZoneBand(20, 100), 0.33, "Bloco intermediário Z2", "Aumente gradualmente dentro da Z2, sem salto de ritmo.", "3-4"),
                ProgressionStageSpec("Z3", ActiveZoneBand(0, 40), 0.33, "Bloco final Z3", "Finalize na parte inicial da Z3, moderado e controlado; retorne à Z2 se perder o conforto.", "5-6")
            ) else listOf(
                ProgressionStageSpec("Z3", ActiveZoneBand(0, 40), 0.33, "Bloco inicial Z3", "Comece em Z3 controlada, sem ultrapassar a faixa prescrita.", "5-6"),
                ProgressionStageSpec("Z2", ActiveZoneBand(20, 100), 0.33, "Bloco intermediário Z2", "Reduza para Z2 e mantenha a respiração estável.", "3-4"),
                ProgressionStageSpec("Z2", ZoneIntensityBandEngine.z2EasyTransitionBand, 0.34, "Bloco final Z2", "Termine na faixa mais confortável da Z2.", "3-4")
            )
        } else {
            if (progressive) listOf(
                ProgressionStageSpec("Z2", ZoneIntensityBandEngine.z2EasyTransitionBand, 0.45, "Bloco inicial Z2 confortável", "Comece na extremidade mais confortável da Z2, usando a faixa ativa de 0–20%.", "3-4"),
                ProgressionStageSpec("Z2", ActiveZoneBand(20, 65), 0.55, "Bloco final Z2 mais rápido", "Aumente gradualmente dentro da faixa aeróbia Z2, sem avançar para Z3.", "3-4")
            ) else listOf(
                ProgressionStageSpec("Z2", ActiveZoneBand(20, 65), 0.45, "Bloco inicial Z2 mais rápido", "Comece na faixa mais rápida permitida da Z2, mantendo controle.", "3-4"),
                ProgressionStageSpec("Z2", ZoneIntensityBandEngine.z2EasyTransitionBand, 0.55, "Bloco final Z2 confortável", "Reduza gradualmente para a faixa confortável de 0–20% da Z2.", "3-4")
            )
        }
        val distances = allocateStageDistances(totalKm, specs.map { it.weight })
        return specs.mapIndexed { index, spec ->
            zoneSegment(spec.name, spec.instruction, distances[index], spec.zone, zones, spec.rpe, spec.band)
        }
    }

    private fun allocateStageDistances(totalKm: Double, weights: List<Double>): List<Double> {
        require(weights.isNotEmpty() && weights.all { it > 0.0 })
        val totalTenths = (round1(totalKm) * 10.0).roundToInt().coerceAtLeast(weights.size * 3)
        var remaining = totalTenths
        val weightTotal = weights.sum()
        return weights.mapIndexed { index, weight ->
            val slotsAfter = weights.size - index - 1
            val tenths = if (slotsAfter == 0) remaining else {
                (totalTenths * weight / weightTotal).roundToInt()
                    .coerceIn(3, (remaining - slotsAfter * 3).coerceAtLeast(3))
            }
            remaining -= tenths
            tenths / 10.0
        }
    }

    private fun isZ3EligibleForAerobicProgression(input: RunnerInput, zones: TrainingPaceZones?): Boolean =
        input.goalCategory != "HEALTH" && zones != null && input.level in setOf("Intermediário", "Avançado", "Elite") &&
            input.weeklyVolumeKm >= 16.0 && input.longestRecentKm >= 8.0 && !input.painPresent &&
            (input.recoveryScore == null || input.recoveryScore >= 75.0) &&
            (input.fatigueScore == null || input.fatigueScore < 65.0)

    private fun zoneSegment(
        name: String,
        instruction: String,
        distanceKm: Double,
        zoneId: String,
        zones: TrainingPaceZones?,
        rpeRange: String,
        activeBand: ActiveZoneBand? = null
    ): WorkoutSegment {
        val zone = when (zoneId.uppercase()) {
            "Z1" -> zones?.z1
            "Z2" -> zones?.z2
            "Z3" -> zones?.z3
            "Z4" -> zones?.z4
            "Z5" -> zones?.z5
            else -> null
        }
        return WorkoutSegment(
            name = name,
            instruction = instruction,
            distanceKm = distanceKm,
            intensity = when (zoneId.uppercase()) {
                "Z3", "Z4" -> "MODERATE"
                "Z5" -> "HIGH"
                else -> "LOW"
            },
            rpeRange = rpeRange,
            targetPaceMinValue = zone?.range?.fastestPaceValue,
            targetPaceMaxValue = zone?.range?.slowestPaceValue,
            paceZone = zoneId,
            zoneIntensityMinPercent = activeBand?.minPercent,
            zoneIntensityMaxPercent = activeBand?.maxPercent
        )
    }

    private fun createQuality(input: RunnerInput, date: LocalDate, km: Double, week: Int, phase: String): PrescribedWorkout {
        val zones = input.calibratedPaceZones ?: PaceCalculator.limitCalibrationChange(
            PaceCalculator.calculateCooper(input.cooperDistanceKm, input.talkTestComfortPaceValues),
            PaceCalculator.calculateCooper(input.previousCooperDistanceKm, input.talkTestComfortPaceValues),
            maxBoundaryShiftSeconds = 15
        )
        val thresholdEligible = TrainingPeriodizationEngine.thresholdEligible(input, zones)
        val vo2Eligible = TrainingPeriodizationEngine.vo2Eligible(input, zones)
        val z3Eligible = isZ3EligibleForAerobicProgression(input, zones)
        val requestedKind = when {
            // Every third quality opportunity can use a fartlek pattern for 5–10 km
            // plans when threshold work is justified; recovery weeks suppress quality upstream.
            thresholdEligible && input.goalKm in 3.0..10.0 && week % 3 == 0 -> "FARTLEK"
            else -> TrainingPeriodizationEngine.selectQualityKind(input, phase, zones)
        }
        val kind = when (requestedKind) {
            "MIXED_INTERVAL_Z3_Z4", "THRESHOLD_INTERVAL_Z3_Z4" -> if (thresholdEligible) requestedKind else "AEROBIC_INTERVAL_Z2"
            "MIXED_INTERVAL_Z4_Z5", "PYRAMID_INTERVAL_Z3_Z5" -> when {
                vo2Eligible -> requestedKind
                thresholdEligible -> "MIXED_INTERVAL_Z3_Z4"
                else -> "AEROBIC_INTERVAL_Z2"
            }
            else -> requestedKind
        }

        val warmKm = round1(km * 0.20)
        val coolKm = round1(km * 0.20)
        val mainBudget = round1((km - warmKm - coolKm).coerceAtLeast(0.5))
        val segments = mutableListOf<WorkoutSegment>()
        segments += asTimeTarget(zoneSegment(
            "Aquecimento", "Comece em Z1 na extremidade mais rápida da própria zona; aumente a atividade gradualmente, sem antecipar o bloco principal.",
            warmKm, "Z1", zones, "2-3", ZoneIntensityBandEngine.z1WarmupCoolDownBand
        ), zones)

        when (kind) {
            "PROGRESSIVE_RUN" -> {
                val useZ3 = z3Eligible && mainBudget >= 2.4
                segments += buildProgressionRegressionSegments(mainBudget, "PROGRESSION", zones, useZ3, longRun = false)
            }
            "STEADY_RUN" -> {
                val useZ3 = z3Eligible && mainBudget >= 2.0
                val zone = if (useZ3) "Z3" else "Z2"
                val band = if (useZ3) ActiveZoneBand(20, 60) else ActiveZoneBand(20, 65)
                segments += asTimeTarget(zoneSegment(
                    if (useZ3) "Corrida moderada sustentada Z3" else "Corrida aeróbia sustentada Z2",
                    if (useZ3) "Mantenha Z3 estável e controlada; reduza para Z2 se perder a técnica ou o controle respiratório."
                    else "Mantenha Z2 contínua e conversável. O objetivo é resistência, não correr no limite.",
                    mainBudget, zone, zones, if (useZ3) "5-6" else "3-4", band
                ), zones)
            }
            "TEMPO_RUN" -> {
                val zone = if (thresholdEligible) "Z4" else if (z3Eligible) "Z3" else "Z2"
                val band = when (zone) {
                    "Z4" -> ActiveZoneBand(25, 65)
                    "Z3" -> ActiveZoneBand(20, 60)
                    else -> ActiveZoneBand(20, 65)
                }
                segments += asTimeTarget(zoneSegment(
                    if (zone == "Z4") "Tempo controlado Z4 estimada" else if (zone == "Z3") "Ritmo sustentado Z3" else "Ritmo aeróbio sustentado Z2",
                    when (zone) {
                        "Z4" -> "Sustente esforço próximo ao limiar estimado, sem transformar o bloco em prova. Z4 não representa LT2 medido; use RPE e controle respiratório."
                        "Z3" -> "Mantenha esforço moderado estável e controlado; recue para Z2 se a respiração deixar de estar sob controle."
                        else -> "Mantenha esforço aeróbio confortável em Z2; como faltam evidências para intensidade superior, não force o ritmo."
                    },
                    mainBudget, zone, zones, if (zone == "Z4") "6-7" else if (zone == "Z3") "5-6" else "3-4", band
                ), zones)
            }
            "AEROBIC_INTERVAL_Z2", "AEROBIC_INTERVAL_Z2_Z3" -> {
                val aerobicPattern = if (kind.endsWith("Z2_Z3") && z3Eligible) listOf(
                    IntervalWorkStage("Z2", ActiveZoneBand(20, 65), "Bloco aeróbio Z2", "Acumule trabalho aeróbio em Z2, com conversa confortável.", "3-4", 1.0),
                    IntervalWorkStage("Z3", ActiveZoneBand(0, 20), "Bloco moderado Z3", "Suba apenas até a entrada da Z3, mantendo controle e sem acelerar abruptamente.", "5", 0.8),
                    IntervalWorkStage("Z2", ActiveZoneBand(65, 100), "Retorno à Z2 rápida", "Retorne à Z2 e estabilize a respiração antes do próximo ciclo.", "3-4", 1.0)
                ) else listOf(
                    IntervalWorkStage("Z2", ActiveZoneBand(20, 65), "Bloco aeróbio Z2", "Acumule trabalho aeróbio em Z2, mantendo a conversa confortável.", "3-4", 1.0),
                    IntervalWorkStage("Z2", ActiveZoneBand(65, 100), "Bloco Z2 mais rápido", "Aumente somente dentro da Z2; não ultrapasse a fronteira da zona.", "4", 0.8),
                    IntervalWorkStage("Z2", ActiveZoneBand(20, 65), "Bloco aeróbio Z2", "Retorne à faixa aeróbia controlada.", "3-4", 1.0)
                )
                segments += buildIntervalSequence(mainBudget, zones, aerobicPattern, recoveryFraction = 0.22, recoveryRpe = "2-3")
            }
            "MIXED_INTERVAL_Z3_Z4", "THRESHOLD_INTERVAL_Z3_Z4" -> {
                val pattern = listOf(
                    IntervalWorkStage("Z3", ActiveZoneBand(80, 100), "Trecho moderado Z3", "Entre na parte rápida da Z3 com controle, sem transformar o início em esforço máximo.", "5-6", 1.0),
                    IntervalWorkStage("Z4", ActiveZoneBand(0, 20), "Trecho de limiar Z4 estimada", "Aproxime-se da Z4 estimada sem ultrapassar a faixa prescrita; o limiar não foi medido em laboratório.", "6-7", 0.8),
                    IntervalWorkStage("Z3", ActiveZoneBand(80, 100), "Retorno controlado Z3", "Retorne à Z3 alta e mantenha a técnica estável.", "5-6", 1.0)
                )
                segments += buildIntervalSequence(mainBudget, zones, pattern, recoveryFraction = 0.30, recoveryRpe = "2-3")
            }
            "MIXED_INTERVAL_Z4_Z5" -> {
                val pattern = listOf(
                    IntervalWorkStage("Z4", ActiveZoneBand(80, 100), "Intervalo forte controlado Z4", "Comece no lado rápido da Z4 estimada, mantendo técnica e margem de controle.", "6-7", 1.0),
                    IntervalWorkStage("Z5", ActiveZoneBand(0, 20), "Aceleração curta Z5 estimada", "Use apenas o trecho curto de Z5, sem sprint máximo; interrompa a aceleração se a técnica se deteriorar.", "7-8", 0.55),
                    IntervalWorkStage("Z4", ActiveZoneBand(80, 100), "Retorno Z4", "Volte à Z4 controlada antes da próxima recuperação.", "6-7", 1.0)
                )
                segments += buildIntervalSequence(mainBudget, zones, pattern, recoveryFraction = 0.36, recoveryRpe = "2-3")
            }
            "PYRAMID_INTERVAL_Z3_Z5" -> {
                val pattern = listOf(
                    IntervalWorkStage("Z3", ActiveZoneBand(80, 100), "Pirâmide — Z3", "Inicie com intensidade moderada, sem antecipar o pico.", "5-6", 0.8),
                    IntervalWorkStage("Z4", ActiveZoneBand(0, 20), "Pirâmide — Z4", "Aumente para a entrada da Z4 estimada, mantendo controle.", "6-7", 1.0),
                    IntervalWorkStage("Z5", ActiveZoneBand(0, 20), "Pirâmide — Z5 curta", "Pico curto e controlado; não transforme a repetição em sprint máximo.", "7-8", 0.65),
                    IntervalWorkStage("Z4", ActiveZoneBand(80, 100), "Pirâmide — retorno Z4", "Reduza para Z4 e preserve a mecânica.", "6-7", 1.0),
                    IntervalWorkStage("Z3", ActiveZoneBand(80, 100), "Pirâmide — final Z3", "Finalize em Z3 controlada e prepare-se para o desaquecimento.", "5-6", 0.8)
                )
                segments += buildIntervalSequence(mainBudget, zones, pattern, recoveryFraction = 0.38, recoveryRpe = "2-3")
            }
            "MARATHON_SPECIFIC" -> {
                val z3Km = if (z3Eligible && mainBudget >= 3.0) round1(mainBudget * 0.10) else 0.0
                val easyKm = round1((mainBudget - z3Km).coerceAtLeast(0.0))
                segments += asTimeTarget(zoneSegment(
                    "Resistência específica de maratona Z2",
                    "Mantenha Z2 confortável e estável; o objetivo é acumular resistência específica, não transformar o bloco em limiar.",
                    easyKm, "Z2", zones, "3-4", ActiveZoneBand(20, 65)
                ), zones)
                if (z3Km > 0.0) segments += asTimeTarget(zoneSegment(
                    "Final moderado controlado Z3",
                    "Trecho final curto e opcional em Z3. Se houver fadiga, mantenha Z2 em todo o bloco.",
                    z3Km, "Z3", zones, "5-6", ActiveZoneBand(0, 20)
                ), zones)
            }
            "ULTRA_SPECIFIC" -> {
                // Ultra preparation emphasizes time-on-feet and sustainable Z2, not repeated hard efforts.
                val ultraPattern = listOf(
                    IntervalWorkStage("Z2", ActiveZoneBand(0, 20), "Bloco confortável Z2", "Acumule tempo em Z2 confortável; use corrida/caminhada se necessário.", "3-4", 1.0),
                    IntervalWorkStage("Z2", ActiveZoneBand(20, 55), "Bloco sustentado Z2", "Mantenha resistência aeróbia em Z2, sem procurar limiar.", "3-4", 1.0),
                    IntervalWorkStage("Z2", ActiveZoneBand(0, 20), "Bloco final confortável Z2", "Reduza o esforço e termine com reserva.", "2-3", 1.0)
                )
                segments += buildIntervalSequence(mainBudget, zones, ultraPattern, recoveryFraction = 0.15, recoveryRpe = "2-3")
            }
            else -> {
                val safePattern = listOf(
                    IntervalWorkStage("Z3", ActiveZoneBand(80, 100), "Fartlek moderado Z3", "Acelere de forma controlada em Z3, sem sprint.", "5-6", 1.0),
                    IntervalWorkStage("Z4", ActiveZoneBand(0, 20), "Fartlek forte Z4 estimada", "Aumente por um trecho curto na entrada da Z4 estimada, sem perder a técnica.", "6-7", 0.65),
                    IntervalWorkStage("Z3", ActiveZoneBand(80, 100), "Fartlek moderado Z3", "Retorne a Z3 antes da recuperação aeróbia.", "5-6", 1.0)
                )
                val effectivePattern = if (thresholdEligible) safePattern else listOf(
                    IntervalWorkStage("Z2", ActiveZoneBand(20, 65), "Fartlek aeróbio Z2", "Varie dentro da Z2, sem ultrapassar o esforço conversável.", "3-4", 1.0),
                    IntervalWorkStage("Z2", ActiveZoneBand(65, 100), "Fartlek Z2 mais rápido", "Acelere apenas dentro da Z2.", "4", 0.8),
                    IntervalWorkStage("Z2", ActiveZoneBand(20, 65), "Fartlek aeróbio Z2", "Retorne ao lado confortável da Z2.", "3-4", 1.0)
                )
                segments += buildIntervalSequence(mainBudget, zones, effectivePattern, recoveryFraction = 0.36, recoveryRpe = "2-3")
            }
        }

        segments += asTimeTarget(zoneSegment(
            "Desaquecimento", "Reduza gradualmente e termine em Z1 confortável, na extremidade mais rápida da própria zona.",
            coolKm, "Z1", zones, "1-2", ZoneIntensityBandEngine.z1WarmupCoolDownBand
        ), zones)

        val title = when (kind) {
            "PROGRESSIVE_RUN" -> if (z3Eligible) "Corrida progressiva Z2–Z3" else "Corrida progressiva Z2"
            "STEADY_RUN" -> if (z3Eligible) "Corrida moderada sustentada Z3" else "Corrida aeróbia sustentada Z2"
            "TEMPO_RUN" -> when (segments.firstOrNull { it.name.contains("controlado") || it.name.contains("sustentado") }?.paceZone) {
                "Z4" -> "Tempo run Z4 estimada"
                "Z3" -> "Tempo run moderado Z3"
                else -> "Rodagem sustentada Z2"
            }
            "AEROBIC_INTERVAL_Z2", "AEROBIC_INTERVAL_Z2_Z3" -> if (segments.any { it.paceZone == "Z3" }) "Intervalado aeróbio Z2–Z3" else "Intervalado aeróbio Z2"
            "MIXED_INTERVAL_Z3_Z4", "THRESHOLD_INTERVAL_Z3_Z4" -> "Intervalado misto Z3–Z4"
            "MIXED_INTERVAL_Z4_Z5" -> "Intervalado misto Z4–Z5"
            "PYRAMID_INTERVAL_Z3_Z5" -> "Intervalado piramidal Z3–Z5"
            "MARATHON_SPECIFIC" -> "Resistência específica de maratona"
            "ULTRA_SPECIFIC" -> "Resistência específica de ultradistância"
            else -> if (thresholdEligible) "Fartlek misto Z3–Z4" else "Fartlek aeróbio Z2"
        }
        val objective = when (kind) {
            "PROGRESSIVE_RUN" -> "Praticar progressão de ritmo sem sair do controle aeróbio"
            "STEADY_RUN" -> "Desenvolver resistência em ritmo sustentável"
            "TEMPO_RUN", "MIXED_INTERVAL_Z3_Z4", "THRESHOLD_INTERVAL_Z3_Z4" -> "Desenvolver tolerância ao esforço sustentado e controle de limiar estimado"
            "AEROBIC_INTERVAL_Z2", "AEROBIC_INTERVAL_Z2_Z3" -> "Acumular trabalho aeróbio em blocos, com recuperação controlada"
            "MIXED_INTERVAL_Z4_Z5", "PYRAMID_INTERVAL_Z3_Z5" -> "Desenvolver potência aeróbia com estímulos curtos e recuperação suficiente"
            "MARATHON_SPECIFIC" -> "Desenvolver resistência específica para a maratona"
            "ULTRA_SPECIFIC" -> "Desenvolver tempo em movimento e resistência aeróbia prolongada, com intensidade sustentável"
            else -> "Desenvolver capacidade de variar intensidade e recuperar em movimento"
        }
        val stimulus = when (kind) {
            "PROGRESSIVE_RUN" -> if (segments.any { it.paceZone == "Z3" }) "PROGRESSION_RUN_Z2_Z3" else "PROGRESSION_RUN_Z2_ONLY"
            "STEADY_RUN" -> if (segments.any { it.paceZone == "Z3" }) "STEADY_RUN_Z3" else "STEADY_RUN_Z2"
            "TEMPO_RUN" -> "TEMPO_RUN_ESTIMATED"
            "AEROBIC_INTERVAL_Z2", "AEROBIC_INTERVAL_Z2_Z3" -> if (segments.any { it.paceZone == "Z3" }) "AEROBIC_INTERVAL_Z2_Z3" else "AEROBIC_INTERVAL_Z2"
            "MIXED_INTERVAL_Z3_Z4", "THRESHOLD_INTERVAL_Z3_Z4" -> "MIXED_INTERVAL_Z3_Z4"
            "MIXED_INTERVAL_Z4_Z5" -> "MIXED_INTERVAL_Z4_Z5_ESTIMATED"
            "PYRAMID_INTERVAL_Z3_Z5" -> "PYRAMID_INTERVAL_Z3_Z5_ESTIMATED"
            "MARATHON_SPECIFIC" -> if (segments.any { it.paceZone == "Z3" }) "MARATHON_ENDURANCE_Z2_Z3" else "MARATHON_ENDURANCE_Z2"
            "ULTRA_SPECIFIC" -> "ULTRA_ENDURANCE_Z2"
            else -> if (thresholdEligible) "FARTLEK_Z3_Z4" else "FARTLEK_Z2_ONLY"
        }
        val totalKm = segments.sumOf { (it.distanceKm ?: 0.0) * it.repeatCount }
        val rationale = when {
            kind == "PROGRESSIVE_RUN" && segments.any { it.paceZone == "Z3" } -> "Progressão Z2→Z2 mais rápida→Z3 controlada. Z1 aparece somente no aquecimento e no desaquecimento."
            kind == "PROGRESSIVE_RUN" -> "Progressão dentro da Z2, sem introduzir Z3 antes dos requisitos individuais."
            kind == "MIXED_INTERVAL_Z4_Z5" || kind == "PYRAMID_INTERVAL_Z3_Z5" -> "Sessão de intensidade mista liberada somente para perfil avançado/elite, volume e maior corrida recentes compatíveis e prontidão favorável. Z5 é estimada, não VO₂máx medido."
            kind == "MIXED_INTERVAL_Z3_Z4" || kind == "THRESHOLD_INTERVAL_Z3_Z4" || kind == "TEMPO_RUN" -> "Blocos de Z3/Z4 estimada, com recuperação aeróbia em Z2. Z4 não equivale a LT2 medido; RPE e controle respiratório complementam o pace."
            kind == "MARATHON_SPECIFIC" -> "Z2 predomina; eventual trecho Z3 é curto e condicionado à experiência e à carga tolerada."
            kind == "ULTRA_SPECIFIC" -> "A preparação de ultradistância prioriza tempo em movimento, Z2 sustentável, estratégia corrida/caminhada e recuperação; não adiciona intensidade alta automaticamente."
            else -> "Sessão selecionada conforme objetivo, fase do ciclo, experiência, carga recente e recuperação. Cada bloco tem zona, faixa ativa, dose e RPE coerentes."
        }
        return workout(date, title, "Qualidade", objective, stimulus, totalKm, if (kind.contains("Z4") || kind.contains("Z5") || kind == "TEMPO_RUN") "6-7" else "3-5", week, phase, segments, rationale, "MODERATE")
    }

    private data class IntervalWorkStage(
        val zone: String,
        val band: ActiveZoneBand,
        val name: String,
        val instruction: String,
        val rpe: String,
        val weight: Double
    )

    /** Builds ordered On/Off intervals; work and recoveries are allocated from the exact main distance budget. */
    private fun buildIntervalSequence(
        totalKm: Double,
        zones: TrainingPaceZones?,
        workStages: List<IntervalWorkStage>,
        recoveryFraction: Double,
        recoveryRpe: String
    ): List<WorkoutSegment> {
        if (workStages.isEmpty() || totalKm < 1.2) {
            return listOf(asTimeTarget(zoneSegment(
                "Bloco aeróbio contínuo Z2", "Mantenha Z2 confortável; o volume disponível é curto demais para intervalos úteis.",
                round1(totalKm), "Z2", zones, "3-4", ZoneIntensityBandEngine.z2EasyTransitionBand
            ), zones))
        }
        val workBlocks = workStages.size
        val recoveryBlocks = workBlocks - 1
        val workKm = round1(totalKm * (1.0 - recoveryFraction.coerceIn(0.20, 0.50)))
        val recoveryKm = round1((totalKm - workKm).coerceAtLeast(0.0))
        if (workKm * 10.0 < workBlocks || recoveryBlocks > 0 && recoveryKm * 10.0 < recoveryBlocks) {
            return listOf(asTimeTarget(zoneSegment(
                "Bloco aeróbio contínuo Z2", "Mantenha Z2 confortável; não comprima intervalos em blocos pequenos demais.",
                round1(totalKm), "Z2", zones, "3-4", ActiveZoneBand(20, 65)
            ), zones))
        }
        val workDistances = allocateTenths(workKm, workStages.map { it.weight })
        val recoveryDistances = if (recoveryBlocks > 0) allocateTenths(recoveryKm, List(recoveryBlocks) { 1.0 }) else emptyList()
        val result = mutableListOf<WorkoutSegment>()
        var recoveryIndex = 0
        workStages.forEachIndexed { index, stage ->
            result += asTimeTarget(zoneSegment(
                "${stage.name} ${index + 1}", stage.instruction, workDistances[index], stage.zone, zones, stage.rpe, stage.band
            ), zones)
            if (index < workStages.lastIndex) {
                result += asTimeTarget(zoneSegment(
                    "Recuperação entre blocos Z2", "Recupere em Z2 muito confortável (0–20% da zona). Só inicie o próximo bloco quando a respiração estiver controlada.",
                    recoveryDistances[recoveryIndex++], "Z2", zones, recoveryRpe, ZoneIntensityBandEngine.z2EasyTransitionBand
                ), zones)
            }
        }
        return result
    }

    private fun allocateTenths(totalKm: Double, weights: List<Double>): List<Double> {
        require(weights.isNotEmpty() && weights.all { it > 0.0 })
        val totalTenths = (round1(totalKm) * 10.0).roundToInt().coerceAtLeast(weights.size)
        val weightSum = weights.sum()
        var remaining = totalTenths
        return weights.mapIndexed { index, weight ->
            val slotsAfter = weights.size - index - 1
            val amount = if (slotsAfter == 0) remaining else {
                (totalTenths * weight / weightSum).roundToInt().coerceIn(1, (remaining - slotsAfter).coerceAtLeast(1))
            }
            remaining -= amount
            amount / 10.0
        }
    }

    private fun createLongRun(input: RunnerInput, date: LocalDate, km: Double, week: Int, phase: String): PrescribedWorkout {
        if (isNovicePlan(input)) return createRunWalk(date, km, week, phase, recovery = phase == "RECOVERY", isLongRun = true)
        val recoveryWeek = phase == "RECOVERY"
        val rpe = if (recoveryWeek) "2-3" else "3-4"
        val warmupKm = round1(km * 0.10)
        val mainKm = round1(km * 0.80)
        val cooldownKm = round1((km - warmupKm - mainKm).coerceAtLeast(0.0))
        val zones = input.calibratedPaceZones ?: PaceCalculator.limitCalibrationChange(
            PaceCalculator.calculateCooper(input.cooperDistanceKm, input.talkTestComfortPaceValues),
            PaceCalculator.calculateCooper(input.previousCooperDistanceKm, input.talkTestComfortPaceValues),
            maxBoundaryShiftSeconds = 15
        )
        val z3Eligible = input.goalCategory != "HEALTH" && zones != null && (input.level == "Avançado" || input.level == "Elite") &&
            input.weeklyVolumeKm >= 25.0 && input.longestRecentKm >= 12.0 && km >= 8.0 &&
            !input.painPresent && (input.recoveryScore == null || input.recoveryScore >= 75.0) &&
            (input.fatigueScore == null || input.fatigueScore < 65.0)
        val cycleWeek = (week - 1) % 4
        val style = when {
            recoveryWeek -> "STEADY_Z2"
            cycleWeek == 1 -> if (z3Eligible) "PROGRESSIVE_Z2_Z3" else "PROGRESSIVE_Z2_ONLY"
            cycleWeek == 2 -> if (z3Eligible) "REGRESSIVE_Z3_Z2" else "REGRESSIVE_Z2_ONLY"
            else -> "STEADY_Z2"
        }
        val mainSegments = when (style) {
            "PROGRESSIVE_Z2_Z3", "PROGRESSIVE_Z2_ONLY" -> buildProgressionRegressionSegments(
                mainKm, "PROGRESSION", zones, allowZ3 = z3Eligible, longRun = true
            )
            "REGRESSIVE_Z3_Z2", "REGRESSIVE_Z2_ONLY" -> buildProgressionRegressionSegments(
                mainKm, "REGRESSION", zones, allowZ3 = z3Eligible, longRun = true
            )
            else -> listOf(zoneSegment(
                "Longão aeróbio Z2", "Mantenha esforço conversável e constante em Z2. Não transforme o longão em prova.", mainKm, "Z2", zones, rpe
            ))
        }
        val segments = listOf(
            asTimeTarget(zoneSegment(
                "Aquecimento", "Comece confortável em Z1, na parte mais rápida da zona, sem forçar o pace.",
                warmupKm, "Z1", zones, "2-3", ZoneIntensityBandEngine.z1WarmupCoolDownBand
            ), zones)
        ) + mainSegments + listOf(
            asTimeTarget(zoneSegment(
                "Desaquecimento", "Reduza gradualmente e encerre em Z1 confortável, na extremidade mais rápida da zona.",
                cooldownKm, "Z1", zones, "1-2", ZoneIntensityBandEngine.z1WarmupCoolDownBand
            ), zones)
        )
        val title = when (style) {
            "PROGRESSIVE_Z2_Z3" -> "Longão progressivo Z2–Z3"
            "PROGRESSIVE_Z2_ONLY" -> "Longão progressivo Z2"
            "REGRESSIVE_Z3_Z2" -> "Longão regressivo Z3–Z2"
            "REGRESSIVE_Z2_ONLY" -> "Longão regressivo Z2"
            else -> if (recoveryWeek) "Longão aeróbio reduzido" else "Longão aeróbio"
        }
        val rationale = when (style) {
            "PROGRESSIVE_Z2_Z3" -> "A maior parte permanece em Z2; o final entra em Z3 por um trecho curto (até 12% da parte principal), somente com experiência, volume, longão recente e recuperação suficientes. Z1 aparece apenas no aquecimento/desaquecimento."
            "PROGRESSIVE_Z2_ONLY" -> "Progressão dentro da Z2, da faixa mais confortável para uma faixa mais rápida. Z3 não foi liberada pelo perfil/carga atual; Z1 fica reservada ao aquecimento e desaquecimento."
            "REGRESSIVE_Z3_Z2" -> "Comece com um trecho curto e controlado em Z3, reduza para Z2 e termine na parte confortável da Z2. Z1 aparece apenas no aquecimento/desaquecimento."
            "REGRESSIVE_Z2_ONLY" -> "Regressão dentro da Z2: comece na faixa mais rápida permitida e reduza gradualmente até a faixa confortável, sem entrar em Z3."
            else -> if (recoveryWeek) "Volume reduzido na semana regenerativa; mantenha esforço conversável em Z2. Aquecimento e desaquecimento são etapas próprias." else "Longão contínuo em Z2, com aquecimento e desaquecimento em Z1. A distância é limitada pelo maior treino recente, pela parcela semanal e pelo objetivo."
        }
        val stimulus = when (style) {
            "PROGRESSIVE_Z2_Z3" -> "LONG_RUN_PROGRESSIVE_Z2_Z3"
            "PROGRESSIVE_Z2_ONLY" -> "LONG_RUN_PROGRESSIVE_Z2"
            "REGRESSIVE_Z3_Z2" -> "LONG_RUN_REGRESSIVE_Z3_Z2"
            "REGRESSIVE_Z2_ONLY" -> "LONG_RUN_REGRESSIVE_Z2"
            else -> "AEROBIC_ENDURANCE"
        }
        return workout(date, title, "Longo", "Desenvolver resistência com carga compatível com a tolerância recente", stimulus,
            km, rpe, week, phase, segments, rationale, "LOW")
    }

    /** Time-based beginner/re-entry session. Distance values are estimates for weekly-load accounting only. */
    private fun createRunWalk(
        date: LocalDate,
        km: Double,
        week: Int,
        phase: String,
        recovery: Boolean,
        isLongRun: Boolean
    ): PrescribedWorkout {
        val stage = when {
            week <= 2 -> 0
            week <= 4 -> 1
            week <= 6 -> 2
            else -> 3
        }
        val runMinutes = listOf(1, 2, 3, 5)[stage]
        val baseWalkMinutes = listOf(2, 2, 2, 2)[stage]
        val targetMinutes = (km * 8.0).toInt().coerceIn(15, if (isLongRun) 45 else 38)
        val warmCoolMinutes = if (targetMinutes >= 24) 4 else 3
        val intervalBudget = (targetMinutes - warmCoolMinutes * 2).coerceAtLeast(4)
        val baseRepeats = (intervalBudget / (runMinutes + baseWalkMinutes)).coerceIn(2, 6)
        val repeats = if (recovery) (baseRepeats - 1).coerceAtLeast(2) else baseRepeats
        val walkMinutes = if (recovery) baseWalkMinutes + 1 else baseWalkMinutes
        val warmKm = km * 0.10
        val coolKm = km * 0.10
        val runTotalKm = km * 0.55
        val walkTotalKm = (km - warmKm - coolKm - runTotalKm).coerceAtLeast(0.0)
        val segments = listOf(
            WorkoutSegment("Aquecimento caminhando", "Caminhe em ritmo confortável e mobilize tornozelos e quadris antes dos intervalos.",
                durationMin = warmCoolMinutes, distanceKm = warmKm, intensity = "LOW", rpeRange = "1-2"),
            WorkoutSegment("Corrida leve", "Corra relaxado, em esforço fácil. Deve ser possível falar frases curtas; não persiga pace.",
                durationMin = runMinutes, distanceKm = runTotalKm / repeats, intensity = "LOW", rpeRange = "3-4", repeatCount = repeats),
            WorkoutSegment("Caminhada de recuperação", "Caminhe até recuperar a respiração antes de iniciar o próximo intervalo. Não elimine as pausas.",
                durationMin = walkMinutes, distanceKm = walkTotalKm / repeats, intensity = "LOW", rpeRange = "1-2", repeatCount = repeats),
            WorkoutSegment("Desaquecimento caminhando", "Finalize caminhando devagar até a respiração voltar ao normal.",
                durationMin = warmCoolMinutes, distanceKm = coolKm, intensity = "LOW", rpeRange = "1-2")
        )
        val totalKm = segments.sumOf { (it.distanceKm ?: 0.0) * it.repeatCount }
        val duration = segments.sumOf { (it.durationMin ?: 0) * it.repeatCount }
        val title = when {
            isLongRun && recovery -> "Longão leve reduzido (corrida/caminhada)"
            isLongRun -> "Longão leve (corrida/caminhada)"
            recovery -> "Corrida/caminhada regenerativa"
            else -> "Corrida/caminhada intervalada"
        }
        return workout(date, title, if (isLongRun) "Longo" else if (recovery) "Recuperação" else "Aeróbio",
            "Desenvolver tolerância gradual à corrida e consistência sem forçar corrida contínua",
            if (isLongRun) "BEGINNER_RUN_WALK_LONG" else "BEGINNER_RUN_WALK",
            totalKm, if (recovery) "2-3" else "3-4", week, phase, segments,
            "Prescrição por tempo, alternando corrida leve e caminhada. A distância indicada é estimada para controle de volume; siga os minutos e o esforço, não um pace. A semana regenerativa reduz repetições e amplia a caminhada.", "LOW")
            .copy(durationMin = duration)
    }

    /**
     * Com pace calibrado, aquecimento, recuperação e desaquecimento são mais naturais por tempo.
     * Sem referência recente, mantém esses blocos por distância e não presume uma velocidade.
     * distanceKm em um bloco TIME é somente a contribuição estimada para o volume semanal.
     */
    private fun asTimeTarget(segment: WorkoutSegment, zones: TrainingPaceZones?): WorkoutSegment {
        if (zones == null) return segment
        val estimatedDistance = segment.distanceKm ?: return segment
        val fullFast = segment.zoneBasePaceFastValue ?: segment.targetPaceMinValue ?: return segment
        val fullSlow = segment.zoneBasePaceSlowValue ?: segment.targetPaceMaxValue ?: return segment
        if (fullFast <= 0 || fullSlow < fullFast) return segment
        val activeRange = if (segment.zoneIntensityMinPercent != null && segment.zoneIntensityMaxPercent != null) {
            ZoneIntensityBandEngine.activeRange(
                PaceRange(fullFast, fullSlow),
                ActiveZoneBand(segment.zoneIntensityMinPercent, segment.zoneIntensityMaxPercent)
            )
        } else PaceRange(fullFast, fullSlow)
        val midpointPace = (activeRange.fastestPaceValue + activeRange.slowestPaceValue) / 2.0
        val minutes = kotlin.math.round(estimatedDistance * midpointPace / 60.0).toInt().coerceAtLeast(1)
        return segment.copy(durationMin = minutes, targetMode = "TIME")
    }

    private fun workout(date: LocalDate, title: String, type: String, objective: String, stimulus: String, distanceKm: Double, rpe: String,
        week: Int, phase: String, segments: List<WorkoutSegment>, rationale: String, intensity: String): PrescribedWorkout {
        // The exact workout total and the visible segment total share one source of truth.
        val reconciledSegments = TrainingPrescriptionAudit.reconcileSegments(segments, distanceKm)
        val reconciledDistance = if (reconciledSegments.any { it.distanceKm != null }) {
            TrainingPrescriptionAudit.estimatedSegmentDistanceKm(reconciledSegments)
        } else distanceKm
        val duration = WorkoutDurationEstimator.estimateMinutes(reconciledSegments, reconciledDistance)
        val dayName = date.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, Locale.forLanguageTag("pt-BR"))
        val dateLabel = "${dayName.replaceFirstChar { it.uppercase(Locale.forLanguageTag("pt-BR")) }}, ${date.format(DateTimeFormatter.ofPattern("dd/MM"))}"
        val detail = formatSegments(reconciledSegments)
        val id = "W$week-${date.dayOfWeek.name}-${type.uppercase(Locale.US).replace(' ', '-')}"
        return PrescribedWorkout(dayName.replaceFirstChar { it.uppercase(Locale.forLanguageTag("pt-BR")) }, dateLabel, date.toString(), title, type, objective, stimulus,
            id, round1(reconciledDistance), duration, intensity,
            if (reconciledSegments.any { it.targetPaceMinValue != null && it.targetPaceMaxValue != null }) "PACE_RANGE" else "PACE_NOT_CALIBRATED",
            rpe, detail, rationale, week, phase, reconciledSegments)
    }

    private fun formatSegments(segments: List<WorkoutSegment>): String = segments.joinToString(" • ") { segment ->
        val estimatedKm = segment.distanceKm?.let { it * segment.repeatCount }
        val dose = when {
            segment.targetMode == "TIME" && segment.repeatCount > 1 && segment.durationMin != null -> "${segment.repeatCount} × ${segment.durationMin} min${estimatedKm?.let { " • ~${formatKm(it)} km estimados no total" }.orEmpty()}"
            segment.targetMode == "TIME" && segment.durationMin != null -> "${segment.durationMin} min${estimatedKm?.let { " • ~${formatKm(it)} km estimados" }.orEmpty()}"
            segment.repeatCount > 1 && segment.distanceKm != null -> "${segment.repeatCount} × ${formatKm(segment.distanceKm)} km"
            segment.distanceKm != null -> "${formatKm(segment.distanceKm)} km"
            segment.durationMin != null -> "${segment.durationMin} min"
            else -> ""
        }
        val pace = if (segment.targetPaceMinValue != null && segment.targetPaceMaxValue != null) {
            "pace ${PaceRange(segment.targetPaceMinValue, segment.targetPaceMaxValue).label()}"
        } else "pace não calibrado"
        val zone = segment.paceZone?.let { "$it • " } ?: ""
        "${segment.name}: $dose ($zone$pace; RPE auxiliar ${segment.rpeRange})"
    }

    private fun trainingDays(input: RunnerInput): List<DayOfWeek> =
        TrainingScheduleEngine.prescribedRunningDays(
            input.availableDays, input.frequency, isNovicePlan(input), input.preferredLongRunDay
        )

    private fun isNovicePlan(input: RunnerInput): Boolean =
        input.level == "Iniciante" || input.weeklyVolumeKm < 8.0 || input.longestRecentKm < 5.0


    private fun recoveryStatus(score: Double?): String = when {
        score == null -> "UNKNOWN"
        score >= 75.0 -> "GOOD"
        score >= 50.0 -> "MODERATE"
        else -> "POOR"
    }

    private fun safetyStatus(input: RunnerInput): String = when {
        input.painPresent -> "RED"
        input.fatigueScore != null && input.fatigueScore >= 65.0 -> "YELLOW"
        input.recoveryScore != null && input.recoveryScore < 75.0 -> "YELLOW"
        input.recoveryScore == null && input.fatigueScore == null -> "UNASSESSED"
        else -> "GREEN"
    }

    private fun buildFlags(input: RunnerInput, recovery: String, safety: String): List<String> = buildList {
        if (input.frequency < 3) add("LOW_FREQUENCY")
        if (input.weeklyVolumeKm == 0.0) add("NO_RECENT_WEEKLY_VOLUME")
        if (input.longestRecentKm < 5.0) add("LIMITED_LONG_RUN_HISTORY")
        if (input.fatigueScore != null && input.fatigueScore >= 75.0) add("HIGH_FATIGUE")
        else if (input.fatigueScore != null && input.fatigueScore >= 65.0) add("RECOVERY_MONITORING")
        if (input.recentActivityHistoryReliable) add("RECENT_LOAD_FROM_LOGGED_ACTIVITIES")
        else if (input.recentActivityCount > 0) add("RECENT_ACTIVITY_HISTORY_PARTIAL")
        if (isNovicePlan(input)) add("BEGINNER_RUN_WALK_ADAPTED_DOSE")
        if (input.longestRecentKm > 0.0) add("SINGLE_SESSION_CAP_BASED_ON_RECENT_TOLERANCE")
        val days = trainingDays(input)
        val longDay = input.preferredLongRunDay?.takeIf { it in days } ?: days.last()
        val qualityPrerequisites = !isNovicePlan(input) && input.frequency >= 3 &&
            input.weeklyVolumeKm >= 16.0 && input.longestRecentKm >= 8.0
        if (qualityPrerequisites && TrainingScheduleEngine.qualityDayWithRecoveryGap(days, longDay) == null) {
            add("QUALITY_SUPPRESSED_BY_RECOVERY_SPACING")
        }
        if (recovery == "POOR") add("LOW_RECOVERY")
        if (safety == "UNASSESSED") add("READINESS_NOT_ASSESSED")
        if (safety == "RED") add("PAIN_REPORTED")
    }

    private fun roundHalf(value: Double): Double = kotlin.math.floor(value * 2.0 + 0.5) / 2.0
    private fun floorHalf(value: Double): Double = kotlin.math.floor(value * 2.0) / 2.0
    private fun round1(value: Double): Double = kotlin.math.round(value * 10.0) / 10.0
    internal fun formatKm(value: Double): String = if (value % 1.0 == 0.0) value.toInt().toString() else String.format(Locale.US, "%.1f", value)
    internal fun currentWeekMonday(from: LocalDate): LocalDate = from.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
}
