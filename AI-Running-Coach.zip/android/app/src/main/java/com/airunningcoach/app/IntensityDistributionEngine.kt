package com.airunningcoach.app

import kotlin.math.roundToInt

/** Distribution by effective segment time, never by number of workouts. */
internal data class IntensityDistributionReport(
    val lowIntensityPercent: Int,
    val moderateIntensityPercent: Int,
    val highIntensityPercent: Int,
    val totalEstimatedMinutes: Int,
    val zoneMinutes: Map<String, Int>,
    val confidence: String,
    val explanation: String
)

internal data class IntensityDistributionTarget(
    val lowMinPercent: Int,
    val lowMaxPercent: Int,
    val moderateMinPercent: Int,
    val moderateMaxPercent: Int,
    val highMinPercent: Int,
    val highMaxPercent: Int,
    val note: String
)

/**
 * Converts all planned workout segments into a time-weighted distribution.
 * If a segment has no duration or pace, its contribution is marked as an estimate.
 * Reference ranges are coaching heuristics, not universal physiological prescriptions.
 */
internal object IntensityDistributionEngine {
    fun target(goalCategory: String, level: String, phase: String): IntensityDistributionTarget {
        val normalizedLevel = RunnerFitnessAssessmentEngine.normalizeLevel(level)
        if (goalCategory == "HEALTH") return IntensityDistributionTarget(
            90, 100, 0, 10, 0, 0,
            "Plano de saúde: predomínio de baixa intensidade; estímulos superiores não são obrigatórios. Referências exclusivas de ritmo e esforço percebido."
        )
        if (phase == TrainingPeriodizationEngine.RECOVERY || phase == TrainingPeriodizationEngine.POST_RACE) {
            return IntensityDistributionTarget(92, 100, 0, 8, 0, 0,
                "Recuperação: concentração em Z1/Z2; estímulos de qualidade são suspensos ou substituídos por corrida leve/caminhada.")
        }
        val beginner = normalizedLevel == "Iniciante"
        val advanced = normalizedLevel == "Performance" || normalizedLevel == "Elite"
        return when (phase) {
            TrainingPeriodizationEngine.BASE -> when {
                beginner -> IntensityDistributionTarget(88, 96, 4, 12, 0, 2, "Base iniciante: predomínio de Z1/Z2 e caminhada/trote; Z3 é breve e opcional, Z4/Z5 não são metas desta fase.")
                advanced -> IntensityDistributionTarget(78, 90, 8, 18, 1, 6, "Base avançada: mantém predominância aeróbia e admite pequenas variações moderadas; estímulos altos permanecem ocasionais.")
                else -> IntensityDistributionTarget(82, 93, 6, 16, 0, 4, "Base intermediária: predominância Z1/Z2 com pequenas entradas moderadas conforme tolerância.")
            }
            TrainingPeriodizationEngine.DEVELOPMENT -> when {
                beginner -> IntensityDistributionTarget(85, 95, 5, 14, 0, 3, "Desenvolvimento iniciante: a maior parte permanece leve; Z3 aparece em blocos curtos somente após adaptação contínua.")
                advanced -> IntensityDistributionTarget(72, 86, 10, 22, 3, 10, "Desenvolvimento avançado: combina base aeróbia, limiar e intervalos; intensidade alta limitada pela recuperação.")
                else -> IntensityDistributionTarget(78, 90, 8, 18, 1, 7, "Desenvolvimento intermediário: Z2 predomina, com Z3 e doses pequenas de Z4 quando volume e recuperação permitem.")
            }
            TrainingPeriodizationEngine.SPECIFIC, TrainingPeriodizationEngine.TAPER -> when {
                beginner -> IntensityDistributionTarget(88, 96, 4, 12, 0, 2, "Preparação específica iniciante: preservar a continuidade e reduzir carga; intensidade alta não é obrigatória.")
                advanced -> IntensityDistributionTarget(74, 88, 8, 19, 3, 10, "Preparação específica avançada: distribuir os estímulos conforme o ritmo da prova, com baixa intensidade predominante e taper sem acumular fadiga.")
                else -> IntensityDistributionTarget(80, 92, 6, 16, 1, 6, "Preparação específica intermediária: priorizar o ritmo-alvo sustentável e conservar a maior parte do volume em baixa intensidade.")
            }
            else -> IntensityDistributionTarget(82, 94, 5, 15, 0, 5, "Referência de ritmo ajustável pela fase, objetivo, nível e tolerância individual; não é uma quota obrigatória.")
        }
    }

    fun summarize(workouts: List<PrescribedWorkout>): IntensityDistributionReport {
        val secondsByZone = mutableMapOf("Z1" to 0.0, "Z2" to 0.0, "Z3" to 0.0, "Z4" to 0.0, "Z5" to 0.0)
        var estimatedSegments = 0
        workouts.forEach { workout ->
            workout.segments.forEach segmentLoop@ { segment ->
                val zone = segment.paceZone?.uppercase()?.takeIf { it in secondsByZone.keys } ?: return@segmentLoop
                val repeat = segment.repeatCount.coerceAtLeast(1)
                val durationSeconds = when {
                    segment.durationSeconds != null -> segment.durationSeconds.toDouble()
                    segment.durationMin != null -> segment.durationMin * 60.0
                    segment.distanceKm != null && segment.targetPaceMinValue != null && segment.targetPaceMaxValue != null -> {
                        val middlePace = (segment.targetPaceMinValue + segment.targetPaceMaxValue) / 2.0
                        segment.distanceKm * middlePace
                    }
                    segment.distanceKm != null -> {
                        estimatedSegments++
                        segment.distanceKm * 600.0 // fallback estimate only; not a measured duration
                    }
                    else -> 0.0
                }
                if (durationSeconds > 0.0) secondsByZone[zone] = secondsByZone.getValue(zone) + durationSeconds * repeat
            }
        }
        val low = secondsByZone.getValue("Z1") + secondsByZone.getValue("Z2")
        val moderate = secondsByZone.getValue("Z3")
        val high = secondsByZone.getValue("Z4") + secondsByZone.getValue("Z5")
        val total = low + moderate + high
        val zoneMinutes = secondsByZone.mapValues { (_, seconds) -> (seconds / 60.0).roundToInt() }
        fun percent(value: Double): Int = if (total <= 0.0) 0 else (value / total * 100.0).roundToInt().coerceIn(0, 100)
        return IntensityDistributionReport(
            lowIntensityPercent = percent(low),
            moderateIntensityPercent = percent(moderate),
            highIntensityPercent = percent(high),
            totalEstimatedMinutes = (total / 60.0).roundToInt(),
            zoneMinutes = zoneMinutes,
            confidence = when {
                total <= 0.0 -> "INSUFFICIENT"
                estimatedSegments > 0 -> "ESTIMATED"
                else -> "STRUCTURED_ESTIMATE"
            },
            explanation = when {
                total <= 0.0 -> "Distribuição indisponível: os segmentos ainda não têm tempo ou pace suficiente. Percentuais não são exibidos para evitar falsos 0%."
                estimatedSegments > 0 -> "Distribuição calculada pelo tempo dos segmentos; ${estimatedSegments} etapa(s) sem duração/ritmo usaram estimativa conservadora. Não representa a intensidade efetivamente executada."
                else -> "Distribuição planejada ponderada pelo tempo de cada segmento. A distribuição realizada só pode ser calculada quando houver tempo em zonas medido/importado."
            }
        )
    }
}
