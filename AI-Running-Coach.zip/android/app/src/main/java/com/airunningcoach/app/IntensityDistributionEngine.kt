package com.airunningcoach.app

import kotlin.math.roundToInt

/** Distribution by effective segment time, never by number of workouts. */
internal data class IntensityDistributionReport(
    val lowIntensityPercent: Int,
    val moderateIntensityPercent: Int,
    val highIntensityPercent: Int,
    val totalEstimatedMinutes: Int,
    val zoneMinutes: Map<String, Int>,
    val confidence: String,
    val explanation: String
)

internal data class IntensityDistributionTarget(
    val lowMinPercent: Int,
    val lowMaxPercent: Int,
    val moderateMinPercent: Int,
    val moderateMaxPercent: Int,
    val highMinPercent: Int,
    val highMaxPercent: Int,
    val note: String
)

/**
 * Converts all planned workout segments into a time-weighted distribution.
 * If a segment has no duration or pace, its contribution is marked as an estimate.
 * Reference ranges are coaching heuristics, not universal physiological prescriptions.
 */
internal object IntensityDistributionEngine {
    fun target(goalCategory: String, level: String, phase: String): IntensityDistributionTarget {
        if (goalCategory == "HEALTH") return IntensityDistributionTarget(
            90, 100, 0, 10, 0, 0,
            "Plano orientado à saúde: predomínio de baixa intensidade, sem obrigação de estímulos intensos."
        )
        val advanced = level in setOf("Performance", "Avançado", "Elite")
        return when {
            phase == TrainingPeriodizationEngine.RECOVERY -> IntensityDistributionTarget(
                90, 100, 0, 10, 0, 0,
                "Semana de recuperação: a distribuição é deliberadamente concentrada em baixa intensidade."
            )
            level == "Iniciante" -> IntensityDistributionTarget(
                85, 100, 0, 15, 0, 0,
                "Iniciante: a qualidade é introduzida gradualmente; a distribuição não exige Z4/Z5."
            )
            advanced -> IntensityDistributionTarget(
                75, 90, 5, 15, 0, 10,
                "Perfil avançado: pode comportar estímulos moderados/altos quando a carga, fase e recuperação permitem."
            )
            else -> IntensityDistributionTarget(
                80, 92, 5, 15, 0, 5,
                "Perfil intermediário: predomínio aeróbio e parcela pequena de intensidade superior quando elegível."
            )
        }
    }

    fun summarize(workouts: List<PrescribedWorkout>): IntensityDistributionReport {
        val secondsByZone = mutableMapOf("Z1" to 0.0, "Z2" to 0.0, "Z3" to 0.0, "Z4" to 0.0, "Z5" to 0.0)
        var estimatedSegments = 0
        workouts.forEach { workout ->
            workout.segments.forEach segmentLoop@ { segment ->
                val zone = segment.paceZone?.uppercase()?.takeIf { it in secondsByZone.keys } ?: return@segmentLoop
                val repeat = segment.repeatCount.coerceAtLeast(1)
                val durationSeconds = when {
                    segment.durationMin != null -> segment.durationMin * 60.0
                    segment.distanceKm != null && segment.targetPaceMinValue != null && segment.targetPaceMaxValue != null -> {
                        val middlePace = (segment.targetPaceMinValue + segment.targetPaceMaxValue) / 2.0
                        segment.distanceKm * middlePace
                    }
                    segment.distanceKm != null -> {
                        estimatedSegments++
                        segment.distanceKm * 600.0 // fallback estimate only; not a measured duration
                    }
                    else -> 0.0
                }
                if (durationSeconds > 0.0) secondsByZone[zone] = secondsByZone.getValue(zone) + durationSeconds * repeat
            }
        }
        val low = secondsByZone.getValue("Z1") + secondsByZone.getValue("Z2")
        val moderate = secondsByZone.getValue("Z3")
        val high = secondsByZone.getValue("Z4") + secondsByZone.getValue("Z5")
        val total = low + moderate + high
        val zoneMinutes = secondsByZone.mapValues { (_, seconds) -> (seconds / 60.0).roundToInt() }
        fun percent(value: Double): Int = if (total <= 0.0) 0 else (value / total * 100.0).roundToInt().coerceIn(0, 100)
        return IntensityDistributionReport(
            lowIntensityPercent = percent(low),
            moderateIntensityPercent = percent(moderate),
            highIntensityPercent = percent(high),
            totalEstimatedMinutes = (total / 60.0).roundToInt(),
            zoneMinutes = zoneMinutes,
            confidence = when {
                total <= 0.0 -> "INSUFFICIENT"
                estimatedSegments > 0 -> "ESTIMATED"
                else -> "STRUCTURED_ESTIMATE"
            },
            explanation = when {
                total <= 0.0 -> "Não há tempo segmentado suficiente para calcular a distribuição planejada."
                estimatedSegments > 0 -> "Distribuição calculada pelo tempo dos segmentos; ${estimatedSegments} etapa(s) sem duração/pace usaram estimativa conservadora. Não representa a intensidade efetivamente executada."
                else -> "Distribuição planejada ponderada pelo tempo de cada segmento. A distribuição realizada só pode ser calculada quando houver tempo em zonas medido/importado."
            }
        )
    }
}
