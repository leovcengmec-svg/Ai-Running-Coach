package com.airunningcoach.app

import kotlin.math.roundToInt

/** Distribution by effective segment time, never by number of workouts. */
internal data class IntensityDistributionReport(
    val lowIntensityPercent: Int,
    val moderateIntensityPercent: Int,
    val highIntensityPercent: Int,
    val totalEstimatedMinutes: Int,
    val zoneMinutes: Map<String, Int>,
    val confidence: String,
    val explanation: String
)

internal data class IntensityDistributionTarget(
    val lowMinPercent: Int,
    val lowMaxPercent: Int,
    val moderateMinPercent: Int,
    val moderateMaxPercent: Int,
    val highMinPercent: Int,
    val highMaxPercent: Int,
    val note: String
)

/**
 * Converts all planned workout segments into a time-weighted distribution.
 * If a segment has no duration or pace, its contribution is marked as an estimate.
 * Reference ranges are coaching heuristics, not universal physiological prescriptions.
 */
internal object IntensityDistributionEngine {
    @Suppress("UNUSED_PARAMETER")
    fun target(goalCategory: String, level: String, phase: String): IntensityDistributionTarget {
        if (goalCategory == "HEALTH") return IntensityDistributionTarget(
            90, 100, 0, 10, 0, 0,
            "Plano de saúde: predomínio de baixa intensidade; estímulos superiores não são obrigatórios."
        )
        return when (phase) {
            TrainingPeriodizationEngine.RECOVERY, TrainingPeriodizationEngine.POST_RACE -> IntensityDistributionTarget(
                90, 100, 0, 10, 0, 0,
                "Recuperação: a distribuição fica concentrada em baixa intensidade, independentemente do nível fisiológico."
            )
            TrainingPeriodizationEngine.BASE -> IntensityDistributionTarget(
                80, 92, 8, 20, 0, 5,
                "Base: predomínio aeróbio; pequenas variações moderadas podem entrar conforme carga e recuperação."
            )
            TrainingPeriodizationEngine.DEVELOPMENT -> IntensityDistributionTarget(
                75, 90, 8, 20, 0, 10,
                "Desenvolvimento: a dose moderada/alta depende de volume, frequência, consistência e recuperação — não do rótulo fisiológico isolado."
            )
            TrainingPeriodizationEngine.SPECIFIC, TrainingPeriodizationEngine.TAPER -> IntensityDistributionTarget(
                75, 92, 5, 20, 0, 10,
                "Específica: distribua o estímulo de acordo com a prova e o objetivo; a intensidade alta só entra quando os critérios individuais permitem."
            )
            else -> IntensityDistributionTarget(
                80, 92, 5, 18, 0, 8,
                "Referência ajustável pela fase, pelo objetivo e pela tolerância individual. Não é uma quota obrigatória de intensidade."
            )
        }
    }

    fun summarize(workouts: List<PrescribedWorkout>): IntensityDistributionReport {
        val secondsByZone = mutableMapOf("Z1" to 0.0, "Z2" to 0.0, "Z3" to 0.0, "Z4" to 0.0, "Z5" to 0.0)
        var estimatedSegments = 0
        workouts.forEach { workout ->
            workout.segments.forEach segmentLoop@ { segment ->
                val zone = segment.paceZone?.uppercase()?.takeIf { it in secondsByZone.keys } ?: return@segmentLoop
                val repeat = segment.repeatCount.coerceAtLeast(1)
                val durationSeconds = when {
                    segment.durationMin != null -> segment.durationMin * 60.0
                    segment.distanceKm != null && segment.targetPaceMinValue != null && segment.targetPaceMaxValue != null -> {
                        val middlePace = (segment.targetPaceMinValue + segment.targetPaceMaxValue) / 2.0
                        segment.distanceKm * middlePace
                    }
                    segment.distanceKm != null -> {
                        estimatedSegments++
                        segment.distanceKm * 600.0 // fallback estimate only; not a measured duration
                    }
                    else -> 0.0
                }
                if (durationSeconds > 0.0) secondsByZone[zone] = secondsByZone.getValue(zone) + durationSeconds * repeat
            }
        }
        val low = secondsByZone.getValue("Z1") + secondsByZone.getValue("Z2")
        val moderate = secondsByZone.getValue("Z3")
        val high = secondsByZone.getValue("Z4") + secondsByZone.getValue("Z5")
        val total = low + moderate + high
        val zoneMinutes = secondsByZone.mapValues { (_, seconds) -> (seconds / 60.0).roundToInt() }
        fun percent(value: Double): Int = if (total <= 0.0) 0 else (value / total * 100.0).roundToInt().coerceIn(0, 100)
        return IntensityDistributionReport(
            lowIntensityPercent = percent(low),
            moderateIntensityPercent = percent(moderate),
            highIntensityPercent = percent(high),
            totalEstimatedMinutes = (total / 60.0).roundToInt(),
            zoneMinutes = zoneMinutes,
            confidence = when {
                total <= 0.0 -> "INSUFFICIENT"
                estimatedSegments > 0 -> "ESTIMATED"
                else -> "STRUCTURED_ESTIMATE"
            },
            explanation = when {
                total <= 0.0 -> "Distribuição indisponível: os segmentos ainda não têm tempo ou pace suficiente. Percentuais não são exibidos para evitar falsos 0%."
                estimatedSegments > 0 -> "Distribuição calculada pelo tempo dos segmentos; ${estimatedSegments} etapa(s) sem duração/pace usaram estimativa conservadora. Não representa a intensidade efetivamente executada."
                else -> "Distribuição planejada ponderada pelo tempo de cada segmento. A distribuição realizada só pode ser calculada quando houver tempo em zonas medido/importado."
            }
        )
    }
}
