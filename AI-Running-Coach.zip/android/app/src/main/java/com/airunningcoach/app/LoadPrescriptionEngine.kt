package com.airunningcoach.app

import kotlin.math.min
import kotlin.math.round

internal data class LoadPrescriptionInput(
    val currentWeeklyKm: Double,
    val activeWeeksLast4: Int,
    val measuredHistoryReliable: Boolean,
    val recoveryScore: Double? = null,
    val fatigueScore: Double? = null,
    val weeks: Int,
    val hasPain: Boolean = false,
    val longestRecentKm: Double = 0.0,
    val recentLoadTrendRatio: Double? = null,
    val averageRpe: Double? = null,
    /** Number of distinct measured activities contributing to averageRpe. */
    val averageRpeEvidenceCount: Int = 0,
    val referenceMinKm: Double? = null,
    val referenceMaxKm: Double? = null,
    /** Explicitly confirmed onboarding baseline when activity history is not yet reliable. */
    val profileBaselineConfirmed: Boolean = false,
    /** Goal catalogue baseline used only when weekly volume was not supplied. */
    val goalBaseKm: Double? = null,
    /** Explicit zero weekly volume AND zero longest run; do not replace a declared no-running state. */
    val explicitNoRecentTraining: Boolean = false,
    /** Completed ÷ scheduled sessions in the previous weeks; null when the sample is too small. */
    val recentSessionCompletionRatio: Double? = null,
    /** Competition weeks are tapered elsewhere and must not receive a second deload reduction. */
    val competitionWeekNumbers: Set<Int> = emptySet()
)

internal data class WeeklyLoadTarget(
    val week: Int,
    val targetKm: Double,
    val phase: String,
    val maxGrowthPercent: Int,
    val rationale: String,
    val recoveryReductionPercent: Int = 25
)

/**
 * Individualized load trajectory. MainActivity supplies the stored goal base only when
 * the athlete leaves both recent-volume fields blank; explicit actual values override it.
 * The goal's stored maximum is the build ceiling. Growth percentages are product guardrails,
 * not universal sports-science laws or medical risk thresholds.
 */
internal object LoadPrescriptionEngine {
    fun build(input: LoadPrescriptionInput): List<WeeklyLoadTarget> {
        require(input.currentWeeklyKm.isFinite() && input.currentWeeklyKm in 0.0..300.0)
        require(input.activeWeeksLast4 == -1 || input.activeWeeksLast4 in 0..4)
        require(input.weeks in 4..52)
        require(input.longestRecentKm.isFinite() && input.longestRecentKm in 0.0..200.0)
        require(input.recentLoadTrendRatio == null || input.recentLoadTrendRatio.isFinite() && input.recentLoadTrendRatio in 0.0..10.0)
        require(input.averageRpe == null || input.averageRpe.isFinite() && input.averageRpe in 1.0..10.0)
        require(input.averageRpeEvidenceCount >= 0)
        require(input.recentSessionCompletionRatio == null ||
            input.recentSessionCompletionRatio.isFinite() && input.recentSessionCompletionRatio in 0.0..1.0)
        require(input.referenceMinKm == null || input.referenceMinKm.isFinite() && input.referenceMinKm > 0.0)
        require(input.referenceMaxKm == null || input.referenceMaxKm.isFinite() && input.referenceMaxKm > 0.0)
        require(input.goalBaseKm == null || input.goalBaseKm.isFinite() && input.goalBaseKm > 0.0)
        require(input.referenceMinKm == null || input.referenceMaxKm == null || input.referenceMinKm <= input.referenceMaxKm)
        if (input.hasPain) return emptyList()

        // A missing activity log is not the same as a zero training baseline. The caller
        // hydrates blank onboarding fields from the selected goal's stored base; a typed
        // zero remains an explicit declaration of no current weekly exposure.
        val reintroduction = input.explicitNoRecentTraining ||
            (input.currentWeeklyKm <= 0.0 && input.longestRecentKm <= 0.0 && input.goalBaseKm == null) ||
            (input.activeWeeksLast4 == 0 && input.longestRecentKm <= 0.0 && input.explicitNoRecentTraining)
        val base = when {
            input.currentWeeklyKm > 0.0 -> input.currentWeeklyKm
            !input.explicitNoRecentTraining && input.goalBaseKm != null -> input.goalBaseKm
            else -> 3.0
        }
        val consistency = when (input.activeWeeksLast4) {
            in 3..4 -> if (input.measuredHistoryReliable) "RELIABLE" else "CONSISTENT"
            1, 2 -> "LOW"
            0 -> if (input.currentWeeklyKm > 0.0 && input.longestRecentKm > 0.0) "LOW" else "RETURN"
            else -> if (input.profileBaselineConfirmed) "PROFILE_CONFIRMED" else "UNKNOWN"
        }
        // A single moderate warning must not freeze every future build week. Severe
        // readiness signals hold progression; moderate signals reduce its rate. These
        // are product guardrails, not universal physiological thresholds.
        val severeReadinessHold =
            (input.recoveryScore != null && input.recoveryScore < 50.0) ||
                (input.fatigueScore != null && input.fatigueScore >= 75.0)
        val moderateCautionCount = listOf(
            input.recoveryScore != null && input.recoveryScore < 75.0,
            input.fatigueScore != null && input.fatigueScore >= 65.0,
            input.averageRpe != null && input.averageRpe >= 7.5 && input.averageRpeEvidenceCount >= 3,
            input.measuredHistoryReliable && input.recentLoadTrendRatio != null && input.recentLoadTrendRatio > 1.35,
            input.recentSessionCompletionRatio != null && input.recentSessionCompletionRatio < 0.65
        ).count { it }
        val recoveryReductionPercent = when {
            severeReadinessHold -> 40
            moderateCautionCount >= 2 -> 35
            moderateCautionCount == 1 || (input.recentSessionCompletionRatio != null && input.recentSessionCompletionRatio < 0.80) -> 30
            else -> 25
        }
        val consistencyGrowth = when (consistency) {
            "RELIABLE" -> 5
            "CONSISTENT" -> 4
            "PROFILE_CONFIRMED" -> 3
            "LOW" -> 1
            // Unknown/returning athletes start cautiously; declared volume is not
            // silently treated as measured consistency.
            "RETURN", "UNKNOWN" -> 2
            else -> 0
        }
        val readinessGrowthCap = when {
            severeReadinessHold -> 0
            moderateCautionCount >= 2 -> 1
            moderateCautionCount == 1 -> 2
            else -> 5
        }
        val growth = min(consistencyGrowth, readinessGrowthCap)

        val targets = mutableListOf<WeeklyLoadTarget>()
        val individualCeiling = input.referenceMaxKm?.let { maxOf(it, base) }
        // Keep the last BUILD reference separate from the temporary recovery-week target.
        // A deload reduces that week's exposure; it must not become the new baseline.
        var lastBuildTarget = round1(base)
        for (week in 1..input.weeks) {
            // Keep the 3-build/1-recovery rhythm, except when a competition week already
            // receives a race-specific taper. This prevents two planned reductions stacking.
            val recoveryWeek = (week - 1) % 4 == 3 && week !in input.competitionWeekNumbers
            val candidateBuildTarget = when {
                week == 1 -> lastBuildTarget
                growth == 0 -> lastBuildTarget
                else -> round1(lastBuildTarget * (1.0 + growth / 100.0))
            }
            val cappedBuildTarget = individualCeiling?.let { min(candidateBuildTarget, it) } ?: candidateBuildTarget
            val cappedByReference = individualCeiling != null && candidateBuildTarget > individualCeiling
            val target = if (recoveryWeek) {
                round1(lastBuildTarget * (1.0 - recoveryReductionPercent / 100.0))
                    .coerceAtLeast(if (reintroduction) 1.0 else 1.5)
            } else {
                cappedBuildTarget
            }
            if (!recoveryWeek) lastBuildTarget = target

            val approachingReferenceFloor = input.referenceMinKm != null && target < input.referenceMinKm
            val rationale = when {
                recoveryWeek && severeReadinessHold -> "Semana regenerativa adaptada: redução de $recoveryReductionPercent% sobre a última referência de construção por recuperação muito baixa ou fadiga elevada. A referência de construção é preservada; não compense sessões não realizadas."
                recoveryWeek && moderateCautionCount > 0 -> "Semana regenerativa adaptada: redução de $recoveryReductionPercent% sobre a última referência de construção após sinais de fadiga, RPE, recuperação, carga ou baixa execução. A referência é preservada; não compense sessões não realizadas."
                recoveryWeek -> "Semana regenerativa após três semanas de construção: redução padrão de 25% sobre a última referência de construção. A carga de construção anterior é preservada para a retomada da semana seguinte."
                severeReadinessHold -> "Progressão temporariamente suspensa: recuperação muito baixa ou fadiga elevada exige manter a carga de construção até nova avaliação."
                reintroduction -> "Reintrodução: dose inicial conservadora por histórico recente ausente; progressão pequena e condicionada à resposta e à recuperação, em direção à referência do objetivo."
                cappedByReference -> "Progressão limitada ao teto da faixa de referência do objetivo; o teto não autoriza saltos nem substitui a resposta individual."
                moderateCautionCount >= 2 -> "Progressão reduzida a 1% por múltiplos sinais moderados confiáveis de cautela (recuperação, fadiga, RPE ou tendência de carga); reavaliar com dados reais antes do próximo ciclo."
                moderateCautionCount == 1 -> "Progressão reduzida a 2% por um sinal moderado confiável de cautela; tendências sRPE sem histórico suficiente e médias com menos de três atividades não limitam a progressão."
                approachingReferenceFloor -> "Construção gradual em direção ao limite inferior de referência (${formatKm(requireNotNull(input.referenceMinKm))} km/semana), sem forçar seu alcance."
                consistency == "LOW" || consistency == "UNKNOWN" -> "Progressão mínima: consistência recente limitada ou desconhecida; a faixa de referência é apenas uma direção de preparação."
                consistency == "PROFILE_CONFIRMED" -> "Progressão moderada condicionada: o volume e o longão foram confirmados no cadastro, mas ainda não há histórico suficiente de sessões para classificar a consistência como medida."
                growth == 0 -> "Carga de construção mantida por uma restrição de segurança identificada; a referência anterior permanece preservada para reavaliação."
                else -> "Progressão gradual de $growth% sobre a última semana de construção. A semana regenerativa não apaga essa referência; volume, longão e resposta real continuam limitando cada sessão."
            }
            targets += WeeklyLoadTarget(
                week = week,
                targetKm = target,
                phase = if (recoveryWeek) TrainingPeriodizationEngine.RECOVERY else "BUILD",
                maxGrowthPercent = if (recoveryWeek) 0 else growth,
                rationale = rationale,
                recoveryReductionPercent = if (recoveryWeek) recoveryReductionPercent else 0
            )
        }
        return targets
    }

    private fun round1(value: Double): Double = round(value * 10.0) / 10.0

    private fun formatKm(value: Double): String = if (value % 1.0 == 0.0) value.toInt().toString() else String.format(java.util.Locale.US, "%.1f", value)
}
