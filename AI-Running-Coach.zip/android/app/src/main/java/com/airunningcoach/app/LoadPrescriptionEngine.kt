package com.airunningcoach.app

import kotlin.math.min
import kotlin.math.round

internal data class LoadPrescriptionInput(
    val currentWeeklyKm: Double,
    val activeWeeksLast4: Int,
    val measuredHistoryReliable: Boolean,
    val recoveryScore: Double? = null,
    val fatigueScore: Double? = null,
    val weeks: Int,
    val hasPain: Boolean = false,
    val longestRecentKm: Double = 0.0,
    val recentLoadTrendRatio: Double? = null,
    val averageRpe: Double? = null,
    val referenceMaxKm: Double? = null
)

internal data class WeeklyLoadTarget(
    val week: Int,
    val targetKm: Double,
    val phase: String,
    val maxGrowthPercent: Int,
    val rationale: String
)

/**
 * Individualized load trajectory. It uses measured/reported current load as the anchor and
 * never raises week one to a goal's reference minimum. Growth percentages are conservative
 * product guardrails, not universal sports-science laws or medical risk thresholds.
 */
internal object LoadPrescriptionEngine {
    fun build(input: LoadPrescriptionInput): List<WeeklyLoadTarget> {
        require(input.currentWeeklyKm.isFinite() && input.currentWeeklyKm in 0.0..300.0)
        require(input.activeWeeksLast4 == -1 || input.activeWeeksLast4 in 0..4)
        require(input.weeks in 4..52)
        require(input.longestRecentKm.isFinite() && input.longestRecentKm in 0.0..200.0)
        require(input.recentLoadTrendRatio == null || input.recentLoadTrendRatio.isFinite() && input.recentLoadTrendRatio in 0.0..10.0)
        require(input.averageRpe == null || input.averageRpe.isFinite() && input.averageRpe in 1.0..10.0)
        require(input.referenceMaxKm == null || input.referenceMaxKm.isFinite() && input.referenceMaxKm > 0.0)
        if (input.hasPain) return emptyList()

        val reintroduction = input.currentWeeklyKm <= 0.0 || input.activeWeeksLast4 == 0
        val base = if (reintroduction) 3.0 else input.currentWeeklyKm
        val consistency = when (input.activeWeeksLast4) {
            in 3..4 -> if (input.measuredHistoryReliable) "RELIABLE" else "CONSISTENT"
            1, 2 -> "LOW"
            0 -> "RETURN"
            else -> "UNKNOWN"
        }
        // The trajectory is individualized from consistency and recent response. These
        // are conservative product guardrails, not a universal weekly progression law.
        val growth = when {
            input.recoveryScore != null && input.recoveryScore < 50.0 -> 0
            input.fatigueScore != null && input.fatigueScore >= 75.0 -> 0
            input.recoveryScore != null && input.recoveryScore < 75.0 -> 0
            input.fatigueScore != null && input.fatigueScore >= 65.0 -> 0
            input.averageRpe != null && input.averageRpe >= 7.5 -> 0
            input.recentLoadTrendRatio != null && input.recentLoadTrendRatio > 1.35 -> 0
            consistency == "RELIABLE" -> 5
            consistency == "CONSISTENT" -> 3
            consistency == "LOW" -> 1
            consistency == "RETURN" -> 0
            else -> 0
        }

        val targets = mutableListOf<WeeklyLoadTarget>()
        var previous = round1(base)
        for (week in 1..input.weeks) {
            val recoveryWeek = (week - 1) % 4 == 3
            val unconstrainedTarget = when {
                week == 1 -> previous
                recoveryWeek -> round1(previous * 0.85)
                growth == 0 -> previous
                else -> round1(previous * (1.0 + growth / 100.0))
            }.coerceAtLeast(if (reintroduction) 1.0 else 1.5)
            // A reference range is a planning ceiling, not a minimum. Never force the
            // athlete up to it, and do not allow a growth step to overshoot it.
            // Do not raise the athlete to the reference minimum, and do not exceed
            // the reference ceiling after a recovery week. If baseline is already
            // above the reference, use that measured baseline as the ceiling so a
            // recovery week can rebuild toward (but never beyond) the athlete's base.
            val individualCeiling = input.referenceMaxKm?.let { maxOf(it, base) }
            val target = individualCeiling?.let { min(unconstrainedTarget, it) } ?: unconstrainedTarget
            val cappedByReference = individualCeiling != null && unconstrainedTarget > individualCeiling
            val rationale = when {
                reintroduction -> "Reintrodução: dose inicial baixa por histórico recente ausente; não tentar atingir a faixa de referência do objetivo."
                recoveryWeek -> "Semana de recuperação: redução em relação à semana anterior para consolidar a carga."
                growth == 0 && input.recentLoadTrendRatio != null && input.recentLoadTrendRatio > 1.35 -> "Carga mantida: a semana recente já está alta em relação à média de 28 dias."
                growth == 0 && input.averageRpe != null && input.averageRpe >= 7.5 -> "Carga mantida: o RPE médio recente indica esforço alto para a dose atual."
                growth == 0 -> "Carga mantida: recuperação, fadiga, dor ou consistência não justificam progressão nesta semana."
                cappedByReference -> "Progressão limitada ao teto de referência individual; a matriz não força o alcance do volume nem autoriza ultrapassá-lo."
                consistency == "LOW" || consistency == "UNKNOWN" -> "Progressão mínima: consistência recente limitada ou desconhecida."
                else -> "Progressão gradual com teto individual de $growth% sobre a semana anterior; a maior sessão, a tendência de carga e a resposta real continuam limitando cada treino."
            }
            targets += WeeklyLoadTarget(
                week = week,
                targetKm = target,
                phase = if (recoveryWeek) TrainingPeriodizationEngine.RECOVERY else "BUILD",
                maxGrowthPercent = growth,
                rationale = rationale
            )
            previous = target
        }
        return targets
    }

    private fun round1(value: Double): Double = round(value * 10.0) / 10.0
}
