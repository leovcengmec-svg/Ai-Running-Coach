package com.airunningcoach.app

import kotlin.math.min
import kotlin.math.round

internal data class LoadPrescriptionInput(
    val currentWeeklyKm: Double,
    val activeWeeksLast4: Int,
    val measuredHistoryReliable: Boolean,
    val recoveryScore: Double? = null,
    val fatigueScore: Double? = null,
    val weeks: Int,
    val hasPain: Boolean = false,
    val longestRecentKm: Double = 0.0,
    val recentLoadTrendRatio: Double? = null,
    val averageRpe: Double? = null,
    val referenceMinKm: Double? = null,
    val referenceMaxKm: Double? = null
)

internal data class WeeklyLoadTarget(
    val week: Int,
    val targetKm: Double,
    val phase: String,
    val maxGrowthPercent: Int,
    val rationale: String
)

/**
 * Individualized load trajectory. It uses measured/reported current load as the anchor and
 * never raises week one to a goal's reference minimum. Growth percentages are conservative
 * product guardrails, not universal sports-science laws or medical risk thresholds.
 */
internal object LoadPrescriptionEngine {
    fun build(input: LoadPrescriptionInput): List<WeeklyLoadTarget> {
        require(input.currentWeeklyKm.isFinite() && input.currentWeeklyKm in 0.0..300.0)
        require(input.activeWeeksLast4 == -1 || input.activeWeeksLast4 in 0..4)
        require(input.weeks in 4..52)
        require(input.longestRecentKm.isFinite() && input.longestRecentKm in 0.0..200.0)
        require(input.recentLoadTrendRatio == null || input.recentLoadTrendRatio.isFinite() && input.recentLoadTrendRatio in 0.0..10.0)
        require(input.averageRpe == null || input.averageRpe.isFinite() && input.averageRpe in 1.0..10.0)
        require(input.referenceMinKm == null || input.referenceMinKm.isFinite() && input.referenceMinKm > 0.0)
        require(input.referenceMaxKm == null || input.referenceMaxKm.isFinite() && input.referenceMaxKm > 0.0)
        require(input.referenceMinKm == null || input.referenceMaxKm == null || input.referenceMinKm <= input.referenceMaxKm)
        if (input.hasPain) return emptyList()

        val reintroduction = input.currentWeeklyKm <= 0.0 || input.activeWeeksLast4 == 0
        val base = if (reintroduction) 3.0 else input.currentWeeklyKm
        val consistency = when (input.activeWeeksLast4) {
            in 3..4 -> if (input.measuredHistoryReliable) "RELIABLE" else "CONSISTENT"
            1, 2 -> "LOW"
            0 -> "RETURN"
            else -> "UNKNOWN"
        }
        // The trajectory is individualized from consistency and recent response. These
        // are conservative product guardrails, not a universal weekly progression law.
        val growth = when {
            input.recoveryScore != null && input.recoveryScore < 50.0 -> 0
            input.fatigueScore != null && input.fatigueScore >= 75.0 -> 0
            input.recoveryScore != null && input.recoveryScore < 75.0 -> 0
            input.fatigueScore != null && input.fatigueScore >= 65.0 -> 0
            input.averageRpe != null && input.averageRpe >= 7.5 -> 0
            input.recentLoadTrendRatio != null && input.recentLoadTrendRatio > 1.35 -> 0
            consistency == "RELIABLE" -> 5
            consistency == "CONSISTENT" -> 3
            consistency == "LOW" -> 1
            // Unknown/returning athletes start from a conservative dose, but a fully
            // frozen trajectory would never prepare them for the selected distance.
            // A small 2% step is allowed only while recovery/fatigue/RPE gates are clear.
            consistency == "RETURN" || consistency == "UNKNOWN" -> 2
            else -> 0
        }

        val targets = mutableListOf<WeeklyLoadTarget>()
        val individualCeiling = input.referenceMaxKm?.let { maxOf(it, base) }
        // Keep the last BUILD reference separate from the temporary recovery-week target.
        // A deload reduces that week's exposure; it must not become the new baseline.
        var lastBuildTarget = round1(base)
        for (week in 1..input.weeks) {
            val recoveryWeek = (week - 1) % 4 == 3
            val candidateBuildTarget = when {
                week == 1 -> lastBuildTarget
                growth == 0 -> lastBuildTarget
                else -> round1(lastBuildTarget * (1.0 + growth / 100.0))
            }
            val cappedBuildTarget = individualCeiling?.let { min(candidateBuildTarget, it) } ?: candidateBuildTarget
            val cappedByReference = individualCeiling != null && candidateBuildTarget > individualCeiling
            val target = if (recoveryWeek) {
                round1(lastBuildTarget * 0.85).coerceAtLeast(if (reintroduction) 1.0 else 1.5)
            } else {
                cappedBuildTarget
            }
            if (!recoveryWeek) lastBuildTarget = target

            val approachingReferenceFloor = input.referenceMinKm != null && target < input.referenceMinKm
            val rationale = when {
                reintroduction -> "Reintrodução: dose inicial conservadora por histórico recente ausente; progressão pequena e condicionada à resposta e à recuperação, em direção à referência do objetivo."
                recoveryWeek -> "Semana regenerativa: redução temporária de 15% sobre a última referência de construção. A carga de construção anterior é preservada para a retomada da semana seguinte."
                growth == 0 && input.recentLoadTrendRatio != null && input.recentLoadTrendRatio > 1.35 -> "Carga de construção mantida: a carga recente já está elevada em relação à média de 28 dias."
                growth == 0 && input.averageRpe != null && input.averageRpe >= 7.5 -> "Carga de construção mantida: o RPE médio recente indica esforço alto para a dose atual."
                growth == 0 -> "Carga de construção mantida: recuperação, fadiga, dor ou consistência não justificam progressão nesta semana."
                cappedByReference -> "Progressão limitada ao teto da faixa de referência do objetivo; o teto não autoriza saltos nem substitui a resposta individual."
                approachingReferenceFloor -> "Construção gradual em direção ao limite inferior de referência (${formatKm(requireNotNull(input.referenceMinKm))} km/semana), sem forçar seu alcance."
                consistency == "LOW" || consistency == "UNKNOWN" -> "Progressão mínima: consistência recente limitada ou desconhecida; a faixa de referência é apenas uma direção de preparação."
                else -> "Progressão gradual de $growth% sobre a última semana de construção. A semana regenerativa não apaga essa referência; volume, longão e resposta real continuam limitando cada sessão."
            }
            targets += WeeklyLoadTarget(
                week = week,
                targetKm = target,
                phase = if (recoveryWeek) TrainingPeriodizationEngine.RECOVERY else "BUILD",
                maxGrowthPercent = if (recoveryWeek) 0 else growth,
                rationale = rationale
            )
        }
        return targets
    }

    private fun round1(value: Double): Double = round(value * 10.0) / 10.0

    private fun formatKm(value: Double): String = if (value % 1.0 == 0.0) value.toInt().toString() else String.format(java.util.Locale.US, "%.1f", value)
}
