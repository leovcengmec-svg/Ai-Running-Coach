package com.airunningcoach.app

/**
 * Comparação única do volume semanal prescrito.
 * A meta semanal da interface é comparada ao total de treinos mais provas válidas,
 * e não somente às sessões de treinamento.
 */
enum class WeeklyVolumeStatus {
    BELOW_TARGET,
    ALIGNED,
    ABOVE_TARGET,
    NO_TARGET
}

data class WeeklyVolumeSummary(
    val trainingKm: Double,
    val raceKm: Double,
    val totalKm: Double,
    val targetKm: Double?,
    val differenceKm: Double?,
    val status: WeeklyVolumeStatus
) {
    val shortfallKm: Double
        get() = if (status == WeeklyVolumeStatus.BELOW_TARGET) (differenceKm ?: 0.0).coerceAtLeast(0.0) else 0.0

    val excessKm: Double
        get() = if (status == WeeklyVolumeStatus.ABOVE_TARGET) (-(differenceKm ?: 0.0)).coerceAtLeast(0.0) else 0.0

    companion object {
        fun calculate(
            trainingKm: Double,
            raceKm: Double,
            targetKm: Double?,
            alignmentToleranceKm: Double = 0.15
        ): WeeklyVolumeSummary {
            val safeTrainingKm = trainingKm.takeIf { it.isFinite() }?.coerceAtLeast(0.0) ?: 0.0
            val safeRaceKm = raceKm.takeIf { it.isFinite() }?.coerceAtLeast(0.0) ?: 0.0
            val safeTargetKm = targetKm?.takeIf { it.isFinite() }?.coerceAtLeast(0.0)
            val total = safeTrainingKm + safeRaceKm
            val delta = safeTargetKm?.minus(total)
            val tolerance = alignmentToleranceKm.takeIf { it.isFinite() }?.coerceAtLeast(0.0) ?: 0.15
            val status = when {
                delta == null -> WeeklyVolumeStatus.NO_TARGET
                kotlin.math.abs(delta) <= tolerance -> WeeklyVolumeStatus.ALIGNED
                delta > 0.0 -> WeeklyVolumeStatus.BELOW_TARGET
                else -> WeeklyVolumeStatus.ABOVE_TARGET
            }
            return WeeklyVolumeSummary(
                trainingKm = safeTrainingKm,
                raceKm = safeRaceKm,
                totalKm = total,
                targetKm = safeTargetKm,
                differenceKm = delta,
                status = status
            )
        }
    }
}
