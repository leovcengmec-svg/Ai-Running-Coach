package com.airunningcoach.app

import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.roundToInt

/** Converts the event-specific race strategy into the same structured workout contract used by training sessions. */
internal object RaceStrategyWorkoutExporter {
    fun build(
        event: RaceEvent,
        strategy: RaceStrategy,
        zones: TrainingPaceZones?
    ): PrescribedWorkout {
        require(strategy.eventId == event.id) { "A estratégia não corresponde à competição selecionada." }
        require(strategy.phases.isNotEmpty()) { "A estratégia não contém etapas exportáveis." }

        val racePhases = strategy.phases.map { phase ->
            val hasPace = phase.fastestPaceSecondsPerKm != null && phase.slowestPaceSecondsPerKm != null &&
                phase.fastestPaceSecondsPerKm in 120..1800 && phase.slowestPaceSecondsPerKm >= phase.fastestPaceSecondsPerKm
            WorkoutSegment(
                name = phase.title,
                instruction = "${phase.rationale} Trecho da prova: ${formatDistance(phase.distanceKm)} km.",
                distanceKm = phase.distanceKm,
                intensity = when (phase.zone) {
                    "Z4", "Z5" -> "HIGH"
                    "Z3", "ALVO" -> "MODERATE"
                    else -> "LOW"
                },
                rpeRange = when (phase.zone) {
                    "Z5" -> "7-8"
                    "Z4" -> "6-7"
                    "Z3" -> "4-6"
                    "ALVO" -> "3-5"
                    else -> "2-4"
                },
                targetMode = "DISTANCE",
                targetPaceMinValue = if (hasPace) phase.fastestPaceSecondsPerKm else null,
                targetPaceMaxValue = if (hasPace) phase.slowestPaceSecondsPerKm else null,
                paceZone = phase.zone.takeIf { it in setOf("Z1", "Z2", "Z3", "Z4", "Z5") }
            )
        }

        val day = event.dateOrNull()?.dayOfWeek?.getDisplayName(TextStyle.FULL, Locale.forLanguageTag("pt-BR"))
            ?.replaceFirstChar { it.uppercase(Locale.forLanguageTag("pt-BR")) }.orEmpty()
        val dateLabel = event.dateOrNull()?.let { RaceEventEngine.formatBrazilianDate(it.toString()) }.orEmpty()
        val raceSeconds = if (strategy.estimatedTimeMinSeconds != null && strategy.estimatedTimeMaxSeconds != null) {
            ((strategy.estimatedTimeMinSeconds + strategy.estimatedTimeMaxSeconds) / 2.0).roundToInt()
        } else PaceDuration.parse(event.targetTime)
        val totalDuration = raceSeconds?.let { (it / 60.0).roundToInt() } ?: 0
        val segments = racePhases
        val exportedDistance = racePhases.sumOf { it.distanceKm ?: 0.0 }
        require(kotlin.math.abs(exportedDistance - event.distanceKm) <= 0.02) {
            "A soma das etapas competitivas precisa corresponder à distância oficial da prova."
        }
        require(racePhases.all { (it.distanceKm ?: 0.0) > 0.0 }) {
            "A exportação competitiva aceita somente etapas por distância."
        }
        return PrescribedWorkout(
            day = day,
            date = if (day.isBlank()) dateLabel else "$day, $dateLabel",
            scheduledDateIso = event.eventDateIso,
            title = "Estratégia de prova — ${event.name}",
            type = "Competição",
            objective = "Executar a prova por etapas, respeitando o ritmo e as zonas validadas no histórico de treinamento.",
            stimulus = "RACE_STRATEGY:${event.priority}",
            sessionId = "RACE-${event.id}",
            distanceKm = event.distanceKm,
            durationMin = totalDuration,
            intensity = if (event.priority == "A") "MODERATE" else "LOW",
            paceMode = "RACE_PHASES",
            rpeRange = "2-7",
            detail = segments.joinToString("\n") { "${it.name}: ${it.instruction}" },
            rationale = "Prioridade ${event.priority} (${event.priorityLabel()}). ${strategy.targetAssessment} ${strategy.readinessNote}",
            week = 1,
            phase = "RACE",
            segments = segments
        )
    }

    fun exportName(event: RaceEvent): String = WorkoutExportNaming.safeFileBaseName("Prova_${event.name}_Estrategia")

    private fun formatDistance(distanceKm: Double): String =
        String.format(Locale.forLanguageTag("pt-BR"), "%.2f", distanceKm).trimEnd('0').trimEnd(',').ifBlank { "0" }
}
