package com.airunningcoach.app

import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.roundToInt

/** Converts the event-specific race strategy into the same structured workout contract used by training sessions. */
internal object RaceStrategyWorkoutExporter {
    fun build(
        event: RaceEvent,
        strategy: RaceStrategy,
        zones: TrainingPaceZones?
    ): PrescribedWorkout {
        require(strategy.eventId == event.id) { "A estratégia não corresponde à competição selecionada." }
        require(strategy.phases.isNotEmpty()) { "A estratégia não contém etapas exportáveis." }

        val z1 = zones?.z1?.range
        val warmupBand = ZoneIntensityBandEngine.z1WarmupCoolDownBand
        val warmupRange = z1?.let { ZoneIntensityBandEngine.activeRange(it, warmupBand) }
        val warmup = WorkoutSegment(
            name = "Aquecimento pré-prova",
            instruction = "Faça 10 minutos leves e progressivos. Termine com a respiração controlada; não transforme o aquecimento em parte competitiva da prova.",
            durationMin = 10,
            intensity = "LOW",
            rpeRange = "2-3",
            targetMode = "TIME",
            targetPaceMinValue = warmupRange?.fastestPaceValue,
            targetPaceMaxValue = warmupRange?.slowestPaceValue,
            paceZone = warmupRange?.let { "Z1" },
            zoneBasePaceFastValue = z1?.fastestPaceValue,
            zoneBasePaceSlowValue = z1?.slowestPaceValue,
            zoneIntensityMinPercent = warmupRange?.let { warmupBand.minPercent },
            zoneIntensityMaxPercent = warmupRange?.let { warmupBand.maxPercent }
        )

        val racePhases = strategy.phases.map { phase ->
            val hasPace = phase.fastestPaceSecondsPerKm != null && phase.slowestPaceSecondsPerKm != null &&
                phase.fastestPaceSecondsPerKm in 120..1800 && phase.slowestPaceSecondsPerKm >= phase.fastestPaceSecondsPerKm
            WorkoutSegment(
                name = phase.title,
                instruction = "${phase.rationale} Trecho da prova: ${formatDistance(phase.distanceKm)} km.",
                distanceKm = phase.distanceKm,
                intensity = when (phase.zone) {
                    "Z4", "Z5" -> "HIGH"
                    "Z3" -> "MODERATE"
                    else -> "LOW"
                },
                rpeRange = when (phase.zone) {
                    "Z5" -> "7-8"
                    "Z4" -> "6-7"
                    "Z3" -> "4-6"
                    else -> "2-4"
                },
                targetMode = "DISTANCE",
                targetPaceMinValue = if (hasPace) phase.fastestPaceSecondsPerKm else null,
                targetPaceMaxValue = if (hasPace) phase.slowestPaceSecondsPerKm else null,
                paceZone = phase.zone.takeIf { it in setOf("Z1", "Z2", "Z3", "Z4", "Z5") }
            )
        }

        val cooldown = WorkoutSegment(
            name = "Desaquecimento pós-prova",
            instruction = "Caminhe alguns minutos e finalize com trote leve somente se estiver confortável. Não há meta competitiva nesta etapa.",
            durationMin = 5,
            intensity = "LOW",
            rpeRange = "1-2",
            targetMode = "TIME"
        )

        val day = event.dateOrNull()?.dayOfWeek?.getDisplayName(TextStyle.FULL, Locale.forLanguageTag("pt-BR"))
            ?.replaceFirstChar { it.uppercase(Locale.forLanguageTag("pt-BR")) }.orEmpty()
        val dateLabel = event.dateOrNull()?.let { RaceEventEngine.formatBrazilianDate(it.toString()) }.orEmpty()
        val raceSeconds = if (strategy.estimatedTimeMinSeconds != null && strategy.estimatedTimeMaxSeconds != null) {
            ((strategy.estimatedTimeMinSeconds + strategy.estimatedTimeMaxSeconds) / 2.0).roundToInt()
        } else PaceDuration.parse(event.targetTime)
        val totalDuration = raceSeconds?.let { (it / 60.0).roundToInt() + 15 } ?: 15
        val segments = listOf(warmup) + racePhases + cooldown
        return PrescribedWorkout(
            day = day,
            date = if (day.isBlank()) dateLabel else "$day, $dateLabel",
            scheduledDateIso = event.eventDateIso,
            title = "Estratégia de prova — ${event.name}",
            type = "Competição",
            objective = "Executar a prova por etapas, respeitando o ritmo e as zonas validadas no histórico de treinamento.",
            stimulus = "RACE_STRATEGY:${event.priority}",
            sessionId = "RACE-${event.id}",
            distanceKm = event.distanceKm,
            durationMin = totalDuration,
            intensity = if (event.priority == "A") "MODERATE" else "LOW",
            paceMode = "RACE_PHASES",
            rpeRange = "2-7",
            detail = segments.joinToString("\n") { "${it.name}: ${it.instruction}" },
            rationale = "Prioridade ${event.priority} (${event.priorityLabel()}). ${strategy.targetAssessment} ${strategy.readinessNote}",
            week = 1,
            phase = "RACE",
            segments = segments
        )
    }

    fun exportName(event: RaceEvent): String = WorkoutExportNaming.safeFileBaseName("Prova_${event.name}_Estrategia")

    private fun formatDistance(distanceKm: Double): String =
        String.format(Locale.forLanguageTag("pt-BR"), "%.2f", distanceKm).trimEnd('0').trimEnd(',').ifBlank { "0" }
}
