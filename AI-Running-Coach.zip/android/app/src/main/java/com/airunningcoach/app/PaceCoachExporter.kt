package com.airunningcoach.app

import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.round
import kotlin.math.roundToLong

/**
 * Exporta no mesmo envelope legado UserWorkoutJson que o Pace Coach gera ao exportar
 * seus próprios treinos. Não usar o contrato interno pace-coach-workout: o receptor
 * do Pace Coach procura explicitamente a chave Garmin UserWorkoutJson.
 */
internal object PaceCoachExporter {
    const val USER_WORKOUT_JSON_KEY = "com.garmin.connect.workout.json.UserWorkoutJson"

    private const val END_CONDITION_ID = 1
    private const val UNIT_DIMENSIONLESS_PK = 6
    private const val UNIT_MILLISECONDS_PK = 41
    private const val UNIT_METERS_PK = 1
    private const val TARGET_PACE_UNIT_PK = 7

    fun workoutToJson(
        workout: PrescribedWorkout,
        @Suppress("UNUSED_PARAMETER") athleteGoal: String,
        @Suppress("UNUSED_PARAMETER") athleteGoalKm: Double?,
        exportName: String? = null
    ): String {
        val auditErrors = TrainingPrescriptionAudit.validateExportStructure(workout.segments, workout.stimulus)
        require(auditErrors.isEmpty()) { "A prescrição não pode ser exportada: ${auditErrors.joinToString("; ")}" }
        val protocolCode = workout.stimulus.substringAfterLast(':').takeIf { TrainingProtocolCatalog.find(it) != null }
        if (protocolCode != null) {
            // Structural validation is based on the protocol code and executable blocks.
            // The visible title is intentionally excluded because localized punctuation or
            // a user-friendly label must not make an otherwise valid session unexportable.
            val protocolErrors = TrainingProtocolCatalog.validateNamedProtocol(protocolCode, workout.segments)
            require(protocolErrors.isEmpty()) { protocolErrors.joinToString("; ") }
        }
        val now = gmtTimestamp()
        val workoutId = nextLegacyId()
        val stepRows = buildWorkoutSteps(workout.segments, workoutId)
        val expectedExecutableSteps = workout.segments.sumOf { it.repeatCount }
        require(stepRows.size == expectedExecutableSteps) { "A exportação não contém uma etapa individual para cada bloco executável." }
        require(stepRows.isNotEmpty()) { "A prescrição não contém etapas exportáveis." }

        val userWorkout = JSONObject().apply {
            put("workoutId", workoutId)
            val stableName = WorkoutExportNaming.normalizeForExport(workout, exportName)
            put("workoutName", WorkoutExportNaming.safeFileBaseName(stableName).take(120))
            put("createdDate", now)
            put("updatedDate", now)
            // O arquivo é uma cópia independente; ownerId=0 evita atribuir o treino
            // ao identificador de conta de outra pessoa presente em arquivos de exemplo.
            put("ownerId", 0)
            put("sportTypeKey", "running")
            put("workoutSteps", JSONArray().apply { stepRows.forEach { put(it) } })
        }

        // Este wrapper é obrigatório: o receptor procura UserWorkoutJson nesta chave.
        return JSONObject().put(USER_WORKOUT_JSON_KEY, userWorkout).toString(2)
    }

    private fun buildWorkoutSteps(segments: List<WorkoutSegment>, workoutId: Long): List<JSONObject> {
        val result = mutableListOf<JSONObject>()
        var index = 0
        var stepOrder = 1
        var nextGroupId = 1

        fun addStep(segment: WorkoutSegment, parentGroupId: Int? = null) {
            val groupId = nextGroupId++
            val row = segmentToStep(segment, workoutId + stepOrder, stepOrder, groupId, parentGroupId)
            result += row
            stepOrder++
        }

        while (index < segments.size) {
            val segment = segments[index]
            if (segment.repeatCount <= 1) {
                addStep(segment)
                index++
                continue
            }

            // The Pace Coach must receive each execution and recovery as its own step.
            // Expand legacy repeatCount groups instead of hiding them in a compact repeat block.
            val repeatCount = segment.repeatCount
            val groupSegments = mutableListOf<WorkoutSegment>()
            while (index < segments.size && segments[index].repeatCount == repeatCount && repeatCount > 1) {
                groupSegments += segments[index]
                index++
            }
            repeat(repeatCount) {
                groupSegments.forEach { repeated -> addStep(repeated.copy(repeatCount = 1)) }
            }
        }
        return result
    }

    private fun segmentToStep(
        segment: WorkoutSegment,
        stepId: Long,
        stepOrder: Int,
        groupId: Int,
        parentGroupId: Int?
    ): JSONObject {
        val kind = stepKind(segment)
        val hasAnyPace = segment.targetPaceMinValue != null || segment.targetPaceMaxValue != null
        require(!hasAnyPace || (segment.targetPaceMinValue != null && segment.targetPaceMaxValue != null)) {
            "A etapa '${segment.name}' possui apenas um limite de ritmo; a exportação foi bloqueada para não perder o alvo."
        }
        val hasPace = segment.targetPaceMinValue != null && segment.targetPaceMaxValue != null
        val isTime = segment.targetMode == "TIME"

        return JSONObject().apply {
            put("stepId", stepId)
            put("stepOrder", stepOrder)
            put("coachRhythm", 1)
            put("groupId", groupId)
            if (parentGroupId != null) put("parentGroupId", parentGroupId)
            put("endConditionId", END_CONDITION_ID)

            if (isTime) {
                val durationMillis = when {
                    segment.durationSeconds != null -> segment.durationSeconds * 1_000L
                    segment.durationMin != null -> segment.durationMin * 60_000L
                    else -> 0L
                }
                require(durationMillis > 0L) { "A etapa '${segment.name}' precisa ter duração maior que zero." }
                put("endConditionValue", durationMillis.toDouble())
                put("endConditionUnitPk", UNIT_MILLISECONDS_PK)
                put("endConditionTypeKey", "time")
                put("endConditionUnitKey", "ms")
                put("endConditionDisplayValue", formatDuration(durationMillis))
                put("endConditionDisplayUnit", "Hours:Minutes:Seconds")
                put("endConditionDisplayUnitAbbr", "h:m:s")
            } else {
                val distanceKm = requireNotNull(segment.distanceKm)
                require(distanceKm > 0.0 && distanceKm.isFinite()) {
                    "A etapa '${segment.name}' precisa ter distância válida maior que zero."
                }
                // Pace Coach lê endConditionValue como metros quando endConditionUnitKey=meter.
                // Não aplicar escala adicional: 1 km deve ser exatamente 1.000.
                val distanceMeters = (distanceKm * 1000.0).roundToLong()
                require(distanceMeters > 0L) { "A distância da etapa '${segment.name}' é pequena demais para exportar." }
                put("endConditionValue", distanceMeters.toDouble())
                put("endConditionUnitPk", UNIT_METERS_PK)
                put("endConditionTypeKey", "distance")
                put("endConditionUnitKey", "meter")
                put("endConditionDisplayValue", formatDistanceMeters(distanceMeters.toDouble()))
                put("endConditionDisplayUnit", "Meters")
                put("endConditionDisplayUnitAbbr", "m")
            }

            put("stepTypeKey", kind.stepTypeKey)
            put("intensityTypeKey", kind.intensityTypeKey)
            put("targetTypeKey", if (hasPace && kind.allowsPaceTarget) "pace.zone" else "no.target")

            if (hasPace && kind.allowsPaceTarget) {
                val fasterPaceSeconds = requireNotNull(segment.targetPaceMinValue).toDouble()
                val slowerPaceSeconds = requireNotNull(segment.targetPaceMaxValue).toDouble()
                // Garmin representa pace como velocidade em cm/ms. O primeiro valor
                // é o limite numérico inferior (pace mais lento), o segundo o superior.
                val slowerSpeed = round((100.0 / slowerPaceSeconds) * 1_000_000.0) / 1_000_000.0
                val fasterSpeed = round((100.0 / fasterPaceSeconds) * 1_000_000.0) / 1_000_000.0
                put("targetValueOne", slowerSpeed)
                put("targetOneDisplayValue", formatGarminPace(slowerPaceSeconds.toInt()))
                put("targetValueUnitPk", TARGET_PACE_UNIT_PK)
                put("targetValueTwo", fasterSpeed)
                put("targetTwoDisplayValue", formatGarminPace(fasterPaceSeconds.toInt()))
                put("targetValueDisplayUnit", "Minutes per Kilometer")
                put("targetValueDisplayUnitAbbr", "min/km")
                put("targetValueUnitKey", "centimetersPerMillisecond")
            } else {
                put("targetValueUnitPk", UNIT_DIMENSIONLESS_PK)
                put("targetValueUnitKey", "dimensionless")
            }
        }
    }

    private data class StepKind(
        val stepTypeKey: String,
        val intensityTypeKey: String,
        val allowsPaceTarget: Boolean
    )

    private fun stepKind(segment: WorkoutSegment): StepKind {
        val name = segment.name.lowercase(Locale.ROOT)
        return when {
            "desaquecimento" in name || "cooldown" in name || "volta à calma" in name ->
                StepKind("cooldown", "cooldown", true)
            "aquecimento" in name || "warm up" in name || "warmup" in name ->
                StepKind("warmup", "warmup", true)
            "recupera" in name || "caminhada" in name || "descanso" in name || "pausa" in name ->
                // Recuperação pode ser passiva (sem alvo) ou ativa (Z1/Z2 com pace).
                // O alvo só é exportado quando a própria prescrição contém os dois limites.
                StepKind("recovery", "rest", true)
            else -> StepKind("interval", "active", true)
        }
    }

    private fun formatDuration(durationMillis: Long): String {
        val totalSeconds = (durationMillis / 1000L).coerceAtLeast(0L)
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
    }

    private fun formatGarminPace(totalSeconds: Int): String {
        val safe = totalSeconds.coerceAtLeast(0)
        return String.format(Locale.US, "%02d:%02d", safe / 60, safe % 60)
    }

    private fun formatDistanceMeters(distanceMeters: Double): String =
        if (distanceMeters % 1.0 == 0.0) distanceMeters.toLong().toString()
        else String.format(Locale.US, "%.1f", distanceMeters)

    private fun gmtTimestamp(): String {
        val formatter = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S 'GMT'", Locale.US)
        formatter.timeZone = TimeZone.getTimeZone("GMT")
        return formatter.format(Date())
    }

    private fun nextLegacyId(): Long = 100_000_000L + (System.currentTimeMillis() % 900_000_000L)
}
