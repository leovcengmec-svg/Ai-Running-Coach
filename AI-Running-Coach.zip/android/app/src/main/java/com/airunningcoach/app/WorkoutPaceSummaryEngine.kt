package com.airunningcoach.app

/** Calculates planned average pace from the same distance/time model used by the session card. */
internal object WorkoutPaceSummaryEngine {
    fun plannedAveragePaceSecondsPerKm(segments: List<WorkoutSegment>): Int? =
        UnifiedPrescriptionCalculator.planned(segments).paceSecondsPerKm
}
