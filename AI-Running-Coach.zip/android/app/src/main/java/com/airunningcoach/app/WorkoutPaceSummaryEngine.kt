package com.airunningcoach.app

/** Calculates the planned average pace from every moving segment with a pace target. */
internal object WorkoutPaceSummaryEngine {
    fun plannedAveragePaceSecondsPerKm(segments: List<WorkoutSegment>): Int? {
        var totalDistanceKm = 0.0
        var totalMovingSeconds = 0.0
        segments.forEach { segment ->
            if (segment.recoveryMode == "PASSIVE") return@forEach
            val minPace = segment.targetPaceMinValue ?: return@forEach
            val maxPace = segment.targetPaceMaxValue ?: return@forEach
            val midpointPace = (minPace + maxPace) / 2.0
            val repeats = segment.repeatCount.coerceAtLeast(1)
            val distance = (segment.distanceKm?.takeIf { it > 0.0 }
                ?: segment.durationMin?.takeIf { it > 0 }?.let { it * 60.0 / midpointPace }
                ?: return@forEach) * repeats
            if (distance <= 0.0) return@forEach
            totalDistanceKm += distance
            totalMovingSeconds += distance * midpointPace
        }
        if (totalDistanceKm <= 0.0) return null
        return (totalMovingSeconds / totalDistanceKm).toInt().coerceAtLeast(1)
    }
}
