package com.airunningcoach.app

import kotlin.math.abs

/** Shared integrity checks used by unit tests and the prescription builder. */
internal object TrainingPrescriptionAudit {

    /** Structural gate called by PaceCoachExporter before producing a native workout file. */
    fun validateExportStructure(segments: List<WorkoutSegment>, stimulus: String): List<String> = buildList {
        if (segments.isEmpty()) add("A sessão não contém blocos executáveis.")
        segments.forEach { segment ->
            if (segment.targetMode == "TIME") {
                val seconds = segment.durationSeconds ?: segment.durationMin?.times(60)
                if (seconds == null || seconds <= 0) add("${segment.name}: duração executável ausente ou inválida.")
            } else if ((segment.distanceKm ?: 0.0) <= 0.0) {
                add("${segment.name}: distância executável ausente ou inválida.")
            }
            if ((segment.targetPaceMinValue == null) != (segment.targetPaceMaxValue == null)) {
                add("${segment.name}: faixa de ritmo incompleta.")
            }
        }
        val code = stimulus.substringAfterLast(':').substringAfterLast('_')
        if (code == "EASY_WITH_STRIDES_Z2_Z5" || stimulus.contains("STRIDES", ignoreCase = true)) {
            val accelerations = segments.filter { it.name.startsWith("Aceleração ", true) }
            val recoveries = segments.filter { it.name.startsWith("Recuperação ", true) }
            if (segments.size != 8) add("Rodagem com acelerações deve conter exatamente 8 blocos; encontrados ${segments.size}.")
            if (accelerations.size != 3 || recoveries.size != 2) add("Rodagem com acelerações exige 3 acelerações e 2 recuperações individuais.")
            if (accelerations.any { it.durationSeconds !in 10..15 || it.repeatCount != 1 }) add("Cada aceleração deve ter 10–15 segundos e ser um bloco individual.")
            if (recoveries.any { it.durationSeconds !in 60..90 || it.repeatCount != 1 || it.recoveryMode != "WALK" }) add("Cada recuperação deve ter 60–90 segundos, caminhada/trote muito leve e ser individual.")
            if (segments.indexOfFirst { it.name.startsWith("Aceleração 1", true) } != 2 ||
                segments.indexOfFirst { it.name.startsWith("Recuperação 1", true) } != 3 ||
                segments.indexOfFirst { it.name.startsWith("Aceleração 2", true) } != 4 ||
                segments.indexOfFirst { it.name.startsWith("Recuperação 2", true) } != 5 ||
                segments.indexOfFirst { it.name.startsWith("Aceleração 3", true) } != 6) {
                add("A sequência das acelerações e recuperações está incorreta.")
            }
        }
    }

    fun estimatedSegmentDistanceKm(segments: List<WorkoutSegment>): Double =
        segments.sumOf { (it.distanceKm ?: 0.0) * it.repeatCount }

    fun validate(workout: PrescribedWorkout, toleranceKm: Double = 0.11): List<String> = buildList {
        if (workout.segments.isEmpty()) add("A sessão não possui segmentos.")
        val estimated = estimatedSegmentDistanceKm(workout.segments)
        if (estimated <= 0.0) add("A estrutura não possui distâncias ou estimativas de distância.")
        if (abs(estimated - workout.distanceKm) > toleranceKm) {
            add("A soma dos segmentos (${format(estimated)} km) difere da distância da sessão (${format(workout.distanceKm)} km).")
        }
        workout.segments.forEach { segment ->
            val minPace = segment.targetPaceMinValue
            val maxPace = segment.targetPaceMaxValue
            if ((minPace == null) != (maxPace == null)) add("${segment.name}: faixa de pace incompleta.")
            if (minPace != null && maxPace != null && maxPace < minPace) add("${segment.name}: faixa de pace invertida.")
            val baseFast = segment.zoneBasePaceFastValue
            val baseSlow = segment.zoneBasePaceSlowValue
            if (minPace != null && maxPace != null && baseFast != null && baseSlow != null) {
                if (minPace < baseFast || maxPace > baseSlow) add("${segment.name}: pace ativo ultrapassa os limites de ${segment.paceZone}.")
            }
            if (segment.paceZone != null && segment.paceZone !in setOf("Z1", "Z2", "Z3", "Z4", "Z5")) {
                add("${segment.name}: zona desconhecida ${segment.paceZone}.")
            }
            val namedZones = Regex("\\bZ[1-5]\\b").findAll(segment.name.uppercase())
                .map { it.value }.distinct().toList()
            if (namedZones.isNotEmpty() && (segment.paceZone == null || segment.paceZone.uppercase() !in namedZones)) {
                add("${segment.name}: nome e zona prescrita (${segment.paceZone ?: "sem zona"}) não correspondem.")
            }
            val bandMin = segment.zoneIntensityMinPercent
            val bandMax = segment.zoneIntensityMaxPercent
            if (minPace != null && maxPace != null && baseFast != null && baseSlow != null &&
                bandMin != null && bandMax != null && bandMin < bandMax) {
                val expected = ZoneIntensityBandEngine.activeRange(
                    PaceRange(baseFast, baseSlow), ActiveZoneBand(bandMin, bandMax)
                )
                if (abs(minPace - expected.fastestPaceValue) > 1 || abs(maxPace - expected.slowestPaceValue) > 1) {
                    add("${segment.name}: pace apresentado não corresponde à faixa ativa de ${segment.paceZone} (${bandMin}–${bandMax}%).")
                }
            }
            if (segment.name.contains("recuper", ignoreCase = true) && segment.paceZone in setOf("Z3", "Z4", "Z5")) {
                add("${segment.name}: recuperação não pode usar ${segment.paceZone} sem uma justificativa específica.")
            }
        }

        // Explicit quality protocols must separate the easy warm-up from the Z2
        // preparation transition; the two blocks cannot carry an identical pace band.
        val preparation = workout.segments.firstOrNull {
            it.name.contains("prepara", true) && it.paceZone?.equals("Z2", ignoreCase = true) == true
        }
        if (preparation != null) {
            val warmup = workout.segments.firstOrNull { it.name.contains("aquec", true) || it.name.contains("warmup", true) }
            if (preparation.zoneIntensityMinPercent != 20 || preparation.zoneIntensityMaxPercent != 40) {
                add("${workout.title}: preparação em Z2 deve usar a faixa de transição 20–40%.")
            }
            if (warmup != null && warmup.paceZone == preparation.paceZone &&
                warmup.zoneIntensityMinPercent == preparation.zoneIntensityMinPercent &&
                warmup.zoneIntensityMaxPercent == preparation.zoneIntensityMaxPercent) {
                add("${workout.title}: preparação repete a faixa de pace do aquecimento.")
            }
        }

        if (workout.stimulus.contains("FARTLEK", ignoreCase = true)) {
            workout.segments.forEachIndexed { index, segment ->
                if (segment.recoveryMode == "ACTIVE_Z2" || segment.name.contains("recuperação ativa Z2", true)) {
                    if (segment.paceZone != "Z2" || segment.zoneIntensityMinPercent != 0 || segment.zoneIntensityMaxPercent != 20) {
                        add("${segment.name}: recuperação Fartlek ativa Z2 deve usar 0–20% da Z2.")
                    }
                    val previous = workout.segments.getOrNull(index - 1)
                    if (previous?.paceZone == "Z2" && previous.zoneIntensityMinPercent == segment.zoneIntensityMinPercent &&
                        previous.zoneIntensityMaxPercent == segment.zoneIntensityMaxPercent) {
                        add("${segment.name}: recuperação repete a mesma faixa ativa do esforço Z2 anterior.")
                    }
                }
            }
        }

        val stimulus = workout.stimulus.uppercase()
        if (stimulus.contains("RECOVERY_Z2_CONSERVATIVE")) {
            val warm = workout.segments.firstOrNull { it.name.contains("aquec", true) }
            val main = workout.segments.firstOrNull { it.name.contains("regenerativo", true) }
            val cool = workout.segments.lastOrNull { it.name.contains("desaquec", true) }
            if (warm?.paceZone != "Z2" || warm.zoneIntensityMinPercent != 0 || warm.zoneIntensityMaxPercent != 20) add("Regenerativo conservador: aquecimento deve usar Z2 0–20%.")
            if (main?.paceZone != "Z2" || main.zoneIntensityMinPercent != 20 || main.zoneIntensityMaxPercent != 35) add("Regenerativo conservador: bloco principal deve usar Z2 20–35%.")
            if (cool?.paceZone != "Z2" || cool.zoneIntensityMinPercent != 0 || cool.zoneIntensityMaxPercent != 20) add("Regenerativo conservador: desaquecimento deve usar Z2 0–20%.")
        }

        if (stimulus.contains("RECOVERY_Z2_EXPERIENCED")) {
            val warm = workout.segments.firstOrNull { it.name.contains("aquec", true) }
            val main = workout.segments.firstOrNull { it.name.contains("regenerativo", true) }
            val cool = workout.segments.lastOrNull { it.name.contains("desaquec", true) }
            if (warm?.paceZone != "Z2" || warm.zoneIntensityMinPercent != 0 || warm.zoneIntensityMaxPercent != 20) add("Regenerativo experiente: aquecimento deve usar Z2 0–20%.")
            if (main?.paceZone != "Z2" || main.zoneIntensityMinPercent != 20 || main.zoneIntensityMaxPercent != 50) add("Regenerativo experiente: bloco principal deve usar Z2 20–50%.")
            if (cool?.paceZone != "Z2" || cool.zoneIntensityMinPercent != 0 || cool.zoneIntensityMaxPercent != 20) add("Regenerativo experiente: desaquecimento deve usar Z2 0–20%.")
        }
        if (stimulus.startsWith("BEGINNER_RUN_WALK") && workout.phase.equals("RECOVERY", ignoreCase = true)) {
            val running = workout.segments.filter { it.name.contains("corrida", true) && it.paceZone != null }
            if (running.isEmpty() || running.any { it.paceZone != "Z1" }) {
                add("Regenerativo iniciante: os blocos de corrida devem permanecer em Z1 dentro do protocolo caminhada/corrida.")
            }
            val walking = workout.segments.filter { it.name.contains("caminhada", true) }
            if (walking.any { it.paceZone != null || it.targetPaceMinValue != null || it.targetPaceMaxValue != null }) {
                add("Regenerativo iniciante: os blocos de caminhada não devem receber pace de corrida.")
            }
        }
        val isProgressive = stimulus.contains("PROGRESSIVE") || stimulus.contains("PROGRESSION_RUN")
        val isRegressive = stimulus.contains("REGRESSIVE")
        if (isProgressive || isRegressive) {
            val warmup = workout.segments.firstOrNull { it.name.contains("aquec", true) || it.name.contains("warmup", true) }
            val main = workout.segments.filter { segment ->
                val name = segment.name.lowercase()
                segment.paceZone in setOf("Z2", "Z3") &&
                    !name.contains("aquec") && !name.contains("warmup") &&
                    !name.contains("desaquec") && !name.contains("cooldown") &&
                    !name.contains("recuper") && !name.contains("recovery")
            }
            val firstMain = main.firstOrNull()
            if (warmup?.paceZone == "Z2" && firstMain?.paceZone == "Z2" &&
                warmup.zoneIntensityMinPercent == firstMain.zoneIntensityMinPercent &&
                warmup.zoneIntensityMaxPercent == firstMain.zoneIntensityMaxPercent) {
                add("${workout.title}: o primeiro bloco principal repete a faixa Z2 do aquecimento.")
            }
            main.zipWithNext().forEach { (left, right) ->
                if (left.paceZone == right.paceZone && left.paceZone == "Z2") {
                    val leftMin = left.zoneIntensityMinPercent
                    val leftMax = left.zoneIntensityMaxPercent
                    val rightMin = right.zoneIntensityMinPercent
                    val rightMax = right.zoneIntensityMaxPercent
                    if (leftMin != null && leftMax != null && rightMin != null && rightMax != null) {
                        val ordered = if (isProgressive) rightMin > leftMin && rightMax > leftMax
                            else rightMin < leftMin && rightMax < leftMax
                        if (!ordered) add("${workout.title}: faixas Z2 principais não seguem a ordem ${if (isProgressive) "progressiva" else "regressiva"}.")
                    }
                }
            }
        }
    }

    /** Reconciles rounding drift on the final distance-bearing segment without changing its zone or pace. */
    fun reconcileSegments(segments: List<WorkoutSegment>, targetKm: Double): List<WorkoutSegment> {
        if (segments.isEmpty()) return segments
        val current = estimatedSegmentDistanceKm(segments)
        val diff = kotlin.math.round((targetKm - current) * 10.0) / 10.0
        if (kotlin.math.abs(diff) < 0.05) return segments
        val index = segments.indexOfLast { it.distanceKm != null }
        if (index < 0) return segments
        val segment = segments[index]
        val repeatCount = segment.repeatCount.coerceAtLeast(1)
        val adjusted = kotlin.math.round(((segment.distanceKm ?: 0.0) + diff / repeatCount) * 100.0) / 100.0
        if (adjusted < 0.05) return segments
        return segments.toMutableList().also { list -> list[index] = segment.copy(distanceKm = adjusted) }
    }

    private fun format(value: Double): String = String.format(java.util.Locale.US, "%.2f", value)
}
