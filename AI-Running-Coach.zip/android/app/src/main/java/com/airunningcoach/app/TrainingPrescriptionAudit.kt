package com.airunningcoach.app

import kotlin.math.abs

/** Shared integrity checks used by unit tests and the prescription builder. */
internal object TrainingPrescriptionAudit {
    fun estimatedSegmentDistanceKm(segments: List<WorkoutSegment>): Double =
        segments.sumOf { (it.distanceKm ?: 0.0) * it.repeatCount }

    fun validate(workout: PrescribedWorkout, toleranceKm: Double = 0.11): List<String> = buildList {
        if (workout.segments.isEmpty()) add("A sessão não possui segmentos.")
        val estimated = estimatedSegmentDistanceKm(workout.segments)
        if (estimated <= 0.0) add("A estrutura não possui distâncias ou estimativas de distância.")
        if (abs(estimated - workout.distanceKm) > toleranceKm) {
            add("A soma dos segmentos (${format(estimated)} km) difere da distância da sessão (${format(workout.distanceKm)} km).")
        }
        workout.segments.forEach { segment ->
            val minPace = segment.targetPaceMinValue
            val maxPace = segment.targetPaceMaxValue
            if ((minPace == null) != (maxPace == null)) add("${segment.name}: faixa de pace incompleta.")
            if (minPace != null && maxPace != null && maxPace < minPace) add("${segment.name}: faixa de pace invertida.")
            val baseFast = segment.zoneBasePaceFastValue
            val baseSlow = segment.zoneBasePaceSlowValue
            if (minPace != null && maxPace != null && baseFast != null && baseSlow != null) {
                if (minPace < baseFast || maxPace > baseSlow) add("${segment.name}: pace ativo ultrapassa os limites de ${segment.paceZone}.")
            }
            if (segment.paceZone != null && segment.paceZone !in setOf("Z1", "Z2", "Z3", "Z4", "Z5")) {
                add("${segment.name}: zona desconhecida ${segment.paceZone}.")
            }
            val namedZones = Regex("\\bZ[1-5]\\b").findAll(segment.name.uppercase())
                .map { it.value }.distinct().toList()
            if (namedZones.isNotEmpty() && (segment.paceZone == null || segment.paceZone.uppercase() !in namedZones)) {
                add("${segment.name}: nome e zona prescrita (${segment.paceZone ?: "sem zona"}) não correspondem.")
            }
            val bandMin = segment.zoneIntensityMinPercent
            val bandMax = segment.zoneIntensityMaxPercent
            if (minPace != null && maxPace != null && baseFast != null && baseSlow != null &&
                bandMin != null && bandMax != null && bandMin < bandMax) {
                val expected = ZoneIntensityBandEngine.activeRange(
                    PaceRange(baseFast, baseSlow), ActiveZoneBand(bandMin, bandMax)
                )
                if (abs(minPace - expected.fastestPaceValue) > 1 || abs(maxPace - expected.slowestPaceValue) > 1) {
                    add("${segment.name}: pace apresentado não corresponde à faixa ativa de ${segment.paceZone} (${bandMin}–${bandMax}%).")
                }
            }
            if (segment.name.contains("recuper", ignoreCase = true) && segment.paceZone in setOf("Z3", "Z4", "Z5")) {
                add("${segment.name}: recuperação não pode usar ${segment.paceZone} sem uma justificativa específica.")
            }
        }

        // Explicit quality protocols must separate the easy warm-up from the Z2
        // preparation transition; the two blocks cannot carry an identical pace band.
        val preparation = workout.segments.firstOrNull {
            it.name.contains("prepara", true) && it.paceZone?.equals("Z2", ignoreCase = true) == true
        }
        if (preparation != null) {
            val warmup = workout.segments.firstOrNull { it.name.contains("aquec", true) || it.name.contains("warmup", true) }
            if (preparation.zoneIntensityMinPercent != 20 || preparation.zoneIntensityMaxPercent != 40) {
                add("${workout.title}: preparação em Z2 deve usar a faixa de transição 20–40%.")
            }
            if (warmup != null && warmup.paceZone == preparation.paceZone &&
                warmup.zoneIntensityMinPercent == preparation.zoneIntensityMinPercent &&
                warmup.zoneIntensityMaxPercent == preparation.zoneIntensityMaxPercent) {
                add("${workout.title}: preparação repete a faixa de pace do aquecimento.")
            }
        }

        if (workout.stimulus.contains("FARTLEK", ignoreCase = true)) {
            workout.segments.forEachIndexed { index, segment ->
                if (segment.recoveryMode == "ACTIVE_Z2" || segment.name.contains("recuperação ativa Z2", true)) {
                    if (segment.paceZone != "Z2" || segment.zoneIntensityMinPercent != 0 || segment.zoneIntensityMaxPercent != 20) {
                        add("${segment.name}: recuperação Fartlek ativa Z2 deve usar 0–20% da Z2.")
                    }
                    val previous = workout.segments.getOrNull(index - 1)
                    if (previous?.paceZone == "Z2" && previous.zoneIntensityMinPercent == segment.zoneIntensityMinPercent &&
                        previous.zoneIntensityMaxPercent == segment.zoneIntensityMaxPercent) {
                        add("${segment.name}: recuperação repete a mesma faixa ativa do esforço Z2 anterior.")
                    }
                }
            }
        }

        val stimulus = workout.stimulus.uppercase()
        val isProgressive = stimulus.contains("PROGRESSIVE") || stimulus.contains("PROGRESSION_RUN")
        val isRegressive = stimulus.contains("REGRESSIVE")
        if (isProgressive || isRegressive) {
            val warmup = workout.segments.firstOrNull { it.name.contains("aquec", true) || it.name.contains("warmup", true) }
            val main = workout.segments.filter { segment ->
                val name = segment.name.lowercase()
                (name.contains("bloco") || name.contains("final progressivo") || name.contains("início moderado") || name.contains("inicio moderado")) &&
                    segment.paceZone in setOf("Z2", "Z3")
            }
            val firstMain = main.firstOrNull()
            if (warmup?.paceZone == "Z2" && firstMain?.paceZone == "Z2" &&
                warmup.zoneIntensityMinPercent == firstMain.zoneIntensityMinPercent &&
                warmup.zoneIntensityMaxPercent == firstMain.zoneIntensityMaxPercent) {
                add("${workout.title}: o primeiro bloco principal repete a faixa Z2 do aquecimento.")
            }
            main.zipWithNext().forEach { (left, right) ->
                if (left.paceZone == right.paceZone && left.paceZone == "Z2") {
                    val leftMin = left.zoneIntensityMinPercent
                    val leftMax = left.zoneIntensityMaxPercent
                    val rightMin = right.zoneIntensityMinPercent
                    val rightMax = right.zoneIntensityMaxPercent
                    if (leftMin != null && leftMax != null && rightMin != null && rightMax != null) {
                        val ordered = if (isProgressive) rightMin > leftMin && rightMax > leftMax
                            else rightMin < leftMin && rightMax < leftMax
                        if (!ordered) add("${workout.title}: faixas Z2 principais não seguem a ordem ${if (isProgressive) "progressiva" else "regressiva"}.")
                    }
                }
            }
        }
    }

    /** Reconciles rounding drift on the final distance-bearing segment without changing its zone or pace. */
    fun reconcileSegments(segments: List<WorkoutSegment>, targetKm: Double): List<WorkoutSegment> {
        if (segments.isEmpty()) return segments
        val current = estimatedSegmentDistanceKm(segments)
        val diff = kotlin.math.round((targetKm - current) * 10.0) / 10.0
        if (kotlin.math.abs(diff) < 0.05) return segments
        val index = segments.indexOfLast { it.distanceKm != null }
        if (index < 0) return segments
        val segment = segments[index]
        val repeatCount = segment.repeatCount.coerceAtLeast(1)
        val adjusted = kotlin.math.round(((segment.distanceKm ?: 0.0) + diff / repeatCount) * 100.0) / 100.0
        if (adjusted < 0.05) return segments
        return segments.toMutableList().also { list -> list[index] = segment.copy(distanceKm = adjusted) }
    }

    private fun format(value: Double): String = String.format(java.util.Locale.US, "%.2f", value)
}
