package com.airunningcoach.app

import kotlin.math.max
import kotlin.math.roundToInt

/** Performance comparison for one prescribed workout segment/repetition. */
internal data class ActivityBlockResult(
    val name: String,
    val repetition: Int,
    val targetZone: String?,
    val targetPaceRange: PaceRange?,
    val plannedDurationSeconds: Int?,
    val plannedDistanceMeters: Double?,
    val actualDurationSeconds: Int,
    val actualDistanceMeters: Double,
    val averagePaceSecondsPerKm: Int?,
    val timeInTargetZoneSeconds: Int,
    val averageHeartRateBpm: Int?,
    val averageCadenceSpm: Int?,
    val sampleCount: Int,
    val confidence: String,
    val status: String
)

/**
 * Aligns measured, time-stamped activity samples with the order/dose of the prescribed
 * segments. This is a best-fit reconstruction when the source file has no explicit lap
 * markers; it never fabricates HR/cadence and marks sparse evidence accordingly.
 */
internal object ActivityBlockAnalysisEngine {
    private data class PlannedBlock(
        val segment: WorkoutSegment,
        val repetition: Int,
        val plannedDurationSeconds: Int?,
        val plannedDistanceMeters: Double?
    )

    private data class TimedSample(
        val sample: ActivityPaceSegment,
        val startSeconds: Int,
        val startMeters: Double,
        val endSeconds: Int,
        val endMeters: Double
    ) {
        val midpointSeconds: Double get() = (startSeconds + endSeconds) / 2.0
        val midpointMeters: Double get() = (startMeters + endMeters) / 2.0
    }

    fun analyze(
        samples: List<ActivityPaceSegment>,
        prescribedSegments: List<WorkoutSegment>,
        zones: List<PaceZone>
    ): List<ActivityBlockResult> {
        if (samples.isEmpty() || prescribedSegments.isEmpty()) return emptyList()
        val normalizedSamples = normalizeSamples(samples)
        if (normalizedSamples.isEmpty()) return emptyList()
        val blocks = mutableListOf<PlannedBlock>()
        var index = 0
        while (index < prescribedSegments.size) {
            val first = prescribedSegments[index]
            val repetitions = first.repeatCount.coerceIn(1, 20)
            var groupEnd = index + 1
            if (repetitions > 1) {
                while (groupEnd < prescribedSegments.size && prescribedSegments[groupEnd].repeatCount == repetitions) groupEnd++
            }
            val group = prescribedSegments.subList(index, groupEnd)
            repeat(repetitions) { repetitionIndex ->
                group.forEach { segment ->
                    blocks += PlannedBlock(
                        segment = segment,
                        repetition = if (repetitions > 1) repetitionIndex + 1 else 1,
                        plannedDurationSeconds = segment.durationMin?.times(60),
                        plannedDistanceMeters = segment.distanceKm?.times(1000.0)
                    )
                }
            }
            index = groupEnd
        }

        var cursorSeconds = 0
        var cursorMeters = 0.0
        return blocks.map { block ->
            val selected = if (block.segment.targetMode == "TIME") {
                val duration = block.plannedDurationSeconds ?: 0
                val start = cursorSeconds
                val end = start + duration
                normalizedSamples.filter { it.midpointSeconds >= start && it.midpointSeconds < end }
                    .also { chosen ->
                        cursorSeconds = end
                        chosen.maxOfOrNull { it.endMeters }?.let { cursorMeters = max(cursorMeters, it) }
                    }
            } else {
                val distance = block.plannedDistanceMeters ?: 0.0
                val start = cursorMeters
                val end = start + distance
                normalizedSamples.filter { it.midpointMeters >= start && it.midpointMeters < end }
                    .also { chosen ->
                        cursorMeters = end
                        chosen.maxOfOrNull { it.endSeconds }?.let { cursorSeconds = max(cursorSeconds, it) }
                    }
            }
            buildResult(block, selected, zones)
        }
    }

    private fun normalizeSamples(samples: List<ActivityPaceSegment>): List<TimedSample> {
        var fallbackSeconds = 0
        var fallbackMeters = 0.0
        return samples.mapNotNull { sample ->
            if (sample.durationSeconds !in 1..120 || sample.paceSecondsPerKm !in 120..1800) return@mapNotNull null
            val startSeconds = sample.startElapsedSeconds?.coerceAtLeast(0) ?: fallbackSeconds
            val estimatedDistance = sample.distanceMeters?.takeIf { it.isFinite() && it > 0.0 }
                ?: sample.durationSeconds * 1000.0 / sample.paceSecondsPerKm
            val startMeters = sample.startDistanceMeters?.takeIf { it.isFinite() && it >= 0.0 } ?: fallbackMeters
            val endSeconds = startSeconds + sample.durationSeconds
            val endMeters = startMeters + estimatedDistance
            fallbackSeconds = max(fallbackSeconds, endSeconds)
            fallbackMeters = max(fallbackMeters, endMeters)
            TimedSample(sample, startSeconds, startMeters, endSeconds, endMeters)
        }.sortedBy { it.startSeconds }
    }

    private fun buildResult(
        block: PlannedBlock,
        selected: List<TimedSample>,
        zones: List<PaceZone>
    ): ActivityBlockResult {
        val segment = block.segment
        val actualSeconds = selected.sumOf { it.sample.durationSeconds }
        val actualMeters = selected.sumOf { it.sample.distanceMeters?.takeIf { d -> d.isFinite() && d > 0.0 }
            ?: it.sample.durationSeconds * 1000.0 / it.sample.paceSecondsPerKm }
        val averagePace = if (actualMeters > 0.0 && actualSeconds > 0) {
            (actualSeconds * 1000.0 / actualMeters).roundToInt()
        } else null
        val targetRange = if (segment.targetPaceMinValue != null && segment.targetPaceMaxValue != null) {
            PaceRange(segment.targetPaceMinValue, segment.targetPaceMaxValue)
        } else segment.paceZone?.let { id -> zones.firstOrNull { it.id == id }?.range }
        val targetZoneRange = segment.paceZone?.let { id -> zones.firstOrNull { it.id == id }?.range }
        val timeInZone = if (targetZoneRange != null) selected.filter { it.sample.paceSecondsPerKm in targetZoneRange.fastestPaceValue..targetZoneRange.slowestPaceValue }
            .sumOf { it.sample.durationSeconds } else 0
        val hrValues = selected.mapNotNull { it.sample.averageHeartRateBpm }.filter { it in 30..240 }
        val cadenceValues = selected.mapNotNull { it.sample.averageCadenceSpm }.filter { it in 30..300 }
        val targetCompliance = if (targetRange != null && selected.isNotEmpty()) {
            selected.count { it.sample.paceSecondsPerKm in targetRange.fastestPaceValue..targetRange.slowestPaceValue }.toDouble() / selected.size
        } else null
        val status = when {
            selected.isEmpty() -> "SEM_DADOS"
            targetCompliance == null -> "SEM_ALVO"
            targetCompliance >= 0.70 -> "DENTRO_DA_META"
            else -> "FORA_DA_META"
        }
        val hasTimeAndDistance = selected.all { it.sample.startElapsedSeconds != null && it.sample.startDistanceMeters != null && it.sample.distanceMeters != null }
        val confidence = when {
            selected.isEmpty() -> "Sem dados"
            selected.size < 3 -> "Baixa"
            hasTimeAndDistance -> "Boa"
            else -> "Estimativa"
        }
        return ActivityBlockResult(
            name = segment.name,
            repetition = block.repetition,
            targetZone = segment.paceZone,
            targetPaceRange = targetRange,
            plannedDurationSeconds = block.plannedDurationSeconds,
            plannedDistanceMeters = block.plannedDistanceMeters,
            actualDurationSeconds = actualSeconds,
            actualDistanceMeters = actualMeters,
            averagePaceSecondsPerKm = averagePace,
            timeInTargetZoneSeconds = timeInZone,
            averageHeartRateBpm = hrValues.takeIf { it.isNotEmpty() }?.average()?.roundToInt(),
            averageCadenceSpm = cadenceValues.takeIf { it.isNotEmpty() }?.average()?.roundToInt(),
            sampleCount = selected.size,
            confidence = confidence,
            status = status
        )
    }
}
