package com.airunningcoach.app

import kotlin.math.max
import kotlin.math.roundToInt

/** Performance comparison for one prescribed workout segment/repetition. */
internal data class ActivityBlockResult(
    val name: String,
    val repetition: Int,
    val targetZone: String?,
    val targetPaceRange: PaceRange?,
    val plannedDurationSeconds: Int?,
    val plannedDistanceMeters: Double?,
    val actualDurationSeconds: Int,
    val actualDistanceMeters: Double,
    val averagePaceSecondsPerKm: Int?,
    val timeInTargetZoneSeconds: Int,
    val averageCadenceSpm: Int?,
    val sampleCount: Int,
    val confidence: String,
    val status: String
)

/**
 * Aligns measured, time-stamped activity samples with the order/dose of the prescribed
 * segments. This is a best-fit reconstruction when the source file has no explicit lap
 * markers; heart rate is not part of the analysis, and sparse pace/cadence evidence is marked accordingly.
 */
internal object ActivityBlockAnalysisEngine {
    private data class PlannedBlock(
        val segment: WorkoutSegment,
        val repetition: Int,
        val plannedDurationSeconds: Int?,
        val plannedDistanceMeters: Double?
    )

    private data class TimedSample(
        val sample: ActivityPaceSegment,
        val startSeconds: Int,
        val startMeters: Double,
        val endSeconds: Int,
        val endMeters: Double
    ) {
        val midpointSeconds: Double get() = (startSeconds + endSeconds) / 2.0
        val midpointMeters: Double get() = (startMeters + endMeters) / 2.0
    }

    fun analyze(
        samples: List<ActivityPaceSegment>,
        prescribedSegments: List<WorkoutSegment>,
        zones: List<PaceZone>
    ): List<ActivityBlockResult> {
        if (samples.isEmpty() || prescribedSegments.isEmpty()) return emptyList()
        val normalizedSamples = normalizeSamples(samples)
        if (normalizedSamples.isEmpty()) return emptyList()
        val blocks = mutableListOf<PlannedBlock>()
        var index = 0
        while (index < prescribedSegments.size) {
            val first = prescribedSegments[index]
            val repetitions = first.repeatCount.coerceIn(1, 20)
            var groupEnd = index + 1
            if (repetitions > 1) {
                while (groupEnd < prescribedSegments.size && prescribedSegments[groupEnd].repeatCount == repetitions) groupEnd++
            }
            val group = prescribedSegments.subList(index, groupEnd)
            repeat(repetitions) { repetitionIndex ->
                group.forEach { segment ->
                    blocks += PlannedBlock(
                        segment = segment,
                        repetition = if (repetitions > 1) repetitionIndex + 1 else 1,
                        plannedDurationSeconds = segment.durationMin?.times(60),
                        plannedDistanceMeters = segment.distanceKm?.times(1000.0)
                    )
                }
            }
            index = groupEnd
        }

        // Device/file laps are the strongest available boundaries, but equal counts alone
        // do not prove that a watch lap represents a prescribed step. Align 1:1 only when
        // every lap dose also matches that step's time or distance within a bounded tolerance.
        val explicitLaps = normalizedSamples.filter { it.sample.sourceType == "EXPLICIT_LAP" }
        if (explicitLaps.isNotEmpty()) {
            val dosesMatch = explicitLaps.size == blocks.size && blocks.zip(explicitLaps).all { (block, sample) ->
                explicitLapMatchesDose(block, sample)
            }
            if (dosesMatch) {
                return blocks.zip(explicitLaps).map { (block, sample) ->
                    buildResult(block, listOf(sample), zones, exactLapAlignment = true)
                }
            }
            // Do not mix lap aggregates with GPS track samples or attach an arbitrary
            // number of laps to unrelated planned steps. When the lap count differs,
            // show an honest activity-level lap summary and leave block alignment unknown.
            val summarySegment = WorkoutSegment(
                name = "Resumo das ${explicitLaps.size} voltas do arquivo (sem alinhamento 1:1)",
                instruction = "O arquivo contém voltas registradas, mas a quantidade não corresponde à estrutura prescrita. O ritmo agregado é mostrado sem atribuir cada volta a um bloco específico.",
                distanceKm = 0.0,
                targetMode = "DISTANCE"
            )
            val summaryBlock = PlannedBlock(summarySegment, repetition = 1, plannedDurationSeconds = null, plannedDistanceMeters = null)
            return listOf(
                buildResult(summaryBlock, explicitLaps, zones, exactLapAlignment = false).copy(
                    confidence = "Voltas registradas • sem correspondência 1:1",
                    status = "SEM_ALVO"
                )
            )
        }
        // A sparse GPX with one or two intervals cannot support a meaningful block split.
        // The global distance/time remains available in the activity summary; do not turn
        // a single GPS pair into a false warm-up or interval result.
        if (normalizedSamples.size < 3 || normalizedSamples.sumOf { it.sample.durationSeconds } < 30) {
            return emptyList()
        }

        var cursorSeconds = 0
        var cursorMeters = 0.0
        return blocks.map { block ->
            val selected = if (block.segment.targetMode == "TIME") {
                val duration = block.plannedDurationSeconds ?: 0
                val start = cursorSeconds
                val end = start + duration
                normalizedSamples.filter { it.midpointSeconds >= start && it.midpointSeconds < end }
                    .also { chosen ->
                        cursorSeconds = end
                        chosen.maxOfOrNull { it.endMeters }?.let { cursorMeters = max(cursorMeters, it) }
                    }
            } else {
                val distance = block.plannedDistanceMeters ?: 0.0
                val start = cursorMeters
                val end = start + distance
                normalizedSamples.filter { it.midpointMeters >= start && it.midpointMeters < end }
                    .also { chosen ->
                        cursorMeters = end
                        chosen.maxOfOrNull { it.endSeconds }?.let { cursorSeconds = max(cursorSeconds, it) }
                    }
            }
            buildResult(block, selected, zones, exactLapAlignment = false)
        }
    }


    private fun explicitLapMatchesDose(block: PlannedBlock, sample: TimedSample): Boolean {
        val plannedDuration = block.plannedDurationSeconds
        val plannedDistance = block.plannedDistanceMeters
        return when {
            plannedDuration != null -> {
                val tolerance = max(30.0, plannedDuration * 0.25)
                kotlin.math.abs(sample.sample.durationSeconds - plannedDuration) <= tolerance
            }
            plannedDistance != null && plannedDistance > 0.0 -> {
                val actual = sample.sample.distanceMeters ?: return false
                val tolerance = max(50.0, plannedDistance * 0.20)
                kotlin.math.abs(actual - plannedDistance) <= tolerance
            }
            else -> false
        }
    }

    private fun normalizeSamples(samples: List<ActivityPaceSegment>): List<TimedSample> {
        var fallbackSeconds = 0
        var fallbackMeters = 0.0
        return samples.mapNotNull { sample ->
            val maxDuration = if (sample.sourceType == "EXPLICIT_LAP") 7_200 else 120
            if (sample.durationSeconds !in 1..maxDuration || sample.paceSecondsPerKm !in 120..1800) return@mapNotNull null
            val startSeconds = sample.startElapsedSeconds?.coerceAtLeast(0) ?: fallbackSeconds
            val estimatedDistance = sample.distanceMeters?.takeIf { it.isFinite() && it > 0.0 }
                ?: sample.durationSeconds * 1000.0 / sample.paceSecondsPerKm
            val startMeters = sample.startDistanceMeters?.takeIf { it.isFinite() && it >= 0.0 } ?: fallbackMeters
            val endSeconds = startSeconds + sample.durationSeconds
            val endMeters = startMeters + estimatedDistance
            fallbackSeconds = max(fallbackSeconds, endSeconds)
            fallbackMeters = max(fallbackMeters, endMeters)
            TimedSample(sample, startSeconds, startMeters, endSeconds, endMeters)
        }.sortedBy { it.startSeconds }
    }

    private fun buildResult(
        block: PlannedBlock,
        selected: List<TimedSample>,
        zones: List<PaceZone>,
        exactLapAlignment: Boolean
    ): ActivityBlockResult {
        val segment = block.segment
        val actualSeconds = selected.sumOf { it.sample.durationSeconds }
        val actualMeters = selected.sumOf { it.sample.distanceMeters?.takeIf { d -> d.isFinite() && d > 0.0 }
            ?: it.sample.durationSeconds * 1000.0 / it.sample.paceSecondsPerKm }
        val averagePace = if (actualMeters > 0.0 && actualSeconds > 0) {
            (actualSeconds * 1000.0 / actualMeters).roundToInt()
        } else null
        val targetRange = if (segment.targetPaceMinValue != null && segment.targetPaceMaxValue != null) {
            PaceRange(segment.targetPaceMinValue, segment.targetPaceMaxValue)
        } else segment.paceZone?.let { id -> zones.firstOrNull { it.id == id }?.range }
        val timeInZone = if (targetRange != null) selected.filter { it.sample.paceSecondsPerKm in targetRange.fastestPaceValue..targetRange.slowestPaceValue }
            .sumOf { it.sample.durationSeconds } else 0
        val cadenceValues = selected.mapNotNull { it.sample.averageCadenceSpm }.filter { it in 30..300 }
        // Direction matters. A faster average is not a generic failure: for a quality
        // interval it is faster than prescribed; for an easy Z1/Z2 block it may indicate
        // an intensity drift, which is reported distinctly instead of "outside target".
        val status = when {
            selected.isEmpty() -> "SEM_DADOS"
            targetRange == null -> "SEM_ALVO"
            averagePace == null -> "SEM_DADOS"
            averagePace in targetRange.fastestPaceValue..targetRange.slowestPaceValue -> "DENTRO_DA_META"
            averagePace < targetRange.fastestPaceValue && segment.paceZone in setOf("Z1", "Z2") -> "ACIMA_DA_INTENSIDADE"
            averagePace < targetRange.fastestPaceValue -> "MAIS_RAPIDO_QUE_META"
            else -> "MAIS_LENTO_QUE_META"
        }
        val hasTimeAndDistance = selected.all { it.sample.startElapsedSeconds != null && it.sample.startDistanceMeters != null && it.sample.distanceMeters != null }
        val explicitLap = selected.any { it.sample.sourceType == "EXPLICIT_LAP" }
        val confidence = when {
            selected.isEmpty() -> "Sem dados"
            explicitLap && exactLapAlignment -> "Volta registrada"
            explicitLap -> "Volta registrada • alinhamento estimado"
            selected.size < 3 -> "Baixa"
            hasTimeAndDistance -> "Boa"
            else -> "Estimativa GPS"
        }
        return ActivityBlockResult(
            name = segment.name,
            repetition = block.repetition,
            targetZone = segment.paceZone,
            targetPaceRange = targetRange,
            plannedDurationSeconds = block.plannedDurationSeconds,
            plannedDistanceMeters = block.plannedDistanceMeters,
            actualDurationSeconds = actualSeconds,
            actualDistanceMeters = actualMeters,
            averagePaceSecondsPerKm = averagePace,
            timeInTargetZoneSeconds = timeInZone,
            averageCadenceSpm = cadenceValues.takeIf { it.isNotEmpty() }?.average()?.roundToInt(),
            sampleCount = selected.size,
            confidence = confidence,
            status = status
        )
    }
}
