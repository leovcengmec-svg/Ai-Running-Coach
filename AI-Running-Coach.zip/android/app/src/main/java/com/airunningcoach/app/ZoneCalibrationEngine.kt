package com.airunningcoach.app

import java.time.LocalDate
import kotlin.math.abs
import kotlin.math.roundToInt

internal data class ZoneObservation(
    val dateIso: String,
    val paceSecondsPerKm: Int
)

internal data class CooperPerformanceEvidence(
    val dateIso: String,
    val distanceKm: Double
)

internal data class ZoneCalibrationEvidence(
    val z1Recovery: List<ZoneObservation> = emptyList(),
    val z2TalkTest: List<ZoneObservation> = emptyList(),
    val z3Performance: List<CooperPerformanceEvidence> = emptyList()
)

/** Independent, evidence-gated calibration for the first three operational pace zones. */
internal object ZoneCalibrationEngine {
    const val INITIAL = "INITIAL"
    const val OBSERVATION = "OBSERVATION"
    const val CALIBRATED = "CALIBRATED"
    const val REVIEW = "REVIEW"
    const val UNSTABLE = "UNSTABLE"
    private const val MAX_BOUNDARY_SHIFT_SECONDS = 15

    /** Boundary order: Z5-fast, Z5-slow, Z4-slow, Z3-slow, Z2-slow, Z1-slow. */
    fun boundaryValues(zones: TrainingPaceZones): List<Int> = listOf(
        zones.z5.range.fastestPaceValue,
        zones.z5.range.slowestPaceValue,
        zones.z4.range.slowestPaceValue,
        zones.z3.range.slowestPaceValue,
        zones.z2.range.slowestPaceValue,
        zones.z1.range.slowestPaceValue
    )

    fun isRecoveryWorkoutType(type: String): Boolean {
        val normalized = type.trim().lowercase(java.util.Locale.ROOT)
        return normalized.contains("recuper") || normalized.contains("regener") || normalized.contains("recovery")
    }

    private fun moveBoundary(previous: Int, target: Int): Int = when {
        target > previous + MAX_BOUNDARY_SHIFT_SECONDS -> previous + MAX_BOUNDARY_SHIFT_SECONDS
        target < previous - MAX_BOUNDARY_SHIFT_SECONDS -> previous - MAX_BOUNDARY_SHIFT_SECONDS
        else -> target
    }

    fun apply(
        base: TrainingPaceZones,
        evidence: ZoneCalibrationEvidence,
        previousBoundaryValues: List<Int>? = null
    ): TrainingPaceZones {
        var z1 = base.z1
        var z2 = base.z2
        var z3 = base.z3
        var z4 = base.z4
        var z1Status = INITIAL
        var z2Status = INITIAL
        var z3Status = INITIAL
        var z1Reference: Int? = null
        var z2Reference: Int? = null
        var z3Reference: Int? = null

        fun previousBoundary(index: Int, fallback: Int): Int =
            previousBoundaryValues?.getOrNull(index)?.takeIf { it in 120..1800 } ?: fallback

        // Z1: at least three recent, pain-free, genuinely regenerative sessions.
        val z1Values = evidence.z1Recovery.map { it.paceSecondsPerKm }.filter { it in 120..1800 }.sorted()
        val z1Count = z1Values.size
        z1Status = statusForCount(z1Count, 3)
        val z1HasCalibration = z1Values.size >= 3 && z1Values.last() - z1Values.first() <= 60
        if (z1Values.size >= 3) {
            if (!z1HasCalibration) {
                z1Status = UNSTABLE
            } else {
                val median = median(z1Values)
                // Smooth against the last applied calibration (or Cooper baseline on
                // first use), moving each boundary by no more than 15 s per update.
                val proposedFast = moveBoundary(
                    previousBoundary(4, base.z1.range.fastestPaceValue), median - 30
                ).coerceAtLeast(base.z2.range.fastestPaceValue + 30)
                val proposedSlow = moveBoundary(
                    previousBoundary(5, base.z1.range.slowestPaceValue), median + 45
                ).coerceAtMost(1800)
                if (proposedSlow >= proposedFast + 30) {
                    z1 = z1.copy(
                        range = PaceRange(proposedFast, proposedSlow),
                        intensityBand = "Z1 individualizada por pelo menos três sessões regenerativas reais"
                    )
                    z2 = z2.copy(range = PaceRange(z2.range.fastestPaceValue, proposedFast))
                    z1Status = if (median in proposedFast..proposedSlow) CALIBRATED else REVIEW
                    z1Reference = median
                } else {
                    z1Status = REVIEW
                }
            }
        }

        // Z2: talk-test observations must sit inside the aerobic band. The reference
        // remains inside Z2; Z1 and Z2 share one boundary, and Z3 shares the other.
        val talkValues = evidence.z2TalkTest.map { it.paceSecondsPerKm }.filter { it in 120..1800 }.sorted()
        val z2Count = talkValues.size
        z2Status = statusForCount(z2Count, 3)
        if (talkValues.size >= 3) {
            if (talkValues.last() - talkValues.first() > 45) {
                z2Status = UNSTABLE
            } else {
                val median = median(talkValues)
                val proposedFastBoundary = moveBoundary(
                    previousBoundary(3, base.z2.range.fastestPaceValue), median - 10
                ).coerceAtLeast(z3.range.fastestPaceValue + 30)
                val z1Z2Boundary = if (z1Status == CALIBRATED || z1Status == REVIEW) {
                    z1.range.fastestPaceValue
                } else {
                    moveBoundary(previousBoundary(4, base.z1.range.fastestPaceValue), median + 45)
                }
                val z1SlowBoundary = if (z1Status == CALIBRATED || z1Status == REVIEW) {
                    z1.range.slowestPaceValue
                } else {
                    moveBoundary(previousBoundary(5, base.z1.range.slowestPaceValue), median + 90).coerceAtMost(1800)
                }
                val hasRoom = proposedFastBoundary >= z3.range.fastestPaceValue + 30 &&
                    z1Z2Boundary >= proposedFastBoundary + 30 &&
                    z1SlowBoundary >= z1Z2Boundary + 30
                if (hasRoom) {
                    if (z1Status != CALIBRATED && z1Status != REVIEW) {
                        z1 = z1.copy(
                            range = PaceRange(z1Z2Boundary, z1SlowBoundary),
                            intensityBand = "Z1 provisória • margem abaixo do pace aeróbio confortável"
                        )
                    }
                    z2 = z2.copy(
                        range = PaceRange(proposedFastBoundary, z1Z2Boundary),
                        intensityBand = "Z2 individualizada pelo pace confortável em três ou mais observações consistentes do teste da fala"
                    )
                    z3 = z3.copy(range = PaceRange(z3.range.fastestPaceValue, proposedFastBoundary))
                    z2Status = if (median in proposedFastBoundary..z1Z2Boundary) CALIBRATED else REVIEW
                    z2Reference = median
                } else {
                    z2Status = REVIEW
                }
            }
        }

        // Z3: require two separate Cooper performance tests, at least 14 days apart,
        // whose distances agree within 8%. An ordinary GPS activity is never a test.
        val validTests = evidence.z3Performance.mapNotNull { item ->
            val date = runCatching { LocalDate.parse(item.dateIso) }.getOrNull() ?: return@mapNotNull null
            if (!item.distanceKm.isFinite() || item.distanceKm !in 1.0..5.0) return@mapNotNull null
            date to item.distanceKm
        }.sortedBy { it.first }
        val z3Count = validTests.size
        z3Status = statusForCount(z3Count, 2)
        if (validTests.size >= 2) {
            val pair = validTests.takeLast(2)
            val gapDays = java.time.temporal.ChronoUnit.DAYS.between(pair.first().first, pair.last().first)
            val meanDistance = pair.map { it.second }.average()
            val variation = if (meanDistance > 0.0) abs(pair.last().second - pair.first().second) / meanDistance else 1.0
            if (gapDays < 14 || variation > 0.08) {
                z3Status = if (gapDays < 14) OBSERVATION else UNSTABLE
            } else {
                val representativeDistance = pair.map { it.second }.average()
                // 90% of mean Cooper speed is an operational performance anchor, not LT2.
                val rawPerformanceBoundary = (720.0 / (representativeDistance * 0.90)).roundToInt()
                val proposedFastBoundary = moveBoundary(
                    previousBoundary(2, base.z3.range.fastestPaceValue), rawPerformanceBoundary
                )
                val z2FastBoundary = z2.range.fastestPaceValue
                val z4FastBoundary = base.z4.range.fastestPaceValue
                if (proposedFastBoundary >= z4FastBoundary + 10 && proposedFastBoundary <= z2FastBoundary - 30) {
                    z3 = z3.copy(
                        range = PaceRange(proposedFastBoundary, z2FastBoundary),
                        intensityBand = "Z3 individualizada por dois testes Cooper independentes; referência operacional de desempenho"
                    )
                    z4 = z4.copy(range = PaceRange(z4FastBoundary, proposedFastBoundary))
                    z3Status = if (proposedFastBoundary == rawPerformanceBoundary) CALIBRATED else REVIEW
                    z3Reference = rawPerformanceBoundary
                } else {
                    z3Status = REVIEW
                }
            }
        }

        // All five zones remain strictly ordered and contiguous, in pace order:
        // faster Z5 -> slower Z1 (lower seconds/km means a faster pace).
        val ordered = listOf(z5Range(base), z4.range, z3.range, z2.range, z1.range)
        val contiguous = ordered.all { it.fastestPaceValue < it.slowestPaceValue } &&
            ordered.zipWithNext().all { (faster, slower) -> faster.slowestPaceValue == slower.fastestPaceValue }
        if (!contiguous) {
            return base.copy(
                z1CalibrationStatus = if (z1Status == CALIBRATED) REVIEW else z1Status,
                z2CalibrationStatus = if (z2Status == CALIBRATED) REVIEW else z2Status,
                z3CalibrationStatus = if (z3Status == CALIBRATED) REVIEW else z3Status,
                z1CalibrationEvidenceCount = z1Count,
                z2CalibrationEvidenceCount = z2Count,
                z3CalibrationEvidenceCount = z3Count
            )
        }
        return base.copy(
            z1 = z1,
            z2 = z2,
            z3 = z3,
            z4 = z4,
            z1CalibrationStatus = z1Status,
            z2CalibrationStatus = z2Status,
            talkTestEvidenceCount = z2Count,
            talkTestReferencePaceValue = z2Reference,
            z3CalibrationStatus = z3Status,
            z1CalibrationEvidenceCount = z1Count,
            z2CalibrationEvidenceCount = z2Count,
            z3CalibrationEvidenceCount = z3Count,
            z1CalibrationReferencePaceValue = z1Reference,
            z2CalibrationReferencePaceValue = z2Reference,
            z3CalibrationReferencePaceValue = z3Reference
        )
    }

    private fun z5Range(base: TrainingPaceZones): PaceRange = base.z5.range

    private fun statusForCount(count: Int, required: Int): String = when {
        count == 0 -> INITIAL
        count < required -> OBSERVATION
        else -> CALIBRATED
    }

    private fun median(sorted: List<Int>): Int = if (sorted.size % 2 == 1) sorted[sorted.size / 2]
        else ((sorted[sorted.size / 2 - 1] + sorted[sorted.size / 2]) / 2.0).roundToInt()
}
