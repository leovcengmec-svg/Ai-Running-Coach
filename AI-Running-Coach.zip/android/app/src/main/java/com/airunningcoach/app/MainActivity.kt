package com.airunningcoach.app

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.provider.OpenableColumns
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.YearMonth
import java.time.DayOfWeek
import java.time.temporal.TemporalAdjusters
import java.time.format.DateTimeFormatter
import java.time.Instant
import java.time.ZoneId
import java.util.Locale
import kotlin.math.roundToInt

private val Navy = Color(0xFF0A1220)
private val Navy2 = Color(0xFF111D2D)
private val CardBlue = Color(0xFF1A2B40)
private val Blue = Color(0xFF8EAEF5)
private val Blue2 = Color(0xFFC1D0FF)
private val TextWhite = Color(0xFFF4F6FC)
private val TextMuted = Color(0xFFA3B0C3)
private val Green = Color(0xFF7AD6B7)
private val Yellow = Color(0xFFF4C77B)
private const val CURRENT_ENGINE_VERSION = 71

private enum class Screen { DASHBOARD, CALENDAR, WORKOUT, STRUCTURE, PLAN, EVOLUTION, FEEDBACK, HISTORY, PROFILE, AVAILABILITY, EXPORT, PACE_ZONES, COOPER_TEST, TRAINING_LIBRARY, RACES, BACKUP, RACE_STRATEGY }

internal data class Workout(
    val date: String,
    val scheduledDateIso: String = "",
    val title: String,
    val detail: String,
    val type: String,
    val objective: String,
    val stimulus: String,
    val distanceKm: Double,
    val done: Boolean = false,
    val sessionId: String = "",
    val durationMin: Int = 0,
    val intensity: String = "LOW",
    val paceMode: String = "PACE_NOT_CALIBRATED",
    val rpeRange: String = "3-4",
    val rationale: String = "",
    val week: Int = 1,
    val phase: String = "BASE",
    val segments: List<WorkoutSegment> = emptyList(),
    val paceCalibrationSnapshot: PaceCalibrationSnapshot? = null,
    val manuallyRescheduled: Boolean = false,
    val originalScheduledDateIso: String = "",
    val selectedOption: String = "PRIMARY",
    val isOptionalExtra: Boolean = false,
    /** Motor target for this week; actual session totals may be lower when safety caps apply. */
    val weeklyTargetKm: Double? = null,
    /** Running experience captured with this prescription; legacy workouts default to unknown. */
    val experienceMonths: Int = -1
)

private fun Workout.asPrescribedForDistribution(): PrescribedWorkout = PrescribedWorkout(
    day = "", date = date, scheduledDateIso = scheduledDateIso, title = title, type = type,
    objective = objective, stimulus = stimulus, sessionId = sessionId, distanceKm = distanceKm,
    durationMin = durationMin, intensity = intensity, paceMode = paceMode, rpeRange = rpeRange,
    detail = detail, rationale = rationale, week = week, phase = phase,
    segments = segments, paceCalibrationSnapshot = paceCalibrationSnapshot, experienceMonths = experienceMonths
)

private data class FeedbackRecord(
    val sessionId: String,
    val effort: String,
    val feeling: String,
    val notes: String,
    val painPresent: Boolean = false,
    val actualDistanceKm: Double? = null,
    val savedAt: Long = System.currentTimeMillis(),
    val actualDuration: String? = null,
    val actualPaceMinKm: String? = null,
    val talkTestPaceMmSs: String? = null,
    /** Date/type of the completed workout; legacy records fall back to feedback save time/current workout. */
    val workoutDateIso: String = "",
    val workoutType: String = "",
    val workoutTitle: String = "",
    val activitySourceFormat: String = "",
    val activityFingerprint: String = "",
    val activityStartedAtIso: String = "",
    val activityStartedAtSource: String = "",
    /** Actual local activity date; separate from the scheduled workout date. */
    val realizedDateIso: String = "",
    /** Explicitly selected terrain for this completed activity. */
    val terrain: String = RunningTerrain.MIXED,
    /** Optional link to a race event; linked results can support physiological estimates. */
    val raceEventId: String = "",
    val recordedPaceSegments: List<ActivityPaceSegment> = emptyList(),
    /** Runner-entered pace for each prescribed block; targets are frozen at completion. */
    val blockPaceFeedback: List<WorkoutBlockPaceFeedback> = emptyList(),
    /** Frozen zone allocation when known; prevents historic runs being reclassified after calibration. */
    val measuredZoneTimeSeconds: Map<String, Int> = emptyMap(),
    val elevationGainMeters: Double? = null,
    // Legacy backup metadata only. V78 does not display, calculate, or use heart rate.
    val averageHeartRateBpm: Int? = null,
    val maxHeartRateBpm: Int? = null,
    val averageCadenceSpm: Int? = null,
    val maxCadenceSpm: Int? = null,
    val routePointCount: Int = 0,
    val splitPacesMmSs: List<String> = emptyList(),
    val splitDetails: List<ActivitySplit> = emptyList(),
    val encodedRoute: String = ""
)

private class CoachState(private val context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("ai_running_coach", Context.MODE_PRIVATE)
    private val navigationHistory = mutableListOf<Screen>()
    private var lastGeneratedObjectiveSignature: String = ""

    private fun currentPlanObjectiveSignature(): String = listOf(
        goal.trim(), customGoalKm.trim(), goalIntent, goalTargetTimeText.trim(), personalBestTimeText.trim(),
        RunnerFitnessAssessmentEngine.normalizeLevel(level), frequency.toString(),
        availableTrainingDays.distinct().sortedBy { it.value }.joinToString(","),
        RunningTerrain.normalize(terrainPreference), runningExperienceDuration, fitnessTestMethod,
        cooperDistanceText.trim(), threeKmTimeText.trim(), weeklyVolumeText.trim(), longestRecent.trim(), planWeeks.toString()
    ).joinToString("|")

    /** Marks future sessions stale as soon as an athlete edits a plan-defining profile field. */
    fun markPlanNeedsRefreshIfObjectiveChanged() {
        if (workouts.isNotEmpty() && lastGeneratedObjectiveSignature.isNotBlank() &&
            currentPlanObjectiveSignature() != lastGeneratedObjectiveSignature) {
            needsEngineRefresh = true
            racePlanNote = "O cadastro que define a estratégia do treinador mudou. Recalcule o plano para atualizar as sessões futuras; treinos concluídos serão preservados."
        }
    }

    fun navigateTo(screen: Screen) {
        if (screen != selectedScreen) {
            navigationHistory.add(selectedScreen)
            selectedScreen = screen
            persist()
        }
    }

    fun canNavigateBack(): Boolean = navigationHistory.isNotEmpty() || selectedScreen != Screen.DASHBOARD

    fun resetNavigation(screen: Screen) {
        navigationHistory.clear()
        selectedScreen = screen
    }

    fun navigateBack(fallback: Screen? = fallbackScreenFor(selectedScreen)) {
        val destination = if (navigationHistory.isNotEmpty()) navigationHistory.removeAt(navigationHistory.lastIndex) else fallback
        if (destination != null && destination != selectedScreen) {
            selectedScreen = destination
            persist()
        }
    }

    private fun fallbackScreenFor(screen: Screen): Screen? = when (screen) {
        Screen.DASHBOARD -> null
        Screen.CALENDAR, Screen.PLAN, Screen.EVOLUTION, Screen.PROFILE -> Screen.DASHBOARD
        Screen.WORKOUT -> Screen.CALENDAR
        Screen.STRUCTURE, Screen.FEEDBACK, Screen.EXPORT -> Screen.WORKOUT
        Screen.AVAILABILITY, Screen.HISTORY, Screen.RACES, Screen.PACE_ZONES,
        Screen.COOPER_TEST, Screen.TRAINING_LIBRARY, Screen.BACKUP -> Screen.PROFILE
        Screen.RACE_STRATEGY -> Screen.RACES
    }

    var name by mutableStateOf("")
    var goal by mutableStateOf("")
    var goalIntent by mutableStateOf(TrainingGoalIntent.COMPLETE)
    var goalTargetTimeText by mutableStateOf("")
    var personalBestTimeText by mutableStateOf("")
    var terrainPreference by mutableStateOf(RunningTerrain.ROAD)
    var customGoalKm by mutableStateOf("")
    var level by mutableStateOf("")
    var frequency by mutableStateOf(0)
    var availableTrainingDays by mutableStateOf<List<DayOfWeek>>(emptyList())
    var preferredLongRunDay by mutableStateOf<DayOfWeek?>(null)
    var scheduleActionMessage by mutableStateOf("")
    var targetDate by mutableStateOf("Sem prova principal")
    var raceEvents by mutableStateOf(listOf<RaceEvent>())
    var planStartDateIso by mutableStateOf("")
    var racePlanNote by mutableStateOf("")
    var racePlanWarnings by mutableStateOf(listOf<String>())
    var raceFormError by mutableStateOf("")
    var raceNameDraft by mutableStateOf("")
    var raceDistanceDraft by mutableStateOf("")
    var raceDateDraft by mutableStateOf(LocalDate.now().plusMonths(2).format(DateTimeFormatter.ofPattern("dd/MM/uuuu")))
    var racePriorityDraft by mutableStateOf("A")
    var raceTargetTimeDraft by mutableStateOf("")
    var raceLocationDraft by mutableStateOf("")
    var raceNotesDraft by mutableStateOf("")
    var editingRaceId by mutableStateOf("")
    var selectedRaceId by mutableStateOf("")
    var volume by mutableStateOf("") // legado V18; mantido apenas para migração local
    var weeklyVolumeText by mutableStateOf("")
    var longestRecent by mutableStateOf("")
    /** Experience duration supplements (but never overrides) the self-declared level. */
    var runningExperienceDuration by mutableStateOf("")
    /** Legacy age-only profiles remain supported; birth date becomes the preferred source. */
    var ageYearsText by mutableStateOf("")
    var birthDateText by mutableStateOf("")
    var historicalTestAgeText by mutableStateOf("")
    var referenceSex by mutableStateOf("")
    var fitnessTestMethod by mutableStateOf("NONE") // NONE, COOPER_12_MIN, THREE_KM
    var threeKmTimeText by mutableStateOf("")
    /** Number of distinct weeks with at least one run in the previous four weeks. Kept for history, no longer asked in onboarding. */
    var activeWeeksLast4 by mutableStateOf(-1)
    var cooperEnabled by mutableStateOf(false)
    var cooperDistanceText by mutableStateOf("")
    var cooperAssessmentDateText by mutableStateOf(LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/uuuu")))
    var cooperAssessments by mutableStateOf(listOf<CooperAssessmentRecord>())
    var latestCooperMessage by mutableStateOf("")
    var onboardingStep by mutableStateOf(-1)
    var selectedScreen by mutableStateOf(Screen.DASHBOARD)
    var selectedWorkoutIndex by mutableStateOf(0)
    var feedbackSaved by mutableStateOf(false)
    var workouts by mutableStateOf(listOf<Workout>())
    var planWeeks by mutableStateOf(8)
    var motorState by mutableStateOf<MotorState?>(null)
    var motorDecision by mutableStateOf<MotorDecision?>(null)
    var motorExplanation by mutableStateOf("")
    var motorError by mutableStateOf("")
    var needsEngineRefresh by mutableStateOf(false)
    var needsPacePlanRefresh by mutableStateOf(false)
    var feedbackRecords by mutableStateOf(listOf<FeedbackRecord>())
    /** Persisted zone boundaries let evidence-based recalibration move by at most 15 s per update. */
    var lastZoneBoundarySnapshot by mutableStateOf<List<Int>?>(null)
    /** Latest assisted zone-review decision, keyed by zone and evidence signature. */
    var zoneReviewDecisions by mutableStateOf<Map<String, String>>(emptyMap())
    var latestFeedbackHeadline by mutableStateOf("")
    var latestFeedbackAdvice by mutableStateOf("")
    var backupMessage by mutableStateOf("")
    var pendingBackupRecalibration by mutableStateOf(false)
    var importedBackupEngineVersion by mutableStateOf(0)
    var restDayRecommendation by mutableStateOf<RestDayRecommendation?>(null)

    init { load() }

    fun parsedCooperAssessmentDate(): LocalDate? = CooperAssessmentEngine.parseAssessmentDate(cooperAssessmentDateText)

    fun parsedBirthDate(): LocalDate? = AthleteDemographicsEngine.parseBirthDate(birthDateText)

    fun ageAtDate(date: LocalDate): Int? = AthleteDemographicsEngine.ageAtDate(birthDateText, ageYearsText, date)

    fun parsedAgeYears(): Int? = ageAtDate(LocalDate.now())

    fun parsedAssessmentAge(): Int? = parsedCooperAssessmentDate()?.let(::ageAtDate) ?: parsedAgeYears()

    fun profileAgeLabel(): String = when {
        birthDateText.isNotBlank() && parsedBirthDate() == null -> "Data inválida"
        else -> parsedAgeYears()?.let { "$it anos" } ?: "Não informada"
    }

    fun selectedFieldTestZones(): TrainingPaceZones? {
        return when (fitnessTestMethod) {
            "COOPER_12_MIN" -> calculateZonesForCooper(cooperDistanceText.trim().replace(",", ".").toDoubleOrNull())
            "THREE_KM" -> {
                val age = parsedAssessmentAge() ?: return null
                if (age !in 18..39) return null
                val time = RunnerFitnessAssessmentEngine.parseDurationSeconds(threeKmTimeText) ?: return null
                val zones = PaceCalculator.calculateThreeKm(time, referenceSex) ?: return null
                val date = parsedCooperAssessmentDate()?.toString() ?: LocalDate.now().toString()
                val previous = cooperAssessments.lastOrNull { it.testMethod == "THREE_KM" && it.dateIso != date }
                    ?.let { record -> record.testDurationSeconds?.let { PaceCalculator.calculateThreeKm(it, record.referenceSex) } }
                PaceCalculator.limitCalibrationChange(zones, previous, 15)
            }
            else -> null
        }
    }

    fun physiologicalLevelFromSelectedTest(): String? {
        val zones = selectedFieldTestZones() ?: return null
        val age = parsedAssessmentAge() ?: return null
        return RunnerFitnessAssessmentEngine.assess(zones.estimatedVo2Max, age, referenceSex, "FIELD_ESTIMATE")?.level
    }

    fun refreshPhysiologicalLevelFromTest() {
        val assessedLevel = physiologicalLevelFromSelectedTest()
        if (assessedLevel != null) {
            level = assessedLevel
            val options = TrainingGoalCatalog.labelsForLevel(level)
            if (goal.isNotBlank() && goal !in options) goal = ""
        } else if (fitnessTestMethod == "NONE") {
            level = "Iniciante" // conservative internal guardrail only; displayed as awaiting a test
            if (goal.isNotBlank() && goal !in TrainingGoalCatalog.labelsForLevel(level)) goal = ""
        }
        markPlanNeedsRefreshIfObjectiveChanged()
        persist()
    }

    fun physiologicalLevelDisplay(): String {
        val latest = cooperAssessments.maxByOrNull { it.dateIso } ?: return "Aguardando teste"
        val testDate = runCatching { LocalDate.parse(latest.dateIso) }.getOrNull()
        val age = latest.ageAtTest ?: testDate?.let(::ageAtDate) ?: parsedAgeYears()
            ?: return "Aguardando idade no perfil"
        val sex = latest.referenceSex.takeIf { it in setOf(RunnerFitnessAssessmentEngine.MALE, RunnerFitnessAssessmentEngine.FEMALE) }
            ?: referenceSex
        if (sex !in setOf(RunnerFitnessAssessmentEngine.MALE, RunnerFitnessAssessmentEngine.FEMALE)) return "Configurar referência fisiológica"
        return RunnerFitnessAssessmentEngine.assess(latest.estimatedVo2Max, age, sex, "FIELD_ESTIMATE")?.level
            ?: "Aguardando teste válido"
    }

    private fun isRunWalkEligibleForCurrentProfile(
        selectedGoalKm: Double = TrainingGoalCatalog.distanceForLabel(
            goal, customGoalKm.trim().replace(",", ".").toDoubleOrNull()
        ) ?: 0.0,
        enteredLongestKm: Double? = longestRecent.trim().replace(",", ".").toDoubleOrNull()
    ): Boolean {
        val enteredWeeklyKm = weeklyVolumeText.trim().replace(",", ".").toDoubleOrNull()
        val completedFiveKmEvidence = loggedActivitiesForLoad().any { it.distanceKm >= 5.0 }
        return RunWalkEligibilityEngine.isEligible(
            goalKm = selectedGoalKm,
            physiologicalLevel = level,
            experienceMonths = experienceMonths(),
            weeklyKmEntered = enteredWeeklyKm,
            longestContinuousKmEntered = enteredLongestKm,
            hasCompletedFiveKm = completedFiveKmEvidence
        )
    }

    fun runWalkAllowedForCurrentProfile(): Boolean = isRunWalkEligibleForCurrentProfile()

    fun qualityReplacementCanPreserveStimulus(): Boolean =
        recentFeedback().takeLast(3).none { it.painPresent } &&
            (deriveRecoveryScore() ?: 75.0) >= 60.0 && (deriveFatigueScore() ?: 25.0) < 70.0

    fun selectedGoalLoadReference(): GoalLoadReference? {
        val selectedDistance = TrainingGoalCatalog.distanceForLabel(
            goal, customGoalKm.trim().replace(",", ".").toDoubleOrNull()
        ) ?: return null
        return runCatching { TrainingPlanReferenceCatalog.loadReference(selectedDistance, TrainingGoalCatalog.categoryForLabel(goal)) }.getOrNull()
    }

    fun effectiveDisplayWeeklyKm(): Double? = weeklyVolumeText.trim().replace(",", ".").toDoubleOrNull()
        ?: selectedGoalLoadReference()?.baseWeeklyKm

    fun effectiveDisplayLongestKm(): Double? = longestRecent.trim().replace(",", ".").toDoubleOrNull()
        ?: selectedGoalLoadReference()?.assumedPreviousContinuousDistanceKm

    fun defaultBeginnerWeeklyKm(): Double = (frequency.coerceIn(2, 6) * 2.0).coerceIn(4.0, 8.0)
    fun defaultBeginnerLongestKm(): Double = 2.0

    fun experienceMonths(): Int = when (runningExperienceDuration) {
        "Menos de 6 meses" -> 3
        "6–12 meses" -> 9
        "1–3 anos" -> 24
        "3–5 anos" -> 48
        "Mais de 5 anos" -> 72
        else -> -1
    }

    fun runnerReadinessSnapshot(
        weeklyOverride: Double? = null,
        longestOverride: Double? = null,
        weeksOverride: Int? = null
    ): RunnerReadinessSnapshot? {
        val goalKm = TrainingGoalCatalog.distanceForLabel(
            goal,
            customGoalKm.trim().replace(",", ".").toDoubleOrNull()
        ) ?: return null
        val safeLevel = RunnerFitnessAssessmentEngine.normalizeLevel(level).takeIf { level.isNotBlank() } ?: return null
        return runCatching {
            RunnerReadinessEngine.evaluate(
                RunnerReadinessInput(
                    goalKm = goalKm,
                    goalCategory = TrainingGoalCatalog.categoryForLabel(goal),
                    declaredLevel = safeLevel,
                    experienceMonths = experienceMonths(),
                    selectedFrequency = frequency.takeIf { it in 2..6 } ?: availableTrainingDays.size.takeIf { it in 2..6 } ?: 3,
                    weeklyVolumeKm = weeklyOverride ?: effectiveDisplayWeeklyKm() ?: 0.0,
                    longestRecentKm = longestOverride ?: effectiveDisplayLongestKm() ?: 0.0,
                    activeWeeksLast4 = weeksOverride ?: activeWeeksLast4,
                    goalIntent = if (TrainingGoalCatalog.categoryForLabel(goal) == "HEALTH") TrainingGoalIntent.HEALTH else goalIntent,
                    targetTimeSeconds = goalTargetTimeText.takeIf { goalIntent == TrainingGoalIntent.TARGET_TIME }?.let(PhysiologicalProfileEngine::parseTargetTime),
                    terrainPreference = terrainPreference
                )
            )
        }.getOrNull()
    }

    fun setTrainingDay(day: DayOfWeek, selected: Boolean) {
        val next = if (selected) (availableTrainingDays + day).distinct().sortedBy { it.value }
                   else availableTrainingDays.filterNot { it == day }
        if (next.size > 6 || (workouts.isNotEmpty() && next.size < 2)) {
            scheduleActionMessage = "Selecione entre 2 e 6 dias disponíveis. Para alterar um plano existente, mantenha pelo menos dois dias selecionados."
            return
        }
        availableTrainingDays = next
        frequency = next.size
        preferredLongRunDay = TrainingScheduleEngine.resolvePreferredLongRunDay(preferredLongRunDay, next)
        scheduleActionMessage = "Disponibilidade salva: ${next.size} dias por semana."
        if (workouts.isNotEmpty()) {
            needsEngineRefresh = true
            racePlanNote = "A disponibilidade semanal mudou. Recalcule o plano para redistribuir as sessões."
        }
        persist()
    }

    fun setLongRunDay(day: DayOfWeek) {
        if (day !in availableTrainingDays) return
        preferredLongRunDay = day
        scheduleActionMessage = "Dia preferido do longão atualizado."
        if (workouts.isNotEmpty()) {
            needsEngineRefresh = true
            racePlanNote = "O dia preferido do longão mudou. Recalcule o plano para aplicar a preferência."
        }
        persist()
    }

    fun availableRescheduleDates(workout: Workout): List<LocalDate> {
        val current = runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull() ?: return emptyList()
        val monday = current.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val slots = workouts.mapNotNull { item ->
            runCatching { LocalDate.parse(item.scheduledDateIso) }.getOrNull()?.let { date ->
                TrainingScheduleEngine.SessionSlot(item.sessionId, date, item.type, item.done)
            }
        }
        val raceDates = raceEvents.filter { it.status != "CANCELLED" }.mapNotNull { it.dateOrNull() }.toSet()
        return (0L..6L).map { monday.plusDays(it) }.filter { candidate ->
            TrainingScheduleEngine.validateMove(
                source = TrainingScheduleEngine.SessionSlot(workout.sessionId, current, workout.type, workout.done),
                targetDate = candidate, sessions = slots, raceDates = raceDates
            ).allowed
        }
    }

    fun rescheduleWorkout(workout: Workout, newDate: LocalDate): Boolean {
        val current = runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull()
        if (current == null) {
            scheduleActionMessage = "A data original desta sessão não é válida."
            return false
        }
        val slots = workouts.mapNotNull { item ->
            runCatching { LocalDate.parse(item.scheduledDateIso) }.getOrNull()?.let { date ->
                TrainingScheduleEngine.SessionSlot(item.sessionId, date, item.type, item.done)
            }
        }
        val raceDates = raceEvents.filter { it.status != "CANCELLED" }.mapNotNull { it.dateOrNull() }.toSet()
        val decision = TrainingScheduleEngine.validateMove(
            source = TrainingScheduleEngine.SessionSlot(workout.sessionId, current, workout.type, workout.done),
            targetDate = newDate, sessions = slots, raceDates = raceDates
        )
        if (!decision.allowed) {
            scheduleActionMessage = decision.reason
            return false
        }
        val newLabel = "${newDate.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, Locale.forLanguageTag("pt-BR")).replaceFirstChar { it.uppercase(Locale.forLanguageTag("pt-BR")) }}, ${newDate.format(DateTimeFormatter.ofPattern("dd/MM"))}"
        workouts = workouts.map { item ->
            if (item.sessionId == workout.sessionId) item.copy(
                date = newLabel,
                scheduledDateIso = newDate.toString(),
                manuallyRescheduled = true,
                originalScheduledDateIso = item.originalScheduledDateIso.ifBlank { current.toString() }
            ) else item
        }
        selectedWorkoutIndex = workouts.indexOfFirst { it.sessionId == workout.sessionId }.coerceAtLeast(0)
        scheduleActionMessage = "Sessão reagendada para ${newDate.format(DateTimeFormatter.ofPattern("dd/MM"))}. A dose e os blocos foram preservados."
        persist()
        return true
    }

    fun isCooperEntryValid(): Boolean {
        if (fitnessTestMethod == "NONE") return true // conservative provisional profile; the test can be added later
        val date = parsedCooperAssessmentDate() ?: return false
        if (!CooperAssessmentEngine.isRecentAssessmentDate(date)) return false
        val ageAtAssessment = parsedAssessmentAge()
        if (ageAtAssessment == null || referenceSex !in setOf(RunnerFitnessAssessmentEngine.MALE, RunnerFitnessAssessmentEngine.FEMALE)) return false
        return when (fitnessTestMethod) {
            "COOPER_12_MIN" -> PaceCalculator.calculateCooper(cooperDistanceText.trim().replace(",", ".").toDoubleOrNull()) != null
            "THREE_KM" -> ageAtAssessment in 18..39 &&
                PaceCalculator.calculateThreeKm(RunnerFitnessAssessmentEngine.parseDurationSeconds(threeKmTimeText), referenceSex) != null
            else -> false
        }
    }

    /** Only an A-priority event is the primary goal race; B/C events remain tune-ups. */
    fun primaryUpcomingRace(): RaceEvent? = raceEvents
        .filter { it.status == "PLANNED" && it.priority == "A" }
        .mapNotNull { event -> event.dateOrNull()?.let { event to it } }
        .filter { !it.second.isBefore(LocalDate.now()) }
        .minByOrNull { it.second }?.first

    fun eventsForPlanWeek(week: Int): List<RaceEvent> {
        val start = runCatching { LocalDate.parse(planStartDateIso) }.getOrNull()
            ?: workouts.minOfOrNull { runCatching { LocalDate.parse(it.scheduledDateIso) }.getOrNull() ?: LocalDate.now() }
                ?.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            ?: return emptyList()
        // UI and planning engine share the same numbering: the current partial
        // calendar week is week 1, the following Monday begins week 2.
        val racePlanningWeek = week.coerceAtLeast(1)
        return RaceEventEngine.eventsForWeek(raceEvents, start, racePlanningWeek)
    }

    fun openRaceStrategy(event: RaceEvent) {
        selectedRaceId = event.id
        navigateTo(Screen.RACE_STRATEGY)
    }

    fun selectedRace(): RaceEvent? = raceEvents.firstOrNull { it.id == selectedRaceId }

    fun racePaceEvidence(): List<RacePaceEvidence> = feedbackRecords.flatMap { record ->
        val date = runCatching { LocalDate.parse(record.realizedDateIso.ifBlank { record.workoutDateIso }) }.getOrNull()
            ?: return@flatMap emptyList()
        val derivedActivityPace = if (record.actualPaceMinKm.isNullOrBlank()) {
            val seconds = record.actualDuration?.let(PaceCalculator::parseDuration)
            val distance = record.actualDistanceKm
            if (seconds != null && distance != null && distance > 0.0) PaceCalculator.paceFromDistanceAndDuration(distance, seconds) else null
        } else PaceRange.parsePace(record.actualPaceMinKm)
        val wholeActivity = derivedActivityPace?.let { pace ->
            listOf(RacePaceEvidence(
                date = date, distanceKm = record.actualDistanceKm ?: 0.0, paceSecondsPerKm = pace,
                effort = record.effort, feeling = record.feeling, painPresent = record.painPresent,
                source = "ACTIVITY", workoutType = record.workoutType, sessionId = record.sessionId
            ))
        }.orEmpty()
        val expandedBlocks = workouts.firstOrNull { it.sessionId == record.sessionId }
            ?.let { WorkoutBlockFeedbackEngine.expand(it.segments).associateBy { prescribed -> prescribed.key } }
            .orEmpty()
        val blocks = record.blockPaceFeedback.mapNotNull { block ->
            val pace = block.actualPaceSecondsPerKm ?: return@mapNotNull null
            val prescribed = expandedBlocks[block.blockKey]?.segment
            val blockDistanceKm = when (block.targetMode) {
                "DISTANCE" -> prescribed?.distanceKm
                "TIME" -> prescribed?.durationMin?.let { (it * 60.0) / pace }
                else -> null
            } ?: 0.0
            val blockDurationSeconds = when (block.targetMode) {
                "TIME" -> prescribed?.durationMin?.times(60)
                "DISTANCE" -> (blockDistanceKm * pace).toInt().takeIf { it > 0 }
                else -> null
            }
            RacePaceEvidence(
                date = date, distanceKm = blockDistanceKm, paceSecondsPerKm = pace, effort = record.effort,
                feeling = record.feeling, painPresent = record.painPresent, source = "BLOCK",
                workoutType = record.workoutType, zone = block.targetZone, sessionId = record.sessionId,
                durationSeconds = blockDurationSeconds
            )
        }
        wholeActivity + blocks
    }

    fun beginRaceEdit(event: RaceEvent) {
        editingRaceId = event.id
        raceNameDraft = event.name
        raceDistanceDraft = String.format(Locale.US, "%.1f", event.distanceKm).replace(".", ",")
        raceDateDraft = RaceEventEngine.formatBrazilianDate(event.eventDateIso)
        racePriorityDraft = event.priority
        raceTargetTimeDraft = event.targetTime
        raceLocationDraft = event.location
        raceNotesDraft = event.notes
        raceFormError = ""
    }

    fun resetRaceDraft() {
        editingRaceId = ""
        raceNameDraft = ""
        raceDistanceDraft = ""
        raceDateDraft = LocalDate.now().plusMonths(2).format(DateTimeFormatter.ofPattern("dd/MM/uuuu"))
        racePriorityDraft = "A"
        raceTargetTimeDraft = ""
        raceLocationDraft = ""
        raceNotesDraft = ""
        raceFormError = ""
    }

    fun saveRaceDraft(): Boolean {
        val distance = raceDistanceDraft.trim().replace(",", ".").toDoubleOrNull()
        raceFormError = RaceEventEngine.validate(raceNameDraft, distance, raceDateDraft, racePriorityDraft, raceTargetTimeDraft).orEmpty()
        if (raceFormError.isNotBlank() || distance == null) return false
        val status = RaceEventEngine.parseBrazilianDate(raceDateDraft)?.let { if (it.isBefore(LocalDate.now())) "COMPLETED" else "PLANNED" } ?: "PLANNED"
        val race = RaceEventEngine.create(
            id = editingRaceId.ifBlank { java.util.UUID.randomUUID().toString() },
            name = raceNameDraft, distanceKm = distance, dateText = raceDateDraft, priority = racePriorityDraft,
            targetTime = raceTargetTimeDraft, location = raceLocationDraft, notes = raceNotesDraft, status = status
        ) ?: run { raceFormError = "Não foi possível salvar a competição. Confira os dados."; return false }
        raceEvents = if (editingRaceId.isBlank()) raceEvents + race else raceEvents.map { if (it.id == editingRaceId) race else it }
        syncTargetDate()
        if (workouts.isNotEmpty()) {
            needsEngineRefresh = true
            racePlanNote = "A lista de competições mudou. Recalcule o plano para ajustar sessões, taper e recuperação."
        }
        resetRaceDraft()
        persist()
        return true
    }

    fun deleteRace(id: String) {
        raceEvents = raceEvents.filterNot { it.id == id }
        syncTargetDate()
        if (workouts.isNotEmpty()) needsEngineRefresh = true
        persist()
    }

    fun markRaceCompleted(id: String) {
        raceEvents = raceEvents.map { if (it.id == id) it.copy(status = "COMPLETED") else it }
        syncTargetDate()
        persist()
    }

    private fun syncTargetDate() {
        val primary = primaryUpcomingRace()
        targetDate = primary?.let { RaceEventEngine.formatBrazilianDate(it.eventDateIso) } ?: "Sem prova principal"
    }

    private fun feedbackRpeValue(record: FeedbackRecord): Int? =
        FeedbackRpeScale.valueFor(record.effort)

    private fun actualDurationSeconds(record: FeedbackRecord): Int? {
        PaceCalculator.parseDuration(record.actualDuration.orEmpty())?.let { return it }
        val distance = record.actualDistanceKm ?: return null
        val pace = PaceRange.parsePace(record.actualPaceMinKm.orEmpty()) ?: return null
        return (distance * pace).toInt().takeIf { it in 1..172_800 }
    }

    private fun estimatedZoneTimeFromSplits(record: FeedbackRecord): Map<String, Int> {
        val distance = record.actualDistanceKm ?: return emptyMap()
        val zones = currentPaceZones() ?: return emptyMap()
        if (record.splitPacesMmSs.isEmpty()) return emptyMap()
        val totals = mutableMapOf<String, Int>()
        var remainingKm = distance
        record.splitPacesMmSs.forEach { rawPace ->
            val pace = PaceRange.parsePace(rawPace) ?: return@forEach
            val splitKm = minOf(1.0, remainingKm)
            if (splitKm <= 0.0) return@forEach
            val zoneId = listOf(
                "Z1" to zones.z1.range, "Z2" to zones.z2.range, "Z3" to zones.z3.range,
                "Z4" to zones.z4.range, "Z5" to zones.z5.range
            ).firstOrNull { (_, range) -> pace in range.fastestPaceValue..range.slowestPaceValue }?.first
            if (zoneId != null) totals[zoneId] = (totals[zoneId] ?: 0) + (splitKm * pace).toInt()
            remainingKm -= splitKm
        }
        return totals
    }

    private fun measuredZoneTimeFromTrack(segments: List<ActivityPaceSegment>): Map<String, Int> =
        currentPaceZones()?.let { zones -> ActivityZoneTimeEngine.summarize(segments, zones.all()) }.orEmpty()

    private fun loggedActivitiesForLoad(): List<LoggedRunActivity> = feedbackRecords.mapNotNull { record ->
        val distance = record.actualDistanceKm ?: return@mapNotNull null
        LoggedRunActivity(
            date = feedbackActivityDate(record),
            distanceKm = distance,
            durationSeconds = actualDurationSeconds(record),
            rpe = feedbackRpeValue(record),
            averageCadenceSpm = record.averageCadenceSpm,
            elevationGainMeters = record.elevationGainMeters,
            sessionType = record.workoutType,
            zoneTimeSeconds = record.measuredZoneTimeSeconds.ifEmpty {
                measuredZoneTimeFromTrack(record.recordedPaceSegments)
            },
            estimatedZoneTimeSeconds = estimatedZoneTimeFromSplits(record),
            terrain = RunningTerrain.normalize(record.terrain)
        )
    }

    fun trainingLoadSnapshot(today: LocalDate = LocalDate.now()): TrainingLoadSnapshot =
        TrainingLoadEngine.summarize(loggedActivitiesForLoad(), today)

    fun criticalSpeedSnapshot(today: LocalDate = LocalDate.now()): CriticalSpeedSnapshot =
        PhysiologicalProfileEngine.estimateCriticalSpeed(performanceTestObservations(), today)

    private fun performanceTestObservations(): List<PerformanceTestObservation> = feedbackRecords.mapNotNull { record ->
        val distance = record.actualDistanceKm ?: return@mapNotNull null
        val duration = actualDurationSeconds(record) ?: return@mapNotNull null
        val rpe = feedbackRpeValue(record) ?: 0
        val testLike = record.raceEventId.isNotBlank() || listOf(record.workoutType, record.workoutTitle).any { value ->
            val normalized = value.lowercase(Locale.ROOT)
            normalized.contains("prova") || normalized.contains("teste") || normalized.contains("cooper") || normalized.contains("time trial")
        }
        PerformanceTestObservation(
            date = feedbackActivityDate(record),
            distanceKm = distance,
            durationSeconds = duration,
            effortRating = rpe,
            painPresent = record.painPresent,
            isRaceOrTest = testLike,
            terrain = RunningTerrain.normalize(record.terrain)
        )
    }

    fun createPlan(preserveCycleAnchor: Boolean = false): Boolean {
        // Recalculation preserves an existing cycle only while its objective identity
        // remains the same. Changing distance, intent, physiological class, frequency,
        // available days or terrain starts a new macrocycle; completed sessions remain history.
        val requestedObjectiveSignature = currentPlanObjectiveSignature()
        val objectiveChanged = workouts.isNotEmpty() && lastGeneratedObjectiveSignature.isNotBlank() &&
            requestedObjectiveSignature != lastGeneratedObjectiveSignature
        val shouldPreserveCycleAnchor = !objectiveChanged && (preserveCycleAnchor || workouts.isNotEmpty())
        motorError = ""
        if (goal.isBlank() || level.isBlank() || availableTrainingDays.size !in 2..6 || frequency != availableTrainingDays.size) {
            motorError = "Complete o objetivo disponível para seu nível fisiológico e a disponibilidade semanal antes de criar o plano."
            persist()
            return false
        }
        if (goal !in TrainingGoalCatalog.labelsForLevel(level)) {
            motorError = "A meta escolhida não está liberada para o nível fisiológico atual. Escolha uma meta disponível ou registre um novo teste de campo."
            persist()
            return false
        }
        when (goalIntent) {
            TrainingGoalIntent.TARGET_TIME -> if (PhysiologicalProfileEngine.parseTargetTime(goalTargetTimeText) == null) {
                motorError = "Informe um tempo-alvo válido em mm:ss ou hh:mm:ss para esta distância."
                persist()
                return false
            }
            TrainingGoalIntent.PERSONAL_BEST -> if (PhysiologicalProfileEngine.parseTargetTime(personalBestTimeText) == null) {
                motorError = "Informe seu recorde pessoal atual na distância selecionada, em mm:ss ou hh:mm:ss."
                persist()
                return false
            }
            else -> Unit
        }

        val customDistance = customGoalKm.trim().replace(",", ".").toDoubleOrNull()
        val goalKm = TrainingGoalCatalog.distanceForLabel(goal, customDistance)
        if (goalKm == null) {
            motorError = "Informe uma distância válida entre 1 e 200 km para o objetivo personalizado."
            persist()
            return false
        }
        val enteredWeeklyKm = weeklyVolumeText.trim().replace(",", ".").toDoubleOrNull()
        val enteredLongestKm = longestRecent.trim().replace(",", ".").toDoubleOrNull()
        val selectedGoalCategory = TrainingGoalCatalog.categoryForLabel(goal)
        val goalLoadReference = TrainingPlanReferenceCatalog.loadReference(goalKm, selectedGoalCategory)
        // Blank means "use the fixed baseline for this goal". A typed zero remains an
        // explicit declaration of no recent running and is never silently replaced.
        val weeklyKm = enteredWeeklyKm ?: goalLoadReference.baseWeeklyKm
        val recentKm = enteredLongestKm ?: goalLoadReference.assumedPreviousContinuousDistanceKm
        if (weeklyKm !in 0.0..300.0) {
            motorError = "Informe uma média semanal válida entre 0 e 300 km, ou deixe em branco para usar a base do objetivo."
            persist()
            return false
        }
        if (recentKm !in 0.0..200.0) {
            motorError = "Informe uma maior corrida válida entre 0 e 200 km, ou deixe em branco para usar a capacidade anterior presumida do objetivo."
            persist()
            return false
        }
        if (!saveCurrentFieldTestToHistory()) {
            persist()
            return false
        }
        level = RunnerFitnessAssessmentEngine.normalizeLevel(level)
        val latestAssessment = cooperAssessments.maxByOrNull { it.dateIso }
        val cooperDistance = latestAssessment?.takeIf { it.testMethod == "COOPER_12_MIN" }?.distanceKm
        val cooperDate = latestAssessment?.dateIso?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
        val previousCooperDistance = CooperAssessmentEngine.previousAssessmentDistance(
            cooperAssessments, cooperDate?.toString()
        )

        return try {
            val today = LocalDate.now()
            val loadSnapshot = TrainingLoadEngine.summarize(
                activities = loggedActivitiesForLoad(),
                today = today
            )
            // Promote measured four-week load only when enough real activities span
            // at least three weeks. With partial logging, keep the profile baseline and
            // use a longer recorded run as an additional tolerance bound.
            val effectiveWeeklyKm = if (loadSnapshot.reliable) {
                loadSnapshot.averageWeeklyKmLast28Days ?: weeklyKm
            } else weeklyKm
            val measuredLongestRun = loadSnapshot.longestRunLast30DaysKm?.takeIf { it > 0.0 }
            // A reliable 28-day load summary can still have no long run in its 30-day window.
            // In that case keep the explicit recent-longest baseline instead of replacing it by zero.
            val effectiveLongestKm = if (loadSnapshot.reliable) {
                measuredLongestRun ?: recentKm
            } else maxOf(recentKm, measuredLongestRun ?: 0.0)
            // When six measured runs span at least three weeks, the activity log is
            // more reliable than the onboarding estimate for both volume and consistency.
            // Otherwise keep the athlete's reported value; legacy unknown values stay unknown.
            val effectiveActiveWeeks = RunnerReadinessEngine.resolveActiveWeeks(
                reportedWeeks = -1,
                measuredWeeks = loadSnapshot.activeWeeksLast28Days.coerceIn(0, 4),
                measuredHistoryReliable = loadSnapshot.reliable
            )
            activeWeeksLast4 = effectiveActiveWeeks
            val readinessAssessment = RunnerReadinessEngine.evaluate(
                RunnerReadinessInput(
                    goalKm = goalKm,
                    goalCategory = selectedGoalCategory,
                    declaredLevel = level,
                    experienceMonths = experienceMonths(),
                    selectedFrequency = frequency,
                    weeklyVolumeKm = effectiveWeeklyKm,
                    longestRecentKm = effectiveLongestKm,
                    activeWeeksLast4 = effectiveActiveWeeks,
                    goalIntent = if (selectedGoalCategory == "HEALTH") TrainingGoalIntent.HEALTH else goalIntent,
                    targetTimeSeconds = goalTargetTimeText.takeIf { goalIntent == TrainingGoalIntent.TARGET_TIME }?.let(PhysiologicalProfileEngine::parseTargetTime),
                    terrainPreference = terrainPreference
                )
            )
            val prescriptionLevel = readinessAssessment.prescriptionLevel
            // Run/walk is an explicit beginner pathway, never a proxy for low VO2 class,
            // missing GPX history or a low weekly-volume number. For performance goals
            // of 10 km and above, the goal catalog already presumes continuous prior capacity.
            val runWalkEligible = isRunWalkEligibleForCurrentProfile(goalKm, enteredLongestKm)
            val prescribedDays = TrainingScheduleEngine.prescribedRunningDays(
                availableTrainingDays, frequency, runWalkEligible, preferredLongRunDay
            )
            val restoredCycleWindow = if (shouldPreserveCycleAnchor) {
                val savedCycleAnchor = PlanMigrationEngine.inferRestoredCycleAnchor(planStartDateIso, workouts)
                    ?.toString().orEmpty()
                PlanMigrationEngine.restoredPlanWindow(savedCycleAnchor, planWeeks, raceEvents, today)
            } else null
            val recommendedWeeks = TrainingPeriodizationEngine.recommendedPlanWeeks(
                goalKm = goalKm,
                level = readinessAssessment.prescriptionLevel,
                weeklyVolumeKm = effectiveWeeklyKm,
                longestRecentKm = effectiveLongestKm
            )
            val planWindow = restoredCycleWindow
                ?: RaceEventEngine.resolvePlanWindow(today, raceEvents, defaultWeeks = recommendedWeeks)
            val preservingOriginalCycle = restoredCycleWindow != null
            // Only a race selected inside the active planning window may change this block's
            // specific goal distance. A distant A-race remains visible but must not hijack a
            // 16-week base block or override a nearer tune-up event.
            val goalRace = planWindow.primaryRaceId
                ?.takeIf { planWindow.raceInsideWindow }
                ?.let { selectedId -> raceEvents.firstOrNull { it.id == selectedId && it.status == "PLANNED" } }
            val planningGoalKm = goalRace?.distanceKm ?: goalKm
            val effectiveGoalIntent = if (goalRace == null && selectedGoalCategory == "HEALTH") TrainingGoalIntent.HEALTH
                else if (goalRace != null) TrainingGoalIntent.TARGET_TIME.takeIf { !goalRace.targetTime.isBlank() } ?: goalIntent
                else goalIntent
            val effectiveTargetTimeSeconds = goalRace?.targetTime?.takeIf { it.isNotBlank() }?.let(PhysiologicalProfileEngine::parseTargetTime)
                ?: goalTargetTimeText.takeIf { effectiveGoalIntent == TrainingGoalIntent.TARGET_TIME }?.let(PhysiologicalProfileEngine::parseTargetTime)
            val performanceEvidence = performanceTestObservations()
            planStartDateIso = planWindow.startDate.toString()
            val currentZones = currentPaceZones()
            rememberZoneBoundaries(currentZones)
            val input = RunnerInput(
                goalKm = planningGoalKm,
                level = RunnerFitnessAssessmentEngine.normalizeLevel(level),
                frequency = frequency,
                availableDays = availableTrainingDays,
                preferredLongRunDay = preferredLongRunDay,
                weeklyVolumeKm = effectiveWeeklyKm,
                longestRecentKm = effectiveLongestKm,
                runWalkEligible = runWalkEligible,
                painPresent = recentFeedback().takeLast(3).any { it.painPresent },
                recoveryScore = deriveRecoveryScore(),
                fatigueScore = deriveFatigueScore(),
                planWeeks = planWindow.weeks,
                cooperDistanceKm = cooperDistance,
                cooperAssessmentDateIso = cooperDate?.toString(),
                previousCooperDistanceKm = previousCooperDistance,
                talkTestComfortPaceValues = emptyList(),
                calibratedPaceZones = currentZones,
                recentActivityCount = loadSnapshot.recordedRunsLast28Days,
                recentActivityHistoryReliable = loadSnapshot.reliable,
                // Any explicitly entered positive volume + longest-run pair confirms the
                // athlete's stated baseline. It does not confirm consistency; only measured
                // activity history can establish distinct active weeks.
                // Goal defaults are explicit planning assumptions when fields are blank;
                // positive actual values override them. Typed zero remains a true no-running signal.
                profileBaselineConfirmed = effectiveWeeklyKm > 0.0 && effectiveLongestKm > 0.0 &&
                    enteredWeeklyKm?.let { it > 0.0 } != false && enteredLongestKm?.let { it > 0.0 } != false,
                experienceMonths = experienceMonths(),
                activeWeeksLast4 = effectiveActiveWeeks,
                startDate = planWindow.startDate,
                goalCategory = if (goalRace != null) "PERFORMANCE" else TrainingGoalCatalog.categoryForLabel(goal),
                goalIntent = effectiveGoalIntent,
                targetTimeSeconds = effectiveTargetTimeSeconds,
                personalBestTimeSeconds = personalBestTimeText.takeIf {
                    effectiveGoalIntent == TrainingGoalIntent.PERSONAL_BEST &&
                        (goalRace == null || kotlin.math.abs(goalRace.distanceKm - goalKm) < 0.01)
                }?.let(PhysiologicalProfileEngine::parseTargetTime),
                terrainPreference = terrainPreference,
                performanceTests = performanceEvidence,
                measuredSessionRpeLoad7Days = loadSnapshot.sessionRpeLoadLast7Days,
                measuredSessionRpeLoad28Days = loadSnapshot.sessionRpeLoadLast28Days,
                measuredDurationMinutes7Days = loadSnapshot.durationMinutesLast7Days,
                measuredDurationMinutes28Days = loadSnapshot.durationMinutesLast28Days,
                measuredAverageRpe28Days = loadSnapshot.averageRpeLast28Days
            )
            val plan = RunningCoachEngine.generate(input)
            // A backup is an authoritative snapshot of what was actually scheduled.
            // Rebuild the original cycle from its anchor, but regenerate only today and
            // future dates. Historical sessions are preserved exclusively from the file:
            // the migration must never invent a past workout absent from that backup.
            // Reapply manual dates to the FULL regenerated cycle before filtering by
            // today. A session originally planned for Monday but moved to Sunday must
            // survive a Wednesday recalibration; filtering its original Monday date
            // first would discard it before the saved move can be restored.
            val previousManualDates = workouts.filter { it.manuallyRescheduled && !it.done }
                .associateBy { it.sessionId }
            val manuallyPlacedFullPlan = PlanMigrationEngine.reapplyManualRescheduleDates(
                sessions = plan.workouts,
                previousManual = previousManualDates,
                today = today
            )
            val remainingCycleSessions = PlanMigrationEngine.currentAndFutureCycleSessions(
                sessions = manuallyPlacedFullPlan,
                today = today,
                cycleStart = planWindow.startDate.takeIf { preservingOriginalCycle },
                cycleWeeks = planWindow.weeks.takeIf { preservingOriginalCycle }
            )
            // Manually moved sessions now carry their chosen dates before race adjustments.
            // Only active/future sessions receive competition taper and intensity-band
            // adjustments. Manually moved sessions are protected from silent replacement.
            val raceAdjustment = RaceEventEngine.applyToPlan(
                workouts = remainingCycleSessions,
                events = raceEvents,
                planStartDate = planWindow.startDate,
                frequency = prescribedDays.size,
                zones = currentZones,
                today = today,
                protectedSessionIds = previousManualDates.keys
            )

            // Ordinary and restored plans both regenerate only today/future sessions;
            // restored history comes only from the authoritative backup snapshot.
            val currentWeekStart = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            val bandAdjustedWorkouts = raceAdjustment.workouts.map { ZoneIntensityBandEngine.apply(it) }
            val upcomingPlanSessions = if (preservingOriginalCycle) {
                bandAdjustedWorkouts.map { prescribed ->
                    val date = LocalDate.parse(prescribed.scheduledDateIso)
                    prescribed.copy(week = RaceEventEngine.weekIndex(date, planWindow.startDate))
                }.sortedBy { it.scheduledDateIso }
            } else {
                TrainingScheduleEngine.keepUpcomingSessionsForCurrentWeek(
                    bandAdjustedWorkouts, today, planWindow.startDate
                )
            }
            val racePlanWarningsCombined = raceAdjustment.warnings
            racePlanWarnings = racePlanWarningsCombined
            racePlanNote = buildString {
                append(planWindow.note)
                goalRace?.let { append(" Objetivo específico do ciclo: ${it.name}, ${formatKmUi(it.distanceKm)} km.") }
                if (raceAdjustment.replacedSessionIds.isNotEmpty()) {
                    append(" ${raceAdjustment.replacedSessionIds.size} sessão(ões) substituída(s) por competição; taper e recuperação foram ajustados.")
                }
                if (raceAdjustment.taperedSessionIds.isNotEmpty()) {
                    append(" As sessões próximas da prova tiveram carga reduzida.")
                }
                if (preservingOriginalCycle) {
                    append(" O ciclo do backup foi atualizado desde ${planWindow.startDate.format(DateTimeFormatter.ofPattern("dd/MM"))}; a numeração original foi mantida e somente hoje/datas futuras foram regeneradas. O histórico anterior permanece exatamente como estava no arquivo.")
                } else {
                    append(" A semana atual começa em ${currentWeekStart.format(DateTimeFormatter.ofPattern("dd/MM"))}; sessões anteriores a hoje não são recriadas e os próximos treinos permanecem na semana correta.")
                }
            }
            motorState = plan.state
            motorDecision = plan.decision
            motorExplanation = plan.explanation
            if (plan.decision.safety == "RED") {
                // Preserve the previous cycle so the athlete can review/update the pain feedback
                // after recovery; a blocked generation must not erase the only way to do that.
                motorError = "Nova prescrição bloqueada por relato de dor. O plano anterior foi preservado; atualize o feedback somente quando estiver sem dor."
                onboardingStep = 8
                resetNavigation(Screen.DASHBOARD)
                persist()
                return false
            }
            if (plan.workouts.isEmpty()) {
                motorError = "O motor terminou sem gerar sessões."
                persist()
                return false
            }
            val recordedSessionIds = feedbackRecords.map { it.sessionId }.toSet()
            // Completed records and optional one-off sessions survive a plan migration.
            val completedBeforeRecalibration = PlanMigrationEngine.preserveHistoryAndCompleted(workouts, recordedSessionIds, today)
            val completedIds = completedBeforeRecalibration.map { it.sessionId }.toSet()
            // Core plan sessions take priority over a still-pending optional extra if both
            // land on the same date after a profile/availability recalculation.
            val weeklyTargetsByWeek = plan.weeklySummaries.associate { it.week to it.targetKm }
            val generatedWorkouts = PlanMigrationEngine.excludeCompletedSessionIdentities(
                upcomingPlanSessions, completedBeforeRecalibration
            ).map { p ->
                val previousManual = previousManualDates[p.sessionId]
                val generatedDate = runCatching { LocalDate.parse(p.scheduledDateIso) }.getOrNull()
                val manualDate = previousManual?.let { runCatching { LocalDate.parse(it.scheduledDateIso) }.getOrNull() }
                val keepManual = generatedDate != null && manualDate != null && !manualDate.isBefore(today) &&
                    generatedDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)) == manualDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
                val finalDate = if (keepManual) manualDate!! else generatedDate
                val finalDateLabel = finalDate?.let { d -> "${d.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, Locale.forLanguageTag("pt-BR")).replaceFirstChar { it.uppercase(Locale.forLanguageTag("pt-BR")) }}, ${d.format(DateTimeFormatter.ofPattern("dd/MM"))}" } ?: p.date
                Workout(
                    date = finalDateLabel, scheduledDateIso = finalDate?.toString() ?: p.scheduledDateIso, title = p.title, detail = p.detail, type = p.type,
                    objective = p.objective, stimulus = p.stimulus, distanceKm = p.distanceKm,
                    sessionId = p.sessionId, durationMin = p.durationMin, intensity = p.intensity,
                    paceMode = p.paceMode, rpeRange = p.rpeRange, rationale = p.rationale,
                    week = p.week, phase = p.phase, segments = p.segments,
                    paceCalibrationSnapshot = p.paceCalibrationSnapshot,
                    manuallyRescheduled = keepManual,
                    originalScheduledDateIso = if (keepManual) (previousManual?.originalScheduledDateIso ?: p.scheduledDateIso) else "",
                    weeklyTargetKm = weeklyTargetsByWeek[p.week],
                    experienceMonths = p.experienceMonths
                )
            }
            // If a regenerated plan no longer emits a previously moved session ID,
            // retain the saved session instead of silently deleting the athlete's move.
            val regeneratedIds = generatedWorkouts.map { it.sessionId }.toSet()
            val orphanedManualSessions = previousManualDates.values.filter { it.sessionId !in regeneratedIds && it.sessionId !in completedIds }
            val generatedDates = generatedWorkouts.mapNotNull { runCatching { LocalDate.parse(it.scheduledDateIso) }.getOrNull() }.toSet()
            val optionalExtrasToKeep = PlanMigrationEngine.pendingOptionalExtras(workouts, today, recordedSessionIds)
                .filter { extra -> runCatching { LocalDate.parse(extra.scheduledDateIso) }.getOrNull() !in generatedDates }
            workouts = PlanMigrationEngine.merge(completedBeforeRecalibration, optionalExtrasToKeep, orphanedManualSessions + generatedWorkouts)
            if (preservingOriginalCycle) {
                workouts = PlanMigrationEngine.normalizeCycleWeekNumbers(workouts, planWindow.startDate)
            }
            if (loadSnapshot.reliable) {
                weeklyVolumeText = String.format(Locale.US, "%.1f", effectiveWeeklyKm)
                longestRecent = String.format(Locale.US, "%.1f", effectiveLongestKm)
            }
            if (cooperEnabled && cooperDistance != null) {
                val record = cooperDate?.let { CooperAssessmentEngine.createRecord(cooperDistance, it, emptyList(), currentZones) }
                if (record != null) {
                    cooperAssessments = (cooperAssessments.filterNot { it.dateIso == record.dateIso } + record)
                        .sortedBy { it.dateIso }
                }
            }
            motorError = ""
            // Preserve the exact cycle duration stored in the backup. Summary-card count
            // can be lower when a generated week contains no running session (e.g. race/recovery).
            planWeeks = planWindow.weeks
            syncTargetDate()
            needsEngineRefresh = false
            needsPacePlanRefresh = false
            lastGeneratedObjectiveSignature = requestedObjectiveSignature
            prefs.edit().putInt("engineVersion", CURRENT_ENGINE_VERSION)
                .putString("lastPlanObjectiveSignature", requestedObjectiveSignature)
                .putBoolean("needsEngineRefresh", false).apply()
            selectedWorkoutIndex = 0
            resetNavigation(Screen.DASHBOARD)
            onboardingStep = 8
            persist()
            true
        } catch (e: Exception) {
            motorError = "Erro ao executar o motor: ${e.message ?: "erro desconhecido"}"
            persist()
            false
        }
    }

    fun selectedWorkoutBase(): Workout? = workouts.getOrNull(selectedWorkoutIndex)

    fun selectedWorkout(): Workout? {
        val base = selectedWorkoutBase() ?: return null
        val selected = if (base.selectedOption == "ALTERNATIVE") WorkoutAlternativeEngine.createAlternative(base, runWalkAllowedForCurrentProfile(), qualityReplacementCanPreserveStimulus()) else base
        return ZoneIntensityBandEngine.apply(selected)
    }

    fun selectWorkoutOption(sessionId: String, option: String) {
        if (option !in setOf("PRIMARY", "ALTERNATIVE")) return
        val index = workouts.indexOfFirst { it.sessionId == sessionId }
        if (index < 0 || workouts[index].done) return
        workouts = workouts.map { if (it.sessionId == sessionId) it.copy(selectedOption = option) else it }
        selectedWorkoutIndex = index
        persist()
    }

    private fun zoneCalibrationEvidence(extraCooper: CooperPerformanceEvidence? = null): ZoneCalibrationEvidence {
        val today = LocalDate.now()
        val cutoff = today.minusDays(42)
        fun validDate(record: FeedbackRecord): LocalDate? = feedbackActivityDate(record).takeIf { !it.isBefore(cutoff) && !it.isAfter(today) }
        fun recordedPace(record: FeedbackRecord): Int? = PaceRange.parsePace(record.actualPaceMinKm.orEmpty())
            ?: run {
                val distance = record.actualDistanceKm ?: return@run null
                val duration = PaceCalculator.parseDuration(record.actualDuration.orEmpty()) ?: return@run null
                PaceCalculator.paceFromDistanceAndDuration(distance, duration)
            }
        val recovery = feedbackRecords.mapNotNull { record ->
            val date = validDate(record) ?: return@mapNotNull null
            val sessionType = record.workoutType.ifBlank {
                workouts.firstOrNull { it.sessionId == record.sessionId }?.type.orEmpty()
            }
            val isRecovery = ZoneCalibrationEngine.isRecoveryWorkoutType(sessionType)
            if (!isRecovery || record.painPresent || record.effort !in setOf("Muito leve", "Leve") ||
                record.feeling !in setOf("Ótimo", "Bem")) return@mapNotNull null
            val pace = recordedPace(record) ?: return@mapNotNull null
            ZoneObservation(date.toString(), pace)
        }.distinctBy { it.dateIso }.sortedBy { it.dateIso }.takeLast(8)
        // Legacy talk-test entries remain readable for backup compatibility but no longer calibrate Z2.
        val talk = emptyList<ZoneObservation>()
        val tests = (cooperAssessments.filter { it.testMethod == "COOPER_12_MIN" }.map { CooperPerformanceEvidence(it.dateIso, it.distanceKm) } + listOfNotNull(extraCooper))
            .distinctBy { it.dateIso }.sortedBy { it.dateIso }
        return ZoneCalibrationEvidence(recovery, talk, tests)
    }

    private fun personalizeZones(base: TrainingPaceZones?, extraCooper: CooperPerformanceEvidence? = null): TrainingPaceZones? {
        if (base == null) return null
        return ZoneCalibrationEngine.apply(base, zoneCalibrationEvidence(extraCooper), lastZoneBoundarySnapshot)
    }

    private fun rememberZoneBoundaries(zones: TrainingPaceZones?) {
        if (zones != null) lastZoneBoundarySnapshot = ZoneCalibrationEngine.boundaryValues(zones)
    }

    fun currentPaceZones(): TrainingPaceZones? {
        if (fitnessTestMethod == "THREE_KM") {
            return selectedFieldTestZones() ?: cooperAssessments.lastOrNull { it.testMethod == "THREE_KM" }?.let { record ->
                val time = record.testDurationSeconds ?: return@let null
                PaceCalculator.calculateThreeKm(time, record.referenceSex)
            }?.let(::personalizeZones)
        }
        val profileDistance = if (cooperEnabled && fitnessTestMethod == "COOPER_12_MIN") cooperDistanceText.trim().replace(",", ".").toDoubleOrNull() else null
        val cooperDistance = profileDistance ?: cooperAssessments.lastOrNull { it.testMethod == "COOPER_12_MIN" }?.distanceKm
        val currentDateIso = if (cooperEnabled) parsedCooperAssessmentDate()?.toString() else cooperAssessments.lastOrNull { it.testMethod == "COOPER_12_MIN" }?.dateIso
        val previousDistance = CooperAssessmentEngine.previousAssessmentDistance(cooperAssessments, currentDateIso, "COOPER_12_MIN")
        val smooth = PaceCalculator.limitCalibrationChange(
            PaceCalculator.calculateCooper(cooperDistance),
            PaceCalculator.calculateCooper(previousDistance),
            maxBoundaryShiftSeconds = 15
        )
        return personalizeZones(smooth)
    }

    /** Preview uses the same independent evidence gates that are saved and applied to the plan. */
    fun calculateZonesForCooper(distanceKm: Double?): TrainingPaceZones? {
        val assessmentDate = parsedCooperAssessmentDate()?.toString() ?: LocalDate.now().toString()
        val previousDistance = CooperAssessmentEngine.previousAssessmentDistance(cooperAssessments, assessmentDate)
        val smooth = PaceCalculator.limitCalibrationChange(
            PaceCalculator.calculateCooper(distanceKm),
            PaceCalculator.calculateCooper(previousDistance),
            maxBoundaryShiftSeconds = 15
        )
        return personalizeZones(smooth, if (distanceKm != null) CooperPerformanceEvidence(assessmentDate, distanceKm) else null)
    }

    /** Rebuilds future sessions from the saved athlete profile and current calibrated zones. */
    fun recalibratePlan(): Boolean {
        if (currentPaceZones() == null) {
            motorError = "Registre um teste fisiológico válido antes de calibrar o plano."
            latestCooperMessage = motorError
            persist()
            navigateTo(Screen.COOPER_TEST)
            return false
        }
        val updated = createPlan()
        if (updated) {
            latestCooperMessage = "Plano recalibrado. As sessões concluídas e os feedbacks anteriores foram preservados."
            latestFeedbackHeadline = "Calibração aplicada"
            latestFeedbackAdvice = "As próximas sessões foram recalculadas com as zonas atuais e os limites de progressão conservadora."
            needsPacePlanRefresh = false
            needsEngineRefresh = false
            persist(synchronous = true)
        }
        return updated
    }

    fun feedbackForSession(sessionId: String): FeedbackRecord? = feedbackRecords.lastOrNull { it.sessionId == sessionId }

    fun orphanFeedbackRecords(): List<FeedbackRecord> {
        val workoutIds = workouts.map { it.sessionId }.toSet()
        return feedbackRecords.filter { it.sessionId !in workoutIds }
    }

    /** V78 no longer uses talk-test pace entries for zone calibration; legacy backups remain readable. */
    /** Zone-specific execution evidence collected from manually completed prescribed blocks. */
    fun zoneExecutionSummary(): List<ZoneExecutionSummary> {
        val observations = feedbackRecords.flatMap { record ->
            record.blockPaceFeedback.mapIndexedNotNull { sequenceIndex, block ->
                val zone = block.targetZone ?: return@mapIndexedNotNull null
                val actual = block.actualPaceSecondsPerKm ?: return@mapIndexedNotNull null
                val fastest = block.targetFastestPaceSecondsPerKm ?: return@mapIndexedNotNull null
                val slowest = block.targetSlowestPaceSecondsPerKm ?: return@mapIndexedNotNull null
                ZoneExecutionObservation(
                    sessionId = record.sessionId,
                    dateIso = feedbackActivityDate(record).toString(),
                    zone = zone,
                    actualPaceSecondsPerKm = actual,
                    targetFastestPaceSecondsPerKm = fastest,
                    targetSlowestPaceSecondsPerKm = slowest,
                    effort = record.effort,
                    feeling = record.feeling,
                    painPresent = record.painPresent,
                    sequenceOrder = sequenceIndex
                )
            }
        }
        return WorkoutBlockFeedbackEngine.summary(observations)
    }

    fun zoneReviewSignature(summary: ZoneExecutionSummary): String = listOf(
        summary.zone, summary.observationCount, summary.sessionCount, summary.fasterCount,
        summary.preciseCount, summary.slowerCount, summary.meanActualPaceSecondsPerKm,
        summary.meanTargetPaceSecondsPerKm
    ).joinToString("-")

    fun zoneReviewDecision(summary: ZoneExecutionSummary): String? {
        val stored = zoneReviewDecisions[summary.zone] ?: return null
        val prefix = "${zoneReviewSignature(summary)}|"
        return stored.removePrefix(prefix).takeIf { stored.startsWith(prefix) }
    }

    fun recordZoneReviewDecision(summary: ZoneExecutionSummary, decision: String) {
        zoneReviewDecisions = zoneReviewDecisions + (summary.zone to "${zoneReviewSignature(summary)}|$decision")
        persist(synchronous = true)
    }

    /** Uses the saved zone snapshot for that completed session; never reclassifies old runs with today's zones. */
    fun measuredZoneTimeForRecord(record: FeedbackRecord): Map<String, Int> {
        if (record.measuredZoneTimeSeconds.isNotEmpty()) return record.measuredZoneTimeSeconds
        val snapshot = workouts.lastOrNull { it.sessionId == record.sessionId }?.paceCalibrationSnapshot ?: return emptyMap()
        val frozenZones = snapshot.zoneRanges.mapNotNull { (id, label) ->
            if (id !in setOf("Z1", "Z2", "Z3", "Z4", "Z5")) return@mapNotNull null
            val rangeText = label.substringBefore(" min/km").trim()
            val parts = rangeText.split('–', '-')
            if (parts.size != 2) return@mapNotNull null
            val fast = PaceRange.parsePace(parts[0].trim()) ?: return@mapNotNull null
            val slow = PaceRange.parsePace(parts[1].trim()) ?: return@mapNotNull null
            runCatching { PaceZone(id, id, "", PaceRange(fast, slow), "") }.getOrNull()
        }
        if (frozenZones.isEmpty()) return emptyMap()
        val recordedSegments = record.recordedPaceSegments.ifEmpty {
            record.splitDetails.mapNotNull { split ->
                if (split.sourceType == "ACTIVITY_REMAINDER_ESTIMATED") return@mapNotNull null
                val pace = split.paceSecondsPerKm ?: return@mapNotNull null
                val duration = split.durationSeconds ?: return@mapNotNull null
                ActivityPaceSegment(
                    paceSecondsPerKm = pace, durationSeconds = duration,
                    distanceMeters = split.distanceMeters, sourceType = when (split.sourceType) {
                        "EXPLICIT_LAP", "EXPLICIT_LAP_AGGREGATED", "LAP_RECONSTRUCTED" -> split.sourceType
                        "TRACK_POINT" -> "TRACK_SPLIT_RECONSTRUCTED"
                        else -> return@mapNotNull null
                    }
                )
            }
        }
        return ActivityZoneTimeEngine.summarize(recordedSegments, frozenZones)
    }

    fun cooperReviewStatus() = CooperAssessmentEngine.reviewStatus(cooperAssessments)

    fun saveCurrentFieldTestToHistory(): Boolean {
        if (fitnessTestMethod == "NONE") {
            level = "Iniciante" // internal conservative starting guardrail; not a tested class
            if (goal.isNotBlank() && goal !in TrainingGoalCatalog.labelsForLevel(level)) goal = ""
            persist()
            return true
        }
        if (recentFeedback().takeLast(3).any { it.painPresent } || deriveRecoveryScore()?.let { it < 50.0 } == true) {
            motorError = "A avaliação foi suspensa porque há sinais recentes de dor ou recuperação insuficiente. Refaça o teste quando estiver recuperado."
            return false
        }
        if (!isCooperEntryValid()) {
            motorError = if (fitnessTestMethod == "THREE_KM") {
                "Para o teste de 3 km, confirme que a idade do perfil na data do teste está entre 18 e 39 anos, selecione a referência fisiológica e informe um tempo mm:ss válido."
            } else "Confira a idade do perfil, a referência fisiológica, a distância do Cooper (1,00–5,00 km) e a data do teste."
            return false
        }
        val date = parsedCooperAssessmentDate() ?: return false
        val zones = selectedFieldTestZones() ?: return false
        val age = ageAtDate(date) ?: return false
        val record = when (fitnessTestMethod) {
            "COOPER_12_MIN" -> CooperAssessmentEngine.createRecord(
                cooperDistanceText.trim().replace(",", ".").toDoubleOrNull() ?: return false,
                date = date, talkTestComfortPaces = emptyList(), zonesOverride = zones,
                referenceSex = referenceSex, ageAtTest = age
            )
            "THREE_KM" -> CooperAssessmentEngine.createThreeKmRecord(
                RunnerFitnessAssessmentEngine.parseDurationSeconds(threeKmTimeText) ?: return false,
                date = date, referenceSex = referenceSex, ageAtTest = age, zonesOverride = zones
            )
            else -> null
        } ?: return false
        cooperAssessments = (cooperAssessments.filterNot { it.dateIso == record.dateIso && it.testMethod == record.testMethod } + record)
            .sortedWith(compareBy<CooperAssessmentRecord> { it.dateIso }.thenBy { it.testMethod })
        cooperEnabled = true
        level = RunnerFitnessAssessmentEngine.assess(record.estimatedVo2Max, age, referenceSex, "FIELD_ESTIMATE")?.level ?: return false
        if (goal.isNotBlank() && goal !in TrainingGoalCatalog.labelsForLevel(level)) goal = ""
        if (fitnessTestMethod == "COOPER_12_MIN") cooperDistanceText = String.format(Locale.US, "%.2f", record.distanceKm).replace(".", ",")
        cooperAssessmentDateText = date.format(DateTimeFormatter.ofPattern("dd/MM/uuuu"))
        latestCooperMessage = "Avaliação salva. VO₂máx estimado: ${String.format(Locale.US, "%.1f", record.estimatedVo2Max)}. Nível fisiológico: $level."
        persist(synchronous = true)
        return true
    }

    fun attachDemographicsToLatestTest(): Boolean {
        val latest = cooperAssessments.maxByOrNull { it.dateIso } ?: return false
        val testDate = runCatching { LocalDate.parse(latest.dateIso) }.getOrNull()
        val age = testDate?.let(::ageAtDate) ?: parsedAgeYears()
            ?: run { motorError = "Informe a data de nascimento ou a idade atual no perfil do atleta."; return false }
        if (referenceSex !in setOf(RunnerFitnessAssessmentEngine.MALE, RunnerFitnessAssessmentEngine.FEMALE)) {
            motorError = "Selecione a referência fisiológica usada no teste."; return false
        }
        val assessed = RunnerFitnessAssessmentEngine.assess(latest.estimatedVo2Max, age, referenceSex, "FIELD_ESTIMATE")
            ?: run { motorError = "Não foi possível classificar esse resultado com os dados informados."; return false }
        cooperAssessments = cooperAssessments.map { record ->
            if (record.dateIso == latest.dateIso && record.testMethod == latest.testMethod) {
                record.copy(ageAtTest = age, referenceSex = referenceSex)
            } else record
        }
        val previousLevel = level
        level = assessed.level
        if (goal.isNotBlank() && goal !in TrainingGoalCatalog.labelsForLevel(level)) goal = ""
        if (workouts.isNotEmpty() && previousLevel != assessed.level) {
            needsEngineRefresh = true
            racePlanNote = "A faixa fisiológica foi completada para o teste salvo. Revise a meta e recalcule somente as sessões futuras."
        }
        latestCooperMessage = "Dados demográficos do perfil vinculados ao teste já salvo. VO₂máx ${String.format(Locale.US, "%.1f", assessed.vo2Max)} • nível ${assessed.level}."
        historicalTestAgeText = ""
        motorError = ""
        persist(synchronous = true)
        return true
    }

    fun openFieldTestEditor() {
        val latest = cooperAssessments.maxByOrNull { it.dateIso }
        fitnessTestMethod = latest?.testMethod ?: "COOPER_12_MIN"
        referenceSex = referenceSex.ifBlank { latest?.referenceSex.orEmpty() }
        // A new test starts with an empty result and today's date; the previous attempt stays in history.
        if (fitnessTestMethod == "THREE_KM") threeKmTimeText = "" else cooperDistanceText = ""
        cooperAssessmentDateText = LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/uuuu"))
        latestCooperMessage = ""
        motorError = ""
        cooperEnabled = true
        navigateTo(Screen.COOPER_TEST)
    }

    fun saveSelectedFieldTestAndReplan(): Boolean {
        if (!saveCurrentFieldTestToHistory()) {
            persist()
            return false
        }
        val profileReady = goal.isNotBlank() && goal in TrainingGoalCatalog.labelsForLevel(level) &&
            availableTrainingDays.size in 2..6 && frequency == availableTrainingDays.size
        if (!profileReady) {
            needsEngineRefresh = workouts.isNotEmpty()
            latestCooperMessage = "Teste salvo. Seu nível fisiológico foi atualizado; escolha uma meta disponível para esse nível antes de recalcular o plano."
            persist()
            return true
        }
        val success = createPlan()
        if (!success) {
            latestCooperMessage = "Teste salvo. O plano anterior foi preservado: ${motorError.ifBlank { "revise os dados do perfil" }}"
            persist()
        }
        return success
    }

    fun saveCooperAndReplan(distanceText: String): Boolean {
        if (recentFeedback().takeLast(3).any { it.painPresent }) {
            latestCooperMessage = "O teste não foi salvo: existe relato recente de dor. Não faça um teste máximo enquanto houver dor; retome a avaliação somente após recuperação adequada."
            persist()
            return false
        }
        if (deriveRecoveryScore()?.let { it < 50.0 } == true) {
            latestCooperMessage = "O teste não foi salvo: os feedbacks recentes indicam recuperação insuficiente. Descanse e reavalie quando estiver recuperado."
            persist()
            return false
        }
        val distanceKm = distanceText.trim().replace(",", ".").toDoubleOrNull()
        val assessmentDateIso = LocalDate.now().toString()
        val previousDistance = CooperAssessmentEngine.previousAssessmentDistance(cooperAssessments, assessmentDateIso)
        val smoothBase = PaceCalculator.limitCalibrationChange(
            PaceCalculator.calculateCooper(distanceKm),
            PaceCalculator.calculateCooper(previousDistance),
            maxBoundaryShiftSeconds = 15
        )
        val smoothedZones = personalizeZones(
            smoothBase,
            distanceKm?.let { CooperPerformanceEvidence(assessmentDateIso, it) }
        )
        val assessmentDate = LocalDate.parse(assessmentDateIso)
        val assessmentAge = ageAtDate(assessmentDate)
        val record = distanceKm?.let { CooperAssessmentEngine.createRecord(
            it, date = assessmentDate, talkTestComfortPaces = emptyList(), zonesOverride = smoothedZones,
            referenceSex = referenceSex, ageAtTest = assessmentAge
        ) }
        if (record == null) {
            latestCooperMessage = "Distância inválida. Informe o total percorrido em quilômetros no teste de 12 minutos."
            persist()
            return false
        }
        cooperEnabled = true
        cooperDistanceText = String.format(Locale.US, "%.2f", record.distanceKm).replace(".", ",")
        cooperAssessmentDateText = record.dateIso.let { LocalDate.parse(it).format(DateTimeFormatter.ofPattern("dd/MM/uuuu")) }
        val history = cooperAssessments.filterNot { it.dateIso == record.dateIso } + record
        cooperAssessments = history.sortedBy { it.dateIso }
        latestCooperMessage = "Cooper salvo. As zonas foram recalculadas com a nova avaliação."
        persist()
        val profileReady = goal.isNotBlank() && level.isNotBlank() && availableTrainingDays.size in 2..6 && frequency == availableTrainingDays.size
        if (!profileReady) {
            rememberZoneBoundaries(smoothedZones)
            latestCooperMessage = "Cooper salvo e zonas atualizadas. Complete os dados do atleta para gerar ou recalcular o plano."
            persist()
            return true
        }
        val success = createPlan()
        if (!success) {
            rememberZoneBoundaries(smoothedZones)
            latestCooperMessage = "Teste salvo e zonas atualizadas. O plano anterior foi preservado: ${motorError.ifBlank { "revise o perfil e a recuperação" }}"
            persist()
        }
        return success
    }

    fun completedWorkouts(): List<Workout> {
        val savedFeedbackIds = feedbackRecords.map { it.sessionId }.toSet()
        return workouts.filter { it.done || it.sessionId in savedFeedbackIds }.map { workout ->
            if (workout.sessionId in savedFeedbackIds && !workout.done) workout.copy(done = true) else workout
        }
    }

    /** One source of truth for the week shown on Dashboard and Plan. */
    fun currentPlanWeekNumber(date: LocalDate = LocalDate.now()): Int? {
        val anchor = runCatching { LocalDate.parse(planStartDateIso) }.getOrNull() ?: return null
        val week = TrainingScheduleEngine.weekNumberForDate(anchor, date)
        return week.takeIf { it in 1..planWeeks }
    }

    /** Active cycle plus the current partial week; older completed cycles stay in history/calendar only. */
    fun activePlanWorkouts(): List<Workout> {
        val planStart = runCatching { LocalDate.parse(planStartDateIso) }.getOrNull() ?: return workouts
        val visibleFrom = if (planStart.isAfter(LocalDate.now())) planStart.minusWeeks(1) else planStart
        return workouts.filter { workout ->
            val date = runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull() ?: return@filter false
            !date.isBefore(visibleFrom)
        }
    }

    fun importedActivityUsedElsewhere(fingerprint: String, sessionId: String): Boolean =
        feedbackRecords.any { it.activityFingerprint == fingerprint && it.sessionId != sessionId }

    fun saveFeedback(
        effort: String,
        feeling: String,
        notes: String,
        painPresent: Boolean,
        actualDistanceText: String,
        actualDurationText: String,
        blockPaceFeedback: List<WorkoutBlockPaceFeedback>,
        importedActivity: ImportedActivity? = null,
        terrain: String = terrainPreference,
        raceEventId: String = ""
    ): Boolean {
        val current = selectedWorkout() ?: run {
            motorError = "Não foi possível localizar a sessão. Abra o treino novamente pelo calendário."
            persist()
            return false
        }
        if (workouts.none { it.sessionId == current.sessionId }) {
            motorError = "A sessão não pertence mais ao plano salvo. Atualize o calendário e tente novamente."
            persist()
            return false
        }
        val previousForSession = feedbackForSession(current.sessionId)
        val manualDistanceKm = actualDistanceText.trim().replace(",", ".").toDoubleOrNull()?.takeIf { it > 0.0 && it <= 200.0 }
        val enteredDurationSeconds = PaceCalculator.parseDuration(actualDurationText)
        // Preserve the importer's full precision while the displayed (rounded) value
        // is unchanged. If the athlete edits a metric, use that correction consistently.
        val importedDistanceDisplay = importedActivity?.distanceKm?.let { formatKmUi(it).replace(",", ".").toDoubleOrNull() }
        val importedDistanceEdited = importedActivity != null && manualDistanceKm != null && importedDistanceDisplay != null &&
            kotlin.math.abs(manualDistanceKm - importedDistanceDisplay) > 0.00001
        val previousWasImported = !previousForSession?.activityFingerprint.isNullOrBlank()
        val linkedRaceDateIso = raceEvents.firstOrNull { it.id == raceEventId }?.dateOrNull()?.toString()
        val previousDistanceDisplay = previousForSession?.actualDistanceKm?.let { formatKmUi(it).replace(",", ".").toDoubleOrNull() }
        val previousDistanceUnchanged = importedActivity == null && previousWasImported && manualDistanceKm != null &&
            previousDistanceDisplay != null && kotlin.math.abs(manualDistanceKm - previousDistanceDisplay) <= 0.00001
        val actualDistanceKm = when {
            importedActivity != null && !importedDistanceEdited -> importedActivity.distanceKm ?: manualDistanceKm
            importedDistanceEdited -> manualDistanceKm
            previousDistanceUnchanged -> previousForSession?.actualDistanceKm
            else -> manualDistanceKm
        }
        val importedElapsedSeconds = importedActivity?.elapsedSeconds
        val importedDurationEdited = importedElapsedSeconds != null && enteredDurationSeconds != null &&
            enteredDurationSeconds != importedElapsedSeconds
        val previousDurationSeconds = previousForSession?.actualDuration?.let(PaceCalculator::parseDuration)
        val previousDurationUnchanged = importedActivity == null && previousWasImported && previousDurationSeconds != null &&
            enteredDurationSeconds == previousDurationSeconds
        val actualDurationSeconds = when {
            importedActivity != null && importedElapsedSeconds != null && !importedDurationEdited -> importedElapsedSeconds
            importedActivity != null && importedDurationEdited -> enteredDurationSeconds
            importedActivity != null -> enteredDurationSeconds
            previousDurationUnchanged -> previousDurationSeconds
            else -> enteredDurationSeconds
        }
        val actualDurationForRecord = when {
            importedActivity != null && importedElapsedSeconds != null && !importedDurationEdited -> importedElapsedSeconds.let(PaceRange::formatDuration)
            importedActivity != null -> actualDurationText.takeIf { enteredDurationSeconds != null }
            previousDurationUnchanged -> previousForSession?.actualDuration
            else -> actualDurationText.takeIf { enteredDurationSeconds != null }
        }
        val actualPace = when {
            importedActivity?.averagePaceMmSs != null && !importedDistanceEdited && !importedDurationEdited -> importedActivity.averagePaceMmSs
            importedActivity == null && previousDistanceUnchanged && previousDurationUnchanged -> previousForSession?.actualPaceMinKm
            actualDistanceKm != null && actualDurationSeconds != null -> PaceCalculator.paceFromDistanceAndDuration(actualDistanceKm, actualDurationSeconds)?.let { PaceRange.format(it) }
            else -> null
        }
        val duplicate = importedActivity?.let { activity ->
            feedbackRecords.firstOrNull { it.activityFingerprint == activity.fingerprint && it.sessionId != current.sessionId }
        }
        if (duplicate != null) {
            motorError = "Esta atividade já está vinculada a outra sessão. Ela não será duplicada no histórico."
            persist()
            return false
        }
        val previousWorkouts = workouts
        val previousFeedbackRecords = feedbackRecords
        val previousRaceEvents = raceEvents
        val previousNeedsEngineRefresh = needsEngineRefresh
        val previousNeedsPacePlanRefresh = needsPacePlanRefresh
        val previousFeedbackHeadline = latestFeedbackHeadline
        val previousFeedbackAdvice = latestFeedbackAdvice
        workouts = workouts.map { workout ->
            if (workout.sessionId == current.sessionId) workout.copy(done = true) else workout
        }
        val record = FeedbackRecord(
            sessionId = current.sessionId, effort = effort, feeling = feeling, notes = notes, painPresent = painPresent,
            actualDistanceKm = actualDistanceKm, actualDuration = actualDurationForRecord, actualPaceMinKm = actualPace,
            workoutDateIso = current.scheduledDateIso,
            workoutType = current.type,
            workoutTitle = current.title,
            activitySourceFormat = importedActivity?.sourceFormat ?: previousForSession?.activitySourceFormat.orEmpty(),
            activityFingerprint = importedActivity?.fingerprint ?: previousForSession?.activityFingerprint.orEmpty(),
            activityStartedAtIso = if (importedActivity != null) importedActivity.startedAtIso.orEmpty()
                else previousForSession?.activityStartedAtIso.orEmpty(),
            activityStartedAtSource = if (importedActivity != null) importedActivity.startedAtSource
                else previousForSession?.activityStartedAtSource.orEmpty(),
            realizedDateIso = importedActivity?.startedAtIso?.let(::localDateFromInstant)
                ?: if (importedActivity != null) linkedRaceDateIso ?: LocalDate.now().toString()
                else previousForSession?.realizedDateIso?.takeIf { it.isNotBlank() }
                    ?: previousForSession?.activityStartedAtIso?.let(::localDateFromInstant)
                    ?: linkedRaceDateIso
                    ?: LocalDate.now().toString(),
            terrain = RunningTerrain.normalize(terrain),
            raceEventId = raceEventId.takeIf { id ->
                actualDistanceKm != null && actualDurationSeconds != null && raceEvents.any { it.id == id }
            }.orEmpty(),
            recordedPaceSegments = if (importedActivity != null) importedActivity.paceSegments
                else previousForSession?.recordedPaceSegments.orEmpty(),
            blockPaceFeedback = blockPaceFeedback,
            measuredZoneTimeSeconds = if (importedActivity != null) {
                importedActivity.paceSegments.let(::measuredZoneTimeFromTrack)
            } else previousForSession?.measuredZoneTimeSeconds.orEmpty(),
            elevationGainMeters = if (importedActivity != null) importedActivity.elevationGainMeters else previousForSession?.elevationGainMeters,
            averageHeartRateBpm = if (importedActivity != null) importedActivity.averageHeartRateBpm else previousForSession?.averageHeartRateBpm,
            maxHeartRateBpm = if (importedActivity != null) importedActivity.maxHeartRateBpm else previousForSession?.maxHeartRateBpm,
            averageCadenceSpm = if (importedActivity != null) importedActivity.averageCadenceSpm else previousForSession?.averageCadenceSpm,
            maxCadenceSpm = if (importedActivity != null) importedActivity.maxCadenceSpm else previousForSession?.maxCadenceSpm,
            routePointCount = if (importedActivity != null) importedActivity.routePointCount else previousForSession?.routePointCount ?: 0,
            splitPacesMmSs = if (importedActivity != null) importedActivity.splitPacesMmSs else previousForSession?.splitPacesMmSs.orEmpty(),
            splitDetails = if (importedActivity != null) importedActivity.splitDetails else previousForSession?.splitDetails.orEmpty(),
            encodedRoute = if (importedActivity != null) importedActivity.encodedRoute else previousForSession?.encodedRoute.orEmpty()
        )
        feedbackRecords = feedbackRecords.filterNot { it.sessionId == current.sessionId } + record
        if (record.raceEventId.isNotBlank()) {
            raceEvents = raceEvents.map { event ->
                if (event.id == record.raceEventId) event.copy(status = "COMPLETED") else event
            }
            syncTargetDate()
        }
        val calibratedZonesAfterFeedback = currentPaceZones()
        rememberZoneBoundaries(calibratedZonesAfterFeedback)
        if (painPresent) {
            latestFeedbackHeadline = "Dor relatada • priorizar recuperação"
            latestFeedbackAdvice = "A dor bloqueia a progressão automática de carga e intensidade. Interrompa o estímulo que provoca dor e retome somente quando estiver recuperado."
        } else if (calibratedZonesAfterFeedback?.let { zones ->
                zones.z1CalibrationStatus == ZoneCalibrationEngine.CALIBRATED ||
                    zones.z3CalibrationStatus == ZoneCalibrationEngine.CALIBRATED ||
                    zones.z1CalibrationStatus == ZoneCalibrationEngine.REVIEW ||
                    zones.z3CalibrationStatus == ZoneCalibrationEngine.REVIEW
            } == true) {
            needsPacePlanRefresh = true
            latestFeedbackHeadline = "Calibração individual em atualização"
            latestFeedbackAdvice = "As evidências estão refinando as fronteiras em passos de até 15 segundos por atualização. Recalcule o plano para aplicar as faixas ativas quando a calibração estiver consistente."
        } else {
            val analysis = TrainingAdaptationEngine.analyzeRun(
                TrainingAdaptationEngine.RunResult(
                    distanceKm = actualDistanceKm,
                    plannedDistanceKm = current.distanceKm,
                    perceivedEffort = effort,
                    feeling = feeling,
                    plannedWorkoutType = current.type,
                    painReported = painPresent
                )
            )
            latestFeedbackHeadline = "Feedback registrado"
            latestFeedbackAdvice = analysis.nextStep
        }
        // Block comparisons describe pace execution, not automatically the physiological
        // quality of a stimulus. Keep this distinction explicit in the coach feedback.
        if (!painPresent && blockPaceFeedback.isNotEmpty()) {
            val comparisons = blockPaceFeedback.map(WorkoutBlockFeedbackEngine::compare)
            val faster = comparisons.count { it.status == WorkoutBlockFeedbackEngine.FASTER }
            val precise = comparisons.count { it.status == WorkoutBlockFeedbackEngine.PRECISE }
            val slower = comparisons.count { it.status == WorkoutBlockFeedbackEngine.SLOWER }
            latestFeedbackAdvice = (latestFeedbackAdvice +
                " Execução dos blocos informados: $faster mais rápidos, $precise dentro da faixa e $slower mais lentos. Ser mais rápido descreve apenas a velocidade; a adequação do estímulo depende também da zona prescrita, do esforço e da sensação.").trim()
        }
        // Any feedback changes the recovery picture, even when the athlete did not
        // enter measured distance/time. Only real metrics are used in pace and volume charts.
        needsEngineRefresh = true
        if (actualDistanceKm != null) {
            latestFeedbackAdvice = (latestFeedbackAdvice + " A distância realizada foi salva no histórico; recalcule o plano para usar essa carga nas próximas semanas.").trim()
        } else {
            latestFeedbackAdvice = (latestFeedbackAdvice + " O feedback subjetivo foi salvo. Informe distância e tempo quando disponíveis para incluir métricas reais nos gráficos e na carga.").trim()
        }
        feedbackSaved = true
        motorError = ""
        // Commit synchronously: feedback is an athlete record and must survive
        // immediate process termination/app switching after the save action.
        try {
            persist(synchronous = true)
        } catch (error: Exception) {
            workouts = previousWorkouts
            feedbackRecords = previousFeedbackRecords
            raceEvents = previousRaceEvents
            syncTargetDate()
            feedbackSaved = feedbackRecords.isNotEmpty()
            needsEngineRefresh = previousNeedsEngineRefresh
            needsPacePlanRefresh = previousNeedsPacePlanRefresh
            latestFeedbackHeadline = previousFeedbackHeadline
            latestFeedbackAdvice = previousFeedbackAdvice
            motorError = "Não foi possível gravar o feedback no armazenamento do aparelho. Tente novamente."
            return false
        }
        return true
    }

    private fun localDateFromInstant(raw: String): String? = runCatching {
        Instant.parse(raw).atZone(ZoneId.systemDefault()).toLocalDate().toString()
    }.getOrNull()

    /** Actual activity date, never the scheduled date when a real activity timestamp exists. */
    fun feedbackActivityDate(record: FeedbackRecord): LocalDate = ActivityDateResolver.resolve(
        realizedDateIso = record.realizedDateIso,
        activityStartedAtIso = record.activityStartedAtIso,
        activitySourceFormat = record.activitySourceFormat,
        scheduledDateIso = record.workoutDateIso,
        savedAtMillis = record.savedAt
    )

    private fun recentFeedback(windowDays: Long = 14): List<FeedbackRecord> {
        val today = LocalDate.now()
        val cutoff = today.minusDays(windowDays)
        return feedbackRecords.filter { record ->
            val date = feedbackActivityDate(record)
            !date.isBefore(cutoff) && !date.isAfter(today)
        }.sortedBy(::feedbackActivityDate)
    }

    /** Live readiness card: recalculates immediately from the three latest feedbacks in 14 days. */
    fun readinessSnapshot(): AthleteReadinessSnapshot = AthleteReadinessEngine.evaluate(
        recentFeedback().takeLast(3).map { record ->
            ReadinessFeedback(
                effort = record.effort,
                feeling = record.feeling,
                painPresent = record.painPresent
            )
        }
    )

    private fun deriveRecoveryScore(): Double? = readinessSnapshot().recoveryScore

    private fun deriveFatigueScore(): Double? = readinessSnapshot().fatigueScore

    fun requestRestDayRecommendation(targetDate: LocalDate): RestDayRecommendation {
        scheduleActionMessage = ""
        val sessionEvidence = workouts.mapNotNull { workout ->
            val date = runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull() ?: return@mapNotNull null
            val hasFeedback = feedbackRecords.any { it.sessionId == workout.sessionId }
            RestDaySessionEvidence(
                sessionId = workout.sessionId,
                date = date,
                title = workout.title,
                type = workout.type,
                distanceKm = workout.distanceKm,
                done = workout.done || hasFeedback,
                optionalExtra = workout.isOptionalExtra
            )
        }
        val feedbackEvidence = feedbackRecords.map { record ->
            RestDayFeedbackEvidence(
                date = feedbackActivityDate(record),
                effort = record.effort,
                feeling = record.feeling,
                painPresent = record.painPresent,
                actualDistanceKm = record.actualDistanceKm
            )
        }
        val measuredActivities = feedbackRecords.mapNotNull { record ->
            val distance = record.actualDistanceKm ?: return@mapNotNull null
            LoggedRunActivity(feedbackActivityDate(record), distance)
        }
        val load = TrainingLoadEngine.summarize(measuredActivities, LocalDate.now())
        val selectedGoalKm = TrainingGoalCatalog.distanceForLabel(
            goal, customGoalKm.trim().replace(",", ".").toDoubleOrNull()
        ) ?: 5.0
        val goalLoad = TrainingPlanReferenceCatalog.loadReference(
            selectedGoalKm, TrainingGoalCatalog.categoryForLabel(goal)
        )
        val profileLongest = load.longestRunLast30DaysKm
            ?: longestRecent.trim().replace(",", ".").toDoubleOrNull()
            ?: goalLoad.assumedPreviousContinuousDistanceKm
        val profileWeeklyBaseline = load.averageWeeklyKmLast28Days
            ?: weeklyVolumeText.trim().replace(",", ".").toDoubleOrNull()
            ?: goalLoad.baseWeeklyKm
        // Goal/experience-specific walk-run eligibility; unknown activity history alone
        // must never force a continuous runner into walk/run on a rest-day suggestion.
        val profileIsNovice = isRunWalkEligibleForCurrentProfile(selectedGoalKm)
        val runningDaysLimit = TrainingScheduleEngine.prescribedRunningDays(
            availableTrainingDays, frequency, profileIsNovice, preferredLongRunDay
        ).size.coerceIn(2, 6)
        val recommendation = RestDayAdaptationEngine.recommend(
            targetDate = targetDate,
            today = LocalDate.now(),
            sessions = sessionEvidence,
            feedback = feedbackEvidence,
            raceDates = raceEvents.filter { it.status != "CANCELLED" }.mapNotNull { it.dateOrNull() }.toSet(),
            weeklyBaselineKm = profileWeeklyBaseline,
            longestRunLast30DaysKm = profileLongest,
            noviceOrReturner = profileIsNovice,
            maxWeeklySessions = runningDaysLimit
        )
        restDayRecommendation = recommendation
        persist()
        return recommendation
    }

    fun addRecommendedRestDayWorkout(option: String = "EASY"): Boolean {
        val recommendation = restDayRecommendation ?: return false
        if (!recommendation.canAddWorkout) return false
        val normalOption = option == "NORMAL"
        if (normalOption && !recommendation.normalAvailable) return false
        val date = recommendation.targetDate
        val dateIso = date.toString()
        val dateAlreadyHasWorkout = workouts.any { it.scheduledDateIso == dateIso }
        val dateHasRace = raceEvents.any { it.status != "CANCELLED" && it.dateOrNull() == date }
        if (dateAlreadyHasWorkout || dateHasRace) {
            restDayRecommendation = null
            scheduleActionMessage = "A consulta de treino extra é exclusiva para dias livres. Esta data recebeu um compromisso; nenhuma sessão foi adicionada."
            persist()
            return false
        }
        val selectedZone = if (normalOption) "Z2" else "Z1"
        val selectedDuration = if (normalOption) recommendation.normalDurationMin else recommendation.durationMin
        val selectedDistance = if (normalOption) recommendation.normalEstimatedDistanceKm else recommendation.estimatedDistanceKm
        val selectedRpe = if (normalOption) recommendation.normalRpeRange else recommendation.rpeRange
        val selectedIntensity = if (normalOption) "MODERATE" else "LOW"
        val zoneRange = currentPaceZones()?.all()?.firstOrNull { it.id == selectedZone }?.range
        fun segment(name: String, minutes: Int, instruction: String): WorkoutSegment = WorkoutSegment(
            name = name,
            instruction = instruction,
            durationMin = minutes,
            intensity = selectedIntensity,
            rpeRange = selectedRpe,
            targetMode = "TIME",
            targetPaceMinValue = zoneRange?.fastestPaceValue,
            targetPaceMaxValue = zoneRange?.slowestPaceValue,
            paceZone = zoneRange?.let { selectedZone },
            zoneBasePaceFastValue = zoneRange?.fastestPaceValue,
            zoneBasePaceSlowValue = zoneRange?.slowestPaceValue
        )
        val warmMinutes = 3
        val coolMinutes = 3
        val mainMinutes = (selectedDuration - warmMinutes - coolMinutes).coerceAtLeast(6)
        val segments = if (recommendation.runWalkPattern) {
            val repetitions = (mainMinutes / 3).coerceAtLeast(2)
            listOf(
                segment("Aquecimento com caminhada", warmMinutes, "Caminhe ativamente e inicie o trote somente se estiver confortável."),
                segment(if (normalOption) "Corrida aeróbia" else "Corrida leve", 2,
                    if (normalOption) "Mantenha Z2 confortável, sem transformar a sessão em treino de ritmo." else "Trote leve em Z1, com respiração tranquila.").copy(repeatCount = repetitions),
                WorkoutSegment("Caminhada", "Recupere caminhando sem pressa entre os trechos de corrida.", durationMin = 1, intensity = "LOW", rpeRange = "1-2", targetMode = "TIME", repeatCount = repetitions),
                segment("Desaquecimento", coolMinutes, "Finalize caminhando e reduza gradualmente o esforço.")
            )
        } else {
            listOf(
                segment("Aquecimento", warmMinutes, "Comece com caminhada ativa e trote muito leve."),
                segment(if (normalOption) "Rodagem" else "Corrida leve adicional", mainMinutes,
                    if (normalOption) "Mantenha Z2 estável e confortável. Não faça progressões nem tente compensar sessões anteriores." else "Mantenha Z1 e conversa confortável. Não acelere nem tente compensar sessões anteriores."),
                segment("Desaquecimento", coolMinutes, "Reduza o esforço gradualmente até encerrar a sessão.")
            )
        }
        val runningMinutes = if (recommendation.runWalkPattern) 2 * ((mainMinutes / 3).coerceAtLeast(2)) else mainMinutes
        val paceForEstimate = zoneRange?.let { (it.fastestPaceValue + it.slowestPaceValue) / 2.0 } ?: 450.0
        val estimatedDistance = selectedDistance.takeIf { it > 0.0 } ?: if (zoneRange != null) {
            (runningMinutes * 60.0 / paceForEstimate).coerceAtLeast(0.5)
        } else 0.0
        val planMonday = runCatching { LocalDate.parse(planStartDateIso) }.getOrNull()
            ?.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            ?: LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val targetMonday = date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val weekNumber = (java.time.temporal.ChronoUnit.WEEKS.between(planMonday, targetMonday).toInt() + 1).coerceAtLeast(1)
        val dateLabel = "${date.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, Locale.forLanguageTag("pt-BR")).replaceFirstChar { it.uppercase(Locale.forLanguageTag("pt-BR")) }}, ${date.format(DateTimeFormatter.ofPattern("dd/MM"))}"
        val workout = Workout(
            date = dateLabel,
            scheduledDateIso = date.toString(),
            title = if (normalOption) "Rodagem extra" else if (recommendation.runWalkPattern) "Corrida-caminhada leve extra" else "Rodagem leve extra",
            detail = if (normalOption) "Sessão aeróbia opcional em Z2, escolhida pelo corredor após visualizar a carga e os riscos." else "Sessão opcional curta em Z1, escolhida pelo corredor após visualizar a carga e os riscos.",
            type = if (normalOption) "Aeróbio" else "Recuperação",
            objective = if (normalOption) "Adicionar estímulo aeróbio controlado sem substituir sessões principais." else "Adicionar movimento leve sem comprometer a recuperação nem substituir as sessões principais.",
            stimulus = if (normalOption) "ADAPTIVE_OPTIONAL_REST_DAY_Z2" else "ADAPTIVE_OPTIONAL_REST_DAY_Z1",
            distanceKm = estimatedDistance,
            done = false,
            sessionId = "EXTRA-${java.util.UUID.randomUUID()}",
            durationMin = selectedDuration,
            intensity = selectedIntensity,
            paceMode = if (zoneRange != null) "PACE_RANGE" else "PACE_NOT_CALIBRATED",
            rpeRange = selectedRpe,
            rationale = recommendation.explanation + " Riscos apresentados antes da inclusão: ${recommendation.riskText}" + if (normalOption) " Opção normal: maior carga aeróbia e risco de fadiga superior à opção leve." else " Opção leve: menor carga e intensidade Z1.",
            week = weekNumber,
            phase = "ADAPTIVE_OPTIONAL",
            segments = segments,
            paceCalibrationSnapshot = currentPaceZones()?.let { zones ->
                PaceCalculator.createCalibrationSnapshot(
                    distanceKm = cooperAssessments.lastOrNull()?.distanceKm,
                    assessmentDateIso = cooperAssessments.lastOrNull()?.dateIso ?: LocalDate.now().toString(),
                    talkTestComfortPaces = emptyList(),
                    zonesOverride = zones
                )
            },
            isOptionalExtra = true
        )
        workouts = (workouts + ZoneIntensityBandEngine.apply(workout)).distinctBy { it.sessionId }.sortedBy { it.scheduledDateIso }
        selectedWorkoutIndex = workouts.indexOfFirst { it.sessionId == workout.sessionId }.coerceAtLeast(0)
        restDayRecommendation = null
        scheduleActionMessage = "${if (normalOption) "Rodagem" else "Sessão leve"} adicional incluída em $dateLabel. Os treinos principais não foram alterados."
        persist(synchronous = true)
        return true
    }

    fun selectWorkout(workout: Workout) {
        // Calendar entries may be derived alternatives; resolve by stable session ID, not full data-class equality.
        val index = workouts.indexOfFirst { it.sessionId == workout.sessionId }
        if (index >= 0) selectedWorkoutIndex = index
        navigateTo(Screen.WORKOUT)
    }

    fun persist(synchronous: Boolean = false) {
        val e = prefs.edit()
            .remove("benchmarkEnabled")
            .remove("benchmarkDistanceText")
            .remove("benchmarkTimeText")
            .putString("name", name)
            .putString("goal", goal)
            .putString("goalIntent", goalIntent)
            .putString("goalTargetTimeText", goalTargetTimeText)
            .putString("personalBestTimeText", personalBestTimeText)
            .putString("historicalTestAgeText", historicalTestAgeText)
            .putString("terrainPreference", terrainPreference)
            .putString("customGoalKm", customGoalKm)
            .putString("level", level)
            .putInt("frequency", frequency)
            .putString("availableTrainingDays", availableTrainingDays.joinToString(",") { it.name })
            .putString("preferredLongRunDay", preferredLongRunDay?.name ?: "")
            .putString("targetDate", targetDate)
            .putString("planStartDateIso", planStartDateIso)
            .putString("racePlanNote", racePlanNote)
            .putString("racePlanWarnings", JSONArray(racePlanWarnings).toString())
            .putString("raceEvents", JSONArray().apply {
                raceEvents.forEach { event -> put(JSONObject().apply {
                    put("id", event.id); put("name", event.name); put("distanceKm", event.distanceKm)
                    put("eventDateIso", event.eventDateIso); put("priority", event.priority)
                    put("targetTime", event.targetTime); put("location", event.location)
                    put("notes", event.notes); put("status", event.status)
                }) }
            }.toString())
            .putString("volume", volume)
            .putString("weeklyVolumeText", weeklyVolumeText)
            .putString("longestRecent", longestRecent)
            .putString("runningExperienceDuration", runningExperienceDuration)
            .putString("ageYearsText", ageYearsText)
            .putString("birthDateText", birthDateText)
            .putString("referenceSex", referenceSex)
            .putString("fitnessTestMethod", fitnessTestMethod)
            .putString("threeKmTimeText", threeKmTimeText)
            .putInt("activeWeeksLast4", activeWeeksLast4)
            .putBoolean("cooperEnabled", cooperEnabled)
            .putString("cooperDistanceText", cooperDistanceText)
            .putString("cooperAssessmentDateText", cooperAssessmentDateText)
            .putString("latestCooperMessage", latestCooperMessage)
            .putInt("onboardingStep", onboardingStep)
            .putInt("selectedScreen", selectedScreen.ordinal)
            .putString("selectedRaceId", selectedRaceId)
            .putInt("selectedWorkoutIndex", selectedWorkoutIndex)
            .putInt("planWeeks", planWeeks)
            .putString("latestFeedbackHeadline", latestFeedbackHeadline)
            .putString("latestFeedbackAdvice", latestFeedbackAdvice)
            .putString("motorExplanation", motorExplanation)
            .putString("motorError", motorError)
            .putBoolean("needsPacePlanRefresh", needsPacePlanRefresh)
            .putBoolean("needsEngineRefresh", needsEngineRefresh)
            .putString("zoneReviewDecisions", JSONObject().apply {
                zoneReviewDecisions.forEach { (zone, decision) -> put(zone, decision) }
            }.toString())
            .putBoolean("pendingBackupRecalibration", pendingBackupRecalibration)
            .putInt("importedBackupEngineVersion", importedBackupEngineVersion)

        lastZoneBoundarySnapshot?.let { boundaries ->
            e.putString("lastZoneBoundarySnapshot", JSONArray(boundaries).toString())
        } ?: e.remove("lastZoneBoundarySnapshot")

        motorState?.let { ms ->
            e.putString("motorState", JSONObject().apply {
                put("fitnessConfidence", ms.fitnessConfidence)
                put("paceConfidence", ms.paceConfidence)
                put("recentVolumeKm", ms.recentVolumeKm)
                put("recentLongRunKm", ms.recentLongRunKm)
                put("recoveryStatus", ms.recoveryStatus)
                put("safetyStatus", ms.safetyStatus)
                put("phase", ms.phase)
                put("flags", JSONArray(ms.flags))
                put("goalPreparationStage", ms.goalPreparationStage)
                ms.goalSpecificWeeklyMinKm?.let { put("goalSpecificWeeklyMinKm", it) }
                ms.goalSpecificLongestMinKm?.let { put("goalSpecificLongestMinKm", it) }
                put("goalSpecificFrequencyMin", ms.goalSpecificFrequencyMin)
            }.toString())
        }
        motorDecision?.let { md ->
            e.putString("motorDecision", JSONObject().apply {
                put("action", md.action)
                put("necessity", md.necessity)
                put("stimulus", md.stimulus)
                put("rationale", md.rationale)
                put("confidence", md.confidence)
                put("safety", md.safety)
            }.toString())
        }
        val arr = JSONArray()
        workouts.forEach { w ->
            arr.put(JSONObject().apply {
                put("date", w.date); put("scheduledDateIso", w.scheduledDateIso); put("title", w.title); put("detail", w.detail)
                put("type", w.type); put("objective", w.objective); put("stimulus", w.stimulus)
                put("distanceKm", w.distanceKm); put("done", w.done); put("sessionId", w.sessionId)
                put("durationMin", w.durationMin); put("intensity", w.intensity); put("paceMode", w.paceMode)
                put("rpeRange", w.rpeRange); put("rationale", w.rationale); put("week", w.week)
                put("phase", w.phase)
                put("manuallyRescheduled", w.manuallyRescheduled)
                put("originalScheduledDateIso", w.originalScheduledDateIso)
                put("selectedOption", w.selectedOption)
                put("isOptionalExtra", w.isOptionalExtra)
                w.weeklyTargetKm?.let { put("weeklyTargetKm", it) }
                put("experienceMonths", w.experienceMonths)
                w.paceCalibrationSnapshot?.let { snapshot ->
                    put("paceCalibration", JSONObject().apply {
                        put("assessmentDateIso", snapshot.assessmentDateIso)
                        put("distanceKm", snapshot.distanceKm)
                        put("averagePaceMmSs", snapshot.averagePaceMmSs)
                        put("estimatedVo2Max", snapshot.estimatedVo2Max)
                        put("estimatedMasPaceMmSs", snapshot.estimatedMasPaceMmSs)
                        put("estimatedSvt2PaceMmSs", snapshot.estimatedSvt2PaceMmSs)
                        put("modelVersion", snapshot.modelVersion)
                        put("z2CalibrationStatus", snapshot.z2CalibrationStatus)
                        put("talkTestEvidenceCount", snapshot.talkTestEvidenceCount)
                        put("talkTestReferencePaceMmSs", snapshot.talkTestReferencePaceMmSs)
                        put("z1CalibrationStatus", snapshot.z1CalibrationStatus); put("z1CalibrationEvidenceCount", snapshot.z1CalibrationEvidenceCount)
                        put("z2CalibrationEvidenceCount", snapshot.z2CalibrationEvidenceCount)
                        put("z3CalibrationStatus", snapshot.z3CalibrationStatus); put("z3CalibrationEvidenceCount", snapshot.z3CalibrationEvidenceCount)
                        put("zoneRanges", JSONObject().apply { snapshot.zoneRanges.forEach { (id, range) -> put(id, range) } })
                    })
                }
                put("segments", JSONArray().apply {
                    w.segments.forEach { segment -> put(JSONObject().apply {
                        put("name", segment.name); put("instruction", segment.instruction)
                        if (segment.durationMin != null) put("durationMin", segment.durationMin)
                        if (segment.distanceKm != null) put("distanceKm", segment.distanceKm)
                        put("intensity", segment.intensity); put("rpeRange", segment.rpeRange)
                        put("repeatCount", segment.repeatCount); put("targetMode", segment.targetMode)
                        segment.targetPaceMinValue?.let { put("paceFasterMinKm", PaceRange.format(it)) }
                        segment.targetPaceMaxValue?.let { put("paceSlowerMinKm", PaceRange.format(it)) }
                        segment.paceZone?.let { put("paceZone", it) }
                        segment.zoneBasePaceFastValue?.let { put("zoneBasePaceFastMinKm", PaceRange.format(it)) }
                        segment.zoneBasePaceSlowValue?.let { put("zoneBasePaceSlowMinKm", PaceRange.format(it)) }
                        segment.zoneIntensityMinPercent?.let { put("zoneIntensityMinPercent", it) }
                        segment.zoneIntensityMaxPercent?.let { put("zoneIntensityMaxPercent", it) }
                        segment.goalPaceReferenceSecondsPerKm?.let { put("goalPaceReferenceSecondsPerKm", it) }
                        segment.recoveryMode?.let { put("recoveryMode", it) }
                    }) }
                })
            })
        }
        val feedbackArray = JSONArray()
        feedbackRecords.forEach { feedback -> feedbackArray.put(JSONObject().apply {
            put("sessionId", feedback.sessionId); put("effort", feedback.effort)
            put("feeling", feedback.feeling); put("notes", feedback.notes); put("painPresent", feedback.painPresent)
            feedback.actualDistanceKm?.let { put("actualDistanceKm", it) }
            feedback.actualDuration?.let { put("actualDuration", it) }
            feedback.actualPaceMinKm?.let { put("actualPaceMinKm", it) }
            feedback.talkTestPaceMmSs?.let { put("talkTestPaceMmSs", it) }
            put("workoutDateIso", feedback.workoutDateIso)
            put("workoutType", feedback.workoutType)
            put("workoutTitle", feedback.workoutTitle)
            put("savedAt", feedback.savedAt)
            put("activitySourceFormat", feedback.activitySourceFormat)
            put("activityFingerprint", feedback.activityFingerprint)
            put("activityStartedAtIso", feedback.activityStartedAtIso)
            put("activityStartedAtSource", feedback.activityStartedAtSource)
            put("realizedDateIso", feedback.realizedDateIso)
            put("terrain", RunningTerrain.normalize(feedback.terrain))
            put("raceEventId", feedback.raceEventId)
            put("blockPaceFeedback", JSONArray().apply {
                feedback.blockPaceFeedback.forEach { block -> put(JSONObject().apply {
                    put("blockKey", block.blockKey)
                    put("segmentIndex", block.segmentIndex)
                    put("repetition", block.repetition)
                    put("segmentName", block.segmentName)
                    block.targetZone?.let { put("targetZone", it) }
                    block.targetFastestPaceSecondsPerKm?.let { put("targetFastestPaceSecondsPerKm", it) }
                    block.targetSlowestPaceSecondsPerKm?.let { put("targetSlowestPaceSecondsPerKm", it) }
                    block.actualPaceSecondsPerKm?.let { put("actualPaceSecondsPerKm", it) }
                    put("targetMode", block.targetMode)
                    block.recoveryMode?.let { put("recoveryMode", it) }
                }) }
            })
            put("recordedPaceSegments", JSONArray().apply {
                feedback.recordedPaceSegments.forEach { segment -> put(JSONObject().apply {
                    put("paceSecondsPerKm", segment.paceSecondsPerKm)
                    put("durationSeconds", segment.durationSeconds)
                    segment.startElapsedSeconds?.let { put("startElapsedSeconds", it) }
                    segment.startDistanceMeters?.let { put("startDistanceMeters", it) }
                    segment.distanceMeters?.let { put("distanceMeters", it) }
                    segment.averageHeartRateBpm?.let { put("averageHeartRateBpm", it) }
                    segment.averageCadenceSpm?.let { put("averageCadenceSpm", it) }
                    put("sourceType", segment.sourceType)
                    segment.sourceBlockIndex?.let { put("sourceBlockIndex", it) }
                }) }
            })
            put("measuredZoneTimeSeconds", JSONObject().apply {
                feedback.measuredZoneTimeSeconds.forEach { (zone, seconds) -> put(zone, seconds) }
            })
            feedback.elevationGainMeters?.let { put("elevationGainMeters", it) }
            feedback.averageHeartRateBpm?.let { put("averageHeartRateBpm", it) }
            feedback.maxHeartRateBpm?.let { put("maxHeartRateBpm", it) }
            feedback.averageCadenceSpm?.let { put("averageCadenceSpm", it) }
            feedback.maxCadenceSpm?.let { put("maxCadenceSpm", it) }
            put("routePointCount", feedback.routePointCount)
            put("splitPacesMmSs", JSONArray(feedback.splitPacesMmSs))
            put("splitDetails", JSONArray().apply { feedback.splitDetails.forEach { split -> put(JSONObject().apply {
                put("label", split.label); put("distanceMeters", split.distanceMeters)
                split.durationSeconds?.let { put("durationSeconds", it) }
                split.paceSecondsPerKm?.let { put("paceSecondsPerKm", it) }
                put("sourceType", split.sourceType)
                split.startDistanceMeters?.let { put("startDistanceMeters", it) }
            }) } })
            put("encodedRoute", feedback.encodedRoute)
        }) }
        e.putString("feedbackRecords", feedbackArray.toString())
        e.putString("workouts", arr.toString())
        e.putString("cooperAssessments", JSONArray().apply {
            cooperAssessments.forEach { record -> put(JSONObject().apply {
                put("dateIso", record.dateIso); put("distanceKm", record.distanceKm)
                put("testMethod", record.testMethod); record.testDurationSeconds?.let { put("testDurationSeconds", it) }
                put("referenceSex", record.referenceSex); record.ageAtTest?.let { put("ageAtTest", it) }
                put("estimatedVo2Max", record.estimatedVo2Max)
                put("averagePace", record.averagePace)
                put("estimatedMasPace", record.estimatedMasPace)
                put("estimatedSvt2Pace", record.estimatedSvt2Pace)
                put("zoneModelVersion", record.zoneModelVersion)
                put("z2CalibrationStatus", record.z2CalibrationStatus)
                put("talkTestEvidenceCount", record.talkTestEvidenceCount)
                put("talkTestReferencePaceMmSs", record.talkTestReferencePaceMmSs)
                put("z1CalibrationStatus", record.z1CalibrationStatus); put("z1CalibrationEvidenceCount", record.z1CalibrationEvidenceCount)
                put("z3CalibrationStatus", record.z3CalibrationStatus); put("z3CalibrationEvidenceCount", record.z3CalibrationEvidenceCount)
                put("zoneRanges", JSONObject().apply { record.zoneRanges.forEach { (zone, range) -> put(zone, range) } })
            }) }
        }.toString())
        if (synchronous) check(e.commit()) { "Não foi possível salvar os dados da sessão no aparelho." } else e.apply()
    }

    fun exportBackup(uri: Uri): BackupOperationResult {
        val result = AppBackupManager.export(context, uri)
        backupMessage = result.message
        return result
    }

    fun importCompletedActivities(uri: Uri): BackupOperationResult {
        val result = AppBackupManager.importCompletedActivities(context, uri)
        if (result.success) {
            load()
            needsEngineRefresh = true
            selectedScreen = Screen.BACKUP
            onboardingStep = 8
            persist(synchronous = true)
        }
        backupMessage = result.message
        return result
    }

    fun restoreBackup(uri: Uri): BackupOperationResult {
        val result = AppBackupManager.restore(context, uri)
        if (!result.success) {
            backupMessage = result.message
            return result
        }
        navigationHistory.clear()
        load()
        importedBackupEngineVersion = prefs.getInt("engineVersion", 0)
        pendingBackupRecalibration = workouts.isNotEmpty()
        // Do not silently overwrite the restored plan. Ask explicitly whether the
        // complete unfinished cycle should be rebuilt by the current engine.
        needsEngineRefresh = workouts.isNotEmpty() && importedBackupEngineVersion < CURRENT_ENGINE_VERSION
        navigationHistory.clear()
        selectedScreen = Screen.BACKUP
        selectedWorkoutIndex = 0
        onboardingStep = 8
        backupMessage = if (workouts.isNotEmpty()) {
            result.message + " O backup foi restaurado. O plano foi preservado até sua decisão; motor do backup: $importedBackupEngineVersion, motor atual: $CURRENT_ENGINE_VERSION. Recomendamos recalibrar zonas, volume-base, periodização, sessões e semanas futuras."
        } else result.message
        persist(synchronous = true)
        return BackupOperationResult(true, backupMessage)
    }

    fun recalibrateRestoredBackup(): Boolean {
        if (!pendingBackupRecalibration) return false
        val profileReady = goal.isNotBlank() && level.isNotBlank() &&
            goal in TrainingGoalCatalog.labelsForLevel(level) &&
            availableTrainingDays.size in 2..6 && frequency == availableTrainingDays.size
        if (!profileReady) {
            motorError = "Complete objetivo, nível e disponibilidade semanal antes de recalibrar o backup."
            backupMessage = motorError
            persist()
            return false
        }
        val completedCount = completedWorkouts().size
        val success = createPlan(preserveCycleAnchor = true)
        if (success) {
            pendingBackupRecalibration = false
            backupMessage = "Backup recalibrado pelo motor $CURRENT_ENGINE_VERSION. Zonas, faixas ativas, base semanal, periodização e sessões futuras foram atualizadas; $completedCount treino(s) concluído(s), feedbacks, atividades e datas reais foram preservados."
            selectedScreen = Screen.BACKUP
            resetNavigation(Screen.BACKUP)
            persist(synchronous = true)
        } else {
            backupMessage = "Não foi possível concluir a recalibração: ${motorError.ifBlank { "revise o perfil e tente novamente" }}"
        }
        return success
    }

    fun keepRestoredBackupPlan() {
        pendingBackupRecalibration = false
        backupMessage = "Plano importado mantido sem recalibração. Você poderá recalcular depois pela opção de atualizar o plano."
        persist(synchronous = true)
    }

    private fun load() {
        // Reset collection/nullable state first. This is also used after restoring an
        // intentionally empty backup, so values from the previous installation cannot leak.
        raceEvents = emptyList()
        racePlanWarnings = emptyList()
        workouts = emptyList()
        feedbackRecords = emptyList()
        cooperAssessments = emptyList()
        lastZoneBoundarySnapshot = null
        motorState = null
        motorDecision = null
        lastGeneratedObjectiveSignature = prefs.getString("lastPlanObjectiveSignature", "") ?: ""
        name = prefs.getString("name", "") ?: ""
        goal = prefs.getString("goal", "") ?: ""
        goalIntent = TrainingGoalIntent.normalize(prefs.getString("goalIntent", TrainingGoalIntent.COMPLETE) ?: TrainingGoalIntent.COMPLETE, goal == "Saúde e qualidade de vida")
        goalTargetTimeText = prefs.getString("goalTargetTimeText", "") ?: ""
        personalBestTimeText = prefs.getString("personalBestTimeText", "") ?: ""
        historicalTestAgeText = prefs.getString("historicalTestAgeText", "") ?: ""
        terrainPreference = RunningTerrain.normalize(prefs.getString("terrainPreference", RunningTerrain.ROAD) ?: RunningTerrain.ROAD)
        customGoalKm = prefs.getString("customGoalKm", "") ?: ""
        level = prefs.getString("level", "") ?: ""
        frequency = prefs.getInt("frequency", 0)
        availableTrainingDays = prefs.getString("availableTrainingDays", "")?.split(",")
            ?.mapNotNull { value -> runCatching { DayOfWeek.valueOf(value) }.getOrNull() }
            ?.distinct()?.sortedBy { it.value }
            ?.takeIf { it.size in 2..6 }
            ?: if (frequency in 2..6) TrainingScheduleEngine.defaultDays(frequency) else emptyList()
        if (availableTrainingDays.isNotEmpty()) frequency = availableTrainingDays.size
        preferredLongRunDay = prefs.getString("preferredLongRunDay", "")?.takeIf { it.isNotBlank() }
            ?.let { runCatching { DayOfWeek.valueOf(it) }.getOrNull() }
            ?.takeIf { it in availableTrainingDays }
            ?: availableTrainingDays.firstOrNull { it == DayOfWeek.SUNDAY }
            ?: availableTrainingDays.lastOrNull()
        targetDate = prefs.getString("targetDate", "Sem prova principal") ?: "Sem prova principal"
        planStartDateIso = prefs.getString("planStartDateIso", "") ?: ""
        racePlanNote = prefs.getString("racePlanNote", "") ?: ""
        racePlanWarnings = prefs.getString("racePlanWarnings", null)?.let { raw -> runCatching {
            val array = JSONArray(raw); buildList { for (i in 0 until array.length()) add(array.optString(i)) }
        }.getOrDefault(emptyList()) } ?: emptyList()
        prefs.getString("raceEvents", null)?.let { raw -> runCatching {
            val array = JSONArray(raw)
            raceEvents = buildList { for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                add(RaceEvent(
                    id = item.optString("id"), name = item.optString("name"), distanceKm = item.optDouble("distanceKm"),
                    eventDateIso = item.optString("eventDateIso"), priority = item.optString("priority", "A"),
                    targetTime = item.optString("targetTime"), location = item.optString("location"),
                    notes = item.optString("notes"), status = item.optString("status", "PLANNED")
                ))
            } }
        } }
        volume = prefs.getString("volume", "") ?: ""
        weeklyVolumeText = prefs.getString("weeklyVolumeText", "") ?: ""
        longestRecent = prefs.getString("longestRecent", "") ?: ""
        runningExperienceDuration = prefs.getString("runningExperienceDuration", "") ?: ""
        ageYearsText = prefs.getString("ageYearsText", "") ?: ""
        birthDateText = prefs.getString("birthDateText", "") ?: ""
        referenceSex = prefs.getString("referenceSex", "") ?: ""
        fitnessTestMethod = prefs.getString("fitnessTestMethod", if (prefs.getBoolean("cooperEnabled", false)) "COOPER_12_MIN" else "NONE") ?: "NONE"
        threeKmTimeText = prefs.getString("threeKmTimeText", "") ?: ""
        activeWeeksLast4 = -1 // Removed from onboarding; rely on logged activity history.

        cooperEnabled = prefs.getBoolean("cooperEnabled", false)
        cooperDistanceText = prefs.getString("cooperDistanceText", "") ?: ""
        cooperAssessmentDateText = prefs.getString("cooperAssessmentDateText", LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/uuuu"))) ?: LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/uuuu"))
        // Normalize older unmasked values once when loading; the strict field validators
        // still reject impossible dates and malformed durations.
        birthDateText = SmartInputMask.date(birthDateText)
        cooperAssessmentDateText = SmartInputMask.date(cooperAssessmentDateText)
        threeKmTimeText = SmartInputMask.duration(threeKmTimeText)
        goalTargetTimeText = SmartInputMask.duration(goalTargetTimeText)
        personalBestTimeText = SmartInputMask.duration(personalBestTimeText)
        cooperDistanceText = SmartInputMask.distance(cooperDistanceText)
        weeklyVolumeText = SmartInputMask.distance(weeklyVolumeText)
        longestRecent = SmartInputMask.distance(longestRecent)
        latestCooperMessage = prefs.getString("latestCooperMessage", "") ?: ""
        // Migra opções antigas (ex.: "5 km" e "Mais de 10 km") para valor editável.
        longestRecent = when {
            longestRecent.startsWith("Mais", ignoreCase = true) -> "" // faixa aberta não é distância medida; exige revisão manual
            longestRecent.contains("km", ignoreCase = true) -> longestRecent.substringBefore(" ").trim()
            else -> longestRecent
        }
        onboardingStep = prefs.getInt("onboardingStep", if (goal.isBlank()) -1 else 1).coerceIn(-1, 8)
        selectedWorkoutIndex = prefs.getInt("selectedWorkoutIndex", 0)
        planWeeks = prefs.getInt("planWeeks", 8)
        needsEngineRefresh = prefs.getBoolean("needsEngineRefresh", false) || (prefs.getInt("engineVersion", 0) < CURRENT_ENGINE_VERSION && prefs.getString("workouts", null) != null)
        pendingBackupRecalibration = prefs.getBoolean("pendingBackupRecalibration", false)
        importedBackupEngineVersion = prefs.getInt("importedBackupEngineVersion", 0)
        needsPacePlanRefresh = prefs.getBoolean("needsPacePlanRefresh", false)
        lastZoneBoundarySnapshot = prefs.getString("lastZoneBoundarySnapshot", null)?.let { raw -> runCatching {
            val array = JSONArray(raw)
            if (array.length() != 6) null else buildList { for (i in 0 until array.length()) add(array.optInt(i, -1)) }
                .takeIf { values -> values.all { it in 120..1800 } }
        }.getOrNull() }
        zoneReviewDecisions = prefs.getString("zoneReviewDecisions", null)?.let { raw -> runCatching {
            val json = JSONObject(raw)
            buildMap { json.keys().forEach { zone ->
                val decision = json.optString(zone)
                if (zone in setOf("Z1", "Z2", "Z3", "Z4", "Z5") && decision.isNotBlank()) put(zone, decision)
            } }
        }.getOrDefault(emptyMap()) } ?: emptyMap()
        motorExplanation = prefs.getString("motorExplanation", "") ?: ""
        latestFeedbackHeadline = prefs.getString("latestFeedbackHeadline", "") ?: ""
        latestFeedbackAdvice = prefs.getString("latestFeedbackAdvice", "") ?: ""
        motorError = prefs.getString("motorError", "") ?: ""
        selectedScreen = Screen.entries.getOrNull(prefs.getInt("selectedScreen", Screen.DASHBOARD.ordinal)) ?: Screen.DASHBOARD
        selectedRaceId = prefs.getString("selectedRaceId", "").orEmpty()

        prefs.getString("motorState", null)?.let { raw -> runCatching {
            val o = JSONObject(raw)
            motorState = MotorState(
                fitnessConfidence = o.optString("fitnessConfidence"),
                paceConfidence = o.optString("paceConfidence"),
                recentVolumeKm = o.optDouble("recentVolumeKm"),
                recentLongRunKm = o.optDouble("recentLongRunKm"),
                recoveryStatus = o.optString("recoveryStatus"),
                safetyStatus = o.optString("safetyStatus"),
                phase = o.optString("phase"),
                flags = buildList { val a=o.optJSONArray("flags"); if (a != null) for (i in 0 until a.length()) add(a.optString(i)) },
                goalPreparationStage = o.optString("goalPreparationStage", "BASE"),
                goalSpecificWeeklyMinKm = if (o.has("goalSpecificWeeklyMinKm")) o.optDouble("goalSpecificWeeklyMinKm") else null,
                goalSpecificLongestMinKm = if (o.has("goalSpecificLongestMinKm")) o.optDouble("goalSpecificLongestMinKm") else null,
                goalSpecificFrequencyMin = o.optInt("goalSpecificFrequencyMin", 0)
            )
        }}
        prefs.getString("motorDecision", null)?.let { raw -> runCatching {
            val o = JSONObject(raw)
            motorDecision = MotorDecision(
                action = o.optString("action"), necessity = o.optString("necessity"), stimulus = o.optString("stimulus"),
                rationale = o.optString("rationale"), confidence = o.optDouble("confidence"), safety = o.optString("safety")
            )
        }}
        prefs.getString("workouts", null)?.let { raw -> runCatching {
            val a = JSONArray(raw)
            workouts = buildList {
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    add(Workout(
                        date=o.optString("date"), scheduledDateIso=o.optString("scheduledDateIso").ifBlank {
                            LegacyWorkoutDateMigration.resolve(o.optString("date"), planStartDateIso)
                        }, title=WorkoutTitleSanitizer.clean(o.optString("title"), o.optString("type", "Treino")), detail=o.optString("detail"), type=o.optString("type"),
                        objective=o.optString("objective"), stimulus=o.optString("stimulus"), distanceKm=o.optDouble("distanceKm"),
                        done=o.optBoolean("done"), sessionId=o.optString("sessionId"), durationMin=o.optInt("durationMin"),
                        intensity=o.optString("intensity", "LOW"), paceMode=o.optString("paceMode", "PACE_NOT_CALIBRATED"),
                        rpeRange=o.optString("rpeRange", "3-4"), rationale=o.optString("rationale"),
                        week=o.optInt("week",1), phase=o.optString("phase", "BASE"),
                        manuallyRescheduled=o.optBoolean("manuallyRescheduled", false), originalScheduledDateIso=o.optString("originalScheduledDateIso", ""), selectedOption=o.optString("selectedOption", "PRIMARY"),
                        isOptionalExtra=o.optBoolean("isOptionalExtra", false),
                        weeklyTargetKm=if (o.has("weeklyTargetKm")) o.optDouble("weeklyTargetKm") else null,
                        experienceMonths=o.optInt("experienceMonths", -1),
                        paceCalibrationSnapshot=o.optJSONObject("paceCalibration")?.let { calibration ->
                            val ranges = calibration.optJSONObject("zoneRanges")
                            PaceCalibrationSnapshot(
                                assessmentDateIso = calibration.optString("assessmentDateIso"),
                                distanceKm = calibration.optDouble("distanceKm"),
                                averagePaceMmSs = calibration.optString("averagePaceMmSs"),
                                estimatedVo2Max = calibration.optDouble("estimatedVo2Max"),
                                estimatedMasPaceMmSs = calibration.optString("estimatedMasPaceMmSs"),
                                estimatedSvt2PaceMmSs = calibration.optString("estimatedSvt2PaceMmSs"),
                                modelVersion = calibration.optString("modelVersion", "AIRC_ZONES_1_LEGACY"),
                                z2CalibrationStatus = calibration.optString("z2CalibrationStatus", "COOPER_INITIAL"),
                                talkTestEvidenceCount = calibration.optInt("talkTestEvidenceCount", 0),
                                talkTestReferencePaceMmSs = calibration.optString("talkTestReferencePaceMmSs", ""),
                                z1CalibrationStatus = calibration.optString("z1CalibrationStatus", ZoneCalibrationEngine.INITIAL),
                                z1CalibrationEvidenceCount = calibration.optInt("z1CalibrationEvidenceCount", 0),
                                z2CalibrationEvidenceCount = calibration.optInt("z2CalibrationEvidenceCount", 0),
                                z3CalibrationStatus = calibration.optString("z3CalibrationStatus", ZoneCalibrationEngine.INITIAL),
                                z3CalibrationEvidenceCount = calibration.optInt("z3CalibrationEvidenceCount", 0),
                                zoneRanges = if (ranges == null) emptyMap() else buildMap {
                                    for (id in listOf("Z1", "Z2", "Z3", "Z4", "Z5")) ranges.optString(id).takeIf { it.isNotBlank() }?.let { put(id, it) }
                                }
                            )
                        },
                        segments=buildList {
                            val segmentArray = o.optJSONArray("segments")
                            if (segmentArray != null) for (j in 0 until segmentArray.length()) {
                                val item = segmentArray.optJSONObject(j) ?: continue
                                add(WorkoutSegment(
                                    name=item.optString("name"), instruction=item.optString("instruction"),
                                    durationMin=if (item.has("durationMin")) item.optInt("durationMin") else null,
                                    distanceKm=if (item.has("distanceKm")) item.optDouble("distanceKm") else null,
                                    intensity=item.optString("intensity", "LOW"), rpeRange=item.optString("rpeRange", "2-3"),
                                    repeatCount=item.optInt("repeatCount", 1),
                                    targetMode=item.optString("targetMode", if (item.has("durationMin")) "TIME" else "DISTANCE"),
                                    targetPaceMinValue=item.optString("paceFasterMinKm").takeIf { it.isNotBlank() }?.let { PaceRange.parsePace(it) },
                                    targetPaceMaxValue=item.optString("paceSlowerMinKm").takeIf { it.isNotBlank() }?.let { PaceRange.parsePace(it) },
                                    paceZone=item.optString("paceZone").takeIf { it.isNotBlank() },
                                    zoneBasePaceFastValue=item.optString("zoneBasePaceFastMinKm").takeIf { it.isNotBlank() }?.let { PaceRange.parsePace(it) },
                                    zoneBasePaceSlowValue=item.optString("zoneBasePaceSlowMinKm").takeIf { it.isNotBlank() }?.let { PaceRange.parsePace(it) },
                                    zoneIntensityMinPercent=if (item.has("zoneIntensityMinPercent")) item.optInt("zoneIntensityMinPercent") else null,
                                    zoneIntensityMaxPercent=if (item.has("zoneIntensityMaxPercent")) item.optInt("zoneIntensityMaxPercent") else null,
                                    goalPaceReferenceSecondsPerKm=if (item.has("goalPaceReferenceSecondsPerKm")) item.optInt("goalPaceReferenceSecondsPerKm") else null,
                                    recoveryMode=item.optString("recoveryMode").takeIf { it.isNotBlank() }
                                ))
                            }
                        }
                    ))
                }
            }
        }}
        if (lastGeneratedObjectiveSignature.isBlank() && workouts.isNotEmpty()) {
            // V73 did not persist the signature. Snapshot the loaded profile now so
            // the first subsequent edit is recognized as an objective/profile change.
            lastGeneratedObjectiveSignature = currentPlanObjectiveSignature()
            prefs.edit().putString("lastPlanObjectiveSignature", lastGeneratedObjectiveSignature).apply()
        }

        // Repair session estimates persisted by V41. Older plans could show only
        // the minutes from TIME segments and omit the run time of DISTANCE segments.
        var durationEstimateMigrated = false
        workouts = workouts.map { saved ->
            if (saved.segments.isEmpty()) saved else {
                val corrected = WorkoutDurationEstimator.estimateMinutes(saved.segments, saved.distanceKm, saved.durationMin)
                if (corrected != saved.durationMin) durationEstimateMigrated = true
                saved.copy(durationMin = corrected)
            }
        }

        // V40 stored the current partial week as 0 and shifted all later weeks down.
        // Migrate saved cards immediately so export/periodization labels are correct
        // even before the athlete taps the recommended recalculation action.
        val migrateV40WeekNumbering = prefs.getInt("engineVersion", 0) == 32 && workouts.isNotEmpty()
        if (migrateV40WeekNumbering) {
            workouts = workouts.map { it.copy(week = TrainingScheduleEngine.migrateV40WeekIndex(it.week)) }
            needsEngineRefresh = true
        }
        // Mark V43 duration/navigation migration complete only when every saved session has
        // structured blocks that were eligible for recalculation.
        val markEngineV35 = workouts.isNotEmpty() && workouts.all { it.segments.isNotEmpty() } &&
            prefs.getInt("engineVersion", 0) < 35
        val activeZoneBandMigration = workouts.any { workout ->
            !workout.done && workout.segments.any { it.paceZone != null && it.targetPaceMinValue != null && it.zoneIntensityMinPercent == null }
        } && prefs.getInt("engineVersion", 0) < 36
        if (markEngineV35) prefs.edit().putInt("engineVersion", 35).apply()

        prefs.getString("feedbackRecords", null)?.let { raw -> runCatching {
            val a = JSONArray(raw)
            feedbackRecords = buildList {
                for (i in 0 until a.length()) {
                    val item = a.optJSONObject(i) ?: continue
                    add(FeedbackRecord(
                        sessionId = item.optString("sessionId"), effort = item.optString("effort"),
                        feeling = item.optString("feeling"), notes = item.optString("notes"),
                        painPresent = item.optBoolean("painPresent", false),
                        actualDistanceKm = if (item.has("actualDistanceKm")) item.optDouble("actualDistanceKm") else null,
                        savedAt = item.optLong("savedAt", System.currentTimeMillis()).takeIf { it > 0L } ?: System.currentTimeMillis(),
                        actualDuration = item.optString("actualDuration").takeIf { it.isNotBlank() },
                        actualPaceMinKm = item.optString("actualPaceMinKm").takeIf { it.isNotBlank() },
                        talkTestPaceMmSs = item.optString("talkTestPaceMmSs").takeIf { it.isNotBlank() },
                        workoutDateIso = item.optString("workoutDateIso"),
                        workoutType = item.optString("workoutType"),
                        workoutTitle = item.optString("workoutTitle"),
                        activitySourceFormat = item.optString("activitySourceFormat"),
                        activityFingerprint = item.optString("activityFingerprint"),
                        activityStartedAtIso = item.optString("activityStartedAtIso"),
                        activityStartedAtSource = item.optString("activityStartedAtSource"),
                        realizedDateIso = item.optString("realizedDateIso"),
                        terrain = RunningTerrain.normalize(item.optString("terrain", RunningTerrain.MIXED)),
                        raceEventId = item.optString("raceEventId"),
                        blockPaceFeedback = item.optJSONArray("blockPaceFeedback")?.let { blocks -> buildList {
                            for (index in 0 until blocks.length()) {
                                val block = blocks.optJSONObject(index) ?: continue
                                val actual = block.optInt("actualPaceSecondsPerKm", 0).takeIf { it in 120..1800 }
                                val rawFastest = block.optInt("targetFastestPaceSecondsPerKm", 0).takeIf { it in 120..1800 }
                                val rawSlowest = block.optInt("targetSlowestPaceSecondsPerKm", 0).takeIf { it in 120..1800 }
                                val validTargetRange = rawFastest != null && rawSlowest != null && rawSlowest >= rawFastest
                                val fastest = rawFastest.takeIf { validTargetRange }
                                val slowest = rawSlowest.takeIf { validTargetRange }
                                add(WorkoutBlockPaceFeedback(
                                    blockKey = block.optString("blockKey"),
                                    segmentIndex = block.optInt("segmentIndex", 0).coerceAtLeast(0),
                                    repetition = block.optInt("repetition", 1).coerceAtLeast(1),
                                    segmentName = block.optString("segmentName"),
                                    targetZone = block.optString("targetZone").takeIf { it.isNotBlank() },
                                    targetFastestPaceSecondsPerKm = fastest,
                                    targetSlowestPaceSecondsPerKm = slowest,
                                    actualPaceSecondsPerKm = actual,
                                    targetMode = block.optString("targetMode", "TIME").takeIf { it in setOf("TIME", "DISTANCE") } ?: "TIME",
                                    recoveryMode = block.optString("recoveryMode").takeIf { it.isNotBlank() }
                                ))
                            }
                        } }.orEmpty(),
                        recordedPaceSegments = item.optJSONArray("recordedPaceSegments")?.let { segments -> buildList {
                            for (index in 0 until segments.length()) {
                                val segment = segments.optJSONObject(index) ?: continue
                                val pace = segment.optInt("paceSecondsPerKm", 0)
                                val seconds = segment.optInt("durationSeconds", 0)
                                val sourceType = segment.optString("sourceType", "TRACK_SAMPLE")
                                val maxDuration = ActivityZoneTimeEngine.maxDurationForSource(sourceType)
                                if (pace in 120..1800 && seconds in 1..maxDuration) add(ActivityPaceSegment(
                                    paceSecondsPerKm = pace,
                                    durationSeconds = seconds,
                                    startElapsedSeconds = segment.optInt("startElapsedSeconds").takeIf { segment.has("startElapsedSeconds") && it >= 0 },
                                    startDistanceMeters = if (segment.has("startDistanceMeters")) segment.optDouble("startDistanceMeters") else null,
                                    distanceMeters = if (segment.has("distanceMeters")) segment.optDouble("distanceMeters") else null,
                                    averageHeartRateBpm = segment.optInt("averageHeartRateBpm").takeIf { segment.has("averageHeartRateBpm") && it in 30..240 },
                                    averageCadenceSpm = segment.optInt("averageCadenceSpm").takeIf { segment.has("averageCadenceSpm") && it in 30..300 },
                                    sourceType = sourceType,
                                    sourceBlockIndex = segment.optInt("sourceBlockIndex").takeIf { segment.has("sourceBlockIndex") && it >= 0 }
                                ))
                            }
                        } }.orEmpty(),
                        measuredZoneTimeSeconds = item.optJSONObject("measuredZoneTimeSeconds")?.let { measured -> buildMap {
                            measured.keys().forEach { zone ->
                                val seconds = measured.optInt(zone, 0)
                                if (zone in setOf("Z1", "Z2", "Z3", "Z4", "Z5") && seconds > 0) put(zone, seconds)
                            }
                        } }.orEmpty(),
                        elevationGainMeters = if (item.has("elevationGainMeters")) item.optDouble("elevationGainMeters") else null,
                        averageHeartRateBpm = if (item.has("averageHeartRateBpm")) item.optInt("averageHeartRateBpm") else null,
                        maxHeartRateBpm = if (item.has("maxHeartRateBpm")) item.optInt("maxHeartRateBpm") else null,
                        averageCadenceSpm = if (item.has("averageCadenceSpm")) item.optInt("averageCadenceSpm") else null,
                        maxCadenceSpm = if (item.has("maxCadenceSpm")) item.optInt("maxCadenceSpm") else null,
                        routePointCount = item.optInt("routePointCount", 0),
                        splitPacesMmSs = item.optJSONArray("splitPacesMmSs")?.let { splits -> buildList { for (index in 0 until splits.length()) add(splits.optString(index)) } }.orEmpty(),
                        splitDetails = item.optJSONArray("splitDetails")?.let { splits -> buildList {
                            for (index in 0 until splits.length()) {
                                val split = splits.optJSONObject(index) ?: continue
                                val distance = split.optDouble("distanceMeters", 0.0)
                                if (!distance.isFinite() || distance <= 0.0) continue
                                add(ActivitySplit(
                                    label = split.optString("label", "Trecho ${index + 1}"),
                                    distanceMeters = distance,
                                    durationSeconds = split.optInt("durationSeconds").takeIf { split.has("durationSeconds") && it > 0 },
                                    paceSecondsPerKm = split.optInt("paceSecondsPerKm").takeIf { split.has("paceSecondsPerKm") && it in 120..1800 },
                                    sourceType = split.optString("sourceType", "LEGACY"),
                                    startDistanceMeters = split.optDouble("startDistanceMeters").takeIf { split.has("startDistanceMeters") && it >= 0.0 }
                                ))
                            }
                        } }.orEmpty(),
                        encodedRoute = item.optString("encodedRoute")
                    ))
                }
            }
        } }
        prefs.getString("cooperAssessments", null)?.let { raw -> runCatching {
            val a = JSONArray(raw)
            cooperAssessments = buildList {
                for (i in 0 until a.length()) {
                    val item = a.optJSONObject(i) ?: continue
                    val distanceKm = item.optDouble("distanceKm")
                    val calculatedSnapshot = PaceCalculator.calculateCooper(distanceKm)
                    val storedRanges = item.optJSONObject("zoneRanges")
                    val storedModelVersion = item.optString("zoneModelVersion")
                    val zoneRanges = if (storedRanges != null) {
                        buildMap { for (key in listOf("Z1", "Z2", "Z3", "Z4", "Z5")) {
                            storedRanges.optString(key).takeIf { it.isNotBlank() }?.let { put(key, it) }
                        } }
                    } else calculatedSnapshot?.all()?.associate { it.id to it.range.label() }.orEmpty()
                    val resolvedModelVersion = when {
                        storedModelVersion.isNotBlank() -> storedModelVersion
                        storedRanges != null -> "AIRC_ZONES_1_LEGACY"
                        else -> calculatedSnapshot?.modelVersion ?: PaceCalculator.ZONE_MODEL_VERSION
                    }
                    val isCurrentZoneModel = resolvedModelVersion == PaceCalculator.ZONE_MODEL_VERSION
                    add(CooperAssessmentRecord(
                        dateIso = item.optString("dateIso"), distanceKm = distanceKm,
                        estimatedVo2Max = item.optDouble("estimatedVo2Max", calculatedSnapshot?.estimatedVo2Max ?: 0.0),
                        averagePace = item.optString("averagePace", calculatedSnapshot?.averageTestPaceValue?.let { PaceRange.format(it) } ?: ""),
                        estimatedMasPace = if (isCurrentZoneModel) item.optString("estimatedMasPace", calculatedSnapshot?.estimatedMasPace ?: "") else "",
                        estimatedSvt2Pace = if (isCurrentZoneModel) item.optString("estimatedSvt2Pace", calculatedSnapshot?.estimatedSvt2Pace ?: "") else "",
                        zoneModelVersion = resolvedModelVersion,
                        zoneRanges = zoneRanges,
                        z2CalibrationStatus = item.optString("z2CalibrationStatus", "COOPER_INITIAL"),
                        talkTestEvidenceCount = item.optInt("talkTestEvidenceCount", 0),
                        talkTestReferencePaceMmSs = item.optString("talkTestReferencePaceMmSs", ""),
                        z1CalibrationStatus = item.optString("z1CalibrationStatus", ZoneCalibrationEngine.INITIAL),
                        z1CalibrationEvidenceCount = item.optInt("z1CalibrationEvidenceCount", 0),
                        z3CalibrationStatus = item.optString("z3CalibrationStatus", ZoneCalibrationEngine.INITIAL),
                        z3CalibrationEvidenceCount = item.optInt("z3CalibrationEvidenceCount", 0),
                        testMethod = item.optString("testMethod", "COOPER_12_MIN"),
                        testDurationSeconds = if (item.has("testDurationSeconds")) item.optInt("testDurationSeconds") else null,
                        referenceSex = item.optString("referenceSex", ""),
                        ageAtTest = if (item.has("ageAtTest")) item.optInt("ageAtTest") else null
                    ))
                }
            }.sortedBy { it.dateIso }
        } }
        if (!prefs.contains("fitnessTestMethod") || (fitnessTestMethod == "NONE" && cooperAssessments.isNotEmpty() && ageYearsText.isBlank() && referenceSex.isBlank())) {
            fitnessTestMethod = cooperAssessments.lastOrNull()?.testMethod ?: if (cooperEnabled) "COOPER_12_MIN" else "NONE"
        }
        // V72: one demographic source. Legacy test snapshots missing age/sex are
        // completed from the athlete profile; a stored historical value is never overwritten.
        val assessmentsBeforeDemographicMigration = cooperAssessments
        val referenceBeforeDemographicMigration = referenceSex
        if (referenceSex !in setOf(RunnerFitnessAssessmentEngine.MALE, RunnerFitnessAssessmentEngine.FEMALE)) {
            referenceSex = cooperAssessments.asReversed().firstOrNull {
                it.referenceSex in setOf(RunnerFitnessAssessmentEngine.MALE, RunnerFitnessAssessmentEngine.FEMALE)
            }?.referenceSex.orEmpty()
        }
        cooperAssessments = cooperAssessments.map { record ->
            val testDate = runCatching { LocalDate.parse(record.dateIso) }.getOrNull()
            val profileAge = testDate?.let(::ageAtDate) ?: parsedAgeYears()
            record.copy(
                ageAtTest = record.ageAtTest ?: profileAge,
                referenceSex = record.referenceSex.takeIf { it in setOf(RunnerFitnessAssessmentEngine.MALE, RunnerFitnessAssessmentEngine.FEMALE) } ?: referenceSex
            )
        }
        val profileDemographicsMigrated = cooperAssessments != assessmentsBeforeDemographicMigration || referenceSex != referenceBeforeDemographicMigration
        val newestFieldAssessment = cooperAssessments.maxByOrNull { it.dateIso }
        val storedPhysiology = newestFieldAssessment?.let { record ->
            val testDate = runCatching { LocalDate.parse(record.dateIso) }.getOrNull()
            val ageAtTest = record.ageAtTest ?: testDate?.let(::ageAtDate) ?: parsedAgeYears()
            val sexAtTest = record.referenceSex.takeIf { it in setOf(RunnerFitnessAssessmentEngine.MALE, RunnerFitnessAssessmentEngine.FEMALE) } ?: referenceSex
            if (ageAtTest != null && sexAtTest in setOf(RunnerFitnessAssessmentEngine.MALE, RunnerFitnessAssessmentEngine.FEMALE)) {
                RunnerFitnessAssessmentEngine.assess(record.estimatedVo2Max, ageAtTest, sexAtTest, "FIELD_ESTIMATE")
            } else null
        }
        // Self-selected/legacy levels are not trusted as physiological classes. Until
        // an assessment with age/sex metadata is available, keep a conservative internal
        // guardrail and show "Aguardando teste" in the interface.
        level = storedPhysiology?.level ?: "Iniciante"
        if (newestFieldAssessment != null && storedPhysiology == null && latestCooperMessage.contains("Nível fisiológico", ignoreCase = true)) {
            latestCooperMessage = "Resultado histórico preservado: VO₂máx ${String.format(Locale.US, "%.1f", newestFieldAssessment.estimatedVo2Max)}. Complete os dados demográficos no perfil para calcular o nível."
        }
        val feedbackSessionIds = feedbackRecords.map { it.sessionId }.toSet()
        if (feedbackSessionIds.isNotEmpty()) {
            workouts = workouts.map { workout -> if (workout.sessionId in feedbackSessionIds && !workout.done) workout.copy(done = true) else workout }
        }
        if (activeZoneBandMigration) {
            workouts = workouts.map { workout ->
                if (workout.done) workout else ZoneIntensityBandEngine.apply(workout)
            }
            needsEngineRefresh = true
        }
        syncTargetDate()
        feedbackSaved = feedbackRecords.isNotEmpty()

        // Se o perfil legado não tem volume numérico, leva diretamente à revisão do dado obrigatório.
        if (goal.isNotBlank() && workouts.isEmpty()) onboardingStep = 1
        // Um plano antigo permanece acessível; o painel pede revisão antes da nova geração.
        if (goal.isNotBlank() && workouts.isNotEmpty()) onboardingStep = 8
        if (migrateV40WeekNumbering || durationEstimateMigrated || markEngineV35 || activeZoneBandMigration || feedbackSessionIds.isNotEmpty() || profileDemographicsMigrated) {
            if (activeZoneBandMigration) prefs.edit().putInt("engineVersion", 36).apply()
            persist(synchronous = feedbackSessionIds.isNotEmpty())
        }
    }
}
private val AppColors = darkColorScheme(
    primary = Blue,
    onPrimary = Color(0xFF101827),
    secondary = Green,
    onSecondary = Color(0xFF0D201B),
    tertiary = Yellow,
    background = Navy,
    surface = Navy2,
    surfaceVariant = CardBlue,
    onBackground = TextWhite,
    onSurface = TextWhite,
    onSurfaceVariant = TextMuted
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RunningCoachApp() }
    }
}

@Composable
private fun RunningCoachApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val state = remember(context) { CoachState(context.applicationContext) }
    MaterialTheme(colorScheme = AppColors) {
        Surface(Modifier.fillMaxSize(), color = Navy) {
            if (state.onboardingStep in -1..6) Onboarding(state) else MainShell(state)
        }
    }
}

@Composable
private fun Onboarding(state: CoachState) {
    val step = state.onboardingStep
    var pendingRestoreUri by remember { mutableStateOf<Uri?>(null) }
    val importBackupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) pendingRestoreUri = uri }
    BackHandler(enabled = step >= 0) { state.onboardingStep = if (step > 0) step - 1 else -1; state.persist() }
    Column(Modifier.fillMaxSize().background(Navy).verticalScroll(rememberScrollState()).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(12.dp)); OnboardingBrandHeader(); Spacer(Modifier.height(18.dp)); OnboardingStepProgress(step)
        Spacer(Modifier.height(if (step == -1) 24.dp else 20.dp))
        when (step) {
            -1 -> { BigRunnerMark(); Text("Seu plano. Sua evolução.", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Text("Treinos definidos pelo seu condicionamento e ajustados pela resposta às sessões.", color = TextMuted, textAlign = TextAlign.Center, modifier = Modifier.padding(12.dp)) }
            0 -> {
                Text("Vamos começar", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = TextWhite)
                Text("Como podemos chamar você?", color = TextMuted, fontSize = 13.sp)
                OutlinedTextField(
                    value = state.name,
                    onValueChange = { state.name = it.take(40); state.persist() },
                    label = { Text("Seu nome") },
                    placeholder = { Text("Digite seu nome") },
                    modifier = Modifier.fillMaxWidth(), singleLine = true
                )
                OutlinedTextField(
                    value = state.birthDateText,
                    onValueChange = { state.birthDateText = SmartInputMask.date(it); state.refreshPhysiologicalLevelFromTest() },
                    label = { Text("Data de nascimento (dd/mm/aaaa)") }, placeholder = { Text("Ex.: 14/06/1990") },
                    supportingText = { Text("A idade será calculada automaticamente para cada avaliação.") },
                    modifier = Modifier.fillMaxWidth(), singleLine = true
                )
                if (state.birthDateText.isBlank()) {
                    OutlinedTextField(
                        value = state.ageYearsText,
                        onValueChange = { state.ageYearsText = it.filter(Char::isDigit).take(3); state.refreshPhysiologicalLevelFromTest() },
                        label = { Text("Ou informe somente a idade atual") }, placeholder = { Text("Ex.: 36") },
                        modifier = Modifier.fillMaxWidth(), singleLine = true
                    )
                } else {
                    Text("Idade atual calculada: ${state.profileAgeLabel()}", color = Blue2, fontSize = 12.sp)
                }
                Text("Esses dados serão cadastrados uma única vez e utilizados nas avaliações seguintes. Não será necessário repetir a idade em cada teste.", color = TextMuted, textAlign = TextAlign.Center, fontSize = 11.sp, lineHeight = 16.sp, modifier = Modifier.padding(8.dp))
            }
            1 -> FieldTestOnboardingStep(state)
            2 -> {
                Text("Qual objetivo deseja alcançar?", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = TextWhite)
                val latestAssessment = state.cooperAssessments.maxByOrNull { it.dateIso }
                Text("Nível fisiológico: ${state.physiologicalLevelDisplay()}" + (latestAssessment?.let { " • VO₂máx ${String.format(Locale.US, "%.1f", it.estimatedVo2Max)}" } ?: ""), color = Blue2, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(if (state.physiologicalLevelDisplay().startsWith("Aguardando")) "Sem referência fisiológica completa, o plano fica em dose de entrada. Com idade, referência fisiológica e teste válidos, as metas são liberadas até a distância compatível. A experiência não altera o nível." else "Os objetivos até a maratona ficam disponíveis para Iniciante e Intermediário. O nível fisiológico calibra ritmos e estímulos; a base e a capacidade anterior presumida vêm da distância escolhida.", color = TextMuted, fontSize = 12.sp, lineHeight = 17.sp)
                Spacer(Modifier.height(10.dp))
                ChoiceScreen("Objetivo", TrainingGoalCatalog.labelsForLevel(state.level), state.goal) {
                    if (state.goal != it) {
                        state.goalTargetTimeText = ""
                        state.personalBestTimeText = ""
                    }
                    state.goal = it
                    state.goalIntent = if (it == "Saúde e qualidade de vida") TrainingGoalIntent.HEALTH else if (state.goalIntent == TrainingGoalIntent.HEALTH) TrainingGoalIntent.COMPLETE else state.goalIntent
                    state.markPlanNeedsRefreshIfObjectiveChanged()
                    state.persist()
                }
                if (state.goal.isNotBlank() && state.goal != "Saúde e qualidade de vida") {
                    Spacer(Modifier.height(12.dp))
                    ChoiceScreen("Prioridade do plano", TrainingGoalIntent.performanceOptions, TrainingGoalIntent.label(state.goalIntent)) { state.goalIntent = TrainingGoalIntent.fromLabel(it); state.markPlanNeedsRefreshIfObjectiveChanged(); state.persist() }
                    val priorityGuidance = when (state.goalIntent) {
                        TrainingGoalIntent.COMPLETE -> "Prioriza resistência aeróbica, rodagens controladas e longão contínuo para completar a distância com esforço sustentável."
                        TrainingGoalIntent.CONTINUOUS -> "Aumenta o tempo correndo sem interrupções, usando progressões contínuas e reduzindo pausas conforme a tolerância."
                        TrainingGoalIntent.PERSONAL_BEST -> "Distribui estímulos de limiar, intervalados e velocidade quando a carga e a recuperação permitem, buscando melhorar seu recorde atual."
                        TrainingGoalIntent.TARGET_TIME -> "Organiza blocos específicos no ritmo necessário para sua meta e verifica se o tempo é compatível com seus testes e zonas atuais."
                        else -> "Treinos leves e regulares com foco em saúde e consistência."
                    }
                    Text(priorityGuidance, color = Blue2, fontSize = 11.sp, lineHeight = 16.sp, modifier = Modifier.padding(top = 6.dp))
                    if (state.goalIntent == TrainingGoalIntent.TARGET_TIME) OutlinedTextField(
                        value = state.goalTargetTimeText,
                        onValueChange = { state.goalTargetTimeText = SmartInputMask.duration(it); state.markPlanNeedsRefreshIfObjectiveChanged(); state.persist() },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        label = { Text("Tempo desejado (mm:ss ou hh:mm:ss)") }, supportingText = { Text("Meta de resultado; não substitui suas zonas fisiológicas.") },
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp), singleLine = true
                    )
                    if (state.goalIntent == TrainingGoalIntent.PERSONAL_BEST) OutlinedTextField(
                        value = state.personalBestTimeText,
                        onValueChange = { state.personalBestTimeText = SmartInputMask.duration(it); state.markPlanNeedsRefreshIfObjectiveChanged(); state.persist() },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        label = { Text("Recorde pessoal atual (mm:ss ou hh:mm:ss)") },
                        supportingText = { Text("Informe seu melhor tempo na distância selecionada. Será usado como referência, sem substituir as zonas fisiológicas.") },
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp), singleLine = true
                    )
                }
            }
            3 -> {
                Text("Há quanto tempo pratica corrida?", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = TextWhite)
                Text("Este dado contextualiza sua experiência, mas não muda o nível fisiológico estimado pelo teste.", color = TextMuted, fontSize = 12.sp, lineHeight = 17.sp)
                Spacer(Modifier.height(12.dp))
                ChoiceScreen("Tempo de prática regular", listOf("Menos de 6 meses", "6–12 meses", "1–3 anos", "3–5 anos", "Mais de 5 anos"), state.runningExperienceDuration) { state.runningExperienceDuration = it; state.markPlanNeedsRefreshIfObjectiveChanged(); state.persist() }
            }
            4 -> {
                Text("Quando e onde você corre?", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = TextWhite)
                TrainingAvailabilityEditor(state, showLongRunPreference = true)
                Spacer(Modifier.height(12.dp))
                ChoiceScreen("Onde costuma correr?", RunningTerrain.options, RunningTerrain.label(state.terrainPreference)) { state.terrainPreference = RunningTerrain.fromLabel(it); state.persist() }
            }
            5 -> {
                Text("Quanto você corre por semana?", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = TextWhite)
                Text("Informe sua média real recente. Se deixar em branco, será usada a base fixa do objetivo; se não correu, informe 0.", color = TextMuted, fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(value = state.weeklyVolumeText, onValueChange = { state.weeklyVolumeText = SmartInputMask.distance(it); state.markPlanNeedsRefreshIfObjectiveChanged(); state.persist() }, label = { Text("Média das últimas 4 semanas (km) — opcional") }, supportingText = { Text("Ex.: 30 km. Em branco usa a base do objetivo; informe 0 somente se não correu.") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth(), singleLine = true)
                val selectedDistance = TrainingGoalCatalog.distanceForLabel(state.goal, state.customGoalKm.trim().replace(",", ".").toDoubleOrNull())
                val selectedLoad = selectedDistance?.let { TrainingPlanReferenceCatalog.loadReference(it, TrainingGoalCatalog.categoryForLabel(state.goal)) }
                if (selectedLoad != null) Text("Base armazenada para ${state.goal}: ${String.format(Locale.US, "%.1f", selectedLoad.baseWeeklyKm)} km/semana; teto de construção: ${String.format(Locale.US, "%.1f", selectedLoad.maximumBuildWeeklyKm)} km/semana; referência de frequência: ${selectedLoad.recommendedFrequency} dias/semana. Histórico real informado substitui a base quando disponível.", color = Blue2, fontSize = 11.sp, lineHeight = 16.sp)
            }
            6 -> {
                Text("Qual foi sua maior corrida recente?", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = TextWhite)
                Text("Informe a maior distância contínua que realmente concluiu. Em branco usa a capacidade anterior presumida do objetivo; informe 0 se nunca concluiu corrida contínua.", color = TextMuted, fontSize = 12.sp, lineHeight = 17.sp)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(value = state.longestRecent, onValueChange = { state.longestRecent = SmartInputMask.distance(it); state.markPlanNeedsRefreshIfObjectiveChanged(); state.persist() }, label = { Text("Maior percurso contínuo recente (km) — opcional") }, supportingText = { Text("Em branco usa a referência anterior do objetivo; 0 indica que ainda não concluiu corrida contínua.") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth(), singleLine = true)
                val selectedDistance = TrainingGoalCatalog.distanceForLabel(state.goal, state.customGoalKm.trim().replace(",", ".").toDoubleOrNull())
                val selectedLoad = selectedDistance?.let { TrainingPlanReferenceCatalog.loadReference(it, TrainingGoalCatalog.categoryForLabel(state.goal)) }
                if (selectedLoad != null) Text(
                    "Capacidade anterior presumida para ${state.goal}: ${String.format(Locale.US, "%.1f", selectedLoad.assumedPreviousContinuousDistanceKm)} km contínuos. Base semanal: ${String.format(Locale.US, "%.1f", selectedLoad.baseWeeklyKm)} km; teto: ${String.format(Locale.US, "%.1f", selectedLoad.maximumBuildWeeklyKm)} km; frequência de referência: ${selectedLoad.recommendedFrequency} dias/semana. Corredor com 5 km contínuos não recebe corrida/caminhada.",
                    color = Blue2, fontSize = 11.sp, lineHeight = 16.sp
                )
            }
        }
        Spacer(Modifier.height(26.dp))
        val beginner = RunnerFitnessAssessmentEngine.normalizeLevel(state.level) == "Iniciante"
        val weekly = state.weeklyVolumeText.trim().replace(",", ".").toDoubleOrNull()
        val longest = state.longestRecent.trim().replace(",", ".").toDoubleOrNull()
        val goalValid = state.goal.isNotBlank() && state.goal in TrainingGoalCatalog.labelsForLevel(state.level) &&
            (state.goal != "Outro objetivo" || state.customGoalKm.trim().replace(",", ".").toDoubleOrNull()?.let { it in 1.0..200.0 } == true) &&
            (state.goal == "Saúde e qualidade de vida" || when (state.goalIntent) {
                TrainingGoalIntent.TARGET_TIME -> PhysiologicalProfileEngine.parseTargetTime(state.goalTargetTimeText) != null
                TrainingGoalIntent.PERSONAL_BEST -> PhysiologicalProfileEngine.parseTargetTime(state.personalBestTimeText) != null
                else -> true
            })
        val canContinue = when (step) {
            0 -> state.name.trim().length >= 2 && state.parsedAgeYears() != null
            1 -> state.isCooperEntryValid()
            2 -> goalValid
            3 -> state.runningExperienceDuration.isNotBlank()
            4 -> state.availableTrainingDays.size in 2..6 && state.frequency == state.availableTrainingDays.size
            5 -> state.weeklyVolumeText.isBlank() || weekly?.let { it in 0.0..300.0 } == true
            6 -> goalValid && (state.longestRecent.isBlank() || longest?.let { it in 0.0..200.0 } == true)
            else -> true
        }
        PrimaryButton(if (step == 6) "Criar meu plano" else if (step == -1) "Começar Novo Plano" else if (step == 0) "Continuar" else "Continuar", enabled = canContinue) {
            if (step == 6) state.createPlan() else if (step == 1 && !state.saveCurrentFieldTestToHistory()) state.persist() else { state.onboardingStep++; state.persist() }
        }
        if (step == -1) {
            Spacer(Modifier.height(10.dp))
            SecondaryButton("Importar Backup") { state.backupMessage = ""; importBackupLauncher.launch(arrayOf("application/json", "text/json", "application/octet-stream")) }
            Text("Recupere seu perfil, plano, sessões e histórico de outro aparelho.", color = TextMuted, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp))
            if (state.backupMessage.isNotBlank()) Text(state.backupMessage, color = Color(0xFFFFA0A0), fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp))
        }
        if (state.motorError.isNotBlank()) Text(state.motorError, color = Color(0xFFFF8A8A), fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
        Spacer(Modifier.height(18.dp))
    }
    if (pendingRestoreUri != null) AlertDialog(
        onDismissRequest = { pendingRestoreUri = null }, title = { Text("Importar backup?") },
        text = { Text("O arquivo será validado antes da restauração. Se for válido, os dados locais serão substituídos pelo perfil, plano, sessões, feedbacks e histórico do backup. Deseja continuar?") },
        confirmButton = { TextButton(onClick = { val uri = pendingRestoreUri; pendingRestoreUri = null; if (uri != null) state.restoreBackup(uri) }) { Text("Importar e restaurar") } },
        dismissButton = { TextButton(onClick = { pendingRestoreUri = null }) { Text("Cancelar") } }
    )
}

@Composable
private fun FieldTestOnboardingStep(state: CoachState) {
    val zones = state.selectedFieldTestZones()
    val assessment = zones?.let { z ->
        state.parsedAssessmentAge()?.let { age -> RunnerFitnessAssessmentEngine.assess(z.estimatedVo2Max, age, state.referenceSex, "FIELD_ESTIMATE") }
    }
    val selectedTest = when (state.fitnessTestMethod) {
        "COOPER_12_MIN" -> "Cooper (12 min)"
        "THREE_KM" -> "Corrida de 3 km"
        else -> "Ainda não tenho teste"
    }
    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Text("Avaliação fisiológica", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = TextWhite)
        Text("O teste estima seu VO₂máx e define a faixa fisiológica. Experiência e volume ajustam a dose, não mudam essa classificação.", color = TextMuted, fontSize = 12.sp, lineHeight = 16.sp)
        CardSurface(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Idade do atleta: ${state.profileAgeLabel()}", color = Blue2, fontSize = 12.sp)
                Text("A avaliação calcula automaticamente a idade na data do teste a partir do nascimento; se o perfil antigo só tiver idade, esse valor será utilizado.", color = TextMuted, fontSize = 10.sp)
                if (state.referenceSex !in setOf(RunnerFitnessAssessmentEngine.MALE, RunnerFitnessAssessmentEngine.FEMALE)) {
                    CompactChoiceScreen(
                        title = "Referência fisiológica do perfil",
                        options = listOf("Masculino", "Feminino"),
                        current = ""
                    ) {
                        state.referenceSex = if (it == "Masculino") RunnerFitnessAssessmentEngine.MALE else RunnerFitnessAssessmentEngine.FEMALE
                        state.refreshPhysiologicalLevelFromTest()
                    }
                } else {
                    Text(
                        "Referência do perfil: ${if (state.referenceSex == RunnerFitnessAssessmentEngine.MALE) "Masculina" else "Feminina"}. Ela será reutilizada nas próximas avaliações.",
                        color = Blue2, fontSize = 10.sp, lineHeight = 14.sp
                    )
                }
                CompactChoiceScreen(
                    title = "Teste utilizado",
                    options = listOf("Cooper (12 min)", "Corrida de 3 km", "Ainda não tenho teste"),
                    current = selectedTest
                ) { selected ->
                    state.fitnessTestMethod = when (selected) {
                        "Cooper (12 min)" -> "COOPER_12_MIN"
                        "Corrida de 3 km" -> "THREE_KM"
                        else -> "NONE"
                    }
                    state.cooperEnabled = state.fitnessTestMethod != "NONE"
                    state.latestCooperMessage = ""
                    state.refreshPhysiologicalLevelFromTest()
                }
                when (state.fitnessTestMethod) {
                    "COOPER_12_MIN" -> {
                        OutlinedTextField(
                            value = state.cooperDistanceText,
                            onValueChange = { state.cooperDistanceText = SmartInputMask.distance(it); state.refreshPhysiologicalLevelFromTest() },
                            label = { Text("Distância em 12 minutos (km)") }, placeholder = { Text("Ex.: 2,10") },
                            modifier = Modifier.fillMaxWidth(), singleLine = true
                        )
                        Text("Registre a distância total percorrida em 12 minutos, em percurso medido.", color = TextMuted, fontSize = 10.sp, lineHeight = 14.sp)
                    }
                    "THREE_KM" -> {
                        OutlinedTextField(
                            value = state.threeKmTimeText,
                            onValueChange = { state.threeKmTimeText = SmartInputMask.duration(it); state.refreshPhysiologicalLevelFromTest() },
                            label = { Text("Tempo para 3 km (mm:ss)") }, placeholder = { Text("Ex.: 15:30") },
                            modifier = Modifier.fillMaxWidth(), singleLine = true
                        )
                        Text("Use percurso plano e medido, em esforço forte e contínuo. A equação disponível foi validada para adultos de 18 a 39 anos.", color = TextMuted, fontSize = 10.sp, lineHeight = 14.sp)
                    }
                    else -> Text("Sem teste: o perfil fica como Aguardando avaliação. Um plano de entrada usa dose conservadora; registre Cooper ou 3 km depois para calcular VO₂máx e calibrar as zonas.", color = Blue2, fontSize = 10.sp, lineHeight = 14.sp)
                }
                if (state.fitnessTestMethod != "NONE") {
                    OutlinedTextField(
                        value = state.cooperAssessmentDateText,
                        onValueChange = { state.cooperAssessmentDateText = SmartInputMask.date(it); state.persist() },
                        label = { Text("Data do teste (dd/mm/aaaa)") }, modifier = Modifier.fillMaxWidth(), singleLine = true
                    )
                }
                if (assessment != null) {
                    HorizontalDivider(color = Color(0x443F5878))
                    Text("VO₂máx estimado: ${String.format(Locale.US, "%.1f", assessment.vo2Max)} ml/kg/min", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("Nível fisiológico: ${assessment.level} • confiança ${if (state.fitnessTestMethod == "THREE_KM") "moderada" else "estimativa de campo"}", color = Green, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    val t = assessment.thresholds
                    Text(
                        "Iniciante < ${String.format(Locale.US, "%.1f", t.intermediate)} • Intermediário ${String.format(Locale.US, "%.1f", t.intermediate)}–${String.format(Locale.US, "%.1f", t.performance - 0.1)} • Performance ${String.format(Locale.US, "%.1f", t.performance)}–${String.format(Locale.US, "%.1f", t.elite - 0.1)} • Elite ≥ ${String.format(Locale.US, "%.1f", t.elite)}",
                        color = TextMuted, fontSize = 10.sp, lineHeight = 14.sp
                    )
                    Text("Referência geral de aptidão por idade e sexo; não é ranking competitivo.", color = TextMuted, fontSize = 9.sp, lineHeight = 13.sp)
                    Text("Zonas de ritmo individuais (min/km)", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    zones!!.all().forEach { zone ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${zone.id} • ${zone.name}", color = TextMuted, fontSize = 10.sp)
                            Text(zone.range.label(), color = TextWhite, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                } else if (state.fitnessTestMethod != "NONE") {
                    Text("Informe idade, referência fisiológica e resultado válido para liberar a classificação.", color = Yellow, fontSize = 10.sp, lineHeight = 14.sp)
                }
            }
        }
        Text("VO₂máx de campo é uma estimativa, não uma medição laboratorial. A carga continua limitada pela tolerância e pela recuperação.", color = TextMuted, fontSize = 9.sp, lineHeight = 13.sp)
    }
}

@Composable private fun OnboardingBrandHeader() {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.onboarding_app_icon),
            contentDescription = "Ícone AI Running Coach",
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(42.dp).clip(RoundedCornerShape(12.dp))
        )
        Spacer(Modifier.width(10.dp))
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("AI RUNNING COACH", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Black, letterSpacing = 1.1.sp)
            Text("PRESCREVE HOJE · EVOLUI SEMPRE", color = Blue2, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.35.sp)
        }
    }
}


@Composable
private fun CompactChoiceScreen(
    title: String,
    options: List<String>,
    current: String,
    selected: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(title, color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        options.chunked(2).forEach { rowOptions ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                rowOptions.forEach { option ->
                    val active = option == current
                    Surface(
                        modifier = Modifier.weight(1f).heightIn(min = 46.dp)
                            .then(if (active) Modifier.border(1.5.dp, Blue, RoundedCornerShape(10.dp)) else Modifier)
                            .clickable { selected(option) },
                        color = if (active) Color(0xFF174968) else CardBlue,
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(Modifier.padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = active, onClick = { selected(option) }, modifier = Modifier.size(28.dp))
                            Spacer(Modifier.width(5.dp))
                            Text(option, color = if (active) TextWhite else TextMuted, fontSize = 10.sp, lineHeight = 13.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium)
                        }
                    }
                }
                if (rowOptions.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable private fun OnboardingStepProgress(step: Int) {
    if (step !in 1..6) return
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            repeat(6) { index ->
                Box(Modifier.weight(1f).height(5.dp).clip(RoundedCornerShape(8.dp)).background(if (index < step) Blue else Color(0xFF29384D)))
            }
        }
        Text("ETAPA $step DE 6", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
    }
}

@Composable private fun BigRunnerMark() {
    Image(
        painter = painterResource(id = R.drawable.onboarding_app_icon),
        contentDescription = "Marca AI Running Coach",
        contentScale = ContentScale.Crop,
        modifier = Modifier.size(132.dp).clip(RoundedCornerShape(30.dp))
    )
}

@Composable private fun CooperOnboardingStep(state: CoachState) {
    val distance = state.cooperDistanceText.trim().replace(",", ".").toDoubleOrNull()
    val zones = state.calculateZonesForCooper(distance)
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text("Calibre suas zonas", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = TextWhite)
            Text("Informe um teste de Cooper recente (12 minutos). O resultado ajuda a estimar suas zonas de ritmo.", color = TextMuted, fontSize = 12.sp, lineHeight = 17.sp)
        }
        CardSurface(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("Tenho um resultado recente", color = TextWhite, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text("Preferencialmente das últimas 4–8 semanas", color = TextMuted, fontSize = 10.sp)
                    }
                    Switch(checked = state.cooperEnabled, onCheckedChange = { state.cooperEnabled = it; state.persist() })
                }
                if (state.cooperEnabled) {
                    OutlinedTextField(
                        value = state.cooperDistanceText,
                        onValueChange = { value ->
                            state.cooperDistanceText = SmartInputMask.distance(value)
                            state.persist()
                        },
                        label = { Text("Distância em 12 min (km)") },
                        placeholder = { Text("Ex.: 2,40") },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color(0xFF49617F))
                    )
                    OutlinedTextField(
                        value = state.cooperAssessmentDateText,
                        onValueChange = { value ->
                            state.cooperAssessmentDateText = SmartInputMask.date(value)
                            state.persist()
                        },
                        label = { Text("Data do teste (dd/mm/aaaa)") },
                        placeholder = { Text("dd/mm/aaaa") },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color(0xFF49617F))
                    )
                    if (zones != null) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            CooperMetric("RITMO MÉDIO", "${PaceRange.format(zones.averageTestPaceValue)}", Modifier.weight(1f))
                            CooperMetric("VAM ESTIMADA", zones.estimatedMasPace, Modifier.weight(1f))
                            CooperMetric("VO₂ MÁX*", String.format(Locale.US, "%.1f", zones.estimatedVo2Max), Modifier.weight(1f))
                        }
                        Text("Segundo limiar estimado: ${zones.estimatedSvt2Pace} min/km", color = TextMuted, fontSize = 10.sp)
                        Text("Zonas estimadas (min/km)", color = Blue2, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        zones.all().chunked(2).forEach { pair ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                pair.forEach { zone ->
                                    Row(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(Navy2).padding(horizontal = 10.dp, vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(zone.id, color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        Text(zone.range.label(), color = TextWhite, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                }
                                if (pair.size == 1) Spacer(Modifier.weight(1f))
                            }
                        }
                        Text("*VO₂máx e VAM são estimativas de campo, não medições laboratoriais.", color = TextMuted, fontSize = 9.sp)
                    } else if (state.cooperDistanceText.isNotBlank()) {
                        Text("Informe uma distância entre 1,00 e 5,00 km.", color = Yellow, fontSize = 11.sp)
                    }
                } else {
                    Text("Você pode continuar sem o teste. O plano será criado, mas as zonas de ritmo ficarão sem calibração até registrar um Cooper.", color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                }
            }
        }
        CardSurface(Modifier.fillMaxWidth(), containerColor = Navy2) {
            Row(Modifier.padding(13.dp), horizontalArrangement = Arrangement.spacedBy(9.dp), verticalAlignment = Alignment.Top) {
                Text("ⓘ", color = Blue2, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text("Faça o teste descansado, em percurso plano e medido. Ele substitui uma sessão forte da semana; não realize com dor, doença ou recuperação insuficiente.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
            }
        }
        Text("Ritmo em mm:ss min/km · Distâncias em km · Duração do teste: 12 min", color = Blue2, fontSize = 10.sp)
    }
}

@Composable private fun CooperMetric(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(10.dp)).background(Navy2).padding(9.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(label, color = TextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(value, color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable private fun TrainingAvailabilityEditor(state: CoachState, showLongRunPreference: Boolean) {
    val days = DayOfWeek.values().toList()
    val rows = days.chunked(2)
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Dias de corrida", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text("Selecione de 2 a 6 dias. O plano usará somente esses dias.", color = TextMuted, fontSize = 11.sp)
            }
            rows.forEach { rowDays ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    rowDays.forEach { day ->
                        AvailabilityDayButton(
                            label = dayLabel(day),
                            selected = day in state.availableTrainingDays,
                            modifier = Modifier.weight(1f)
                        ) { state.setTrainingDay(day, day !in state.availableTrainingDays) }
                    }
                    if (rowDays.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("${state.availableTrainingDays.size} de 6 dias selecionados", color = Blue2, fontWeight = FontWeight.SemiBold, fontSize = 11.sp, modifier = Modifier.weight(1f))
                if (state.availableTrainingDays.size in 2..6) StatusPill("DISPONIBILIDADE", Green)
            }
            if (showLongRunPreference && state.availableTrainingDays.isNotEmpty()) {
                HorizontalDivider(color = Color(0x443F5878))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Dia preferido do longão", color = TextWhite, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        state.availableTrainingDays.forEach { day ->
                            AvailabilityDayButton(
                                label = dayLabel(day),
                                selected = state.preferredLongRunDay == day,
                                modifier = Modifier.widthIn(min = 82.dp)
                            ) { state.setLongRunDay(day) }
                        }
                    }
                }
            }
            if (state.scheduleActionMessage.isNotBlank()) Text(state.scheduleActionMessage, color = Green, fontSize = 10.sp, lineHeight = 14.sp)
        }
    }
}

@Composable private fun AvailabilityDayButton(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(
        modifier = modifier.height(46.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        color = if (selected) Color(0xFF304A70) else Color(0xFF142337),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) Blue.copy(alpha = 0.8f) else Color(0xFF34465E))
    ) {
        Row(Modifier.fillMaxSize().padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.size(15.dp).clip(RoundedCornerShape(50)).background(if (selected) Blue else Color.Transparent).border(1.dp, if (selected) Blue else TextMuted, RoundedCornerShape(50)), contentAlignment = Alignment.Center) {
                if (selected) Text("✓", color = Navy, fontSize = 9.sp, fontWeight = FontWeight.Black)
            }
            Text(label, color = if (selected) TextWhite else TextMuted, fontSize = 10.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
        }
    }
}

private fun dayLabel(day: DayOfWeek): String = when (day) {
    DayOfWeek.MONDAY -> "Segunda"
    DayOfWeek.TUESDAY -> "Terça"
    DayOfWeek.WEDNESDAY -> "Quarta"
    DayOfWeek.THURSDAY -> "Quinta"
    DayOfWeek.FRIDAY -> "Sexta"
    DayOfWeek.SATURDAY -> "Sábado"
    DayOfWeek.SUNDAY -> "Domingo"
}

private fun calendarCategory(workout: Workout): String = when {
    workout.type == "Recuperação" -> "REGENERATIVO"
    workout.type == "Longo" -> "LONGÃO"
    workout.type == "Qualidade" && (workout.title.contains("VO2", true) || workout.title.contains("interval", true)) -> "INTERVALADO"
    workout.type == "Qualidade" && workout.title.contains("fartlek", true) -> "FARTLEK"
    workout.type == "Qualidade" && (workout.title.contains("limiar", true) || workout.title.contains("tempo", true)) -> "LIMIAR"
    workout.type == "Qualidade" && (workout.title.contains("moderad", true) || workout.title.contains("steady", true)) -> "MODERADO"
    workout.title.contains("progress", true) -> "PROGRESSIVO"
    workout.type == "Qualidade" -> "QUALIDADE"
    else -> "AERÓBIO"
}

private fun calendarCategoryColor(category: String): Color = when (category) {
    "REGENERATIVO" -> Color(0xFF91B9EA)
    "AERÓBIO" -> Color(0xFF65CBA7)
    "PROGRESSIVO" -> Color(0xFFE5C16F)
    "MODERADO" -> Color(0xFFD9A66F)
    "QUALIDADE", "LIMIAR" -> Color(0xFFE89D66)
    "INTERVALADO" -> Color(0xFFE77D8B)
    "LONGÃO" -> Color(0xFF65B9D5)
    else -> Blue
}

private fun calendarCategoryShort(category: String): String = when (category) {
    "REGENERATIVO" -> "REG"
    "AERÓBIO" -> "AER"
    "PROGRESSIVO" -> "PROG"
    "MODERADO" -> "MOD"
    "FARTLEK" -> "FAR"
    "QUALIDADE" -> "QUAL"
    "LIMIAR" -> "LIM"
    "INTERVALADO" -> "INT"
    "LONGÃO" -> "LONG"
    else -> category.take(3)
}

@Composable private fun ChoiceScreen(title: String, options: List<String>, current: String, selected: (String) -> Unit) {
    Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
    Spacer(Modifier.height(8.dp))
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
    options.forEach { option ->
        val isSelected = option == current
        Card(
            Modifier
                .fillMaxWidth()
                .then(if (isSelected) Modifier.border(1.5.dp, Blue, RoundedCornerShape(10.dp)) else Modifier)
                .clickable { selected(option) },
            colors = CardDefaults.cardColors(containerColor = if (isSelected) Color(0xFF174968) else CardBlue),
            shape = RoundedCornerShape(10.dp)
        ) {
            Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(20.dp).border(2.dp, if (isSelected) Blue2 else TextMuted, RoundedCornerShape(50)),
                    contentAlignment = Alignment.Center
                ) {
                    if (isSelected) Box(Modifier.size(10.dp).clip(RoundedCornerShape(50)).background(Blue2))
                }
                Spacer(Modifier.width(10.dp))
                Text(option, fontSize = 14.sp, lineHeight = 18.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium)
            }
        }
    }
    }
}

@Composable private fun MainShell(state: CoachState) {
    // Android system Back uses the same navigation history as in-app navigation.
    // A restored deep screen has no in-memory history, so CoachState supplies a safe parent fallback.
    BackHandler(enabled = state.canNavigateBack()) {
        state.navigateBack()
    }
    Scaffold(
        containerColor = Navy,
        bottomBar = { BottomNav(state) }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (state.selectedScreen) {
                Screen.DASHBOARD -> Dashboard(state)
                Screen.CALENDAR -> CalendarScreen(state)
                Screen.WORKOUT -> WorkoutDetail(state)
                Screen.STRUCTURE -> StructureScreen(state)
                Screen.PLAN -> PlanScreen(state)
                Screen.EVOLUTION -> EvolutionScreen(state)
                Screen.FEEDBACK -> FeedbackScreen(state)
                Screen.HISTORY -> HistoryScreen(state)
                Screen.PROFILE -> ProfileScreen(state)
                Screen.AVAILABILITY -> AvailabilityScreen(state)
                Screen.EXPORT -> ExportScreen(state)
                Screen.PACE_ZONES -> PaceZonesScreen(state)
                Screen.COOPER_TEST -> CooperTestScreen(state)
                Screen.TRAINING_LIBRARY -> TrainingLibraryScreen(state)
                Screen.RACES -> RaceManagementScreen(state)
                Screen.RACE_STRATEGY -> RaceStrategyScreen(state)
                Screen.BACKUP -> BackupScreen(state)
            }
        }
    }
}

@Composable private fun Header(title: String, back: Boolean = false, onBack: () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (back) {
            Surface(
                modifier = Modifier.size(42.dp).clickable(onClick = onBack),
                shape = RoundedCornerShape(15.dp),
                color = Navy2
            ) { Box(contentAlignment = Alignment.Center) { Text("‹", fontSize = 30.sp, color = Blue2) } }
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("AI RUNNING COACH", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Text(title, fontSize = 23.sp, fontWeight = FontWeight.Bold, color = TextWhite)
        }
    }
}

@Composable private fun Dashboard(state: CoachState) {
    val activePlan = state.activePlanWorkouts()
    val earliestWeek = activePlan.minOfOrNull { it.week } ?: 1
    val currentPlanWeek = state.currentPlanWeekNumber()
    // Always label the current cycle week, even when it currently has no run session.
    // Never fall back to an older week while keeping the current week's distance/count.
    val dashboardWeek = currentPlanWeek ?: earliestWeek
    val firstWeekSessions = activePlan.filter { it.week == dashboardWeek }
    val firstWeekRaces = state.eventsForPlanWeek(dashboardWeek).filter { it.status != "CANCELLED" }
    val firstWeekKm = firstWeekSessions.sumOf { it.distanceKm } + firstWeekRaces.sumOf { it.distanceKm }
    val firstWeekRemainingKm = firstWeekSessions.filter { !it.done }.sumOf { it.distanceKm } + firstWeekRaces.filter { it.status == "PLANNED" }.sumOf { it.distanceKm }
    val firstWeekTargetKm = firstWeekSessions.mapNotNull { it.weeklyTargetKm }.maxOrNull() ?: state.effectiveDisplayWeeklyKm()
    val nextWorkout = activePlan.firstOrNull { !it.done }
    val actualDistance = state.feedbackRecords.mapNotNull { it.actualDistanceKm }.sum()
    val weeklyReference = state.effectiveDisplayWeeklyKm()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 22.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(start = 22.dp, end = 18.dp, top = 18.dp, bottom = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("TRAINING HUB", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.8.sp)
                Text("Olá, ${state.name}!", color = TextWhite, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text("Seu treinamento, em um só lugar.", color = TextMuted, fontSize = 13.sp)
            }
            Surface(shape = RoundedCornerShape(18.dp), color = CardBlue, modifier = Modifier.size(48.dp)) {
                Box(contentAlignment = Alignment.Center) { Text(state.name.take(1).uppercase(), color = Blue2, fontWeight = FontWeight.Bold, fontSize = 20.sp) }
            }
        }

        Surface(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            shape = RoundedCornerShape(28.dp),
            color = Color.Transparent
        ) {
            Column(
                Modifier.background(Brush.linearGradient(listOf(Color(0xFF263D62), Color(0xFF172B46), Color(0xFF183B50)))).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("SEU CICLO ATUAL", color = Color(0xFFCEDAFF), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                        Text("Plano de ${state.planWeeks} semanas", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    }
                    Surface(shape = RoundedCornerShape(50), color = Color(0x333FCEB7)) {
                        Text(if (state.workouts.isNotEmpty()) "ATIVO" else "PENDENTE", color = Color(0xFF9AF0D5), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp))
                    }
                }
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text(formatKmUi(firstWeekKm), fontSize = 38.sp, fontWeight = FontWeight.Black, color = Color.White)
                        Text("km agendados na semana $dashboardWeek", fontSize = 12.sp, color = Color(0xFFD0D9EA))
                Text("${formatKmUi(firstWeekRemainingKm)} km restantes • meta ${firstWeekTargetKm?.let(::formatKmUi) ?: "—"} km", fontSize = 10.sp, color = Color(0xFFB9C8DE))
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("${firstWeekSessions.size + firstWeekRaces.size}", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("compromissos", fontSize = 12.sp, color = Color(0xFFD0D9EA))
                    }
                }
                ProgressTrack(progress = if (firstWeekTargetKm != null && firstWeekTargetKm > 0.0) (firstWeekKm / firstWeekTargetKm).toFloat().coerceIn(0f, 1f) else 0f, color = Color(0xFF9BE2D0), trackColor = Color(0x55FFFFFF))
                Text(
                    text = if (state.weeklyVolumeText.isNotBlank()) "Base informada: ${state.weeklyVolumeText} km/semana" else "Base automática do objetivo: ${formatKmUi(state.effectiveDisplayWeeklyKm() ?: 0.0)} km/semana",
                    color = Color(0xFFD0D9EA), fontSize = 11.sp
                )
            }
        }

        SectionHeading("Indicadores do atleta", "Dados do perfil")
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricPod("Volume de referência", state.effectiveDisplayWeeklyKm()?.let { "${formatKmUi(it)} km" } ?: "—", "↗", Blue2, Modifier.weight(1f), if (state.weeklyVolumeText.isBlank()) "Base padrão do objetivo" else "Média das últimas 4 semanas")
            MetricPod("Maior sessão", state.effectiveDisplayLongestKm()?.let { "${formatKmUi(it)} km" } ?: "—", "◷", Color(0xFFFFD18A), Modifier.weight(1f), if (state.longestRecent.isBlank()) "Capacidade anterior do objetivo" else "Distância contínua recente")
        }
        val readiness = state.readinessSnapshot()
        val recoveryAccent = when (readiness.recoveryStatus) {
            "POOR" -> Color(0xFFFF9292)
            "MODERATE" -> Yellow
            "GOOD" -> Color(0xFF91D9C5)
            else -> TextMuted
        }
        val safetyAccent = when (readiness.safetyStatus) {
            "RED" -> Color(0xFFFF9292)
            "YELLOW" -> Yellow
            "GREEN" -> Color(0xFF91D9C5)
            else -> TextMuted
        }
        val readinessSubtitle = if (readiness.sampleCount == 0) "Aguardando feedback recente" else "${readiness.sampleCount} feedback(s) • últimos 14 dias"
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricPod("Recuperação", recoveryLabel(readiness.recoveryStatus), "✦", recoveryAccent, Modifier.weight(1f), if (readiness.sampleCount == 0) readinessSubtitle else "$readinessSubtitle • RPE e sensação")
            MetricPod("Segurança", safetyLabel(readiness.safetyStatus), "♥", safetyAccent, Modifier.weight(1f), if (readiness.sampleCount == 0) readinessSubtitle else "$readinessSubtitle • dor e fadiga")
        }

        val cooperStatus = state.cooperReviewStatus()
        val currentZones = state.currentPaceZones()
        CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), containerColor = Color(0xFF1A2D43)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("ZONAS DE RITMO", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                        Text(if (currentZones != null) "Perfil calibrado" else "Ritmo ainda não calibrado", color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                    StatusPill(if (cooperStatus.isDue) "REVISÃO" else if (currentZones != null) "Z1–Z5" else "PENDENTE", if (cooperStatus.isDue) Yellow else Green)
                }
                if (currentZones != null) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        currentZones.all().forEach { zone ->
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(zone.id, color = Blue2, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text(zone.range.label().removeSuffix(" min/km"), color = TextWhite, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Text(cooperStatus.message, color = TextMuted, fontSize = 10.sp)
                } else {
                    Text("Registre Cooper de 12 minutos ou teste de 3 km para estimar VO₂máx e calibrar Z1–Z5.", color = TextMuted, fontSize = 11.sp)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SecondaryButton("Ver zonas", modifier = Modifier.weight(1f), horizontalPadding = 0) { state.navigateTo(Screen.PACE_ZONES) }
                    PrimaryButton("${if (cooperStatus.isDue) "Reavaliar teste" else "Novo teste"}", modifier = Modifier.weight(1f), horizontalPadding = 0) { state.openFieldTestEditor() }
                }
            }
        }

        val upcomingRace = state.primaryUpcomingRace()
        if (upcomingRace != null) {
            SectionHeading("Próxima competição", "Gerenciar") { state.navigateTo(Screen.RACES) }
            CardSurface(Modifier.padding(horizontal = 16.dp).clickable { state.openRaceStrategy(upcomingRace) }, containerColor = Color(0xFF292747)) {
                Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("🏁", fontSize = 29.sp)
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(upcomingRace.name, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("${formatKmUi(upcomingRace.distanceKm)} km • ${RaceEventEngine.formatBrazilianDate(upcomingRace.eventDateIso)} • Prioridade ${upcomingRace.priority}", color = Color(0xFFD2BFFF), fontSize = 10.sp)
                        val raceDate = upcomingRace.dateOrNull()
                        if (raceDate != null) Text("${java.time.temporal.ChronoUnit.DAYS.between(LocalDate.now(), raceDate).coerceAtLeast(0)} dias até a prova", color = TextMuted, fontSize = 10.sp)
                    }
                    Text("›", color = Blue2, fontSize = 25.sp)
                }
            }
        }

        SectionHeading("Distribuição semanal", "Planejado")
        CardSurface(Modifier.padding(horizontal = 16.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (dashboardWeek == currentPlanWeek) "Semana $dashboardWeek · em andamento" else "Semana $dashboardWeek do plano",
                            fontSize = 17.sp, fontWeight = FontWeight.Bold
                        )
                if (firstWeekRaces.isNotEmpty()) Text("${firstWeekSessions.size} treinos + ${firstWeekRaces.size} prova(s)", color = Color(0xFFD2BFFF), fontSize = 10.sp)
                        Text("Distância prevista por dia", color = TextMuted, fontSize = 11.sp)
                    }
                    Text("${formatKmUi(firstWeekKm)} km", color = Blue2, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                SevenDayBreakdown(firstWeekSessions, firstWeekRaces)
                Text("Barras roxas indicam competição. O gráfico mostra compromissos planejados, não atividades realizadas.", color = TextMuted, fontSize = 10.sp)
            }
        }

        SectionHeading("Próximo treino", "Ver calendário") {
            state.navigateTo(Screen.CALENDAR)
        }
        if (nextWorkout != null) {
            NextWorkoutCard(nextWorkout) { state.selectWorkout(nextWorkout) }
        } else {
            EmptyStateCard("Nenhum treino pendente", "Gere um novo ciclo para visualizar suas próximas sessões.", "Criar ou revisar plano") {
                state.onboardingStep = 1
                state.persist()
            }
        }

        state.motorDecision?.let { decision ->
            SectionHeading("Leitura do treinador")
            CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF182B3D)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text(
                        if (state.needsEngineRefresh) "Revisão da prescrição pendente" else stimulusLabel(decision.stimulus),
                        color = Blue2, fontWeight = FontWeight.Bold, fontSize = 16.sp
                    )
                    Text(
                        if (state.needsEngineRefresh) {
                            "O perfil fisiológico ou a meta mudou. Recalcule para atualizar as próximas sessões; treinos concluídos e histórico ficam preservados."
                        } else decision.rationale,
                        color = TextMuted, fontSize = 12.sp, lineHeight = 18.sp
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (state.needsEngineRefresh) StatusPill("Aguardando atualização", Yellow)
                        else {
                            StatusPill("Confiança ${((decision.confidence * 100).toInt()).coerceIn(0, 100)}%", Color(0xFFB7C8FF))
                            StatusPill(safetyLabel(decision.safety), if (decision.safety == "RED") Color(0xFFFF9292) else Color(0xFF9BE2D0))
                        }
                    }
                }
            }
        }
        if (state.needsEngineRefresh) {
            val currentGoalAllowed = state.goal in TrainingGoalCatalog.labelsForLevel(state.level)
            if (!currentGoalAllowed) {
                NoteBlock("O nível fisiológico foi atualizado. Escolha uma meta liberada para essa faixa antes de recalcular; o histórico e os treinos concluídos continuam preservados.")
                PrimaryButton("Revisar perfil e meta") {
                    state.onboardingStep = if (state.physiologicalLevelDisplay() == "Aguardando teste") 1 else 2
                    state.persist()
                }
            } else {
                NoteBlock("Há dados novos desde a última prescrição. Recalcular atualiza as zonas e somente as sessões futuras, preservando histórico, treinos concluídos e ciclo.")
                PrimaryButton("Recalcular plano") { state.createPlan() }
            }
        }
        if (state.needsPacePlanRefresh) {
            NoteBlock("Há evidência suficiente para revisar zonas calibráveis por sessões regenerativas (Z1) ou testes Cooper independentes (Z3). O comportamento por bloco em Z1–Z5 é acompanhado separadamente e não altera os limites automaticamente. Recalcular aplica apenas calibrações validadas às sessões futuras; o histórico permanece preservado.")
            PrimaryButton("Aplicar calibração e recalcular próximas sessões") {
                val updated = state.recalibratePlan()
                if (!updated && state.motorError.isBlank()) state.motorError = "Não foi possível aplicar a calibração. Confira o perfil e o histórico recente."
            }
            if (state.motorError.isNotBlank()) NoteBlock(state.motorError)
        }
        if (actualDistance > 0.0) {
            CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("Distância registrada", color = TextMuted, fontSize = 11.sp)
                        Text("${formatKmUi(actualDistance)} km", color = TextWhite, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("${state.completedWorkouts().size} concluídos", color = Green, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
    }
}

@Composable private fun MetricPod(label: String, value: String, icon: String, accent: Color, modifier: Modifier = Modifier, subtitle: String = "") {
    // Metric cards use the same vertical hierarchy so labels never compete with icons
    // for horizontal space on narrow Android screens.
    CardSurface(modifier.padding(vertical = 5.dp), containerColor = CardBlue) {
        Column(
            Modifier.fillMaxWidth().height(124.dp).padding(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(icon, color = accent, fontSize = 17.sp, lineHeight = 20.sp)
            Text(
                label, color = TextMuted, fontSize = 10.sp, lineHeight = 13.sp,
                minLines = 2, softWrap = true
            )
            Text(
                value, color = accent, fontSize = 17.sp, lineHeight = 21.sp,
                fontWeight = FontWeight.Bold, softWrap = true
            )
            Text(
                subtitle.ifBlank { " " }, color = TextMuted, fontSize = 9.sp, lineHeight = 12.sp,
                minLines = 1, maxLines = 1, softWrap = false
            )
        }
    }
}

@Composable private fun CardBlock(title: String, main: String, note: String) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, color = Blue2, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(main, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = TextWhite)
            Text(note, color = TextMuted, fontSize = 12.sp, lineHeight = 17.sp)
        }
    }
}

@Composable private fun WorkoutCard(
    w: Workout,
    realizedDateLabel: String? = null,
    realizedTimeLabel: String? = null,
    scheduledDateIsoLabel: String? = null,
    onClick: () -> Unit
) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp).clickable(onClick = onClick)) {
        Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(11.dp)) {
            SessionGlyph(w, 42)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(
                    realizedDateLabel?.let { "Realizado em $it${realizedTimeLabel?.let { time -> " • $time" }.orEmpty()}" }
                        ?: "${w.date} • ~${formatKmUi(w.distanceKm)} km estimados",
                    color = if (realizedDateLabel != null) Green else TextMuted, fontSize = 10.sp, fontWeight = FontWeight.SemiBold
                )
                if (realizedDateLabel != null && !scheduledDateIsoLabel.isNullOrBlank()) {
                    val scheduled = runCatching { LocalDate.parse(scheduledDateIsoLabel).format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) }.getOrNull()
                    if (scheduled != null && scheduled != realizedDateLabel) Text("Planejado para $scheduled", color = TextMuted, fontSize = 9.sp)
                }
                Text(w.title, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(workoutTypeLabel(w.type), color = Blue2, fontSize = 10.sp)
            }
            Text(if (w.done) "✓" else "›", color = if (w.done) Green else TextMuted, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable private fun CalendarScreen(state: CoachState) {
    var displayedMonth by remember { mutableStateOf(YearMonth.now()) }
    var selectedDate by remember { mutableStateOf(LocalDate.now()) }
    var viewMode by remember { mutableStateOf("MONTH") }
    val calendarWorkouts = state.workouts.map { stored ->
        val selected = if (stored.selectedOption == "ALTERNATIVE") WorkoutAlternativeEngine.createAlternative(stored, state.runWalkAllowedForCurrentProfile(), state.qualityReplacementCanPreserveStimulus()) else stored
        val scheduledIso = stored.scheduledDateIso.ifBlank { stored.originalScheduledDateIso }
        val actualDate = if (stored.done) state.feedbackForSession(stored.sessionId)?.let(state::feedbackActivityDate) else null
        val calendarDate = WorkoutCalendarDateResolver.resolve(scheduledIso, actualDate, stored.done)
        if (calendarDate.bucketDate != null) selected.copy(
            date = calendarDate.displayLabel,
            scheduledDateIso = calendarDate.bucketDate.toString(),
            originalScheduledDateIso = stored.originalScheduledDateIso.ifBlank { scheduledIso }
        ) else selected
    }
    val workoutsByDate = calendarWorkouts.filter { it.scheduledDateIso.isNotBlank() }.groupBy { it.scheduledDateIso }
    val eventsByDate = state.raceEvents.filter { it.status != "CANCELLED" }.groupBy { it.eventDateIso }
    val monthStart = displayedMonth.atDay(1).with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    val monthDays = (0 until 42).map { monthStart.plusDays(it.toLong()) }
    val nextRace = state.primaryUpcomingRace()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Calendário")
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20334D)) {
            Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("AGENDA ESPORTIVA", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
                Text("${state.workouts.size} treinos • ${state.raceEvents.count { it.status != "CANCELLED" }} provas", color = TextWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(nextRace?.let { "Próxima prova: ${it.name} • ${RaceEventEngine.formatBrazilianDate(it.eventDateIso)}" } ?: "Cadastre suas competições para o treinador organizar a preparação por data.", color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                PrimaryButton("Gerenciar competições", modifier = Modifier.fillMaxWidth()) { state.navigateTo(Screen.RACES) }
            }
        }

        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 13.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = viewMode == "MONTH", onClick = { viewMode = "MONTH" }, label = { Text("Mês") })
            FilterChip(selected = viewMode == "WEEK", onClick = { viewMode = "WEEK" }, label = { Text("Semana") })
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = {
                displayedMonth = displayedMonth.minusMonths(1)
                selectedDate = displayedMonth.atDay(1)
            }) { Text("‹", fontSize = 24.sp, color = Blue2) }
            Text(displayedMonth.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale("pt", "BR"))).replaceFirstChar { it.uppercase() }, color = TextWhite, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
            TextButton(onClick = {
                displayedMonth = displayedMonth.plusMonths(1)
                selectedDate = displayedMonth.atDay(1)
            }) { Text("›", fontSize = 24.sp, color = Blue2) }
        }

        if (viewMode == "WEEK") {
            val weekStart = selectedDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { selectedDate = selectedDate.minusWeeks(1); displayedMonth = YearMonth.from(selectedDate) }) { Text("‹ Semana anterior", color = Blue2, fontSize = 10.sp) }
                Spacer(Modifier.weight(1f))
                Text("${weekStart.format(DateTimeFormatter.ofPattern("dd/MM"))} – ${weekStart.plusDays(6).format(DateTimeFormatter.ofPattern("dd/MM"))}", color = TextMuted, fontSize = 10.sp)
                TextButton(onClick = { selectedDate = selectedDate.plusWeeks(1); displayedMonth = YearMonth.from(selectedDate) }) { Text("Próxima ›", color = Blue2, fontSize = 10.sp) }
            }
        }

        if (viewMode == "MONTH") {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                listOf("SEG", "TER", "QUA", "QUI", "SEX", "SÁB", "DOM").forEach { day ->
                    Text(day, modifier = Modifier.weight(1f), color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                }
            }
            monthDays.chunked(7).forEach { rowDays ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    rowDays.forEach { date ->
                        val dayWorkouts = workoutsByDate[date.toString()].orEmpty()
                        val dayEvents = eventsByDate[date.toString()].orEmpty()
                        val selected = date == selectedDate
                        val inMonth = date.month == displayedMonth.month
                        Card(
                            modifier = Modifier.weight(1f).height(62.dp).clickable { selectedDate = date; displayedMonth = YearMonth.from(date) },
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = when {
                                selected -> Color(0xFF304A73)
                                !inMonth -> Color(0xFF101B2A)
                                else -> Color(0xFF182A40)
                            })
                        ) {
                            Column(Modifier.fillMaxSize().padding(5.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceBetween) {
                                Text(date.dayOfMonth.toString(), color = if (inMonth) TextWhite else Color(0xFF607086), fontSize = 11.sp, fontWeight = if (selected) FontWeight.Black else FontWeight.Medium)
                                Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                    dayWorkouts.map { calendarCategory(it) }.distinct().take(4).forEach { category ->
                                        Box(Modifier.size(6.dp).clip(RoundedCornerShape(50)).background(calendarCategoryColor(category)))
                                    }
                                    if (dayEvents.isNotEmpty()) Box(Modifier.size(6.dp).clip(RoundedCornerShape(50)).background(Color(0xFFB79AF7)))
                                }
                                val dayLabels = dayWorkouts.map { calendarCategoryShort(calendarCategory(it)) }.distinct().take(2).joinToString("·")
                                Text(when { dayEvents.isNotEmpty() -> "PROVA"; dayLabels.isNotBlank() -> dayLabels; else -> "" }, color = if (dayEvents.isNotEmpty()) Color(0xFFD2BFFF) else TextMuted, fontSize = 7.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            }
                        }
                    }
                }
            }
        } else {
            val monday = selectedDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            (0..6).forEach { offset ->
                val date = monday.plusDays(offset.toLong())
                CalendarDayAgenda(
                    date = date,
                    workouts = workoutsByDate[date.toString()].orEmpty(),
                    events = eventsByDate[date.toString()].orEmpty(),
                    onWorkout = { state.selectWorkout(it) },
                    onRace = { state.openRaceStrategy(it) },
                    onSelectDate = { selectedDate = it; displayedMonth = YearMonth.from(it) }
                )
            }
        }

        SectionHeading("${selectedDate.format(DateTimeFormatter.ofPattern("EEEE, dd 'de' MMMM", Locale("pt", "BR"))).replaceFirstChar { it.uppercase() }}")
        val selectedEvents = eventsByDate[selectedDate.toString()].orEmpty()
        val selectedWorkouts = workoutsByDate[selectedDate.toString()].orEmpty()
        if (selectedEvents.isEmpty() && selectedWorkouts.isEmpty()) {
            CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), containerColor = Color(0xFF142338)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("DIA LIVRE", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Text("Nenhuma sessão programada para esta data.", color = TextWhite, fontSize = 12.sp)
                    if (!selectedDate.isBefore(LocalDate.now())) {
                        PrimaryButton("Consultar treinador para este dia") { state.requestRestDayRecommendation(selectedDate) }
                    } else {
                        Text("Datas passadas não recebem sessões adicionais.", color = TextMuted, fontSize = 10.sp)
                    }
                    state.restDayRecommendation?.takeIf { it.targetDate == selectedDate }?.let { suggestion ->
                        Divider(color = Color(0xFF31465F))
                        Text(suggestion.title, color = if (suggestion.canAddWorkout) Green else Blue2, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(suggestion.explanation, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                        if (suggestion.canAddWorkout) {
                            CardSurface(containerColor = Color(0xFF1B3047)) {
                                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("OPÇÃO 1 · MENOR CARGA", color = Green, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                        StatusPill("RECOMENDADA", Green)
                                    }
                                    Text(if (suggestion.estimatedDistanceKm > 0.0) "${suggestion.durationMin} min • ~${formatKmUi(suggestion.estimatedDistanceKm)} km • Z1 • RPE ${suggestion.rpeRange}" else "${suggestion.durationMin} min • distância não estimada • esforço muito leve", color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    Text(if (suggestion.runWalkPattern) "Corrida/caminhada para iniciante real ou retorno elegível. Prioriza movimento confortável e menor estresse." else "Corrida contínua leve, sem pausas de caminhada prescritas. Prioriza movimento confortável e menor estresse.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                                    PrimaryButton("Adicionar treino leve") { state.addRecommendedRestDayWorkout("EASY") }
                                }
                            }
                            CardSurface(containerColor = Color(0xFF1B3047)) {
                                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                    Text("OPÇÃO 2 · CARGA MODERADA", color = Blue2, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    if (suggestion.normalAvailable) {
                                        Text(if (suggestion.normalEstimatedDistanceKm > 0.0) "${suggestion.normalDurationMin} min • ~${formatKmUi(suggestion.normalEstimatedDistanceKm)} km • Z2 • RPE ${suggestion.normalRpeRange}" else "${suggestion.normalDurationMin} min • distância não estimada • Z2 confortável • RPE ${suggestion.normalRpeRange}", color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                        Text(
                                            if (suggestion.runWalkPattern) "Rodagem confortável em corrida/caminhada, conforme a estratégia atual, sem aceleração final."
                                            else "Rodagem contínua e confortável, sem intervalos ou aceleração final.",
                                            color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp
                                        )
                                        Text(suggestion.normalRiskText, color = Yellow, fontSize = 10.sp, lineHeight = 15.sp)
                                        SecondaryButton("Adicionar rodagem normal") { state.addRecommendedRestDayWorkout("NORMAL") }
                                    } else {
                                        Text("O histórico ainda não sustenta uma segunda opção com carga moderada.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                                    }
                                }
                            }
                            StatusPill("RISCO ${suggestion.riskLevel}", if (suggestion.riskLevel == "HIGH") Color(0xFFE58A8A) else if (suggestion.riskLevel == "MODERATE") Yellow else Green)
                            Text(suggestion.riskText, color = if (suggestion.riskLevel == "HIGH") Color(0xFFFFB0B0) else Yellow, fontSize = 10.sp, lineHeight = 15.sp)
                            Text("A decisão é do corredor. A inclusão não apaga, substitui nem transfere as sessões principais.", color = Blue2, fontSize = 10.sp, lineHeight = 15.sp)
                        } else {
                            Text("A programação principal foi mantida. Nenhuma sessão foi adicionada.", color = TextMuted, fontSize = 10.sp)
                        }
                    }
                    if (state.scheduleActionMessage.isNotBlank()) Text(state.scheduleActionMessage, color = Green, fontSize = 10.sp)
                }
            }
        }
        selectedEvents.forEach { event -> RaceAgendaRow(event) { state.openRaceStrategy(event) } }
        selectedWorkouts.forEach { workout -> SessionAgendaRow(workout) { state.selectWorkout(workout) } }
        SectionHeading("Legenda")
        Column(Modifier.fillMaxWidth().padding(horizontal = 17.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                LegendDot("Regenerativo", calendarCategoryColor("REGENERATIVO"))
                LegendDot("Aeróbio", calendarCategoryColor("AERÓBIO"))
                LegendDot("Moderado", calendarCategoryColor("MODERADO"))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                LegendDot("Progressivo", calendarCategoryColor("PROGRESSIVO"))
                LegendDot("Qualidade/limiar", calendarCategoryColor("QUALIDADE"))
                LegendDot("Intervalado", calendarCategoryColor("INTERVALADO"))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                LegendDot("Fartlek", calendarCategoryColor("FARTLEK"))
                LegendDot("Longão", calendarCategoryColor("LONGÃO"))
                LegendDot("Prova", Color(0xFFB79AF7))
                LegendDot("Descanso", TextMuted)
            }
        }
        if (state.needsEngineRefresh) {
            NoteBlock("Sua disponibilidade, feedback ou competições foram alterados. Recalcular redistribui apenas as sessões de hoje em diante, mantém o ciclo e as semanas já concluídas e respeita os ${state.frequency} dias selecionados no perfil.")
            PrimaryButton("Recalcular preparação") { state.createPlan() }
        }
    }
}

@Composable private fun CalendarDayAgenda(
    date: LocalDate,
    workouts: List<Workout>,
    events: List<RaceEvent>,
    onWorkout: (Workout) -> Unit,
    onRace: (RaceEvent) -> Unit,
    onSelectDate: (LocalDate) -> Unit
) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), containerColor = Color(0xFF142338)) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(date.format(DateTimeFormatter.ofPattern("EEEE, dd/MM", Locale("pt", "BR"))).replaceFirstChar { it.uppercase() }, modifier = Modifier.clickable { onSelectDate(date) }, color = Blue2, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            if (events.isEmpty() && workouts.isEmpty()) Text("Descanso / sem compromisso", color = TextMuted, fontSize = 10.sp)
            events.forEach { event -> RaceAgendaRow(event) { onRace(event) } }
            workouts.forEach { SessionAgendaRow(it) { onWorkout(it) } }
        }
    }
}

@Composable private fun LegendDot(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Box(Modifier.size(8.dp).clip(RoundedCornerShape(50)).background(color))
        Text(label, color = TextMuted, fontSize = 9.sp)
    }
}

@Composable private fun RaceAgendaRow(event: RaceEvent, onClick: () -> Unit = {}) {
    CardSurface(Modifier.clickable(onClick = onClick), containerColor = Color(0xFF2B2850)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("🏁", fontSize = 21.sp)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(event.name, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text("${formatKmUi(event.distanceKm)} km • ${event.priorityLabel()} • ${RaceEventEngine.formatBrazilianDate(event.eventDateIso)}", color = Color(0xFFD2BFFF), fontSize = 9.sp)
                if (event.targetTime.isNotBlank()) Text("Tempo-alvo: ${event.targetTime}", color = TextMuted, fontSize = 9.sp)
            }
            StatusPill(when (event.status) { "COMPLETED" -> "REALIZADA"; "CANCELLED" -> "CANCELADA"; else -> "PROVA" }, Color(0xFFB79AF7))
        }
    }
}

@Composable private fun RaceDayGuideCard(event: RaceEvent, intent: String) {
    val guide = RaceDayGuideEngine.build(event, intent)
    CardSurface(containerColor = Color(0xFF172B42)) {
        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("ORIENTAÇÃO PARA O DIA DA PROVA", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
            Text(guide.title, color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text(guide.targetStrategy, color = Green, fontSize = 11.sp, lineHeight = 15.sp)
            RaceGuideItem("Véspera", guide.preRace)
            RaceGuideItem("Aquecimento", guide.warmUp)
            RaceGuideItem("Largada", guide.start)
            RaceGuideItem("Durante a prova", guide.middle)
            RaceGuideItem("Trecho final", guide.finish)
            RaceGuideItem("Hidratação e energia", guide.fueling)
            RaceGuideItem("Pós-prova", guide.recovery)
        }
    }
}

@Composable private fun RaceGuideItem(title: String, body: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(title, color = Blue2, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        Text(body, color = TextMuted, fontSize = 10.sp, lineHeight = 14.sp)
    }
}

@Composable private fun RaceManagementScreen(state: CoachState) {
    val sortedEvents = state.raceEvents.sortedBy { it.eventDateIso }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Header("Competições", true) { state.navigateBack(Screen.CALENDAR) }
        SectionHeading(if (state.editingRaceId.isBlank()) "Cadastrar prova" else "Editar prova")
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF1B2D43)) {
            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = state.raceNameDraft, onValueChange = { state.raceNameDraft = it.take(80) },
                    label = { Text("Nome da prova") }, modifier = Modifier.fillMaxWidth(), singleLine = true
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Top) {
                    OutlinedTextField(
                        value = state.raceDistanceDraft, onValueChange = { state.raceDistanceDraft = SmartInputMask.distance(it) },
                        label = { Text("Distância (km)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f), singleLine = true
                    )
                    OutlinedTextField(
                        value = state.raceDateDraft, onValueChange = { state.raceDateDraft = SmartInputMask.date(it) },
                        label = { Text("Data da prova") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true
                    )
                }
                Text("PRIORIDADE", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.7.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf("A", "B", "C").forEach { priority ->
                        val label = when (priority) { "A" -> "Principal"; "B" -> "Preparatória"; else -> "Treino" }
                        val selected = state.racePriorityDraft == priority
                        Surface(
                            modifier = Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).clickable { state.racePriorityDraft = priority },
                            shape = RoundedCornerShape(12.dp), color = if (selected) Color(0xFF4A405A) else Color(0xFF142338),
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) Color(0xFF9A87B7) else Color(0xFF42516A))
                        ) {
                            Column(Modifier.padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(priority, color = if (selected) TextWhite else Blue2, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text(label, color = if (selected) TextWhite else TextMuted, fontSize = 8.sp, maxLines = 1)
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = state.raceTargetTimeDraft, onValueChange = { state.raceTargetTimeDraft = SmartInputMask.duration(it) },
                        label = { Text("Tempo-alvo (opcional)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true
                    )
                    OutlinedTextField(
                        value = state.raceLocationDraft, onValueChange = { state.raceLocationDraft = it.take(100) },
                        label = { Text("Local (opcional)") }, modifier = Modifier.weight(1f), singleLine = true
                    )
                }
                OutlinedTextField(
                    value = state.raceNotesDraft, onValueChange = { state.raceNotesDraft = it.take(300) },
                    label = { Text("Observações (opcional)") }, modifier = Modifier.fillMaxWidth(),
                    minLines = 2, maxLines = 3
                )
                if (state.raceFormError.isNotBlank()) Text(state.raceFormError, color = Color(0xFFFF9292), fontSize = 10.sp)
                PrimaryButton(if (state.editingRaceId.isBlank()) "Salvar prova" else "Salvar alterações", modifier = Modifier.fillMaxWidth()) {
                    if (state.saveRaceDraft()) state.navigateTo(Screen.RACES)
                }
                if (state.editingRaceId.isNotBlank()) SecondaryButton("Cancelar edição", modifier = Modifier.fillMaxWidth()) { state.resetRaceDraft() }
            }
        }

        SectionHeading("Provas cadastradas", sortedEvents.size.toString())
        if (sortedEvents.isEmpty()) {
            EmptyStateCard("Nenhuma prova cadastrada", "Cadastre uma competição para planejar a preparação e criar uma estratégia individual.", "Cadastrar prova") {
                state.raceNameDraft = "Minha prova"
            }
        }
        sortedEvents.forEach { event ->
            CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 3.dp), containerColor = Color(0xFF192B40)) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text(event.name, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                        StatusPill("${event.priority} · ${when (event.priority) { "A" -> "Principal"; "B" -> "Preparatória"; else -> "Treino" }}", if (event.priority == "A") Green else Blue2)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("${formatKmUi(event.distanceKm)} km", color = Blue2, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("•", color = TextMuted)
                        Text(RaceEventEngine.formatBrazilianDate(event.eventDateIso), color = TextMuted, fontSize = 11.sp)
                        Spacer(Modifier.weight(1f))
                        StatusPill(raceStatusLabel(event.status), if (event.status == "COMPLETED") Green else Blue2)
                    }
                    if (event.targetTime.isNotBlank() || event.location.isNotBlank()) {
                        Text(listOfNotNull(event.targetTime.takeIf { it.isNotBlank() }?.let { "Alvo $it" }, event.location.takeIf { it.isNotBlank() }).joinToString(" • "), color = TextMuted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        SecondaryButton("Editar", modifier = Modifier.weight(1f), horizontalPadding = 5) { state.beginRaceEdit(event) }
                        SecondaryButton("Excluir", modifier = Modifier.weight(1f), horizontalPadding = 5) { state.deleteRace(event.id) }
                    }
                }
            }
        }
    }
}

@Composable private fun RaceStrategyScreen(state: CoachState) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val event = state.selectedRace()
    if (event == null) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Header("Estratégia de prova", true) { state.navigateBack(Screen.RACES) }
            EmptyStateCard("Prova não encontrada", "A competição pode ter sido excluída. Volte à agenda e selecione outra prova.", "Voltar às competições") { state.navigateTo(Screen.RACES) }
        }
        return
    }
    val strategyZones = state.currentPaceZones()
    val strategyEvidence = remember(state.feedbackRecords, state.workouts) { state.racePaceEvidence() }
    // Rebuild when the plan, test-derived zones or activity/block evidence changes.
    // This prevents a strategy screen from retaining stale pace targets after a new session.
    val strategy = remember(
        event, state.goalIntent, state.raceEvents, state.feedbackRecords, state.cooperAssessments,
        state.fitnessTestMethod, state.workouts, strategyZones, strategyEvidence
    ) {
        RaceStrategyEngine.build(event, state.goalIntent, strategyZones, strategyEvidence)
    }
    val dayGuide = remember(event, state.goalIntent) { RaceDayGuideEngine.build(event, state.goalIntent) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 26.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Header("Estratégia da prova", true) { state.navigateBack(Screen.RACES) }
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF203852)) {
            Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(event.name, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
                    StatusPill("Prioridade ${event.priority}", if (event.priority == "A") Green else Blue2)
                }
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("${formatKmUi(event.distanceKm)} km", color = TextWhite, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text(RaceEventEngine.formatBrazilianDate(event.eventDateIso), color = TextMuted, fontSize = 11.sp, modifier = Modifier.padding(bottom = 4.dp))
                }
                if (event.targetTime.isNotBlank()) Text("Tempo-alvo cadastrado: ${event.targetTime}", color = Blue2, fontSize = 11.sp)
                StatusPill("Confiança: ${strategy.confidence}", if (strategy.confidence == "Boa base de evidências") Green else Yellow)
                Text("${strategy.evidenceCount} evidências válidas • ${strategy.evidenceSessionCount} sessões recentes", color = TextMuted, fontSize = 10.sp)
            }
        }
        SectionHeading("Estratégia de execução", "Início · Meio · Final")
        strategy.phases.forEach { phase ->
            CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 3.dp), containerColor = Color(0xFF1A2D43)) {
                Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(phase.title, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.weight(1f))
                        StatusPill(phase.zone, Blue2)
                    }
                    Text("${formatKmUi(phase.startKm)}–${formatKmUi(phase.endKm)} km • ${formatKmUi(phase.distanceKm)} km", color = Blue2, fontSize = 11.sp)
                    if (phase.fastestPaceSecondsPerKm != null && phase.slowestPaceSecondsPerKm != null) {
                        Text("${PaceRange.format(phase.fastestPaceSecondsPerKm)}–${PaceRange.format(phase.slowestPaceSecondsPerKm)} min/km", color = Green, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    } else {
                        Text("Ritmo ainda não disponível", color = Yellow, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Text(phase.rationale, color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                }
            }
        }
        SectionHeading("Exportar estratégia para Pace Coach")
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20344E)) {
            Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                val raceExportName = RaceStrategyWorkoutExporter.exportName(event)
                Text("${strategy.phases.size} etapas competitivas + aquecimento e desaquecimento", color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Text("Arquivo: $raceExportName.json", color = TextMuted, fontSize = 10.sp, lineHeight = 14.sp)
                Text("As etapas serão exportadas por distância, com ritmo somente quando houver uma faixa validada. Zonas sem ritmo disponível não receberão alvo inventado.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                PrimaryButton("Compartilhar estratégia JSON", enabled = strategy.phases.isNotEmpty()) {
                    runCatching {
                        val prescribed = RaceStrategyWorkoutExporter.build(event, strategy, strategyZones)
                        val json = PaceCoachExporter.workoutToJson(
                            prescribed, event.name, event.distanceKm, raceExportName
                        )
                        val jsonFile = PaceCoachJsonAttachment.create(context.cacheDir, raceExportName, json)
                        val contentUri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", jsonFile)
                        val sendIntent = Intent(Intent.ACTION_SEND).apply {
                            type = PaceCoachJsonAttachment.MIME_TYPE
                            putExtra(Intent.EXTRA_SUBJECT, "Estratégia de prova — ${event.name}")
                            putExtra(Intent.EXTRA_STREAM, contentUri)
                            clipData = ClipData.newUri(context.contentResolver, jsonFile.name, contentUri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(sendIntent, "Enviar estratégia compatível com o Pace Coach"))
                    }.onFailure { error ->
                        state.motorError = "Não foi possível exportar a estratégia: ${error.message ?: "erro desconhecido"}."
                        state.persist()
                    }
                }
            }
        }
        SectionHeading("Projeção de tempo")
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20344E)) {
            Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                if (strategy.estimatedTimeMinSeconds != null && strategy.estimatedTimeMaxSeconds != null) {
                    Text("${PaceRange.formatDuration(strategy.estimatedTimeMinSeconds)}–${PaceRange.formatDuration(strategy.estimatedTimeMaxSeconds)}", color = TextWhite, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Text("Faixa matemática estimada a partir dos ritmos das fases. Não é garantia de resultado.", color = TextMuted, fontSize = 10.sp)
                } else Text("Indisponível: faltam zonas ou ritmos recentes para uma projeção responsável.", color = Yellow, fontSize = 11.sp)
                Text(strategy.targetAssessment, color = Blue2, fontSize = 10.sp, lineHeight = 15.sp)
                Text(strategy.readinessNote, color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
            }
        }
        SectionHeading("Orientações específicas da distância")
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF172B42)) {
            Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(dayGuide.title, color = TextWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text("Prioridade ${event.priority} · ${strategy.priorityLabel}", color = Green, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                RaceGuideItem("Véspera", dayGuide.preRace)
                RaceGuideItem("Aquecimento", dayGuide.warmUp)
                RaceGuideItem("Hidratação e energia", dayGuide.fueling)
                RaceGuideItem("Pós-prova", dayGuide.recovery)
            }
        }
        SectionHeading("Como utilizar a estratégia")
        strategy.pacingNotes.forEach { note -> NoteBlock(note) }
        Text("A estratégia é recalculada com os treinos e testes recentes. Reabra esta tela depois de novas sessões para consultar a revisão mais atual.", color = TextMuted, fontSize = 10.sp, lineHeight = 14.sp, modifier = Modifier.padding(horizontal = 18.dp))
    }
}

@Composable private fun WorkoutDetail(state: CoachState) {
    val workout = state.selectedWorkout()
    var showReschedule by remember(workout?.sessionId) { mutableStateOf(false) }
    var showAlternativeDialog by remember(workout?.sessionId) { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Header("Sessão de treinamento", true) { state.navigateBack(Screen.CALENDAR) }
        if (workout == null) {
            EmptyStateCard("Nenhuma sessão selecionada", "Escolha um treino no calendário ou no plano.", "Abrir calendário") { state.navigateTo(Screen.CALENDAR) }
            return@Column
        }

        val baseWorkout = state.selectedWorkoutBase() ?: workout
        val isAlternativeSelected = baseWorkout.selectedOption == "ALTERNATIVE"
        // Uma única prescrição fica visível. A alternativa só aparece quando solicitada.
        SessionHero(workout, state.feedbackRecords)
        Row(
            Modifier.fillMaxWidth().padding(start = 18.dp, end = 16.dp, top = 2.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    if (isAlternativeSelected) "ALTERNATIVA ESCOLHIDA" else "PRESCRIÇÃO RECOMENDADA",
                    color = if (isAlternativeSelected) Color(0xFFE5C16F) else Green,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Text("Há outra opção compatível com esta sessão.", color = TextMuted, fontSize = 10.sp)
            }
            if (!baseWorkout.done && baseWorkout.type != "Competição") {
                TextButton(
                    onClick = { showAlternativeDialog = true },
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text("⇄ Trocar treino", color = Blue2, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        SectionHeading("Objetivo da sessão")
        CardSurface(Modifier.padding(horizontal = 16.dp)) {
            Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(workout.objective, color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Text(workout.rationale, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
            }
        }

        // Mostra todos os blocos na própria sessão: nenhum aquecimento, recuperação ou
        // desaquecimento fica escondido atrás de um limite visual de quatro itens.
        SectionHeading("Estrutura completa do treino")
        if (workout.segments.isNotEmpty()) {
            val segmentTotalKm = workout.segments.sumOf { (it.distanceKm ?: 0.0) * it.repeatCount }
            val distanceMatches = kotlin.math.abs(segmentTotalKm - workout.distanceKm) <= 0.11
            Text(
                "Soma dos blocos: ~${formatKmUi(segmentTotalKm)} km • Total da sessão: ${formatKmUi(workout.distanceKm)} km",
                color = if (distanceMatches) Green else Yellow,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 2.dp)
            )
        }
        workout.segments.forEachIndexed { index, segment -> SegmentRow(index + 1, segment) }

        if (workout.manuallyRescheduled) {
            Text(
                "Sessão movida da data original ${workout.originalScheduledDateIso.takeIf { it.isNotBlank() } ?: "não registrada"}. Dose e blocos preservados.",
                color = TextMuted, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 18.dp, vertical = 4.dp)
            )
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (!workout.done) {
                SecondaryButton("Reagendar", modifier = Modifier.weight(1f), horizontalPadding = 0) {
                    state.scheduleActionMessage = ""
                    showReschedule = true
                }
            }
            SecondaryButton("Feedback", modifier = Modifier.weight(1f), horizontalPadding = 0) {
                state.navigateTo(Screen.FEEDBACK)
            }
        }
        PrimaryButton("Exportar para Pace Coach", modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth()) {
            state.navigateTo(Screen.EXPORT)
        }
    }

    if (showAlternativeDialog && workout != null) {
        val base = state.selectedWorkoutBase() ?: workout
        val returningToPrimary = base.selectedOption == "ALTERNATIVE"
        val candidate = if (returningToPrimary) base.copy(selectedOption = "PRIMARY") else WorkoutAlternativeEngine.createAlternative(base, state.runWalkAllowedForCurrentProfile(), state.qualityReplacementCanPreserveStimulus())
        AlertDialog(
            onDismissRequest = { showAlternativeDialog = false },
            containerColor = CardBlue,
            title = { Text(if (returningToPrimary) "Voltar ao treino recomendado?" else "Outra opção para hoje", color = TextWhite, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text(if (returningToPrimary) "PRESCRIÇÃO PRINCIPAL" else "ALTERNATIVA", color = if (returningToPrimary) Green else Color(0xFFE5C16F), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(candidate.title, color = TextWhite, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text("${formatKmUi(candidate.distanceKm)} km estimados • Tempo estimado: ~${candidate.durationMin} min", color = Blue2, fontSize = 12.sp)
                    candidate.primaryPaceRange()?.let { Text("Ritmo-alvo: $it min/km", color = Blue2, fontSize = 12.sp) }
                    Text(candidate.objective, color = TextWhite, fontSize = 12.sp)
                    Text(candidate.rationale, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                    Text("A escolha substitui a sessão atual. Não acrescenta treino nem volume à semana.", color = TextMuted, fontSize = 10.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    state.selectWorkoutOption(base.sessionId, if (returningToPrimary) "PRIMARY" else "ALTERNATIVE")
                    showAlternativeDialog = false
                }) { Text(if (returningToPrimary) "Voltar ao recomendado" else "Usar esta opção", color = Blue2, fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { showAlternativeDialog = false }) { Text("Manter atual", color = TextMuted) }
            }
        )
    }

    if (showReschedule && workout != null) {
        val candidates = state.availableRescheduleDates(workout)
        AlertDialog(
            onDismissRequest = { showReschedule = false },
            containerColor = CardBlue,
            title = { Text("Reagendar sessão", color = TextWhite) },
            text = {
                Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("Escolha um dia livre dentro da mesma semana. A sessão mantém distância, ritmo, blocos e identidade.", color = TextMuted, fontSize = 12.sp)
                    if (candidates.isEmpty()) Text("Não há outro dia seguro e livre nesta semana.", color = Yellow, fontSize = 12.sp)
                    candidates.forEach { date ->
                        OutlinedButton(onClick = {
                            if (state.rescheduleWorkout(workout, date)) showReschedule = false
                        }, modifier = Modifier.fillMaxWidth()) {
                            Text(date.format(DateTimeFormatter.ofPattern("EEEE, dd/MM", Locale("pt", "BR"))).replaceFirstChar { it.uppercase() }, color = Blue2)
                        }
                    }
                    if (state.scheduleActionMessage.isNotBlank()) Text(state.scheduleActionMessage, color = Yellow, fontSize = 11.sp)
                }
            },
            confirmButton = { TextButton(onClick = { showReschedule = false }) { Text("Fechar", color = Blue2) } }
        )
    }
}

@Composable private fun StructureScreen(state: CoachState) {
    val workout = state.selectedWorkout()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 22.dp)) {
        Header("Estrutura da sessão", true) { state.navigateBack(Screen.WORKOUT) }
        if (workout == null) {
            EmptyStateCard("Sessão não encontrada", "Selecione uma sessão para consultar os blocos.", "Voltar ao calendário") { state.navigateBack(Screen.CALENDAR) }
            return@Column
        }
        SessionHero(workout, state.feedbackRecords)
        SectionHeading("Blocos prescritos")
        if (workout.segments.isEmpty()) {
            NoteBlock("Esta sessão pertence a um plano antigo e não possui blocos detalhados. Gere um novo ciclo para receber a estrutura completa.")
        } else {
            workout.segments.forEachIndexed { index, segment -> SegmentRow(index + 1, segment) }
        }
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF1A2A3D)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("Orientação do treinador", color = Blue2, fontWeight = FontWeight.Bold)
                Text(workout.rationale, color = TextMuted, fontSize = 12.sp, lineHeight = 18.sp)
            }
        }
    }
}

@Composable private fun SessionHero(workout: Workout, feedbackRecords: List<FeedbackRecord> = emptyList()) {
    val feedback = feedbackRecords.lastOrNull { it.sessionId == workout.sessionId }
    val planned = remember(workout.sessionId, workout.segments, workout.distanceKm, workout.durationMin) {
        UnifiedPrescriptionCalculator.planned(workout.segments, workout.distanceKm, workout.durationMin)
    }
    val actual = remember(feedback?.sessionId, feedback?.actualDistanceKm, feedback?.actualDuration) {
        UnifiedPrescriptionCalculator.realized(feedback?.actualDistanceKm, feedback?.actualDuration)
    }
    val useActual = workout.done
    val distance = if (useActual) actual.distanceKm else planned.distanceKm
    val duration = if (useActual) actual.durationSeconds else planned.durationSeconds
    val pace = if (useActual) actual.paceSecondsPerKm else planned.paceSecondsPerKm
    val distanceLabel = if (distance == null) "—" else (if (!useActual && planned.distanceEstimated) "~" else "") + formatKmUi(distance)
    val durationLabel = duration?.let { (if (!useActual && planned.durationEstimated) "~" else "") + PaceRange.formatDuration(it) } ?: "—"
    val paceLabel = pace?.let { (if (!useActual && planned.paceEstimated) "~" else "") + PaceRange.format(it) } ?: "—"
    val durationUnit = if ((duration ?: 0) >= 3_600) "h:min:s" else "min:s"
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF243B5D), Color(0xFF17344B))))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatusPill(workoutTypeLabel(workout.type).uppercase(), Color(0xFFBFD0FF))
            Spacer(Modifier.weight(1f))
            Text(if (workout.done) "CONCLUÍDO" else "PROGRAMADO", color = if (workout.done) Color(0xFF9BE2D0) else Color(0xFFCEDAFF), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
        }
        Text(workout.title, color = Color.White, fontSize = 22.sp, lineHeight = 26.sp, fontWeight = FontWeight.Bold)
        Text("${workout.date}  ·  Semana ${workout.week}  ·  ${phaseLabel(workout.phase)}", color = Color(0xFFD0D9EA), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            SessionMetric(if (useActual) "DISTÂNCIA REAL" else "DISTÂNCIA PREVISTA", distanceLabel, "km", Modifier.weight(1f), compact = true)
            SessionMetric(if (useActual) "TEMPO REAL" else "TEMPO PREVISTO", durationLabel, durationUnit, Modifier.weight(1f), compact = true)
            SessionMetric(if (useActual) "RITMO REAL" else "RITMO PREVISTO", paceLabel, "min/km", Modifier.weight(1f), compact = true)
        }
    }
}

@Composable private fun SessionMetric(label: String, value: String, unit: String, modifier: Modifier = Modifier, compact: Boolean = false) {
    Column(
        modifier.clip(RoundedCornerShape(13.dp)).background(Color.White.copy(alpha = 0.055f)).padding(horizontal = 9.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(label, color = Color(0xFFB9C8DE), fontSize = 7.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.25.sp, maxLines = 2, minLines = 2, lineHeight = 9.sp)
        Text(value, color = Color.White, fontSize = if (compact) 13.sp else 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false, overflow = TextOverflow.Clip)
        Text(unit, color = Color(0xFFD0D9EA), fontSize = 8.sp, maxLines = 1)
    }
}

@Composable private fun SegmentRow(index: Int, segment: WorkoutSegment) {
    val dose = when {
        segment.targetMode == "TIME" && segment.repeatCount > 1 && segment.durationMin != null -> "${segment.repeatCount} × ${segment.durationMin} min"
        segment.targetMode == "TIME" && segment.durationMin != null -> "${segment.durationMin} min"
        segment.repeatCount > 1 && segment.distanceKm != null -> "${segment.repeatCount} × ${formatKmUi(segment.distanceKm)} km"
        segment.distanceKm != null -> "${formatKmUi(segment.distanceKm)} km"
        segment.durationMin != null -> "${segment.durationMin} min"
        else -> "Conforme orientação"
    }
    val estimatedDistanceText = if (segment.targetMode == "TIME" && segment.distanceKm != null) {
        val total = segment.distanceKm * segment.repeatCount
        if (segment.repeatCount > 1) "Distância estimada: ~${formatKmUi(total)} km no total (${formatKmUi(segment.distanceKm)} km por repetição)"
        else "Distância estimada: ~${formatKmUi(total)} km"
    } else null
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
            Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFF253A56), modifier = Modifier.size(34.dp)) {
                Box(contentAlignment = Alignment.Center) { Text(index.toString(), color = Blue2, fontWeight = FontWeight.Bold) }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(WorkoutTitleSanitizer.clean(segment.name), color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(dose, color = Blue2, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                estimatedDistanceText?.let { Text(it, color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Medium) }
                Text(segment.instruction, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                if (segment.targetPaceMinValue != null && segment.targetPaceMaxValue != null) {
                    Text("${segment.paceZone?.let { "$it • " } ?: ""}Ritmo-alvo: ${PaceRange(segment.targetPaceMinValue, segment.targetPaceMaxValue).label()}", color = Blue2, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    if (segment.zoneIntensityMinPercent != null && segment.zoneIntensityMaxPercent != null) {
                        Text("Faixa ativa: ${segment.zoneIntensityMinPercent}–${segment.zoneIntensityMaxPercent}% da zona", color = TextMuted, fontSize = 10.sp)
                    }
                    segment.goalPaceReferenceSecondsPerKm?.let { pace ->
                        Text("Referência da meta: ${PaceRange.format(pace)} min/km • não substitui o ritmo da zona", color = Green, fontSize = 10.sp, fontWeight = FontWeight.Medium)
                    }
                } else {
                    Text("Orientação por esforço percebido (RPE)", color = TextMuted, fontSize = 10.sp)
                }
                Text("RPE ${segment.rpeRange}: referência complementar de esforço", color = TextMuted, fontSize = 10.sp)
            }
        }
    }
}

@Composable private fun PlanScreen(state: CoachState) {
    val groups = state.activePlanWorkouts().groupBy { it.week }.toSortedMap()
    val currentPlanWeek = state.currentPlanWeekNumber()
    val initialExpandedWeek = currentPlanWeek?.takeIf { it in groups } ?: groups.keys.firstOrNull() ?: 1
    var expandedWeek by remember(groups.keys.toList(), currentPlanWeek) { mutableStateOf(initialExpandedWeek) }
    val distributionSessions = groups[expandedWeek].orEmpty()
    val distributionReport = remember(distributionSessions) {
        IntensityDistributionEngine.summarize(distributionSessions.map { it.asPrescribedForDistribution() })
    }
    val distributionPhase = distributionSessions.firstOrNull()?.phase ?: TrainingPeriodizationEngine.BASE
    val distributionTarget = remember(state.goal, state.level, distributionPhase) {
        IntensityDistributionEngine.target(TrainingGoalCatalog.categoryForLabel(state.goal), state.level, distributionPhase)
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 26.dp)) {
        Header("Plano de treinamento")
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(Color(0xFF293F63), Color(0xFF182C45)))).padding(horizontal = 16.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("OBJETIVO PRINCIPAL", color = Color(0xFFCEDAFF), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
            Text(state.primaryUpcomingRace()?.let { "${it.name} • ${formatKmUi(it.distanceKm)} km" } ?: goalLabel(state), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
            Text("${state.physiologicalLevelDisplay()}  •  ${state.frequency} dias por semana", color = Color(0xFFD0D9EA), fontSize = 12.sp)
            Text("PRIORIDADE DO PLANO", color = Color(0xFFCEDAFF), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
            Text(TrainingGoalIntent.label(state.goalIntent), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            state.motorState?.takeIf { it.goalPreparationStage == "PREPARATORY_BASE" }?.let { readiness ->
                Text(
                    "BASE PREPARATÓRIA • fase específica ainda não liberada. Referências de entrada: " +
                        "${formatKmUi(readiness.goalSpecificWeeklyMinKm ?: 0.0)} km/semana, " +
                        "longão ${formatKmUi(readiness.goalSpecificLongestMinKm ?: 0.0)} km e " +
                        "${readiness.goalSpecificFrequencyMin} dias/semana. O volume informado não será elevado à força; conclua o bloco e reavalie a carga real.",
                    color = Color(0xFFF1C986), fontSize = 10.sp, lineHeight = 15.sp
                )
            }
            if (state.goalIntent == TrainingGoalIntent.PERSONAL_BEST) {
                Text("Recorde atual: ${state.personalBestTimeText.ifBlank { "Não informado" }}", color = Color(0xFFD0D9EA), fontSize = 11.sp)
            }
            if (state.goalIntent == TrainingGoalIntent.TARGET_TIME) {
                Text("Tempo-alvo: ${state.goalTargetTimeText.ifBlank { "Não informado" }}", color = Color(0xFFD0D9EA), fontSize = 11.sp)
            }
            HorizontalDivider(color = Color(0x446F8DB8))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                PlanStat("Duração", "${state.planWeeks} sem.")
                PlanStat("Base semanal", "${state.effectiveDisplayWeeklyKm()?.let(::formatKmUi) ?: "—"} km")
                PlanStat("Maior sessão", "${state.effectiveDisplayLongestKm()?.let(::formatKmUi) ?: "—"} km")
            }
        }
        if (state.needsEngineRefresh) {
            NoteBlock("Este plano foi gerado pela versão anterior do treinador. Atualize a meta, se necessário, e recalcule para aplicar a avaliação fisiológica e a carga atuais. Sessões concluídas e histórico permanecem preservados.")
            val goalAllowed = state.goal in TrainingGoalCatalog.labelsForLevel(state.level)
            PrimaryButton(if (goalAllowed) "Recalcular plano" else "Revisar meta") {
                if (goalAllowed) state.createPlan() else {
                    state.onboardingStep = if (state.physiologicalLevelDisplay() == "Aguardando teste") 1 else 2
                    state.persist()
                }
            }
        }
        SectionHeading("Evolução do volume", "Quilômetros previstos por semana")
        if (groups.isNotEmpty()) {
            val weeklyVolumes = groups.map { (week, sessions) ->
                val raceKm = state.eventsForPlanWeek(week).filter { it.status != "CANCELLED" }.sumOf { it.distanceKm }
                week to (sessions.sumOf { it.distanceKm } + raceKm)
            }
            val maxPlannedKm = weeklyVolumes.maxOfOrNull { it.second }?.coerceAtLeast(0.1) ?: 0.1
            CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 2.dp), containerColor = Color(0xFF20344E)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Progressão planejada", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("Inclui provas cadastradas; não representa distância já realizada.", color = TextMuted, fontSize = 9.sp)
                        }
                        Text("${weeklyVolumes.size} sem.", color = Blue2, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Row(
                        Modifier.fillMaxWidth()
                            .then(if (weeklyVolumes.size > 8) Modifier.horizontalScroll(rememberScrollState()) else Modifier)
                            .height(112.dp),
                        horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.Bottom
                    ) {
                        weeklyVolumes.forEach { (week, km) ->
                            Column(
                                (if (weeklyVolumes.size > 8) Modifier.width(38.dp) else Modifier.weight(1f)).fillMaxHeight(),
                                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom
                            ) {
                                Text(formatKmUi(km), color = TextMuted, fontSize = 8.sp, maxLines = 1, softWrap = false)
                                Spacer(Modifier.height(3.dp))
                                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.BottomCenter) {
                                    Box(
                                        Modifier.fillMaxWidth(0.68f)
                                            .height((72.0 * (km / maxPlannedKm)).coerceIn(4.0, 72.0).dp)
                                            .clip(RoundedCornerShape(topStart = 5.dp, topEnd = 5.dp))
                                            .background(if (week == currentPlanWeek) Green else Blue)
                                    )
                                }
                                Spacer(Modifier.height(4.dp))
                                Text("S$week", color = if (week == currentPlanWeek) Green else TextMuted, fontSize = 8.sp, fontWeight = if (week == currentPlanWeek) FontWeight.Bold else FontWeight.Normal)
                            }
                        }
                    }
                }
            }
        }
        SectionHeading("Periodização", "${groups.size} semanas no ciclo")
        if (state.motorDecision != null && !state.needsEngineRefresh) {
            CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 2.dp), containerColor = Color(0xFF192B40)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("ESTRATÉGIA", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                    Text(stimulusLabel(state.motorDecision!!.stimulus), color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text("Distribuição planejada ponderada pelo tempo dos segmentos da semana ${expandedWeek}.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                    if (distributionReport.totalEstimatedMinutes > 0) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            DistributionMetric("Baixa", distributionReport.lowIntensityPercent, "${distributionTarget.lowMinPercent}–${distributionTarget.lowMaxPercent}%", Modifier.weight(1f), Color(0xFF7BA9E8))
                            DistributionMetric("Moderada", distributionReport.moderateIntensityPercent, "${distributionTarget.moderateMinPercent}–${distributionTarget.moderateMaxPercent}%", Modifier.weight(1f), Color(0xFFE2B66E))
                            DistributionMetric("Alta", distributionReport.highIntensityPercent, "${distributionTarget.highMinPercent}–${distributionTarget.highMaxPercent}%", Modifier.weight(1f), Color(0xFFCB91A5))
                        }
                        Text("~${distributionReport.totalEstimatedMinutes} min estimados • ${if (distributionReport.confidence == "ESTIMATED") "inclui etapas estimadas" else "segmentos estruturados"}", color = TextMuted, fontSize = 9.sp)
                    } else {
                        Text("Ainda não há duração/ritmo suficiente nos blocos para estimar a distribuição. O aplicativo não exibirá percentuais artificiais.", color = TextMuted, fontSize = 9.sp)
                    }
                    Text(distributionTarget.note, color = TextMuted, fontSize = 9.sp, lineHeight = 13.sp)
                }
            }
        }
        if (groups.isEmpty()) EmptyStateCard("Plano não criado", "Complete o perfil para o treinador organizar o seu ciclo.", "Revisar perfil") { state.onboardingStep = 1; state.persist() }
        groups.forEach { (week, sessions) ->
            TrainingWeekCard(
                week = week, sessions = sessions, currentWeek = (week == currentPlanWeek), expanded = expandedWeek == week,
                onToggle = { expandedWeek = if (expandedWeek == week) -1 else week },
                onSession = { state.selectWorkout(it) },
                onRaceStrategy = { state.openRaceStrategy(it) },
                events = state.eventsForPlanWeek(week)
            )
        }
        if (state.racePlanNote.isNotBlank()) {
            SectionHeading("Preparação para competição")
            NoteBlock(state.racePlanNote)
            state.racePlanWarnings.forEach { NoteBlock(it) }
        }
        if (state.raceEvents.isEmpty()) {
            CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 6.dp).clickable { state.navigateTo(Screen.RACES) }) {
                Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("Tem uma corrida marcada?", color = Blue2, fontWeight = FontWeight.Bold)
                    Text("Cadastre a prova para o treinador organizar a preparação, o taper e a recuperação.", color = TextMuted, fontSize = 11.sp)
                }
            }
        }
        NoteBlock("Os volumes representam a prescrição. A evolução real só é calculada quando as sessões são concluídas e a distância realizada é registrada.")
    }
}

@Composable private fun DistributionMetric(
    label: String,
    plannedPercent: Int,
    targetRange: String,
    modifier: Modifier = Modifier,
    accent: Color
) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, color = TextMuted, fontSize = 9.sp, maxLines = 1)
        Text("$plannedPercent%", color = accent, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text("Faixa $targetRange", color = TextMuted, fontSize = 8.sp, maxLines = 2, lineHeight = 10.sp)
    }
}

@Composable private fun TrainingWeekCard(
    week: Int,
    sessions: List<Workout>,
    currentWeek: Boolean,
    expanded: Boolean,
    onToggle: () -> Unit,
    onSession: (Workout) -> Unit,
    onRaceStrategy: (RaceEvent) -> Unit,
    events: List<RaceEvent> = emptyList()
) {
    val trainingKm = sessions.sumOf { it.distanceKm }
    val raceKm = events.filter { it.status != "CANCELLED" }.sumOf { it.distanceKm }
    val totalKm = trainingKm + raceKm
    val weeklyTargetKm = sessions.firstOrNull { it.weeklyTargetKm != null }?.weeklyTargetKm
    val longKm = sessions.filter { it.type == "Longo" }.sumOf { it.distanceKm }
    val qualityKm = sessions.filter { it.type == "Qualidade" }.sumOf { it.distanceKm }
    val easyKm = (trainingKm - longKm - qualityKm).coerceAtLeast(0.0)
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth().clickable(onClick = onToggle), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(if (currentWeek) "SEMANA $week · EM ANDAMENTO" else "SEMANA $week", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                    Text(when {
                        events.any { it.status == "PLANNED" && it.priority == "A" } -> "Semana da prova principal"
                        events.any { it.status == "PLANNED" && it.priority == "B" } -> "Prova preparatória"
                        events.any { it.status == "PLANNED" && it.priority == "C" } -> "Evento de treinamento"
                        sessions.firstOrNull()?.phase == "TAPER" -> "Redução pré-prova"
                        sessions.firstOrNull()?.phase == "POST_RACE_RECOVERY" -> "Recuperação pós-prova"
                        else -> phaseLabel(sessions.firstOrNull()?.phase ?: "BASE")
                    }, color = TextWhite, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("~${formatKmUi(totalKm)} km", color = TextWhite, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text(if (events.isEmpty()) "${sessions.size} treinos" else "${sessions.size} treinos + ${events.size} provas", color = TextMuted, fontSize = 10.sp)
                    weeklyTargetKm?.let { target ->
                        Text("Meta ${formatKmUi(target)} km", color = if (trainingKm + 0.05 < target) Yellow else Green, fontSize = 9.sp)
                    }
                }
                Spacer(Modifier.width(10.dp))
                Text(if (expanded) "⌃" else "⌄", color = Blue2, fontSize = 20.sp)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                if (totalKm > 0.0) {
                    if (easyKm > 0.0) Box(Modifier.weight((easyKm / totalKm).toFloat().coerceAtLeast(0.02f)).height(6.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF7BA9E8)))
                    if (qualityKm > 0.0) Box(Modifier.weight((qualityKm / totalKm).toFloat().coerceAtLeast(0.02f)).height(6.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFFE2B66E)))
                    if (longKm > 0.0) Box(Modifier.weight((longKm / totalKm).toFloat().coerceAtLeast(0.02f)).height(6.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF76CDB1)))
                    if (raceKm > 0.0) Box(Modifier.weight((raceKm / totalKm).toFloat().coerceAtLeast(0.02f)).height(6.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFFB79AF7)))
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Leves ${formatKmUi(easyKm)}", color = TextMuted, fontSize = 9.sp, modifier = Modifier.weight(1f), maxLines = 1)
                Text("Qualidade ${formatKmUi(qualityKm)}", color = TextMuted, fontSize = 9.sp, modifier = Modifier.weight(1f), maxLines = 1, textAlign = TextAlign.Center)
                Text("Longão ${formatKmUi(longKm)}", color = TextMuted, fontSize = 9.sp, modifier = Modifier.weight(1f), maxLines = 1, textAlign = TextAlign.End)
            }
            if (events.isNotEmpty()) {
                Text("Provas ${formatKmUi(raceKm)} km", color = Color(0xFFD2BFFF), fontSize = 9.sp)
            }
            if (expanded) {
                weeklyTargetKm?.let { target ->
                    val difference = trainingKm - target
                    Text(
                        when {
                            kotlin.math.abs(difference) < 0.15 -> "Volume prescrito alinhado à meta semanal."
                            difference < 0 -> "Prescrito abaixo da meta em ${formatKmUi(-difference)} km por limites de sessão e tolerância recente. O motor não força o volume restante."
                            else -> "Prescrito ${formatKmUi(difference)} km acima da meta; confira provas e sessões adicionais."
                        },
                        color = TextMuted, fontSize = 10.sp, lineHeight = 14.sp
                    )
                }
                HorizontalDivider(color = Color(0xFF31445A))
                events.sortedBy { it.eventDateIso }.forEach { event -> RaceAgendaRow(event) { onRaceStrategy(event) } }
                sessions.forEach { SessionAgendaRow(it) { onSession(it) } }
            } else {
                Text("Ver ${sessions.size} sessões  ›", color = Blue2, fontSize = 9.sp, modifier = Modifier.clickable(onClick = onToggle))
            }
        }
    }
}

@Composable private fun SessionAgendaRow(workout: Workout, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(Color(0xFF142338)).clickable(onClick = onClick).padding(11.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        SessionGlyph(workout, 36)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(workout.title, color = TextWhite, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            Text("${workout.date}  •  ${calendarCategory(workout)}", color = calendarCategoryColor(calendarCategory(workout)), fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text("~${formatKmUi(workout.distanceKm)} km", color = Blue2, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(if (workout.done) "Concluído" else "Planejado", color = if (workout.done) Green else TextMuted, fontSize = 9.sp)
        }
    }
}

@Composable private fun EvolutionScreen(state: CoachState) {
    var selectedPeriod by remember { mutableIntStateOf(28) }
    var zoneReview by remember { mutableStateOf<ZoneExecutionSummary?>(null) }
    val today = LocalDate.now()
    val cutoff = today.minusDays((selectedPeriod - 1).toLong())
    val allFeedback = state.feedbackRecords.sortedBy { state.feedbackActivityDate(it) }
    val feedbackEntries = allFeedback.filter { record ->
        val date = state.feedbackActivityDate(record)
        !date.isBefore(cutoff) && !date.isAfter(today)
    }
    val recorded = feedbackEntries.mapNotNull { record -> record.actualDistanceKm?.let { record to it } }
    val totalDistance = recorded.sumOf { it.second }
    val completedCount = feedbackEntries.size
    val averagePaceObservations = feedbackEntries.mapNotNull { feedback ->
        val pace = feedback.actualPaceMinKm ?: return@mapNotNull null
        val date = state.feedbackActivityDate(feedback).toString()
        PaceObservation(
            date, feedback.actualDistanceKm ?: 0.0, pace, feedback.workoutType, feedback.effort, feedback.feeling,
            feedback.painPresent, RunningTerrain.normalize(feedback.terrain), feedback.elevationGainMeters
        )
    }
    val paceTrend = PerformanceMonitoringEngine.evaluate(averagePaceObservations)
    val weeklyTotals = recorded.groupBy { (record, _) ->
        state.feedbackActivityDate(record).with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    }.toSortedMap().map { (weekStart, items) -> weekStart to items.sumOf { it.second } }
    val chartBuckets: List<Pair<LocalDate, Double>> = if (selectedPeriod == 7) {
        (0L..6L).map { cutoff.plusDays(it) }.map { date ->
            date to recorded.filter { state.feedbackActivityDate(it.first) == date }.sumOf { it.second }
        }
    } else {
        val firstWeek = cutoff.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val lastWeek = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val count = (java.time.temporal.ChronoUnit.WEEKS.between(firstWeek, lastWeek).toInt() + 1).coerceIn(1, 14)
        (0 until count).map { firstWeek.plusWeeks(it.toLong()) }
            .map { start -> start to (weeklyTotals.firstOrNull { it.first == start }?.second ?: 0.0) }
    }
    val completedIds = state.completedWorkouts().map { it.sessionId }.toSet()
    val plannedEvidence = state.workouts.mapNotNull { workout ->
        val date = runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull() ?: return@mapNotNull null
        PlannedSessionEvidence(workout.sessionId, date, workout.distanceKm, workout.done || workout.sessionId in completedIds)
    }
    val realizedEvidence = feedbackEntries.mapNotNull { record ->
        val distance = record.actualDistanceKm ?: return@mapNotNull null
        RealizedActivityEvidence(record.sessionId, state.feedbackActivityDate(record), distance)
    }
    val plannedVsRealized = PlannedVsRealizedEngine.summarize(plannedEvidence, realizedEvidence, today, selectedPeriod)
    val zoneTimesByRecord = feedbackEntries.associateWith { state.measuredZoneTimeForRecord(it) }
    val measuredZoneActivities = zoneTimesByRecord.values.count { it.isNotEmpty() }
    val measuredZones = zoneTimesByRecord.values.flatMap { it.entries }
        .groupBy({ it.key }, { it.value }).mapValues { (_, values) -> values.sum() }
    val maxZoneSeconds = measuredZones.values.maxOrNull()?.coerceAtLeast(1) ?: 1
    val maxWeeklyKm = chartBuckets.maxOfOrNull { it.second }?.coerceAtLeast(0.1) ?: 0.1
    val trainingLoad = state.trainingLoadSnapshot()
    val currentZones = state.currentPaceZones()?.all().orEmpty()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Evolução")
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf(7, 28, 90).forEach { days ->
                FilterChip(
                    selected = selectedPeriod == days,
                    onClick = { selectedPeriod = days },
                    label = { Text("${days} dias", fontSize = 11.sp) }
                )
            }
        }
        Text("Seu desempenho nos últimos $selectedPeriod dias", color = TextMuted, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 2.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            EvolutionMetric("Distância realizada", "${formatKmUi(totalDistance)} km", "↗", Blue2, Modifier.weight(1f))
            EvolutionMetric("Sessões registradas", completedCount.toString(), "✓", Green, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            EvolutionMetric("Aderência", plannedVsRealized.adherencePercent?.let { "$it%" } ?: "—", "◎", Green, Modifier.weight(1f))
            EvolutionMetric("Atividades medidas", recorded.size.toString(), "◷", Blue2, Modifier.weight(1f))
        }

        SectionHeading("Volume semanal")
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20344E)) {
            Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Quilômetros realizados", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(if (selectedPeriod == 7) "Quilômetros por dia" else "Quilômetros por semana", color = TextMuted, fontSize = 10.sp)
                    }
                    Text("${formatKmUi(totalDistance)} km", color = Blue2, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
                Row(
                    Modifier.fillMaxWidth().then(if (chartBuckets.size > 8) Modifier.horizontalScroll(rememberScrollState()) else Modifier).height(112.dp),
                    horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.Bottom
                ) {
                    chartBuckets.forEach { (bucketStart, km) ->
                        Column((if (chartBuckets.size > 8) Modifier.width(42.dp) else Modifier.weight(1f)).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                            Text(if (km > 0.0) formatKmUi(km) else "—", color = TextMuted, fontSize = 8.sp, maxLines = 1)
                            Spacer(Modifier.height(4.dp))
                            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.BottomCenter) {
                                if (km > 0.0) {
                                    Box(
                                        Modifier.fillMaxWidth(0.72f)
                                            .height((76.0 * (km / maxWeeklyKm)).coerceIn(5.0, 76.0).dp)
                                            .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                                            .background(Blue)
                                    )
                                } else Box(Modifier.fillMaxWidth(0.72f).height(3.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFF41516A)))
                            }
                            Spacer(Modifier.height(5.dp))
                            Text(bucketStart.format(DateTimeFormatter.ofPattern("dd/MM")), color = TextMuted, fontSize = 8.sp)
                        }
                    }
                }
            }
        }

        SectionHeading("Planejado x realizado")
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20344E)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Aderência ao plano", color = TextWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text(plannedVsRealized.adherencePercent?.let { "$it%" } ?: "Sem referência", color = Green, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
                val adherenceFraction = (plannedVsRealized.adherencePercent ?: 0).coerceIn(0, 100) / 100f
                Box(Modifier.fillMaxWidth().height(9.dp).clip(RoundedCornerShape(20.dp)).background(Color(0xFF34465D))) {
                    Box(Modifier.fillMaxWidth(adherenceFraction).fillMaxHeight().background(Green))
                }
                InfoRow("Distância planejada", "${formatKmUi(plannedVsRealized.plannedDistanceKm)} km")
                InfoRow("Distância realizada", "${formatKmUi(plannedVsRealized.realizedDistanceKm)} km")
                InfoRow("Sessões concluídas", "${plannedVsRealized.completedSessions} / ${plannedVsRealized.plannedSessions}")
                InfoRow("Atividades com distância real", plannedVsRealized.activitiesWithMeasuredDistance.toString())
                Text("Sessões sem distância real contam para aderência, mas não aumentam os quilômetros realizados.", color = TextMuted, fontSize = 9.sp, lineHeight = 13.sp)
            }
        }

        SectionHeading("Distribuição de intensidade")
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20344E)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Tempo medido nas zonas de ritmo", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("Calculado com amostras temporizadas e voltas válidas do GPX/FIT/TCX. O tempo manual informado nos blocos é exibido separadamente; trechos sem duração ou ritmo confiável permanecem desconhecidos.", color = TextMuted, fontSize = 9.sp, lineHeight = 13.sp)
                if (measuredZones.isEmpty()) {
                    Text("${feedbackEntries.size} sessão(ões) registradas; nenhuma forneceu amostras temporizadas ou voltas com ritmo e duração suficientes para classificar Z1–Z5.", color = TextMuted, fontSize = 10.sp)
                } else {
                    Text("Base: $measuredZoneActivities atividade(s) com dados utilizáveis • ${measuredZones.values.sum() / 60} min classificados", color = TextMuted, fontSize = 9.sp)
                    listOf("Z1", "Z2", "Z3", "Z4", "Z5").forEach { zone ->
                        val seconds = measuredZones[zone] ?: 0
                        val color = when (zone) {
                            "Z1" -> Color(0xFF7296DF)
                            "Z2" -> Green
                            "Z3" -> Yellow
                            "Z4" -> Color(0xFFFF986F)
                            else -> Color(0xFFE38DB8)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(zone, color = TextWhite, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(23.dp))
                            Box(Modifier.weight(1f).height(8.dp).clip(RoundedCornerShape(20.dp)).background(Color(0xFF34465D))) {
                                if (seconds > 0) Box(Modifier.fillMaxWidth((seconds.toFloat() / maxZoneSeconds).coerceIn(0f, 1f)).fillMaxHeight().background(color))
                            }
                            Text(if (seconds > 0) "${seconds / 60} min" else "—", color = TextMuted, fontSize = 9.sp, modifier = Modifier.width(42.dp), textAlign = TextAlign.End)
                        }
                    }
                }
            }
        }

        SectionHeading("Carga de treinamento")
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20344E)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    EvolutionMetric("Distância · 7 dias", "${formatKmUi(trainingLoad.totalKmLast7Days)} km", "↗", Blue2, Modifier.weight(1f))
                    EvolutionMetric("Distância · 28 dias", "${formatKmUi(trainingLoad.totalKmLast28Days)} km", "↗", Blue2, Modifier.weight(1f))
                }
                InfoRow("Média semanal (28 dias)", trainingLoad.averageWeeklyKmLast28Days?.let { "${formatKmUi(it)} km" } ?: "Histórico insuficiente")
                InfoRow("Média semanal (42 dias)", trainingLoad.averageWeeklyKmLast42Days?.let { "${formatKmUi(it)} km" } ?: "Sem dados suficientes")
                InfoRow("Maior corrida em 30 dias", trainingLoad.longestRunLast30DaysKm?.let { "${formatKmUi(it)} km" } ?: "Não disponível")
                InfoRow("Duração em 7 dias", trainingLoad.durationMinutesLast7Days?.let { "$it min" } ?: "Não informada")
                InfoRow("Carga sRPE em 7 dias", trainingLoad.sessionRpeLoadLast7Days?.toString() ?: "Não disponível")
                InfoRow("RPE médio em 28 dias", trainingLoad.averageRpeLast28Days?.let { String.format(Locale.US, "%.1f/10", it) } ?: "Não disponível")
                InfoRow("Cadência média em 28 dias", trainingLoad.averageCadenceLast28DaysSpm?.let { "$it spm" } ?: "Não disponível")
                InfoRow("Elevação acumulada em 28 dias", trainingLoad.elevationGainLast28DaysMeters?.let { "${it.roundToInt()} m" } ?: "Não disponível")
                trainingLoad.loadTrend7To28?.let { InfoRow("Tendência sRPE (7d × 4 / 28d)", String.format(Locale.US, "%.2f", it)) }
            }
        }

        SectionHeading("Monitoramento do ritmo")
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20344E)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                StatusPill(when (paceTrend.status) { "FASTER" -> "SINAL DE MELHORA"; "SLOWER" -> "ATENÇÃO"; "STABLE" -> "ESTÁVEL"; else -> "DADOS INSUFICIENTES" }, when (paceTrend.status) { "FASTER" -> Green; "SLOWER" -> Yellow; else -> Blue2 })
                Text(paceTrend.headline, color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text(paceTrend.explanation, color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                Text("Sessões comparáveis: ${paceTrend.comparableSessions}", color = Blue2, fontSize = 9.sp)
            }
        }

        SectionHeading("Zonas e calibração")
        val latestTest = state.cooperAssessments.maxByOrNull { it.dateIso }
        val review = state.cooperReviewStatus()
        val criticalSpeed = state.criticalSpeedSnapshot()
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20344E)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                InfoRow("Último teste", latestTest?.let { record ->
                    if (record.testMethod == "THREE_KM") "3 km • ${record.testDurationSeconds?.let(PhysiologicalProfileEngine::formatDuration) ?: "—"} • VO₂ ${String.format(Locale.US, "%.1f", record.estimatedVo2Max)}"
                    else "Cooper • ${formatKmUi(record.distanceKm)} km • VO₂ ${String.format(Locale.US, "%.1f", record.estimatedVo2Max)}"
                } ?: "Não realizado")
                InfoRow("Revisão", if (review.isDue) "Disponível" else review.nextReviewDate?.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) ?: "Pendente")
                InfoRow("Velocidade crítica estimada", criticalSpeed.paceLabel)
                InfoRow("Evidências para velocidade crítica", criticalSpeed.evidenceCount.toString())
                Text(criticalSpeed.explanation, color = TextMuted, fontSize = 9.sp, lineHeight = 14.sp)
                if (currentZones.isNotEmpty()) currentZones.forEach { zone -> InfoRow("${zone.id} • ${zone.name}", zone.range.label()) }
            }
        }

        val zoneExecution = state.zoneExecutionSummary()
        if (zoneExecution.isNotEmpty()) {
            SectionHeading("Comportamento por zona")
            CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20344E)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Evidências dos ritmos informados nos blocos. Este painel identifica tendências; não altera automaticamente as zonas prescritas.", color = TextMuted, fontSize = 10.sp, lineHeight = 14.sp)
                    zoneExecution.forEach { summary ->
                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(summary.zone, color = Blue2, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(1f))
                                Text("${summary.observationCount} blocos • ${summary.sessionCount} sessões", color = TextMuted, fontSize = 9.sp)
                            }
                            Text("Mais rápido ${summary.fasterCount} • preciso ${summary.preciseCount} • mais lento ${summary.slowerCount}", color = TextWhite, fontSize = 10.sp)
                            Text("Pace médio realizado ${PaceRange.format(summary.meanActualPaceSecondsPerKm)} • alvo médio ${PaceRange.format(summary.meanTargetPaceSecondsPerKm)} min/km", color = TextMuted, fontSize = 9.sp)
                            Text("Padrão entre blocos: queda ${summary.sessionsWithPaceFade} • aceleração ${summary.sessionsWithPaceAcceleration} • estável ${summary.sessionsWithStablePacing} sessão(ões)", color = TextMuted, fontSize = 9.sp)
                            Text("${summary.confidence}: ${summary.interpretation}", color = TextMuted, fontSize = 9.sp, lineHeight = 13.sp)
                            if (summary.interpretation.contains("candidata a revisão", ignoreCase = true)) {
                                val decision = state.zoneReviewDecision(summary)
                                if (decision == "OBSERVE") {
                                    Text("Revisão analisada • mantendo a faixa e observando novas sessões", color = Green, fontSize = 9.sp)
                                } else if (decision == "TEST") {
                                    Text("Teste solicitado • aguardando nova avaliação", color = Blue2, fontSize = 9.sp)
                                }
                                TextButton(onClick = { zoneReview = summary }, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)) {
                                    Text(if (decision == null) "Avaliar evidências" else "Reavaliar evidências", color = Blue2, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
        SectionHeading("Atividades recentes", "${feedbackEntries.size} registros")
        if (feedbackEntries.isEmpty()) {
            Text("As atividades registradas aparecerão aqui com data real, distância e execução dos blocos informada pelo corredor.", color = TextMuted, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 5.dp))
        } else {
            feedbackEntries.asReversed().take(5).forEach { record ->
                FeedbackHistoryDetails(record, state.feedbackActivityDate(record))
            }
        }
    }
    zoneReview?.let { summary ->
        AlertDialog(
            onDismissRequest = { zoneReview = null },
            title = { Text("Revisão assistida da ${summary.zone}") },
            text = {
                Text(
                    "Foram observados ${summary.observationCount} blocos em ${summary.sessionCount} sessões. " +
                        "${summary.fasterCount} execuções ficaram mais rápidas que o alvo. " +
                        "Esse padrão sugere que a faixa pode estar conservadora, mas não comprova sozinho que a zona deva ser acelerada. " +
                        "Confirme que os treinos foram confortáveis, sem dor e executados no objetivo previsto. A faixa atual não será alterada por esta avaliação.",
                    color = TextMuted
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    state.recordZoneReviewDecision(summary, "TEST")
                    zoneReview = null
                    state.openFieldTestEditor()
                }) {
                    Text("Abrir teste de desempenho")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    state.recordZoneReviewDecision(summary, "OBSERVE")
                    zoneReview = null
                }) { Text("Manter e observar") }
            }
        )
    }
}

@Composable private fun EvolutionMetric(label: String, value: String, icon: String, accent: Color, modifier: Modifier = Modifier) {
    CardSurface(modifier.padding(vertical = 3.dp), containerColor = CardBlue) {
        Column(Modifier.fillMaxWidth().heightIn(min = 78.dp).padding(horizontal = 11.dp, vertical = 9.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                Surface(shape = RoundedCornerShape(9.dp), color = accent.copy(alpha = 0.14f), modifier = Modifier.size(29.dp)) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(icon, color = accent, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Text(label, color = TextMuted, fontSize = 9.sp, lineHeight = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            }
            Text(value, color = accent, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable private fun FeedbackScreen(state: CoachState) {
    val workout = state.selectedWorkout()
    val existingFeedback = workout?.let { state.feedbackForSession(it.sessionId) }
    val context = androidx.compose.ui.platform.LocalContext.current
    var effort by remember(workout?.sessionId) { mutableStateOf(existingFeedback?.effort ?: "Leve") }
    var feeling by remember(workout?.sessionId) { mutableStateOf(existingFeedback?.feeling ?: "Bem") }
    var pain by remember(workout?.sessionId) { mutableStateOf(if (existingFeedback?.painPresent == true) "Sim" else "Não") }
    var notes by remember(workout?.sessionId) { mutableStateOf(existingFeedback?.notes ?: "") }
    var actualDistance by remember(workout?.sessionId) { mutableStateOf(existingFeedback?.actualDistanceKm?.let { formatKmUi(it) } ?: "") }
    var actualDuration by remember(workout?.sessionId) { mutableStateOf(existingFeedback?.actualDuration ?: "") }
    val prescribedBlocks = remember(workout?.sessionId, workout?.segments) {
        WorkoutBlockFeedbackEngine.expand(workout?.segments.orEmpty())
    }
    var blockPaceInputs by remember(workout?.sessionId) {
        mutableStateOf(existingFeedback?.blockPaceFeedback?.associate { it.blockKey to it.actualPaceSecondsPerKm?.let(PaceRange::format).orEmpty() }.orEmpty())
    }
    var activityTerrain by remember(workout?.sessionId) {
        mutableStateOf(existingFeedback?.terrain?.let(RunningTerrain::normalize) ?: state.terrainPreference)
    }
    var selectedRaceId by remember(workout?.sessionId) { mutableStateOf(existingFeedback?.raceEventId.orEmpty()) }
    var raceMenuExpanded by remember(workout?.sessionId) { mutableStateOf(false) }
    var importedActivity by remember(workout?.sessionId) { mutableStateOf<ImportedActivity?>(null) }
    var importMessage by remember(workout?.sessionId) { mutableStateOf("") }
    var importError by remember(workout?.sessionId) { mutableStateOf("") }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && workout != null) {
            try {
                val filename = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) cursor.getString(0) else null
                } ?: uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':') ?: "atividade.gpx"
                val stream = context.contentResolver.openInputStream(uri)
                    ?: throw ActivityImportException("Não foi possível abrir o arquivo selecionado.")
                val parsed = ActivityFileImporter.import(stream, filename)
                if (state.importedActivityUsedElsewhere(parsed.fingerprint, workout.sessionId)) {
                    importedActivity = null
                    importError = "Esta atividade já está vinculada a outra sessão. Escolha o arquivo correto para evitar duplicação."
                    importMessage = ""
                } else {
                    importedActivity = parsed
                    parsed.distanceKm?.let { actualDistance = String.format(Locale.US, "%.2f", it) }
                    // Missing timestamps stay missing; they are never replaced with an estimated duration.
                    actualDuration = parsed.elapsedSeconds?.let(PaceRange::formatDuration).orEmpty()
                    importMessage = "${parsed.sourceFormat} importado. Confira as métricas e confirme junto ao feedback."
                    importError = ""
                }
            } catch (error: Exception) {
                importedActivity = null
                importMessage = ""
                importError = error.message ?: "Falha ao importar a atividade."
            }
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Feedback da sessão", true) { state.navigateBack(Screen.WORKOUT) }
        if (workout != null) SessionHero(workout, state.feedbackRecords)
        else NoteBlock("Selecione uma sessão para registrar o feedback.")
        SectionHeading("Como foi o esforço?")
        FeedbackGroup("Esforço percebido", listOf("Muito leve", "Leve", "Ok", "Pesado", "Muito pesado"), effort) { effort = it }
        SectionHeading("Como você se sentiu?")
        FeedbackGroup("Sensação geral", listOf("Ótimo", "Bem", "Cansado", "Muito cansado"), feeling) { feeling = it }
        SectionHeading("Segurança")
        FeedbackGroup("Sentiu dor durante ou após o treino?", listOf("Não", "Sim"), pain) { pain = it }
        FeedbackGroup("Terreno desta atividade", RunningTerrain.options, RunningTerrain.label(activityTerrain)) {
            activityTerrain = RunningTerrain.fromLabel(it)
        }
        CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Métricas reais da sessão", color = TextWhite, fontWeight = FontWeight.Bold)
                Text("Importe a atividade do relógio ou aplicativo. O arquivo preenche as métricas que realmente contém; dados ausentes permanecem vazios. A importação não substitui esforço, sensação ou dor.", color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                OutlinedButton(onClick = { importLauncher.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (importedActivity != null) "Trocar arquivo da atividade" else "Importar atividade GPX, FIT ou TCX")
                }
                if (importMessage.isNotBlank()) Text(importMessage, color = Green, fontSize = 10.sp)
                if (importError.isNotBlank()) Text(importError, color = Yellow, fontSize = 10.sp)
                if (importedActivity != null) {
                    val activity = importedActivity!!
                    CardSurface(Modifier.fillMaxWidth(), containerColor = Color(0xFF162B40)) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("Prévia da atividade • ${activity.sourceFormat}", color = Blue2, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            val distanceLabel = activity.distanceKm?.let { "${formatKmUi(it)} km" } ?: "Não disponível"
                            val durationLabel = activity.elapsedSeconds?.let(PaceRange::formatDuration) ?: "Não disponível (sem tempo válido no arquivo)"
                            InfoRow("Distância", distanceLabel)
                            InfoRow("Tempo decorrido", durationLabel)
                            activity.averagePaceMmSs?.let { InfoRow("Ritmo médio", "$it min/km") }
                            activity.startedAtIso?.let { InfoRow("Início", it.replace('T', ' ').substringBefore('.').removeSuffix("Z")) }
                            activity.elevationGainMeters?.let { InfoRow("Ganho de elevação", "${it.roundToInt()} m") }
                            activity.averageCadenceSpm?.let { InfoRow("Cadência média", "$it spm") }
                            activity.maxCadenceSpm?.let { InfoRow("Cadência máxima", "$it spm") }
                            if (activity.routePointCount > 0) InfoRow("Pontos GPS do percurso", activity.routePointCount.toString())
                            if (activity.splitDetails.isNotEmpty()) {
                                Text("Parciais e trechos da atividade", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                activity.splitDetails.forEach { split ->
                                    val distanceText = "${String.format(Locale("pt", "BR"), "%.2f", split.distanceMeters / 1000.0)} km"
                                    val paceText = split.paceSecondsPerKm?.let { " • ${PaceRange.format(it)} min/km" }.orEmpty()
                                    val timeText = split.durationSeconds?.let { " • ${PaceRange.formatDuration(it)}" }.orEmpty()
                                    Text("${split.label} • $distanceText$paceText$timeText", color = TextMuted, fontSize = 10.sp)
                                }
                                val coverage = activity.splitDetails.sumOf { it.distanceMeters } / 1000.0
                                Text("Trechos detalhados: ${formatKmUi(coverage)} km de ${activity.distanceKm?.let(::formatKmUi) ?: "—"} km", color = Green, fontSize = 9.sp)
                            } else if (activity.splitPacesMmSs.isNotEmpty()) {
                                Text("Parciais calculadas (distância estimada por volta)", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                activity.splitPacesMmSs.forEachIndexed { index, split -> Text("${index + 1}º km • $split min/km", color = TextMuted, fontSize = 10.sp) }
                            }
                        }
                    }
                } else if (!existingFeedback?.activitySourceFormat.isNullOrBlank()) {
                    Text("Atividade ${existingFeedback?.activitySourceFormat} já vinculada a esta sessão. Salvar novamente preserva as métricas e o percurso importados.", color = Blue2, fontSize = 10.sp)
                }
                OutlinedTextField(actualDistance, { actualDistance = SmartInputMask.distance(it) }, label = { Text("Distância realizada (km)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(actualDuration, { actualDuration = SmartInputMask.duration(it) }, label = { Text("Tempo total (mm:ss ou hh:mm:ss)") }, supportingText = { Text("Exemplo: 42:30 ou 01:12:30") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth(), singleLine = true)
                if (prescribedBlocks.isNotEmpty()) {
                    HorizontalDivider(color = Color(0x443F5878))
                    Text("EXECUÇÃO DOS BLOCOS", color = Blue2, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("Informe o ritmo médio realizado em cada bloco, conforme a prescrição. As repetições são separadas e os ritmos do arquivo GPX não são usados para atribuí-las automaticamente.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                    prescribedBlocks.forEachIndexed { index, block ->
                        val segment = block.segment
                        val isPassiveOrWalk = !WorkoutBlockFeedbackEngine.requiresPaceInput(block)
                        val paceAllowed = !isPassiveOrWalk
                        val paceText = blockPaceInputs[block.key].orEmpty()
                        val actualPaceValue = PaceRange.parsePace(paceText)
                        val comparison = if (paceAllowed && paceText.isNotBlank() && actualPaceValue != null) {
                            WorkoutBlockFeedbackEngine.compare(WorkoutBlockFeedbackEngine.from(block, actualPaceValue))
                        } else null
                        CardSurface(Modifier.fillMaxWidth(), containerColor = Color(0xFF162B40)) {
                            Column(Modifier.padding(11.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("${index + 1}. ${WorkoutTitleSanitizer.clean(segment.name)}" + if (segment.repeatCount > 1) " • ${block.repetition}" else "", color = TextWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                    segment.paceZone?.let { Text(it, color = Blue2, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                                }
                                val targetLabel = if (segment.targetPaceMinValue != null && segment.targetPaceMaxValue != null) {
                                    "${PaceRange(segment.targetPaceMinValue, segment.targetPaceMaxValue).label()}"
                                } else "Sem ritmo proposto"
                                Text("Ritmo proposto: $targetLabel", color = Blue2, fontSize = 10.sp)
                                if (paceAllowed) {
                                    OutlinedTextField(
                                        value = paceText,
                                        onValueChange = { next -> blockPaceInputs = blockPaceInputs + (block.key to SmartInputMask.pace(next)) },
                                        label = { Text("Ritmo realizado (mm:ss min/km)") },
                                        supportingText = { Text("Opcional • exemplo 6:15") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth(), singleLine = true
                                    )
                                    if (paceText.isNotBlank() && actualPaceValue == null) {
                                        Text("Use mm:ss min/km, por exemplo 6:15.", color = Yellow, fontSize = 10.sp)
                                    } else if (comparison != null) {
                                        val (label, color) = when (comparison.status) {
                                            WorkoutBlockFeedbackEngine.FASTER -> "Mais rápido que o proposto" to Green
                                            WorkoutBlockFeedbackEngine.PRECISE -> "Dentro do ritmo proposto" to Green
                                            WorkoutBlockFeedbackEngine.SLOWER -> "Mais lento que o proposto" to Yellow
                                            else -> "Sem comparação" to TextMuted
                                        }
                                        Text(if (comparison.status == WorkoutBlockFeedbackEngine.NO_TARGET) "Ritmo salvo • bloco sem faixa prescrita" else label, color = if (comparison.status == WorkoutBlockFeedbackEngine.NO_TARGET) TextMuted else color, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                } else {
                                    Text(if (segment.recoveryMode == "PASSIVE" || segment.name.contains("pausa", ignoreCase = true)) "Pausa passiva • não exige ritmo" else "Caminhada • não exige ritmo", color = TextMuted, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
                val actualKm = actualDistance.trim().replace(",", ".").toDoubleOrNull()
                val elapsed = PaceCalculator.parseDuration(actualDuration)
                if (actualKm != null && elapsed != null) {
                    val pace = PaceCalculator.paceFromDistanceAndDuration(actualKm, elapsed)
                    if (pace != null) Text("Ritmo realizado: ${PaceRange.format(pace)} min/km", color = Green, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                if (actualDuration.isNotBlank() && elapsed == null) Text("Informe o tempo como mm:ss ou hh:mm:ss.", color = Yellow, fontSize = 10.sp)
                OutlinedTextField(notes, { notes = it }, label = { Text("Observações (opcional)") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
            }
        }
        if (state.raceEvents.isNotEmpty()) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Resultado de prova (opcional)", color = TextMuted, fontSize = 11.sp)
                Box {
                    OutlinedButton(onClick = { raceMenuExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                        val linkedName = state.raceEvents.firstOrNull { it.id == selectedRaceId }?.name ?: "Não vincular a uma prova"
                        Text(linkedName, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    DropdownMenu(expanded = raceMenuExpanded, onDismissRequest = { raceMenuExpanded = false }) {
                        DropdownMenuItem(text = { Text("Não vincular a uma prova") }, onClick = {
                            selectedRaceId = ""; raceMenuExpanded = false
                        })
                        state.raceEvents.forEach { race ->
                            DropdownMenuItem(text = { Text("${race.name} • ${RaceEventEngine.formatBrazilianDate(race.eventDateIso)}") }, onClick = {
                                selectedRaceId = race.id; raceMenuExpanded = false
                            })
                        }
                    }
                }
                Text("Vincule somente quando esta atividade corresponder à prova. Com distância e duração reais, ela fica associada ao resultado e marca a prova como concluída. Só entra na estimativa de velocidade crítica se também cumprir os critérios de esforço forte (RPE ≥ 7), ausência de dor, atualidade e diversidade de distâncias/durações.", color = TextMuted, fontSize = 10.sp, lineHeight = 14.sp)
            }
        }
        val blockEntriesValid = blockPaceInputs.values.all { it.isBlank() || PaceRange.parsePace(it) != null }
        val savedBlockFeedback = prescribedBlocks.mapNotNull { block ->
            val text = blockPaceInputs[block.key].orEmpty()
            if (text.isBlank()) null else PaceRange.parsePace(text)?.let { pace -> WorkoutBlockFeedbackEngine.from(block, pace) }
        }
        PrimaryButton(if (existingFeedback != null) "Atualizar registro da sessão" else "Salvar feedback e registrar sessão", enabled = workout != null && (actualDuration.isBlank() || PaceCalculator.parseDuration(actualDuration) != null) && blockEntriesValid) {
            if (state.saveFeedback(
                    effort, feeling, notes, pain == "Sim", actualDistance, actualDuration,
                    savedBlockFeedback, importedActivity, activityTerrain, selectedRaceId
                )) {
                state.navigateTo(Screen.HISTORY)
            }
        }
        if (state.motorError.isNotBlank()) NoteBlock(state.motorError)
    }
}

@Composable private fun FeedbackGroup(title: String, options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text(title, color = TextMuted, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 20.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            options.forEach { option ->
                val active = option == selected
                Surface(
                    modifier = Modifier.clickable { onSelect(option) },
                    shape = RoundedCornerShape(50),
                    color = if (active) Color(0xFF344B78) else CardBlue,
                    border = if (active) androidx.compose.foundation.BorderStroke(1.dp, Blue2) else null
                ) { Text(option, color = if (active) Color.White else TextMuted, fontSize = 11.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) }
            }
        }
    }
}

@Composable private fun HistoryScreen(state: CoachState) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 22.dp)) {
        Header("Histórico de treinos")
        val completed = state.completedWorkouts().sortedByDescending { workout ->
            state.feedbackForSession(workout.sessionId)?.let(state::feedbackActivityDate)
                ?: runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull() ?: LocalDate.MIN
        }
        val archivedFeedback = state.orphanFeedbackRecords().sortedByDescending(state::feedbackActivityDate)
        if (completed.isEmpty() && archivedFeedback.isEmpty()) {
            EmptyStateCard("Nenhuma sessão concluída", "Quando registrar o feedback de uma sessão, ela ficará salva aqui mesmo depois de recalcular um novo plano.", "Voltar ao início") { state.navigateBack(Screen.DASHBOARD) }
        } else {
            SectionHeading("Sessões registradas", "${completed.size + archivedFeedback.size} no total")
            completed.forEach { workout ->
                val record = state.feedbackForSession(workout.sessionId)
                val activityDate = record?.let(state::feedbackActivityDate)
                val activityStart = record?.activityStartedAtIso?.takeIf { it.isNotBlank() }?.let { raw ->
                    runCatching { Instant.parse(raw).atZone(ZoneId.systemDefault()) }.getOrNull()
                }
                WorkoutCard(
                    workout,
                    activityDate?.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")),
                    activityStart?.format(DateTimeFormatter.ofPattern("HH:mm")),
                    if (activityDate != null) workout.scheduledDateIso else null
                ) {
                    state.selectWorkout(workout); state.navigateTo(Screen.FEEDBACK)
                }
                record?.let { FeedbackHistoryDetails(it, activityDate) }
            }
            if (archivedFeedback.isNotEmpty()) {
                SectionHeading("Registros preservados de ciclos anteriores")
                archivedFeedback.forEach { FeedbackHistoryDetails(it, state.feedbackActivityDate(it)) }
            }
        }
    }
}

@Composable private fun FeedbackHistoryDetails(
    record: FeedbackRecord,
    realizedDate: LocalDate? = null
) {
    var detailsExpanded by remember(record.sessionId) { mutableStateOf(false) }
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 3.dp), containerColor = Color(0xFF142338)) {
        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(record.workoutTitle.ifBlank { record.workoutType.ifBlank { "Feedback de treino" } }, color = Blue2, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            val actualLabel = realizedDate?.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) ?: "Data não informada"
            val activityStart = record.activityStartedAtIso.takeIf { it.isNotBlank() }?.let { raw ->
                runCatching { Instant.parse(raw).atZone(ZoneId.systemDefault()) }.getOrNull()
            }
            val actualTime = activityStart?.format(DateTimeFormatter.ofPattern("HH:mm"))
            val timeSourceLabel = when (record.activityStartedAtSource) {
                "TRACK_POINT" -> "hora do GPS"
                "SESSION" -> "hora da sessão"
                "LAP" -> "hora da volta"
                "METADATA" -> "horário de metadados"
                else -> ""
            }
            val actualDateTimeLabel = "Realizado $actualLabel" + (actualTime?.let { " • $it" }.orEmpty())
            val plannedLabel = record.workoutDateIso.takeIf { it.isNotBlank() }?.let {
                runCatching { LocalDate.parse(it).format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) }.getOrNull()
            }
            val datesLabel = if (plannedLabel != null && plannedLabel != actualLabel) {
                "$actualDateTimeLabel • planejado $plannedLabel"
            } else actualDateTimeLabel
            Text(datesLabel + (timeSourceLabel.takeIf { it.isNotBlank() }?.let { " • $it" }.orEmpty()) + " • Esforço: ${record.effort} • Sensação: ${record.feeling}", color = TextMuted, fontSize = 10.sp)
            val distance = record.actualDistanceKm?.let { "${formatKmUi(it)} km reais" } ?: "Distância real não informada"
            val duration = record.actualDuration ?: "Tempo real não informado"
            val pace = record.actualPaceMinKm?.let { " • $it min/km" }.orEmpty()
            Text("$distance • $duration$pace", color = TextWhite, fontSize = 11.sp)
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(9.dp)).clickable { detailsExpanded = !detailsExpanded }.padding(vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(if (detailsExpanded) "Ocultar detalhes da atividade" else "Ver detalhes da atividade", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                Text(if (detailsExpanded) "⌃" else "⌄", color = Blue2, fontSize = 14.sp)
            }
            if (detailsExpanded) {
            Text("Terreno: ${RunningTerrain.label(record.terrain)}", color = TextMuted, fontSize = 10.sp)
            if (record.raceEventId.isNotBlank()) Text("Atividade vinculada a uma prova • pode compor evidências fisiológicas quando válida", color = Green, fontSize = 10.sp)
            if (record.activitySourceFormat.isNotBlank()) {
                Text("Atividade ${record.activitySourceFormat} importada • ${record.routePointCount} pontos GPS", color = Blue2, fontSize = 10.sp)
                val metrics = listOfNotNull(
                    record.elevationGainMeters?.let { "Elevação +${it.roundToInt()} m" },
                    record.averageCadenceSpm?.let { "Cadência $it spm" }
                )
                if (metrics.isNotEmpty()) Text(metrics.joinToString(" • "), color = TextMuted, fontSize = 10.sp)
                if (record.splitDetails.isNotEmpty()) {
                    Text("Parciais: " + record.splitDetails.joinToString(" • ") { split ->
                        "${split.label} ${formatKmUi(split.distanceMeters / 1000.0)} km" + (split.paceSecondsPerKm?.let { " ${PaceRange.format(it)}" } ?: "")
                    }, color = TextMuted, fontSize = 10.sp, lineHeight = 14.sp)
                } else if (record.splitPacesMmSs.isNotEmpty()) Text("Parciais: ${record.splitPacesMmSs.joinToString(" / ")} min/km", color = TextMuted, fontSize = 10.sp)
                if (record.measuredZoneTimeSeconds.isNotEmpty()) {
                    Text("Tempo medido por zona: " + record.measuredZoneTimeSeconds.toSortedMap().entries.joinToString(" • ") { (zone, seconds) -> "$zone ${seconds / 60} min" }, color = Blue2, fontSize = 10.sp)
                }
            }
            if (record.blockPaceFeedback.isNotEmpty()) {
                Text("Execução manual dos blocos", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                record.blockPaceFeedback.forEach { block ->
                    val comparison = WorkoutBlockFeedbackEngine.compare(block)
                    val resultLabel = when (comparison.status) {
                        WorkoutBlockFeedbackEngine.FASTER -> "Mais rápido que o proposto"
                        WorkoutBlockFeedbackEngine.PRECISE -> "Dentro do ritmo proposto"
                        WorkoutBlockFeedbackEngine.SLOWER -> "Mais lento que o proposto"
                        WorkoutBlockFeedbackEngine.NO_TARGET -> "Sem faixa proposta"
                        else -> "Sem ritmo informado"
                    }
                    val target = if (block.targetFastestPaceSecondsPerKm != null && block.targetSlowestPaceSecondsPerKm != null) {
                        PaceRange(block.targetFastestPaceSecondsPerKm, block.targetSlowestPaceSecondsPerKm).label()
                    } else "Sem ritmo proposto"
                    val actual = block.actualPaceSecondsPerKm?.let { "${PaceRange.format(it)} min/km" } ?: "Não informado"
                    Text(
                        "${block.segmentName}${if (block.repetition > 1) " • ${block.repetition}" else ""} ${block.targetZone?.let { "• $it" }.orEmpty()} — alvo $target • realizado $actual • $resultLabel",
                        color = TextMuted, fontSize = 9.sp, lineHeight = 13.sp
                    )
                }
            }
            if (record.painPresent) Text("Dor relatada • revisar recuperação antes de nova carga", color = Color(0xFFFFA4A4), fontSize = 10.sp)
            if (record.notes.isNotBlank()) Text(record.notes, color = TextMuted, fontSize = 10.sp)
            }
        }
    }
}

@Composable private fun CalibrationStatusLine(title: String, status: String, count: Int, required: Int) {
    val calibrated = status == ZoneCalibrationEngine.CALIBRATED
    val detail = when (status) {
        ZoneCalibrationEngine.CALIBRATED -> "Calibrada • $count evidências válidas"
        ZoneCalibrationEngine.OBSERVATION -> "Em observação • $count/$required evidências"
        ZoneCalibrationEngine.UNSTABLE -> "Instável • dados contraditórios; faixa-base preservada"
        ZoneCalibrationEngine.REVIEW -> "Reavaliação • fronteira em ajuste gradual ou referência fora da faixa atual"
        else -> "Inicial • $count/$required evidências"
    }
    Text("$title — $detail", color = if (calibrated) Green else if (status == ZoneCalibrationEngine.UNSTABLE || status == ZoneCalibrationEngine.REVIEW) Yellow else TextMuted, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
}

@Composable private fun PaceZonesScreen(state: CoachState) {
    val zones = state.currentPaceZones()
    val review = state.cooperReviewStatus()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Zonas de ritmo Z1–Z5", true) { state.navigateBack(Screen.PROFILE) }
        if (zones == null) {
            EmptyStateCard("Zonas ainda não calibradas", "Registre um Cooper de 12 minutos ou um teste de 3 km válido. O treinador estimará VO₂máx e as faixas individuais Z1–Z5.", "Calibrar ritmo") { state.openFieldTestEditor() }
        } else {
            CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20344E)) {
                Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("REFERÊNCIA ATUAL", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                    Text(if (listOf(zones.z1CalibrationStatus, zones.z3CalibrationStatus).any { it == ZoneCalibrationEngine.CALIBRATED }) "Zonas refinadas por evidências de desempenho" else "Faixas operacionais estimadas pelo teste de campo", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    InfoRow("VAM estimada (referência complementar)", "${zones.estimatedMasPace} min/km")
                    InfoRow("Segundo limiar estimado (complementar)", "${zones.estimatedSvt2Pace} min/km")
                    CalibrationStatusLine("Z1 • Recuperação", zones.z1CalibrationStatus, zones.z1CalibrationEvidenceCount, 3)
                    CalibrationStatusLine("Z3 • Desempenho", zones.z3CalibrationStatus, zones.z3CalibrationEvidenceCount, 2)
                    zones.z1CalibrationReferencePaceValue?.let { InfoRow("Referência observada Z1", "${PaceRange.format(it)} min/km") }
                    zones.z3CalibrationReferencePaceValue?.let { InfoRow("Fronteira operacional Z3", "${PaceRange.format(it)} min/km") }
                    val last = state.cooperAssessments.lastOrNull()
                    if (last != null) {
                        InfoRow("Teste de referência", if (last.testMethod == "THREE_KM") "3 km • ${last.testDurationSeconds?.let(PhysiologicalProfileEngine::formatDuration) ?: "—"}" else "Cooper • ${formatKmUi(last.distanceKm)} km em 12 min")
                        InfoRow("Ritmo médio", "${last.averagePace} min/km")
                        InfoRow("VO₂máx estimado", String.format(Locale.US, "%.1f ml/kg/min", last.estimatedVo2Max))
                    }
                    Text("Z1–Z5 são faixas operacionais. A evidência regenerativa pode revisar Z1; testes de desempenho independentes podem revisar Z3. A execução manual dos blocos acompanha o comportamento em Z1–Z5, sem alterar automaticamente as faixas. Z4–Z5 continuam estimativas de campo.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                    Text("Cada etapa pode usar qualquer faixa contínua de 0% a 100% dentro da zona: 0% é o limite mais lento e 100% o mais rápido; não é percentual de VO₂máx. Para corredores com 6 meses ou mais, aquecimento e desaquecimento usam Z2 0–20%; recuperações são definidas pelo esforço e podem ser paradas, caminhadas ou ativas.", color = Blue2, fontSize = 10.sp, lineHeight = 15.sp)
                    Text("Ajustes automáticos exigem registros consistentes e sem relato de dor. O ritmo de competição nunca substitui uma zona fisiológica.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                    Text(review.message, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                    val method = last?.testMethod ?: "COOPER_12_MIN"
                    CooperAssessmentEngine.improvementSincePrevious(state.cooperAssessments, method)?.let { change ->
                        val sign = if (change >= 0.0) "+" else ""
                        Text("Evolução no mesmo teste: $sign${String.format(Locale.US, "%.1f", change)}%", color = if (change >= 0.0) Green else Yellow, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            zones.all().forEach { zone ->
                CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(zone.id, color = Blue2, fontSize = 19.sp, fontWeight = FontWeight.Black)
                            Spacer(Modifier.width(10.dp))
                            Text(zone.name, color = TextWhite, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Text(zone.range.label(), color = Green, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Text(zone.purpose, color = TextMuted, fontSize = 11.sp)
                        Text(zone.intensityBand, color = TextMuted, fontSize = 10.sp)
                    }
                }
            }
            NoteBlock("Atividades comuns alimentam carga e recuperação, mas não são tratadas como testes máximos. VO₂máx e limiares permanecem estimativas de campo.")
            if (state.workouts.isNotEmpty()) {
                PrimaryButton("Aplicar calibração ao plano") {
                    val updated = state.recalibratePlan()
                    if (!updated && state.motorError.isBlank()) state.motorError = "Não foi possível recalibrar o plano. Confira o perfil e os dados de recuperação."
                }
                if (state.latestCooperMessage.isNotBlank()) NoteBlock(state.latestCooperMessage)
            }
        }
        PrimaryButton("Registrar teste fisiológico") { state.openFieldTestEditor() }
    }
}

@Composable private fun CooperTestScreen(state: CoachState) {
    val zones = state.selectedFieldTestZones()
    val assessment = zones?.let { z ->
        state.parsedAssessmentAge()?.let { age -> RunnerFitnessAssessmentEngine.assess(z.estimatedVo2Max, age, state.referenceSex, "FIELD_ESTIMATE") }
    }
    val testIsValid = state.fitnessTestMethod != "NONE" && state.isCooperEntryValid() && zones != null
    val methodLabel = when (state.fitnessTestMethod) {
        "THREE_KM" -> "Corrida de 3 km"
        "COOPER_12_MIN" -> "Cooper (12 min)"
        else -> "Selecione o teste"
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Teste fisiológico", true) { state.navigateBack(Screen.PROFILE) }
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20344E)) {
            Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("AVALIAÇÃO DE VO₂MÁX", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                Text("O resultado define o nível fisiológico e atualiza as zonas de ritmo.", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Text("Use um percurso plano, medido e condições seguras. O teste substitui uma sessão intensa.", color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
            }
        }
        SectionHeading("Método e dados")
        CardSurface(Modifier.padding(horizontal = 16.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                CompactChoiceScreen("Teste", listOf("Cooper (12 min)", "Corrida de 3 km"), methodLabel) { selected ->
                    state.fitnessTestMethod = if (selected == "Corrida de 3 km") "THREE_KM" else "COOPER_12_MIN"
                    state.cooperEnabled = true
                    state.refreshPhysiologicalLevelFromTest()
                }
                Text("Idade do atleta: ${state.profileAgeLabel()}", color = Blue2, fontSize = 12.sp)
                Text("A idade do teste é calculada automaticamente pela data de nascimento do perfil. Não é necessário informar idade novamente.", color = TextMuted, fontSize = 10.sp, lineHeight = 14.sp)
                if (state.referenceSex !in setOf(RunnerFitnessAssessmentEngine.MALE, RunnerFitnessAssessmentEngine.FEMALE)) {
                    CompactChoiceScreen("Configurar referência fisiológica do perfil", listOf("Masculino", "Feminino"), "") {
                        state.referenceSex = if (it == "Masculino") RunnerFitnessAssessmentEngine.MALE else RunnerFitnessAssessmentEngine.FEMALE
                        state.persist(synchronous = true)
                        state.refreshPhysiologicalLevelFromTest()
                    }
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Referência do perfil: ${if (state.referenceSex == RunnerFitnessAssessmentEngine.MALE) "Masculina" else "Feminina"}", color = Blue2, fontSize = 11.sp, modifier = Modifier.weight(1f))
                        TextButton(onClick = { state.navigateTo(Screen.PROFILE) }) { Text("Alterar no perfil", fontSize = 10.sp) }
                    }
                }
                when (state.fitnessTestMethod) {
                    "THREE_KM" -> {
                        OutlinedTextField(
                            value = state.threeKmTimeText,
                            onValueChange = { state.threeKmTimeText = SmartInputMask.duration(it); state.refreshPhysiologicalLevelFromTest() },
                            label = { Text("Tempo para 3 km (mm:ss)") }, placeholder = { Text("Ex.: 15:30") },
                            modifier = Modifier.fillMaxWidth(), singleLine = true
                        )
                        Text("Equação de campo estudada para adultos de 18 a 39 anos. Fora dessa faixa, use o Cooper.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                    }
                    else -> {
                        OutlinedTextField(
                            value = state.cooperDistanceText,
                            onValueChange = { state.cooperDistanceText = SmartInputMask.distance(it); state.refreshPhysiologicalLevelFromTest() },
                            label = { Text("Distância em 12 minutos (km)") }, placeholder = { Text("Ex.: 2,40") },
                            modifier = Modifier.fillMaxWidth(), singleLine = true
                        )
                        Text("Registre a distância total percorrida em 12 minutos.", color = TextMuted, fontSize = 10.sp)
                    }
                }
                OutlinedTextField(
                    value = state.cooperAssessmentDateText,
                    onValueChange = { state.cooperAssessmentDateText = SmartInputMask.date(it); state.persist() },
                    label = { Text("Data do teste (dd/mm/aaaa)") }, modifier = Modifier.fillMaxWidth(), singleLine = true
                )
                if (assessment != null) {
                    HorizontalDivider(color = Color(0x443F5878))
                    InfoRow("VO₂máx estimado", String.format(Locale.US, "%.1f ml/kg/min", assessment.vo2Max))
                    InfoRow("Nível fisiológico", assessment.level)
                    InfoRow("Método", methodLabel)
                    val thresholds = assessment.thresholds
                    Text("Faixas da sua referência etária (ml/kg/min)", color = Blue2, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    listOf(
                        "Iniciante" to "< ${String.format(Locale.US, "%.1f", thresholds.intermediate)}",
                        "Intermediário" to "${String.format(Locale.US, "%.1f", thresholds.intermediate)}–${String.format(Locale.US, "%.1f", thresholds.performance - 0.1)}",
                        "Performance" to "${String.format(Locale.US, "%.1f", thresholds.performance)}–${String.format(Locale.US, "%.1f", thresholds.elite - 0.1)}",
                        "Elite" to "≥ ${String.format(Locale.US, "%.1f", thresholds.elite)}"
                    ).forEach { (label, range) ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(label, color = TextMuted, fontSize = 10.sp)
                            Text(range, color = TextWhite, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    Text("Referência geral de aptidão cardiorrespiratória por idade e sexo; não é ranking competitivo.", color = TextMuted, fontSize = 9.sp, lineHeight = 13.sp)
                    Text("Zonas individuais (min/km)", color = Blue2, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    zones!!.all().forEach { InfoRow("${it.id} • ${it.name}", it.range.label()) }
                }
            }
        }
        Text("A estimativa de campo não substitui uma medição laboratorial. A experiência de corrida não muda o nível; volume e recuperação ajustam a dose do plano.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp, modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp))
        val latestWithoutReference = state.cooperAssessments.maxByOrNull { it.dateIso }?.let {
            it.ageAtTest == null || it.referenceSex !in setOf(RunnerFitnessAssessmentEngine.MALE, RunnerFitnessAssessmentEngine.FEMALE)
        } == true
        if (latestWithoutReference) {
            CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp), containerColor = Navy2) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("VINCULAR DADOS DO PERFIL", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("Este teste antigo não contém todos os dados demográficos. O aplicativo utilizará a data de nascimento ou idade e a referência fisiológica já cadastradas no perfil, sem pedir a idade novamente.", color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                    SecondaryButton(
                        "Aplicar dados do perfil ao teste",
                        enabled = state.parsedAgeYears() != null && state.referenceSex in setOf(RunnerFitnessAssessmentEngine.MALE, RunnerFitnessAssessmentEngine.FEMALE)
                    ) {
                        if (state.attachDemographicsToLatestTest()) state.navigateBack(Screen.PROFILE)
                    }
                }
            }
        }
        if (state.latestCooperMessage.isNotBlank()) NoteBlock(state.latestCooperMessage)
        PrimaryButton("Salvar teste e atualizar plano", enabled = testIsValid) {
            val saved = state.saveSelectedFieldTestAndReplan()
            if (saved && state.workouts.isNotEmpty()) state.navigateTo(Screen.PLAN)
        }
        SectionHeading("Histórico de testes")
        if (state.cooperAssessments.isEmpty()) {
            EmptyStateCard("Nenhum teste registrado", "Os resultados de Cooper e 3 km ficam guardados para comparação.", "Voltar ao perfil") { state.navigateBack(Screen.PROFILE) }
        } else {
            state.cooperAssessments.asReversed().forEach { record ->
                CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(record.dateIso, color = Blue2, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text(if (record.testMethod == "THREE_KM") "3 km em ${record.testDurationSeconds?.let(PhysiologicalProfileEngine::formatDuration) ?: "—"}" else "Cooper • ${formatKmUi(record.distanceKm)} km em 12 min", color = TextWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        val recordedReference = if (record.ageAtTest != null && record.referenceSex in setOf(RunnerFitnessAssessmentEngine.MALE, RunnerFitnessAssessmentEngine.FEMALE)) {
                            "${record.ageAtTest} anos • ${if (record.referenceSex == RunnerFitnessAssessmentEngine.MALE) "masculino" else "feminino"} • ${RunnerFitnessAssessmentEngine.assess(record.estimatedVo2Max, record.ageAtTest, record.referenceSex, "FIELD_ESTIMATE")?.level ?: "nível indisponível"}"
                        } else "idade/referência não registradas na data — nível não classificado"
                        Text("VO₂máx estimado ${String.format(Locale.US, "%.1f", record.estimatedVo2Max)} ml/kg/min • $recordedReference", color = TextMuted, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable private fun TrainingLibraryScreen(state: CoachState) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Biblioteca de treinos", true) { state.navigateBack(Screen.PROFILE) }
        CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), containerColor = Color(0xFF1B3048)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("COMO O TREINADOR USA A BIBLIOTECA", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text("Os estímulos são selecionados conforme objetivo, experiência, carga recente, recuperação e fase do ciclo. Nem todos aparecem no mesmo plano.", color = TextMuted, fontSize = 12.sp, lineHeight = 18.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                    StatusPill("Automático", Green)
                    StatusPill("Condicional", Blue2)
                    StatusPill("Não integrado", Yellow)
                }
            }
        }
        SectionHeading("Treinos da prescrição")
        TrainingTypeCatalog.all.forEach { item ->
            val status = TrainingTypeCatalog.prescriptionStatus(item.id)
            val statusColor = when {
                status.startsWith("Não integrado") -> Yellow
                status.startsWith("Condicional") || status == "Complementar" -> Blue2
                else -> Green
            }
            CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
                Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(item.title, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("Zona de referência: ${item.zone}", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                        }
                        StatusPill(status, statusColor)
                    }
                    Text(item.objective, color = TextWhite, fontSize = 12.sp, lineHeight = 17.sp)
                    Text(TrainingTypeCatalog.prescriptionDetail(item.id), color = statusColor, fontSize = 10.sp, lineHeight = 15.sp)
                    Text("Estrutura", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(item.structure, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                    Text("Quando entra: ${item.use}.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                }
            }
        }
        SectionHeading("Fortalecimento complementar")
        NoteBlock("As rotinas de força são sugestões complementares. Nesta versão, elas não são inseridas automaticamente no calendário de corrida.")
        StrengthTrainingCatalog.all.forEach { routine ->
            CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
                Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(routine.title, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        StatusPill(routine.duration, Blue2)
                    }
                    Text(routine.focus, color = Blue2, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Text(routine.exercises, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                    Text(routine.guidance, color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                }
            }
        }
    }
}

@Composable private fun BackupScreen(state: CoachState) {
    var pendingRestoreUri by remember { mutableStateOf<Uri?>(null) }
    var pendingHistoryImportUri by remember { mutableStateOf<Uri?>(null) }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) state.exportBackup(uri)
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) pendingRestoreUri = uri
    }
    val importHistoryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) pendingHistoryImportUri = uri
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Backup e restauração", true) { state.navigateBack(Screen.PROFILE) }
        CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp), containerColor = Color(0xFF1B3048)) {
            Column(Modifier.fillMaxWidth().padding(17.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("SEUS DADOS, SOB SEU CONTROLE", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text("Crie um arquivo de backup para guardar fora do celular. Ao trocar de aparelho, importe esse arquivo para recuperar suas informações.", color = TextMuted, fontSize = 12.sp, lineHeight = 18.sp)
            }
        }
        SectionHeading("O que será protegido")
        listOf(
            "Perfil, objetivo, nível e disponibilidade semanal",
            "Plano de treinamento, sessões, blocos e alternativas selecionadas",
            "Histórico de sessões concluídas e feedbacks",
            "Testes fisiológicos, calibrações e zonas de ritmo",
            "Competições, datas, prioridades e observações",
            "Estado e configurações persistidas do treinador"
        ).forEach { item ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 5.dp), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("✓", color = Green, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(item, color = TextWhite, fontSize = 12.sp, lineHeight = 17.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            PrimaryButton("Exportar backup completo", modifier = Modifier.fillMaxWidth(), horizontalPadding = 0) {
                exportLauncher.launch("AI-Running-Coach-backup-${LocalDate.now().format(DateTimeFormatter.ISO_DATE)}.json")
            }
            SecondaryButton("Restaurar backup completo", modifier = Modifier.fillMaxWidth(), horizontalPadding = 0) {
                importLauncher.launch(arrayOf("application/json", "text/json", "application/octet-stream"))
            }
            SecondaryButton("Importar treinos concluídos", modifier = Modifier.fillMaxWidth(), horizontalPadding = 0) {
                importHistoryLauncher.launch(arrayOf("application/json", "text/json", "application/octet-stream"))
            }
        }
        Text("A importação seletiva mescla apenas atividades concluídas e seus feedbacks; ignora duplicados e preserva o plano e o perfil atuais. A restauração completa substitui os dados locais.", color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp, modifier = Modifier.padding(horizontal = 18.dp, vertical = 6.dp))
        if (state.backupMessage.isNotBlank()) {
            NoteBlock(state.backupMessage)
        }
        NoteBlock("O arquivo JSON não é criptografado e contém dados pessoais e esportivos; guarde-o em local seguro. Antes da restauração completa, exporte um backup atual.")
    }
    if (pendingRestoreUri != null) {
        AlertDialog(
            onDismissRequest = { pendingRestoreUri = null },
            title = { Text("Restaurar backup?") },
            text = { Text("Os dados atuais do AI Running Coach serão substituídos pelo conteúdo do arquivo selecionado. Recomendamos exportar um backup atual antes de continuar.") },
            confirmButton = {
                TextButton(onClick = {
                    val uri = pendingRestoreUri
                    pendingRestoreUri = null
                    if (uri != null) state.restoreBackup(uri)
                }) { Text("Restaurar") }
            },
            dismissButton = { TextButton(onClick = { pendingRestoreUri = null }) { Text("Cancelar") } }
        )
    }
    if (state.pendingBackupRecalibration) {
        AlertDialog(
            onDismissRequest = { state.keepRestoredBackupPlan() },
            title = { Text("Recalibrar plano com o motor atual?") },
            text = { Text("O backup foi restaurado e seu plano antigo está preservado. Recomendamos atualizar zonas e faixas de ritmo, quilometragem-base, periodização, biblioteca, sessões e semanas futuras. Treinos concluídos, feedbacks, atividades importadas e datas reais serão mantidos. Motor do backup: ${state.importedBackupEngineVersion}; motor atual: $CURRENT_ENGINE_VERSION.") },
            confirmButton = {
                TextButton(onClick = { state.recalibrateRestoredBackup() }) { Text("Recalibrar plano") }
            },
            dismissButton = {
                TextButton(onClick = { state.keepRestoredBackupPlan() }) { Text("Manter plano importado") }
            }
        )
    }
    if (pendingHistoryImportUri != null) {
        AlertDialog(
            onDismissRequest = { pendingHistoryImportUri = null },
            title = { Text("Importar somente treinos concluídos?") },
            text = { Text("As atividades concluídas e os respectivos feedbacks serão mesclados com o histórico atual. Sessões futuras e duplicadas serão ignoradas. O plano, o perfil e as configurações atuais serão preservados.") },
            confirmButton = {
                TextButton(onClick = {
                    val uri = pendingHistoryImportUri
                    pendingHistoryImportUri = null
                    if (uri != null) state.importCompletedActivities(uri)
                }) { Text("Importar histórico") }
            },
            dismissButton = { TextButton(onClick = { pendingHistoryImportUri = null }) { Text("Cancelar") } }
        )
    }
}

@Composable private fun ProfileScreen(state: CoachState) {
    var editingProfile by remember { mutableStateOf(false) }
    val latestTest = state.cooperAssessments.maxByOrNull { it.dateIso }
    val loadSnapshot = state.trainingLoadSnapshot()
    val physiologyReference = when (state.referenceSex) {
        RunnerFitnessAssessmentEngine.MALE -> "Masculina"
        RunnerFitnessAssessmentEngine.FEMALE -> "Feminina"
        else -> "Não configurada"
    }
    val availableDays = state.availableTrainingDays.joinToString(" • ") { dayLabel(it) }.ifBlank { "Não configurada" }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Perfil do atleta")
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20344E)) {
            Column(Modifier.fillMaxWidth().padding(17.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Surface(shape = RoundedCornerShape(21.dp), color = Color(0xFF3C527A), modifier = Modifier.size(62.dp)) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(state.name.trim().firstOrNull()?.uppercase() ?: "A", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(state.name.ifBlank { "Atleta" }, color = TextWhite, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Text("AI Running Coach • Perfil esportivo", color = TextMuted, fontSize = 10.sp)
                        StatusPill(state.physiologicalLevelDisplay(), if (state.physiologicalLevelDisplay().startsWith("Aguardando")) Yellow else Green)
                    }
                    TextButton(onClick = {
                        if (editingProfile) {
                            state.refreshPhysiologicalLevelFromTest()
                            state.persist(synchronous = true)
                        }
                        editingProfile = !editingProfile
                    }) {
                        Text(if (editingProfile) "Salvar" else "✎ Editar", color = Blue2, fontWeight = FontWeight.SemiBold)
                    }
                }
                if (editingProfile) {
                    HorizontalDivider(color = Color(0x446F8DB8))
                    OutlinedTextField(
                        value = state.name,
                        onValueChange = { state.name = it.take(40); state.persist() },
                        label = { Text("Nome do atleta") },
                        modifier = Modifier.fillMaxWidth(), singleLine = true
                    )
                    OutlinedTextField(
                        value = state.birthDateText,
                        onValueChange = { value -> state.birthDateText = SmartInputMask.date(value); state.persist() },
                        label = { Text("Data de nascimento (dd/mm/aaaa)") },
                        supportingText = { Text("A idade será calculada automaticamente na data atual e na data de cada avaliação.") },
                        modifier = Modifier.fillMaxWidth(), singleLine = true
                    )
                    if (state.birthDateText.isBlank()) {
                        OutlinedTextField(
                            value = state.ageYearsText,
                            onValueChange = { state.ageYearsText = it.filter(Char::isDigit).take(3); state.refreshPhysiologicalLevelFromTest() },
                            label = { Text("Idade atual (anos), caso não informe nascimento") },
                            modifier = Modifier.fillMaxWidth(), singleLine = true
                        )
                    } else {
                        Text("Idade calculada: ${state.profileAgeLabel()}", color = Blue2, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                    CompactChoiceScreen(
                        "Referência fisiológica do perfil",
                        listOf("Masculino", "Feminino"),
                        when (state.referenceSex) {
                            RunnerFitnessAssessmentEngine.MALE -> "Masculino"
                            RunnerFitnessAssessmentEngine.FEMALE -> "Feminino"
                            else -> ""
                        }
                    ) { selected ->
                        state.referenceSex = if (selected == "Masculino") RunnerFitnessAssessmentEngine.MALE else RunnerFitnessAssessmentEngine.FEMALE
                        state.persist(synchronous = true)
                    }
                }
            }
        }

        SectionHeading("Resumo do atleta")
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            ProfileStatCard("Idade", state.profileAgeLabel(), "◷", Blue2, Modifier.weight(1f))
            ProfileStatCard("VO₂máx", latestTest?.let { String.format(Locale.US, "%.1f", it.estimatedVo2Max) } ?: "—", "↗", Green, Modifier.weight(1f), "ml/kg/min")
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            ProfileStatCard("Objetivo", goalLabel(state), "◎", Blue2, Modifier.weight(1f))
            ProfileStatCard("Treinos/semana", state.availableTrainingDays.size.toString(), "▦", Green, Modifier.weight(1f), "dias disponíveis")
        }

        SectionHeading("Dados pessoais")
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF1A2B40)) {
            Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                InfoRow("Nascimento", state.birthDateText.ifBlank { "Data não cadastrada; idade informada no perfil" })
                InfoRow("Referência fisiológica", physiologyReference)
            }
        }

        SectionHeading("Avaliação fisiológica")
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF1A2B40)) {
            Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                InfoRow("Nível fisiológico", state.physiologicalLevelDisplay())
                InfoRow("Última avaliação", latestTest?.let { RaceEventEngine.formatBrazilianDate(it.dateIso) } ?: "Ainda não realizada")
                InfoRow("Método", latestTest?.let { if (it.testMethod == "THREE_KM") "Teste de 3 km" else "Cooper de 12 minutos" } ?: "—")
                Text("A idade e a referência fisiológica são mantidas no cadastro do atleta. Cada avaliação utiliza uma fotografia calculada para sua data, sem solicitar os mesmos dados novamente.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
            }
        }

        SectionHeading("Objetivos e planejamento")
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF1A2B40)) {
            Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                InfoRow("Distância-alvo", goalLabel(state))
                InfoRow("Prioridade", TrainingGoalIntent.label(state.goalIntent))
                if (state.goalIntent == TrainingGoalIntent.TARGET_TIME) InfoRow("Tempo-alvo", state.goalTargetTimeText.ifBlank { "Não informado" })
                if (state.goalIntent == TrainingGoalIntent.PERSONAL_BEST) InfoRow("Recorde pessoal", state.personalBestTimeText.ifBlank { "Não informado" })
                InfoRow("Duração do ciclo", "${state.planWeeks} semanas")
                InfoRow("Data-alvo", state.targetDate)
            }
        }

        SectionHeading("Rotina e carga atual")
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF1A2B40)) {
            Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                InfoRow("Dias disponíveis", availableDays)
                InfoRow("Dia do longão", state.preferredLongRunDay?.let(::dayLabel) ?: "Não definido")
                InfoRow("Terreno habitual", RunningTerrain.label(state.terrainPreference))
                InfoRow("Experiência", state.runningExperienceDuration.ifBlank { "Não informada" })
                InfoRow("Base semanal usada", state.effectiveDisplayWeeklyKm()?.let { "${formatKmUi(it)} km/semana${if (state.weeklyVolumeText.isBlank()) " (objetivo)" else " (informada)"}" } ?: "Não definida")
                InfoRow("Maior sessão usada", state.effectiveDisplayLongestKm()?.let { "${formatKmUi(it)} km${if (state.longestRecent.isBlank()) " (objetivo)" else " (informada)"}" } ?: "Não definida")
                InfoRow("Volume registrado (28 dias)", "${formatKmUi(loadSnapshot.totalKmLast28Days)} km")
                InfoRow("Corridas com distância (28 dias)", loadSnapshot.recordedRunsLast28Days.toString())
            }
        }

        SectionHeading("Gerenciar perfil")
        val availabilitySummary = if (state.availableTrainingDays.isEmpty()) "Definir dias de corrida e preferência do longão" else "${state.availableTrainingDays.size} dias disponíveis • Longão: ${state.preferredLongRunDay?.let(::dayLabel) ?: "não definido"}"
        ProfileAction("Disponibilidade semanal", availabilitySummary, "▦") {
            state.scheduleActionMessage = ""
            state.navigateTo(Screen.AVAILABILITY)
        }
        ProfileAction("Revisar cadastro do atleta", "Dados pessoais, objetivo, rotina e carga", "✎") { state.onboardingStep = 0; state.persist() }
        ProfileAction("Teste fisiológico", "Cooper 12 min ou corrida de 3 km", "◷") { state.openFieldTestEditor() }
        ProfileAction("Zonas de ritmo Z1–Z5", "Consultar faixas individuais em mm:ss min/km", "⌁") { state.navigateTo(Screen.PACE_ZONES) }
        ProfileAction("Competições", "Cadastrar provas e ajustar a preparação", "🏁") { state.navigateTo(Screen.RACES) }
        ProfileAction("Biblioteca de treinos", "Consultar os estímulos reconhecidos pelo motor", "▤") { state.navigateTo(Screen.TRAINING_LIBRARY) }
        ProfileAction("Consultar sessões concluídas", "Ver atividades, datas reais e análise de execução", "◷") { state.navigateTo(Screen.HISTORY) }
        ProfileAction("Backup e restauração", "Exportar ou recuperar dados e histórico", "⇄") { state.backupMessage = ""; state.navigateTo(Screen.BACKUP) }
        CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("Privacidade e funcionamento", color = Blue2, fontWeight = FontWeight.Bold)
                Text("Perfil, plano e feedbacks ficam armazenados localmente. O Pace Coach continua responsável pela execução, GPS, áudio e registro das corridas.", color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
            }
        }
    }
}

@Composable private fun ProfileStatCard(label: String, value: String, icon: String, accent: Color, modifier: Modifier = Modifier, subtitle: String = "") {
    CardSurface(modifier.padding(vertical = 4.dp), containerColor = CardBlue) {
        Column(Modifier.fillMaxWidth().heightIn(min = 88.dp).padding(horizontal = 10.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                Surface(shape = RoundedCornerShape(8.dp), color = accent.copy(alpha = 0.14f), modifier = Modifier.size(27.dp)) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(icon, color = accent, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Text(label, color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, lineHeight = 12.sp)
            }
            Text(value, color = TextWhite, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 2, lineHeight = 19.sp)
            if (subtitle.isNotBlank()) Text(
                subtitle, color = TextMuted, fontSize = 9.sp, maxLines = 2, lineHeight = 11.sp
            )
        }
    }
}

@Composable private fun AvailabilityScreen(state: CoachState) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Minha disponibilidade semanal", true) { state.navigateBack(Screen.PROFILE) }
        Text(
            "Escolha os dias em que você consegue correr habitualmente. O treinador distribuirá as sessões somente nesses dias e respeitará sua preferência para o longão. As alterações são salvas automaticamente.",
            color = TextMuted,
            fontSize = 12.sp,
            lineHeight = 18.sp,
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 2.dp)
        )
        TrainingAvailabilityEditor(state, showLongRunPreference = true)
        if (state.needsEngineRefresh) {
            NoteBlock("Sua disponibilidade mudou. Recalcule o plano para redistribuir os treinos sem alterar sessões concluídas.")
            PrimaryButton("Recalcular plano com minha disponibilidade") { state.createPlan() }
        }
    }
}

@Composable private fun ProfileAction(title: String, description: String, icon: String, onClick: () -> Unit) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp).clickable(onClick = onClick)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Surface(shape = RoundedCornerShape(13.dp), color = Color(0xFF293E5C), modifier = Modifier.size(44.dp)) { Box(contentAlignment = Alignment.Center) { Text(icon, color = Blue2, fontSize = 22.sp, fontWeight = FontWeight.SemiBold) } }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text(description, color = TextMuted, fontSize = 10.sp)
            }
            Text("›", color = TextMuted, fontSize = 23.sp)
        }
    }
}

@Composable private fun ExportScreen(state: CoachState) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val workout = state.selectedWorkout()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Compartilhar com Pace Coach", true) { state.navigateBack(Screen.WORKOUT) }
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20344E)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("PRESCRIÇÃO ESTRUTURADA", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                Text(workout?.title ?: "Nenhuma sessão selecionada", color = TextWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                if (workout != null) Text("${workout.date} • ~${formatKmUi(workout.distanceKm)} km estimados • ${workout.segments.size} blocos", color = TextMuted, fontSize = 11.sp)
                Text("O AI Running Coach planeja. O Pace Coach executa e registra o treino.", color = TextMuted, fontSize = 11.sp)
            }
        }
        SectionHeading("O que será compartilhado")
        val exportName = workout?.let { WorkoutExportNaming.name(it, state.workouts) }
        StepExport("01", "Nome do arquivo", exportName?.let { "$it.json" } ?: "Semana, número do treino, nome e data")
        StepExport("02", "Blocos de treino", workout?.let { "${it.segments.size} blocos • Aquecimento, estímulos, recuperação e desaquecimento" } ?: "Estrutura da sessão")
        StepExport("03", "Alvo de execução", workout?.let {
            val modes = it.segments.map { segment -> segment.targetMode }.distinct()
            val modeLabel = when (modes.size) { 2 -> "Tempo + distância"; 1 -> if (modes.first() == "TIME") "Tempo" else "Distância"; else -> "Sem blocos" }
            "$modeLabel • Ritmo ${it.primaryPaceRange() ?: "não calibrado"} min/km • RPE ${it.rpeRange} como apoio"
        } ?: "Etapas por tempo ou distância, com ritmo em min/km quando houver referência")
        NoteBlock("A transferência anexa um arquivo .json no formato nativo UserWorkoutJson do Pace Coach. Etapas são exportadas por tempo (ms) ou distância (m), com ritmo convertido para a unidade Garmin e repetições preservadas em grupos.")
        PrimaryButton("Compartilhar arquivo JSON", enabled = workout != null) {
            val selected = workout
            if (selected != null) {
                val prescription = selected.toPrescribedWorkout()
                val goalDistanceKm = TrainingGoalCatalog.distanceForLabel(
                    state.goal, state.customGoalKm.trim().replace(",", ".").toDoubleOrNull()
                ) ?: 5.0
                val friendlyName = WorkoutExportNaming.name(selected, state.workouts)
                val json = PaceCoachExporter.workoutToJson(prescription, state.goal, goalDistanceKm, friendlyName)
                val jsonFile = PaceCoachJsonAttachment.create(context.cacheDir, friendlyName, json)
                val contentUri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    jsonFile
                )
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    type = PaceCoachJsonAttachment.MIME_TYPE
                    putExtra(Intent.EXTRA_SUBJECT, "Prescrição — ${selected.title}")
                    putExtra(Intent.EXTRA_STREAM, contentUri)
                    clipData = ClipData.newUri(context.contentResolver, jsonFile.name, contentUri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(sendIntent, "Enviar treino compatível com o Pace Coach"))
            }
        }
    }
}

private fun Workout.primaryPaceRange(): String? =
    WorkoutPaceSummaryEngine.plannedAveragePaceSecondsPerKm(segments)?.let { PaceRange.format(it) }

private fun Workout.toPrescribedWorkout(): PrescribedWorkout = PrescribedWorkout(
    day = date.substringBefore(","), date = date, scheduledDateIso = scheduledDateIso, title = title, type = type, objective = objective,
    stimulus = stimulus, sessionId = sessionId, distanceKm = distanceKm, durationMin = durationMin,
    intensity = intensity, paceMode = paceMode, rpeRange = rpeRange, detail = detail,
    rationale = rationale, week = week, phase = phase, segments = segments,
    paceCalibrationSnapshot = paceCalibrationSnapshot, experienceMonths = experienceMonths
)

@Composable private fun BottomNav(state: CoachState) {
    Row(
        Modifier.fillMaxWidth().background(Color(0xFF0D1726)).padding(horizontal = 9.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        DockItem(Modifier.weight(1f), "⌂", "Início", state.selectedScreen == Screen.DASHBOARD) { state.navigateTo(Screen.DASHBOARD) }
        DockItem(Modifier.weight(1f), "▦", "Agenda", state.selectedScreen == Screen.CALENDAR) { state.navigateTo(Screen.CALENDAR) }
        DockItem(Modifier.weight(1f), "≋", "Plano", state.selectedScreen == Screen.PLAN) { state.navigateTo(Screen.PLAN) }
        DockItem(Modifier.weight(1f), "↗", "Evolução", state.selectedScreen == Screen.EVOLUTION) { state.navigateTo(Screen.EVOLUTION) }
        DockItem(Modifier.weight(1f), "•••", "Mais", state.selectedScreen == Screen.PROFILE || state.selectedScreen == Screen.AVAILABILITY || state.selectedScreen == Screen.HISTORY || state.selectedScreen == Screen.RACES || state.selectedScreen == Screen.RACE_STRATEGY) { state.navigateTo(Screen.PROFILE) }
    }
}

@Composable private fun DockItem(modifier: Modifier, icon: String, label: String, selected: Boolean, onClick: () -> Unit) {
    Column(modifier.clickable(onClick = onClick).padding(vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Surface(shape = RoundedCornerShape(15.dp), color = if (selected) Color(0xFF2B4168) else Color.Transparent) {
            Box(Modifier.widthIn(min = 52.dp).height(32.dp).padding(horizontal = 13.dp), contentAlignment = Alignment.Center) {
                Text(icon, color = if (selected) Color.White else TextMuted, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            }
        }
        Text(label, color = if (selected) Blue2 else TextMuted, fontSize = 9.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium)
    }
}

@Composable private fun SectionHeading(title: String, action: String? = null, onAction: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 21.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = TextWhite, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (action != null) Text(
            action, color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold,
            maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = (if (onAction != null) Modifier.clickable(onClick = onAction) else Modifier).widthIn(max = 118.dp)
        )
    }
}

@Composable private fun CardSurface(modifier: Modifier = Modifier, containerColor: Color = CardBlue, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier = modifier, shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = containerColor), content = content)
}

@Composable private fun StatusPill(text: String, color: Color) {
    Surface(shape = RoundedCornerShape(50), color = color.copy(alpha = 0.13f), border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.35f))) {
        Text(
            text, color = color, fontSize = 9.sp, lineHeight = 11.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp),
            maxLines = 2, softWrap = true, textAlign = TextAlign.Center
        )
    }
}

@Composable private fun ProgressTrack(progress: Float, color: Color = Blue2, trackColor: Color = Color(0xFF2A3D55)) {
    Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)).background(trackColor)) {
        if (progress > 0f) Box(Modifier.fillMaxWidth(progress.coerceIn(0f, 1f)).fillMaxHeight().clip(RoundedCornerShape(50)).background(color))
    }
}

@Composable private fun SevenDayBreakdown(sessions: List<Workout>, races: List<RaceEvent> = emptyList()) {
    val labels = listOf("SEG", "TER", "QUA", "QUI", "SEX", "SÁB", "DOM")
    val values = MutableList(7) { 0.0 }
    val raceDays = mutableSetOf<Int>()
    sessions.forEach { workout ->
        val dayIndex = runCatching { LocalDate.parse(workout.scheduledDateIso).dayOfWeek.value - 1 }.getOrNull()
        if (dayIndex != null && dayIndex in 0..6) values[dayIndex] = values[dayIndex] + workout.distanceKm
    }
    races.filter { it.status != "CANCELLED" }.forEach { race ->
        val dayIndex = race.dateOrNull()?.dayOfWeek?.value?.minus(1)
        if (dayIndex != null && dayIndex in 0..6) {
            values[dayIndex] = values[dayIndex] + race.distanceKm
            raceDays += dayIndex
        }
    }
    val maxValue = (values.maxOrNull() ?: 0.0).coerceAtLeast(1.0)
    Row(Modifier.fillMaxWidth().height(126.dp), horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.Bottom) {
        values.forEachIndexed { index, value ->
            Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                if (value > 0.0) Text(formatKmUi(value), color = Blue2, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(5.dp))
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.BottomCenter) {
                    Box(Modifier.fillMaxWidth(0.62f).height(if (value > 0.0) (value / maxValue * 76.0).coerceAtLeast(10.0).dp else 4.dp).clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp)).background(
                        if (index in raceDays) Brush.verticalGradient(listOf(Color(0xFFD1B7FF), Color(0xFF8C6FC4)))
                        else if (value > 0.0) Brush.verticalGradient(listOf(Color(0xFFB4C8FF), Color(0xFF5E81C3)))
                        else Brush.verticalGradient(listOf(Color(0xFF34445A), Color(0xFF34445A)))
                    ))
                }
                Spacer(Modifier.height(7.dp))
                Text(labels[index], color = TextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable private fun NextWorkoutCard(workout: Workout, onClick: () -> Unit) {
    CardSurface(Modifier.padding(horizontal = 16.dp).clickable(onClick = onClick), containerColor = Color(0xFF1B3048)) {
        Row(Modifier.fillMaxWidth().padding(17.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(13.dp)) {
            SessionGlyph(workout, 48)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(workout.date.uppercase(), color = Blue2, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text(workout.title, color = TextWhite, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text("~${formatKmUi(workout.distanceKm)} km  •  Tempo estimado: ~${workout.durationMin} min  •  Ritmo ${workout.primaryPaceRange() ?: "a calibrar"}", color = TextMuted, fontSize = 10.sp)
            }
            Text("›", color = Blue2, fontSize = 27.sp)
        }
    }
}

@Composable private fun SessionGlyph(workout: Workout, size: Int) {
    val category = calendarCategory(workout)
    val done = workout.done
    val color = if (done) Color(0xFF1D4A43) else calendarCategoryColor(category).copy(alpha = 0.25f)
    val glyph = when (category) {
        "REGENERATIVO" -> "☾"
        "AERÓBIO" -> "◉"
        "PROGRESSIVO" -> "↗"
        "QUALIDADE", "LIMIAR" -> "⌁"
        "INTERVALADO" -> "⚡"
        "LONGÃO" -> "➚"
        else -> "•"
    }
    Surface(shape = RoundedCornerShape(16.dp), color = color, modifier = Modifier.size(size.dp)) {
        Box(contentAlignment = Alignment.Center) {
            Text(if (done) "✓" else glyph, color = if (done) Green else calendarCategoryColor(category), fontSize = if (size > 40) 19.sp else 15.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable private fun PlanStat(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, color = Color(0xFFD0D9EA), fontSize = 9.sp)
        Text(value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable private fun EmptyStateCard(title: String, description: String, action: String, onClick: () -> Unit) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
        Column(Modifier.fillMaxWidth().padding(19.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("◌", color = Blue2, fontSize = 26.sp)
            Text(title, color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(description, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
            Text(action + "  ›", color = Blue2, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable(onClick = onClick).padding(top = 3.dp))
        }
    }
}

@Composable private fun NoteBlock(text: String) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), containerColor = Color(0xFF1B2D42)) {
        Row(Modifier.padding(15.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Top) {
            Text("ⓘ", color = Blue2, fontSize = 17.sp)
            Text(text, color = Color(0xFFB9C8DD), fontSize = 11.sp, lineHeight = 17.sp, modifier = Modifier.weight(1f))
        }
    }
}

@Composable private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = TextMuted, fontSize = 11.sp, modifier = Modifier.weight(0.45f))
        Text(value, color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End, modifier = Modifier.weight(0.55f))
    }
}

@Composable private fun ListButton(text: String, onClick: () -> Unit) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp).clickable(onClick = onClick)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text(text, color = TextWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text("›", color = Blue2, fontSize = 22.sp)
        }
    }
}

@Composable private fun StepExport(n: String, title: String, desc: String) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(n, color = Blue2, fontSize = 24.sp, fontWeight = FontWeight.Black)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(desc, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
            }
        }
    }
}

@Composable private fun SecondaryButton(
    text: String,
    modifier: Modifier = Modifier,
    horizontalPadding: Int = 16,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.fillMaxWidth().padding(horizontal = horizontalPadding.dp).height(54.dp),
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = Blue2)
    ) {
        Text(text, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable private fun PrimaryButton(
    text: String,
    enabled: Boolean = true,
    modifier: Modifier = Modifier,
    horizontalPadding: Int = 16,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.fillMaxWidth().padding(horizontal = horizontalPadding.dp).height(54.dp),
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Blue, contentColor = Color(0xFF101827))
    ) {
        Text(text, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable private fun LazyColumnLike(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 16.dp), content = content)
}

private fun goalLabel(state: CoachState): String = when {
    state.goal == "Outro objetivo" -> "${state.customGoalKm} km"
    state.goal.isBlank() -> "Objetivo não definido"
    else -> state.goal
}

private fun formatKmUi(value: Double): String = String.format(Locale("pt", "BR"), "%.1f", value).replace(",0", "")
private fun recoveryLabel(status: String?): String = when (status) {
    "GOOD" -> "Boa"
    "MODERATE" -> "Moderada"
    "POOR" -> "Baixa"
    else -> "Não avaliada"
}
private fun safetyLabel(status: String?): String = when (status) {
    "RED" -> "Dor relatada"
    "YELLOW" -> "Atenção à fadiga"
    "GREEN" -> "Sem alerta"
    else -> "Não avaliada"
}
private fun raceStatusLabel(status: String): String = when (status) {
    "COMPLETED" -> "Realizada"
    "CANCELLED" -> "Cancelada"
    else -> "Programada"
}
private fun phaseLabel(phase: String): String = when (phase) {
    "BASE" -> "Base aeróbia"
    "DEVELOPMENT" -> "Desenvolvimento"
    "SPECIFIC" -> "Preparação específica"
    "PREPARATION" -> "Base preparatória para o objetivo"
    "ADAPTATION" -> "Adaptação"
    "CONSOLIDATION" -> "Consolidação"
    "PROGRESSION" -> "Progressão"
    "RECOVERY" -> "Regenerativa"
    "TAPER" -> "Redução pré-prova principal"
    "POST_RACE_RECOVERY" -> "Recuperação pós-prova principal"
    else -> "Base aeróbia"
}
private fun workoutTypeLabel(type: String): String = when (type) {
    "Longo" -> "Longão"
    "Qualidade" -> "Treino de qualidade"
    "Aeróbio" -> "Rodagem"
    "Recuperação" -> "Rodagem regenerativa"
    else -> type
}
private fun stimulusLabel(stimulus: String): String = when (stimulus) {
    "AEROBIC_BASE" -> "Desenvolvimento da base aeróbia"
    "AEROBIC_BASE_AND_CONTROLLED_QUALITY" -> "Base aeróbia com qualidade controlada"
    "PREPARATORY_BASE_BUILD" -> "Construção da base para o objetivo"
    "LOW_INTENSITY_AEROBIC" -> "Recuperação e baixa intensidade"
    "NONE" -> "Prescrição suspensa por segurança"
    else -> "Desenvolvimento de resistência"
}

