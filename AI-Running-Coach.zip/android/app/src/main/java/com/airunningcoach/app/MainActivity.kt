package com.airunningcoach.app

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.provider.OpenableColumns
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.YearMonth
import java.time.DayOfWeek
import java.time.temporal.TemporalAdjusters
import java.time.format.DateTimeFormatter
import java.time.Instant
import java.time.ZoneId
import java.util.Locale
import kotlin.math.roundToInt

private val Navy = Color(0xFF0A1220)
private val Navy2 = Color(0xFF111D2D)
private val CardBlue = Color(0xFF1A2B40)
private val Blue = Color(0xFF8EAEF5)
private val Blue2 = Color(0xFFC1D0FF)
private val TextWhite = Color(0xFFF4F6FC)
private val TextMuted = Color(0xFFA3B0C3)
private val Green = Color(0xFF7AD6B7)
private val Yellow = Color(0xFFF4C77B)
private const val CURRENT_ENGINE_VERSION = 53

private enum class Screen { DASHBOARD, CALENDAR, WORKOUT, STRUCTURE, PLAN, EVOLUTION, FEEDBACK, HISTORY, PROFILE, AVAILABILITY, EXPORT, PACE_ZONES, COOPER_TEST, TRAINING_LIBRARY, RACES, BACKUP }

internal data class Workout(
    val date: String,
    val scheduledDateIso: String = "",
    val title: String,
    val detail: String,
    val type: String,
    val objective: String,
    val stimulus: String,
    val distanceKm: Double,
    val done: Boolean = false,
    val sessionId: String = "",
    val durationMin: Int = 0,
    val intensity: String = "LOW",
    val paceMode: String = "PACE_NOT_CALIBRATED",
    val rpeRange: String = "3-4",
    val rationale: String = "",
    val week: Int = 1,
    val phase: String = "BASE",
    val segments: List<WorkoutSegment> = emptyList(),
    val paceCalibrationSnapshot: PaceCalibrationSnapshot? = null,
    val manuallyRescheduled: Boolean = false,
    val originalScheduledDateIso: String = "",
    val selectedOption: String = "PRIMARY",
    val isOptionalExtra: Boolean = false
)

private data class FeedbackRecord(
    val sessionId: String,
    val effort: String,
    val feeling: String,
    val notes: String,
    val painPresent: Boolean = false,
    val actualDistanceKm: Double? = null,
    val savedAt: Long = System.currentTimeMillis(),
    val actualDuration: String? = null,
    val actualPaceMinKm: String? = null,
    val talkTestPaceMmSs: String? = null,
    /** Date/type of the completed workout; legacy records fall back to feedback save time/current workout. */
    val workoutDateIso: String = "",
    val workoutType: String = "",
    val workoutTitle: String = "",
    val activitySourceFormat: String = "",
    val activityFingerprint: String = "",
    val activityStartedAtIso: String = "",
    /** Actual local activity date; separate from the scheduled workout date. */
    val realizedDateIso: String = "",
    /** Explicitly selected terrain for this completed activity. */
    val terrain: String = RunningTerrain.MIXED,
    /** Optional link to a race event; linked results can support physiological estimates. */
    val raceEventId: String = "",
    val recordedPaceSegments: List<ActivityPaceSegment> = emptyList(),
    /** Frozen zone allocation when known; prevents historic runs being reclassified after calibration. */
    val measuredZoneTimeSeconds: Map<String, Int> = emptyMap(),
    val elevationGainMeters: Double? = null,
    val averageHeartRateBpm: Int? = null,
    val maxHeartRateBpm: Int? = null,
    val averageCadenceSpm: Int? = null,
    val maxCadenceSpm: Int? = null,
    val routePointCount: Int = 0,
    val splitPacesMmSs: List<String> = emptyList(),
    val encodedRoute: String = ""
)

private class CoachState(private val context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("ai_running_coach", Context.MODE_PRIVATE)
    private val navigationHistory = mutableListOf<Screen>()

    fun navigateTo(screen: Screen) {
        if (screen != selectedScreen) {
            navigationHistory.add(selectedScreen)
            selectedScreen = screen
            persist()
        }
    }

    fun canNavigateBack(): Boolean = navigationHistory.isNotEmpty() || selectedScreen != Screen.DASHBOARD

    fun resetNavigation(screen: Screen) {
        navigationHistory.clear()
        selectedScreen = screen
    }

    fun navigateBack(fallback: Screen? = fallbackScreenFor(selectedScreen)) {
        val destination = if (navigationHistory.isNotEmpty()) navigationHistory.removeAt(navigationHistory.lastIndex) else fallback
        if (destination != null && destination != selectedScreen) {
            selectedScreen = destination
            persist()
        }
    }

    private fun fallbackScreenFor(screen: Screen): Screen? = when (screen) {
        Screen.DASHBOARD -> null
        Screen.CALENDAR, Screen.PLAN, Screen.EVOLUTION, Screen.PROFILE -> Screen.DASHBOARD
        Screen.WORKOUT -> Screen.CALENDAR
        Screen.STRUCTURE, Screen.FEEDBACK, Screen.EXPORT -> Screen.WORKOUT
        Screen.AVAILABILITY, Screen.HISTORY, Screen.RACES, Screen.PACE_ZONES,
        Screen.COOPER_TEST, Screen.TRAINING_LIBRARY, Screen.BACKUP -> Screen.PROFILE
    }

    var name by mutableStateOf("")
    var goal by mutableStateOf("")
    var goalIntent by mutableStateOf(TrainingGoalIntent.COMPLETE)
    var goalTargetTimeText by mutableStateOf("")
    var terrainPreference by mutableStateOf(RunningTerrain.ROAD)
    var customGoalKm by mutableStateOf("")
    var level by mutableStateOf("")
    var frequency by mutableStateOf(0)
    var availableTrainingDays by mutableStateOf<List<DayOfWeek>>(emptyList())
    var preferredLongRunDay by mutableStateOf<DayOfWeek?>(null)
    var scheduleActionMessage by mutableStateOf("")
    var targetDate by mutableStateOf("Sem prova principal")
    var raceEvents by mutableStateOf(listOf<RaceEvent>())
    var planStartDateIso by mutableStateOf("")
    var racePlanNote by mutableStateOf("")
    var racePlanWarnings by mutableStateOf(listOf<String>())
    var raceFormError by mutableStateOf("")
    var raceNameDraft by mutableStateOf("")
    var raceDistanceDraft by mutableStateOf("")
    var raceDateDraft by mutableStateOf(LocalDate.now().plusMonths(2).format(DateTimeFormatter.ofPattern("dd/MM/uuuu")))
    var racePriorityDraft by mutableStateOf("A")
    var raceTargetTimeDraft by mutableStateOf("")
    var raceLocationDraft by mutableStateOf("")
    var raceNotesDraft by mutableStateOf("")
    var editingRaceId by mutableStateOf("")
    var volume by mutableStateOf("") // legado V18; mantido apenas para migração local
    var weeklyVolumeText by mutableStateOf("")
    var longestRecent by mutableStateOf("")
    /** Experience duration supplements (but never overrides) the self-declared level. */
    var runningExperienceDuration by mutableStateOf("")
    var ageYearsText by mutableStateOf("")
    var referenceSex by mutableStateOf("")
    var fitnessTestMethod by mutableStateOf("NONE") // NONE, COOPER_12_MIN, THREE_KM
    var threeKmTimeText by mutableStateOf("")
    /** Number of distinct weeks with at least one run in the previous four weeks. Kept for history, no longer asked in onboarding. */
    var activeWeeksLast4 by mutableStateOf(-1)
    var cooperEnabled by mutableStateOf(false)
    var cooperDistanceText by mutableStateOf("")
    var cooperAssessmentDateText by mutableStateOf(LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/uuuu")))
    var cooperAssessments by mutableStateOf(listOf<CooperAssessmentRecord>())
    var latestCooperMessage by mutableStateOf("")
    var onboardingStep by mutableStateOf(-1)
    var selectedScreen by mutableStateOf(Screen.DASHBOARD)
    var selectedWorkoutIndex by mutableStateOf(0)
    var feedbackSaved by mutableStateOf(false)
    var workouts by mutableStateOf(listOf<Workout>())
    var planWeeks by mutableStateOf(8)
    var motorState by mutableStateOf<MotorState?>(null)
    var motorDecision by mutableStateOf<MotorDecision?>(null)
    var motorExplanation by mutableStateOf("")
    var motorError by mutableStateOf("")
    var needsEngineRefresh by mutableStateOf(false)
    var needsPacePlanRefresh by mutableStateOf(false)
    var feedbackRecords by mutableStateOf(listOf<FeedbackRecord>())
    /** Persisted zone boundaries let evidence-based recalibration move by at most 15 s per update. */
    var lastZoneBoundarySnapshot by mutableStateOf<List<Int>?>(null)
    var latestFeedbackHeadline by mutableStateOf("")
    var latestFeedbackAdvice by mutableStateOf("")
    var backupMessage by mutableStateOf("")
    var restDayRecommendation by mutableStateOf<RestDayRecommendation?>(null)

    init { load() }

    fun parsedCooperAssessmentDate(): LocalDate? = CooperAssessmentEngine.parseAssessmentDate(cooperAssessmentDateText)

    fun parsedAgeYears(): Int? = ageYearsText.toIntOrNull()?.takeIf { it in 18..100 }

    fun selectedFieldTestZones(): TrainingPaceZones? {
        return when (fitnessTestMethod) {
            "COOPER_12_MIN" -> calculateZonesForCooper(cooperDistanceText.trim().replace(",", ".").toDoubleOrNull())
            "THREE_KM" -> {
                val age = parsedAgeYears() ?: return null
                if (age !in 18..39) return null
                val time = RunnerFitnessAssessmentEngine.parseDurationSeconds(threeKmTimeText) ?: return null
                val zones = PaceCalculator.calculateThreeKm(time, referenceSex) ?: return null
                val date = parsedCooperAssessmentDate()?.toString() ?: LocalDate.now().toString()
                val previous = cooperAssessments.lastOrNull { it.testMethod == "THREE_KM" && it.dateIso != date }
                    ?.let { record -> record.testDurationSeconds?.let { PaceCalculator.calculateThreeKm(it, record.referenceSex) } }
                PaceCalculator.limitCalibrationChange(zones, previous, 15)
            }
            else -> null
        }
    }

    fun physiologicalLevelFromSelectedTest(): String? {
        val zones = selectedFieldTestZones() ?: return null
        val age = parsedAgeYears() ?: return null
        return RunnerFitnessAssessmentEngine.assess(zones.estimatedVo2Max, age, referenceSex, "FIELD_ESTIMATE")?.level
    }

    fun refreshPhysiologicalLevelFromTest() {
        val assessedLevel = physiologicalLevelFromSelectedTest()
        if (assessedLevel != null) {
            level = assessedLevel
            val options = TrainingGoalCatalog.labelsForLevel(level)
            if (goal.isNotBlank() && goal !in options) goal = ""
        } else if (fitnessTestMethod == "NONE") {
            level = "Iniciante" // conservative internal guardrail only; displayed as awaiting a test
            if (goal.isNotBlank() && goal !in TrainingGoalCatalog.labelsForLevel(level)) goal = ""
        }
        persist()
    }

    fun physiologicalLevelDisplay(): String {
        val latest = cooperAssessments.maxByOrNull { it.dateIso }
        if (latest == null) return "Aguardando teste"
        val age = latest.ageAtTest ?: return "Aguardando idade da avaliação"
        val sex = latest.referenceSex
        if (sex !in setOf(RunnerFitnessAssessmentEngine.MALE, RunnerFitnessAssessmentEngine.FEMALE)) return "Aguardando referência fisiológica"
        return RunnerFitnessAssessmentEngine.assess(
            latest.estimatedVo2Max, age, sex, "FIELD_ESTIMATE"
        )?.level ?: "Aguardando teste"
    }

    fun defaultBeginnerWeeklyKm(): Double = (frequency.coerceIn(2, 6) * 2.0).coerceIn(4.0, 8.0)
    fun defaultBeginnerLongestKm(): Double = 2.0

    fun experienceMonths(): Int = when (runningExperienceDuration) {
        "Menos de 6 meses" -> 3
        "6–12 meses" -> 9
        "1–3 anos" -> 24
        "3–5 anos" -> 48
        "Mais de 5 anos" -> 72
        else -> -1
    }

    fun runnerReadinessSnapshot(
        weeklyOverride: Double? = null,
        longestOverride: Double? = null,
        weeksOverride: Int? = null
    ): RunnerReadinessSnapshot? {
        val goalKm = TrainingGoalCatalog.distanceForLabel(
            goal,
            customGoalKm.trim().replace(",", ".").toDoubleOrNull()
        ) ?: return null
        val safeLevel = RunnerFitnessAssessmentEngine.normalizeLevel(level).takeIf { level.isNotBlank() } ?: return null
        return runCatching {
            RunnerReadinessEngine.evaluate(
                RunnerReadinessInput(
                    goalKm = goalKm,
                    goalCategory = TrainingGoalCatalog.categoryForLabel(goal),
                    declaredLevel = safeLevel,
                    experienceMonths = experienceMonths(),
                    selectedFrequency = frequency.takeIf { it in 2..6 } ?: availableTrainingDays.size.takeIf { it in 2..6 } ?: 3,
                    weeklyVolumeKm = weeklyOverride ?: weeklyVolumeText.trim().replace(",", ".").toDoubleOrNull() ?: 0.0,
                    longestRecentKm = longestOverride ?: longestRecent.trim().replace(",", ".").toDoubleOrNull() ?: 0.0,
                    activeWeeksLast4 = weeksOverride ?: activeWeeksLast4,
                    goalIntent = if (TrainingGoalCatalog.categoryForLabel(goal) == "HEALTH") TrainingGoalIntent.HEALTH else goalIntent,
                    targetTimeSeconds = goalTargetTimeText.takeIf { goalIntent == TrainingGoalIntent.TARGET_TIME }?.let(PhysiologicalProfileEngine::parseTargetTime),
                    terrainPreference = terrainPreference
                )
            )
        }.getOrNull()
    }

    fun setTrainingDay(day: DayOfWeek, selected: Boolean) {
        val next = if (selected) (availableTrainingDays + day).distinct().sortedBy { it.value }
                   else availableTrainingDays.filterNot { it == day }
        if (next.size > 6 || (workouts.isNotEmpty() && next.size < 2)) {
            scheduleActionMessage = "Selecione entre 2 e 6 dias disponíveis. Para alterar um plano existente, mantenha pelo menos dois dias selecionados."
            return
        }
        availableTrainingDays = next
        frequency = next.size
        preferredLongRunDay = TrainingScheduleEngine.resolvePreferredLongRunDay(preferredLongRunDay, next)
        scheduleActionMessage = "Disponibilidade salva: ${next.size} dias por semana."
        if (workouts.isNotEmpty()) {
            needsEngineRefresh = true
            racePlanNote = "A disponibilidade semanal mudou. Recalcule o plano para redistribuir as sessões."
        }
        persist()
    }

    fun setLongRunDay(day: DayOfWeek) {
        if (day !in availableTrainingDays) return
        preferredLongRunDay = day
        scheduleActionMessage = "Dia preferido do longão atualizado."
        if (workouts.isNotEmpty()) {
            needsEngineRefresh = true
            racePlanNote = "O dia preferido do longão mudou. Recalcule o plano para aplicar a preferência."
        }
        persist()
    }

    fun availableRescheduleDates(workout: Workout): List<LocalDate> {
        val current = runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull() ?: return emptyList()
        val monday = current.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val slots = workouts.mapNotNull { item ->
            runCatching { LocalDate.parse(item.scheduledDateIso) }.getOrNull()?.let { date ->
                TrainingScheduleEngine.SessionSlot(item.sessionId, date, item.type, item.done)
            }
        }
        val raceDates = raceEvents.filter { it.status != "CANCELLED" }.mapNotNull { it.dateOrNull() }.toSet()
        return (0L..6L).map { monday.plusDays(it) }.filter { candidate ->
            TrainingScheduleEngine.validateMove(
                source = TrainingScheduleEngine.SessionSlot(workout.sessionId, current, workout.type, workout.done),
                targetDate = candidate, sessions = slots, raceDates = raceDates
            ).allowed
        }
    }

    fun rescheduleWorkout(workout: Workout, newDate: LocalDate): Boolean {
        val current = runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull()
        if (current == null) {
            scheduleActionMessage = "A data original desta sessão não é válida."
            return false
        }
        val slots = workouts.mapNotNull { item ->
            runCatching { LocalDate.parse(item.scheduledDateIso) }.getOrNull()?.let { date ->
                TrainingScheduleEngine.SessionSlot(item.sessionId, date, item.type, item.done)
            }
        }
        val raceDates = raceEvents.filter { it.status != "CANCELLED" }.mapNotNull { it.dateOrNull() }.toSet()
        val decision = TrainingScheduleEngine.validateMove(
            source = TrainingScheduleEngine.SessionSlot(workout.sessionId, current, workout.type, workout.done),
            targetDate = newDate, sessions = slots, raceDates = raceDates
        )
        if (!decision.allowed) {
            scheduleActionMessage = decision.reason
            return false
        }
        val newLabel = "${newDate.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, Locale.forLanguageTag("pt-BR")).replaceFirstChar { it.uppercase(Locale.forLanguageTag("pt-BR")) }}, ${newDate.format(DateTimeFormatter.ofPattern("dd/MM"))}"
        workouts = workouts.map { item ->
            if (item.sessionId == workout.sessionId) item.copy(
                date = newLabel,
                scheduledDateIso = newDate.toString(),
                manuallyRescheduled = true,
                originalScheduledDateIso = item.originalScheduledDateIso.ifBlank { current.toString() }
            ) else item
        }
        selectedWorkoutIndex = workouts.indexOfFirst { it.sessionId == workout.sessionId }.coerceAtLeast(0)
        scheduleActionMessage = "Sessão reagendada para ${newDate.format(DateTimeFormatter.ofPattern("dd/MM"))}. A dose e os blocos foram preservados."
        persist()
        return true
    }

    fun isCooperEntryValid(): Boolean {
        if (fitnessTestMethod == "NONE") return true // conservative provisional profile; the test can be added later
        val date = parsedCooperAssessmentDate() ?: return false
        if (!CooperAssessmentEngine.isRecentAssessmentDate(date)) return false
        if (parsedAgeYears() == null || referenceSex !in setOf(RunnerFitnessAssessmentEngine.MALE, RunnerFitnessAssessmentEngine.FEMALE)) return false
        return when (fitnessTestMethod) {
            "COOPER_12_MIN" -> PaceCalculator.calculateCooper(cooperDistanceText.trim().replace(",", ".").toDoubleOrNull()) != null
            "THREE_KM" -> parsedAgeYears()?.let { it in 18..39 } == true &&
                PaceCalculator.calculateThreeKm(RunnerFitnessAssessmentEngine.parseDurationSeconds(threeKmTimeText), referenceSex) != null
            else -> false
        }
    }

    /** Only an A-priority event is the primary goal race; B/C events remain tune-ups. */
    fun primaryUpcomingRace(): RaceEvent? = raceEvents
        .filter { it.status == "PLANNED" && it.priority == "A" }
        .mapNotNull { event -> event.dateOrNull()?.let { event to it } }
        .filter { !it.second.isBefore(LocalDate.now()) }
        .minByOrNull { it.second }?.first

    fun eventsForPlanWeek(week: Int): List<RaceEvent> {
        val start = runCatching { LocalDate.parse(planStartDateIso) }.getOrNull()
            ?: workouts.minOfOrNull { runCatching { LocalDate.parse(it.scheduledDateIso) }.getOrNull() ?: LocalDate.now() }
                ?.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            ?: return emptyList()
        // UI and planning engine share the same numbering: the current partial
        // calendar week is week 1, the following Monday begins week 2.
        val racePlanningWeek = week.coerceAtLeast(1)
        return RaceEventEngine.eventsForWeek(raceEvents, start, racePlanningWeek)
    }

    fun beginRaceEdit(event: RaceEvent) {
        editingRaceId = event.id
        raceNameDraft = event.name
        raceDistanceDraft = String.format(Locale.US, "%.1f", event.distanceKm).replace(".", ",")
        raceDateDraft = RaceEventEngine.formatBrazilianDate(event.eventDateIso)
        racePriorityDraft = event.priority
        raceTargetTimeDraft = event.targetTime
        raceLocationDraft = event.location
        raceNotesDraft = event.notes
        raceFormError = ""
    }

    fun resetRaceDraft() {
        editingRaceId = ""
        raceNameDraft = ""
        raceDistanceDraft = ""
        raceDateDraft = LocalDate.now().plusMonths(2).format(DateTimeFormatter.ofPattern("dd/MM/uuuu"))
        racePriorityDraft = "A"
        raceTargetTimeDraft = ""
        raceLocationDraft = ""
        raceNotesDraft = ""
        raceFormError = ""
    }

    fun saveRaceDraft(): Boolean {
        val distance = raceDistanceDraft.trim().replace(",", ".").toDoubleOrNull()
        raceFormError = RaceEventEngine.validate(raceNameDraft, distance, raceDateDraft, racePriorityDraft, raceTargetTimeDraft).orEmpty()
        if (raceFormError.isNotBlank() || distance == null) return false
        val status = RaceEventEngine.parseBrazilianDate(raceDateDraft)?.let { if (it.isBefore(LocalDate.now())) "COMPLETED" else "PLANNED" } ?: "PLANNED"
        val race = RaceEventEngine.create(
            id = editingRaceId.ifBlank { java.util.UUID.randomUUID().toString() },
            name = raceNameDraft, distanceKm = distance, dateText = raceDateDraft, priority = racePriorityDraft,
            targetTime = raceTargetTimeDraft, location = raceLocationDraft, notes = raceNotesDraft, status = status
        ) ?: run { raceFormError = "Não foi possível salvar a competição. Confira os dados."; return false }
        raceEvents = if (editingRaceId.isBlank()) raceEvents + race else raceEvents.map { if (it.id == editingRaceId) race else it }
        syncTargetDate()
        if (workouts.isNotEmpty()) {
            needsEngineRefresh = true
            racePlanNote = "A lista de competições mudou. Recalcule o plano para ajustar sessões, taper e recuperação."
        }
        resetRaceDraft()
        persist()
        return true
    }

    fun deleteRace(id: String) {
        raceEvents = raceEvents.filterNot { it.id == id }
        syncTargetDate()
        if (workouts.isNotEmpty()) needsEngineRefresh = true
        persist()
    }

    fun markRaceCompleted(id: String) {
        raceEvents = raceEvents.map { if (it.id == id) it.copy(status = "COMPLETED") else it }
        syncTargetDate()
        persist()
    }

    private fun syncTargetDate() {
        val primary = primaryUpcomingRace()
        targetDate = primary?.let { RaceEventEngine.formatBrazilianDate(it.eventDateIso) } ?: "Sem prova principal"
    }

    private fun feedbackRpeValue(record: FeedbackRecord): Int? =
        FeedbackRpeScale.valueFor(record.effort)

    private fun actualDurationSeconds(record: FeedbackRecord): Int? {
        PaceCalculator.parseDuration(record.actualDuration.orEmpty())?.let { return it }
        val distance = record.actualDistanceKm ?: return null
        val pace = PaceRange.parsePace(record.actualPaceMinKm.orEmpty()) ?: return null
        return (distance * pace).toInt().takeIf { it in 1..172_800 }
    }

    private fun estimatedZoneTimeFromSplits(record: FeedbackRecord): Map<String, Int> {
        val distance = record.actualDistanceKm ?: return emptyMap()
        val zones = currentPaceZones() ?: return emptyMap()
        if (record.splitPacesMmSs.isEmpty()) return emptyMap()
        val totals = mutableMapOf<String, Int>()
        var remainingKm = distance
        record.splitPacesMmSs.forEach { rawPace ->
            val pace = PaceRange.parsePace(rawPace) ?: return@forEach
            val splitKm = minOf(1.0, remainingKm)
            if (splitKm <= 0.0) return@forEach
            val zoneId = listOf(
                "Z1" to zones.z1.range, "Z2" to zones.z2.range, "Z3" to zones.z3.range,
                "Z4" to zones.z4.range, "Z5" to zones.z5.range
            ).firstOrNull { (_, range) -> pace in range.fastestPaceValue..range.slowestPaceValue }?.first
            if (zoneId != null) totals[zoneId] = (totals[zoneId] ?: 0) + (splitKm * pace).toInt()
            remainingKm -= splitKm
        }
        return totals
    }

    private fun measuredZoneTimeFromTrack(segments: List<ActivityPaceSegment>): Map<String, Int> =
        currentPaceZones()?.let { zones -> ActivityZoneTimeEngine.summarize(segments, zones.all()) }.orEmpty()

    private fun loggedActivitiesForLoad(): List<LoggedRunActivity> = feedbackRecords.mapNotNull { record ->
        val distance = record.actualDistanceKm ?: return@mapNotNull null
        LoggedRunActivity(
            date = feedbackActivityDate(record),
            distanceKm = distance,
            durationSeconds = actualDurationSeconds(record),
            rpe = feedbackRpeValue(record),
            averageHeartRateBpm = record.averageHeartRateBpm,
            averageCadenceSpm = record.averageCadenceSpm,
            elevationGainMeters = record.elevationGainMeters,
            sessionType = record.workoutType,
            zoneTimeSeconds = record.measuredZoneTimeSeconds.ifEmpty {
                measuredZoneTimeFromTrack(record.recordedPaceSegments)
            },
            estimatedZoneTimeSeconds = estimatedZoneTimeFromSplits(record),
            terrain = RunningTerrain.normalize(record.terrain)
        )
    }

    fun trainingLoadSnapshot(today: LocalDate = LocalDate.now()): TrainingLoadSnapshot =
        TrainingLoadEngine.summarize(loggedActivitiesForLoad(), today)

    fun criticalSpeedSnapshot(today: LocalDate = LocalDate.now()): CriticalSpeedSnapshot =
        PhysiologicalProfileEngine.estimateCriticalSpeed(performanceTestObservations(), today)

    private fun performanceTestObservations(): List<PerformanceTestObservation> = feedbackRecords.mapNotNull { record ->
        val distance = record.actualDistanceKm ?: return@mapNotNull null
        val duration = actualDurationSeconds(record) ?: return@mapNotNull null
        val rpe = feedbackRpeValue(record) ?: 0
        val testLike = record.raceEventId.isNotBlank() || listOf(record.workoutType, record.workoutTitle).any { value ->
            val normalized = value.lowercase(Locale.ROOT)
            normalized.contains("prova") || normalized.contains("teste") || normalized.contains("cooper") || normalized.contains("time trial")
        }
        PerformanceTestObservation(
            date = feedbackActivityDate(record),
            distanceKm = distance,
            durationSeconds = duration,
            effortRating = rpe,
            painPresent = record.painPresent,
            isRaceOrTest = testLike,
            terrain = RunningTerrain.normalize(record.terrain)
        )
    }

    fun createPlan(preserveCycleAnchor: Boolean = false): Boolean {
        // Recalculation updates zones and sessions from today forward; it must not
        // restart an active 8-week cycle. Only an empty/expired plan starts a new cycle.
        val shouldPreserveCycleAnchor = preserveCycleAnchor || workouts.isNotEmpty()
        motorError = ""
        if (goal.isBlank() || level.isBlank() || availableTrainingDays.size !in 2..6 || frequency != availableTrainingDays.size) {
            motorError = "Complete o objetivo disponível para seu nível fisiológico e a disponibilidade semanal antes de criar o plano."
            persist()
            return false
        }
        if (goal !in TrainingGoalCatalog.labelsForLevel(level)) {
            motorError = "A meta escolhida não está liberada para o nível fisiológico atual. Escolha uma meta disponível ou registre um novo teste de campo."
            persist()
            return false
        }

        val customDistance = customGoalKm.trim().replace(",", ".").toDoubleOrNull()
        val goalKm = TrainingGoalCatalog.distanceForLabel(goal, customDistance)
        if (goalKm == null) {
            motorError = "Informe uma distância válida entre 1 e 200 km para o objetivo personalizado."
            persist()
            return false
        }
        val beginnerProfile = RunnerFitnessAssessmentEngine.normalizeLevel(level) == "Iniciante"
        val enteredWeeklyKm = weeklyVolumeText.trim().replace(",", ".").toDoubleOrNull()
        val enteredLongestKm = longestRecent.trim().replace(",", ".").toDoubleOrNull()
        val weeklyKm = enteredWeeklyKm ?: if (beginnerProfile) defaultBeginnerWeeklyKm() else null
        val recentKm = enteredLongestKm ?: if (beginnerProfile) defaultBeginnerLongestKm() else null
        if (weeklyKm == null || weeklyKm !in 0.0..300.0) {
            motorError = "Informe a média semanal real. Para um perfil Iniciante sem histórico, o treinador usa uma dose inicial conservadora automaticamente."
            persist()
            return false
        }
        if (recentKm == null || recentKm !in 0.0..200.0) {
            motorError = "Informe a maior corrida recente. Para um perfil Iniciante sem histórico, o treinador usa um limite inicial conservador automaticamente."
            persist()
            return false
        }
        if (!saveCurrentFieldTestToHistory()) {
            persist()
            return false
        }
        level = RunnerFitnessAssessmentEngine.normalizeLevel(level)
        val latestAssessment = cooperAssessments.maxByOrNull { it.dateIso }
        val cooperDistance = latestAssessment?.takeIf { it.testMethod == "COOPER_12_MIN" }?.distanceKm
        val cooperDate = latestAssessment?.dateIso?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
        val previousCooperDistance = CooperAssessmentEngine.previousAssessmentDistance(
            cooperAssessments, cooperDate?.toString()
        )

        return try {
            val today = LocalDate.now()
            val loadSnapshot = TrainingLoadEngine.summarize(
                activities = loggedActivitiesForLoad(),
                today = today
            )
            // Promote measured four-week load only when enough real activities span
            // at least three weeks. With partial logging, keep the profile baseline and
            // use a longer recorded run as an additional tolerance bound.
            val effectiveWeeklyKm = if (loadSnapshot.reliable) {
                loadSnapshot.averageWeeklyKmLast28Days ?: weeklyKm
            } else weeklyKm
            val measuredLongestRun = loadSnapshot.longestRunLast30DaysKm?.takeIf { it > 0.0 }
            // A reliable 28-day load summary can still have no long run in its 30-day window.
            // In that case keep the explicit recent-longest baseline instead of replacing it by zero.
            val effectiveLongestKm = if (loadSnapshot.reliable) {
                measuredLongestRun ?: recentKm
            } else maxOf(recentKm, measuredLongestRun ?: 0.0)
            // When six measured runs span at least three weeks, the activity log is
            // more reliable than the onboarding estimate for both volume and consistency.
            // Otherwise keep the athlete's reported value; legacy unknown values stay unknown.
            val effectiveActiveWeeks = RunnerReadinessEngine.resolveActiveWeeks(
                reportedWeeks = -1,
                measuredWeeks = loadSnapshot.activeWeeksLast28Days.coerceIn(0, 4),
                measuredHistoryReliable = loadSnapshot.reliable
            )
            activeWeeksLast4 = effectiveActiveWeeks
            val selectedGoalCategory = TrainingGoalCatalog.categoryForLabel(goal)
            val readinessAssessment = RunnerReadinessEngine.evaluate(
                RunnerReadinessInput(
                    goalKm = goalKm,
                    goalCategory = selectedGoalCategory,
                    declaredLevel = level,
                    experienceMonths = experienceMonths(),
                    selectedFrequency = frequency,
                    weeklyVolumeKm = effectiveWeeklyKm,
                    longestRecentKm = effectiveLongestKm,
                    activeWeeksLast4 = effectiveActiveWeeks,
                    goalIntent = if (selectedGoalCategory == "HEALTH") TrainingGoalIntent.HEALTH else goalIntent,
                    targetTimeSeconds = goalTargetTimeText.takeIf { goalIntent == TrainingGoalIntent.TARGET_TIME }?.let(PhysiologicalProfileEngine::parseTargetTime),
                    terrainPreference = terrainPreference
                )
            )
            val prescriptionLevel = readinessAssessment.prescriptionLevel
            // Physiological level does not force walk-only scheduling. Adapt the format
            // to the actual recent load, independent of the VO2max class.
            val novicePlan = effectiveWeeklyKm < 4.0 || effectiveLongestKm < 2.5 ||
                (effectiveWeeklyKm <= 0.0 && effectiveActiveWeeks == 0)
            val prescribedDays = TrainingScheduleEngine.prescribedRunningDays(
                availableTrainingDays, frequency, novicePlan, preferredLongRunDay
            )
            val restoredCycleWindow = if (shouldPreserveCycleAnchor) {
                val savedCycleAnchor = PlanMigrationEngine.inferRestoredCycleAnchor(planStartDateIso, workouts)
                    ?.toString().orEmpty()
                PlanMigrationEngine.restoredPlanWindow(savedCycleAnchor, planWeeks, raceEvents, today)
            } else null
            val recommendedWeeks = TrainingPeriodizationEngine.recommendedPlanWeeks(
                goalKm = goalKm,
                level = readinessAssessment.prescriptionLevel,
                weeklyVolumeKm = effectiveWeeklyKm
            )
            val planWindow = restoredCycleWindow
                ?: RaceEventEngine.resolvePlanWindow(today, raceEvents, defaultWeeks = recommendedWeeks)
            val preservingOriginalCycle = restoredCycleWindow != null
            // Only a race selected inside the active planning window may change this block's
            // specific goal distance. A distant A-race remains visible but must not hijack a
            // 16-week base block or override a nearer tune-up event.
            val goalRace = planWindow.primaryRaceId
                ?.takeIf { planWindow.raceInsideWindow }
                ?.let { selectedId -> raceEvents.firstOrNull { it.id == selectedId && it.status == "PLANNED" } }
            val planningGoalKm = goalRace?.distanceKm ?: goalKm
            val effectiveGoalIntent = if (goalRace == null && selectedGoalCategory == "HEALTH") TrainingGoalIntent.HEALTH
                else if (goalRace != null) TrainingGoalIntent.TARGET_TIME.takeIf { !goalRace.targetTime.isBlank() } ?: goalIntent
                else goalIntent
            val effectiveTargetTimeSeconds = goalRace?.targetTime?.takeIf { it.isNotBlank() }?.let(PhysiologicalProfileEngine::parseTargetTime)
                ?: goalTargetTimeText.takeIf { effectiveGoalIntent == TrainingGoalIntent.TARGET_TIME }?.let(PhysiologicalProfileEngine::parseTargetTime)
            val performanceEvidence = performanceTestObservations()
            planStartDateIso = planWindow.startDate.toString()
            val currentZones = currentPaceZones()
            rememberZoneBoundaries(currentZones)
            val input = RunnerInput(
                goalKm = planningGoalKm,
                level = RunnerFitnessAssessmentEngine.normalizeLevel(level),
                frequency = frequency,
                availableDays = availableTrainingDays,
                preferredLongRunDay = preferredLongRunDay,
                weeklyVolumeKm = effectiveWeeklyKm,
                longestRecentKm = effectiveLongestKm,
                painPresent = recentFeedback().takeLast(3).any { it.painPresent },
                recoveryScore = deriveRecoveryScore(),
                fatigueScore = deriveFatigueScore(),
                planWeeks = planWindow.weeks,
                cooperDistanceKm = cooperDistance,
                cooperAssessmentDateIso = cooperDate?.toString(),
                previousCooperDistanceKm = previousCooperDistance,
                talkTestComfortPaceValues = recentTalkTestPaces(),
                calibratedPaceZones = currentZones,
                recentActivityCount = loadSnapshot.recordedRunsLast28Days,
                recentActivityHistoryReliable = loadSnapshot.reliable,
                profileBaselineConfirmed = weeklyVolumeText.trim().replace(",", ".").toDoubleOrNull()?.let { it >= 8.0 } == true &&
                    longestRecent.trim().replace(",", ".").toDoubleOrNull()?.let { it >= 4.0 } == true,
                experienceMonths = experienceMonths(),
                activeWeeksLast4 = effectiveActiveWeeks,
                startDate = planWindow.startDate,
                goalCategory = if (goalRace != null) "PERFORMANCE" else TrainingGoalCatalog.categoryForLabel(goal),
                goalIntent = effectiveGoalIntent,
                targetTimeSeconds = effectiveTargetTimeSeconds,
                terrainPreference = terrainPreference,
                performanceTests = performanceEvidence,
                measuredSessionRpeLoad7Days = loadSnapshot.sessionRpeLoadLast7Days,
                measuredSessionRpeLoad28Days = loadSnapshot.sessionRpeLoadLast28Days,
                measuredDurationMinutes7Days = loadSnapshot.durationMinutesLast7Days,
                measuredDurationMinutes28Days = loadSnapshot.durationMinutesLast28Days,
                measuredAverageRpe28Days = loadSnapshot.averageRpeLast28Days
            )
            val plan = RunningCoachEngine.generate(input)
            // A backup is an authoritative snapshot of what was actually scheduled.
            // Rebuild the original cycle from its anchor, but regenerate only today and
            // future dates. Historical sessions are preserved exclusively from the file:
            // the migration must never invent a past workout absent from that backup.
            val remainingCycleSessions = PlanMigrationEngine.currentAndFutureCycleSessions(
                sessions = plan.workouts,
                today = today,
                cycleStart = planWindow.startDate.takeIf { preservingOriginalCycle },
                cycleWeeks = planWindow.weeks.takeIf { preservingOriginalCycle }
            )
            // Only active/future sessions receive competition taper and intensity-band
            // adjustments. Past sessions already present in the backup remain untouched.
            val raceAdjustment = RaceEventEngine.applyToPlan(
                workouts = remainingCycleSessions,
                events = raceEvents,
                planStartDate = planWindow.startDate,
                frequency = prescribedDays.size,
                zones = currentZones,
                today = today
            )

            // Ordinary and restored plans both regenerate only today/future sessions;
            // restored history comes only from the authoritative backup snapshot.
            val currentWeekStart = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            val bandAdjustedWorkouts = raceAdjustment.workouts.map { ZoneIntensityBandEngine.apply(it) }
            val upcomingPlanSessions = if (preservingOriginalCycle) {
                bandAdjustedWorkouts.map { prescribed ->
                    val date = LocalDate.parse(prescribed.scheduledDateIso)
                    prescribed.copy(week = RaceEventEngine.weekIndex(date, planWindow.startDate))
                }.sortedBy { it.scheduledDateIso }
            } else {
                TrainingScheduleEngine.keepUpcomingSessionsForCurrentWeek(
                    bandAdjustedWorkouts, today, planWindow.startDate
                )
            }
            val racePlanWarningsCombined = raceAdjustment.warnings
            val previousManualDates = workouts.filter { it.manuallyRescheduled && !it.done }.associateBy { it.sessionId }
            racePlanWarnings = racePlanWarningsCombined
            racePlanNote = buildString {
                append(planWindow.note)
                goalRace?.let { append(" Objetivo específico do ciclo: ${it.name}, ${formatKmUi(it.distanceKm)} km.") }
                if (raceAdjustment.replacedSessionIds.isNotEmpty()) {
                    append(" ${raceAdjustment.replacedSessionIds.size} sessão(ões) substituída(s) por competição; taper e recuperação foram ajustados.")
                }
                if (raceAdjustment.taperedSessionIds.isNotEmpty()) {
                    append(" As sessões próximas da prova tiveram carga reduzida.")
                }
                if (preservingOriginalCycle) {
                    append(" O ciclo do backup foi atualizado desde ${planWindow.startDate.format(DateTimeFormatter.ofPattern("dd/MM"))}; a numeração original foi mantida e somente hoje/datas futuras foram regeneradas. O histórico anterior permanece exatamente como estava no arquivo.")
                } else {
                    append(" A semana atual começa em ${currentWeekStart.format(DateTimeFormatter.ofPattern("dd/MM"))}; sessões anteriores a hoje não são recriadas e os próximos treinos permanecem na semana correta.")
                }
            }
            motorState = plan.state
            motorDecision = plan.decision
            motorExplanation = plan.explanation
            if (plan.decision.safety == "RED") {
                // Preserve the previous cycle so the athlete can review/update the pain feedback
                // after recovery; a blocked generation must not erase the only way to do that.
                motorError = "Nova prescrição bloqueada por relato de dor. O plano anterior foi preservado; atualize o feedback somente quando estiver sem dor."
                onboardingStep = 8
                resetNavigation(Screen.DASHBOARD)
                persist()
                return false
            }
            if (plan.workouts.isEmpty()) {
                motorError = "O motor terminou sem gerar sessões."
                persist()
                return false
            }
            val recordedSessionIds = feedbackRecords.map { it.sessionId }.toSet()
            // Completed records and optional one-off sessions survive a plan migration.
            val completedBeforeRecalibration = PlanMigrationEngine.preserveHistoryAndCompleted(workouts, recordedSessionIds, today)
            val completedDates = completedBeforeRecalibration
                .mapNotNull { runCatching { LocalDate.parse(it.scheduledDateIso) }.getOrNull() }.toSet()
            // Core plan sessions take priority over a still-pending optional extra if both
            // land on the same date after a profile/availability recalculation.
            val generatedWorkouts = upcomingPlanSessions.filter { prescribed ->
                val date = runCatching { LocalDate.parse(prescribed.scheduledDateIso) }.getOrNull()
                date != null && date !in completedDates
            }.map { p ->
                val previousManual = previousManualDates[p.sessionId]
                val generatedDate = runCatching { LocalDate.parse(p.scheduledDateIso) }.getOrNull()
                val manualDate = previousManual?.let { runCatching { LocalDate.parse(it.scheduledDateIso) }.getOrNull() }
                val keepManual = generatedDate != null && manualDate != null && !manualDate.isBefore(today) &&
                    generatedDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)) == manualDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
                val finalDate = if (keepManual) manualDate!! else generatedDate
                val finalDateLabel = finalDate?.let { d -> "${d.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, Locale.forLanguageTag("pt-BR")).replaceFirstChar { it.uppercase(Locale.forLanguageTag("pt-BR")) }}, ${d.format(DateTimeFormatter.ofPattern("dd/MM"))}" } ?: p.date
                Workout(
                    date = finalDateLabel, scheduledDateIso = finalDate?.toString() ?: p.scheduledDateIso, title = p.title, detail = p.detail, type = p.type,
                    objective = p.objective, stimulus = p.stimulus, distanceKm = p.distanceKm,
                    sessionId = p.sessionId, durationMin = p.durationMin, intensity = p.intensity,
                    paceMode = p.paceMode, rpeRange = p.rpeRange, rationale = p.rationale,
                    week = p.week, phase = p.phase, segments = p.segments,
                    paceCalibrationSnapshot = p.paceCalibrationSnapshot,
                    manuallyRescheduled = keepManual,
                    originalScheduledDateIso = if (keepManual) (previousManual?.originalScheduledDateIso ?: p.scheduledDateIso) else ""
                )
            }
            val generatedDates = generatedWorkouts.mapNotNull { runCatching { LocalDate.parse(it.scheduledDateIso) }.getOrNull() }.toSet()
            val optionalExtrasToKeep = PlanMigrationEngine.pendingOptionalExtras(workouts, today, recordedSessionIds)
                .filter { extra -> runCatching { LocalDate.parse(extra.scheduledDateIso) }.getOrNull() !in generatedDates }
            workouts = PlanMigrationEngine.merge(completedBeforeRecalibration, optionalExtrasToKeep, generatedWorkouts)
            if (preservingOriginalCycle) {
                workouts = PlanMigrationEngine.normalizeCycleWeekNumbers(workouts, planWindow.startDate)
            }
            if (loadSnapshot.reliable) {
                weeklyVolumeText = String.format(Locale.US, "%.1f", effectiveWeeklyKm)
                longestRecent = String.format(Locale.US, "%.1f", effectiveLongestKm)
            }
            if (cooperEnabled && cooperDistance != null) {
                val record = cooperDate?.let { CooperAssessmentEngine.createRecord(cooperDistance, it, recentTalkTestPaces(), currentZones) }
                if (record != null) {
                    cooperAssessments = (cooperAssessments.filterNot { it.dateIso == record.dateIso } + record)
                        .sortedBy { it.dateIso }
                }
            }
            motorError = ""
            // Preserve the exact cycle duration stored in the backup. Summary-card count
            // can be lower when a generated week contains no running session (e.g. race/recovery).
            planWeeks = planWindow.weeks
            syncTargetDate()
            needsEngineRefresh = false
            needsPacePlanRefresh = false
            prefs.edit().putInt("engineVersion", CURRENT_ENGINE_VERSION).putBoolean("needsEngineRefresh", false).apply()
            selectedWorkoutIndex = 0
            resetNavigation(Screen.DASHBOARD)
            onboardingStep = 8
            persist()
            true
        } catch (e: Exception) {
            motorError = "Erro ao executar o motor: ${e.message ?: "erro desconhecido"}"
            persist()
            false
        }
    }

    fun selectedWorkoutBase(): Workout? = workouts.getOrNull(selectedWorkoutIndex)

    fun selectedWorkout(): Workout? {
        val base = selectedWorkoutBase() ?: return null
        val selected = if (base.selectedOption == "ALTERNATIVE") WorkoutAlternativeEngine.createAlternative(base) else base
        return ZoneIntensityBandEngine.apply(selected)
    }

    fun selectWorkoutOption(sessionId: String, option: String) {
        if (option !in setOf("PRIMARY", "ALTERNATIVE")) return
        val index = workouts.indexOfFirst { it.sessionId == sessionId }
        if (index < 0 || workouts[index].done) return
        workouts = workouts.map { if (it.sessionId == sessionId) it.copy(selectedOption = option) else it }
        selectedWorkoutIndex = index
        persist()
    }

    private fun zoneCalibrationEvidence(extraCooper: CooperPerformanceEvidence? = null): ZoneCalibrationEvidence {
        val today = LocalDate.now()
        val cutoff = today.minusDays(42)
        fun validDate(record: FeedbackRecord): LocalDate? = feedbackActivityDate(record).takeIf { !it.isBefore(cutoff) && !it.isAfter(today) }
        fun recordedPace(record: FeedbackRecord): Int? = PaceRange.parsePace(record.actualPaceMinKm.orEmpty())
            ?: run {
                val distance = record.actualDistanceKm ?: return@run null
                val duration = PaceCalculator.parseDuration(record.actualDuration.orEmpty()) ?: return@run null
                PaceCalculator.paceFromDistanceAndDuration(distance, duration)
            }
        val recovery = feedbackRecords.mapNotNull { record ->
            val date = validDate(record) ?: return@mapNotNull null
            val sessionType = record.workoutType.ifBlank {
                workouts.firstOrNull { it.sessionId == record.sessionId }?.type.orEmpty()
            }
            val isRecovery = ZoneCalibrationEngine.isRecoveryWorkoutType(sessionType)
            if (!isRecovery || record.painPresent || record.effort !in setOf("Muito leve", "Leve") ||
                record.feeling !in setOf("Ótimo", "Bem")) return@mapNotNull null
            val pace = recordedPace(record) ?: return@mapNotNull null
            ZoneObservation(date.toString(), pace)
        }.distinctBy { it.dateIso }.sortedBy { it.dateIso }.takeLast(8)
        val talk = feedbackRecords.mapNotNull { record ->
            val date = validDate(record) ?: return@mapNotNull null
            val workoutType = record.workoutType.ifBlank { workouts.firstOrNull { it.sessionId == record.sessionId }?.type.orEmpty() }
            if (!TalkTestCalibrationRules.isEligibleWorkout(workoutType) ||
                !TalkTestCalibrationRules.canCalibrate(record.effort, record.feeling, record.painPresent)) return@mapNotNull null
            val pace = PaceRange.parsePace(record.talkTestPaceMmSs.orEmpty()) ?: return@mapNotNull null
            ZoneObservation(date.toString(), pace)
        }.distinctBy { it.dateIso }.sortedBy { it.dateIso }.takeLast(8)
        val tests = (cooperAssessments.filter { it.testMethod == "COOPER_12_MIN" }.map { CooperPerformanceEvidence(it.dateIso, it.distanceKm) } + listOfNotNull(extraCooper))
            .distinctBy { it.dateIso }.sortedBy { it.dateIso }
        return ZoneCalibrationEvidence(recovery, talk, tests)
    }

    private fun personalizeZones(base: TrainingPaceZones?, extraCooper: CooperPerformanceEvidence? = null): TrainingPaceZones? {
        if (base == null) return null
        return ZoneCalibrationEngine.apply(base, zoneCalibrationEvidence(extraCooper), lastZoneBoundarySnapshot)
    }

    private fun rememberZoneBoundaries(zones: TrainingPaceZones?) {
        if (zones != null) lastZoneBoundarySnapshot = ZoneCalibrationEngine.boundaryValues(zones)
    }

    fun currentPaceZones(): TrainingPaceZones? {
        if (fitnessTestMethod == "THREE_KM") {
            return selectedFieldTestZones() ?: cooperAssessments.lastOrNull { it.testMethod == "THREE_KM" }?.let { record ->
                val time = record.testDurationSeconds ?: return@let null
                PaceCalculator.calculateThreeKm(time, record.referenceSex)
            }?.let(::personalizeZones)
        }
        val profileDistance = if (cooperEnabled && fitnessTestMethod == "COOPER_12_MIN") cooperDistanceText.trim().replace(",", ".").toDoubleOrNull() else null
        val cooperDistance = profileDistance ?: cooperAssessments.lastOrNull { it.testMethod == "COOPER_12_MIN" }?.distanceKm
        val currentDateIso = if (cooperEnabled) parsedCooperAssessmentDate()?.toString() else cooperAssessments.lastOrNull { it.testMethod == "COOPER_12_MIN" }?.dateIso
        val previousDistance = CooperAssessmentEngine.previousAssessmentDistance(cooperAssessments, currentDateIso, "COOPER_12_MIN")
        val smooth = PaceCalculator.limitCalibrationChange(
            PaceCalculator.calculateCooper(cooperDistance),
            PaceCalculator.calculateCooper(previousDistance),
            maxBoundaryShiftSeconds = 15
        )
        return personalizeZones(smooth)
    }

    /** Preview uses the same independent evidence gates that are saved and applied to the plan. */
    fun calculateZonesForCooper(distanceKm: Double?): TrainingPaceZones? {
        val assessmentDate = parsedCooperAssessmentDate()?.toString() ?: LocalDate.now().toString()
        val previousDistance = CooperAssessmentEngine.previousAssessmentDistance(cooperAssessments, assessmentDate)
        val smooth = PaceCalculator.limitCalibrationChange(
            PaceCalculator.calculateCooper(distanceKm),
            PaceCalculator.calculateCooper(previousDistance),
            maxBoundaryShiftSeconds = 15
        )
        return personalizeZones(smooth, if (distanceKm != null) CooperPerformanceEvidence(assessmentDate, distanceKm) else null)
    }

    /** Rebuilds future sessions from the saved athlete profile and current calibrated zones. */
    fun recalibratePlan(): Boolean {
        if (currentPaceZones() == null) {
            motorError = "Registre um teste fisiológico válido antes de calibrar o plano."
            latestCooperMessage = motorError
            persist()
            navigateTo(Screen.COOPER_TEST)
            return false
        }
        val updated = createPlan()
        if (updated) {
            latestCooperMessage = "Plano recalibrado. As sessões concluídas e os feedbacks anteriores foram preservados."
            latestFeedbackHeadline = "Calibração aplicada"
            latestFeedbackAdvice = "As próximas sessões foram recalculadas com as zonas atuais e os limites de progressão conservadora."
            needsPacePlanRefresh = false
            needsEngineRefresh = false
            persist(synchronous = true)
        }
        return updated
    }

    fun feedbackForSession(sessionId: String): FeedbackRecord? = feedbackRecords.lastOrNull { it.sessionId == sessionId }

    fun orphanFeedbackRecords(): List<FeedbackRecord> {
        val workoutIds = workouts.map { it.sessionId }.toSet()
        return feedbackRecords.filter { it.sessionId !in workoutIds }
    }

    /** Last three talk-test paces from recent, completed easy/long sessions. */
    private fun recentTalkTestPaces(): List<Int> {
        val today = LocalDate.now()
        val cutoff = today.minusDays(42)
        return feedbackRecords.asSequence()
            .filter { record ->
                val date = feedbackActivityDate(record)
                !date.isBefore(cutoff) && !date.isAfter(today) && !record.painPresent
            }
            .sortedBy(::feedbackActivityDate)
            .filter { it.effort in setOf("Muito leve", "Leve", "Ok") && it.feeling in setOf("Ótimo", "Bem") }
            .mapNotNull { record ->
                val workoutType = record.workoutType.ifBlank {
                    workouts.firstOrNull { it.sessionId == record.sessionId }?.type.orEmpty()
                }
                if (!TalkTestCalibrationRules.isEligibleWorkout(workoutType) ||
                    !TalkTestCalibrationRules.canCalibrate(record.effort, record.feeling, record.painPresent)
                ) return@mapNotNull null
                PaceRange.parsePace(record.talkTestPaceMmSs.orEmpty())
            }
            .toList()
            .takeLast(3)
    }

    fun cooperReviewStatus() = CooperAssessmentEngine.reviewStatus(cooperAssessments)

    fun saveCurrentFieldTestToHistory(): Boolean {
        if (fitnessTestMethod == "NONE") {
            level = "Iniciante" // internal conservative starting guardrail; not a tested class
            if (goal.isNotBlank() && goal !in TrainingGoalCatalog.labelsForLevel(level)) goal = ""
            persist()
            return true
        }
        if (recentFeedback().takeLast(3).any { it.painPresent } || deriveRecoveryScore()?.let { it < 50.0 } == true) {
            motorError = "A avaliação foi suspensa porque há sinais recentes de dor ou recuperação insuficiente. Refaça o teste quando estiver recuperado."
            return false
        }
        if (!isCooperEntryValid()) {
            motorError = if (fitnessTestMethod == "THREE_KM") {
                "Para o teste de 3 km, informe idade entre 18 e 39 anos, referência fisiológica, tempo mm:ss válido e data recente."
            } else "Confira idade, referência fisiológica, distância do Cooper (1,00–5,00 km) e data do teste."
            return false
        }
        val date = parsedCooperAssessmentDate() ?: return false
        val zones = selectedFieldTestZones() ?: return false
        val age = parsedAgeYears() ?: return false
        val record = when (fitnessTestMethod) {
            "COOPER_12_MIN" -> CooperAssessmentEngine.createRecord(
                cooperDistanceText.trim().replace(",", ".").toDoubleOrNull() ?: return false,
                date = date, talkTestComfortPaces = recentTalkTestPaces(), zonesOverride = zones,
                referenceSex = referenceSex, ageAtTest = age
            )
            "THREE_KM" -> CooperAssessmentEngine.createThreeKmRecord(
                RunnerFitnessAssessmentEngine.parseDurationSeconds(threeKmTimeText) ?: return false,
                date = date, referenceSex = referenceSex, ageAtTest = age, zonesOverride = zones
            )
            else -> null
        } ?: return false
        cooperAssessments = (cooperAssessments.filterNot { it.dateIso == record.dateIso && it.testMethod == record.testMethod } + record)
            .sortedWith(compareBy<CooperAssessmentRecord> { it.dateIso }.thenBy { it.testMethod })
        cooperEnabled = true
        level = RunnerFitnessAssessmentEngine.assess(record.estimatedVo2Max, age, referenceSex, "FIELD_ESTIMATE")?.level ?: return false
        if (goal.isNotBlank() && goal !in TrainingGoalCatalog.labelsForLevel(level)) goal = ""
        if (fitnessTestMethod == "COOPER_12_MIN") cooperDistanceText = String.format(Locale.US, "%.2f", record.distanceKm).replace(".", ",")
        cooperAssessmentDateText = date.format(DateTimeFormatter.ofPattern("dd/MM/uuuu"))
        latestCooperMessage = "Avaliação salva. VO₂máx estimado: ${String.format(Locale.US, "%.1f", record.estimatedVo2Max)}. Nível fisiológico: $level."
        persist(synchronous = true)
        return true
    }

    fun attachDemographicsToLatestTest(): Boolean {
        val latest = cooperAssessments.maxByOrNull { it.dateIso } ?: return false
        val age = parsedAgeYears() ?: run { motorError = "Informe a idade que você tinha na data do teste."; return false }
        if (referenceSex !in setOf(RunnerFitnessAssessmentEngine.MALE, RunnerFitnessAssessmentEngine.FEMALE)) {
            motorError = "Selecione a referência fisiológica usada no teste."; return false
        }
        val assessed = RunnerFitnessAssessmentEngine.assess(latest.estimatedVo2Max, age, referenceSex, "FIELD_ESTIMATE")
            ?: run { motorError = "Não foi possível classificar esse resultado com os dados informados."; return false }
        cooperAssessments = cooperAssessments.map { record ->
            if (record.dateIso == latest.dateIso && record.testMethod == latest.testMethod) {
                record.copy(ageAtTest = age, referenceSex = referenceSex)
            } else record
        }
        val previousLevel = level
        level = assessed.level
        if (goal.isNotBlank() && goal !in TrainingGoalCatalog.labelsForLevel(level)) goal = ""
        if (workouts.isNotEmpty() && previousLevel != assessed.level) {
            needsEngineRefresh = true
            racePlanNote = "A faixa fisiológica foi completada para o teste salvo. Revise a meta e recalcule somente as sessões futuras."
        }
        latestCooperMessage = "Referência etária vinculada ao teste já salvo. VO₂máx ${String.format(Locale.US, "%.1f", assessed.vo2Max)} • nível ${assessed.level}. Nenhum resultado foi alterado."
        motorError = ""
        persist(synchronous = true)
        return true
    }

    fun openFieldTestEditor() {
        val latest = cooperAssessments.maxByOrNull { it.dateIso }
        fitnessTestMethod = latest?.testMethod ?: "COOPER_12_MIN"
        ageYearsText = ageYearsText.ifBlank { latest?.ageAtTest?.toString().orEmpty() }
        referenceSex = referenceSex.ifBlank { latest?.referenceSex.orEmpty() }
        // A new test starts with an empty result and today's date; the previous attempt stays in history.
        if (fitnessTestMethod == "THREE_KM") threeKmTimeText = "" else cooperDistanceText = ""
        cooperAssessmentDateText = LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/uuuu"))
        latestCooperMessage = ""
        motorError = ""
        cooperEnabled = true
        navigateTo(Screen.COOPER_TEST)
    }

    fun saveSelectedFieldTestAndReplan(): Boolean {
        if (!saveCurrentFieldTestToHistory()) {
            persist()
            return false
        }
        val profileReady = goal.isNotBlank() && goal in TrainingGoalCatalog.labelsForLevel(level) &&
            availableTrainingDays.size in 2..6 && frequency == availableTrainingDays.size &&
            (level == "Iniciante" || (weeklyVolumeText.isNotBlank() && longestRecent.isNotBlank()))
        if (!profileReady) {
            needsEngineRefresh = workouts.isNotEmpty()
            latestCooperMessage = "Teste salvo. Seu nível fisiológico foi atualizado; escolha uma meta disponível para esse nível antes de recalcular o plano."
            persist()
            return true
        }
        val success = createPlan()
        if (!success) {
            latestCooperMessage = "Teste salvo. O plano anterior foi preservado: ${motorError.ifBlank { "revise os dados do perfil" }}"
            persist()
        }
        return success
    }

    fun saveCooperAndReplan(distanceText: String): Boolean {
        if (recentFeedback().takeLast(3).any { it.painPresent }) {
            latestCooperMessage = "O teste não foi salvo: existe relato recente de dor. Não faça um teste máximo enquanto houver dor; retome a avaliação somente após recuperação adequada."
            persist()
            return false
        }
        if (deriveRecoveryScore()?.let { it < 50.0 } == true) {
            latestCooperMessage = "O teste não foi salvo: os feedbacks recentes indicam recuperação insuficiente. Descanse e reavalie quando estiver recuperado."
            persist()
            return false
        }
        val distanceKm = distanceText.trim().replace(",", ".").toDoubleOrNull()
        val assessmentDateIso = LocalDate.now().toString()
        val previousDistance = CooperAssessmentEngine.previousAssessmentDistance(cooperAssessments, assessmentDateIso)
        val talkPaces = recentTalkTestPaces()
        val smoothBase = PaceCalculator.limitCalibrationChange(
            PaceCalculator.calculateCooper(distanceKm),
            PaceCalculator.calculateCooper(previousDistance),
            maxBoundaryShiftSeconds = 15
        )
        val smoothedZones = personalizeZones(
            smoothBase,
            distanceKm?.let { CooperPerformanceEvidence(assessmentDateIso, it) }
        )
        val record = distanceKm?.let { CooperAssessmentEngine.createRecord(it, talkTestComfortPaces = talkPaces, zonesOverride = smoothedZones) }
        if (record == null) {
            latestCooperMessage = "Distância inválida. Informe o total percorrido em quilômetros no teste de 12 minutos."
            persist()
            return false
        }
        cooperEnabled = true
        cooperDistanceText = String.format(Locale.US, "%.2f", record.distanceKm).replace(".", ",")
        cooperAssessmentDateText = record.dateIso.let { LocalDate.parse(it).format(DateTimeFormatter.ofPattern("dd/MM/uuuu")) }
        val history = cooperAssessments.filterNot { it.dateIso == record.dateIso } + record
        cooperAssessments = history.sortedBy { it.dateIso }
        latestCooperMessage = "Cooper salvo. As zonas foram recalculadas com a nova avaliação."
        persist()
        val profileReady = goal.isNotBlank() && level.isNotBlank() && availableTrainingDays.size in 2..6 && frequency == availableTrainingDays.size &&
            weeklyVolumeText.isNotBlank() && longestRecent.isNotBlank()
        if (!profileReady) {
            rememberZoneBoundaries(smoothedZones)
            latestCooperMessage = "Cooper salvo e zonas atualizadas. Complete os dados do atleta para gerar ou recalcular o plano."
            persist()
            return true
        }
        val success = createPlan()
        if (!success) {
            rememberZoneBoundaries(smoothedZones)
            latestCooperMessage = "Teste salvo e zonas atualizadas. O plano anterior foi preservado: ${motorError.ifBlank { "revise o perfil e a recuperação" }}"
            persist()
        }
        return success
    }

    fun completedWorkouts(): List<Workout> {
        val savedFeedbackIds = feedbackRecords.map { it.sessionId }.toSet()
        return workouts.filter { it.done || it.sessionId in savedFeedbackIds }.map { workout ->
            if (workout.sessionId in savedFeedbackIds && !workout.done) workout.copy(done = true) else workout
        }
    }

    /** One source of truth for the week shown on Dashboard and Plan. */
    fun currentPlanWeekNumber(date: LocalDate = LocalDate.now()): Int? {
        val anchor = runCatching { LocalDate.parse(planStartDateIso) }.getOrNull() ?: return null
        val week = TrainingScheduleEngine.weekNumberForDate(anchor, date)
        return week.takeIf { it in 1..planWeeks }
    }

    /** Active cycle plus the current partial week; older completed cycles stay in history/calendar only. */
    fun activePlanWorkouts(): List<Workout> {
        val planStart = runCatching { LocalDate.parse(planStartDateIso) }.getOrNull() ?: return workouts
        val visibleFrom = if (planStart.isAfter(LocalDate.now())) planStart.minusWeeks(1) else planStart
        return workouts.filter { workout ->
            val date = runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull() ?: return@filter false
            !date.isBefore(visibleFrom)
        }
    }

    fun importedActivityUsedElsewhere(fingerprint: String, sessionId: String): Boolean =
        feedbackRecords.any { it.activityFingerprint == fingerprint && it.sessionId != sessionId }

    fun saveFeedback(
        effort: String,
        feeling: String,
        notes: String,
        painPresent: Boolean,
        actualDistanceText: String,
        actualDurationText: String,
        talkTestPaceText: String,
        importedActivity: ImportedActivity? = null,
        terrain: String = terrainPreference,
        raceEventId: String = ""
    ): Boolean {
        val current = selectedWorkout() ?: run {
            motorError = "Não foi possível localizar a sessão. Abra o treino novamente pelo calendário."
            persist()
            return false
        }
        if (workouts.none { it.sessionId == current.sessionId }) {
            motorError = "A sessão não pertence mais ao plano salvo. Atualize o calendário e tente novamente."
            persist()
            return false
        }
        val previousForSession = feedbackForSession(current.sessionId)
        val manualDistanceKm = actualDistanceText.trim().replace(",", ".").toDoubleOrNull()?.takeIf { it > 0.0 && it <= 200.0 }
        val enteredDurationSeconds = PaceCalculator.parseDuration(actualDurationText)
        // Preserve the importer's full precision while the displayed (rounded) value
        // is unchanged. If the athlete edits a metric, use that correction consistently.
        val importedDistanceDisplay = importedActivity?.distanceKm?.let { formatKmUi(it).replace(",", ".").toDoubleOrNull() }
        val importedDistanceEdited = importedActivity != null && manualDistanceKm != null && importedDistanceDisplay != null &&
            kotlin.math.abs(manualDistanceKm - importedDistanceDisplay) > 0.00001
        val previousWasImported = !previousForSession?.activityFingerprint.isNullOrBlank()
        val linkedRaceDateIso = raceEvents.firstOrNull { it.id == raceEventId }?.dateOrNull()?.toString()
        val previousDistanceDisplay = previousForSession?.actualDistanceKm?.let { formatKmUi(it).replace(",", ".").toDoubleOrNull() }
        val previousDistanceUnchanged = importedActivity == null && previousWasImported && manualDistanceKm != null &&
            previousDistanceDisplay != null && kotlin.math.abs(manualDistanceKm - previousDistanceDisplay) <= 0.00001
        val actualDistanceKm = when {
            importedActivity != null && !importedDistanceEdited -> importedActivity.distanceKm ?: manualDistanceKm
            importedDistanceEdited -> manualDistanceKm
            previousDistanceUnchanged -> previousForSession?.actualDistanceKm
            else -> manualDistanceKm
        }
        val importedElapsedSeconds = importedActivity?.elapsedSeconds
        val importedDurationEdited = importedElapsedSeconds != null && enteredDurationSeconds != null &&
            enteredDurationSeconds != importedElapsedSeconds
        val previousDurationSeconds = previousForSession?.actualDuration?.let(PaceCalculator::parseDuration)
        val previousDurationUnchanged = importedActivity == null && previousWasImported && previousDurationSeconds != null &&
            enteredDurationSeconds == previousDurationSeconds
        val actualDurationSeconds = when {
            importedActivity != null && importedElapsedSeconds != null && !importedDurationEdited -> importedElapsedSeconds
            importedActivity != null && importedDurationEdited -> enteredDurationSeconds
            importedActivity != null -> enteredDurationSeconds
            previousDurationUnchanged -> previousDurationSeconds
            else -> enteredDurationSeconds
        }
        val actualDurationForRecord = when {
            importedActivity != null && importedElapsedSeconds != null && !importedDurationEdited -> importedElapsedSeconds.let(PaceRange::formatDuration)
            importedActivity != null -> actualDurationText.takeIf { enteredDurationSeconds != null }
            previousDurationUnchanged -> previousForSession?.actualDuration
            else -> actualDurationText.takeIf { enteredDurationSeconds != null }
        }
        val actualPace = when {
            importedActivity?.averagePaceMmSs != null && !importedDistanceEdited && !importedDurationEdited -> importedActivity.averagePaceMmSs
            importedActivity == null && previousDistanceUnchanged && previousDurationUnchanged -> previousForSession?.actualPaceMinKm
            actualDistanceKm != null && actualDurationSeconds != null -> PaceCalculator.paceFromDistanceAndDuration(actualDistanceKm, actualDurationSeconds)?.let { PaceRange.format(it) }
            else -> null
        }
        val duplicate = importedActivity?.let { activity ->
            feedbackRecords.firstOrNull { it.activityFingerprint == activity.fingerprint && it.sessionId != current.sessionId }
        }
        if (duplicate != null) {
            motorError = "Esta atividade já está vinculada a outra sessão. Ela não será duplicada no histórico."
            persist()
            return false
        }
        val previousWorkouts = workouts
        val previousFeedbackRecords = feedbackRecords
        val previousRaceEvents = raceEvents
        val previousNeedsEngineRefresh = needsEngineRefresh
        val previousNeedsPacePlanRefresh = needsPacePlanRefresh
        val previousFeedbackHeadline = latestFeedbackHeadline
        val previousFeedbackAdvice = latestFeedbackAdvice
        workouts = workouts.map { workout ->
            if (workout.sessionId == current.sessionId) workout.copy(done = true) else workout
        }
        val record = FeedbackRecord(
            sessionId = current.sessionId, effort = effort, feeling = feeling, notes = notes, painPresent = painPresent,
            actualDistanceKm = actualDistanceKm, actualDuration = actualDurationForRecord, actualPaceMinKm = actualPace,
            talkTestPaceMmSs = TalkTestCalibrationRules.normalizeEntry(current.type, talkTestPaceText),
            workoutDateIso = current.scheduledDateIso,
            workoutType = current.type,
            workoutTitle = current.title,
            activitySourceFormat = importedActivity?.sourceFormat ?: previousForSession?.activitySourceFormat.orEmpty(),
            activityFingerprint = importedActivity?.fingerprint ?: previousForSession?.activityFingerprint.orEmpty(),
            activityStartedAtIso = if (importedActivity != null) importedActivity.startedAtIso.orEmpty()
                else previousForSession?.activityStartedAtIso.orEmpty(),
            realizedDateIso = importedActivity?.startedAtIso?.let(::localDateFromInstant)
                ?: if (importedActivity != null) linkedRaceDateIso ?: LocalDate.now().toString()
                else previousForSession?.realizedDateIso?.takeIf { it.isNotBlank() }
                    ?: previousForSession?.activityStartedAtIso?.let(::localDateFromInstant)
                    ?: linkedRaceDateIso
                    ?: LocalDate.now().toString(),
            terrain = RunningTerrain.normalize(terrain),
            raceEventId = raceEventId.takeIf { id ->
                actualDistanceKm != null && actualDurationSeconds != null && raceEvents.any { it.id == id }
            }.orEmpty(),
            recordedPaceSegments = if (importedActivity != null) importedActivity.paceSegments
                else previousForSession?.recordedPaceSegments.orEmpty(),
            measuredZoneTimeSeconds = if (importedActivity != null) {
                importedActivity.paceSegments.let(::measuredZoneTimeFromTrack)
            } else previousForSession?.measuredZoneTimeSeconds.orEmpty(),
            elevationGainMeters = if (importedActivity != null) importedActivity.elevationGainMeters else previousForSession?.elevationGainMeters,
            averageHeartRateBpm = if (importedActivity != null) importedActivity.averageHeartRateBpm else previousForSession?.averageHeartRateBpm,
            maxHeartRateBpm = if (importedActivity != null) importedActivity.maxHeartRateBpm else previousForSession?.maxHeartRateBpm,
            averageCadenceSpm = if (importedActivity != null) importedActivity.averageCadenceSpm else previousForSession?.averageCadenceSpm,
            maxCadenceSpm = if (importedActivity != null) importedActivity.maxCadenceSpm else previousForSession?.maxCadenceSpm,
            routePointCount = if (importedActivity != null) importedActivity.routePointCount else previousForSession?.routePointCount ?: 0,
            splitPacesMmSs = if (importedActivity != null) importedActivity.splitPacesMmSs else previousForSession?.splitPacesMmSs.orEmpty(),
            encodedRoute = if (importedActivity != null) importedActivity.encodedRoute else previousForSession?.encodedRoute.orEmpty()
        )
        feedbackRecords = feedbackRecords.filterNot { it.sessionId == current.sessionId } + record
        if (record.raceEventId.isNotBlank()) {
            raceEvents = raceEvents.map { event ->
                if (event.id == record.raceEventId) event.copy(status = "COMPLETED") else event
            }
            syncTargetDate()
        }
        val calibratedZonesAfterFeedback = currentPaceZones()
        rememberZoneBoundaries(calibratedZonesAfterFeedback)
        if (painPresent) {
            latestFeedbackHeadline = "Dor relatada • priorizar recuperação"
            latestFeedbackAdvice = "A dor bloqueia a progressão automática de carga e intensidade. Interrompa o estímulo que provoca dor e retome somente quando estiver recuperado."
        } else if (calibratedZonesAfterFeedback?.let { zones ->
                zones.z1CalibrationStatus == ZoneCalibrationEngine.CALIBRATED ||
                    zones.z2CalibrationStatus == ZoneCalibrationEngine.CALIBRATED ||
                    zones.z3CalibrationStatus == ZoneCalibrationEngine.CALIBRATED ||
                    zones.z1CalibrationStatus == ZoneCalibrationEngine.REVIEW ||
                    zones.z2CalibrationStatus == ZoneCalibrationEngine.REVIEW ||
                    zones.z3CalibrationStatus == ZoneCalibrationEngine.REVIEW
            } == true) {
            needsPacePlanRefresh = true
            latestFeedbackHeadline = "Calibração individual em atualização"
            latestFeedbackAdvice = "As evidências estão refinando as fronteiras em passos de até 15 segundos por atualização. Recalcule o plano para aplicar as faixas ativas quando a calibração estiver consistente."
        } else {
            val analysis = TrainingAdaptationEngine.analyzeRun(
                TrainingAdaptationEngine.RunResult(
                    distanceKm = actualDistanceKm,
                    plannedDistanceKm = current.distanceKm,
                    perceivedEffort = effort,
                    feeling = feeling,
                    plannedWorkoutType = current.type,
                    painReported = painPresent
                )
            )
            latestFeedbackHeadline = "Feedback registrado"
            latestFeedbackAdvice = analysis.nextStep
        }
        // Any feedback changes the recovery picture, even when the athlete did not
        // enter measured distance/time. Only real metrics are used in pace and volume charts.
        needsEngineRefresh = true
        if (actualDistanceKm != null) {
            latestFeedbackAdvice = (latestFeedbackAdvice + " A distância realizada foi salva no histórico; recalcule o plano para usar essa carga nas próximas semanas.").trim()
        } else {
            latestFeedbackAdvice = (latestFeedbackAdvice + " O feedback subjetivo foi salvo. Informe distância e tempo quando disponíveis para incluir métricas reais nos gráficos e na carga.").trim()
        }
        feedbackSaved = true
        motorError = ""
        // Commit synchronously: feedback is an athlete record and must survive
        // immediate process termination/app switching after the save action.
        try {
            persist(synchronous = true)
        } catch (error: Exception) {
            workouts = previousWorkouts
            feedbackRecords = previousFeedbackRecords
            raceEvents = previousRaceEvents
            syncTargetDate()
            feedbackSaved = feedbackRecords.isNotEmpty()
            needsEngineRefresh = previousNeedsEngineRefresh
            needsPacePlanRefresh = previousNeedsPacePlanRefresh
            latestFeedbackHeadline = previousFeedbackHeadline
            latestFeedbackAdvice = previousFeedbackAdvice
            motorError = "Não foi possível gravar o feedback no armazenamento do aparelho. Tente novamente."
            return false
        }
        return true
    }

    private fun localDateFromInstant(raw: String): String? = runCatching {
        Instant.parse(raw).atZone(ZoneId.systemDefault()).toLocalDate().toString()
    }.getOrNull()

    /** Actual activity date, never the scheduled date when a real activity timestamp exists. */
    fun feedbackActivityDate(record: FeedbackRecord): LocalDate = ActivityDateResolver.resolve(
        realizedDateIso = record.realizedDateIso,
        activityStartedAtIso = record.activityStartedAtIso,
        activitySourceFormat = record.activitySourceFormat,
        scheduledDateIso = record.workoutDateIso,
        savedAtMillis = record.savedAt
    )

    private fun recentFeedback(windowDays: Long = 14): List<FeedbackRecord> {
        val today = LocalDate.now()
        val cutoff = today.minusDays(windowDays)
        return feedbackRecords.filter { record ->
            val date = feedbackActivityDate(record)
            !date.isBefore(cutoff) && !date.isAfter(today)
        }.sortedBy(::feedbackActivityDate)
    }

    /** Live readiness card: recalculates immediately from the three latest feedbacks in 14 days. */
    fun readinessSnapshot(): AthleteReadinessSnapshot = AthleteReadinessEngine.evaluate(
        recentFeedback().takeLast(3).map { record ->
            ReadinessFeedback(
                effort = record.effort,
                feeling = record.feeling,
                painPresent = record.painPresent
            )
        }
    )

    private fun deriveRecoveryScore(): Double? = readinessSnapshot().recoveryScore

    private fun deriveFatigueScore(): Double? = readinessSnapshot().fatigueScore

    fun requestRestDayRecommendation(targetDate: LocalDate): RestDayRecommendation {
        scheduleActionMessage = ""
        val sessionEvidence = workouts.mapNotNull { workout ->
            val date = runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull() ?: return@mapNotNull null
            val hasFeedback = feedbackRecords.any { it.sessionId == workout.sessionId }
            RestDaySessionEvidence(
                sessionId = workout.sessionId,
                date = date,
                title = workout.title,
                type = workout.type,
                distanceKm = workout.distanceKm,
                done = workout.done || hasFeedback,
                optionalExtra = workout.isOptionalExtra
            )
        }
        val feedbackEvidence = feedbackRecords.map { record ->
            RestDayFeedbackEvidence(
                date = feedbackActivityDate(record),
                effort = record.effort,
                feeling = record.feeling,
                painPresent = record.painPresent,
                actualDistanceKm = record.actualDistanceKm
            )
        }
        val measuredActivities = feedbackRecords.mapNotNull { record ->
            val distance = record.actualDistanceKm ?: return@mapNotNull null
            LoggedRunActivity(feedbackActivityDate(record), distance)
        }
        val load = TrainingLoadEngine.summarize(measuredActivities, LocalDate.now())
        val profileLongest = (load.longestRunLast30DaysKm ?: longestRecent.trim().replace(",", ".").toDoubleOrNull())
        val profileWeeklyBaseline = (load.averageWeeklyKmLast28Days ?: weeklyVolumeText.trim().replace(",", ".").toDoubleOrNull())
        // Recovery-day scheduling follows demonstrated load tolerance, not the VO2 class.
        val profileIsNovice = (profileWeeklyBaseline ?: 0.0) < 4.0 || (profileLongest ?: 0.0) < 2.5
        val runningDaysLimit = TrainingScheduleEngine.prescribedRunningDays(
            availableTrainingDays, frequency, profileIsNovice, preferredLongRunDay
        ).size.coerceIn(2, 6)
        val recommendation = RestDayAdaptationEngine.recommend(
            targetDate = targetDate,
            today = LocalDate.now(),
            sessions = sessionEvidence,
            feedback = feedbackEvidence,
            raceDates = raceEvents.filter { it.status != "CANCELLED" }.mapNotNull { it.dateOrNull() }.toSet(),
            weeklyBaselineKm = profileWeeklyBaseline,
            longestRunLast30DaysKm = profileLongest,
            noviceOrReturner = profileIsNovice,
            maxWeeklySessions = runningDaysLimit
        )
        restDayRecommendation = recommendation
        persist()
        return recommendation
    }

    fun addRecommendedRestDayWorkout(option: String = "EASY"): Boolean {
        val recommendation = restDayRecommendation ?: return false
        if (!recommendation.canAddWorkout) return false
        val normalOption = option == "NORMAL"
        if (normalOption && !recommendation.normalAvailable) return false
        val date = recommendation.targetDate
        val dateIso = date.toString()
        val dateAlreadyHasWorkout = workouts.any { it.scheduledDateIso == dateIso }
        val dateHasRace = raceEvents.any { it.status != "CANCELLED" && it.dateOrNull() == date }
        if (dateAlreadyHasWorkout || dateHasRace) {
            restDayRecommendation = null
            scheduleActionMessage = "A consulta de treino extra é exclusiva para dias livres. Esta data recebeu um compromisso; nenhuma sessão foi adicionada."
            persist()
            return false
        }
        val selectedZone = if (normalOption) "Z2" else "Z1"
        val selectedDuration = if (normalOption) recommendation.normalDurationMin else recommendation.durationMin
        val selectedDistance = if (normalOption) recommendation.normalEstimatedDistanceKm else recommendation.estimatedDistanceKm
        val selectedRpe = if (normalOption) recommendation.normalRpeRange else recommendation.rpeRange
        val selectedIntensity = if (normalOption) "MODERATE" else "LOW"
        val zoneRange = currentPaceZones()?.all()?.firstOrNull { it.id == selectedZone }?.range
        fun segment(name: String, minutes: Int, instruction: String): WorkoutSegment = WorkoutSegment(
            name = name,
            instruction = instruction,
            durationMin = minutes,
            intensity = selectedIntensity,
            rpeRange = selectedRpe,
            targetMode = "TIME",
            targetPaceMinValue = zoneRange?.fastestPaceValue,
            targetPaceMaxValue = zoneRange?.slowestPaceValue,
            paceZone = zoneRange?.let { selectedZone },
            zoneBasePaceFastValue = zoneRange?.fastestPaceValue,
            zoneBasePaceSlowValue = zoneRange?.slowestPaceValue
        )
        val warmMinutes = 3
        val coolMinutes = 3
        val mainMinutes = (selectedDuration - warmMinutes - coolMinutes).coerceAtLeast(6)
        val segments = if (recommendation.runWalkPattern) {
            val repetitions = (mainMinutes / 3).coerceAtLeast(2)
            listOf(
                segment("Aquecimento com caminhada", warmMinutes, "Caminhe ativamente e inicie o trote somente se estiver confortável."),
                segment(if (normalOption) "Corrida aeróbia" else "Corrida leve", 2,
                    if (normalOption) "Mantenha Z2 confortável, sem transformar a sessão em treino de ritmo." else "Trote leve em Z1, com respiração tranquila.").copy(repeatCount = repetitions),
                WorkoutSegment("Caminhada", "Recupere caminhando sem pressa entre os trechos de corrida.", durationMin = 1, intensity = "LOW", rpeRange = "1-2", targetMode = "TIME", repeatCount = repetitions),
                segment("Desaquecimento", coolMinutes, "Finalize caminhando e reduza gradualmente o esforço.")
            )
        } else {
            listOf(
                segment("Aquecimento", warmMinutes, "Comece com caminhada ativa e trote muito leve."),
                segment(if (normalOption) "Rodagem aeróbia" else "Corrida leve adicional", mainMinutes,
                    if (normalOption) "Mantenha Z2 estável e confortável. Não faça progressões nem tente compensar sessões anteriores." else "Mantenha Z1 e conversa confortável. Não acelere nem tente compensar sessões anteriores."),
                segment("Desaquecimento", coolMinutes, "Reduza o esforço gradualmente até encerrar a sessão.")
            )
        }
        val runningMinutes = if (recommendation.runWalkPattern) 2 * ((mainMinutes / 3).coerceAtLeast(2)) else mainMinutes
        val paceForEstimate = zoneRange?.let { (it.fastestPaceValue + it.slowestPaceValue) / 2.0 } ?: 450.0
        val estimatedDistance = selectedDistance.takeIf { it > 0.0 } ?: if (zoneRange != null) {
            (runningMinutes * 60.0 / paceForEstimate).coerceAtLeast(0.5)
        } else 0.0
        val planMonday = runCatching { LocalDate.parse(planStartDateIso) }.getOrNull()
            ?.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            ?: LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val targetMonday = date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val weekNumber = (java.time.temporal.ChronoUnit.WEEKS.between(planMonday, targetMonday).toInt() + 1).coerceAtLeast(1)
        val dateLabel = "${date.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, Locale.forLanguageTag("pt-BR")).replaceFirstChar { it.uppercase(Locale.forLanguageTag("pt-BR")) }}, ${date.format(DateTimeFormatter.ofPattern("dd/MM"))}"
        val workout = Workout(
            date = dateLabel,
            scheduledDateIso = date.toString(),
            title = if (normalOption) "Rodagem aeróbia extra" else if (recommendation.runWalkPattern) "Corrida-caminhada leve extra" else "Rodagem leve extra",
            detail = if (normalOption) "Sessão aeróbia opcional em Z2, escolhida pelo corredor após visualizar a carga e os riscos." else "Sessão opcional curta em Z1, escolhida pelo corredor após visualizar a carga e os riscos.",
            type = if (normalOption) "Aeróbio" else "Recuperação",
            objective = if (normalOption) "Adicionar estímulo aeróbio controlado sem substituir sessões principais." else "Adicionar movimento leve sem comprometer a recuperação nem substituir as sessões principais.",
            stimulus = if (normalOption) "ADAPTIVE_OPTIONAL_REST_DAY_Z2" else "ADAPTIVE_OPTIONAL_REST_DAY_Z1",
            distanceKm = estimatedDistance,
            done = false,
            sessionId = "EXTRA-${java.util.UUID.randomUUID()}",
            durationMin = selectedDuration,
            intensity = selectedIntensity,
            paceMode = if (zoneRange != null) "PACE_RANGE" else "PACE_NOT_CALIBRATED",
            rpeRange = selectedRpe,
            rationale = recommendation.explanation + " Riscos apresentados antes da inclusão: ${recommendation.riskText}" + if (normalOption) " Opção normal: maior carga aeróbia e risco de fadiga superior à opção leve." else " Opção leve: menor carga e intensidade Z1.",
            week = weekNumber,
            phase = "ADAPTIVE_OPTIONAL",
            segments = segments,
            paceCalibrationSnapshot = currentPaceZones()?.let { zones ->
                PaceCalculator.createCalibrationSnapshot(
                    distanceKm = cooperAssessments.lastOrNull()?.distanceKm,
                    assessmentDateIso = cooperAssessments.lastOrNull()?.dateIso ?: LocalDate.now().toString(),
                    talkTestComfortPaces = recentTalkTestPaces(),
                    zonesOverride = zones
                )
            },
            isOptionalExtra = true
        )
        workouts = (workouts + ZoneIntensityBandEngine.apply(workout)).distinctBy { it.sessionId }.sortedBy { it.scheduledDateIso }
        selectedWorkoutIndex = workouts.indexOfFirst { it.sessionId == workout.sessionId }.coerceAtLeast(0)
        restDayRecommendation = null
        scheduleActionMessage = "${if (normalOption) "Rodagem aeróbia" else "Sessão leve"} adicional incluída em $dateLabel. Os treinos principais não foram alterados."
        persist(synchronous = true)
        return true
    }

    fun selectWorkout(workout: Workout) {
        // Calendar entries may be derived alternatives; resolve by stable session ID, not full data-class equality.
        val index = workouts.indexOfFirst { it.sessionId == workout.sessionId }
        if (index >= 0) selectedWorkoutIndex = index
        navigateTo(Screen.WORKOUT)
    }

    fun persist(synchronous: Boolean = false) {
        val e = prefs.edit()
            .remove("benchmarkEnabled")
            .remove("benchmarkDistanceText")
            .remove("benchmarkTimeText")
            .putString("name", name)
            .putString("goal", goal)
            .putString("goalIntent", goalIntent)
            .putString("goalTargetTimeText", goalTargetTimeText)
            .putString("terrainPreference", terrainPreference)
            .putString("customGoalKm", customGoalKm)
            .putString("level", level)
            .putInt("frequency", frequency)
            .putString("availableTrainingDays", availableTrainingDays.joinToString(",") { it.name })
            .putString("preferredLongRunDay", preferredLongRunDay?.name ?: "")
            .putString("targetDate", targetDate)
            .putString("planStartDateIso", planStartDateIso)
            .putString("racePlanNote", racePlanNote)
            .putString("racePlanWarnings", JSONArray(racePlanWarnings).toString())
            .putString("raceEvents", JSONArray().apply {
                raceEvents.forEach { event -> put(JSONObject().apply {
                    put("id", event.id); put("name", event.name); put("distanceKm", event.distanceKm)
                    put("eventDateIso", event.eventDateIso); put("priority", event.priority)
                    put("targetTime", event.targetTime); put("location", event.location)
                    put("notes", event.notes); put("status", event.status)
                }) }
            }.toString())
            .putString("volume", volume)
            .putString("weeklyVolumeText", weeklyVolumeText)
            .putString("longestRecent", longestRecent)
            .putString("runningExperienceDuration", runningExperienceDuration)
            .putString("ageYearsText", ageYearsText)
            .putString("referenceSex", referenceSex)
            .putString("fitnessTestMethod", fitnessTestMethod)
            .putString("threeKmTimeText", threeKmTimeText)
            .putInt("activeWeeksLast4", activeWeeksLast4)
            .putBoolean("cooperEnabled", cooperEnabled)
            .putString("cooperDistanceText", cooperDistanceText)
            .putString("cooperAssessmentDateText", cooperAssessmentDateText)
            .putString("latestCooperMessage", latestCooperMessage)
            .putInt("onboardingStep", onboardingStep)
            .putInt("selectedScreen", selectedScreen.ordinal)
            .putInt("selectedWorkoutIndex", selectedWorkoutIndex)
            .putInt("planWeeks", planWeeks)
            .putString("latestFeedbackHeadline", latestFeedbackHeadline)
            .putString("latestFeedbackAdvice", latestFeedbackAdvice)
            .putString("motorExplanation", motorExplanation)
            .putString("motorError", motorError)
            .putBoolean("needsPacePlanRefresh", needsPacePlanRefresh)
            .putBoolean("needsEngineRefresh", needsEngineRefresh)

        lastZoneBoundarySnapshot?.let { boundaries ->
            e.putString("lastZoneBoundarySnapshot", JSONArray(boundaries).toString())
        } ?: e.remove("lastZoneBoundarySnapshot")

        motorState?.let { ms ->
            e.putString("motorState", JSONObject().apply {
                put("fitnessConfidence", ms.fitnessConfidence)
                put("paceConfidence", ms.paceConfidence)
                put("recentVolumeKm", ms.recentVolumeKm)
                put("recentLongRunKm", ms.recentLongRunKm)
                put("recoveryStatus", ms.recoveryStatus)
                put("safetyStatus", ms.safetyStatus)
                put("phase", ms.phase)
                put("flags", JSONArray(ms.flags))
            }.toString())
        }
        motorDecision?.let { md ->
            e.putString("motorDecision", JSONObject().apply {
                put("action", md.action)
                put("necessity", md.necessity)
                put("stimulus", md.stimulus)
                put("rationale", md.rationale)
                put("confidence", md.confidence)
                put("safety", md.safety)
            }.toString())
        }
        val arr = JSONArray()
        workouts.forEach { w ->
            arr.put(JSONObject().apply {
                put("date", w.date); put("scheduledDateIso", w.scheduledDateIso); put("title", w.title); put("detail", w.detail)
                put("type", w.type); put("objective", w.objective); put("stimulus", w.stimulus)
                put("distanceKm", w.distanceKm); put("done", w.done); put("sessionId", w.sessionId)
                put("durationMin", w.durationMin); put("intensity", w.intensity); put("paceMode", w.paceMode)
                put("rpeRange", w.rpeRange); put("rationale", w.rationale); put("week", w.week)
                put("phase", w.phase)
                put("manuallyRescheduled", w.manuallyRescheduled)
                put("originalScheduledDateIso", w.originalScheduledDateIso)
                put("selectedOption", w.selectedOption)
                put("isOptionalExtra", w.isOptionalExtra)
                w.paceCalibrationSnapshot?.let { snapshot ->
                    put("paceCalibration", JSONObject().apply {
                        put("assessmentDateIso", snapshot.assessmentDateIso)
                        put("distanceKm", snapshot.distanceKm)
                        put("averagePaceMmSs", snapshot.averagePaceMmSs)
                        put("estimatedVo2Max", snapshot.estimatedVo2Max)
                        put("estimatedMasPaceMmSs", snapshot.estimatedMasPaceMmSs)
                        put("estimatedSvt2PaceMmSs", snapshot.estimatedSvt2PaceMmSs)
                        put("modelVersion", snapshot.modelVersion)
                        put("z2CalibrationStatus", snapshot.z2CalibrationStatus)
                        put("talkTestEvidenceCount", snapshot.talkTestEvidenceCount)
                        put("talkTestReferencePaceMmSs", snapshot.talkTestReferencePaceMmSs)
                        put("z1CalibrationStatus", snapshot.z1CalibrationStatus); put("z1CalibrationEvidenceCount", snapshot.z1CalibrationEvidenceCount)
                        put("z2CalibrationEvidenceCount", snapshot.z2CalibrationEvidenceCount)
                        put("z3CalibrationStatus", snapshot.z3CalibrationStatus); put("z3CalibrationEvidenceCount", snapshot.z3CalibrationEvidenceCount)
                        put("zoneRanges", JSONObject().apply { snapshot.zoneRanges.forEach { (id, range) -> put(id, range) } })
                    })
                }
                put("segments", JSONArray().apply {
                    w.segments.forEach { segment -> put(JSONObject().apply {
                        put("name", segment.name); put("instruction", segment.instruction)
                        if (segment.durationMin != null) put("durationMin", segment.durationMin)
                        if (segment.distanceKm != null) put("distanceKm", segment.distanceKm)
                        put("intensity", segment.intensity); put("rpeRange", segment.rpeRange)
                        put("repeatCount", segment.repeatCount); put("targetMode", segment.targetMode)
                        segment.targetPaceMinValue?.let { put("paceFasterMinKm", PaceRange.format(it)) }
                        segment.targetPaceMaxValue?.let { put("paceSlowerMinKm", PaceRange.format(it)) }
                        segment.paceZone?.let { put("paceZone", it) }
                        segment.zoneBasePaceFastValue?.let { put("zoneBasePaceFastMinKm", PaceRange.format(it)) }
                        segment.zoneBasePaceSlowValue?.let { put("zoneBasePaceSlowMinKm", PaceRange.format(it)) }
                        segment.zoneIntensityMinPercent?.let { put("zoneIntensityMinPercent", it) }
                        segment.zoneIntensityMaxPercent?.let { put("zoneIntensityMaxPercent", it) }
                        segment.goalPaceReferenceSecondsPerKm?.let { put("goalPaceReferenceSecondsPerKm", it) }
                    }) }
                })
            })
        }
        val feedbackArray = JSONArray()
        feedbackRecords.forEach { feedback -> feedbackArray.put(JSONObject().apply {
            put("sessionId", feedback.sessionId); put("effort", feedback.effort)
            put("feeling", feedback.feeling); put("notes", feedback.notes); put("painPresent", feedback.painPresent)
            feedback.actualDistanceKm?.let { put("actualDistanceKm", it) }
            feedback.actualDuration?.let { put("actualDuration", it) }
            feedback.actualPaceMinKm?.let { put("actualPaceMinKm", it) }
            feedback.talkTestPaceMmSs?.let { put("talkTestPaceMmSs", it) }
            put("workoutDateIso", feedback.workoutDateIso)
            put("workoutType", feedback.workoutType)
            put("workoutTitle", feedback.workoutTitle)
            put("savedAt", feedback.savedAt)
            put("activitySourceFormat", feedback.activitySourceFormat)
            put("activityFingerprint", feedback.activityFingerprint)
            put("activityStartedAtIso", feedback.activityStartedAtIso)
            put("realizedDateIso", feedback.realizedDateIso)
            put("terrain", RunningTerrain.normalize(feedback.terrain))
            put("raceEventId", feedback.raceEventId)
            put("recordedPaceSegments", JSONArray().apply {
                feedback.recordedPaceSegments.forEach { segment -> put(JSONObject().apply {
                    put("paceSecondsPerKm", segment.paceSecondsPerKm)
                    put("durationSeconds", segment.durationSeconds)
                }) }
            })
            put("measuredZoneTimeSeconds", JSONObject().apply {
                feedback.measuredZoneTimeSeconds.forEach { (zone, seconds) -> put(zone, seconds) }
            })
            feedback.elevationGainMeters?.let { put("elevationGainMeters", it) }
            feedback.averageHeartRateBpm?.let { put("averageHeartRateBpm", it) }
            feedback.maxHeartRateBpm?.let { put("maxHeartRateBpm", it) }
            feedback.averageCadenceSpm?.let { put("averageCadenceSpm", it) }
            feedback.maxCadenceSpm?.let { put("maxCadenceSpm", it) }
            put("routePointCount", feedback.routePointCount)
            put("splitPacesMmSs", JSONArray(feedback.splitPacesMmSs))
            put("encodedRoute", feedback.encodedRoute)
        }) }
        e.putString("feedbackRecords", feedbackArray.toString())
        e.putString("workouts", arr.toString())
        e.putString("cooperAssessments", JSONArray().apply {
            cooperAssessments.forEach { record -> put(JSONObject().apply {
                put("dateIso", record.dateIso); put("distanceKm", record.distanceKm)
                put("testMethod", record.testMethod); record.testDurationSeconds?.let { put("testDurationSeconds", it) }
                put("referenceSex", record.referenceSex); record.ageAtTest?.let { put("ageAtTest", it) }
                put("estimatedVo2Max", record.estimatedVo2Max)
                put("averagePace", record.averagePace)
                put("estimatedMasPace", record.estimatedMasPace)
                put("estimatedSvt2Pace", record.estimatedSvt2Pace)
                put("zoneModelVersion", record.zoneModelVersion)
                put("z2CalibrationStatus", record.z2CalibrationStatus)
                put("talkTestEvidenceCount", record.talkTestEvidenceCount)
                put("talkTestReferencePaceMmSs", record.talkTestReferencePaceMmSs)
                put("z1CalibrationStatus", record.z1CalibrationStatus); put("z1CalibrationEvidenceCount", record.z1CalibrationEvidenceCount)
                put("z3CalibrationStatus", record.z3CalibrationStatus); put("z3CalibrationEvidenceCount", record.z3CalibrationEvidenceCount)
                put("zoneRanges", JSONObject().apply { record.zoneRanges.forEach { (zone, range) -> put(zone, range) } })
            }) }
        }.toString())
        if (synchronous) check(e.commit()) { "Não foi possível salvar os dados da sessão no aparelho." } else e.apply()
    }

    fun exportBackup(uri: Uri): BackupOperationResult {
        val result = AppBackupManager.export(context, uri)
        backupMessage = result.message
        return result
    }

    fun restoreBackup(uri: Uri): BackupOperationResult {
        val result = AppBackupManager.restore(context, uri)
        if (!result.success) {
            backupMessage = result.message
            return result
        }
        navigationHistory.clear()
        load()
        val importedEngineVersion = prefs.getInt("engineVersion", 0)
        val completedBeforeMigration = completedWorkouts().size
        var migrationMessage = ""
        // A legacy backup is not merely reopened: its unfinished plan is regenerated
        // with the current adaptive model while all completed sessions and feedback remain.
        if (PlanMigrationEngine.requiresMigration(importedEngineVersion, CURRENT_ENGINE_VERSION, workouts.isNotEmpty())) {
            needsEngineRefresh = true
            val beginnerProfile = RunnerFitnessAssessmentEngine.normalizeLevel(level) == "Iniciante"
            val profileReady = goal.isNotBlank() && level.isNotBlank() &&
                goal in TrainingGoalCatalog.labelsForLevel(level) &&
                availableTrainingDays.size in 2..6 && frequency == availableTrainingDays.size &&
                (beginnerProfile || (weeklyVolumeText.isNotBlank() && longestRecent.isNotBlank()))
            if (profileReady) {
                val migrated = createPlan(preserveCycleAnchor = true)
                migrationMessage = if (migrated) {
                    " Plano atualizado a partir da âncora original do backup; $completedBeforeMigration sessão(ões) concluída(s), feedbacks e avaliações foram preservados. Sessões históricas existentes no arquivo foram mantidas; nenhuma sessão passada ausente foi inventada."
                } else {
                    " O backup foi restaurado e o plano anterior foi preservado, mas a migração automática não pôde ser concluída: ${motorError.ifBlank { "revise o perfil e tente recalcular" }}"
                }
            } else {
                migrationMessage = " O backup foi restaurado com o plano e o histórico preservados. Complete os dados do perfil para migrar as sessões futuras ao novo treinador."
            }
        }
        navigationHistory.clear()
        selectedScreen = Screen.BACKUP
        selectedWorkoutIndex = 0
        onboardingStep = 8
        persist(synchronous = true)
        backupMessage = result.message + migrationMessage
        return BackupOperationResult(true, backupMessage)
    }

    private fun load() {
        // Reset collection/nullable state first. This is also used after restoring an
        // intentionally empty backup, so values from the previous installation cannot leak.
        raceEvents = emptyList()
        racePlanWarnings = emptyList()
        workouts = emptyList()
        feedbackRecords = emptyList()
        cooperAssessments = emptyList()
        lastZoneBoundarySnapshot = null
        motorState = null
        motorDecision = null
        name = prefs.getString("name", "") ?: ""
        goal = prefs.getString("goal", "") ?: ""
        goalIntent = TrainingGoalIntent.normalize(prefs.getString("goalIntent", TrainingGoalIntent.COMPLETE) ?: TrainingGoalIntent.COMPLETE, goal == "Saúde e qualidade de vida")
        goalTargetTimeText = prefs.getString("goalTargetTimeText", "") ?: ""
        terrainPreference = RunningTerrain.normalize(prefs.getString("terrainPreference", RunningTerrain.ROAD) ?: RunningTerrain.ROAD)
        customGoalKm = prefs.getString("customGoalKm", "") ?: ""
        level = prefs.getString("level", "") ?: ""
        frequency = prefs.getInt("frequency", 0)
        availableTrainingDays = prefs.getString("availableTrainingDays", "")?.split(",")
            ?.mapNotNull { value -> runCatching { DayOfWeek.valueOf(value) }.getOrNull() }
            ?.distinct()?.sortedBy { it.value }
            ?.takeIf { it.size in 2..6 }
            ?: if (frequency in 2..6) TrainingScheduleEngine.defaultDays(frequency) else emptyList()
        if (availableTrainingDays.isNotEmpty()) frequency = availableTrainingDays.size
        preferredLongRunDay = prefs.getString("preferredLongRunDay", "")?.takeIf { it.isNotBlank() }
            ?.let { runCatching { DayOfWeek.valueOf(it) }.getOrNull() }
            ?.takeIf { it in availableTrainingDays }
            ?: availableTrainingDays.firstOrNull { it == DayOfWeek.SUNDAY }
            ?: availableTrainingDays.lastOrNull()
        targetDate = prefs.getString("targetDate", "Sem prova principal") ?: "Sem prova principal"
        planStartDateIso = prefs.getString("planStartDateIso", "") ?: ""
        racePlanNote = prefs.getString("racePlanNote", "") ?: ""
        racePlanWarnings = prefs.getString("racePlanWarnings", null)?.let { raw -> runCatching {
            val array = JSONArray(raw); buildList { for (i in 0 until array.length()) add(array.optString(i)) }
        }.getOrDefault(emptyList()) } ?: emptyList()
        prefs.getString("raceEvents", null)?.let { raw -> runCatching {
            val array = JSONArray(raw)
            raceEvents = buildList { for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                add(RaceEvent(
                    id = item.optString("id"), name = item.optString("name"), distanceKm = item.optDouble("distanceKm"),
                    eventDateIso = item.optString("eventDateIso"), priority = item.optString("priority", "A"),
                    targetTime = item.optString("targetTime"), location = item.optString("location"),
                    notes = item.optString("notes"), status = item.optString("status", "PLANNED")
                ))
            } }
        } }
        volume = prefs.getString("volume", "") ?: ""
        weeklyVolumeText = prefs.getString("weeklyVolumeText", "") ?: ""
        longestRecent = prefs.getString("longestRecent", "") ?: ""
        runningExperienceDuration = prefs.getString("runningExperienceDuration", "") ?: ""
        ageYearsText = prefs.getString("ageYearsText", "") ?: ""
        referenceSex = prefs.getString("referenceSex", "") ?: ""
        fitnessTestMethod = prefs.getString("fitnessTestMethod", if (prefs.getBoolean("cooperEnabled", false)) "COOPER_12_MIN" else "NONE") ?: "NONE"
        threeKmTimeText = prefs.getString("threeKmTimeText", "") ?: ""
        activeWeeksLast4 = -1 // Removed from onboarding; rely on logged activity history.

        cooperEnabled = prefs.getBoolean("cooperEnabled", false)
        cooperDistanceText = prefs.getString("cooperDistanceText", "") ?: ""
        cooperAssessmentDateText = prefs.getString("cooperAssessmentDateText", LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/uuuu"))) ?: LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/uuuu"))
        latestCooperMessage = prefs.getString("latestCooperMessage", "") ?: ""
        // Migra opções antigas (ex.: "5 km" e "Mais de 10 km") para valor editável.
        longestRecent = when {
            longestRecent.startsWith("Mais", ignoreCase = true) -> "" // faixa aberta não é distância medida; exige revisão manual
            longestRecent.contains("km", ignoreCase = true) -> longestRecent.substringBefore(" ").trim()
            else -> longestRecent
        }
        onboardingStep = prefs.getInt("onboardingStep", if (goal.isBlank()) -1 else 1).coerceIn(-1, 8)
        selectedWorkoutIndex = prefs.getInt("selectedWorkoutIndex", 0)
        planWeeks = prefs.getInt("planWeeks", 8)
        needsEngineRefresh = prefs.getBoolean("needsEngineRefresh", false) || (prefs.getInt("engineVersion", 0) < CURRENT_ENGINE_VERSION && prefs.getString("workouts", null) != null)
        needsPacePlanRefresh = prefs.getBoolean("needsPacePlanRefresh", false)
        lastZoneBoundarySnapshot = prefs.getString("lastZoneBoundarySnapshot", null)?.let { raw -> runCatching {
            val array = JSONArray(raw)
            if (array.length() != 6) null else buildList { for (i in 0 until array.length()) add(array.optInt(i, -1)) }
                .takeIf { values -> values.all { it in 120..1800 } }
        }.getOrNull() }
        motorExplanation = prefs.getString("motorExplanation", "") ?: ""
        latestFeedbackHeadline = prefs.getString("latestFeedbackHeadline", "") ?: ""
        latestFeedbackAdvice = prefs.getString("latestFeedbackAdvice", "") ?: ""
        motorError = prefs.getString("motorError", "") ?: ""
        selectedScreen = Screen.entries.getOrNull(prefs.getInt("selectedScreen", Screen.DASHBOARD.ordinal)) ?: Screen.DASHBOARD

        prefs.getString("motorState", null)?.let { raw -> runCatching {
            val o = JSONObject(raw)
            motorState = MotorState(
                fitnessConfidence = o.optString("fitnessConfidence"),
                paceConfidence = o.optString("paceConfidence"),
                recentVolumeKm = o.optDouble("recentVolumeKm"),
                recentLongRunKm = o.optDouble("recentLongRunKm"),
                recoveryStatus = o.optString("recoveryStatus"),
                safetyStatus = o.optString("safetyStatus"),
                phase = o.optString("phase"),
                flags = buildList { val a=o.optJSONArray("flags"); if (a != null) for (i in 0 until a.length()) add(a.optString(i)) }
            )
        }}
        prefs.getString("motorDecision", null)?.let { raw -> runCatching {
            val o = JSONObject(raw)
            motorDecision = MotorDecision(
                action = o.optString("action"), necessity = o.optString("necessity"), stimulus = o.optString("stimulus"),
                rationale = o.optString("rationale"), confidence = o.optDouble("confidence"), safety = o.optString("safety")
            )
        }}
        prefs.getString("workouts", null)?.let { raw -> runCatching {
            val a = JSONArray(raw)
            workouts = buildList {
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    add(Workout(
                        date=o.optString("date"), scheduledDateIso=o.optString("scheduledDateIso").ifBlank {
                            LegacyWorkoutDateMigration.resolve(o.optString("date"), planStartDateIso)
                        }, title=o.optString("title"), detail=o.optString("detail"), type=o.optString("type"),
                        objective=o.optString("objective"), stimulus=o.optString("stimulus"), distanceKm=o.optDouble("distanceKm"),
                        done=o.optBoolean("done"), sessionId=o.optString("sessionId"), durationMin=o.optInt("durationMin"),
                        intensity=o.optString("intensity", "LOW"), paceMode=o.optString("paceMode", "PACE_NOT_CALIBRATED"),
                        rpeRange=o.optString("rpeRange", "3-4"), rationale=o.optString("rationale"),
                        week=o.optInt("week",1), phase=o.optString("phase", "BASE"),
                        manuallyRescheduled=o.optBoolean("manuallyRescheduled", false), originalScheduledDateIso=o.optString("originalScheduledDateIso", ""), selectedOption=o.optString("selectedOption", "PRIMARY"),
                        isOptionalExtra=o.optBoolean("isOptionalExtra", false),
                        paceCalibrationSnapshot=o.optJSONObject("paceCalibration")?.let { calibration ->
                            val ranges = calibration.optJSONObject("zoneRanges")
                            PaceCalibrationSnapshot(
                                assessmentDateIso = calibration.optString("assessmentDateIso"),
                                distanceKm = calibration.optDouble("distanceKm"),
                                averagePaceMmSs = calibration.optString("averagePaceMmSs"),
                                estimatedVo2Max = calibration.optDouble("estimatedVo2Max"),
                                estimatedMasPaceMmSs = calibration.optString("estimatedMasPaceMmSs"),
                                estimatedSvt2PaceMmSs = calibration.optString("estimatedSvt2PaceMmSs"),
                                modelVersion = calibration.optString("modelVersion", "AIRC_ZONES_1_LEGACY"),
                                z2CalibrationStatus = calibration.optString("z2CalibrationStatus", "COOPER_INITIAL"),
                                talkTestEvidenceCount = calibration.optInt("talkTestEvidenceCount", 0),
                                talkTestReferencePaceMmSs = calibration.optString("talkTestReferencePaceMmSs", ""),
                                z1CalibrationStatus = calibration.optString("z1CalibrationStatus", ZoneCalibrationEngine.INITIAL),
                                z1CalibrationEvidenceCount = calibration.optInt("z1CalibrationEvidenceCount", 0),
                                z2CalibrationEvidenceCount = calibration.optInt("z2CalibrationEvidenceCount", 0),
                                z3CalibrationStatus = calibration.optString("z3CalibrationStatus", ZoneCalibrationEngine.INITIAL),
                                z3CalibrationEvidenceCount = calibration.optInt("z3CalibrationEvidenceCount", 0),
                                zoneRanges = if (ranges == null) emptyMap() else buildMap {
                                    for (id in listOf("Z1", "Z2", "Z3", "Z4", "Z5")) ranges.optString(id).takeIf { it.isNotBlank() }?.let { put(id, it) }
                                }
                            )
                        },
                        segments=buildList {
                            val segmentArray = o.optJSONArray("segments")
                            if (segmentArray != null) for (j in 0 until segmentArray.length()) {
                                val item = segmentArray.optJSONObject(j) ?: continue
                                add(WorkoutSegment(
                                    name=item.optString("name"), instruction=item.optString("instruction"),
                                    durationMin=if (item.has("durationMin")) item.optInt("durationMin") else null,
                                    distanceKm=if (item.has("distanceKm")) item.optDouble("distanceKm") else null,
                                    intensity=item.optString("intensity", "LOW"), rpeRange=item.optString("rpeRange", "2-3"),
                                    repeatCount=item.optInt("repeatCount", 1),
                                    targetMode=item.optString("targetMode", if (item.has("durationMin")) "TIME" else "DISTANCE"),
                                    targetPaceMinValue=item.optString("paceFasterMinKm").takeIf { it.isNotBlank() }?.let { PaceRange.parsePace(it) },
                                    targetPaceMaxValue=item.optString("paceSlowerMinKm").takeIf { it.isNotBlank() }?.let { PaceRange.parsePace(it) },
                                    paceZone=item.optString("paceZone").takeIf { it.isNotBlank() },
                                    zoneBasePaceFastValue=item.optString("zoneBasePaceFastMinKm").takeIf { it.isNotBlank() }?.let { PaceRange.parsePace(it) },
                                    zoneBasePaceSlowValue=item.optString("zoneBasePaceSlowMinKm").takeIf { it.isNotBlank() }?.let { PaceRange.parsePace(it) },
                                    zoneIntensityMinPercent=if (item.has("zoneIntensityMinPercent")) item.optInt("zoneIntensityMinPercent") else null,
                                    zoneIntensityMaxPercent=if (item.has("zoneIntensityMaxPercent")) item.optInt("zoneIntensityMaxPercent") else null,
                                    goalPaceReferenceSecondsPerKm=if (item.has("goalPaceReferenceSecondsPerKm")) item.optInt("goalPaceReferenceSecondsPerKm") else null
                                ))
                            }
                        }
                    ))
                }
            }
        }}
        // Repair session estimates persisted by V41. Older plans could show only
        // the minutes from TIME segments and omit the run time of DISTANCE segments.
        var durationEstimateMigrated = false
        workouts = workouts.map { saved ->
            if (saved.segments.isEmpty()) saved else {
                val corrected = WorkoutDurationEstimator.estimateMinutes(saved.segments, saved.distanceKm, saved.durationMin)
                if (corrected != saved.durationMin) durationEstimateMigrated = true
                saved.copy(durationMin = corrected)
            }
        }

        // V40 stored the current partial week as 0 and shifted all later weeks down.
        // Migrate saved cards immediately so export/periodization labels are correct
        // even before the athlete taps the recommended recalculation action.
        val migrateV40WeekNumbering = prefs.getInt("engineVersion", 0) == 32 && workouts.isNotEmpty()
        if (migrateV40WeekNumbering) {
            workouts = workouts.map { it.copy(week = TrainingScheduleEngine.migrateV40WeekIndex(it.week)) }
            needsEngineRefresh = true
        }
        // Mark V43 duration/navigation migration complete only when every saved session has
        // structured blocks that were eligible for recalculation.
        val markEngineV35 = workouts.isNotEmpty() && workouts.all { it.segments.isNotEmpty() } &&
            prefs.getInt("engineVersion", 0) < 35
        val activeZoneBandMigration = workouts.any { workout ->
            !workout.done && workout.segments.any { it.paceZone != null && it.targetPaceMinValue != null && it.zoneIntensityMinPercent == null }
        } && prefs.getInt("engineVersion", 0) < 36
        if (markEngineV35) prefs.edit().putInt("engineVersion", 35).apply()

        prefs.getString("feedbackRecords", null)?.let { raw -> runCatching {
            val a = JSONArray(raw)
            feedbackRecords = buildList {
                for (i in 0 until a.length()) {
                    val item = a.optJSONObject(i) ?: continue
                    add(FeedbackRecord(
                        sessionId = item.optString("sessionId"), effort = item.optString("effort"),
                        feeling = item.optString("feeling"), notes = item.optString("notes"),
                        painPresent = item.optBoolean("painPresent", false),
                        actualDistanceKm = if (item.has("actualDistanceKm")) item.optDouble("actualDistanceKm") else null,
                        savedAt = item.optLong("savedAt", System.currentTimeMillis()).takeIf { it > 0L } ?: System.currentTimeMillis(),
                        actualDuration = item.optString("actualDuration").takeIf { it.isNotBlank() },
                        actualPaceMinKm = item.optString("actualPaceMinKm").takeIf { it.isNotBlank() },
                        talkTestPaceMmSs = item.optString("talkTestPaceMmSs").takeIf { it.isNotBlank() },
                        workoutDateIso = item.optString("workoutDateIso"),
                        workoutType = item.optString("workoutType"),
                        workoutTitle = item.optString("workoutTitle"),
                        activitySourceFormat = item.optString("activitySourceFormat"),
                        activityFingerprint = item.optString("activityFingerprint"),
                        activityStartedAtIso = item.optString("activityStartedAtIso"),
                        realizedDateIso = item.optString("realizedDateIso"),
                        terrain = RunningTerrain.normalize(item.optString("terrain", RunningTerrain.MIXED)),
                        raceEventId = item.optString("raceEventId"),
                        recordedPaceSegments = item.optJSONArray("recordedPaceSegments")?.let { segments -> buildList {
                            for (index in 0 until segments.length()) {
                                val segment = segments.optJSONObject(index) ?: continue
                                val pace = segment.optInt("paceSecondsPerKm", 0)
                                val seconds = segment.optInt("durationSeconds", 0)
                                if (pace in 120..1800 && seconds in 1..120) add(ActivityPaceSegment(pace, seconds))
                            }
                        } }.orEmpty(),
                        measuredZoneTimeSeconds = item.optJSONObject("measuredZoneTimeSeconds")?.let { measured -> buildMap {
                            measured.keys().forEach { zone ->
                                val seconds = measured.optInt(zone, 0)
                                if (zone in setOf("Z1", "Z2", "Z3", "Z4", "Z5") && seconds > 0) put(zone, seconds)
                            }
                        } }.orEmpty(),
                        elevationGainMeters = if (item.has("elevationGainMeters")) item.optDouble("elevationGainMeters") else null,
                        averageHeartRateBpm = if (item.has("averageHeartRateBpm")) item.optInt("averageHeartRateBpm") else null,
                        maxHeartRateBpm = if (item.has("maxHeartRateBpm")) item.optInt("maxHeartRateBpm") else null,
                        averageCadenceSpm = if (item.has("averageCadenceSpm")) item.optInt("averageCadenceSpm") else null,
                        maxCadenceSpm = if (item.has("maxCadenceSpm")) item.optInt("maxCadenceSpm") else null,
                        routePointCount = item.optInt("routePointCount", 0),
                        splitPacesMmSs = item.optJSONArray("splitPacesMmSs")?.let { splits -> buildList { for (index in 0 until splits.length()) add(splits.optString(index)) } }.orEmpty(),
                        encodedRoute = item.optString("encodedRoute")
                    ))
                }
            }
        } }
        prefs.getString("cooperAssessments", null)?.let { raw -> runCatching {
            val a = JSONArray(raw)
            cooperAssessments = buildList {
                for (i in 0 until a.length()) {
                    val item = a.optJSONObject(i) ?: continue
                    val distanceKm = item.optDouble("distanceKm")
                    val calculatedSnapshot = PaceCalculator.calculateCooper(distanceKm)
                    val storedRanges = item.optJSONObject("zoneRanges")
                    val storedModelVersion = item.optString("zoneModelVersion")
                    val zoneRanges = if (storedRanges != null) {
                        buildMap { for (key in listOf("Z1", "Z2", "Z3", "Z4", "Z5")) {
                            storedRanges.optString(key).takeIf { it.isNotBlank() }?.let { put(key, it) }
                        } }
                    } else calculatedSnapshot?.all()?.associate { it.id to it.range.label() }.orEmpty()
                    val resolvedModelVersion = when {
                        storedModelVersion.isNotBlank() -> storedModelVersion
                        storedRanges != null -> "AIRC_ZONES_1_LEGACY"
                        else -> calculatedSnapshot?.modelVersion ?: PaceCalculator.ZONE_MODEL_VERSION
                    }
                    val isCurrentZoneModel = resolvedModelVersion == PaceCalculator.ZONE_MODEL_VERSION
                    add(CooperAssessmentRecord(
                        dateIso = item.optString("dateIso"), distanceKm = distanceKm,
                        estimatedVo2Max = item.optDouble("estimatedVo2Max", calculatedSnapshot?.estimatedVo2Max ?: 0.0),
                        averagePace = item.optString("averagePace", calculatedSnapshot?.averageTestPaceValue?.let { PaceRange.format(it) } ?: ""),
                        estimatedMasPace = if (isCurrentZoneModel) item.optString("estimatedMasPace", calculatedSnapshot?.estimatedMasPace ?: "") else "",
                        estimatedSvt2Pace = if (isCurrentZoneModel) item.optString("estimatedSvt2Pace", calculatedSnapshot?.estimatedSvt2Pace ?: "") else "",
                        zoneModelVersion = resolvedModelVersion,
                        zoneRanges = zoneRanges,
                        z2CalibrationStatus = item.optString("z2CalibrationStatus", "COOPER_INITIAL"),
                        talkTestEvidenceCount = item.optInt("talkTestEvidenceCount", 0),
                        talkTestReferencePaceMmSs = item.optString("talkTestReferencePaceMmSs", ""),
                        z1CalibrationStatus = item.optString("z1CalibrationStatus", ZoneCalibrationEngine.INITIAL),
                        z1CalibrationEvidenceCount = item.optInt("z1CalibrationEvidenceCount", 0),
                        z3CalibrationStatus = item.optString("z3CalibrationStatus", ZoneCalibrationEngine.INITIAL),
                        z3CalibrationEvidenceCount = item.optInt("z3CalibrationEvidenceCount", 0),
                        testMethod = item.optString("testMethod", "COOPER_12_MIN"),
                        testDurationSeconds = if (item.has("testDurationSeconds")) item.optInt("testDurationSeconds") else null,
                        referenceSex = item.optString("referenceSex", ""),
                        ageAtTest = if (item.has("ageAtTest")) item.optInt("ageAtTest") else null
                    ))
                }
            }.sortedBy { it.dateIso }
        } }
        if (!prefs.contains("fitnessTestMethod") || (fitnessTestMethod == "NONE" && cooperAssessments.isNotEmpty() && ageYearsText.isBlank() && referenceSex.isBlank())) {
            fitnessTestMethod = cooperAssessments.lastOrNull()?.testMethod ?: if (cooperEnabled) "COOPER_12_MIN" else "NONE"
        }
        val newestFieldAssessment = cooperAssessments.maxByOrNull { it.dateIso }
        val storedPhysiology = newestFieldAssessment?.let { record ->
            // A field test must retain the age and reference sex used on its date.
            // Never infer these from the current profile when the historic snapshot is missing.
            val ageAtTest = record.ageAtTest
            val sexAtTest = record.referenceSex
            if (ageAtTest != null && sexAtTest.isNotBlank()) {
                RunnerFitnessAssessmentEngine.assess(record.estimatedVo2Max, ageAtTest, sexAtTest, "FIELD_ESTIMATE")
            } else null
        }
        // Self-selected/legacy levels are not trusted as physiological classes. Until
        // an assessment with age/sex metadata is available, keep a conservative internal
        // guardrail and show "Aguardando teste" in the interface.
        level = storedPhysiology?.level ?: "Iniciante"
        if (newestFieldAssessment != null && storedPhysiology == null && latestCooperMessage.contains("Nível fisiológico", ignoreCase = true)) {
            latestCooperMessage = "Resultado histórico preservado: VO₂máx ${String.format(Locale.US, "%.1f", newestFieldAssessment.estimatedVo2Max)}. Complete idade e referência fisiológica na data do teste para calcular o nível."
        }
        val feedbackSessionIds = feedbackRecords.map { it.sessionId }.toSet()
        if (feedbackSessionIds.isNotEmpty()) {
            workouts = workouts.map { workout -> if (workout.sessionId in feedbackSessionIds && !workout.done) workout.copy(done = true) else workout }
        }
        if (activeZoneBandMigration) {
            workouts = workouts.map { workout ->
                if (workout.done) workout else ZoneIntensityBandEngine.apply(workout)
            }
            needsEngineRefresh = true
        }
        syncTargetDate()
        feedbackSaved = feedbackRecords.isNotEmpty()

        // Se o perfil legado não tem volume numérico, leva diretamente à revisão do dado obrigatório.
        if (goal.isNotBlank() && workouts.isEmpty()) onboardingStep = 1
        // Um plano antigo permanece acessível; o painel pede revisão antes da nova geração.
        if (goal.isNotBlank() && workouts.isNotEmpty()) onboardingStep = 8
        if (migrateV40WeekNumbering || durationEstimateMigrated || markEngineV35 || activeZoneBandMigration || feedbackSessionIds.isNotEmpty()) {
            if (activeZoneBandMigration) prefs.edit().putInt("engineVersion", 36).apply()
            persist(synchronous = feedbackSessionIds.isNotEmpty())
        }
    }
}
private val AppColors = darkColorScheme(
    primary = Blue,
    onPrimary = Color(0xFF101827),
    secondary = Green,
    onSecondary = Color(0xFF0D201B),
    tertiary = Yellow,
    background = Navy,
    surface = Navy2,
    surfaceVariant = CardBlue,
    onBackground = TextWhite,
    onSurface = TextWhite,
    onSurfaceVariant = TextMuted
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RunningCoachApp() }
    }
}

@Composable
private fun RunningCoachApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val state = remember(context) { CoachState(context.applicationContext) }
    MaterialTheme(colorScheme = AppColors) {
        Surface(Modifier.fillMaxSize(), color = Navy) {
            if (state.onboardingStep in -1..6) Onboarding(state) else MainShell(state)
        }
    }
}

@Composable
private fun Onboarding(state: CoachState) {
    val step = state.onboardingStep
    var pendingRestoreUri by remember { mutableStateOf<Uri?>(null) }
    val importBackupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) pendingRestoreUri = uri }
    BackHandler(enabled = step >= 0) { state.onboardingStep = if (step > 0) step - 1 else -1; state.persist() }
    Column(Modifier.fillMaxSize().background(Navy).verticalScroll(rememberScrollState()).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(12.dp)); OnboardingBrandHeader(); Spacer(Modifier.height(18.dp)); OnboardingStepProgress(step)
        Spacer(Modifier.height(if (step == -1) 24.dp else 20.dp))
        when (step) {
            -1 -> { BigRunnerMark(); Text("Seu plano. Sua evolução.", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Text("Treinos definidos pelo seu condicionamento e ajustados pela resposta às sessões.", color = TextMuted, textAlign = TextAlign.Center, modifier = Modifier.padding(12.dp)) }
            0 -> {
                Text("Vamos começar", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = TextWhite)
                Text("Como podemos chamar você?", color = TextMuted, fontSize = 13.sp)
                OutlinedTextField(
                    value = state.name,
                    onValueChange = { state.name = it.take(40); state.persist() },
                    label = { Text("Seu nome") },
                    placeholder = { Text("Digite seu nome") },
                    modifier = Modifier.fillMaxWidth(), singleLine = true
                )
                Text("Depois vamos avaliar seu condicionamento e montar um plano de acordo com seu objetivo e sua rotina.", color = TextMuted, textAlign = TextAlign.Center, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(8.dp))
            }
            1 -> FieldTestOnboardingStep(state)
            2 -> {
                Text("Qual objetivo deseja alcançar?", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = TextWhite)
                val latestAssessment = state.cooperAssessments.maxByOrNull { it.dateIso }
                Text("Nível fisiológico: ${state.physiologicalLevelDisplay()}" + (latestAssessment?.let { " • VO₂máx ${String.format(Locale.US, "%.1f", it.estimatedVo2Max)}" } ?: ""), color = Blue2, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(if (state.physiologicalLevelDisplay().startsWith("Aguardando")) "Sem referência fisiológica completa, o plano fica em dose de entrada. Com idade, referência fisiológica e teste válidos, as metas são liberadas até a distância compatível. A experiência não altera o nível." else "As distâncias compatíveis ficam disponíveis até a meia maratona para os níveis Iniciante e Intermediário. O que muda entre níveis é a progressão e a complexidade dos estímulos.", color = TextMuted, fontSize = 12.sp, lineHeight = 17.sp)
                Spacer(Modifier.height(10.dp))
                ChoiceScreen("Objetivo", TrainingGoalCatalog.labelsForLevel(state.level), state.goal) {
                    state.goal = it
                    state.goalIntent = if (it == "Saúde e qualidade de vida") TrainingGoalIntent.HEALTH else if (state.goalIntent == TrainingGoalIntent.HEALTH) TrainingGoalIntent.COMPLETE else state.goalIntent
                    state.persist()
                }
                if (state.goal.isNotBlank() && state.goal != "Saúde e qualidade de vida") {
                    Spacer(Modifier.height(12.dp))
                    ChoiceScreen("O que deseja alcançar?", TrainingGoalIntent.performanceOptions, TrainingGoalIntent.label(state.goalIntent)) { state.goalIntent = TrainingGoalIntent.fromLabel(it); state.persist() }
                    if (state.goalIntent == TrainingGoalIntent.TARGET_TIME) OutlinedTextField(
                        value = state.goalTargetTimeText,
                        onValueChange = { state.goalTargetTimeText = it.filter { c -> c.isDigit() || c == ':' }.take(8); state.persist() },
                        label = { Text("Tempo desejado (mm:ss ou hh:mm:ss)") }, supportingText = { Text("Meta de resultado; não substitui suas zonas fisiológicas.") },
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp), singleLine = true
                    )
                }
            }
            3 -> {
                Text("Há quanto tempo pratica corrida?", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = TextWhite)
                Text("Este dado contextualiza sua experiência, mas não muda o nível fisiológico estimado pelo teste.", color = TextMuted, fontSize = 12.sp, lineHeight = 17.sp)
                Spacer(Modifier.height(12.dp))
                ChoiceScreen("Tempo de prática regular", listOf("Menos de 6 meses", "6–12 meses", "1–3 anos", "3–5 anos", "Mais de 5 anos"), state.runningExperienceDuration) { state.runningExperienceDuration = it; state.persist() }
            }
            4 -> {
                Text("Quando e onde você corre?", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = TextWhite)
                TrainingAvailabilityEditor(state, showLongRunPreference = true)
                Spacer(Modifier.height(12.dp))
                ChoiceScreen("Onde costuma correr?", RunningTerrain.options, RunningTerrain.label(state.terrainPreference)) { state.terrainPreference = RunningTerrain.fromLabel(it); state.persist() }
            }
            5 -> {
                Text("Quanto você corre por semana?", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = TextWhite)
                Text("Informe sua média real recente. Ela ajusta a carga, não altera seu nível fisiológico.", color = TextMuted, fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(value = state.weeklyVolumeText, onValueChange = { state.weeklyVolumeText = it.filter { c -> c.isDigit() || c == ',' || c == '.' }; state.persist() }, label = { Text("Média semanal em km (opcional para Iniciante)") }, supportingText = { Text("Ex.: 16 km. Se não correu nas últimas semanas, informe 0.") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                if (RunnerFitnessAssessmentEngine.normalizeLevel(state.level) == "Iniciante") Text("Sem histórico, será usada uma dose inicial de ${String.format(Locale.US, "%.1f", state.defaultBeginnerWeeklyKm())} km/semana, ajustada conforme seus registros.", color = Blue2, fontSize = 11.sp, lineHeight = 16.sp)
            }
            6 -> {
                Text("Qual foi sua maior corrida recente?", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = TextWhite)
                Text("Informe a maior distância que realmente concluiu. Para Iniciante, pode deixar em branco sem histórico.", color = TextMuted, fontSize = 12.sp, lineHeight = 17.sp)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(value = state.longestRecent, onValueChange = { state.longestRecent = it.filter { c -> c.isDigit() || c == ',' || c == '.' }; state.persist() }, label = { Text("Maior distância recente em km") }, supportingText = { Text("Ex.: 5,0 km. Se ainda não correu, informe 0.") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                if (RunnerFitnessAssessmentEngine.normalizeLevel(state.level) == "Iniciante") Text("Sem registro, o limite inicial por sessão será ${String.format(Locale.US, "%.1f", state.defaultBeginnerLongestKm())} km. O motor aumenta esse limite após tolerância registrada.", color = Blue2, fontSize = 11.sp, lineHeight = 16.sp)
            }
        }
        Spacer(Modifier.height(26.dp))
        val beginner = RunnerFitnessAssessmentEngine.normalizeLevel(state.level) == "Iniciante"
        val weekly = state.weeklyVolumeText.trim().replace(",", ".").toDoubleOrNull()
        val longest = state.longestRecent.trim().replace(",", ".").toDoubleOrNull()
        val goalValid = state.goal.isNotBlank() && state.goal in TrainingGoalCatalog.labelsForLevel(state.level) &&
            (state.goal != "Outro objetivo" || state.customGoalKm.trim().replace(",", ".").toDoubleOrNull()?.let { it in 1.0..200.0 } == true) &&
            (state.goal == "Saúde e qualidade de vida" || state.goalIntent != TrainingGoalIntent.TARGET_TIME || PhysiologicalProfileEngine.parseTargetTime(state.goalTargetTimeText) != null)
        val canContinue = when (step) {
            0 -> state.name.trim().length >= 2
            1 -> state.isCooperEntryValid()
            2 -> goalValid
            3 -> state.runningExperienceDuration.isNotBlank()
            4 -> state.availableTrainingDays.size in 2..6 && state.frequency == state.availableTrainingDays.size
            5 -> (beginner && state.weeklyVolumeText.isBlank()) || weekly?.let { it in 0.0..300.0 } == true
            6 -> goalValid && ((beginner && state.longestRecent.isBlank()) || longest?.let { it in 0.0..200.0 } == true)
            else -> true
        }
        PrimaryButton(if (step == 6) "Criar meu plano" else if (step == -1) "Começar Novo Plano" else if (step == 0) "Continuar" else "Continuar", enabled = canContinue) {
            if (step == 6) state.createPlan() else if (step == 1 && !state.saveCurrentFieldTestToHistory()) state.persist() else { state.onboardingStep++; state.persist() }
        }
        if (step == -1) {
            Spacer(Modifier.height(10.dp))
            SecondaryButton("Importar Backup") { state.backupMessage = ""; importBackupLauncher.launch(arrayOf("application/json", "text/json", "application/octet-stream")) }
            Text("Recupere seu perfil, plano, sessões e histórico de outro aparelho.", color = TextMuted, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp))
            if (state.backupMessage.isNotBlank()) Text(state.backupMessage, color = Color(0xFFFFA0A0), fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp))
        }
        if (state.motorError.isNotBlank()) Text(state.motorError, color = Color(0xFFFF8A8A), fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
        Spacer(Modifier.height(18.dp))
    }
    if (pendingRestoreUri != null) AlertDialog(
        onDismissRequest = { pendingRestoreUri = null }, title = { Text("Importar backup?") },
        text = { Text("O arquivo será validado antes da restauração. Se for válido, os dados locais serão substituídos pelo perfil, plano, sessões, feedbacks e histórico do backup. Deseja continuar?") },
        confirmButton = { TextButton(onClick = { val uri = pendingRestoreUri; pendingRestoreUri = null; if (uri != null) state.restoreBackup(uri) }) { Text("Importar e restaurar") } },
        dismissButton = { TextButton(onClick = { pendingRestoreUri = null }) { Text("Cancelar") } }
    )
}

@Composable
private fun FieldTestOnboardingStep(state: CoachState) {
    val zones = state.selectedFieldTestZones()
    val assessment = zones?.let { z ->
        state.parsedAgeYears()?.let { age -> RunnerFitnessAssessmentEngine.assess(z.estimatedVo2Max, age, state.referenceSex, "FIELD_ESTIMATE") }
    }
    val selectedTest = when (state.fitnessTestMethod) {
        "COOPER_12_MIN" -> "Cooper (12 min)"
        "THREE_KM" -> "Corrida de 3 km"
        else -> "Ainda não tenho teste"
    }
    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Text("Avaliação fisiológica", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = TextWhite)
        Text("O teste estima seu VO₂máx e define a faixa fisiológica. Experiência e volume ajustam a dose, não mudam essa classificação.", color = TextMuted, fontSize = 12.sp, lineHeight = 16.sp)
        CardSurface(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = state.ageYearsText,
                    onValueChange = { state.ageYearsText = it.filter(Char::isDigit).take(3); state.refreshPhysiologicalLevelFromTest() },
                    label = { Text("Idade na data do teste (anos)") },
                    placeholder = { Text("Ex.: 35") },
                    modifier = Modifier.fillMaxWidth(), singleLine = true
                )
                CompactChoiceScreen(
                    title = "Referência fisiológica",
                    options = listOf("Masculino", "Feminino"),
                    current = when (state.referenceSex) {
                        RunnerFitnessAssessmentEngine.MALE -> "Masculino"
                        RunnerFitnessAssessmentEngine.FEMALE -> "Feminino"
                        else -> ""
                    }
                ) {
                    state.referenceSex = if (it == "Masculino") RunnerFitnessAssessmentEngine.MALE else RunnerFitnessAssessmentEngine.FEMALE
                    state.refreshPhysiologicalLevelFromTest()
                }
                CompactChoiceScreen(
                    title = "Teste utilizado",
                    options = listOf("Cooper (12 min)", "Corrida de 3 km", "Ainda não tenho teste"),
                    current = selectedTest
                ) { selected ->
                    state.fitnessTestMethod = when (selected) {
                        "Cooper (12 min)" -> "COOPER_12_MIN"
                        "Corrida de 3 km" -> "THREE_KM"
                        else -> "NONE"
                    }
                    state.cooperEnabled = state.fitnessTestMethod != "NONE"
                    state.latestCooperMessage = ""
                    state.refreshPhysiologicalLevelFromTest()
                }
                when (state.fitnessTestMethod) {
                    "COOPER_12_MIN" -> {
                        OutlinedTextField(
                            value = state.cooperDistanceText,
                            onValueChange = { state.cooperDistanceText = it.filter { c -> c.isDigit() || c == ',' || c == '.' }.take(6); state.refreshPhysiologicalLevelFromTest() },
                            label = { Text("Distância em 12 minutos (km)") }, placeholder = { Text("Ex.: 2,10") },
                            modifier = Modifier.fillMaxWidth(), singleLine = true
                        )
                        Text("Registre a distância total percorrida em 12 minutos, em percurso medido.", color = TextMuted, fontSize = 10.sp, lineHeight = 14.sp)
                    }
                    "THREE_KM" -> {
                        OutlinedTextField(
                            value = state.threeKmTimeText,
                            onValueChange = { state.threeKmTimeText = it.filter { c -> c.isDigit() || c == ':' }.take(5); state.refreshPhysiologicalLevelFromTest() },
                            label = { Text("Tempo para 3 km (mm:ss)") }, placeholder = { Text("Ex.: 15:30") },
                            modifier = Modifier.fillMaxWidth(), singleLine = true
                        )
                        Text("Use percurso plano e medido, em esforço forte e contínuo. A equação disponível foi validada para adultos de 18 a 39 anos.", color = TextMuted, fontSize = 10.sp, lineHeight = 14.sp)
                    }
                    else -> Text("Sem teste: o perfil fica como Aguardando avaliação. Um plano de entrada usa dose conservadora; registre Cooper ou 3 km depois para calcular VO₂máx e calibrar as zonas.", color = Blue2, fontSize = 10.sp, lineHeight = 14.sp)
                }
                if (state.fitnessTestMethod != "NONE") {
                    OutlinedTextField(
                        value = state.cooperAssessmentDateText,
                        onValueChange = { state.cooperAssessmentDateText = it.filter { c -> c.isDigit() || c == '/' }.take(10); state.persist() },
                        label = { Text("Data do teste (dd/mm/aaaa)") }, modifier = Modifier.fillMaxWidth(), singleLine = true
                    )
                }
                if (assessment != null) {
                    HorizontalDivider(color = Color(0x443F5878))
                    Text("VO₂máx estimado: ${String.format(Locale.US, "%.1f", assessment.vo2Max)} ml/kg/min", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("Nível fisiológico: ${assessment.level} • confiança ${if (state.fitnessTestMethod == "THREE_KM") "moderada" else "estimativa de campo"}", color = Green, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    val t = assessment.thresholds
                    Text(
                        "Iniciante < ${String.format(Locale.US, "%.1f", t.intermediate)} • Intermediário ${String.format(Locale.US, "%.1f", t.intermediate)}–${String.format(Locale.US, "%.1f", t.performance - 0.1)} • Performance ${String.format(Locale.US, "%.1f", t.performance)}–${String.format(Locale.US, "%.1f", t.elite - 0.1)} • Elite ≥ ${String.format(Locale.US, "%.1f", t.elite)}",
                        color = TextMuted, fontSize = 10.sp, lineHeight = 14.sp
                    )
                    Text("Referência geral de aptidão por idade e sexo; não é ranking competitivo.", color = TextMuted, fontSize = 9.sp, lineHeight = 13.sp)
                    Text("Zonas de pace individuais (min/km)", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    zones!!.all().forEach { zone ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${zone.id} • ${zone.name}", color = TextMuted, fontSize = 10.sp)
                            Text(zone.range.label(), color = TextWhite, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                } else if (state.fitnessTestMethod != "NONE") {
                    Text("Informe idade, referência fisiológica e resultado válido para liberar a classificação.", color = Yellow, fontSize = 10.sp, lineHeight = 14.sp)
                }
            }
        }
        Text("VO₂máx de campo é uma estimativa, não uma medição laboratorial. A carga continua limitada pela tolerância e pela recuperação.", color = TextMuted, fontSize = 9.sp, lineHeight = 13.sp)
    }
}

@Composable private fun OnboardingBrandHeader() {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.onboarding_app_icon),
            contentDescription = "Ícone AI Running Coach",
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(42.dp).clip(RoundedCornerShape(12.dp))
        )
        Spacer(Modifier.width(10.dp))
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("AI RUNNING COACH", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Black, letterSpacing = 1.1.sp)
            Text("PRESCREVE HOJE · EVOLUI SEMPRE", color = Blue2, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.35.sp)
        }
    }
}


@Composable
private fun CompactChoiceScreen(
    title: String,
    options: List<String>,
    current: String,
    selected: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(title, color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        options.chunked(2).forEach { rowOptions ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                rowOptions.forEach { option ->
                    val active = option == current
                    Surface(
                        modifier = Modifier.weight(1f).heightIn(min = 46.dp)
                            .then(if (active) Modifier.border(1.5.dp, Blue, RoundedCornerShape(10.dp)) else Modifier)
                            .clickable { selected(option) },
                        color = if (active) Color(0xFF174968) else CardBlue,
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(Modifier.padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = active, onClick = { selected(option) }, modifier = Modifier.size(28.dp))
                            Spacer(Modifier.width(5.dp))
                            Text(option, color = if (active) TextWhite else TextMuted, fontSize = 10.sp, lineHeight = 13.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium)
                        }
                    }
                }
                if (rowOptions.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable private fun OnboardingStepProgress(step: Int) {
    if (step !in 1..6) return
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            repeat(6) { index ->
                Box(Modifier.weight(1f).height(5.dp).clip(RoundedCornerShape(8.dp)).background(if (index < step) Blue else Color(0xFF29384D)))
            }
        }
        Text("ETAPA $step DE 6", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
    }
}

@Composable private fun BigRunnerMark() {
    Image(
        painter = painterResource(id = R.drawable.onboarding_app_icon),
        contentDescription = "Marca AI Running Coach",
        contentScale = ContentScale.Crop,
        modifier = Modifier.size(132.dp).clip(RoundedCornerShape(30.dp))
    )
}

@Composable private fun CooperOnboardingStep(state: CoachState) {
    val distance = state.cooperDistanceText.trim().replace(",", ".").toDoubleOrNull()
    val zones = state.calculateZonesForCooper(distance)
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text("Calibre suas zonas", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = TextWhite)
            Text("Informe um teste de Cooper recente (12 minutos). O resultado ajuda a estimar suas zonas de pace.", color = TextMuted, fontSize = 12.sp, lineHeight = 17.sp)
        }
        CardSurface(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("Tenho um resultado recente", color = TextWhite, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text("Preferencialmente das últimas 4–8 semanas", color = TextMuted, fontSize = 10.sp)
                    }
                    Switch(checked = state.cooperEnabled, onCheckedChange = { state.cooperEnabled = it; state.persist() })
                }
                if (state.cooperEnabled) {
                    OutlinedTextField(
                        value = state.cooperDistanceText,
                        onValueChange = { value ->
                            state.cooperDistanceText = value.filter { ch -> ch.isDigit() || ch == ',' || ch == '.' }.take(6)
                            state.persist()
                        },
                        label = { Text("Distância em 12 min (km)") },
                        placeholder = { Text("Ex.: 2,40") },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color(0xFF49617F))
                    )
                    OutlinedTextField(
                        value = state.cooperAssessmentDateText,
                        onValueChange = { value ->
                            state.cooperAssessmentDateText = value.filter { ch -> ch.isDigit() || ch == '/' }.take(10)
                            state.persist()
                        },
                        label = { Text("Data do teste (dd/mm/aaaa)") },
                        placeholder = { Text("dd/mm/aaaa") },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color(0xFF49617F))
                    )
                    if (zones != null) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            CooperMetric("PACE MÉDIO", "${PaceRange.format(zones.averageTestPaceValue)}", Modifier.weight(1f))
                            CooperMetric("VAM ESTIMADA", zones.estimatedMasPace, Modifier.weight(1f))
                            CooperMetric("VO₂ MÁX*", String.format(Locale.US, "%.1f", zones.estimatedVo2Max), Modifier.weight(1f))
                        }
                        Text("Segundo limiar estimado: ${zones.estimatedSvt2Pace} min/km", color = TextMuted, fontSize = 10.sp)
                        Text("Zonas estimadas (min/km)", color = Blue2, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        zones.all().chunked(2).forEach { pair ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                pair.forEach { zone ->
                                    Row(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(Navy2).padding(horizontal = 10.dp, vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(zone.id, color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        Text(zone.range.label(), color = TextWhite, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                }
                                if (pair.size == 1) Spacer(Modifier.weight(1f))
                            }
                        }
                        Text("*VO₂máx e VAM são estimativas de campo, não medições laboratoriais.", color = TextMuted, fontSize = 9.sp)
                    } else if (state.cooperDistanceText.isNotBlank()) {
                        Text("Informe uma distância entre 1,00 e 5,00 km.", color = Yellow, fontSize = 11.sp)
                    }
                } else {
                    Text("Você pode continuar sem o teste. O plano será criado, mas as zonas de pace ficarão sem calibração até registrar um Cooper.", color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                }
            }
        }
        CardSurface(Modifier.fillMaxWidth(), containerColor = Navy2) {
            Row(Modifier.padding(13.dp), horizontalArrangement = Arrangement.spacedBy(9.dp), verticalAlignment = Alignment.Top) {
                Text("ⓘ", color = Blue2, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text("Faça o teste descansado, em percurso plano e medido. Ele substitui uma sessão forte da semana; não realize com dor, doença ou recuperação insuficiente.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
            }
        }
        Text("Pace em mm:ss min/km · Distâncias em km · Duração do teste: 12 min", color = Blue2, fontSize = 10.sp)
    }
}

@Composable private fun CooperMetric(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(10.dp)).background(Navy2).padding(9.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(label, color = TextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(value, color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable private fun TrainingAvailabilityEditor(state: CoachState, showLongRunPreference: Boolean) {
    val days = DayOfWeek.values().toList()
    val rows = days.chunked(2)
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Dias de corrida", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text("Selecione de 2 a 6 dias. O plano usará somente esses dias.", color = TextMuted, fontSize = 11.sp)
            }
            rows.forEach { rowDays ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    rowDays.forEach { day ->
                        AvailabilityDayButton(
                            label = dayLabel(day),
                            selected = day in state.availableTrainingDays,
                            modifier = Modifier.weight(1f)
                        ) { state.setTrainingDay(day, day !in state.availableTrainingDays) }
                    }
                    if (rowDays.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("${state.availableTrainingDays.size} de 6 dias selecionados", color = Blue2, fontWeight = FontWeight.SemiBold, fontSize = 11.sp, modifier = Modifier.weight(1f))
                if (state.availableTrainingDays.size in 2..6) StatusPill("DISPONIBILIDADE", Green)
            }
            if (showLongRunPreference && state.availableTrainingDays.isNotEmpty()) {
                HorizontalDivider(color = Color(0x443F5878))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Dia preferido do longão", color = TextWhite, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        state.availableTrainingDays.forEach { day ->
                            AvailabilityDayButton(
                                label = dayLabel(day),
                                selected = state.preferredLongRunDay == day,
                                modifier = Modifier.widthIn(min = 82.dp)
                            ) { state.setLongRunDay(day) }
                        }
                    }
                }
            }
            if (state.scheduleActionMessage.isNotBlank()) Text(state.scheduleActionMessage, color = Green, fontSize = 10.sp, lineHeight = 14.sp)
        }
    }
}

@Composable private fun AvailabilityDayButton(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(
        modifier = modifier.height(46.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        color = if (selected) Color(0xFF304A70) else Color(0xFF142337),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) Blue.copy(alpha = 0.8f) else Color(0xFF34465E))
    ) {
        Row(Modifier.fillMaxSize().padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.size(15.dp).clip(RoundedCornerShape(50)).background(if (selected) Blue else Color.Transparent).border(1.dp, if (selected) Blue else TextMuted, RoundedCornerShape(50)), contentAlignment = Alignment.Center) {
                if (selected) Text("✓", color = Navy, fontSize = 9.sp, fontWeight = FontWeight.Black)
            }
            Text(label, color = if (selected) TextWhite else TextMuted, fontSize = 10.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
        }
    }
}

private fun dayLabel(day: DayOfWeek): String = when (day) {
    DayOfWeek.MONDAY -> "Segunda"
    DayOfWeek.TUESDAY -> "Terça"
    DayOfWeek.WEDNESDAY -> "Quarta"
    DayOfWeek.THURSDAY -> "Quinta"
    DayOfWeek.FRIDAY -> "Sexta"
    DayOfWeek.SATURDAY -> "Sábado"
    DayOfWeek.SUNDAY -> "Domingo"
}

private fun calendarCategory(workout: Workout): String = when {
    workout.type == "Recuperação" -> "REGENERATIVO"
    workout.type == "Longo" -> "LONGÃO"
    workout.type == "Qualidade" && (workout.title.contains("VO2", true) || workout.title.contains("interval", true)) -> "INTERVALADO"
    workout.type == "Qualidade" && workout.title.contains("fartlek", true) -> "FARTLEK"
    workout.type == "Qualidade" && (workout.title.contains("limiar", true) || workout.title.contains("tempo", true)) -> "LIMIAR"
    workout.type == "Qualidade" && (workout.title.contains("moderad", true) || workout.title.contains("steady", true)) -> "MODERADO"
    workout.title.contains("progress", true) -> "PROGRESSIVO"
    workout.type == "Qualidade" -> "QUALIDADE"
    else -> "AERÓBIO"
}

private fun calendarCategoryColor(category: String): Color = when (category) {
    "REGENERATIVO" -> Color(0xFF91B9EA)
    "AERÓBIO" -> Color(0xFF65CBA7)
    "PROGRESSIVO" -> Color(0xFFE5C16F)
    "MODERADO" -> Color(0xFFD9A66F)
    "QUALIDADE", "LIMIAR" -> Color(0xFFE89D66)
    "INTERVALADO" -> Color(0xFFE77D8B)
    "LONGÃO" -> Color(0xFF65B9D5)
    else -> Blue
}

private fun calendarCategoryShort(category: String): String = when (category) {
    "REGENERATIVO" -> "REG"
    "AERÓBIO" -> "AER"
    "PROGRESSIVO" -> "PROG"
    "MODERADO" -> "MOD"
    "FARTLEK" -> "FAR"
    "QUALIDADE" -> "QUAL"
    "LIMIAR" -> "LIM"
    "INTERVALADO" -> "INT"
    "LONGÃO" -> "LONG"
    else -> category.take(3)
}

@Composable private fun ChoiceScreen(title: String, options: List<String>, current: String, selected: (String) -> Unit) {
    Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
    Spacer(Modifier.height(8.dp))
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
    options.forEach { option ->
        val isSelected = option == current
        Card(
            Modifier
                .fillMaxWidth()
                .then(if (isSelected) Modifier.border(1.5.dp, Blue, RoundedCornerShape(10.dp)) else Modifier)
                .clickable { selected(option) },
            colors = CardDefaults.cardColors(containerColor = if (isSelected) Color(0xFF174968) else CardBlue),
            shape = RoundedCornerShape(10.dp)
        ) {
            Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(20.dp).border(2.dp, if (isSelected) Blue2 else TextMuted, RoundedCornerShape(50)),
                    contentAlignment = Alignment.Center
                ) {
                    if (isSelected) Box(Modifier.size(10.dp).clip(RoundedCornerShape(50)).background(Blue2))
                }
                Spacer(Modifier.width(10.dp))
                Text(option, fontSize = 14.sp, lineHeight = 18.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium)
            }
        }
    }
    }
}

@Composable private fun MainShell(state: CoachState) {
    // Android system Back uses the same navigation history as in-app navigation.
    // A restored deep screen has no in-memory history, so CoachState supplies a safe parent fallback.
    BackHandler(enabled = state.canNavigateBack()) {
        state.navigateBack()
    }
    Scaffold(
        containerColor = Navy,
        bottomBar = { BottomNav(state) }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (state.selectedScreen) {
                Screen.DASHBOARD -> Dashboard(state)
                Screen.CALENDAR -> CalendarScreen(state)
                Screen.WORKOUT -> WorkoutDetail(state)
                Screen.STRUCTURE -> StructureScreen(state)
                Screen.PLAN -> PlanScreen(state)
                Screen.EVOLUTION -> EvolutionScreen(state)
                Screen.FEEDBACK -> FeedbackScreen(state)
                Screen.HISTORY -> HistoryScreen(state)
                Screen.PROFILE -> ProfileScreen(state)
                Screen.AVAILABILITY -> AvailabilityScreen(state)
                Screen.EXPORT -> ExportScreen(state)
                Screen.PACE_ZONES -> PaceZonesScreen(state)
                Screen.COOPER_TEST -> CooperTestScreen(state)
                Screen.TRAINING_LIBRARY -> TrainingLibraryScreen(state)
                Screen.RACES -> RaceManagementScreen(state)
                Screen.BACKUP -> BackupScreen(state)
            }
        }
    }
}

@Composable private fun Header(title: String, back: Boolean = false, onBack: () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (back) {
            Surface(
                modifier = Modifier.size(42.dp).clickable(onClick = onBack),
                shape = RoundedCornerShape(15.dp),
                color = Navy2
            ) { Box(contentAlignment = Alignment.Center) { Text("‹", fontSize = 30.sp, color = Blue2) } }
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("AI RUNNING COACH", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Text(title, fontSize = 23.sp, fontWeight = FontWeight.Bold, color = TextWhite)
        }
    }
}

@Composable private fun Dashboard(state: CoachState) {
    val activePlan = state.activePlanWorkouts()
    val earliestWeek = activePlan.minOfOrNull { it.week } ?: 1
    val currentPlanWeek = state.currentPlanWeekNumber()
    // Always label the current cycle week, even when it currently has no run session.
    // Never fall back to an older week while keeping the current week's distance/count.
    val dashboardWeek = currentPlanWeek ?: earliestWeek
    val firstWeekSessions = activePlan.filter { it.week == dashboardWeek }
    val firstWeekRaces = state.eventsForPlanWeek(dashboardWeek).filter { it.status != "CANCELLED" }
    val firstWeekKm = firstWeekSessions.sumOf { it.distanceKm } + firstWeekRaces.sumOf { it.distanceKm }
    val nextWorkout = activePlan.firstOrNull { !it.done }
    val actualDistance = state.feedbackRecords.mapNotNull { it.actualDistanceKm }.sum()
    val weeklyReference = state.weeklyVolumeText.trim().replace(",", ".").toDoubleOrNull()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 22.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(start = 22.dp, end = 18.dp, top = 18.dp, bottom = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("TRAINING HUB", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.8.sp)
                Text("Olá, ${state.name}!", color = TextWhite, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text("Seu treinamento, em um só lugar.", color = TextMuted, fontSize = 13.sp)
            }
            Surface(shape = RoundedCornerShape(18.dp), color = CardBlue, modifier = Modifier.size(48.dp)) {
                Box(contentAlignment = Alignment.Center) { Text(state.name.take(1).uppercase(), color = Blue2, fontWeight = FontWeight.Bold, fontSize = 20.sp) }
            }
        }

        Surface(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            shape = RoundedCornerShape(28.dp),
            color = Color.Transparent
        ) {
            Column(
                Modifier.background(Brush.linearGradient(listOf(Color(0xFF263D62), Color(0xFF172B46), Color(0xFF183B50)))).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("SEU CICLO ATUAL", color = Color(0xFFCEDAFF), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                        Text("Plano de ${state.planWeeks} semanas", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    }
                    Surface(shape = RoundedCornerShape(50), color = Color(0x333FCEB7)) {
                        Text(if (state.workouts.isNotEmpty()) "ATIVO" else "PENDENTE", color = Color(0xFF9AF0D5), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp))
                    }
                }
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text(formatKmUi(firstWeekKm), fontSize = 38.sp, fontWeight = FontWeight.Black, color = Color.White)
                        Text("km estimados na semana $dashboardWeek", fontSize = 12.sp, color = Color(0xFFD0D9EA))
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("${firstWeekSessions.size + firstWeekRaces.size}", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("compromissos", fontSize = 12.sp, color = Color(0xFFD0D9EA))
                    }
                }
                ProgressTrack(progress = if (weeklyReference != null && weeklyReference > 0.0) (firstWeekKm / weeklyReference).toFloat().coerceIn(0f, 1f) else 0f, color = Color(0xFF9BE2D0), trackColor = Color(0x55FFFFFF))
                Text(
                    text = if (state.weeklyVolumeText.isNotBlank()) "Base informada: ${state.weeklyVolumeText} km/semana" else "Informe sua base recente para personalizar a carga",
                    color = Color(0xFFD0D9EA), fontSize = 11.sp
                )
            }
        }

        SectionHeading("Indicadores do atleta", "Dados do perfil")
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricPod("Volume de referência", state.weeklyVolumeText.takeIf { it.isNotBlank() }?.let { "$it km" } ?: "Não informado", "↗", Blue2, Modifier.weight(1f), "Média das últimas 4 semanas")
            MetricPod("Maior sessão", state.longestRecent.takeIf { it.isNotBlank() }?.let { "$it km" } ?: "Não informada", "◷", Color(0xFFFFD18A), Modifier.weight(1f), "Distância contínua recente")
        }
        val readiness = state.readinessSnapshot()
        val recoveryAccent = when (readiness.recoveryStatus) {
            "POOR" -> Color(0xFFFF9292)
            "MODERATE" -> Yellow
            "GOOD" -> Color(0xFF91D9C5)
            else -> TextMuted
        }
        val safetyAccent = when (readiness.safetyStatus) {
            "RED" -> Color(0xFFFF9292)
            "YELLOW" -> Yellow
            "GREEN" -> Color(0xFF91D9C5)
            else -> TextMuted
        }
        val readinessSubtitle = if (readiness.sampleCount == 0) "Aguardando feedback recente" else "${readiness.sampleCount} feedback(s) • últimos 14 dias"
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricPod("Recuperação", recoveryLabel(readiness.recoveryStatus), "✦", recoveryAccent, Modifier.weight(1f), if (readiness.sampleCount == 0) readinessSubtitle else "$readinessSubtitle • RPE e sensação")
            MetricPod("Segurança", safetyLabel(readiness.safetyStatus), "♥", safetyAccent, Modifier.weight(1f), if (readiness.sampleCount == 0) readinessSubtitle else "$readinessSubtitle • dor e fadiga")
        }

        val cooperStatus = state.cooperReviewStatus()
        val currentZones = state.currentPaceZones()
        CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), containerColor = Color(0xFF1A2D43)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("ZONAS DE PACE", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                        Text(if (currentZones != null) "Perfil calibrado" else "Pace ainda não calibrado", color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                    StatusPill(if (cooperStatus.isDue) "REVISÃO" else if (currentZones != null) "Z1–Z5" else "PENDENTE", if (cooperStatus.isDue) Yellow else Green)
                }
                if (currentZones != null) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        currentZones.all().forEach { zone ->
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(zone.id, color = Blue2, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text(zone.range.label().removeSuffix(" min/km"), color = TextWhite, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Text(cooperStatus.message, color = TextMuted, fontSize = 10.sp)
                } else {
                    Text("Registre Cooper de 12 minutos ou teste de 3 km para estimar VO₂máx e calibrar Z1–Z5.", color = TextMuted, fontSize = 11.sp)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SecondaryButton("Ver zonas", modifier = Modifier.weight(1f), horizontalPadding = 0) { state.navigateTo(Screen.PACE_ZONES) }
                    PrimaryButton("${if (cooperStatus.isDue) "Reavaliar teste" else "Novo teste"}", modifier = Modifier.weight(1f), horizontalPadding = 0) { state.openFieldTestEditor() }
                }
            }
        }

        val upcomingRace = state.primaryUpcomingRace()
        if (upcomingRace != null) {
            SectionHeading("Próxima competição", "Gerenciar") { state.navigateTo(Screen.RACES) }
            CardSurface(Modifier.padding(horizontal = 16.dp).clickable { state.navigateTo(Screen.RACES) }, containerColor = Color(0xFF292747)) {
                Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("🏁", fontSize = 29.sp)
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(upcomingRace.name, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("${formatKmUi(upcomingRace.distanceKm)} km • ${RaceEventEngine.formatBrazilianDate(upcomingRace.eventDateIso)} • Prioridade ${upcomingRace.priority}", color = Color(0xFFD2BFFF), fontSize = 10.sp)
                        val raceDate = upcomingRace.dateOrNull()
                        if (raceDate != null) Text("${java.time.temporal.ChronoUnit.DAYS.between(LocalDate.now(), raceDate).coerceAtLeast(0)} dias até a prova", color = TextMuted, fontSize = 10.sp)
                    }
                    Text("›", color = Blue2, fontSize = 25.sp)
                }
            }
        }

        SectionHeading("Distribuição semanal", "Planejado")
        CardSurface(Modifier.padding(horizontal = 16.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (dashboardWeek == currentPlanWeek) "Semana $dashboardWeek · em andamento" else "Semana $dashboardWeek do plano",
                            fontSize = 17.sp, fontWeight = FontWeight.Bold
                        )
                if (firstWeekRaces.isNotEmpty()) Text("${firstWeekSessions.size} treinos + ${firstWeekRaces.size} prova(s)", color = Color(0xFFD2BFFF), fontSize = 10.sp)
                        Text("Distância prevista por dia", color = TextMuted, fontSize = 11.sp)
                    }
                    Text("${formatKmUi(firstWeekKm)} km", color = Blue2, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                SevenDayBreakdown(firstWeekSessions, firstWeekRaces)
                Text("Barras roxas indicam competição. O gráfico mostra compromissos planejados, não atividades realizadas.", color = TextMuted, fontSize = 10.sp)
            }
        }

        SectionHeading("Próximo treino", "Ver calendário") {
            state.navigateTo(Screen.CALENDAR)
        }
        if (nextWorkout != null) {
            NextWorkoutCard(nextWorkout) { state.selectWorkout(nextWorkout) }
        } else {
            EmptyStateCard("Nenhum treino pendente", "Gere um novo ciclo para visualizar suas próximas sessões.", "Criar ou revisar plano") {
                state.onboardingStep = 1
                state.persist()
            }
        }

        state.motorDecision?.let { decision ->
            SectionHeading("Leitura do treinador")
            CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF182B3D)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text(
                        if (state.needsEngineRefresh) "Revisão da prescrição pendente" else stimulusLabel(decision.stimulus),
                        color = Blue2, fontWeight = FontWeight.Bold, fontSize = 16.sp
                    )
                    Text(
                        if (state.needsEngineRefresh) {
                            "O perfil fisiológico ou a meta mudou. Recalcule para atualizar as próximas sessões; treinos concluídos e histórico ficam preservados."
                        } else decision.rationale,
                        color = TextMuted, fontSize = 12.sp, lineHeight = 18.sp
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (state.needsEngineRefresh) StatusPill("Aguardando atualização", Yellow)
                        else {
                            StatusPill("Confiança ${((decision.confidence * 100).toInt()).coerceIn(0, 100)}%", Color(0xFFB7C8FF))
                            StatusPill(safetyLabel(decision.safety), if (decision.safety == "RED") Color(0xFFFF9292) else Color(0xFF9BE2D0))
                        }
                    }
                }
            }
        }
        if (state.needsEngineRefresh) {
            val currentGoalAllowed = state.goal in TrainingGoalCatalog.labelsForLevel(state.level)
            if (!currentGoalAllowed) {
                NoteBlock("O nível fisiológico foi atualizado. Escolha uma meta liberada para essa faixa antes de recalcular; o histórico e os treinos concluídos continuam preservados.")
                PrimaryButton("Revisar perfil e meta") {
                    state.onboardingStep = if (state.physiologicalLevelDisplay() == "Aguardando teste") 1 else 2
                    state.persist()
                }
            } else {
                NoteBlock("Há dados novos desde a última prescrição. Recalcular atualiza as zonas e somente as sessões futuras, preservando histórico, treinos concluídos e ciclo.")
                PrimaryButton("Recalcular plano") { state.createPlan() }
            }
        }
        if (state.needsPacePlanRefresh) {
            NoteBlock("Há evidência suficiente para atualizar uma ou mais zonas individuais (Z1 por sessões regenerativas, Z2 pelo teste da fala e Z3 por testes Cooper independentes). Recalcular aplica os limites atualizados somente às sessões de hoje em diante; o ciclo e o histórico permanecem preservados.")
            PrimaryButton("Aplicar calibração e recalcular próximas sessões") {
                val updated = state.recalibratePlan()
                if (!updated && state.motorError.isBlank()) state.motorError = "Não foi possível aplicar a calibração. Confira o perfil e o histórico recente."
            }
            if (state.motorError.isNotBlank()) NoteBlock(state.motorError)
        }
        if (actualDistance > 0.0) {
            CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("Distância registrada", color = TextMuted, fontSize = 11.sp)
                        Text("${formatKmUi(actualDistance)} km", color = TextWhite, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("${state.completedWorkouts().size} concluídos", color = Green, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
    }
}

@Composable private fun MetricPod(label: String, value: String, icon: String, accent: Color, modifier: Modifier = Modifier, subtitle: String = "") {
    // Metric cards use the same vertical hierarchy so labels never compete with icons
    // for horizontal space on narrow Android screens.
    CardSurface(modifier.padding(vertical = 5.dp), containerColor = CardBlue) {
        Column(
            Modifier.fillMaxWidth().heightIn(min = 124.dp).padding(horizontal = 12.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(icon, color = accent, fontSize = 17.sp, lineHeight = 20.sp)
            Text(
                label, color = TextMuted, fontSize = 10.sp, lineHeight = 13.sp,
                minLines = 2, softWrap = true
            )
            Text(
                value, color = accent, fontSize = 17.sp, lineHeight = 21.sp,
                fontWeight = FontWeight.Bold, softWrap = true
            )
            if (subtitle.isNotBlank()) Text(
                subtitle, color = TextMuted, fontSize = 9.sp, lineHeight = 12.sp,
                softWrap = true
            )
        }
    }
}

@Composable private fun CardBlock(title: String, main: String, note: String) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, color = Blue2, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(main, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = TextWhite)
            Text(note, color = TextMuted, fontSize = 12.sp, lineHeight = 17.sp)
        }
    }
}

@Composable private fun WorkoutCard(w: Workout, onClick: () -> Unit) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp).clickable(onClick = onClick)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            SessionGlyph(w, 44)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("${w.date}  •  ~${formatKmUi(w.distanceKm)} km estimados", color = TextMuted, fontSize = 10.sp)
                Text(w.title, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(workoutTypeLabel(w.type), color = Blue2, fontSize = 11.sp)
            }
            Text(if (w.done) "✓" else "›", color = if (w.done) Green else TextMuted, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable private fun CalendarScreen(state: CoachState) {
    var displayedMonth by remember { mutableStateOf(YearMonth.now()) }
    var selectedDate by remember { mutableStateOf(LocalDate.now()) }
    var viewMode by remember { mutableStateOf("MONTH") }
    val workoutsByDate = state.workouts.filter { it.scheduledDateIso.isNotBlank() }.map { if (it.selectedOption == "ALTERNATIVE") WorkoutAlternativeEngine.createAlternative(it) else it }.groupBy { it.scheduledDateIso }
    val eventsByDate = state.raceEvents.filter { it.status != "CANCELLED" }.groupBy { it.eventDateIso }
    val monthStart = displayedMonth.atDay(1).with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    val monthDays = (0 until 42).map { monthStart.plusDays(it.toLong()) }
    val nextRace = state.primaryUpcomingRace()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Calendário")
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20334D)) {
            Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("AGENDA ESPORTIVA", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
                Text("${state.workouts.size} treinos • ${state.raceEvents.count { it.status != "CANCELLED" }} provas", color = TextWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(nextRace?.let { "Próxima prova: ${it.name} • ${RaceEventEngine.formatBrazilianDate(it.eventDateIso)}" } ?: "Cadastre suas competições para o treinador organizar a preparação por data.", color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                PrimaryButton("Gerenciar competições", modifier = Modifier.fillMaxWidth()) { state.navigateTo(Screen.RACES) }
            }
        }

        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 13.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = viewMode == "MONTH", onClick = { viewMode = "MONTH" }, label = { Text("Mês") })
            FilterChip(selected = viewMode == "WEEK", onClick = { viewMode = "WEEK" }, label = { Text("Semana") })
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = {
                displayedMonth = displayedMonth.minusMonths(1)
                selectedDate = displayedMonth.atDay(1)
            }) { Text("‹", fontSize = 24.sp, color = Blue2) }
            Text(displayedMonth.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale("pt", "BR"))).replaceFirstChar { it.uppercase() }, color = TextWhite, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
            TextButton(onClick = {
                displayedMonth = displayedMonth.plusMonths(1)
                selectedDate = displayedMonth.atDay(1)
            }) { Text("›", fontSize = 24.sp, color = Blue2) }
        }

        if (viewMode == "WEEK") {
            val weekStart = selectedDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { selectedDate = selectedDate.minusWeeks(1); displayedMonth = YearMonth.from(selectedDate) }) { Text("‹ Semana anterior", color = Blue2, fontSize = 10.sp) }
                Spacer(Modifier.weight(1f))
                Text("${weekStart.format(DateTimeFormatter.ofPattern("dd/MM"))} – ${weekStart.plusDays(6).format(DateTimeFormatter.ofPattern("dd/MM"))}", color = TextMuted, fontSize = 10.sp)
                TextButton(onClick = { selectedDate = selectedDate.plusWeeks(1); displayedMonth = YearMonth.from(selectedDate) }) { Text("Próxima ›", color = Blue2, fontSize = 10.sp) }
            }
        }

        if (viewMode == "MONTH") {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                listOf("SEG", "TER", "QUA", "QUI", "SEX", "SÁB", "DOM").forEach { day ->
                    Text(day, modifier = Modifier.weight(1f), color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                }
            }
            monthDays.chunked(7).forEach { rowDays ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    rowDays.forEach { date ->
                        val dayWorkouts = workoutsByDate[date.toString()].orEmpty()
                        val dayEvents = eventsByDate[date.toString()].orEmpty()
                        val selected = date == selectedDate
                        val inMonth = date.month == displayedMonth.month
                        Card(
                            modifier = Modifier.weight(1f).height(62.dp).clickable { selectedDate = date; displayedMonth = YearMonth.from(date) },
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = when {
                                selected -> Color(0xFF304A73)
                                !inMonth -> Color(0xFF101B2A)
                                else -> Color(0xFF182A40)
                            })
                        ) {
                            Column(Modifier.fillMaxSize().padding(5.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceBetween) {
                                Text(date.dayOfMonth.toString(), color = if (inMonth) TextWhite else Color(0xFF607086), fontSize = 11.sp, fontWeight = if (selected) FontWeight.Black else FontWeight.Medium)
                                Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                    dayWorkouts.map { calendarCategory(it) }.distinct().take(4).forEach { category ->
                                        Box(Modifier.size(6.dp).clip(RoundedCornerShape(50)).background(calendarCategoryColor(category)))
                                    }
                                    if (dayEvents.isNotEmpty()) Box(Modifier.size(6.dp).clip(RoundedCornerShape(50)).background(Color(0xFFB79AF7)))
                                }
                                val dayLabels = dayWorkouts.map { calendarCategoryShort(calendarCategory(it)) }.distinct().take(2).joinToString("·")
                                Text(when { dayEvents.isNotEmpty() -> "PROVA"; dayLabels.isNotBlank() -> dayLabels; else -> "" }, color = if (dayEvents.isNotEmpty()) Color(0xFFD2BFFF) else TextMuted, fontSize = 7.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            }
                        }
                    }
                }
            }
        } else {
            val monday = selectedDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            (0..6).forEach { offset ->
                val date = monday.plusDays(offset.toLong())
                CalendarDayAgenda(
                    date = date,
                    workouts = workoutsByDate[date.toString()].orEmpty(),
                    events = eventsByDate[date.toString()].orEmpty(),
                    onWorkout = { state.selectWorkout(it) },
                    onSelectDate = { selectedDate = it; displayedMonth = YearMonth.from(it) }
                )
            }
        }

        SectionHeading("${selectedDate.format(DateTimeFormatter.ofPattern("EEEE, dd 'de' MMMM", Locale("pt", "BR"))).replaceFirstChar { it.uppercase() }}")
        val selectedEvents = eventsByDate[selectedDate.toString()].orEmpty()
        val selectedWorkouts = workoutsByDate[selectedDate.toString()].orEmpty()
        if (selectedEvents.isEmpty() && selectedWorkouts.isEmpty()) {
            CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), containerColor = Color(0xFF142338)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("DIA LIVRE", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Text("Nenhuma sessão programada para esta data.", color = TextWhite, fontSize = 12.sp)
                    if (!selectedDate.isBefore(LocalDate.now())) {
                        PrimaryButton("Consultar treinador para este dia") { state.requestRestDayRecommendation(selectedDate) }
                    } else {
                        Text("Datas passadas não recebem sessões adicionais.", color = TextMuted, fontSize = 10.sp)
                    }
                    state.restDayRecommendation?.takeIf { it.targetDate == selectedDate }?.let { suggestion ->
                        Divider(color = Color(0xFF31465F))
                        Text(suggestion.title, color = if (suggestion.canAddWorkout) Green else Blue2, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(suggestion.explanation, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                        if (suggestion.canAddWorkout) {
                            CardSurface(containerColor = Color(0xFF1B3047)) {
                                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("OPÇÃO 1 · MENOR CARGA", color = Green, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                        StatusPill("RECOMENDADA", Green)
                                    }
                                    Text(if (suggestion.estimatedDistanceKm > 0.0) "${suggestion.durationMin} min • ~${formatKmUi(suggestion.estimatedDistanceKm)} km • Z1 • RPE ${suggestion.rpeRange}" else "${suggestion.durationMin} min • distância não estimada • esforço muito leve", color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    Text("Corrida leve ou corrida/caminhada. Prioriza movimento confortável e menor estresse.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                                    PrimaryButton("Adicionar treino leve") { state.addRecommendedRestDayWorkout("EASY") }
                                }
                            }
                            CardSurface(containerColor = Color(0xFF1B3047)) {
                                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                    Text("OPÇÃO 2 · CARGA MODERADA", color = Blue2, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    if (suggestion.normalAvailable) {
                                        Text(if (suggestion.normalEstimatedDistanceKm > 0.0) "${suggestion.normalDurationMin} min • ~${formatKmUi(suggestion.normalEstimatedDistanceKm)} km • Z2 • RPE ${suggestion.normalRpeRange}" else "${suggestion.normalDurationMin} min • distância não estimada • Z2 confortável • RPE ${suggestion.normalRpeRange}", color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                        Text(
                                            if (suggestion.runWalkPattern) "Rodagem aeróbia confortável em corrida/caminhada, conforme a estratégia atual, sem aceleração final."
                                            else "Rodagem aeróbia contínua e confortável, sem intervalos ou aceleração final.",
                                            color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp
                                        )
                                        Text(suggestion.normalRiskText, color = Yellow, fontSize = 10.sp, lineHeight = 15.sp)
                                        SecondaryButton("Adicionar rodagem normal") { state.addRecommendedRestDayWorkout("NORMAL") }
                                    } else {
                                        Text("O histórico ainda não sustenta uma segunda opção com carga moderada.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                                    }
                                }
                            }
                            StatusPill("RISCO ${suggestion.riskLevel}", if (suggestion.riskLevel == "HIGH") Color(0xFFE58A8A) else if (suggestion.riskLevel == "MODERATE") Yellow else Green)
                            Text(suggestion.riskText, color = if (suggestion.riskLevel == "HIGH") Color(0xFFFFB0B0) else Yellow, fontSize = 10.sp, lineHeight = 15.sp)
                            Text("A decisão é do corredor. A inclusão não apaga, substitui nem transfere as sessões principais.", color = Blue2, fontSize = 10.sp, lineHeight = 15.sp)
                        } else {
                            Text("A programação principal foi mantida. Nenhuma sessão foi adicionada.", color = TextMuted, fontSize = 10.sp)
                        }
                    }
                    if (state.scheduleActionMessage.isNotBlank()) Text(state.scheduleActionMessage, color = Green, fontSize = 10.sp)
                }
            }
        }
        selectedEvents.forEach { event -> RaceAgendaRow(event) }
        selectedWorkouts.forEach { workout -> SessionAgendaRow(workout) { state.selectWorkout(workout) } }
        SectionHeading("Legenda")
        Column(Modifier.fillMaxWidth().padding(horizontal = 17.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                LegendDot("Regenerativo", calendarCategoryColor("REGENERATIVO"))
                LegendDot("Aeróbio", calendarCategoryColor("AERÓBIO"))
                LegendDot("Moderado", calendarCategoryColor("MODERADO"))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                LegendDot("Progressivo", calendarCategoryColor("PROGRESSIVO"))
                LegendDot("Qualidade/limiar", calendarCategoryColor("QUALIDADE"))
                LegendDot("Intervalado", calendarCategoryColor("INTERVALADO"))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                LegendDot("Fartlek", calendarCategoryColor("FARTLEK"))
                LegendDot("Longão", calendarCategoryColor("LONGÃO"))
                LegendDot("Prova", Color(0xFFB79AF7))
                LegendDot("Descanso", TextMuted)
            }
        }
        if (state.needsEngineRefresh) {
            NoteBlock("Sua disponibilidade, feedback ou competições foram alterados. Recalcular redistribui apenas as sessões de hoje em diante, mantém o ciclo e as semanas já concluídas e respeita os ${state.frequency} dias selecionados no perfil.")
            PrimaryButton("Recalcular preparação") { state.createPlan() }
        }
    }
}

@Composable private fun CalendarDayAgenda(
    date: LocalDate,
    workouts: List<Workout>,
    events: List<RaceEvent>,
    onWorkout: (Workout) -> Unit,
    onSelectDate: (LocalDate) -> Unit
) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), containerColor = Color(0xFF142338)) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(date.format(DateTimeFormatter.ofPattern("EEEE, dd/MM", Locale("pt", "BR"))).replaceFirstChar { it.uppercase() }, modifier = Modifier.clickable { onSelectDate(date) }, color = Blue2, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            if (events.isEmpty() && workouts.isEmpty()) Text("Descanso / sem compromisso", color = TextMuted, fontSize = 10.sp)
            events.forEach { RaceAgendaRow(it) }
            workouts.forEach { SessionAgendaRow(it) { onWorkout(it) } }
        }
    }
}

@Composable private fun LegendDot(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Box(Modifier.size(8.dp).clip(RoundedCornerShape(50)).background(color))
        Text(label, color = TextMuted, fontSize = 9.sp)
    }
}

@Composable private fun RaceAgendaRow(event: RaceEvent) {
    CardSurface(containerColor = Color(0xFF2B2850)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("🏁", fontSize = 21.sp)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(event.name, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text("${formatKmUi(event.distanceKm)} km • ${event.priorityLabel()} • ${RaceEventEngine.formatBrazilianDate(event.eventDateIso)}", color = Color(0xFFD2BFFF), fontSize = 9.sp)
                if (event.targetTime.isNotBlank()) Text("Tempo-alvo: ${event.targetTime}", color = TextMuted, fontSize = 9.sp)
            }
            StatusPill(when (event.status) { "COMPLETED" -> "REALIZADA"; "CANCELLED" -> "CANCELADA"; else -> "PROVA" }, Color(0xFFB79AF7))
        }
    }
}

@Composable private fun RaceManagementScreen(state: CoachState) {
    val sortedEvents = state.raceEvents.sortedBy { it.eventDateIso }
    val planned = sortedEvents.count { it.status == "PLANNED" }
    val completed = sortedEvents.count { it.status == "COMPLETED" }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Header("Competições", true) { state.navigateBack(Screen.CALENDAR) }

        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20344E)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("AGENDA DE PROVAS", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                Text("Organize seus objetivos", color = TextWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    MetricPod("Programadas", planned.toString(), "◷", Blue2, Modifier.weight(1f))
                    MetricPod("Concluídas", completed.toString(), "✓", Green, Modifier.weight(1f))
                    MetricPod("Total", sortedEvents.size.toString(), "🏁", Yellow, Modifier.weight(1f))
                }
                Text("A prioridade A define o objetivo principal. Provas B e C entram como preparação, sem substituir a recuperação.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
            }
        }

        SectionHeading(if (state.editingRaceId.isBlank()) "Adicionar competição" else "Editar competição")
        CardSurface(Modifier.padding(horizontal = 16.dp)) {
            Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = state.raceNameDraft,
                    onValueChange = { state.raceNameDraft = it.take(80) },
                    label = { Text("Nome da prova") },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 58.dp), singleLine = true
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Top) {
                    OutlinedTextField(
                        value = state.raceDistanceDraft,
                        onValueChange = { state.raceDistanceDraft = it.filter { c -> c.isDigit() || c == ',' || c == '.' }.take(6) },
                        label = { Text("Distância (km)", maxLines = 2, softWrap = true) },
                        modifier = Modifier.weight(1f).heightIn(min = 64.dp), singleLine = true
                    )
                    OutlinedTextField(
                        value = state.raceDateDraft,
                        onValueChange = { state.raceDateDraft = it.filter { c -> c.isDigit() || c == '/' }.take(10) },
                        label = { Text("Data da prova") },
                        modifier = Modifier.weight(1f).heightIn(min = 64.dp), singleLine = true
                    )
                }
                Text("PRIORIDADE DA COMPETIÇÃO", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("A", "B", "C").forEach { priority ->
                        val label = when (priority) { "A" -> "Principal"; "B" -> "Preparatória"; else -> "Treino" }
                        val selected = state.racePriorityDraft == priority
                        Surface(
                            modifier = Modifier.weight(1f).heightIn(min = 62.dp).clip(RoundedCornerShape(15.dp))
                                .clickable { state.racePriorityDraft = priority },
                            shape = RoundedCornerShape(15.dp),
                            color = if (selected) Color(0xFF4A405A) else Color(0xFF1A2B40),
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) Color(0xFF9A87B7) else Color(0xFF42516A))
                        ) {
                            Column(
                                Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 9.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Text(priority, color = if (selected) TextWhite else Blue2, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text(label, color = if (selected) TextWhite else TextMuted, fontSize = 9.sp, lineHeight = 11.sp, maxLines = 2, softWrap = true, textAlign = TextAlign.Center)
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Top) {
                    OutlinedTextField(
                        value = state.raceTargetTimeDraft,
                        onValueChange = { state.raceTargetTimeDraft = it.filter { c -> c.isDigit() || c == ':' }.take(8) },
                        label = { Text("Tempo-alvo") },
                        supportingText = { Text("Opcional · mm:ss", maxLines = 2) },
                        modifier = Modifier.weight(1f).heightIn(min = 64.dp), singleLine = true
                    )
                    OutlinedTextField(
                        value = state.raceLocationDraft,
                        onValueChange = { state.raceLocationDraft = it.take(100) },
                        label = { Text("Local da prova") },
                        supportingText = { Text("Opcional") },
                        modifier = Modifier.weight(1f).heightIn(min = 64.dp), singleLine = true
                    )
                }
                OutlinedTextField(
                    value = state.raceNotesDraft,
                    onValueChange = { state.raceNotesDraft = it.take(300) },
                    label = { Text("Observações") },
                    placeholder = { Text("Informações adicionais sobre a prova (opcional)", maxLines = 2, softWrap = true) },
                    modifier = Modifier.fillMaxWidth(), minLines = 3, maxLines = 5
                )
                if (state.raceFormError.isNotBlank()) Text(state.raceFormError, color = Color(0xFFFF9292), fontSize = 11.sp)
                PrimaryButton(if (state.editingRaceId.isBlank()) "Salvar competição" else "Salvar alterações", modifier = Modifier.fillMaxWidth()) {
                    if (state.saveRaceDraft()) state.navigateTo(Screen.RACES)
                }
                if (state.editingRaceId.isNotBlank()) SecondaryButton("Cancelar edição", modifier = Modifier.fillMaxWidth()) { state.resetRaceDraft() }
            }
        }

        SectionHeading("Suas competições", sortedEvents.size.toString())
        if (sortedEvents.isEmpty()) {
            EmptyStateCard("Nenhuma prova cadastrada", "Adicione uma competição para que o treinador organize o ciclo e a preparação.", "Cadastrar prova") { state.raceNameDraft = "Minha prova" }
        }
        sortedEvents.forEach { event ->
            CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                    Text(
                        event.name, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp,
                        lineHeight = 21.sp, softWrap = true
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        StatusPill(
                            "Prioridade ${event.priority} · ${when (event.priority) { "A" -> "Principal"; "B" -> "Preparatória"; else -> "Treino" }}",
                            if (event.priority == "A") Green else Blue2
                        )
                        StatusPill(raceStatusLabel(event.status), if (event.status == "COMPLETED") Green else Blue2)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("DISTÂNCIA", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.6.sp)
                            Text("${formatKmUi(event.distanceKm)} km", color = TextWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("DATA", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.6.sp)
                            Text(RaceEventEngine.formatBrazilianDate(event.eventDateIso), color = TextWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    if (event.targetTime.isNotBlank() || event.location.isNotBlank() || event.notes.isNotBlank()) {
                        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            if (event.targetTime.isNotBlank()) Text("Tempo-alvo: ${event.targetTime}", color = Blue2, fontSize = 11.sp, lineHeight = 15.sp, softWrap = true)
                            if (event.location.isNotBlank()) Text("Local: ${event.location}", color = TextMuted, fontSize = 11.sp, lineHeight = 15.sp, softWrap = true)
                            if (event.notes.isNotBlank()) Text("Observações: ${event.notes}", color = TextMuted, fontSize = 11.sp, lineHeight = 15.sp, softWrap = true)
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SecondaryButton("Editar", modifier = Modifier.weight(1f), horizontalPadding = 0) { state.beginRaceEdit(event) }
                        if (event.status == "PLANNED" && event.dateOrNull()?.let { !it.isAfter(LocalDate.now()) } == true) {
                            SecondaryButton("Concluir", modifier = Modifier.weight(1f), horizontalPadding = 0) { state.markRaceCompleted(event.id) }
                        }
                        SecondaryButton("Excluir", modifier = Modifier.weight(1f), horizontalPadding = 0) { state.deleteRace(event.id) }
                    }
                }
            }
        }
        if (state.racePlanNote.isNotBlank()) {
            SectionHeading("Integração com o plano")
            NoteBlock(state.racePlanNote)
            state.racePlanWarnings.forEach { NoteBlock(it) }
            if (state.needsEngineRefresh) PrimaryButton("Recalcular plano com as provas") { state.createPlan() }
        }
    }
}

@Composable private fun WorkoutDetail(state: CoachState) {
    val workout = state.selectedWorkout()
    var showReschedule by remember(workout?.sessionId) { mutableStateOf(false) }
    var showAlternativeDialog by remember(workout?.sessionId) { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Header("Sessão de treinamento", true) { state.navigateBack(Screen.CALENDAR) }
        if (workout == null) {
            EmptyStateCard("Nenhuma sessão selecionada", "Escolha um treino no calendário ou no plano.", "Abrir calendário") { state.navigateTo(Screen.CALENDAR) }
            return@Column
        }

        val baseWorkout = state.selectedWorkoutBase() ?: workout
        val isAlternativeSelected = baseWorkout.selectedOption == "ALTERNATIVE"
        // Uma única prescrição fica visível. A alternativa só aparece quando solicitada.
        SessionHero(workout)
        Row(
            Modifier.fillMaxWidth().padding(start = 18.dp, end = 16.dp, top = 2.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    if (isAlternativeSelected) "ALTERNATIVA ESCOLHIDA" else "PRESCRIÇÃO RECOMENDADA",
                    color = if (isAlternativeSelected) Color(0xFFE5C16F) else Green,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Text("Há outra opção compatível com esta sessão.", color = TextMuted, fontSize = 10.sp)
            }
            if (!baseWorkout.done && baseWorkout.type != "Competição") {
                TextButton(
                    onClick = { showAlternativeDialog = true },
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text("⇄ Trocar treino", color = Blue2, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        SectionHeading("Objetivo da sessão")
        CardSurface(Modifier.padding(horizontal = 16.dp)) {
            Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(workout.objective, color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Text(workout.rationale, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
            }
        }

        // Mostra todos os blocos na própria sessão: nenhum aquecimento, recuperação ou
        // desaquecimento fica escondido atrás de um limite visual de quatro itens.
        SectionHeading("Estrutura completa do treino")
        if (workout.segments.isNotEmpty()) {
            val segmentTotalKm = workout.segments.sumOf { (it.distanceKm ?: 0.0) * it.repeatCount }
            val distanceMatches = kotlin.math.abs(segmentTotalKm - workout.distanceKm) <= 0.11
            Text(
                "Soma dos blocos: ~${formatKmUi(segmentTotalKm)} km • Total da sessão: ${formatKmUi(workout.distanceKm)} km",
                color = if (distanceMatches) Green else Yellow,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 2.dp)
            )
        }
        workout.segments.forEachIndexed { index, segment -> SegmentRow(index + 1, segment) }

        if (workout.manuallyRescheduled) {
            Text(
                "Sessão movida da data original ${workout.originalScheduledDateIso.takeIf { it.isNotBlank() } ?: "não registrada"}. Dose e blocos preservados.",
                color = TextMuted, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 18.dp, vertical = 4.dp)
            )
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (!workout.done) {
                SecondaryButton("Reagendar", modifier = Modifier.weight(1f), horizontalPadding = 0) {
                    state.scheduleActionMessage = ""
                    showReschedule = true
                }
            }
            SecondaryButton("Feedback", modifier = Modifier.weight(1f), horizontalPadding = 0) {
                state.navigateTo(Screen.FEEDBACK)
            }
        }
        PrimaryButton("Exportar para Pace Coach", modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth()) {
            state.navigateTo(Screen.EXPORT)
        }
    }

    if (showAlternativeDialog && workout != null) {
        val base = state.selectedWorkoutBase() ?: workout
        val returningToPrimary = base.selectedOption == "ALTERNATIVE"
        val candidate = if (returningToPrimary) base.copy(selectedOption = "PRIMARY") else WorkoutAlternativeEngine.createAlternative(base)
        AlertDialog(
            onDismissRequest = { showAlternativeDialog = false },
            containerColor = CardBlue,
            title = { Text(if (returningToPrimary) "Voltar ao treino recomendado?" else "Outra opção para hoje", color = TextWhite, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text(if (returningToPrimary) "PRESCRIÇÃO PRINCIPAL" else "ALTERNATIVA", color = if (returningToPrimary) Green else Color(0xFFE5C16F), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(candidate.title, color = TextWhite, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text("${formatKmUi(candidate.distanceKm)} km estimados • Tempo estimado: ~${candidate.durationMin} min", color = Blue2, fontSize = 12.sp)
                    candidate.primaryPaceRange()?.let { Text("Pace-alvo: $it min/km", color = Blue2, fontSize = 12.sp) }
                    Text(candidate.objective, color = TextWhite, fontSize = 12.sp)
                    Text(candidate.rationale, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                    Text("A escolha substitui a sessão atual. Não acrescenta treino nem volume à semana.", color = TextMuted, fontSize = 10.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    state.selectWorkoutOption(base.sessionId, if (returningToPrimary) "PRIMARY" else "ALTERNATIVE")
                    showAlternativeDialog = false
                }) { Text(if (returningToPrimary) "Voltar ao recomendado" else "Usar esta opção", color = Blue2, fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { showAlternativeDialog = false }) { Text("Manter atual", color = TextMuted) }
            }
        )
    }

    if (showReschedule && workout != null) {
        val candidates = state.availableRescheduleDates(workout)
        AlertDialog(
            onDismissRequest = { showReschedule = false },
            containerColor = CardBlue,
            title = { Text("Reagendar sessão", color = TextWhite) },
            text = {
                Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("Escolha um dia livre dentro da mesma semana. A sessão mantém distância, pace, blocos e identidade.", color = TextMuted, fontSize = 12.sp)
                    if (candidates.isEmpty()) Text("Não há outro dia seguro e livre nesta semana.", color = Yellow, fontSize = 12.sp)
                    candidates.forEach { date ->
                        OutlinedButton(onClick = {
                            if (state.rescheduleWorkout(workout, date)) showReschedule = false
                        }, modifier = Modifier.fillMaxWidth()) {
                            Text(date.format(DateTimeFormatter.ofPattern("EEEE, dd/MM", Locale("pt", "BR"))).replaceFirstChar { it.uppercase() }, color = Blue2)
                        }
                    }
                    if (state.scheduleActionMessage.isNotBlank()) Text(state.scheduleActionMessage, color = Yellow, fontSize = 11.sp)
                }
            },
            confirmButton = { TextButton(onClick = { showReschedule = false }) { Text("Fechar", color = Blue2) } }
        )
    }
}

@Composable private fun StructureScreen(state: CoachState) {
    val workout = state.selectedWorkout()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 22.dp)) {
        Header("Estrutura da sessão", true) { state.navigateBack(Screen.WORKOUT) }
        if (workout == null) {
            EmptyStateCard("Sessão não encontrada", "Selecione uma sessão para consultar os blocos.", "Voltar ao calendário") { state.navigateBack(Screen.CALENDAR) }
            return@Column
        }
        SessionHero(workout)
        SectionHeading("Blocos prescritos")
        if (workout.segments.isEmpty()) {
            NoteBlock("Esta sessão pertence a um plano antigo e não possui blocos detalhados. Gere um novo ciclo para receber a estrutura completa.")
        } else {
            workout.segments.forEachIndexed { index, segment -> SegmentRow(index + 1, segment) }
        }
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF1A2A3D)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("Orientação do treinador", color = Blue2, fontWeight = FontWeight.Bold)
                Text(workout.rationale, color = TextMuted, fontSize = 12.sp, lineHeight = 18.sp)
            }
        }
    }
}

@Composable private fun SessionHero(workout: Workout) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF243B5D), Color(0xFF17344B))))
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatusPill(workoutTypeLabel(workout.type).uppercase(), Color(0xFFBFD0FF))
            Spacer(Modifier.weight(1f))
            Text(if (workout.done) "CONCLUÍDO" else "PROGRAMADO", color = if (workout.done) Color(0xFF9BE2D0) else Color(0xFFCEDAFF), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
        }
        Text(workout.title, color = Color.White, fontSize = 23.sp, lineHeight = 27.sp, fontWeight = FontWeight.Bold)
        Text("${workout.date}  ·  Semana ${workout.week}  ·  ${phaseLabel(workout.phase)}", color = Color(0xFFD0D9EA), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SessionMetric("DISTÂNCIA", formatKmUi(workout.distanceKm), "km", Modifier.weight(1f))
            SessionMetric("TEMPO", "~${workout.durationMin}", "min", Modifier.weight(1f))
            SessionMetric("PACE", workout.primaryPaceRange() ?: "—", "min/km", Modifier.weight(1f), compact = true)
        }
    }
}

@Composable private fun SessionMetric(label: String, value: String, unit: String, modifier: Modifier = Modifier, compact: Boolean = false) {
    Column(
        modifier.clip(RoundedCornerShape(13.dp)).background(Color.White.copy(alpha = 0.055f)).padding(horizontal = 9.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Text(label, color = Color(0xFFB9C8DE), fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.45.sp, maxLines = 1)
        Text(value, color = Color.White, fontSize = if (compact) 13.sp else 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false, overflow = TextOverflow.Clip)
        Text(unit, color = Color(0xFFD0D9EA), fontSize = 9.sp, maxLines = 1)
    }
}

@Composable private fun SegmentRow(index: Int, segment: WorkoutSegment) {
    val dose = when {
        segment.targetMode == "TIME" && segment.repeatCount > 1 && segment.durationMin != null -> "${segment.repeatCount} × ${segment.durationMin} min"
        segment.targetMode == "TIME" && segment.durationMin != null -> "${segment.durationMin} min"
        segment.repeatCount > 1 && segment.distanceKm != null -> "${segment.repeatCount} × ${formatKmUi(segment.distanceKm)} km"
        segment.distanceKm != null -> "${formatKmUi(segment.distanceKm)} km"
        segment.durationMin != null -> "${segment.durationMin} min"
        else -> "Conforme orientação"
    }
    val estimatedDistanceText = if (segment.targetMode == "TIME" && segment.distanceKm != null) {
        val total = segment.distanceKm * segment.repeatCount
        if (segment.repeatCount > 1) "Distância estimada: ~${formatKmUi(total)} km no total (${formatKmUi(segment.distanceKm)} km por repetição)"
        else "Distância estimada: ~${formatKmUi(total)} km"
    } else null
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
            Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFF253A56), modifier = Modifier.size(34.dp)) {
                Box(contentAlignment = Alignment.Center) { Text(index.toString(), color = Blue2, fontWeight = FontWeight.Bold) }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(segment.name, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(dose, color = Blue2, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                estimatedDistanceText?.let { Text(it, color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Medium) }
                Text(segment.instruction, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                if (segment.targetPaceMinValue != null && segment.targetPaceMaxValue != null) {
                    Text("${segment.paceZone?.let { "$it • " } ?: ""}Pace-alvo: ${PaceRange(segment.targetPaceMinValue, segment.targetPaceMaxValue).label()}", color = Blue2, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    if (segment.zoneIntensityMinPercent != null && segment.zoneIntensityMaxPercent != null) {
                        Text("Faixa ativa: ${segment.zoneIntensityMinPercent}–${segment.zoneIntensityMaxPercent}% da zona", color = TextMuted, fontSize = 10.sp)
                    }
                    segment.goalPaceReferenceSecondsPerKm?.let { pace ->
                        Text("Referência da meta: ${PaceRange.format(pace)} min/km • não substitui o pace da zona", color = Green, fontSize = 10.sp, fontWeight = FontWeight.Medium)
                    }
                } else {
                    Text("Orientação por esforço percebido (RPE)", color = TextMuted, fontSize = 10.sp)
                }
                Text("RPE ${segment.rpeRange}: referência complementar de esforço", color = TextMuted, fontSize = 10.sp)
            }
        }
    }
}

@Composable private fun PlanScreen(state: CoachState) {
    val groups = state.activePlanWorkouts().groupBy { it.week }.toSortedMap()
    val currentPlanWeek = state.currentPlanWeekNumber()
    val initialExpandedWeek = currentPlanWeek?.takeIf { it in groups } ?: groups.keys.firstOrNull() ?: 1
    var expandedWeek by remember(groups.keys.toList(), currentPlanWeek) { mutableStateOf(initialExpandedWeek) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 26.dp)) {
        Header("Plano de treinamento")
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).clip(RoundedCornerShape(28.dp)).background(Brush.linearGradient(listOf(Color(0xFF293F63), Color(0xFF182C45)))).padding(20.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
            Text("OBJETIVO PRINCIPAL", color = Color(0xFFCEDAFF), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
            Text(state.primaryUpcomingRace()?.let { "${it.name} • ${formatKmUi(it.distanceKm)} km" } ?: goalLabel(state), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
            Text("${state.physiologicalLevelDisplay()}  •  ${state.frequency} dias por semana", color = Color(0xFFD0D9EA), fontSize = 12.sp)
            HorizontalDivider(color = Color(0x446F8DB8))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                PlanStat("Duração", "${state.planWeeks} sem.")
                PlanStat("Base recente", "${state.weeklyVolumeText.ifBlank { "—" }} km")
                PlanStat("Maior treino", "${state.longestRecent.ifBlank { "—" }} km")
            }
        }
        if (state.needsEngineRefresh) {
            NoteBlock("Este plano foi gerado pela versão anterior do treinador. Atualize a meta, se necessário, e recalcule para aplicar a avaliação fisiológica e a carga atuais. Sessões concluídas e histórico permanecem preservados.")
            val goalAllowed = state.goal in TrainingGoalCatalog.labelsForLevel(state.level)
            PrimaryButton(if (goalAllowed) "Recalcular plano" else "Revisar meta") {
                if (goalAllowed) state.createPlan() else {
                    state.onboardingStep = if (state.physiologicalLevelDisplay() == "Aguardando teste") 1 else 2
                    state.persist()
                }
            }
        }
        SectionHeading("Periodização", "${groups.size} semanas no ciclo")
        if (state.motorDecision != null && !state.needsEngineRefresh) {
            CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 2.dp), containerColor = Color(0xFF192B40)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("ESTRATÉGIA", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                    Text(stimulusLabel(state.motorDecision!!.stimulus), color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text("Distribuição e zonas estão detalhadas nas sessões abaixo.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                }
            }
        }
        if (groups.isEmpty()) EmptyStateCard("Plano não criado", "Complete o perfil para o treinador organizar o seu ciclo.", "Revisar perfil") { state.onboardingStep = 1; state.persist() }
        groups.forEach { (week, sessions) ->
            TrainingWeekCard(
                week = week, sessions = sessions, currentWeek = (week == currentPlanWeek), expanded = expandedWeek == week,
                onToggle = { expandedWeek = if (expandedWeek == week) -1 else week },
                onSession = { state.selectWorkout(it) },
                events = state.eventsForPlanWeek(week)
            )
        }
        if (state.racePlanNote.isNotBlank()) {
            SectionHeading("Preparação para competição")
            NoteBlock(state.racePlanNote)
            state.racePlanWarnings.forEach { NoteBlock(it) }
        }
        if (state.raceEvents.isEmpty()) {
            CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 6.dp).clickable { state.navigateTo(Screen.RACES) }) {
                Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("Tem uma corrida marcada?", color = Blue2, fontWeight = FontWeight.Bold)
                    Text("Cadastre a prova para o treinador organizar a preparação, o taper e a recuperação.", color = TextMuted, fontSize = 11.sp)
                }
            }
        }
        NoteBlock("Os volumes representam a prescrição. A evolução real só é calculada quando as sessões são concluídas e a distância realizada é registrada.")
    }
}

@Composable private fun TrainingWeekCard(
    week: Int,
    sessions: List<Workout>,
    currentWeek: Boolean,
    expanded: Boolean,
    onToggle: () -> Unit,
    onSession: (Workout) -> Unit,
    events: List<RaceEvent> = emptyList()
) {
    val trainingKm = sessions.sumOf { it.distanceKm }
    val raceKm = events.filter { it.status != "CANCELLED" }.sumOf { it.distanceKm }
    val totalKm = trainingKm + raceKm
    val longKm = sessions.filter { it.type == "Longo" }.sumOf { it.distanceKm }
    val qualityKm = sessions.filter { it.type == "Qualidade" }.sumOf { it.distanceKm }
    val easyKm = (trainingKm - longKm - qualityKm).coerceAtLeast(0.0)
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
            Row(Modifier.fillMaxWidth().clickable(onClick = onToggle), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(if (currentWeek) "SEMANA $week · EM ANDAMENTO" else "SEMANA $week", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                    Text(when {
                        events.any { it.status == "PLANNED" && it.priority == "A" } -> "Semana da prova principal"
                        events.any { it.status == "PLANNED" && it.priority == "B" } -> "Semana de prova preparatória"
                        events.any { it.status == "PLANNED" && it.priority == "C" } -> "Evento de treinamento"
                        sessions.firstOrNull()?.phase == "TAPER" -> "Redução pré-prova principal"
                        sessions.firstOrNull()?.phase == "POST_RACE_RECOVERY" -> "Recuperação pós-prova principal"
                        else -> phaseLabel(sessions.firstOrNull()?.phase ?: "BASE")
                    }, color = TextWhite, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("~${formatKmUi(totalKm)} km", color = TextWhite, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text(if (events.isEmpty()) "${sessions.size} treinos" else "${sessions.size} treinos + ${events.size} provas", color = TextMuted, fontSize = 10.sp)
                }
                Spacer(Modifier.width(10.dp))
                Text(if (expanded) "⌃" else "⌄", color = Blue2, fontSize = 20.sp)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                if (totalKm > 0.0) {
                    if (easyKm > 0.0) Box(Modifier.weight((easyKm / totalKm).toFloat().coerceAtLeast(0.02f)).height(7.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF7BA9E8)))
                    if (qualityKm > 0.0) Box(Modifier.weight((qualityKm / totalKm).toFloat().coerceAtLeast(0.02f)).height(7.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFFE2B66E)))
                    if (longKm > 0.0) Box(Modifier.weight((longKm / totalKm).toFloat().coerceAtLeast(0.02f)).height(7.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF76CDB1)))
                    if (raceKm > 0.0) Box(Modifier.weight((raceKm / totalKm).toFloat().coerceAtLeast(0.02f)).height(7.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFFB79AF7)))
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Leves ${formatKmUi(easyKm)} km", color = TextMuted, fontSize = 9.sp)
                Text("Qualidade ${formatKmUi(qualityKm)} km", color = TextMuted, fontSize = 9.sp)
                Text("Longão ${formatKmUi(longKm)} km", color = TextMuted, fontSize = 9.sp)
            }
            if (events.isNotEmpty()) {
                Text("Provas ${formatKmUi(raceKm)} km", color = Color(0xFFD2BFFF), fontSize = 9.sp)
            }
            if (expanded) {
                HorizontalDivider(color = Color(0xFF31445A))
                events.sortedBy { it.eventDateIso }.forEach { RaceAgendaRow(it) }
                sessions.forEach { SessionAgendaRow(it) { onSession(it) } }
            } else {
                Text("Toque para expandir as sessões  ›", color = Blue2, fontSize = 10.sp, modifier = Modifier.clickable(onClick = onToggle))
            }
        }
    }
}

@Composable private fun SessionAgendaRow(workout: Workout, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(Color(0xFF142338)).clickable(onClick = onClick).padding(11.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        SessionGlyph(workout, 36)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(workout.title, color = TextWhite, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            Text("${workout.date}  •  ${calendarCategory(workout)}", color = calendarCategoryColor(calendarCategory(workout)), fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text("~${formatKmUi(workout.distanceKm)} km", color = Blue2, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(if (workout.done) "Concluído" else "Planejado", color = if (workout.done) Green else TextMuted, fontSize = 9.sp)
        }
    }
}

@Composable private fun EvolutionScreen(state: CoachState) {
    val completed = state.completedWorkouts()
    val feedbackEntries = state.feedbackRecords.sortedBy { record ->
        state.feedbackActivityDate(record).toEpochDay()
    }
    val recorded = feedbackEntries.mapNotNull { record -> record.actualDistanceKm?.let { record to it } }
    val totalDistance = recorded.sumOf { it.second }
    val paceObservations = feedbackEntries.mapNotNull { feedback ->
        val pace = feedback.actualPaceMinKm ?: return@mapNotNull null
        val date = state.feedbackActivityDate(feedback).toString()
        PaceObservation(
            date, feedback.actualDistanceKm ?: 0.0, pace, feedback.workoutType, feedback.effort, feedback.feeling,
            feedback.painPresent, RunningTerrain.normalize(feedback.terrain), feedback.elevationGainMeters
        )
    }
    val paceTrend = PerformanceMonitoringEngine.evaluate(paceObservations)
    val weeklyTotals = recorded.groupBy { (record, _) ->
        val date = state.feedbackActivityDate(record)
        date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    }.toSortedMap().map { (weekStart, items) -> WeeklyRangeLabel.fromActivityDate(weekStart) to items.sumOf { it.second } }
    val today = LocalDate.now()
    val completedIds = state.completedWorkouts().map { it.sessionId }.toSet()
    val plannedEvidence = state.workouts.mapNotNull { workout ->
        val date = runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull() ?: return@mapNotNull null
        PlannedSessionEvidence(workout.sessionId, date, workout.distanceKm, workout.done || workout.sessionId in completedIds)
    }
    val realizedEvidence = state.feedbackRecords.mapNotNull { record ->
        val date = state.feedbackActivityDate(record)
        val distance = record.actualDistanceKm ?: return@mapNotNull null
        RealizedActivityEvidence(record.sessionId, date, distance)
    }
    val plannedVsRealized = PlannedVsRealizedEngine.summarize(plannedEvidence, realizedEvidence, today, 28)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Evolução")
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            MetricPod("Sessões concluídas", completed.size.toString(), "✓", Green, Modifier.weight(1f))
            MetricPod("Feedbacks salvos", feedbackEntries.size.toString(), "●", Blue2, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            MetricPod("Distância registrada", "${formatKmUi(totalDistance)} km", "↗", Blue2, Modifier.weight(1f))
            MetricPod("Com distância real", recorded.size.toString(), "◎", Green, Modifier.weight(1f))
        }

        SectionHeading("Planejado x realizado — últimos 28 dias")
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20344E)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                InfoRow("Distância planejada", "${formatKmUi(plannedVsRealized.plannedDistanceKm)} km")
                InfoRow("Distância efetivamente registrada", "${formatKmUi(plannedVsRealized.realizedDistanceKm)} km")
                InfoRow("Sessões concluídas", "${plannedVsRealized.completedSessions} / ${plannedVsRealized.plannedSessions}")
                InfoRow("Aderência por sessões", plannedVsRealized.adherencePercent?.let { "$it%" } ?: "Sem sessões planejadas no período")
                InfoRow("Atividades com distância real", plannedVsRealized.activitiesWithMeasuredDistance.toString())
                Text("A distância realizada considera apenas métricas informadas ou importadas. Uma sessão marcada como concluída sem distância real conta para aderência, mas não aumenta os quilômetros realizados.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
            }
        }

        SectionHeading("Carga de treinamento")
        val trainingLoad = state.trainingLoadSnapshot()
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20344E)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                InfoRow("Distância nos últimos 7 dias", "${formatKmUi(trainingLoad.totalKmLast7Days)} km")
                InfoRow("Distância nos últimos 28 dias", "${formatKmUi(trainingLoad.totalKmLast28Days)} km")
                InfoRow("Média semanal medida (28 dias)", trainingLoad.averageWeeklyKmLast28Days?.let { "${formatKmUi(it)} km" } ?: "Histórico insuficiente")
                InfoRow("Média semanal (42 dias)", trainingLoad.averageWeeklyKmLast42Days?.let { "${formatKmUi(it)} km" } ?: "Sem dados suficientes")
                InfoRow("Maior corrida em 30 dias", trainingLoad.longestRunLast30DaysKm?.let { "${formatKmUi(it)} km" } ?: "Não disponível")
                InfoRow("Duração em 7 dias", trainingLoad.durationMinutesLast7Days?.let { "$it min" } ?: "Não informada")
                InfoRow("Carga sRPE em 7 dias", trainingLoad.sessionRpeLoadLast7Days?.toString() ?: "Não disponível")
                InfoRow("RPE médio em 28 dias", trainingLoad.averageRpeLast28Days?.let { String.format(Locale.US, "%.1f/10", it) } ?: "Não disponível")
                InfoRow("FC média em 7 dias", trainingLoad.averageHeartRateLast7DaysBpm?.let { "$it bpm" } ?: "Não disponível")
                InfoRow("FC média em 28 dias", trainingLoad.averageHeartRateLast28DaysBpm?.let { "$it bpm" } ?: "Não disponível")
                InfoRow("Cadência média em 28 dias", trainingLoad.averageCadenceLast28DaysSpm?.let { "$it spm" } ?: "Não disponível")
                InfoRow("Elevação acumulada em 28 dias", trainingLoad.elevationGainLast28DaysMeters?.let { "${formatKmUi(it / 1000.0)} km" } ?: "Não disponível")
                trainingLoad.loadTrend7To28?.let { ratio ->
                    InfoRow("Tendência sRPE (7d × 4 / 28d)", String.format(Locale.US, "%.2f", ratio))
                }
                if (trainingLoad.zoneTimeSecondsLast28Days.isNotEmpty()) {
                    val summary = trainingLoad.zoneTimeSecondsLast28Days.toSortedMap().entries.joinToString(" • ") { (zone, seconds) ->
                        "$zone ${seconds / 60} min"
                    }
                    Text("Tempo medido por trechos temporizados: $summary", color = Blue2, fontSize = 10.sp, lineHeight = 15.sp)
                }
                if (trainingLoad.estimatedZoneTimeSecondsLast28Days.isNotEmpty()) {
                    val summary = trainingLoad.estimatedZoneTimeSecondsLast28Days.toSortedMap().entries.joinToString(" • ") { (zone, seconds) ->
                        "$zone ${seconds / 60} min"
                    }
                    Text("Tempo estimado por parciais de pace: $summary", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                }
                Text(
                    if (trainingLoad.reliable) "Histórico de 28 dias considerado suficiente (pelo menos seis atividades em três semanas). Tempo medido considera apenas trechos com distância e horário válidos; o restante permanece desconhecido." else "Histórico parcial: a média informada no perfil continua sendo a referência principal. Os tempos medidos vêm de trechos temporizados; estimativas por parciais permanecem separadas.",
                    color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp
                )
            }
        }

        SectionHeading("Monitoramento do pace")
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20344E)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                StatusPill(when (paceTrend.status) { "FASTER" -> "SINAL DE MELHORA"; "SLOWER" -> "ATENÇÃO"; "STABLE" -> "ESTÁVEL"; else -> "DADOS INSUFICIENTES" }, when (paceTrend.status) { "FASTER" -> Green; "SLOWER" -> Yellow; else -> Blue2 })
                Text(paceTrend.headline, color = TextWhite, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(paceTrend.explanation, color = TextMuted, fontSize = 11.sp, lineHeight = 17.sp)
                Text("Sessões comparáveis consideradas: ${paceTrend.comparableSessions}", color = Blue2, fontSize = 10.sp)
            }
        }

        SectionHeading("Zonas e calibração")
        // Keep the most recent field-test record in this composable scope; it is
        // also displayed in the athlete profile, but that local variable is not
        // visible from the monitoring screen.
        val latestTest = state.cooperAssessments.maxByOrNull { it.dateIso }
        val review = state.cooperReviewStatus()
        val criticalSpeed = state.criticalSpeedSnapshot()
        CardSurface(Modifier.padding(horizontal = 16.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                InfoRow("Último teste", latestTest?.let { record ->
                    if (record.testMethod == "THREE_KM") "3 km • ${record.testDurationSeconds?.let(PhysiologicalProfileEngine::formatDuration) ?: "—"} • VO₂ ${String.format(Locale.US, "%.1f", record.estimatedVo2Max)}"
                    else "Cooper • ${formatKmUi(record.distanceKm)} km • VO₂ ${String.format(Locale.US, "%.1f", record.estimatedVo2Max)}"
                } ?: "Não realizado")
                InfoRow("Revisão", if (review.isDue) "Disponível" else review.nextReviewDate?.format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy")) ?: "Pendente")
                InfoRow("Velocidade crítica estimada", criticalSpeed.paceLabel)
                InfoRow("Evidências para velocidade crítica", criticalSpeed.evidenceCount.toString())
                Text("${criticalSpeed.explanation} Os feedbacks orientam a recuperação; as zonas oficiais não são alteradas automaticamente por um único resultado.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                SecondaryButton("Ver zonas Z1–Z5") { state.navigateTo(Screen.PACE_ZONES) }
                PrimaryButton("Registrar teste fisiológico") { state.openFieldTestEditor() }
            }
        }

        SectionHeading("Registro das sessões")
        Text("${feedbackEntries.size} feedbacks salvos", color = TextMuted, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 20.dp))
        if (feedbackEntries.isEmpty()) {
            EmptyStateCard("Nenhum feedback registrado", "Depois de concluir uma sessão e salvar esforço, sensação e segurança, o registro aparecerá aqui. Distância e tempo podem ser adicionados quando disponíveis.", "Ver treinos") { state.navigateTo(Screen.HISTORY) }
        } else {
            feedbackEntries.asReversed().forEach { FeedbackHistoryDetails(it, state.feedbackActivityDate(it)) }
        }

        SectionHeading("Desempenho medido")
        if (recorded.isEmpty()) {
            NoteBlock("Os feedbacks acima estão salvos. Ainda não há distância real informada; preencha distância e tempo no feedback para alimentar os gráficos de volume e pace. O aplicativo não usa a distância planejada como resultado realizado.")
        } else {
            ChartCard("Quilômetros efetivamente registrados por semana", weeklyTotals)
            CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 7.dp)) {
                Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Resumo das métricas reais", color = Blue2, fontWeight = FontWeight.Bold)
                    InfoRow("Sessões com distância real", recorded.size.toString())
                    InfoRow("Distância total informada", "${formatKmUi(totalDistance)} km")
                    InfoRow("Sessões com pace calculado", paceObservations.size.toString())
                }
            }
        }
        NoteBlock("Esforço, sensação e segurança são mantidos como feedback mesmo sem distância ou tempo. Gráficos, pace real e carga por quilometragem usam exclusivamente métricas informadas pelo atleta.")
    }
}

@Composable private fun ChartCard(title: String, values: List<Pair<String, Double>>) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 7.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
            Text(title, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            if (values.isEmpty()) {
                Text("Sem dados suficientes para montar o gráfico.", color = TextMuted, fontSize = 11.sp)
            } else {
                val maxValue = (values.maxOfOrNull { it.second } ?: 0.0).coerceAtLeast(1.0)
                Row(Modifier.fillMaxWidth().height(132.dp), horizontalArrangement = Arrangement.spacedBy(9.dp), verticalAlignment = Alignment.Bottom) {
                    values.forEach { (label, value) ->
                        Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                            Text(formatKmUi(value), color = Blue2, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(5.dp))
                            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.BottomCenter) {
                                Box(Modifier.fillMaxWidth(0.68f).height((value / maxValue * 82.0).coerceAtLeast(5.0).dp).clip(RoundedCornerShape(topStart = 9.dp, topEnd = 9.dp)).background(Brush.verticalGradient(listOf(Color(0xFF9BB7FF), Color(0xFF5479BC)))))
                            }
                            Spacer(Modifier.height(7.dp))
                            Text(label, color = TextMuted, fontSize = 8.sp, maxLines = 1, textAlign = TextAlign.Center)
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun FeedbackScreen(state: CoachState) {
    val workout = state.selectedWorkout()
    val existingFeedback = workout?.let { state.feedbackForSession(it.sessionId) }
    val context = androidx.compose.ui.platform.LocalContext.current
    var effort by remember(workout?.sessionId) { mutableStateOf(existingFeedback?.effort ?: "Leve") }
    var feeling by remember(workout?.sessionId) { mutableStateOf(existingFeedback?.feeling ?: "Bem") }
    var pain by remember(workout?.sessionId) { mutableStateOf(if (existingFeedback?.painPresent == true) "Sim" else "Não") }
    var notes by remember(workout?.sessionId) { mutableStateOf(existingFeedback?.notes ?: "") }
    var actualDistance by remember(workout?.sessionId) { mutableStateOf(existingFeedback?.actualDistanceKm?.let { formatKmUi(it) } ?: "") }
    var actualDuration by remember(workout?.sessionId) { mutableStateOf(existingFeedback?.actualDuration ?: "") }
    var talkTestPace by remember(workout?.sessionId) { mutableStateOf(existingFeedback?.talkTestPaceMmSs ?: "") }
    var activityTerrain by remember(workout?.sessionId) {
        mutableStateOf(existingFeedback?.terrain?.let(RunningTerrain::normalize) ?: state.terrainPreference)
    }
    var selectedRaceId by remember(workout?.sessionId) { mutableStateOf(existingFeedback?.raceEventId.orEmpty()) }
    var raceMenuExpanded by remember(workout?.sessionId) { mutableStateOf(false) }
    var importedActivity by remember(workout?.sessionId) { mutableStateOf<ImportedActivity?>(null) }
    var importMessage by remember(workout?.sessionId) { mutableStateOf("") }
    var importError by remember(workout?.sessionId) { mutableStateOf("") }
    val talkTestEligible = workout?.let { TalkTestCalibrationRules.isEligibleWorkout(it.type) } == true
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && workout != null) {
            try {
                val filename = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) cursor.getString(0) else null
                } ?: uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':') ?: "atividade.gpx"
                val stream = context.contentResolver.openInputStream(uri)
                    ?: throw ActivityImportException("Não foi possível abrir o arquivo selecionado.")
                val parsed = ActivityFileImporter.import(stream, filename)
                if (state.importedActivityUsedElsewhere(parsed.fingerprint, workout.sessionId)) {
                    importedActivity = null
                    importError = "Esta atividade já está vinculada a outra sessão. Escolha o arquivo correto para evitar duplicação."
                    importMessage = ""
                } else {
                    importedActivity = parsed
                    parsed.distanceKm?.let { actualDistance = String.format(Locale.US, "%.2f", it) }
                    // Missing timestamps stay missing; they are never replaced with an estimated duration.
                    actualDuration = parsed.elapsedSeconds?.let(PaceRange::formatDuration).orEmpty()
                    importMessage = "${parsed.sourceFormat} importado. Confira as métricas e confirme junto ao feedback."
                    importError = ""
                }
            } catch (error: Exception) {
                importedActivity = null
                importMessage = ""
                importError = error.message ?: "Falha ao importar a atividade."
            }
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Feedback da sessão", true) { state.navigateBack(Screen.WORKOUT) }
        if (workout != null) SessionHero(workout)
        else NoteBlock("Selecione uma sessão para registrar o feedback.")
        SectionHeading("Como foi o esforço?")
        FeedbackGroup("Esforço percebido", listOf("Muito leve", "Leve", "Ok", "Pesado", "Muito pesado"), effort) { effort = it }
        SectionHeading("Como você se sentiu?")
        FeedbackGroup("Sensação geral", listOf("Ótimo", "Bem", "Cansado", "Muito cansado"), feeling) { feeling = it }
        SectionHeading("Segurança")
        FeedbackGroup("Sentiu dor durante ou após o treino?", listOf("Não", "Sim"), pain) { pain = it }
        FeedbackGroup("Terreno desta atividade", RunningTerrain.options, RunningTerrain.label(activityTerrain)) {
            activityTerrain = RunningTerrain.fromLabel(it)
        }
        CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Métricas reais da sessão", color = TextWhite, fontWeight = FontWeight.Bold)
                Text("Importe a atividade do relógio ou aplicativo. O arquivo preenche as métricas que realmente contém; dados ausentes permanecem vazios. A importação não substitui esforço, sensação ou dor.", color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                OutlinedButton(onClick = { importLauncher.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (importedActivity != null) "Trocar arquivo da atividade" else "Importar atividade GPX, FIT ou TCX")
                }
                if (importMessage.isNotBlank()) Text(importMessage, color = Green, fontSize = 10.sp)
                if (importError.isNotBlank()) Text(importError, color = Yellow, fontSize = 10.sp)
                if (importedActivity != null) {
                    val activity = importedActivity!!
                    CardSurface(Modifier.fillMaxWidth(), containerColor = Color(0xFF162B40)) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("Prévia da atividade • ${activity.sourceFormat}", color = Blue2, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            val distanceLabel = activity.distanceKm?.let { "${formatKmUi(it)} km" } ?: "Não disponível"
                            val durationLabel = activity.elapsedSeconds?.let(PaceRange::formatDuration) ?: "Não disponível (sem tempo válido no arquivo)"
                            InfoRow("Distância", distanceLabel)
                            InfoRow("Tempo decorrido", durationLabel)
                            activity.averagePaceMmSs?.let { InfoRow("Pace médio", "$it min/km") }
                            activity.startedAtIso?.let { InfoRow("Início", it.replace('T', ' ').substringBefore('.').removeSuffix("Z")) }
                            activity.elevationGainMeters?.let { InfoRow("Ganho de elevação", "${it.roundToInt()} m") }
                            activity.averageHeartRateBpm?.let { InfoRow("FC média", "$it bpm") }
                            activity.maxHeartRateBpm?.let { InfoRow("FC máxima", "$it bpm") }
                            activity.averageCadenceSpm?.let { InfoRow("Cadência média", "$it spm") }
                            activity.maxCadenceSpm?.let { InfoRow("Cadência máxima", "$it spm") }
                            if (activity.routePointCount > 0) InfoRow("Pontos GPS do percurso", activity.routePointCount.toString())
                            if (activity.splitPacesMmSs.isNotEmpty()) {
                                Text("Parciais calculadas", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                activity.splitPacesMmSs.forEachIndexed { index, split ->
                                    Text("${index + 1}º km • $split min/km", color = TextMuted, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                } else if (!existingFeedback?.activitySourceFormat.isNullOrBlank()) {
                    Text("Atividade ${existingFeedback?.activitySourceFormat} já vinculada a esta sessão. Salvar novamente preserva as métricas e o percurso importados.", color = Blue2, fontSize = 10.sp)
                }
                OutlinedTextField(actualDistance, { actualDistance = it.filter { ch -> ch.isDigit() || ch == ',' || ch == '.' }.take(7) }, label = { Text("Distância realizada (km)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(actualDuration, { actualDuration = it.filter { ch -> ch.isDigit() || ch == ':' }.take(8) }, label = { Text("Tempo total (mm:ss ou hh:mm:ss)") }, supportingText = { Text("Exemplo: 42:30 ou 01:12:30") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                if (talkTestEligible) {
                    HorizontalDivider(color = Color(0x443F5878))
                    Text("Calibração individual da Z2", color = Blue2, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("Informe o pace do trecho estável em que conseguiu falar frases completas com conforto. Só observações confortáveis e sem dor entram na calibração; são necessárias pelo menos três observações consistentes em sessões diferentes.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                    OutlinedTextField(talkTestPace, { talkTestPace = it.filter { ch -> ch.isDigit() || ch == ':' }.take(5) }, label = { Text("Pace confortável (mm:ss min/km)") }, supportingText = { Text("Exemplo: 7:20. Registre apenas se a fala ficou confortável.") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    if (talkTestPace.isNotBlank() && PaceRange.parsePace(talkTestPace) == null) Text("Use mm:ss min/km, por exemplo 7:20.", color = Yellow, fontSize = 10.sp)
                }
                val actualKm = actualDistance.trim().replace(",", ".").toDoubleOrNull()
                val elapsed = PaceCalculator.parseDuration(actualDuration)
                if (actualKm != null && elapsed != null) {
                    val pace = PaceCalculator.paceFromDistanceAndDuration(actualKm, elapsed)
                    if (pace != null) Text("Pace realizado: ${PaceRange.format(pace)} min/km", color = Green, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                if (actualDuration.isNotBlank() && elapsed == null) Text("Informe o tempo como mm:ss ou hh:mm:ss.", color = Yellow, fontSize = 10.sp)
                OutlinedTextField(notes, { notes = it }, label = { Text("Observações (opcional)") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
            }
        }
        if (state.raceEvents.isNotEmpty()) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Resultado de prova (opcional)", color = TextMuted, fontSize = 11.sp)
                Box {
                    OutlinedButton(onClick = { raceMenuExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                        val linkedName = state.raceEvents.firstOrNull { it.id == selectedRaceId }?.name ?: "Não vincular a uma prova"
                        Text(linkedName, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    DropdownMenu(expanded = raceMenuExpanded, onDismissRequest = { raceMenuExpanded = false }) {
                        DropdownMenuItem(text = { Text("Não vincular a uma prova") }, onClick = {
                            selectedRaceId = ""; raceMenuExpanded = false
                        })
                        state.raceEvents.forEach { race ->
                            DropdownMenuItem(text = { Text("${race.name} • ${RaceEventEngine.formatBrazilianDate(race.eventDateIso)}") }, onClick = {
                                selectedRaceId = race.id; raceMenuExpanded = false
                            })
                        }
                    }
                }
                Text("Vincule somente quando esta atividade corresponder à prova. Com distância e duração reais, ela fica associada ao resultado e marca a prova como concluída. Só entra na estimativa de velocidade crítica se também cumprir os critérios de esforço forte (RPE ≥ 7), ausência de dor, atualidade e diversidade de distâncias/durações.", color = TextMuted, fontSize = 10.sp, lineHeight = 14.sp)
            }
        }
        val talkEntryValid = talkTestPace.isBlank() ||
            TalkTestCalibrationRules.normalizeEntry(workout?.type.orEmpty(), talkTestPace) != null
        PrimaryButton(if (existingFeedback != null) "Atualizar registro da sessão" else "Salvar feedback e registrar sessão", enabled = workout != null && (actualDuration.isBlank() || PaceCalculator.parseDuration(actualDuration) != null) && talkEntryValid) {
            if (state.saveFeedback(
                    effort, feeling, notes, pain == "Sim", actualDistance, actualDuration,
                    talkTestPace, importedActivity, activityTerrain, selectedRaceId
                )) {
                state.navigateTo(Screen.HISTORY)
            }
        }
        if (state.motorError.isNotBlank()) NoteBlock(state.motorError)
    }
}

@Composable private fun FeedbackGroup(title: String, options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text(title, color = TextMuted, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 20.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            options.forEach { option ->
                val active = option == selected
                Surface(
                    modifier = Modifier.clickable { onSelect(option) },
                    shape = RoundedCornerShape(50),
                    color = if (active) Color(0xFF344B78) else CardBlue,
                    border = if (active) androidx.compose.foundation.BorderStroke(1.dp, Blue2) else null
                ) { Text(option, color = if (active) Color.White else TextMuted, fontSize = 11.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) }
            }
        }
    }
}

@Composable private fun HistoryScreen(state: CoachState) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 22.dp)) {
        Header("Histórico de treinos")
        val completed = state.completedWorkouts().asReversed()
        val archivedFeedback = state.orphanFeedbackRecords().asReversed()
        if (completed.isEmpty() && archivedFeedback.isEmpty()) {
            EmptyStateCard("Nenhuma sessão concluída", "Quando registrar o feedback de uma sessão, ela ficará salva aqui mesmo depois de recalcular um novo plano.", "Voltar ao início") { state.navigateBack(Screen.DASHBOARD) }
        } else {
            SectionHeading("Sessões registradas", "${completed.size + archivedFeedback.size} no total")
            completed.forEach { workout ->
                WorkoutCard(workout) { state.selectWorkout(workout); state.navigateTo(Screen.FEEDBACK) }
                state.feedbackForSession(workout.sessionId)?.let { FeedbackHistoryDetails(it, state.feedbackActivityDate(it)) }
            }
            if (archivedFeedback.isNotEmpty()) {
                SectionHeading("Registros preservados de ciclos anteriores")
                archivedFeedback.forEach { FeedbackHistoryDetails(it, state.feedbackActivityDate(it)) }
            }
        }
    }
}

@Composable private fun FeedbackHistoryDetails(record: FeedbackRecord, realizedDate: LocalDate? = null) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 3.dp), containerColor = Color(0xFF142338)) {
        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(record.workoutTitle.ifBlank { record.workoutType.ifBlank { "Feedback de treino" } }, color = Blue2, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            val actualLabel = realizedDate?.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) ?: "Data não informada"
            val plannedLabel = record.workoutDateIso.takeIf { it.isNotBlank() }?.let {
                runCatching { LocalDate.parse(it).format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) }.getOrNull()
            }
            val datesLabel = if (plannedLabel != null && plannedLabel != actualLabel) {
                "Realizado $actualLabel • planejado $plannedLabel"
            } else "Realizado $actualLabel"
            Text("$datesLabel • Esforço: ${record.effort} • Sensação: ${record.feeling}", color = TextMuted, fontSize = 10.sp)
            val distance = record.actualDistanceKm?.let { "${formatKmUi(it)} km reais" } ?: "Distância real não informada"
            val duration = record.actualDuration ?: "Tempo real não informado"
            val pace = record.actualPaceMinKm?.let { " • $it min/km" }.orEmpty()
            Text("$distance • $duration$pace", color = TextWhite, fontSize = 11.sp)
            record.talkTestPaceMmSs?.let { pace ->
                val usable = TalkTestCalibrationRules.canCalibrate(record.effort, record.feeling, record.painPresent)
                Text(
                    "Teste da fala: $pace min/km" + if (usable) " • observação válida para Z2" else " • armazenado, não usado na calibração",
                    color = if (usable) Green else TextMuted,
                    fontSize = 10.sp
                )
            }
            Text("Terreno: ${RunningTerrain.label(record.terrain)}", color = TextMuted, fontSize = 10.sp)
            if (record.raceEventId.isNotBlank()) Text("Atividade vinculada a uma prova • pode compor evidências fisiológicas quando válida", color = Green, fontSize = 10.sp)
            if (record.activitySourceFormat.isNotBlank()) {
                Text("Atividade ${record.activitySourceFormat} importada • ${record.routePointCount} pontos GPS", color = Blue2, fontSize = 10.sp)
                val metrics = listOfNotNull(
                    record.elevationGainMeters?.let { "Elevação +${it.roundToInt()} m" },
                    record.averageHeartRateBpm?.let { "FC média $it bpm" },
                    record.maxHeartRateBpm?.let { "FC máx. $it bpm" },
                    record.averageCadenceSpm?.let { "Cadência $it spm" }
                )
                if (metrics.isNotEmpty()) Text(metrics.joinToString(" • "), color = TextMuted, fontSize = 10.sp)
                if (record.splitPacesMmSs.isNotEmpty()) Text("Parciais: ${record.splitPacesMmSs.joinToString(" / ")} min/km", color = TextMuted, fontSize = 10.sp)
            }
            if (record.painPresent) Text("Dor relatada • revisar recuperação antes de nova carga", color = Color(0xFFFFA4A4), fontSize = 10.sp)
            if (record.notes.isNotBlank()) Text(record.notes, color = TextMuted, fontSize = 10.sp)
        }
    }
}

@Composable private fun CalibrationStatusLine(title: String, status: String, count: Int, required: Int) {
    val calibrated = status == ZoneCalibrationEngine.CALIBRATED
    val detail = when (status) {
        ZoneCalibrationEngine.CALIBRATED -> "Calibrada • $count evidências válidas"
        ZoneCalibrationEngine.OBSERVATION -> "Em observação • $count/$required evidências"
        ZoneCalibrationEngine.UNSTABLE -> "Instável • dados contraditórios; faixa-base preservada"
        ZoneCalibrationEngine.REVIEW -> "Reavaliação • fronteira em ajuste gradual ou referência fora da faixa atual"
        else -> "Inicial • $count/$required evidências"
    }
    Text("$title — $detail", color = if (calibrated) Green else if (status == ZoneCalibrationEngine.UNSTABLE || status == ZoneCalibrationEngine.REVIEW) Yellow else TextMuted, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
}

@Composable private fun PaceZonesScreen(state: CoachState) {
    val zones = state.currentPaceZones()
    val review = state.cooperReviewStatus()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Zonas de pace Z1–Z5", true) { state.navigateBack(Screen.PROFILE) }
        if (zones == null) {
            EmptyStateCard("Zonas ainda não calibradas", "Registre um Cooper de 12 minutos ou um teste de 3 km válido. O treinador estimará VO₂máx e as faixas individuais Z1–Z5.", "Calibrar pace") { state.openFieldTestEditor() }
        } else {
            CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20344E)) {
                Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("REFERÊNCIA ATUAL", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                    Text(if (listOf(zones.z1CalibrationStatus, zones.z2CalibrationStatus, zones.z3CalibrationStatus).any { it == ZoneCalibrationEngine.CALIBRATED }) "Zonas individualizadas por evidências reais" else "Faixas operacionais estimadas pelo teste de campo", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    InfoRow("VAM estimada (referência complementar)", "${zones.estimatedMasPace} min/km")
                    InfoRow("Segundo limiar estimado (complementar)", "${zones.estimatedSvt2Pace} min/km")
                    CalibrationStatusLine("Z1 • Recuperação", zones.z1CalibrationStatus, zones.z1CalibrationEvidenceCount, 3)
                    CalibrationStatusLine("Z2 • Teste da fala", zones.z2CalibrationStatus, zones.z2CalibrationEvidenceCount, 3)
                    CalibrationStatusLine("Z3 • Desempenho", zones.z3CalibrationStatus, zones.z3CalibrationEvidenceCount, 2)
                    zones.z1CalibrationReferencePaceValue?.let { InfoRow("Referência observada Z1", "${PaceRange.format(it)} min/km") }
                    zones.z2CalibrationReferencePaceValue?.let { InfoRow("Referência observada Z2", "${PaceRange.format(it)} min/km") }
                    zones.z3CalibrationReferencePaceValue?.let { InfoRow("Fronteira operacional Z3", "${PaceRange.format(it)} min/km") }
                    val last = state.cooperAssessments.lastOrNull()
                    if (last != null) {
                        InfoRow("Teste de referência", if (last.testMethod == "THREE_KM") "3 km • ${last.testDurationSeconds?.let(PhysiologicalProfileEngine::formatDuration) ?: "—"}" else "Cooper • ${formatKmUi(last.distanceKm)} km em 12 min")
                        InfoRow("Pace médio", "${last.averagePace} min/km")
                        InfoRow("VO₂máx estimado", String.format(Locale.US, "%.1f ml/kg/min", last.estimatedVo2Max))
                    }
                    Text("Z1–Z5 são faixas operacionais. Registros de treino refinam Z1–Z3; provas e testes válidos podem atualizar a avaliação fisiológica. Z4–Z5 continuam estimativas de campo.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                    Text("Cada treino usa uma faixa ativa dentro da zona. Nesta escala interna, 100% é o limite de pace mais rápido e 0% o mais lento; não é percentual de VO₂máx. Rodagens e longões usam subfaixas conservadoras diferentes.", color = Blue2, fontSize = 10.sp, lineHeight = 15.sp)
                    Text("Ajustes automáticos exigem registros consistentes e sem relato de dor. O pace de competição nunca substitui uma zona fisiológica.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                    Text(review.message, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                    val method = last?.testMethod ?: "COOPER_12_MIN"
                    CooperAssessmentEngine.improvementSincePrevious(state.cooperAssessments, method)?.let { change ->
                        val sign = if (change >= 0.0) "+" else ""
                        Text("Evolução no mesmo teste: $sign${String.format(Locale.US, "%.1f", change)}%", color = if (change >= 0.0) Green else Yellow, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            zones.all().forEach { zone ->
                CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(zone.id, color = Blue2, fontSize = 19.sp, fontWeight = FontWeight.Black)
                            Spacer(Modifier.width(10.dp))
                            Text(zone.name, color = TextWhite, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Text(zone.range.label(), color = Green, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Text(zone.purpose, color = TextMuted, fontSize = 11.sp)
                        Text(zone.intensityBand, color = TextMuted, fontSize = 10.sp)
                    }
                }
            }
            NoteBlock("Atividades comuns alimentam carga e recuperação, mas não são tratadas como testes máximos. VO₂máx e limiares permanecem estimativas de campo.")
            if (state.workouts.isNotEmpty()) {
                PrimaryButton("Aplicar calibração ao plano") {
                    val updated = state.recalibratePlan()
                    if (!updated && state.motorError.isBlank()) state.motorError = "Não foi possível recalibrar o plano. Confira o perfil e os dados de recuperação."
                }
                if (state.latestCooperMessage.isNotBlank()) NoteBlock(state.latestCooperMessage)
            }
        }
        PrimaryButton("Registrar teste fisiológico") { state.openFieldTestEditor() }
    }
}

@Composable private fun CooperTestScreen(state: CoachState) {
    val zones = state.selectedFieldTestZones()
    val assessment = zones?.let { z ->
        state.parsedAgeYears()?.let { age -> RunnerFitnessAssessmentEngine.assess(z.estimatedVo2Max, age, state.referenceSex, "FIELD_ESTIMATE") }
    }
    val testIsValid = state.fitnessTestMethod != "NONE" && state.isCooperEntryValid() && zones != null
    val methodLabel = when (state.fitnessTestMethod) {
        "THREE_KM" -> "Corrida de 3 km"
        "COOPER_12_MIN" -> "Cooper (12 min)"
        else -> "Selecione o teste"
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Teste fisiológico", true) { state.navigateBack(Screen.PROFILE) }
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20344E)) {
            Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("AVALIAÇÃO DE VO₂MÁX", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                Text("O resultado define o nível fisiológico e atualiza as zonas de pace.", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Text("Use um percurso plano, medido e condições seguras. O teste substitui uma sessão intensa.", color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
            }
        }
        SectionHeading("Método e dados")
        CardSurface(Modifier.padding(horizontal = 16.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                CompactChoiceScreen("Teste", listOf("Cooper (12 min)", "Corrida de 3 km"), methodLabel) { selected ->
                    state.fitnessTestMethod = if (selected == "Corrida de 3 km") "THREE_KM" else "COOPER_12_MIN"
                    state.cooperEnabled = true
                    state.refreshPhysiologicalLevelFromTest()
                }
                OutlinedTextField(
                    value = state.ageYearsText,
                    onValueChange = { state.ageYearsText = it.filter(Char::isDigit).take(3); state.refreshPhysiologicalLevelFromTest() },
                    label = { Text("Idade no teste (anos)") }, modifier = Modifier.fillMaxWidth(), singleLine = true
                )
                CompactChoiceScreen("Referência fisiológica", listOf("Masculino", "Feminino"), when (state.referenceSex) {
                    RunnerFitnessAssessmentEngine.MALE -> "Masculino"
                    RunnerFitnessAssessmentEngine.FEMALE -> "Feminino"
                    else -> ""
                }) {
                    state.referenceSex = if (it == "Masculino") RunnerFitnessAssessmentEngine.MALE else RunnerFitnessAssessmentEngine.FEMALE
                    state.refreshPhysiologicalLevelFromTest()
                }
                when (state.fitnessTestMethod) {
                    "THREE_KM" -> {
                        OutlinedTextField(
                            value = state.threeKmTimeText,
                            onValueChange = { state.threeKmTimeText = it.filter { c -> c.isDigit() || c == ':' }.take(5); state.refreshPhysiologicalLevelFromTest() },
                            label = { Text("Tempo para 3 km (mm:ss)") }, placeholder = { Text("Ex.: 15:30") },
                            modifier = Modifier.fillMaxWidth(), singleLine = true
                        )
                        Text("Equação de campo estudada para adultos de 18 a 39 anos. Fora dessa faixa, use o Cooper.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                    }
                    else -> {
                        OutlinedTextField(
                            value = state.cooperDistanceText,
                            onValueChange = { state.cooperDistanceText = it.filter { c -> c.isDigit() || c == ',' || c == '.' }.take(6); state.refreshPhysiologicalLevelFromTest() },
                            label = { Text("Distância em 12 minutos (km)") }, placeholder = { Text("Ex.: 2,40") },
                            modifier = Modifier.fillMaxWidth(), singleLine = true
                        )
                        Text("Registre a distância total percorrida em 12 minutos.", color = TextMuted, fontSize = 10.sp)
                    }
                }
                OutlinedTextField(
                    value = state.cooperAssessmentDateText,
                    onValueChange = { state.cooperAssessmentDateText = it.filter { c -> c.isDigit() || c == '/' }.take(10); state.persist() },
                    label = { Text("Data do teste (dd/mm/aaaa)") }, modifier = Modifier.fillMaxWidth(), singleLine = true
                )
                if (assessment != null) {
                    HorizontalDivider(color = Color(0x443F5878))
                    InfoRow("VO₂máx estimado", String.format(Locale.US, "%.1f ml/kg/min", assessment.vo2Max))
                    InfoRow("Nível fisiológico", assessment.level)
                    InfoRow("Método", methodLabel)
                    val thresholds = assessment.thresholds
                    Text("Faixas da sua referência etária (ml/kg/min)", color = Blue2, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    listOf(
                        "Iniciante" to "< ${String.format(Locale.US, "%.1f", thresholds.intermediate)}",
                        "Intermediário" to "${String.format(Locale.US, "%.1f", thresholds.intermediate)}–${String.format(Locale.US, "%.1f", thresholds.performance - 0.1)}",
                        "Performance" to "${String.format(Locale.US, "%.1f", thresholds.performance)}–${String.format(Locale.US, "%.1f", thresholds.elite - 0.1)}",
                        "Elite" to "≥ ${String.format(Locale.US, "%.1f", thresholds.elite)}"
                    ).forEach { (label, range) ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(label, color = TextMuted, fontSize = 10.sp)
                            Text(range, color = TextWhite, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    Text("Referência geral de aptidão cardiorrespiratória por idade e sexo; não é ranking competitivo.", color = TextMuted, fontSize = 9.sp, lineHeight = 13.sp)
                    Text("Zonas individuais (min/km)", color = Blue2, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    zones!!.all().forEach { InfoRow("${it.id} • ${it.name}", it.range.label()) }
                }
            }
        }
        Text("A estimativa de campo não substitui uma medição laboratorial. A experiência de corrida não muda o nível; volume e recuperação ajustam a dose do plano.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp, modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp))
        val latestWithoutReference = state.cooperAssessments.maxByOrNull { it.dateIso }?.let { it.ageAtTest == null || it.referenceSex !in setOf(RunnerFitnessAssessmentEngine.MALE, RunnerFitnessAssessmentEngine.FEMALE) } == true
        if (latestWithoutReference) {
            CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp), containerColor = Navy2) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("TESTE ANTIGO SEM REFERÊNCIA ETÁRIA", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("Você pode vincular idade e referência fisiológica ao resultado já salvo sem repetir o Cooper. Informe a idade que tinha no dia daquele teste.", color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                    SecondaryButton("Aplicar ao teste já salvo", enabled = state.parsedAgeYears() != null && state.referenceSex in setOf(RunnerFitnessAssessmentEngine.MALE, RunnerFitnessAssessmentEngine.FEMALE)) {
                        if (state.attachDemographicsToLatestTest()) state.navigateBack(Screen.PROFILE)
                    }
                }
            }
        }
        if (state.latestCooperMessage.isNotBlank()) NoteBlock(state.latestCooperMessage)
        PrimaryButton("Salvar teste e atualizar plano", enabled = testIsValid) {
            val saved = state.saveSelectedFieldTestAndReplan()
            if (saved && state.workouts.isNotEmpty()) state.navigateTo(Screen.PLAN)
        }
        SectionHeading("Histórico de testes")
        if (state.cooperAssessments.isEmpty()) {
            EmptyStateCard("Nenhum teste registrado", "Os resultados de Cooper e 3 km ficam guardados para comparação.", "Voltar ao perfil") { state.navigateBack(Screen.PROFILE) }
        } else {
            state.cooperAssessments.asReversed().forEach { record ->
                CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(record.dateIso, color = Blue2, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text(if (record.testMethod == "THREE_KM") "3 km em ${record.testDurationSeconds?.let(PhysiologicalProfileEngine::formatDuration) ?: "—"}" else "Cooper • ${formatKmUi(record.distanceKm)} km em 12 min", color = TextWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        val recordedReference = if (record.ageAtTest != null && record.referenceSex in setOf(RunnerFitnessAssessmentEngine.MALE, RunnerFitnessAssessmentEngine.FEMALE)) {
                            "${record.ageAtTest} anos • ${if (record.referenceSex == RunnerFitnessAssessmentEngine.MALE) "masculino" else "feminino"} • ${RunnerFitnessAssessmentEngine.assess(record.estimatedVo2Max, record.ageAtTest, record.referenceSex, "FIELD_ESTIMATE")?.level ?: "nível indisponível"}"
                        } else "idade/referência não registradas na data — nível não classificado"
                        Text("VO₂máx estimado ${String.format(Locale.US, "%.1f", record.estimatedVo2Max)} ml/kg/min • $recordedReference", color = TextMuted, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable private fun TrainingLibraryScreen(state: CoachState) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Biblioteca de treinos", true) { state.navigateBack(Screen.PROFILE) }
        CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), containerColor = Color(0xFF1B3048)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("COMO O TREINADOR USA A BIBLIOTECA", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text("Os estímulos são selecionados conforme objetivo, experiência, carga recente, recuperação e fase do ciclo. Nem todos aparecem no mesmo plano.", color = TextMuted, fontSize = 12.sp, lineHeight = 18.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                    StatusPill("Automático", Green)
                    StatusPill("Condicional", Blue2)
                    StatusPill("Não integrado", Yellow)
                }
            }
        }
        SectionHeading("Treinos da prescrição")
        TrainingTypeCatalog.all.forEach { item ->
            val status = TrainingTypeCatalog.prescriptionStatus(item.id)
            val statusColor = when {
                status.startsWith("Não integrado") -> Yellow
                status.startsWith("Condicional") || status == "Complementar" -> Blue2
                else -> Green
            }
            CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
                Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(item.title, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("Zona de referência: ${item.zone}", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                        }
                        StatusPill(status, statusColor)
                    }
                    Text(item.objective, color = TextWhite, fontSize = 12.sp, lineHeight = 17.sp)
                    Text(TrainingTypeCatalog.prescriptionDetail(item.id), color = statusColor, fontSize = 10.sp, lineHeight = 15.sp)
                    Text("Estrutura", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(item.structure, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                    Text("Quando entra: ${item.use}.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                }
            }
        }
        SectionHeading("Fortalecimento complementar")
        NoteBlock("As rotinas de força são sugestões complementares. Nesta versão, elas não são inseridas automaticamente no calendário de corrida.")
        StrengthTrainingCatalog.all.forEach { routine ->
            CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
                Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(routine.title, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        StatusPill(routine.duration, Blue2)
                    }
                    Text(routine.focus, color = Blue2, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Text(routine.exercises, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                    Text(routine.guidance, color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                }
            }
        }
    }
}

@Composable private fun BackupScreen(state: CoachState) {
    var pendingRestoreUri by remember { mutableStateOf<Uri?>(null) }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) state.exportBackup(uri)
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) pendingRestoreUri = uri
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Backup e restauração", true) { state.navigateBack(Screen.PROFILE) }
        CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp), containerColor = Color(0xFF1B3048)) {
            Column(Modifier.fillMaxWidth().padding(17.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("SEUS DADOS, SOB SEU CONTROLE", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text("Crie um arquivo de backup para guardar fora do celular. Ao trocar de aparelho, importe esse arquivo para recuperar suas informações.", color = TextMuted, fontSize = 12.sp, lineHeight = 18.sp)
            }
        }
        SectionHeading("O que será protegido")
        listOf(
            "Perfil, objetivo, nível e disponibilidade semanal",
            "Plano de treinamento, sessões, blocos e alternativas selecionadas",
            "Histórico de sessões concluídas e feedbacks",
            "Testes fisiológicos, calibrações e zonas de pace",
            "Competições, datas, prioridades e observações",
            "Estado e configurações persistidas do treinador"
        ).forEach { item ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 5.dp), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("✓", color = Green, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(item, color = TextWhite, fontSize = 12.sp, lineHeight = 17.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        PrimaryButton("Exportar backup completo") {
            exportLauncher.launch("AI-Running-Coach-backup-${LocalDate.now().format(DateTimeFormatter.ISO_DATE)}.json")
        }
        SecondaryButton("Importar backup de outro aparelho") {
            importLauncher.launch(arrayOf("application/json", "text/json", "application/octet-stream"))
        }
        if (state.backupMessage.isNotBlank()) {
            NoteBlock(state.backupMessage)
        }
        NoteBlock("A restauração substitui os dados atualmente salvos neste aparelho pelos dados do arquivo escolhido. Exporte um backup atual antes de restaurar. O arquivo JSON não é criptografado e contém dados pessoais e esportivos; guarde-o em local seguro.")
    }
    if (pendingRestoreUri != null) {
        AlertDialog(
            onDismissRequest = { pendingRestoreUri = null },
            title = { Text("Restaurar backup?") },
            text = { Text("Os dados atuais do AI Running Coach serão substituídos pelo conteúdo do arquivo selecionado. Recomendamos exportar um backup atual antes de continuar.") },
            confirmButton = {
                TextButton(onClick = {
                    val uri = pendingRestoreUri
                    pendingRestoreUri = null
                    if (uri != null) state.restoreBackup(uri)
                }) { Text("Restaurar") }
            },
            dismissButton = { TextButton(onClick = { pendingRestoreUri = null }) { Text("Cancelar") } }
        )
    }
}

@Composable private fun ProfileScreen(state: CoachState) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Perfil do atleta")
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20344E)) {
            Column(Modifier.padding(19.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Surface(shape = RoundedCornerShape(20.dp), color = Color(0xFF3C527A), modifier = Modifier.size(54.dp)) { Box(contentAlignment = Alignment.Center) { Text(state.name.take(1).uppercase(), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold) } }
                    Column {
                        Text(state.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("${state.physiologicalLevelDisplay()} • AI Running Coach", color = Color(0xFFD0D9EA), fontSize = 11.sp)
                    }
                }
                HorizontalDivider(color = Color(0x446F8DB8))
                OutlinedTextField(
                    value = state.name,
                    onValueChange = { state.name = it.take(40); state.persist() },
                    label = { Text("Nome do atleta") },
                    modifier = Modifier.fillMaxWidth(), singleLine = true
                )
                val latestTest = state.cooperAssessments.maxByOrNull { it.dateIso }
                val loadSnapshot = state.trainingLoadSnapshot()
                InfoRow("Nível fisiológico", state.physiologicalLevelDisplay())
                InfoRow("VO₂máx estimado", latestTest?.let { "${String.format(Locale.US, "%.1f", it.estimatedVo2Max)} ml/kg/min" } ?: "Aguardando teste")
                InfoRow("Idade na data do teste", latestTest?.ageAtTest?.let { "$it anos" } ?: if (latestTest != null) "Não salva — completar referência" else state.ageYearsText.takeIf { it.isNotBlank() }?.let { "$it anos no perfil" } ?: "Não informada")
                InfoRow("Referência fisiológica do teste", latestTest?.referenceSex?.let { sex -> when (sex) { RunnerFitnessAssessmentEngine.MALE -> "Masculina"; RunnerFitnessAssessmentEngine.FEMALE -> "Feminina"; else -> "Não informada" } } ?: if (latestTest != null) "Não salva — completar referência" else when (state.referenceSex) { RunnerFitnessAssessmentEngine.MALE -> "Masculina"; RunnerFitnessAssessmentEngine.FEMALE -> "Feminina"; else -> "Não informada" })
                InfoRow("Objetivo", goalLabel(state))
                InfoRow("O que deseja alcançar", TrainingGoalIntent.label(state.goalIntent))
                InfoRow("Disponibilidade", state.availableTrainingDays.joinToString(", ") { dayLabel(it) }.ifBlank { "Não configurada" })
                InfoRow("Dia do longão", state.preferredLongRunDay?.let(::dayLabel) ?: "Não definido")
                InfoRow("Terreno habitual", RunningTerrain.label(state.terrainPreference))
                InfoRow("Experiência regular", state.runningExperienceDuration.ifBlank { "Não informada" })
                InfoRow("Volume semanal informado", if (state.weeklyVolumeText.isBlank()) "Não informado" else "${state.weeklyVolumeText} km/semana")
                InfoRow("Maior sessão recente informada", if (state.longestRecent.isBlank()) "Sem histórico informado" else "${state.longestRecent} km")
                InfoRow("Quilômetros registrados (28 dias)", "${formatKmUi(loadSnapshot.totalKmLast28Days)} km")
                InfoRow("Corridas registradas (28 dias)", loadSnapshot.recordedRunsLast28Days.toString())
                InfoRow("Semanas com atividade (28 dias)", "${loadSnapshot.activeWeeksLast28Days} de 4")
                InfoRow("Média registrada (28 dias)", loadSnapshot.averageWeeklyKmLast28Days?.let { "${formatKmUi(it)} km/semana" } ?: "Histórico insuficiente")
                InfoRow("Último teste", latestTest?.let { record ->
                    val method = if (record.testMethod == "THREE_KM") "3 km em ${record.testDurationSeconds?.let(PhysiologicalProfileEngine::formatDuration) ?: "—"}" else "Cooper • ${String.format(Locale.US, "%.2f", record.distanceKm)} km"
                    "$method • VO₂ ${String.format(Locale.US, "%.1f", record.estimatedVo2Max)}"
                } ?: "Não realizado")
                InfoRow("Data do último teste", latestTest?.dateIso ?: "Não realizado")
                InfoRow("Tempo-alvo", if (state.goalIntent == TrainingGoalIntent.TARGET_TIME) state.goalTargetTimeText.ifBlank { "Não informado" } else "Não definido")
                InfoRow("Duração do ciclo", "${state.planWeeks} semanas")
            }
        }
        SectionHeading("Gerenciar perfil")
        val availabilitySummary = if (state.availableTrainingDays.isEmpty()) {
            "Definir dias de corrida e preferência do longão"
        } else {
            val longRun = state.preferredLongRunDay?.let { "Longão: ${dayLabel(it)}" } ?: "Longão não definido"
            "${state.availableTrainingDays.size} dias disponíveis • $longRun"
        }
        ProfileAction("Disponibilidade semanal", availabilitySummary, "▦") {
            state.scheduleActionMessage = ""
            state.navigateTo(Screen.AVAILABILITY)
        }
        state.runnerReadinessSnapshot()?.let { readiness ->
            CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), containerColor = Navy2) {
                Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("AVALIAÇÃO DE PRONTIDÃO", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("${readiness.goalBand} • ${state.physiologicalLevelDisplay()}", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("${readiness.selectedFrequency} dias/semana • início: ${formatKmUi(readiness.initialRecommendedWeeklyKm)} km/semana", color = TextMuted, fontSize = 11.sp)
                    Text("Ajustes de carga usam volume real, maior sessão recente e resposta aos treinos. Consulte a leitura do treinador para a justificativa.", color = TextMuted, fontSize = 10.sp, lineHeight = 14.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        ProfileAction("Revisar cadastro do atleta", "Nome, teste fisiológico, objetivo, rotina e carga", "✎") { state.onboardingStep = 0; state.persist() }
        ProfileAction("Exportar sessão para Pace Coach", "Compartilhar uma prescrição estruturada", "⇧") { state.navigateTo(Screen.EXPORT) }
        ProfileAction("Teste fisiológico", "Cooper 12 min ou corrida de 3 km", "◷") { state.openFieldTestEditor() }
        ProfileAction("Zonas de pace Z1–Z5", "Consultar faixas atuais em mm:ss min/km", "⌁") { state.navigateTo(Screen.PACE_ZONES) }
        ProfileAction("Competições", "Cadastrar provas e ajustar a preparação", "🏁") { state.navigateTo(Screen.RACES) }
        ProfileAction("Biblioteca de treinos", "Consultar os estímulos reconhecidos pelo motor", "▤") { state.navigateTo(Screen.TRAINING_LIBRARY) }
        ProfileAction("Consultar sessões concluídas", "Ver feedback, distância e ritmo registrado", "◷") { state.navigateTo(Screen.HISTORY) }
        ProfileAction("Backup e restauração", "Exportar ou recuperar todos os dados do aplicativo", "⇄") { state.backupMessage = ""; state.navigateTo(Screen.BACKUP) }
        CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("Privacidade e funcionamento", color = Blue2, fontWeight = FontWeight.Bold)
                Text("O perfil, o plano e os feedbacks são armazenados localmente neste dispositivo. O Pace Coach continua responsável pela execução, GPS, áudio e registro das corridas.", color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
            }
        }
    }
}

@Composable private fun AvailabilityScreen(state: CoachState) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Minha disponibilidade semanal", true) { state.navigateBack(Screen.PROFILE) }
        Text(
            "Escolha os dias em que você consegue correr habitualmente. O treinador distribuirá as sessões somente nesses dias e respeitará sua preferência para o longão. As alterações são salvas automaticamente.",
            color = TextMuted,
            fontSize = 12.sp,
            lineHeight = 18.sp,
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 2.dp)
        )
        TrainingAvailabilityEditor(state, showLongRunPreference = true)
        if (state.needsEngineRefresh) {
            NoteBlock("Sua disponibilidade mudou. Recalcule o plano para redistribuir os treinos sem alterar sessões concluídas.")
            PrimaryButton("Recalcular plano com minha disponibilidade") { state.createPlan() }
        }
    }
}

@Composable private fun ProfileAction(title: String, description: String, icon: String, onClick: () -> Unit) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp).clickable(onClick = onClick)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Surface(shape = RoundedCornerShape(13.dp), color = Color(0xFF293E5C), modifier = Modifier.size(40.dp)) { Box(contentAlignment = Alignment.Center) { Text(icon, color = Blue2, fontSize = 18.sp) } }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text(description, color = TextMuted, fontSize = 10.sp)
            }
            Text("›", color = TextMuted, fontSize = 23.sp)
        }
    }
}

@Composable private fun ExportScreen(state: CoachState) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val workout = state.selectedWorkout()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Compartilhar com Pace Coach", true) { state.navigateBack(Screen.WORKOUT) }
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20344E)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("PRESCRIÇÃO ESTRUTURADA", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                Text(workout?.title ?: "Nenhuma sessão selecionada", color = TextWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                if (workout != null) Text("${workout.date} • ~${formatKmUi(workout.distanceKm)} km estimados • ${workout.segments.size} blocos", color = TextMuted, fontSize = 11.sp)
                Text("O AI Running Coach planeja. O Pace Coach executa e registra o treino.", color = TextMuted, fontSize = 11.sp)
            }
        }
        SectionHeading("O que será compartilhado")
        val exportName = workout?.let { WorkoutExportNaming.name(it, state.workouts) }
        StepExport("01", "Nome do arquivo", exportName?.let { "$it.json" } ?: "Semana, número do treino, nome e data")
        StepExport("02", "Blocos de treino", workout?.let { "${it.segments.size} blocos • Aquecimento, estímulos, recuperação e desaquecimento" } ?: "Estrutura da sessão")
        StepExport("03", "Alvo de execução", workout?.let {
            val modes = it.segments.map { segment -> segment.targetMode }.distinct()
            val modeLabel = when (modes.size) { 2 -> "Tempo + distância"; 1 -> if (modes.first() == "TIME") "Tempo" else "Distância"; else -> "Sem blocos" }
            "$modeLabel • Pace ${it.primaryPaceRange() ?: "não calibrado"} min/km • RPE ${it.rpeRange} como apoio"
        } ?: "Etapas por tempo ou distância, com pace em min/km quando houver referência")
        NoteBlock("A transferência anexa um arquivo .json no formato nativo UserWorkoutJson do Pace Coach. Etapas são exportadas por tempo (ms) ou distância (m), com pace convertido para a unidade Garmin e repetições preservadas em grupos.")
        PrimaryButton("Compartilhar arquivo JSON", enabled = workout != null) {
            val selected = workout
            if (selected != null) {
                val prescription = selected.toPrescribedWorkout()
                val goalDistanceKm = TrainingGoalCatalog.distanceForLabel(
                    state.goal, state.customGoalKm.trim().replace(",", ".").toDoubleOrNull()
                ) ?: 5.0
                val friendlyName = WorkoutExportNaming.name(selected, state.workouts)
                val json = PaceCoachExporter.workoutToJson(prescription, state.goal, goalDistanceKm, friendlyName)
                val jsonFile = PaceCoachJsonAttachment.create(context.cacheDir, friendlyName, json)
                val contentUri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    jsonFile
                )
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    type = PaceCoachJsonAttachment.MIME_TYPE
                    putExtra(Intent.EXTRA_SUBJECT, "Prescrição — ${selected.title}")
                    putExtra(Intent.EXTRA_STREAM, contentUri)
                    clipData = ClipData.newUri(context.contentResolver, jsonFile.name, contentUri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(sendIntent, "Enviar treino compatível com o Pace Coach"))
            }
        }
    }
}

private fun Workout.primaryPaceRange(): String? {
    val preferred = segments.firstOrNull { it.name.contains("principal", true) || it.name.contains("aeróbio", true) || it.name.contains("longão", true) }
        ?: segments.firstOrNull { it.targetPaceMinValue != null && it.targetPaceMaxValue != null }
    val minPace = preferred?.targetPaceMinValue ?: return null
    val maxPace = preferred.targetPaceMaxValue ?: return null
    return "${PaceRange.format(minPace)}–${PaceRange.format(maxPace)}"
}

private fun Workout.toPrescribedWorkout(): PrescribedWorkout = PrescribedWorkout(
    day = date.substringBefore(","), date = date, scheduledDateIso = scheduledDateIso, title = title, type = type, objective = objective,
    stimulus = stimulus, sessionId = sessionId, distanceKm = distanceKm, durationMin = durationMin,
    intensity = intensity, paceMode = paceMode, rpeRange = rpeRange, detail = detail,
    rationale = rationale, week = week, phase = phase, segments = segments,
    paceCalibrationSnapshot = paceCalibrationSnapshot
)

@Composable private fun BottomNav(state: CoachState) {
    Row(
        Modifier.fillMaxWidth().background(Color(0xFF0D1726)).padding(horizontal = 9.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        DockItem(Modifier.weight(1f), "⌂", "Início", state.selectedScreen == Screen.DASHBOARD) { state.navigateTo(Screen.DASHBOARD) }
        DockItem(Modifier.weight(1f), "▦", "Agenda", state.selectedScreen == Screen.CALENDAR) { state.navigateTo(Screen.CALENDAR) }
        DockItem(Modifier.weight(1f), "≋", "Plano", state.selectedScreen == Screen.PLAN) { state.navigateTo(Screen.PLAN) }
        DockItem(Modifier.weight(1f), "↗", "Evolução", state.selectedScreen == Screen.EVOLUTION) { state.navigateTo(Screen.EVOLUTION) }
        DockItem(Modifier.weight(1f), "•••", "Mais", state.selectedScreen == Screen.PROFILE || state.selectedScreen == Screen.AVAILABILITY || state.selectedScreen == Screen.HISTORY || state.selectedScreen == Screen.RACES) { state.navigateTo(Screen.PROFILE) }
    }
}

@Composable private fun DockItem(modifier: Modifier, icon: String, label: String, selected: Boolean, onClick: () -> Unit) {
    Column(modifier.clickable(onClick = onClick).padding(vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Surface(shape = RoundedCornerShape(15.dp), color = if (selected) Color(0xFF2B4168) else Color.Transparent) {
            Box(Modifier.widthIn(min = 52.dp).height(32.dp).padding(horizontal = 13.dp), contentAlignment = Alignment.Center) {
                Text(icon, color = if (selected) Color.White else TextMuted, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            }
        }
        Text(label, color = if (selected) Blue2 else TextMuted, fontSize = 9.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium)
    }
}

@Composable private fun SectionHeading(title: String, action: String? = null, onAction: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 21.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = TextWhite, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (action != null) Text(
            action, color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold,
            maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = (if (onAction != null) Modifier.clickable(onClick = onAction) else Modifier).widthIn(max = 118.dp)
        )
    }
}

@Composable private fun CardSurface(modifier: Modifier = Modifier, containerColor: Color = CardBlue, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier = modifier, shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = containerColor), content = content)
}

@Composable private fun StatusPill(text: String, color: Color) {
    Surface(shape = RoundedCornerShape(50), color = color.copy(alpha = 0.13f), border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.35f))) {
        Text(
            text, color = color, fontSize = 9.sp, lineHeight = 11.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp),
            maxLines = 2, softWrap = true, textAlign = TextAlign.Center
        )
    }
}

@Composable private fun ProgressTrack(progress: Float, color: Color = Blue2, trackColor: Color = Color(0xFF2A3D55)) {
    Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)).background(trackColor)) {
        if (progress > 0f) Box(Modifier.fillMaxWidth(progress.coerceIn(0f, 1f)).fillMaxHeight().clip(RoundedCornerShape(50)).background(color))
    }
}

@Composable private fun SevenDayBreakdown(sessions: List<Workout>, races: List<RaceEvent> = emptyList()) {
    val labels = listOf("SEG", "TER", "QUA", "QUI", "SEX", "SÁB", "DOM")
    val values = MutableList(7) { 0.0 }
    val raceDays = mutableSetOf<Int>()
    sessions.forEach { workout ->
        val dayIndex = runCatching { LocalDate.parse(workout.scheduledDateIso).dayOfWeek.value - 1 }.getOrNull()
        if (dayIndex != null && dayIndex in 0..6) values[dayIndex] = values[dayIndex] + workout.distanceKm
    }
    races.filter { it.status != "CANCELLED" }.forEach { race ->
        val dayIndex = race.dateOrNull()?.dayOfWeek?.value?.minus(1)
        if (dayIndex != null && dayIndex in 0..6) {
            values[dayIndex] = values[dayIndex] + race.distanceKm
            raceDays += dayIndex
        }
    }
    val maxValue = (values.maxOrNull() ?: 0.0).coerceAtLeast(1.0)
    Row(Modifier.fillMaxWidth().height(126.dp), horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.Bottom) {
        values.forEachIndexed { index, value ->
            Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                if (value > 0.0) Text(formatKmUi(value), color = Blue2, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(5.dp))
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.BottomCenter) {
                    Box(Modifier.fillMaxWidth(0.62f).height(if (value > 0.0) (value / maxValue * 76.0).coerceAtLeast(10.0).dp else 4.dp).clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp)).background(
                        if (index in raceDays) Brush.verticalGradient(listOf(Color(0xFFD1B7FF), Color(0xFF8C6FC4)))
                        else if (value > 0.0) Brush.verticalGradient(listOf(Color(0xFFB4C8FF), Color(0xFF5E81C3)))
                        else Brush.verticalGradient(listOf(Color(0xFF34445A), Color(0xFF34445A)))
                    ))
                }
                Spacer(Modifier.height(7.dp))
                Text(labels[index], color = TextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable private fun NextWorkoutCard(workout: Workout, onClick: () -> Unit) {
    CardSurface(Modifier.padding(horizontal = 16.dp).clickable(onClick = onClick), containerColor = Color(0xFF1B3048)) {
        Row(Modifier.fillMaxWidth().padding(17.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(13.dp)) {
            SessionGlyph(workout, 48)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(workout.date.uppercase(), color = Blue2, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text(workout.title, color = TextWhite, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text("~${formatKmUi(workout.distanceKm)} km  •  Tempo estimado: ~${workout.durationMin} min  •  Pace ${workout.primaryPaceRange() ?: "a calibrar"}", color = TextMuted, fontSize = 10.sp)
            }
            Text("›", color = Blue2, fontSize = 27.sp)
        }
    }
}

@Composable private fun SessionGlyph(workout: Workout, size: Int) {
    val category = calendarCategory(workout)
    val done = workout.done
    val color = if (done) Color(0xFF1D4A43) else calendarCategoryColor(category).copy(alpha = 0.25f)
    val glyph = when (category) {
        "REGENERATIVO" -> "☾"
        "AERÓBIO" -> "◉"
        "PROGRESSIVO" -> "↗"
        "QUALIDADE", "LIMIAR" -> "⌁"
        "INTERVALADO" -> "⚡"
        "LONGÃO" -> "➚"
        else -> "•"
    }
    Surface(shape = RoundedCornerShape(16.dp), color = color, modifier = Modifier.size(size.dp)) {
        Box(contentAlignment = Alignment.Center) {
            Text(if (done) "✓" else glyph, color = if (done) Green else calendarCategoryColor(category), fontSize = if (size > 40) 19.sp else 15.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable private fun PlanStat(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, color = Color(0xFFD0D9EA), fontSize = 9.sp)
        Text(value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable private fun EmptyStateCard(title: String, description: String, action: String, onClick: () -> Unit) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
        Column(Modifier.fillMaxWidth().padding(19.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("◌", color = Blue2, fontSize = 26.sp)
            Text(title, color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(description, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
            Text(action + "  ›", color = Blue2, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable(onClick = onClick).padding(top = 3.dp))
        }
    }
}

@Composable private fun NoteBlock(text: String) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), containerColor = Color(0xFF1B2D42)) {
        Row(Modifier.padding(15.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Top) {
            Text("ⓘ", color = Blue2, fontSize = 17.sp)
            Text(text, color = Color(0xFFB9C8DD), fontSize = 11.sp, lineHeight = 17.sp, modifier = Modifier.weight(1f))
        }
    }
}

@Composable private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = TextMuted, fontSize = 11.sp, modifier = Modifier.weight(0.45f))
        Text(value, color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End, modifier = Modifier.weight(0.55f))
    }
}

@Composable private fun ListButton(text: String, onClick: () -> Unit) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp).clickable(onClick = onClick)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text(text, color = TextWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text("›", color = Blue2, fontSize = 22.sp)
        }
    }
}

@Composable private fun StepExport(n: String, title: String, desc: String) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(n, color = Blue2, fontSize = 24.sp, fontWeight = FontWeight.Black)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(desc, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
            }
        }
    }
}

@Composable private fun SecondaryButton(
    text: String,
    modifier: Modifier = Modifier,
    horizontalPadding: Int = 16,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier.fillMaxWidth().padding(horizontal = horizontalPadding.dp).height(54.dp),
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = Blue2)
    ) {
        Text(text, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable private fun PrimaryButton(
    text: String,
    enabled: Boolean = true,
    modifier: Modifier = Modifier,
    horizontalPadding: Int = 16,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.fillMaxWidth().padding(horizontal = horizontalPadding.dp).height(54.dp),
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Blue, contentColor = Color(0xFF101827))
    ) {
        Text(text, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable private fun LazyColumnLike(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 16.dp), content = content)
}

private fun goalLabel(state: CoachState): String = when {
    state.goal == "Outro objetivo" -> "${state.customGoalKm} km"
    state.goal.isBlank() -> "Objetivo não definido"
    else -> state.goal
}

private fun formatKmUi(value: Double): String = String.format(Locale("pt", "BR"), "%.1f", value).replace(",0", "")
private fun recoveryLabel(status: String?): String = when (status) {
    "GOOD" -> "Boa"
    "MODERATE" -> "Moderada"
    "POOR" -> "Baixa"
    else -> "Não avaliada"
}
private fun safetyLabel(status: String?): String = when (status) {
    "RED" -> "Dor relatada"
    "YELLOW" -> "Atenção à fadiga"
    "GREEN" -> "Sem alerta"
    else -> "Não avaliada"
}
private fun raceStatusLabel(status: String): String = when (status) {
    "COMPLETED" -> "Realizada"
    "CANCELLED" -> "Cancelada"
    else -> "Programada"
}
private fun phaseLabel(phase: String): String = when (phase) {
    "BASE" -> "Base aeróbia"
    "DEVELOPMENT" -> "Desenvolvimento"
    "SPECIFIC" -> "Preparação específica"
    "ADAPTATION" -> "Adaptação"
    "CONSOLIDATION" -> "Consolidação"
    "PROGRESSION" -> "Progressão"
    "RECOVERY" -> "Regenerativa"
    "TAPER" -> "Redução pré-prova principal"
    "POST_RACE_RECOVERY" -> "Recuperação pós-prova principal"
    else -> "Base aeróbia"
}
private fun workoutTypeLabel(type: String): String = when (type) {
    "Longo" -> "Longão aeróbio"
    "Qualidade" -> "Treino de qualidade"
    "Aeróbio" -> "Rodagem aeróbia"
    "Recuperação" -> "Rodagem regenerativa"
    else -> type
}
private fun stimulusLabel(stimulus: String): String = when (stimulus) {
    "AEROBIC_BASE" -> "Desenvolvimento da base aeróbia"
    "AEROBIC_BASE_AND_CONTROLLED_QUALITY" -> "Base aeróbia com qualidade controlada"
    "LOW_INTENSITY_AEROBIC" -> "Recuperação e baixa intensidade"
    "NONE" -> "Prescrição suspensa por segurança"
    else -> "Desenvolvimento de resistência"
}

