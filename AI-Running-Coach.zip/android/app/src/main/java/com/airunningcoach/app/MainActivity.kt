package com.airunningcoach.app

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.YearMonth
import java.time.DayOfWeek
import java.time.temporal.TemporalAdjusters
import java.time.format.DateTimeFormatter
import java.time.Instant
import java.time.ZoneId
import java.util.Locale

private val Navy = Color(0xFF0A1220)
private val Navy2 = Color(0xFF111D2D)
private val CardBlue = Color(0xFF1A2B40)
private val Blue = Color(0xFF8EAEF5)
private val Blue2 = Color(0xFFC1D0FF)
private val TextWhite = Color(0xFFF4F6FC)
private val TextMuted = Color(0xFFA3B0C3)
private val Green = Color(0xFF7AD6B7)
private val Yellow = Color(0xFFF4C77B)

private enum class Screen { DASHBOARD, CALENDAR, WORKOUT, STRUCTURE, PLAN, EVOLUTION, FEEDBACK, HISTORY, PROFILE, AVAILABILITY, EXPORT, PACE_ZONES, COOPER_TEST, TRAINING_LIBRARY, RACES, BACKUP }

internal data class Workout(
    val date: String,
    val scheduledDateIso: String = "",
    val title: String,
    val detail: String,
    val type: String,
    val objective: String,
    val stimulus: String,
    val distanceKm: Double,
    val done: Boolean = false,
    val sessionId: String = "",
    val durationMin: Int = 0,
    val intensity: String = "LOW",
    val paceMode: String = "PACE_NOT_CALIBRATED",
    val rpeRange: String = "3-4",
    val rationale: String = "",
    val week: Int = 1,
    val phase: String = "BASE",
    val segments: List<WorkoutSegment> = emptyList(),
    val paceCalibrationSnapshot: PaceCalibrationSnapshot? = null,
    val manuallyRescheduled: Boolean = false,
    val originalScheduledDateIso: String = "",
    val selectedOption: String = "PRIMARY"
)

private data class FeedbackRecord(
    val sessionId: String,
    val effort: String,
    val feeling: String,
    val notes: String,
    val painPresent: Boolean = false,
    val actualDistanceKm: Double? = null,
    val savedAt: Long = System.currentTimeMillis(),
    val actualDuration: String? = null,
    val actualPaceMinKm: String? = null,
    val talkTestPaceMmSs: String? = null,
    /** Date/type of the completed workout; legacy records fall back to feedback save time/current workout. */
    val workoutDateIso: String = "",
    val workoutType: String = "",
    val workoutTitle: String = ""
)

private class CoachState(private val context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("ai_running_coach", Context.MODE_PRIVATE)
    private val navigationHistory = mutableListOf<Screen>()

    fun navigateTo(screen: Screen) {
        if (screen != selectedScreen) {
            navigationHistory.add(selectedScreen)
            selectedScreen = screen
            persist()
        }
    }

    fun canNavigateBack(): Boolean = navigationHistory.isNotEmpty() || selectedScreen != Screen.DASHBOARD

    fun resetNavigation(screen: Screen) {
        navigationHistory.clear()
        selectedScreen = screen
    }

    fun navigateBack(fallback: Screen? = fallbackScreenFor(selectedScreen)) {
        val destination = if (navigationHistory.isNotEmpty()) navigationHistory.removeAt(navigationHistory.lastIndex) else fallback
        if (destination != null && destination != selectedScreen) {
            selectedScreen = destination
            persist()
        }
    }

    private fun fallbackScreenFor(screen: Screen): Screen? = when (screen) {
        Screen.DASHBOARD -> null
        Screen.CALENDAR, Screen.PLAN, Screen.EVOLUTION, Screen.PROFILE -> Screen.DASHBOARD
        Screen.WORKOUT -> Screen.CALENDAR
        Screen.STRUCTURE, Screen.FEEDBACK, Screen.EXPORT -> Screen.WORKOUT
        Screen.AVAILABILITY, Screen.HISTORY, Screen.RACES, Screen.PACE_ZONES,
        Screen.COOPER_TEST, Screen.TRAINING_LIBRARY, Screen.BACKUP -> Screen.PROFILE
    }

    var name by mutableStateOf("Leonardo")
    var goal by mutableStateOf("")
    var customGoalKm by mutableStateOf("")
    var level by mutableStateOf("")
    var frequency by mutableStateOf(0)
    var availableTrainingDays by mutableStateOf<List<DayOfWeek>>(emptyList())
    var preferredLongRunDay by mutableStateOf<DayOfWeek?>(null)
    var scheduleActionMessage by mutableStateOf("")
    var targetDate by mutableStateOf("Sem prova principal")
    var raceEvents by mutableStateOf(listOf<RaceEvent>())
    var planStartDateIso by mutableStateOf("")
    var racePlanNote by mutableStateOf("")
    var racePlanWarnings by mutableStateOf(listOf<String>())
    var raceFormError by mutableStateOf("")
    var raceNameDraft by mutableStateOf("")
    var raceDistanceDraft by mutableStateOf("")
    var raceDateDraft by mutableStateOf(LocalDate.now().plusMonths(2).format(DateTimeFormatter.ofPattern("dd/MM/uuuu")))
    var racePriorityDraft by mutableStateOf("A")
    var raceTargetTimeDraft by mutableStateOf("")
    var raceLocationDraft by mutableStateOf("")
    var raceNotesDraft by mutableStateOf("")
    var editingRaceId by mutableStateOf("")
    var volume by mutableStateOf("") // legado V18; mantido apenas para migração local
    var weeklyVolumeText by mutableStateOf("")
    var longestRecent by mutableStateOf("")
    var cooperEnabled by mutableStateOf(false)
    var cooperDistanceText by mutableStateOf("")
    var cooperAssessmentDateText by mutableStateOf(LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/uuuu")))
    var cooperAssessments by mutableStateOf(listOf<CooperAssessmentRecord>())
    var latestCooperMessage by mutableStateOf("")
    var onboardingStep by mutableStateOf(-1)
    var selectedScreen by mutableStateOf(Screen.DASHBOARD)
    var selectedWorkoutIndex by mutableStateOf(0)
    var feedbackSaved by mutableStateOf(false)
    var workouts by mutableStateOf(listOf<Workout>())
    var planWeeks by mutableStateOf(8)
    var motorState by mutableStateOf<MotorState?>(null)
    var motorDecision by mutableStateOf<MotorDecision?>(null)
    var motorExplanation by mutableStateOf("")
    var motorError by mutableStateOf("")
    var needsEngineRefresh by mutableStateOf(false)
    var needsPacePlanRefresh by mutableStateOf(false)
    var feedbackRecords by mutableStateOf(listOf<FeedbackRecord>())
    var latestFeedbackHeadline by mutableStateOf("")
    var latestFeedbackAdvice by mutableStateOf("")
    var backupMessage by mutableStateOf("")

    init { load() }

    fun parsedCooperAssessmentDate(): LocalDate? = CooperAssessmentEngine.parseAssessmentDate(cooperAssessmentDateText)

    fun setTrainingDay(day: DayOfWeek, selected: Boolean) {
        val next = if (selected) (availableTrainingDays + day).distinct().sortedBy { it.value }
                   else availableTrainingDays.filterNot { it == day }
        if (next.size > 6 || (workouts.isNotEmpty() && next.size < 2)) {
            scheduleActionMessage = "Selecione entre 2 e 6 dias disponíveis. Para alterar um plano existente, mantenha pelo menos dois dias selecionados."
            return
        }
        availableTrainingDays = next
        frequency = next.size
        preferredLongRunDay = TrainingScheduleEngine.resolvePreferredLongRunDay(preferredLongRunDay, next)
        scheduleActionMessage = "Disponibilidade salva: ${next.size} dias por semana."
        if (workouts.isNotEmpty()) {
            needsEngineRefresh = true
            racePlanNote = "A disponibilidade semanal mudou. Recalcule o plano para redistribuir as sessões."
        }
        persist()
    }

    fun setLongRunDay(day: DayOfWeek) {
        if (day !in availableTrainingDays) return
        preferredLongRunDay = day
        scheduleActionMessage = "Dia preferido do longão atualizado."
        if (workouts.isNotEmpty()) {
            needsEngineRefresh = true
            racePlanNote = "O dia preferido do longão mudou. Recalcule o plano para aplicar a preferência."
        }
        persist()
    }

    fun availableRescheduleDates(workout: Workout): List<LocalDate> {
        val current = runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull() ?: return emptyList()
        val monday = current.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val slots = workouts.mapNotNull { item ->
            runCatching { LocalDate.parse(item.scheduledDateIso) }.getOrNull()?.let { date ->
                TrainingScheduleEngine.SessionSlot(item.sessionId, date, item.type, item.done)
            }
        }
        val raceDates = raceEvents.filter { it.status != "CANCELLED" }.mapNotNull { it.dateOrNull() }.toSet()
        return (0L..6L).map { monday.plusDays(it) }.filter { candidate ->
            TrainingScheduleEngine.validateMove(
                source = TrainingScheduleEngine.SessionSlot(workout.sessionId, current, workout.type, workout.done),
                targetDate = candidate, sessions = slots, raceDates = raceDates
            ).allowed
        }
    }

    fun rescheduleWorkout(workout: Workout, newDate: LocalDate): Boolean {
        val current = runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull()
        if (current == null) {
            scheduleActionMessage = "A data original desta sessão não é válida."
            return false
        }
        val slots = workouts.mapNotNull { item ->
            runCatching { LocalDate.parse(item.scheduledDateIso) }.getOrNull()?.let { date ->
                TrainingScheduleEngine.SessionSlot(item.sessionId, date, item.type, item.done)
            }
        }
        val raceDates = raceEvents.filter { it.status != "CANCELLED" }.mapNotNull { it.dateOrNull() }.toSet()
        val decision = TrainingScheduleEngine.validateMove(
            source = TrainingScheduleEngine.SessionSlot(workout.sessionId, current, workout.type, workout.done),
            targetDate = newDate, sessions = slots, raceDates = raceDates
        )
        if (!decision.allowed) {
            scheduleActionMessage = decision.reason
            return false
        }
        val newLabel = "${newDate.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, Locale.forLanguageTag("pt-BR")).replaceFirstChar { it.uppercase(Locale.forLanguageTag("pt-BR")) }}, ${newDate.format(DateTimeFormatter.ofPattern("dd/MM"))}"
        workouts = workouts.map { item ->
            if (item.sessionId == workout.sessionId) item.copy(
                date = newLabel,
                scheduledDateIso = newDate.toString(),
                manuallyRescheduled = true,
                originalScheduledDateIso = item.originalScheduledDateIso.ifBlank { current.toString() }
            ) else item
        }
        selectedWorkoutIndex = workouts.indexOfFirst { it.sessionId == workout.sessionId }.coerceAtLeast(0)
        scheduleActionMessage = "Sessão reagendada para ${newDate.format(DateTimeFormatter.ofPattern("dd/MM"))}. A dose e os blocos foram preservados."
        persist()
        return true
    }

    fun isCooperEntryValid(): Boolean {
        if (!cooperEnabled) return true
        val distance = cooperDistanceText.trim().replace(",", ".").toDoubleOrNull()
        val date = parsedCooperAssessmentDate() ?: return false
        return PaceCalculator.calculateCooper(distance) != null && CooperAssessmentEngine.isRecentAssessmentDate(date)
    }

    fun primaryUpcomingRace(): RaceEvent? = raceEvents
        .filter { it.status == "PLANNED" && (it.priority == "A" || it.priority == "B") }
        .mapNotNull { event -> event.dateOrNull()?.let { event to it } }
        .filter { !it.second.isBefore(LocalDate.now()) }
        .sortedWith(compareBy<Pair<RaceEvent, LocalDate>> { if (it.first.priority == "A") 0 else 1 }.thenBy { it.second })
        .firstOrNull()?.first

    fun eventsForPlanWeek(week: Int): List<RaceEvent> {
        val start = runCatching { LocalDate.parse(planStartDateIso) }.getOrNull()
            ?: workouts.minOfOrNull { runCatching { LocalDate.parse(it.scheduledDateIso) }.getOrNull() ?: LocalDate.now() }
                ?.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            ?: return emptyList()
        // UI and planning engine share the same numbering: the current partial
        // calendar week is week 1, the following Monday begins week 2.
        val racePlanningWeek = week.coerceAtLeast(1)
        return RaceEventEngine.eventsForWeek(raceEvents, start, racePlanningWeek)
    }

    fun beginRaceEdit(event: RaceEvent) {
        editingRaceId = event.id
        raceNameDraft = event.name
        raceDistanceDraft = String.format(Locale.US, "%.1f", event.distanceKm).replace(".", ",")
        raceDateDraft = RaceEventEngine.formatBrazilianDate(event.eventDateIso)
        racePriorityDraft = event.priority
        raceTargetTimeDraft = event.targetTime
        raceLocationDraft = event.location
        raceNotesDraft = event.notes
        raceFormError = ""
    }

    fun resetRaceDraft() {
        editingRaceId = ""
        raceNameDraft = ""
        raceDistanceDraft = ""
        raceDateDraft = LocalDate.now().plusMonths(2).format(DateTimeFormatter.ofPattern("dd/MM/uuuu"))
        racePriorityDraft = "A"
        raceTargetTimeDraft = ""
        raceLocationDraft = ""
        raceNotesDraft = ""
        raceFormError = ""
    }

    fun saveRaceDraft(): Boolean {
        val distance = raceDistanceDraft.trim().replace(",", ".").toDoubleOrNull()
        raceFormError = RaceEventEngine.validate(raceNameDraft, distance, raceDateDraft, racePriorityDraft, raceTargetTimeDraft).orEmpty()
        if (raceFormError.isNotBlank() || distance == null) return false
        val status = RaceEventEngine.parseBrazilianDate(raceDateDraft)?.let { if (it.isBefore(LocalDate.now())) "COMPLETED" else "PLANNED" } ?: "PLANNED"
        val race = RaceEventEngine.create(
            id = editingRaceId.ifBlank { java.util.UUID.randomUUID().toString() },
            name = raceNameDraft, distanceKm = distance, dateText = raceDateDraft, priority = racePriorityDraft,
            targetTime = raceTargetTimeDraft, location = raceLocationDraft, notes = raceNotesDraft, status = status
        ) ?: run { raceFormError = "Não foi possível salvar a competição. Confira os dados."; return false }
        raceEvents = if (editingRaceId.isBlank()) raceEvents + race else raceEvents.map { if (it.id == editingRaceId) race else it }
        syncTargetDate()
        if (workouts.isNotEmpty()) {
            needsEngineRefresh = true
            racePlanNote = "A lista de competições mudou. Recalcule o plano para ajustar sessões, taper e recuperação."
        }
        resetRaceDraft()
        persist()
        return true
    }

    fun deleteRace(id: String) {
        raceEvents = raceEvents.filterNot { it.id == id }
        syncTargetDate()
        if (workouts.isNotEmpty()) needsEngineRefresh = true
        persist()
    }

    fun markRaceCompleted(id: String) {
        raceEvents = raceEvents.map { if (it.id == id) it.copy(status = "COMPLETED") else it }
        syncTargetDate()
        persist()
    }

    private fun syncTargetDate() {
        val primary = primaryUpcomingRace()
        targetDate = primary?.let { RaceEventEngine.formatBrazilianDate(it.eventDateIso) } ?: "Sem prova principal"
    }

    fun createPlan(): Boolean {
        motorError = ""
        if (goal.isBlank() || level.isBlank() || availableTrainingDays.size !in 2..6 || frequency != availableTrainingDays.size || weeklyVolumeText.isBlank() || longestRecent.isBlank()) {
            motorError = "Complete todas as escolhas antes de criar o plano."
            persist()
            return false
        }

        val goalKm = when {
            goal.startsWith("5") -> 5.0
            goal.startsWith("10") -> 10.0
            goal.startsWith("Meia") -> 21.1
            goal.startsWith("Maratona") -> 42.2
            goal.startsWith("Saúde") -> 5.0
            goal == "Outro objetivo" -> customGoalKm.trim().replace(",", ".").toDoubleOrNull()
                ?.takeIf { it in 1.0..100.0 }
            else -> null
        }
        if (goalKm == null) {
            motorError = "Informe uma distância válida entre 1 e 100 km para o objetivo personalizado."
            persist()
            return false
        }
        val recentKm = longestRecent.trim().replace(",", ".").toDoubleOrNull()
        // A V19 exige a média real das últimas quatro semanas; não converte mais faixas em números arbitrários.
        val weeklyKm = weeklyVolumeText.trim().replace(",", ".").toDoubleOrNull()
        if (weeklyKm == null || weeklyKm !in 0.0..150.0) {
            motorError = "Informe a média semanal real entre 0 e 150 km, considerando as últimas quatro semanas."
            persist()
            return false
        }
        if (recentKm == null || recentKm !in 0.0..60.0) {
            motorError = "Informe o maior treino recente entre 0 e 60 km."
            persist()
            return false
        }
        val cooperDistance = if (cooperEnabled) cooperDistanceText.trim().replace(",", ".").toDoubleOrNull()
            else cooperAssessments.lastOrNull()?.distanceKm
        val cooperDate = if (cooperEnabled) parsedCooperAssessmentDate() else cooperAssessments.lastOrNull()?.dateIso?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
        val previousCooperDistance = CooperAssessmentEngine.previousAssessmentDistance(
            cooperAssessments, cooperDate?.toString()
        )
        if (cooperEnabled && PaceCalculator.calculateCooper(cooperDistance) == null) {
            motorError = "Informe a distância percorrida no Teste de Cooper de 12 minutos, entre 1,00 e 5,00 km."
            persist()
            return false
        }
        if (cooperEnabled && cooperDate == null) {
            motorError = "Informe a data correta em que o Teste de Cooper foi realizado."
            persist()
            return false
        }
        if (cooperEnabled && cooperDate != null && !CooperAssessmentEngine.isRecentAssessmentDate(cooperDate)) {
            motorError = "O resultado informado precisa ter sido realizado nos últimos 56 dias. Faça um novo Cooper para calibrar o plano."
            persist()
            return false
        }

        return try {
            val today = LocalDate.now()
            val loadSnapshot = TrainingLoadEngine.summarize(
                activities = feedbackRecords.mapNotNull { record ->
                    val distance = record.actualDistanceKm ?: return@mapNotNull null
                    val activityDate = record.workoutDateIso.takeIf { it.isNotBlank() }
                        ?.let { raw -> runCatching { LocalDate.parse(raw) }.getOrNull() }
                        ?: runCatching {
                            Instant.ofEpochMilli(record.savedAt).atZone(ZoneId.systemDefault()).toLocalDate()
                        }.getOrNull()
                        ?: return@mapNotNull null
                    LoggedRunActivity(activityDate, distance)
                },
                today = today
            )
            // Promote measured four-week load only when enough real activities span
            // at least three weeks. With partial logging, keep the profile baseline and
            // use a longer recorded run as an additional tolerance bound.
            val effectiveWeeklyKm = if (loadSnapshot.reliable) {
                loadSnapshot.averageWeeklyKmLast28Days ?: weeklyKm
            } else weeklyKm
            val effectiveLongestKm = if (loadSnapshot.reliable) {
                loadSnapshot.longestRunLast30DaysKm ?: 0.0
            } else maxOf(recentKm, loadSnapshot.longestRunLast30DaysKm ?: 0.0)
            val novicePlan = level == "Iniciante" || effectiveWeeklyKm < 8.0 || effectiveLongestKm < 5.0
            val prescribedDays = TrainingScheduleEngine.prescribedRunningDays(
                availableTrainingDays, frequency, novicePlan, preferredLongRunDay
            )
            val planWindow = RaceEventEngine.resolvePlanWindow(today, raceEvents, defaultWeeks = 8)
            // Only a race selected inside the active planning window may change this block's
            // specific goal distance. A distant A-race remains visible but must not hijack a
            // 16-week base block or override a nearer tune-up event.
            val goalRace = planWindow.primaryRaceId
                ?.takeIf { planWindow.raceInsideWindow }
                ?.let { selectedId -> raceEvents.firstOrNull { it.id == selectedId && it.status == "PLANNED" } }
            val planningGoalKm = goalRace?.distanceKm ?: goalKm
            planStartDateIso = planWindow.startDate.toString()
            val input = RunnerInput(
                goalKm = planningGoalKm,
                level = level,
                frequency = frequency,
                availableDays = availableTrainingDays,
                preferredLongRunDay = preferredLongRunDay,
                weeklyVolumeKm = effectiveWeeklyKm,
                longestRecentKm = effectiveLongestKm,
                painPresent = recentFeedback().takeLast(3).any { it.painPresent },
                recoveryScore = deriveRecoveryScore(),
                fatigueScore = deriveFatigueScore(),
                planWeeks = planWindow.weeks,
                cooperDistanceKm = cooperDistance,
                cooperAssessmentDateIso = cooperDate?.toString(),
                previousCooperDistanceKm = previousCooperDistance,
                talkTestComfortPaceValues = recentTalkTestPaces(),
                recentActivityCount = loadSnapshot.recordedRunsLast28Days,
                recentActivityHistoryReliable = loadSnapshot.reliable,
                startDate = planWindow.startDate
            )
            val plan = RunningCoachEngine.generate(input)
            val currentZones = PaceCalculator.limitCalibrationChange(
                PaceCalculator.calculateCooper(cooperDistance, recentTalkTestPaces()),
                PaceCalculator.calculateCooper(previousCooperDistance, recentTalkTestPaces()),
                maxBoundaryShiftSeconds = 15
            )
            // A plan created midweek must include the current week. Keep only sessions
            // from today onward; do not move missed Monday/Tuesday sessions into later days.
            val remainingCycleSessions = plan.workouts.filter { prescribed ->
                val date = runCatching { LocalDate.parse(prescribed.scheduledDateIso) }.getOrNull()
                date != null && !date.isBefore(today)
            }
            val raceAdjustment = RaceEventEngine.applyToPlan(
                workouts = remainingCycleSessions,
                events = raceEvents,
                planStartDate = planWindow.startDate,
                frequency = prescribedDays.size,
                zones = currentZones,
                today = today
            )

            // The current calendar week is generated from its Monday anchor, with past
            // sessions removed above. It remains week 1 even when the plan starts midweek.
            val currentWeekStart = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            val bandAdjustedWorkouts = raceAdjustment.workouts.map { ZoneIntensityBandEngine.apply(it) }
            val upcomingPlanSessions = TrainingScheduleEngine.keepUpcomingSessionsForCurrentWeek(
                bandAdjustedWorkouts, today, planWindow.startDate
            )
            val racePlanWarningsCombined = raceAdjustment.warnings
            val previousManualDates = workouts.filter { it.manuallyRescheduled && !it.done }.associateBy { it.sessionId }
            racePlanWarnings = racePlanWarningsCombined
            racePlanNote = buildString {
                append(planWindow.note)
                goalRace?.let { append(" Objetivo específico do ciclo: ${it.name}, ${formatKmUi(it.distanceKm)} km.") }
                if (raceAdjustment.replacedSessionIds.isNotEmpty()) {
                    append(" ${raceAdjustment.replacedSessionIds.size} sessão(ões) substituída(s) por competição; taper e recuperação foram ajustados.")
                }
                if (raceAdjustment.taperedSessionIds.isNotEmpty()) {
                    append(" As sessões próximas da prova tiveram carga reduzida.")
                }
                append(" A semana atual começa em ${currentWeekStart.format(DateTimeFormatter.ofPattern("dd/MM"))}; sessões anteriores a hoje não são recriadas e os próximos treinos permanecem na semana correta.")
            }
            motorState = plan.state
            motorDecision = plan.decision
            motorExplanation = plan.explanation
            if (novicePlan && prescribedDays.size < availableTrainingDays.size) {
                racePlanNote = (racePlanNote + " Para iniciante/reintrodução, o treinador prescreveu no máximo três dias de corrida; os demais dias continuam disponíveis, mas não viram sessões obrigatórias.").trim()
            }
            if (plan.decision.safety == "RED") {
                // Preserve the previous cycle so the athlete can review/update the pain feedback
                // after recovery; a blocked generation must not erase the only way to do that.
                motorError = "Nova prescrição bloqueada por relato de dor. O plano anterior foi preservado; atualize o feedback somente quando estiver sem dor."
                onboardingStep = 8
                resetNavigation(Screen.DASHBOARD)
                persist()
                return false
            }
            if (plan.workouts.isEmpty()) {
                motorError = "O motor terminou sem gerar sessões."
                persist()
                return false
            }
            val recordedSessionIds = feedbackRecords.map { it.sessionId }.toSet()
            // A completed workout is a permanent history record. Replanning must never
            // discard it merely because it belongs to an earlier calendar week/cycle.
            val completedBeforeRecalibration = workouts
                .filter { it.done || it.sessionId in recordedSessionIds }
                .map { workout -> if (workout.sessionId in recordedSessionIds) workout.copy(done = true) else workout }
            val generatedWorkouts = upcomingPlanSessions.map { p ->
                val previousManual = previousManualDates[p.sessionId]
                val generatedDate = runCatching { LocalDate.parse(p.scheduledDateIso) }.getOrNull()
                val manualDate = previousManual?.let { runCatching { LocalDate.parse(it.scheduledDateIso) }.getOrNull() }
                val keepManual = generatedDate != null && manualDate != null && !manualDate.isBefore(today) &&
                    generatedDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)) == manualDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
                val finalDate = if (keepManual) manualDate!! else generatedDate
                val finalDateLabel = finalDate?.let { d -> "${d.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, Locale.forLanguageTag("pt-BR")).replaceFirstChar { it.uppercase(Locale.forLanguageTag("pt-BR")) }}, ${d.format(DateTimeFormatter.ofPattern("dd/MM"))}" } ?: p.date
                Workout(
                    date = finalDateLabel, scheduledDateIso = finalDate?.toString() ?: p.scheduledDateIso, title = p.title, detail = p.detail, type = p.type,
                    objective = p.objective, stimulus = p.stimulus, distanceKm = p.distanceKm,
                    sessionId = p.sessionId, durationMin = p.durationMin, intensity = p.intensity,
                    paceMode = p.paceMode, rpeRange = p.rpeRange, rationale = p.rationale,
                    week = p.week, phase = p.phase, segments = p.segments,
                    paceCalibrationSnapshot = p.paceCalibrationSnapshot,
                    manuallyRescheduled = keepManual,
                    originalScheduledDateIso = if (keepManual) (previousManual?.originalScheduledDateIso ?: p.scheduledDateIso) else ""
                )
            }
            workouts = (completedBeforeRecalibration + generatedWorkouts)
                .distinctBy { it.sessionId }
                .sortedBy { it.scheduledDateIso }
            if (loadSnapshot.reliable) {
                weeklyVolumeText = String.format(Locale.US, "%.1f", effectiveWeeklyKm)
                longestRecent = String.format(Locale.US, "%.1f", effectiveLongestKm)
            }
            if (cooperEnabled && cooperDistance != null) {
                val record = cooperDate?.let { CooperAssessmentEngine.createRecord(cooperDistance, it, recentTalkTestPaces(), currentZones) }
                if (record != null) {
                    cooperAssessments = (cooperAssessments.filterNot { it.dateIso == record.dateIso } + record)
                        .sortedBy { it.dateIso }
                }
            }
            motorError = ""
            planWeeks = plan.weeklySummaries.size.coerceAtLeast(4)
            syncTargetDate()
            needsEngineRefresh = false
            needsPacePlanRefresh = false
            prefs.edit().putInt("engineVersion", 36).putBoolean("needsEngineRefresh", false).apply()
            selectedWorkoutIndex = 0
            resetNavigation(Screen.DASHBOARD)
            onboardingStep = 8
            persist()
            true
        } catch (e: Exception) {
            motorError = "Erro ao executar o motor: ${e.message ?: "erro desconhecido"}"
            persist()
            false
        }
    }

    fun selectedWorkoutBase(): Workout? = workouts.getOrNull(selectedWorkoutIndex)

    fun selectedWorkout(): Workout? {
        val base = selectedWorkoutBase() ?: return null
        val selected = if (base.selectedOption == "ALTERNATIVE") WorkoutAlternativeEngine.createAlternative(base) else base
        return ZoneIntensityBandEngine.apply(selected)
    }

    fun selectWorkoutOption(sessionId: String, option: String) {
        if (option !in setOf("PRIMARY", "ALTERNATIVE")) return
        val index = workouts.indexOfFirst { it.sessionId == sessionId }
        if (index < 0 || workouts[index].done) return
        workouts = workouts.map { if (it.sessionId == sessionId) it.copy(selectedOption = option) else it }
        selectedWorkoutIndex = index
        persist()
    }

    fun currentPaceZones(): TrainingPaceZones? {
        val profileDistance = if (cooperEnabled) cooperDistanceText.trim().replace(",", ".").toDoubleOrNull() else null
        val cooperDistance = profileDistance ?: cooperAssessments.lastOrNull()?.distanceKm
        val currentDateIso = if (cooperEnabled) parsedCooperAssessmentDate()?.toString() else cooperAssessments.lastOrNull()?.dateIso
        val previousDistance = CooperAssessmentEngine.previousAssessmentDistance(cooperAssessments, currentDateIso)
        val paces = recentTalkTestPaces()
        return PaceCalculator.limitCalibrationChange(
            PaceCalculator.calculateCooper(cooperDistance, paces),
            PaceCalculator.calculateCooper(previousDistance, paces),
            maxBoundaryShiftSeconds = 15
        )
    }

    /** Preview uses the same smoothed result that will be saved and applied to the plan. */
    fun calculateZonesForCooper(distanceKm: Double?): TrainingPaceZones? {
        val talkPaces = recentTalkTestPaces()
        val assessmentDate = LocalDate.now().toString()
        val previousDistance = CooperAssessmentEngine.previousAssessmentDistance(cooperAssessments, assessmentDate)
        return PaceCalculator.limitCalibrationChange(
            PaceCalculator.calculateCooper(distanceKm, talkPaces),
            PaceCalculator.calculateCooper(previousDistance, talkPaces),
            maxBoundaryShiftSeconds = 15
        )
    }

    /** Rebuilds future sessions from the saved athlete profile and current calibrated zones. */
    fun recalibratePlan(): Boolean {
        if (currentPaceZones() == null) {
            motorError = "Registre um Teste de Cooper válido antes de calibrar o plano."
            latestCooperMessage = motorError
            persist()
            navigateTo(Screen.COOPER_TEST)
            return false
        }
        val updated = createPlan()
        if (updated) {
            latestCooperMessage = "Plano recalibrado. As sessões concluídas e os feedbacks anteriores foram preservados."
            latestFeedbackHeadline = "Calibração aplicada"
            latestFeedbackAdvice = "As próximas sessões foram recalculadas com as zonas atuais e os limites de progressão conservadora."
            needsPacePlanRefresh = false
            needsEngineRefresh = false
            persist(synchronous = true)
        }
        return updated
    }

    fun feedbackForSession(sessionId: String): FeedbackRecord? = feedbackRecords.lastOrNull { it.sessionId == sessionId }

    fun orphanFeedbackRecords(): List<FeedbackRecord> {
        val workoutIds = workouts.map { it.sessionId }.toSet()
        return feedbackRecords.filter { it.sessionId !in workoutIds }
    }

    /** Last three talk-test paces from recent, completed easy/long sessions. */
    private fun recentTalkTestPaces(): List<Int> {
        val today = LocalDate.now()
        val cutoff = today.minusDays(42)
        return feedbackRecords.asSequence()
            .filter { record ->
                val date = feedbackActivityDate(record)
                !date.isBefore(cutoff) && !date.isAfter(today) && !record.painPresent
            }
            .sortedBy(::feedbackActivityDate)
            .filter { it.effort in setOf("Muito leve", "Leve", "Ok") && it.feeling in setOf("Ótimo", "Bem") }
            .mapNotNull { record ->
                val workoutType = record.workoutType.ifBlank {
                    workouts.firstOrNull { it.sessionId == record.sessionId }?.type.orEmpty()
                }
                if (!TalkTestCalibrationRules.isEligibleWorkout(workoutType) ||
                    !TalkTestCalibrationRules.canCalibrate(record.effort, record.feeling, record.painPresent)
                ) return@mapNotNull null
                PaceRange.parsePace(record.talkTestPaceMmSs.orEmpty())
            }
            .toList()
            .takeLast(3)
    }

    fun cooperReviewStatus() = CooperAssessmentEngine.reviewStatus(cooperAssessments)

    fun saveCooperAndReplan(distanceText: String): Boolean {
        if (recentFeedback().takeLast(3).any { it.painPresent }) {
            latestCooperMessage = "O teste não foi salvo: existe relato recente de dor. Não faça um teste máximo enquanto houver dor; retome a avaliação somente após recuperação adequada."
            persist()
            return false
        }
        if (deriveRecoveryScore()?.let { it < 50.0 } == true) {
            latestCooperMessage = "O teste não foi salvo: os feedbacks recentes indicam recuperação insuficiente. Descanse e reavalie quando estiver recuperado."
            persist()
            return false
        }
        val distanceKm = distanceText.trim().replace(",", ".").toDoubleOrNull()
        val assessmentDateIso = LocalDate.now().toString()
        val previousDistance = CooperAssessmentEngine.previousAssessmentDistance(cooperAssessments, assessmentDateIso)
        val talkPaces = recentTalkTestPaces()
        val smoothedZones = PaceCalculator.limitCalibrationChange(
            PaceCalculator.calculateCooper(distanceKm, talkPaces),
            PaceCalculator.calculateCooper(previousDistance, talkPaces),
            maxBoundaryShiftSeconds = 15
        )
        val record = distanceKm?.let { CooperAssessmentEngine.createRecord(it, talkTestComfortPaces = talkPaces, zonesOverride = smoothedZones) }
        if (record == null) {
            latestCooperMessage = "Distância inválida. Informe o total percorrido em quilômetros no teste de 12 minutos."
            persist()
            return false
        }
        cooperEnabled = true
        cooperDistanceText = String.format(Locale.US, "%.2f", record.distanceKm).replace(".", ",")
        cooperAssessmentDateText = record.dateIso.let { LocalDate.parse(it).format(DateTimeFormatter.ofPattern("dd/MM/uuuu")) }
        val history = cooperAssessments.filterNot { it.dateIso == record.dateIso } + record
        cooperAssessments = history.sortedBy { it.dateIso }
        latestCooperMessage = "Cooper salvo. As zonas foram recalculadas com a nova avaliação."
        persist()
        val profileReady = goal.isNotBlank() && level.isNotBlank() && availableTrainingDays.size in 2..6 && frequency == availableTrainingDays.size &&
            weeklyVolumeText.isNotBlank() && longestRecent.isNotBlank()
        if (!profileReady) {
            latestCooperMessage = "Cooper salvo e zonas atualizadas. Complete os dados do atleta para gerar ou recalcular o plano."
            persist()
            return true
        }
        val success = createPlan()
        if (!success) {
            latestCooperMessage = "Teste salvo e zonas atualizadas. O plano anterior foi preservado: ${motorError.ifBlank { "revise o perfil e a recuperação" }}"
            persist()
        }
        return success
    }

    fun completedWorkouts(): List<Workout> {
        val savedFeedbackIds = feedbackRecords.map { it.sessionId }.toSet()
        return workouts.filter { it.done || it.sessionId in savedFeedbackIds }.map { workout ->
            if (workout.sessionId in savedFeedbackIds && !workout.done) workout.copy(done = true) else workout
        }
    }

    /** Active cycle plus the current partial week; older completed cycles stay in history/calendar only. */
    fun activePlanWorkouts(): List<Workout> {
        val planStart = runCatching { LocalDate.parse(planStartDateIso) }.getOrNull() ?: return workouts
        val visibleFrom = if (planStart.isAfter(LocalDate.now())) planStart.minusWeeks(1) else planStart
        return workouts.filter { workout ->
            val date = runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull() ?: return@filter false
            !date.isBefore(visibleFrom)
        }
    }

    fun saveFeedback(effort: String, feeling: String, notes: String, painPresent: Boolean, actualDistanceText: String, actualDurationText: String, talkTestPaceText: String): Boolean {
        val current = selectedWorkout() ?: run {
            motorError = "Não foi possível localizar a sessão. Abra o treino novamente pelo calendário."
            persist()
            return false
        }
        if (workouts.none { it.sessionId == current.sessionId }) {
            motorError = "A sessão não pertence mais ao plano salvo. Atualize o calendário e tente novamente."
            persist()
            return false
        }
        val actualDistanceKm = actualDistanceText.trim().replace(",", ".").toDoubleOrNull()?.takeIf { it > 0.0 && it <= 200.0 }
        val durationValue = PaceCalculator.parseDuration(actualDurationText)
        val actualPace = if (actualDistanceKm != null && durationValue != null) PaceCalculator.paceFromDistanceAndDuration(actualDistanceKm, durationValue)?.let { PaceRange.format(it) } else null

        val previousWorkouts = workouts
        val previousFeedbackRecords = feedbackRecords
        val previousNeedsEngineRefresh = needsEngineRefresh
        val previousNeedsPacePlanRefresh = needsPacePlanRefresh
        val previousFeedbackHeadline = latestFeedbackHeadline
        val previousFeedbackAdvice = latestFeedbackAdvice
        workouts = workouts.map { workout ->
            if (workout.sessionId == current.sessionId) workout.copy(done = true) else workout
        }
        val record = FeedbackRecord(
            sessionId = current.sessionId, effort = effort, feeling = feeling, notes = notes, painPresent = painPresent,
            actualDistanceKm = actualDistanceKm, actualDuration = actualDurationText.takeIf { durationValue != null }, actualPaceMinKm = actualPace,
            talkTestPaceMmSs = TalkTestCalibrationRules.normalizeEntry(current.type, talkTestPaceText),
            workoutDateIso = current.scheduledDateIso,
            workoutType = current.type,
            workoutTitle = current.title
        )
        feedbackRecords = feedbackRecords.filterNot { it.sessionId == current.sessionId } + record
        if (currentPaceZones()?.z2CalibrationStatus == "TALK_TEST_CONFIRMED") {
            needsPacePlanRefresh = true
            latestFeedbackHeadline = "Z2 personalizada disponível"
            latestFeedbackAdvice = "Dois ou mais registros consistentes de fala confortável foram encontrados. Recalcule o plano para aplicar a faixa ativa atualizada nas próximas sessões."
        } else {
            val analysis = TrainingAdaptationEngine.analyzeRun(
                TrainingAdaptationEngine.RunResult(
                    distanceKm = actualDistanceKm,
                    plannedDistanceKm = current.distanceKm,
                    perceivedEffort = effort,
                    feeling = feeling,
                    plannedWorkoutType = current.type,
                    painReported = painPresent
                )
            )
            latestFeedbackHeadline = "Feedback registrado"
            latestFeedbackAdvice = analysis.nextStep
        }
        // Any feedback changes the recovery picture, even when the athlete did not
        // enter measured distance/time. Only real metrics are used in pace and volume charts.
        needsEngineRefresh = true
        if (actualDistanceKm != null) {
            latestFeedbackAdvice = (latestFeedbackAdvice + " A distância realizada foi salva no histórico; recalcule o plano para usar essa carga nas próximas semanas.").trim()
        } else {
            latestFeedbackAdvice = (latestFeedbackAdvice + " O feedback subjetivo foi salvo. Informe distância e tempo quando disponíveis para incluir métricas reais nos gráficos e na carga.").trim()
        }
        feedbackSaved = true
        motorError = ""
        // Commit synchronously: feedback is an athlete record and must survive
        // immediate process termination/app switching after the save action.
        try {
            persist(synchronous = true)
        } catch (error: Exception) {
            workouts = previousWorkouts
            feedbackRecords = previousFeedbackRecords
            feedbackSaved = feedbackRecords.isNotEmpty()
            needsEngineRefresh = previousNeedsEngineRefresh
            needsPacePlanRefresh = previousNeedsPacePlanRefresh
            latestFeedbackHeadline = previousFeedbackHeadline
            latestFeedbackAdvice = previousFeedbackAdvice
            motorError = "Não foi possível gravar o feedback no armazenamento do aparelho. Tente novamente."
            return false
        }
        return true
    }

    private fun feedbackActivityDate(record: FeedbackRecord): LocalDate =
        record.workoutDateIso.takeIf { it.isNotBlank() }
            ?.let { raw -> runCatching { LocalDate.parse(raw) }.getOrNull() }
            ?: runCatching { Instant.ofEpochMilli(record.savedAt).atZone(ZoneId.systemDefault()).toLocalDate() }
                .getOrDefault(LocalDate.now())

    private fun recentFeedback(windowDays: Long = 14): List<FeedbackRecord> {
        val today = LocalDate.now()
        val cutoff = today.minusDays(windowDays)
        return feedbackRecords.filter { record ->
            val date = feedbackActivityDate(record)
            !date.isBefore(cutoff) && !date.isAfter(today)
        }.sortedBy(::feedbackActivityDate)
    }

    private fun deriveRecoveryScore(): Double? {
        val recent = recentFeedback().takeLast(3)
        if (recent.isEmpty()) return null
        val tired = recent.count { it.feeling == "Cansado" || it.feeling == "Muito cansado" }
        val heavy = recent.count { it.effort == "Pesado" || it.effort == "Muito pesado" }
        return when {
            recent.any { it.painPresent } -> 10.0
            tired >= 2 || heavy >= 2 -> 35.0
            tired + heavy >= 1 -> 60.0
            else -> 80.0
        }
    }

    private fun deriveFatigueScore(): Double? {
        val recent = recentFeedback().takeLast(3)
        if (recent.isEmpty()) return null
        val tired = recent.count { it.feeling == "Cansado" || it.feeling == "Muito cansado" }
        val heavy = recent.count { it.effort == "Pesado" || it.effort == "Muito pesado" }
        return when {
            recent.any { it.painPresent } -> 95.0
            tired >= 2 || heavy >= 2 -> 80.0
            tired + heavy >= 1 -> 65.0
            else -> 30.0
        }
    }

    fun selectWorkout(workout: Workout) {
        // Calendar entries may be derived alternatives; resolve by stable session ID, not full data-class equality.
        val index = workouts.indexOfFirst { it.sessionId == workout.sessionId }
        if (index >= 0) selectedWorkoutIndex = index
        navigateTo(Screen.WORKOUT)
    }

    fun persist(synchronous: Boolean = false) {
        val e = prefs.edit()
            .remove("benchmarkEnabled")
            .remove("benchmarkDistanceText")
            .remove("benchmarkTimeText")
            .putString("name", name)
            .putString("goal", goal)
            .putString("customGoalKm", customGoalKm)
            .putString("level", level)
            .putInt("frequency", frequency)
            .putString("availableTrainingDays", availableTrainingDays.joinToString(",") { it.name })
            .putString("preferredLongRunDay", preferredLongRunDay?.name ?: "")
            .putString("targetDate", targetDate)
            .putString("planStartDateIso", planStartDateIso)
            .putString("racePlanNote", racePlanNote)
            .putString("racePlanWarnings", JSONArray(racePlanWarnings).toString())
            .putString("raceEvents", JSONArray().apply {
                raceEvents.forEach { event -> put(JSONObject().apply {
                    put("id", event.id); put("name", event.name); put("distanceKm", event.distanceKm)
                    put("eventDateIso", event.eventDateIso); put("priority", event.priority)
                    put("targetTime", event.targetTime); put("location", event.location)
                    put("notes", event.notes); put("status", event.status)
                }) }
            }.toString())
            .putString("volume", volume)
            .putString("weeklyVolumeText", weeklyVolumeText)
            .putString("longestRecent", longestRecent)
            .putBoolean("cooperEnabled", cooperEnabled)
            .putString("cooperDistanceText", cooperDistanceText)
            .putString("cooperAssessmentDateText", cooperAssessmentDateText)
            .putString("latestCooperMessage", latestCooperMessage)
            .putInt("onboardingStep", onboardingStep)
            .putInt("selectedScreen", selectedScreen.ordinal)
            .putInt("selectedWorkoutIndex", selectedWorkoutIndex)
            .putInt("planWeeks", planWeeks)
            .putString("latestFeedbackHeadline", latestFeedbackHeadline)
            .putString("latestFeedbackAdvice", latestFeedbackAdvice)
            .putString("motorExplanation", motorExplanation)
            .putString("motorError", motorError)
            .putBoolean("needsPacePlanRefresh", needsPacePlanRefresh)
            .putBoolean("needsEngineRefresh", needsEngineRefresh)

        motorState?.let { ms ->
            e.putString("motorState", JSONObject().apply {
                put("fitnessConfidence", ms.fitnessConfidence)
                put("paceConfidence", ms.paceConfidence)
                put("recentVolumeKm", ms.recentVolumeKm)
                put("recentLongRunKm", ms.recentLongRunKm)
                put("recoveryStatus", ms.recoveryStatus)
                put("safetyStatus", ms.safetyStatus)
                put("phase", ms.phase)
                put("flags", JSONArray(ms.flags))
            }.toString())
        }
        motorDecision?.let { md ->
            e.putString("motorDecision", JSONObject().apply {
                put("action", md.action)
                put("necessity", md.necessity)
                put("stimulus", md.stimulus)
                put("rationale", md.rationale)
                put("confidence", md.confidence)
                put("safety", md.safety)
            }.toString())
        }
        val arr = JSONArray()
        workouts.forEach { w ->
            arr.put(JSONObject().apply {
                put("date", w.date); put("scheduledDateIso", w.scheduledDateIso); put("title", w.title); put("detail", w.detail)
                put("type", w.type); put("objective", w.objective); put("stimulus", w.stimulus)
                put("distanceKm", w.distanceKm); put("done", w.done); put("sessionId", w.sessionId)
                put("durationMin", w.durationMin); put("intensity", w.intensity); put("paceMode", w.paceMode)
                put("rpeRange", w.rpeRange); put("rationale", w.rationale); put("week", w.week)
                put("phase", w.phase)
                put("manuallyRescheduled", w.manuallyRescheduled)
                put("originalScheduledDateIso", w.originalScheduledDateIso)
                put("selectedOption", w.selectedOption)
                w.paceCalibrationSnapshot?.let { snapshot ->
                    put("paceCalibration", JSONObject().apply {
                        put("assessmentDateIso", snapshot.assessmentDateIso)
                        put("distanceKm", snapshot.distanceKm)
                        put("averagePaceMmSs", snapshot.averagePaceMmSs)
                        put("estimatedVo2Max", snapshot.estimatedVo2Max)
                        put("estimatedMasPaceMmSs", snapshot.estimatedMasPaceMmSs)
                        put("estimatedSvt2PaceMmSs", snapshot.estimatedSvt2PaceMmSs)
                        put("modelVersion", snapshot.modelVersion)
                        put("z2CalibrationStatus", snapshot.z2CalibrationStatus)
                        put("talkTestEvidenceCount", snapshot.talkTestEvidenceCount)
                        put("talkTestReferencePaceMmSs", snapshot.talkTestReferencePaceMmSs)
                        put("zoneRanges", JSONObject().apply { snapshot.zoneRanges.forEach { (id, range) -> put(id, range) } })
                    })
                }
                put("segments", JSONArray().apply {
                    w.segments.forEach { segment -> put(JSONObject().apply {
                        put("name", segment.name); put("instruction", segment.instruction)
                        if (segment.durationMin != null) put("durationMin", segment.durationMin)
                        if (segment.distanceKm != null) put("distanceKm", segment.distanceKm)
                        put("intensity", segment.intensity); put("rpeRange", segment.rpeRange)
                        put("repeatCount", segment.repeatCount); put("targetMode", segment.targetMode)
                        segment.targetPaceMinValue?.let { put("paceFasterMinKm", PaceRange.format(it)) }
                        segment.targetPaceMaxValue?.let { put("paceSlowerMinKm", PaceRange.format(it)) }
                        segment.paceZone?.let { put("paceZone", it) }
                        segment.zoneBasePaceFastValue?.let { put("zoneBasePaceFastMinKm", PaceRange.format(it)) }
                        segment.zoneBasePaceSlowValue?.let { put("zoneBasePaceSlowMinKm", PaceRange.format(it)) }
                        segment.zoneIntensityMinPercent?.let { put("zoneIntensityMinPercent", it) }
                        segment.zoneIntensityMaxPercent?.let { put("zoneIntensityMaxPercent", it) }
                    }) }
                })
            })
        }
        val feedbackArray = JSONArray()
        feedbackRecords.forEach { feedback -> feedbackArray.put(JSONObject().apply {
            put("sessionId", feedback.sessionId); put("effort", feedback.effort)
            put("feeling", feedback.feeling); put("notes", feedback.notes); put("painPresent", feedback.painPresent)
            feedback.actualDistanceKm?.let { put("actualDistanceKm", it) }
            feedback.actualDuration?.let { put("actualDuration", it) }
            feedback.actualPaceMinKm?.let { put("actualPaceMinKm", it) }
            feedback.talkTestPaceMmSs?.let { put("talkTestPaceMmSs", it) }
            put("workoutDateIso", feedback.workoutDateIso)
            put("workoutType", feedback.workoutType)
            put("workoutTitle", feedback.workoutTitle)
            put("savedAt", feedback.savedAt)
        }) }
        e.putString("feedbackRecords", feedbackArray.toString())
        e.putString("workouts", arr.toString())
        e.putString("cooperAssessments", JSONArray().apply {
            cooperAssessments.forEach { record -> put(JSONObject().apply {
                put("dateIso", record.dateIso); put("distanceKm", record.distanceKm)
                put("estimatedVo2Max", record.estimatedVo2Max)
                put("averagePace", record.averagePace)
                put("estimatedMasPace", record.estimatedMasPace)
                put("estimatedSvt2Pace", record.estimatedSvt2Pace)
                put("zoneModelVersion", record.zoneModelVersion)
                put("z2CalibrationStatus", record.z2CalibrationStatus)
                put("talkTestEvidenceCount", record.talkTestEvidenceCount)
                put("talkTestReferencePaceMmSs", record.talkTestReferencePaceMmSs)
                put("zoneRanges", JSONObject().apply { record.zoneRanges.forEach { (zone, range) -> put(zone, range) } })
            }) }
        }.toString())
        if (synchronous) check(e.commit()) { "Não foi possível salvar os dados da sessão no aparelho." } else e.apply()
    }

    fun exportBackup(uri: Uri): BackupOperationResult {
        val result = AppBackupManager.export(context, uri)
        backupMessage = result.message
        return result
    }

    fun restoreBackup(uri: Uri): BackupOperationResult {
        val result = AppBackupManager.restore(context, uri)
        if (result.success) {
            navigationHistory.clear()
            load()
            selectedScreen = Screen.BACKUP
            selectedWorkoutIndex = 0
            onboardingStep = 8
            persist()
        }
        backupMessage = result.message
        return result
    }

    private fun load() {
        // Reset collection/nullable state first. This is also used after restoring an
        // intentionally empty backup, so values from the previous installation cannot leak.
        raceEvents = emptyList()
        racePlanWarnings = emptyList()
        workouts = emptyList()
        feedbackRecords = emptyList()
        cooperAssessments = emptyList()
        motorState = null
        motorDecision = null
        name = prefs.getString("name", "Leonardo") ?: "Leonardo"
        goal = prefs.getString("goal", "") ?: ""
        customGoalKm = prefs.getString("customGoalKm", "") ?: ""
        level = prefs.getString("level", "") ?: ""
        frequency = prefs.getInt("frequency", 0)
        availableTrainingDays = prefs.getString("availableTrainingDays", "")?.split(",")
            ?.mapNotNull { value -> runCatching { DayOfWeek.valueOf(value) }.getOrNull() }
            ?.distinct()?.sortedBy { it.value }
            ?.takeIf { it.size in 2..6 }
            ?: if (frequency in 2..6) TrainingScheduleEngine.defaultDays(frequency) else emptyList()
        if (availableTrainingDays.isNotEmpty()) frequency = availableTrainingDays.size
        preferredLongRunDay = prefs.getString("preferredLongRunDay", "")?.takeIf { it.isNotBlank() }
            ?.let { runCatching { DayOfWeek.valueOf(it) }.getOrNull() }
            ?.takeIf { it in availableTrainingDays }
            ?: availableTrainingDays.firstOrNull { it == DayOfWeek.SUNDAY }
            ?: availableTrainingDays.lastOrNull()
        targetDate = prefs.getString("targetDate", "Sem prova principal") ?: "Sem prova principal"
        planStartDateIso = prefs.getString("planStartDateIso", "") ?: ""
        racePlanNote = prefs.getString("racePlanNote", "") ?: ""
        racePlanWarnings = prefs.getString("racePlanWarnings", null)?.let { raw -> runCatching {
            val array = JSONArray(raw); buildList { for (i in 0 until array.length()) add(array.optString(i)) }
        }.getOrDefault(emptyList()) } ?: emptyList()
        prefs.getString("raceEvents", null)?.let { raw -> runCatching {
            val array = JSONArray(raw)
            raceEvents = buildList { for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                add(RaceEvent(
                    id = item.optString("id"), name = item.optString("name"), distanceKm = item.optDouble("distanceKm"),
                    eventDateIso = item.optString("eventDateIso"), priority = item.optString("priority", "A"),
                    targetTime = item.optString("targetTime"), location = item.optString("location"),
                    notes = item.optString("notes"), status = item.optString("status", "PLANNED")
                ))
            } }
        } }
        volume = prefs.getString("volume", "") ?: ""
        weeklyVolumeText = prefs.getString("weeklyVolumeText", "") ?: ""
        longestRecent = prefs.getString("longestRecent", "") ?: ""
        cooperEnabled = prefs.getBoolean("cooperEnabled", false)
        cooperDistanceText = prefs.getString("cooperDistanceText", "") ?: ""
        cooperAssessmentDateText = prefs.getString("cooperAssessmentDateText", LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/uuuu"))) ?: LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/uuuu"))
        latestCooperMessage = prefs.getString("latestCooperMessage", "") ?: ""
        // Migra opções antigas (ex.: "5 km" e "Mais de 10 km") para valor editável.
        longestRecent = when {
            longestRecent.startsWith("Mais", ignoreCase = true) -> "" // faixa aberta não é distância medida; exige revisão manual
            longestRecent.contains("km", ignoreCase = true) -> longestRecent.substringBefore(" ").trim()
            else -> longestRecent
        }
        onboardingStep = prefs.getInt("onboardingStep", if (goal.isBlank()) -1 else 6)
        selectedWorkoutIndex = prefs.getInt("selectedWorkoutIndex", 0)
        planWeeks = prefs.getInt("planWeeks", 8)
        needsEngineRefresh = prefs.getBoolean("needsEngineRefresh", false) || (prefs.getInt("engineVersion", 0) < 36 && prefs.getString("workouts", null) != null)
        needsPacePlanRefresh = prefs.getBoolean("needsPacePlanRefresh", false)
        motorExplanation = prefs.getString("motorExplanation", "") ?: ""
        latestFeedbackHeadline = prefs.getString("latestFeedbackHeadline", "") ?: ""
        latestFeedbackAdvice = prefs.getString("latestFeedbackAdvice", "") ?: ""
        motorError = prefs.getString("motorError", "") ?: ""
        selectedScreen = Screen.entries.getOrNull(prefs.getInt("selectedScreen", Screen.DASHBOARD.ordinal)) ?: Screen.DASHBOARD

        prefs.getString("motorState", null)?.let { raw -> runCatching {
            val o = JSONObject(raw)
            motorState = MotorState(
                fitnessConfidence = o.optString("fitnessConfidence"),
                paceConfidence = o.optString("paceConfidence"),
                recentVolumeKm = o.optDouble("recentVolumeKm"),
                recentLongRunKm = o.optDouble("recentLongRunKm"),
                recoveryStatus = o.optString("recoveryStatus"),
                safetyStatus = o.optString("safetyStatus"),
                phase = o.optString("phase"),
                flags = buildList { val a=o.optJSONArray("flags"); if (a != null) for (i in 0 until a.length()) add(a.optString(i)) }
            )
        }}
        prefs.getString("motorDecision", null)?.let { raw -> runCatching {
            val o = JSONObject(raw)
            motorDecision = MotorDecision(
                action = o.optString("action"), necessity = o.optString("necessity"), stimulus = o.optString("stimulus"),
                rationale = o.optString("rationale"), confidence = o.optDouble("confidence"), safety = o.optString("safety")
            )
        }}
        prefs.getString("workouts", null)?.let { raw -> runCatching {
            val a = JSONArray(raw)
            workouts = buildList {
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    add(Workout(
                        date=o.optString("date"), scheduledDateIso=o.optString("scheduledDateIso"), title=o.optString("title"), detail=o.optString("detail"), type=o.optString("type"),
                        objective=o.optString("objective"), stimulus=o.optString("stimulus"), distanceKm=o.optDouble("distanceKm"),
                        done=o.optBoolean("done"), sessionId=o.optString("sessionId"), durationMin=o.optInt("durationMin"),
                        intensity=o.optString("intensity", "LOW"), paceMode=o.optString("paceMode", "PACE_NOT_CALIBRATED"),
                        rpeRange=o.optString("rpeRange", "3-4"), rationale=o.optString("rationale"),
                        week=o.optInt("week",1), phase=o.optString("phase", "BASE"),
                        manuallyRescheduled=o.optBoolean("manuallyRescheduled", false), originalScheduledDateIso=o.optString("originalScheduledDateIso", ""), selectedOption=o.optString("selectedOption", "PRIMARY"),
                        paceCalibrationSnapshot=o.optJSONObject("paceCalibration")?.let { calibration ->
                            val ranges = calibration.optJSONObject("zoneRanges")
                            PaceCalibrationSnapshot(
                                assessmentDateIso = calibration.optString("assessmentDateIso"),
                                distanceKm = calibration.optDouble("distanceKm"),
                                averagePaceMmSs = calibration.optString("averagePaceMmSs"),
                                estimatedVo2Max = calibration.optDouble("estimatedVo2Max"),
                                estimatedMasPaceMmSs = calibration.optString("estimatedMasPaceMmSs"),
                                estimatedSvt2PaceMmSs = calibration.optString("estimatedSvt2PaceMmSs"),
                                modelVersion = calibration.optString("modelVersion", "AIRC_ZONES_1_LEGACY"),
                                z2CalibrationStatus = calibration.optString("z2CalibrationStatus", "COOPER_INITIAL"),
                                talkTestEvidenceCount = calibration.optInt("talkTestEvidenceCount", 0),
                                talkTestReferencePaceMmSs = calibration.optString("talkTestReferencePaceMmSs", ""),
                                zoneRanges = if (ranges == null) emptyMap() else buildMap {
                                    for (id in listOf("Z1", "Z2", "Z3", "Z4", "Z5")) ranges.optString(id).takeIf { it.isNotBlank() }?.let { put(id, it) }
                                }
                            )
                        },
                        segments=buildList {
                            val segmentArray = o.optJSONArray("segments")
                            if (segmentArray != null) for (j in 0 until segmentArray.length()) {
                                val item = segmentArray.optJSONObject(j) ?: continue
                                add(WorkoutSegment(
                                    name=item.optString("name"), instruction=item.optString("instruction"),
                                    durationMin=if (item.has("durationMin")) item.optInt("durationMin") else null,
                                    distanceKm=if (item.has("distanceKm")) item.optDouble("distanceKm") else null,
                                    intensity=item.optString("intensity", "LOW"), rpeRange=item.optString("rpeRange", "2-3"),
                                    repeatCount=item.optInt("repeatCount", 1),
                                    targetMode=item.optString("targetMode", if (item.has("durationMin")) "TIME" else "DISTANCE"),
                                    targetPaceMinValue=item.optString("paceFasterMinKm").takeIf { it.isNotBlank() }?.let { PaceRange.parsePace(it) },
                                    targetPaceMaxValue=item.optString("paceSlowerMinKm").takeIf { it.isNotBlank() }?.let { PaceRange.parsePace(it) },
                                    paceZone=item.optString("paceZone").takeIf { it.isNotBlank() },
                                    zoneBasePaceFastValue=item.optString("zoneBasePaceFastMinKm").takeIf { it.isNotBlank() }?.let { PaceRange.parsePace(it) },
                                    zoneBasePaceSlowValue=item.optString("zoneBasePaceSlowMinKm").takeIf { it.isNotBlank() }?.let { PaceRange.parsePace(it) },
                                    zoneIntensityMinPercent=if (item.has("zoneIntensityMinPercent")) item.optInt("zoneIntensityMinPercent") else null,
                                    zoneIntensityMaxPercent=if (item.has("zoneIntensityMaxPercent")) item.optInt("zoneIntensityMaxPercent") else null
                                ))
                            }
                        }
                    ))
                }
            }
        }}
        // Repair session estimates persisted by V41. Older plans could show only
        // the minutes from TIME segments and omit the run time of DISTANCE segments.
        var durationEstimateMigrated = false
        workouts = workouts.map { saved ->
            if (saved.segments.isEmpty()) saved else {
                val corrected = WorkoutDurationEstimator.estimateMinutes(saved.segments, saved.distanceKm, saved.durationMin)
                if (corrected != saved.durationMin) durationEstimateMigrated = true
                saved.copy(durationMin = corrected)
            }
        }

        // V40 stored the current partial week as 0 and shifted all later weeks down.
        // Migrate saved cards immediately so export/periodization labels are correct
        // even before the athlete taps the recommended recalculation action.
        val migrateV40WeekNumbering = prefs.getInt("engineVersion", 0) == 32 && workouts.isNotEmpty()
        if (migrateV40WeekNumbering) {
            workouts = workouts.map { it.copy(week = TrainingScheduleEngine.migrateV40WeekIndex(it.week)) }
            needsEngineRefresh = true
        }
        // Mark V43 duration/navigation migration complete only when every saved session has
        // structured blocks that were eligible for recalculation.
        val markEngineV35 = workouts.isNotEmpty() && workouts.all { it.segments.isNotEmpty() } &&
            prefs.getInt("engineVersion", 0) < 35
        val activeZoneBandMigration = workouts.any { workout ->
            !workout.done && workout.segments.any { it.paceZone != null && it.targetPaceMinValue != null && it.zoneIntensityMinPercent == null }
        } && prefs.getInt("engineVersion", 0) < 36
        if (markEngineV35) prefs.edit().putInt("engineVersion", 35).apply()

        prefs.getString("feedbackRecords", null)?.let { raw -> runCatching {
            val a = JSONArray(raw)
            feedbackRecords = buildList {
                for (i in 0 until a.length()) {
                    val item = a.optJSONObject(i) ?: continue
                    add(FeedbackRecord(
                        sessionId = item.optString("sessionId"), effort = item.optString("effort"),
                        feeling = item.optString("feeling"), notes = item.optString("notes"),
                        painPresent = item.optBoolean("painPresent", false),
                        actualDistanceKm = if (item.has("actualDistanceKm")) item.optDouble("actualDistanceKm") else null,
                        savedAt = item.optLong("savedAt", System.currentTimeMillis()).takeIf { it > 0L } ?: System.currentTimeMillis(),
                        actualDuration = item.optString("actualDuration").takeIf { it.isNotBlank() },
                        actualPaceMinKm = item.optString("actualPaceMinKm").takeIf { it.isNotBlank() },
                        talkTestPaceMmSs = item.optString("talkTestPaceMmSs").takeIf { it.isNotBlank() },
                        workoutDateIso = item.optString("workoutDateIso"),
                        workoutType = item.optString("workoutType"),
                        workoutTitle = item.optString("workoutTitle")
                    ))
                }
            }
        } }
        prefs.getString("cooperAssessments", null)?.let { raw -> runCatching {
            val a = JSONArray(raw)
            cooperAssessments = buildList {
                for (i in 0 until a.length()) {
                    val item = a.optJSONObject(i) ?: continue
                    val distanceKm = item.optDouble("distanceKm")
                    val calculatedSnapshot = PaceCalculator.calculateCooper(distanceKm)
                    val storedRanges = item.optJSONObject("zoneRanges")
                    val storedModelVersion = item.optString("zoneModelVersion")
                    val zoneRanges = if (storedRanges != null) {
                        buildMap { for (key in listOf("Z1", "Z2", "Z3", "Z4", "Z5")) {
                            storedRanges.optString(key).takeIf { it.isNotBlank() }?.let { put(key, it) }
                        } }
                    } else calculatedSnapshot?.all()?.associate { it.id to it.range.label() }.orEmpty()
                    val resolvedModelVersion = when {
                        storedModelVersion.isNotBlank() -> storedModelVersion
                        storedRanges != null -> "AIRC_ZONES_1_LEGACY"
                        else -> calculatedSnapshot?.modelVersion ?: PaceCalculator.ZONE_MODEL_VERSION
                    }
                    val isCurrentZoneModel = resolvedModelVersion == PaceCalculator.ZONE_MODEL_VERSION
                    add(CooperAssessmentRecord(
                        dateIso = item.optString("dateIso"), distanceKm = distanceKm,
                        estimatedVo2Max = item.optDouble("estimatedVo2Max", calculatedSnapshot?.estimatedVo2Max ?: 0.0),
                        averagePace = item.optString("averagePace", calculatedSnapshot?.averageTestPaceValue?.let { PaceRange.format(it) } ?: ""),
                        estimatedMasPace = if (isCurrentZoneModel) item.optString("estimatedMasPace", calculatedSnapshot?.estimatedMasPace ?: "") else "",
                        estimatedSvt2Pace = if (isCurrentZoneModel) item.optString("estimatedSvt2Pace", calculatedSnapshot?.estimatedSvt2Pace ?: "") else "",
                        zoneModelVersion = resolvedModelVersion,
                        zoneRanges = zoneRanges,
                        z2CalibrationStatus = item.optString("z2CalibrationStatus", "COOPER_INITIAL"),
                        talkTestEvidenceCount = item.optInt("talkTestEvidenceCount", 0),
                        talkTestReferencePaceMmSs = item.optString("talkTestReferencePaceMmSs", "")
                    ))
                }
            }.sortedBy { it.dateIso }
        } }
        val feedbackSessionIds = feedbackRecords.map { it.sessionId }.toSet()
        if (feedbackSessionIds.isNotEmpty()) {
            workouts = workouts.map { workout -> if (workout.sessionId in feedbackSessionIds && !workout.done) workout.copy(done = true) else workout }
        }
        if (activeZoneBandMigration) {
            workouts = workouts.map { workout ->
                if (workout.done) workout else ZoneIntensityBandEngine.apply(workout)
            }
            needsEngineRefresh = true
        }
        syncTargetDate()
        feedbackSaved = feedbackRecords.isNotEmpty()

        // Se o perfil legado não tem volume numérico, leva diretamente à revisão do dado obrigatório.
        if (goal.isNotBlank() && weeklyVolumeText.isBlank() && workouts.isEmpty()) onboardingStep = 4
        // Um plano antigo permanece acessível; o painel pede revisão antes da nova geração.
        if (goal.isNotBlank() && workouts.isNotEmpty()) onboardingStep = 8
        if (migrateV40WeekNumbering || durationEstimateMigrated || markEngineV35 || activeZoneBandMigration || feedbackSessionIds.isNotEmpty()) {
            if (activeZoneBandMigration) prefs.edit().putInt("engineVersion", 36).apply()
            persist(synchronous = feedbackSessionIds.isNotEmpty())
        }
    }
}
private val AppColors = darkColorScheme(
    primary = Blue,
    onPrimary = Color(0xFF101827),
    secondary = Green,
    onSecondary = Color(0xFF0D201B),
    tertiary = Yellow,
    background = Navy,
    surface = Navy2,
    surfaceVariant = CardBlue,
    onBackground = TextWhite,
    onSurface = TextWhite,
    onSurfaceVariant = TextMuted
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RunningCoachApp() }
    }
}

@Composable
private fun RunningCoachApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val state = remember(context) { CoachState(context.applicationContext) }
    MaterialTheme(colorScheme = AppColors) {
        Surface(Modifier.fillMaxSize(), color = Navy) {
            if (state.onboardingStep in -1..7) Onboarding(state) else MainShell(state)
        }
    }
}

@Composable
private fun Onboarding(state: CoachState) {
    val step = state.onboardingStep
    BackHandler(enabled = step >= 0) {
        state.onboardingStep = if (step > 0) step - 1 else -1
        state.persist()
    }
    Column(
        Modifier.fillMaxSize().background(Navy).verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(12.dp))
        OnboardingBrandHeader()
        Spacer(Modifier.height(18.dp))
        StepBar(step)
        Spacer(Modifier.height(if (step == -1) 24.dp else 20.dp))
        when (step) {
            -1 -> {
                BigRunnerMark()
                Text("Seu plano. Sua evolução.", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("Prescrição inteligente de treinos de corrida. Sem execução de treino neste app.", color = TextMuted, textAlign = TextAlign.Center, modifier = Modifier.padding(12.dp))
            }
            0 -> {
                Text("Vamos começar", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("Em alguns passos vamos criar seu perfil e seu primeiro plano de corrida.", color = TextMuted, textAlign = TextAlign.Center, modifier = Modifier.padding(12.dp))
            }
            1 -> {
                ChoiceScreen("Qual é o seu objetivo?", listOf("5 km", "10 km", "Meia Maratona (21 km)", "Maratona (42 km)", "Saúde e qualidade de vida", "Outro objetivo"), state.goal) { state.goal = it; state.persist() }
                if (state.goal == "Outro objetivo") {
                    OutlinedTextField(
                        value = state.customGoalKm,
                        onValueChange = { state.customGoalKm = it.filter { ch -> ch.isDigit() || ch == ',' || ch == '.' }; state.persist() },
                        label = { Text("Distância do objetivo em km") },
                        modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color(0xFF35536A))
                    )
                }
            }
            2 -> ChoiceScreen("Qual é o seu nível de experiência?", listOf("Iniciante", "Intermediário", "Avançado", "Elite"), state.level) { state.level = it; state.persist() }
            3 -> TrainingAvailabilityEditor(state, showLongRunPreference = true)
            4 -> {
                Text("Quanto você correu por semana?", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Informe a média REAL das últimas quatro semanas. Não escolha uma faixa: esse número determina o ponto de partida do seu plano.", color = TextMuted, fontSize = 13.sp)
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = state.weeklyVolumeText,
                    onValueChange = { state.weeklyVolumeText = it.filter { ch -> ch.isDigit() || ch == ',' || ch == '.' }; state.persist() },
                    label = { Text("Média semanal em km") },
                    supportingText = { Text("Exemplo: se correu 18, 20, 22 e 20 km, informe 20 km.") },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color(0xFF35536A))
                )
                Spacer(Modifier.height(8.dp))
                Text("Sem corrida nas últimas quatro semanas? Informe 0. O motor criará uma reintrodução leve, mesmo que seu nível de experiência seja intermediário ou avançado.", color = TextMuted, fontSize = 12.sp)
            }
            5 -> {
                Text("Qual foi sua maior corrida recente?", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Informe a distância da maior sessão contínua que você realizou nas últimas quatro semanas. Isso limita o tamanho inicial do longão e das outras sessões.", color = TextMuted, fontSize = 13.sp)
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = state.longestRecent,
                    onValueChange = { state.longestRecent = it.filter { ch -> ch.isDigit() || ch == ',' || ch == '.' }; state.persist() },
                    label = { Text("Maior distância recente em km") },
                    supportingText = { Text("Exemplo: informe 8,5 para uma corrida de 8,5 km.") },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color(0xFF35536A))
                )
                Spacer(Modifier.height(8.dp))
                Text("Se não correu nas últimas quatro semanas, informe 0. Não use a distância de uma prova antiga como histórico recente.", color = TextMuted, fontSize = 12.sp)
            }
            6 -> CooperOnboardingStep(state)
            7 -> {
                Text("Resumo do seu perfil", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = CardBlue)) {
                    Column(Modifier.padding(18.dp)) {
                        InfoRow("Nome", state.name)
                        InfoRow("Nível", state.level)
                        InfoRow("Objetivo", if (state.goal == "Outro objetivo") "${state.customGoalKm} km" else state.goal)
                        InfoRow("Próxima prova principal", state.targetDate)
                        InfoRow("Frequência", "${state.frequency} dias por semana")
                        InfoRow("Volume médio nas últimas 4 semanas", if (state.weeklyVolumeText.isBlank()) "Precisa ser informado" else "${state.weeklyVolumeText} km/semana")
                        InfoRow("Maior treino recente", "${state.longestRecent} km")
                        InfoRow("Teste de Cooper", if (state.cooperEnabled) "${state.cooperDistanceText} km em 12 min" else "Ainda não realizado")
                    }
                }
            }
        }
        Spacer(Modifier.height(26.dp))
        val canContinue = when (step) {
            1 -> state.goal.isNotBlank()
            2 -> state.level.isNotBlank()
            3 -> state.availableTrainingDays.size in 2..6 && state.frequency == state.availableTrainingDays.size
            4 -> state.weeklyVolumeText.trim().replace(",", ".").toDoubleOrNull()?.let { it in 0.0..150.0 } == true
            5 -> state.longestRecent.trim().replace(",", ".").toDoubleOrNull()?.let { it in 0.0..60.0 } == true
            6 -> state.isCooperEntryValid()
            7 -> state.goal.isNotBlank() && state.level.isNotBlank() && state.availableTrainingDays.size in 2..6 && state.frequency == state.availableTrainingDays.size && state.weeklyVolumeText.trim().replace(",", ".").toDoubleOrNull()?.let { it in 0.0..150.0 } == true && state.longestRecent.trim().replace(",", ".").toDoubleOrNull()?.let { it in 0.0..60.0 } == true && (state.goal != "Outro objetivo" || state.customGoalKm.trim().replace(",", ".").toDoubleOrNull()?.let { it in 1.0..100.0 } == true)
            else -> true
        }
        PrimaryButton(if (step == 7) "Criar meu plano" else if (step <= 0) "Começar" else "Continuar", enabled = canContinue) {
            if (step == 7) state.createPlan() else { state.onboardingStep++; state.persist() }
        }
        if (state.motorError.isNotBlank()) {
            Text(state.motorError, color = Color(0xFFFF8A8A), fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
        }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable private fun StepBar(step: Int) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        repeat(8) { index ->
            Box(
                Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(50))
                    .background(if (index <= step) Blue else Color(0xFF293A52))
            )
        }
    }
}

@Composable private fun OnboardingBrandHeader() {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.onboarding_app_icon),
            contentDescription = "Ícone AI Running Coach",
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(42.dp).clip(RoundedCornerShape(12.dp))
        )
        Spacer(Modifier.width(10.dp))
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("AI RUNNING COACH", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Black, letterSpacing = 1.1.sp)
            Text("PRESCREVE HOJE · EVOLUI SEMPRE", color = Blue2, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.35.sp)
        }
    }
}

@Composable private fun BigRunnerMark() {
    Image(
        painter = painterResource(id = R.drawable.onboarding_app_icon),
        contentDescription = "Marca AI Running Coach",
        contentScale = ContentScale.Crop,
        modifier = Modifier.size(132.dp).clip(RoundedCornerShape(30.dp))
    )
}

@Composable private fun CooperOnboardingStep(state: CoachState) {
    val distance = state.cooperDistanceText.trim().replace(",", ".").toDoubleOrNull()
    val zones = state.calculateZonesForCooper(distance)
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text("Calibre suas zonas", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = TextWhite)
            Text("Informe um teste de Cooper recente (12 minutos). O resultado ajuda a estimar suas zonas de pace.", color = TextMuted, fontSize = 12.sp, lineHeight = 17.sp)
        }
        CardSurface(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("Tenho um resultado recente", color = TextWhite, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text("Preferencialmente das últimas 4–8 semanas", color = TextMuted, fontSize = 10.sp)
                    }
                    Switch(checked = state.cooperEnabled, onCheckedChange = { state.cooperEnabled = it; state.persist() })
                }
                if (state.cooperEnabled) {
                    OutlinedTextField(
                        value = state.cooperDistanceText,
                        onValueChange = { value ->
                            state.cooperDistanceText = value.filter { ch -> ch.isDigit() || ch == ',' || ch == '.' }.take(6)
                            state.persist()
                        },
                        label = { Text("Distância em 12 min (km)") },
                        placeholder = { Text("Ex.: 2,40") },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color(0xFF49617F))
                    )
                    OutlinedTextField(
                        value = state.cooperAssessmentDateText,
                        onValueChange = { value ->
                            state.cooperAssessmentDateText = value.filter { ch -> ch.isDigit() || ch == '/' }.take(10)
                            state.persist()
                        },
                        label = { Text("Data do teste (dd/mm/aaaa)") },
                        placeholder = { Text("dd/mm/aaaa") },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color(0xFF49617F))
                    )
                    if (zones != null) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            CooperMetric("PACE MÉDIO", "${PaceRange.format(zones.averageTestPaceValue)}", Modifier.weight(1f))
                            CooperMetric("VAM ESTIMADA", zones.estimatedMasPace, Modifier.weight(1f))
                            CooperMetric("VO₂ MÁX*", String.format(Locale.US, "%.1f", zones.estimatedVo2Max), Modifier.weight(1f))
                        }
                        Text("Segundo limiar estimado: ${zones.estimatedSvt2Pace} min/km", color = TextMuted, fontSize = 10.sp)
                        Text("Zonas estimadas (min/km)", color = Blue2, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        zones.all().chunked(2).forEach { pair ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                pair.forEach { zone ->
                                    Row(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(Navy2).padding(horizontal = 10.dp, vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(zone.id, color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        Text(zone.range.label(), color = TextWhite, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                }
                                if (pair.size == 1) Spacer(Modifier.weight(1f))
                            }
                        }
                        Text("*VO₂máx e VAM são estimativas de campo, não medições laboratoriais.", color = TextMuted, fontSize = 9.sp)
                    } else if (state.cooperDistanceText.isNotBlank()) {
                        Text("Informe uma distância entre 1,00 e 5,00 km.", color = Yellow, fontSize = 11.sp)
                    }
                } else {
                    Text("Você pode continuar sem o teste. O plano será criado, mas as zonas de pace ficarão sem calibração até registrar um Cooper.", color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                }
            }
        }
        CardSurface(Modifier.fillMaxWidth(), containerColor = Navy2) {
            Row(Modifier.padding(13.dp), horizontalArrangement = Arrangement.spacedBy(9.dp), verticalAlignment = Alignment.Top) {
                Text("ⓘ", color = Blue2, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text("Faça o teste descansado, em percurso plano e medido. Ele substitui uma sessão forte da semana; não realize com dor, doença ou recuperação insuficiente.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
            }
        }
        Text("Pace em mm:ss min/km · Distâncias em km · Duração do teste: 12 min", color = Blue2, fontSize = 10.sp)
    }
}

@Composable private fun CooperMetric(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(10.dp)).background(Navy2).padding(9.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(label, color = TextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(value, color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable private fun TrainingAvailabilityEditor(state: CoachState, showLongRunPreference: Boolean) {
    val days = DayOfWeek.values().toList()
    val rows = days.chunked(2)
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Dias de corrida", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text("Selecione de 2 a 6 dias. O plano usará somente esses dias.", color = TextMuted, fontSize = 11.sp)
            }
            rows.forEach { rowDays ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    rowDays.forEach { day ->
                        AvailabilityDayButton(
                            label = dayLabel(day),
                            selected = day in state.availableTrainingDays,
                            modifier = Modifier.weight(1f)
                        ) { state.setTrainingDay(day, day !in state.availableTrainingDays) }
                    }
                    if (rowDays.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("${state.availableTrainingDays.size} de 6 dias selecionados", color = Blue2, fontWeight = FontWeight.SemiBold, fontSize = 11.sp, modifier = Modifier.weight(1f))
                if (state.availableTrainingDays.size in 2..6) StatusPill("DISPONIBILIDADE", Green)
            }
            if (showLongRunPreference && state.availableTrainingDays.isNotEmpty()) {
                HorizontalDivider(color = Color(0x443F5878))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Dia preferido do longão", color = TextWhite, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        state.availableTrainingDays.forEach { day ->
                            AvailabilityDayButton(
                                label = dayLabel(day),
                                selected = state.preferredLongRunDay == day,
                                modifier = Modifier.widthIn(min = 82.dp)
                            ) { state.setLongRunDay(day) }
                        }
                    }
                }
            }
            if (state.scheduleActionMessage.isNotBlank()) Text(state.scheduleActionMessage, color = Green, fontSize = 10.sp, lineHeight = 14.sp)
        }
    }
}

@Composable private fun AvailabilityDayButton(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(
        modifier = modifier.height(46.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        color = if (selected) Color(0xFF304A70) else Color(0xFF142337),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) Blue.copy(alpha = 0.8f) else Color(0xFF34465E))
    ) {
        Row(Modifier.fillMaxSize().padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.size(15.dp).clip(RoundedCornerShape(50)).background(if (selected) Blue else Color.Transparent).border(1.dp, if (selected) Blue else TextMuted, RoundedCornerShape(50)), contentAlignment = Alignment.Center) {
                if (selected) Text("✓", color = Navy, fontSize = 9.sp, fontWeight = FontWeight.Black)
            }
            Text(label, color = if (selected) TextWhite else TextMuted, fontSize = 10.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
        }
    }
}

private fun dayLabel(day: DayOfWeek): String = when (day) {
    DayOfWeek.MONDAY -> "Segunda"
    DayOfWeek.TUESDAY -> "Terça"
    DayOfWeek.WEDNESDAY -> "Quarta"
    DayOfWeek.THURSDAY -> "Quinta"
    DayOfWeek.FRIDAY -> "Sexta"
    DayOfWeek.SATURDAY -> "Sábado"
    DayOfWeek.SUNDAY -> "Domingo"
}

private fun calendarCategory(workout: Workout): String = when {
    workout.type == "Recuperação" -> "REGENERATIVO"
    workout.type == "Longo" -> "LONGÃO"
    workout.type == "Qualidade" && (workout.title.contains("VO2", true) || workout.title.contains("interval", true)) -> "INTERVALADO"
    workout.type == "Qualidade" && workout.title.contains("fartlek", true) -> "FARTLEK"
    workout.type == "Qualidade" && (workout.title.contains("limiar", true) || workout.title.contains("tempo", true)) -> "LIMIAR"
    workout.type == "Qualidade" && (workout.title.contains("moderad", true) || workout.title.contains("steady", true)) -> "MODERADO"
    workout.title.contains("progress", true) -> "PROGRESSIVO"
    workout.type == "Qualidade" -> "QUALIDADE"
    else -> "AERÓBIO"
}

private fun calendarCategoryColor(category: String): Color = when (category) {
    "REGENERATIVO" -> Color(0xFF91B9EA)
    "AERÓBIO" -> Color(0xFF65CBA7)
    "PROGRESSIVO" -> Color(0xFFE5C16F)
    "MODERADO" -> Color(0xFFD9A66F)
    "QUALIDADE", "LIMIAR" -> Color(0xFFE89D66)
    "INTERVALADO" -> Color(0xFFE77D8B)
    "LONGÃO" -> Color(0xFF65B9D5)
    else -> Blue
}

private fun calendarCategoryShort(category: String): String = when (category) {
    "REGENERATIVO" -> "REG"
    "AERÓBIO" -> "AER"
    "PROGRESSIVO" -> "PROG"
    "MODERADO" -> "MOD"
    "FARTLEK" -> "FAR"
    "QUALIDADE" -> "QUAL"
    "LIMIAR" -> "LIM"
    "INTERVALADO" -> "INT"
    "LONGÃO" -> "LONG"
    else -> category.take(3)
}

@Composable private fun ChoiceScreen(title: String, options: List<String>, current: String, selected: (String) -> Unit) {
    Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
    Spacer(Modifier.height(14.dp))
    options.forEach { option ->
        val isSelected = option == current
        Card(
            Modifier
                .fillMaxWidth()
                .padding(vertical = 5.dp)
                .then(if (isSelected) Modifier.border(2.dp, Blue, RoundedCornerShape(12.dp)) else Modifier)
                .clickable { selected(option) },
            colors = CardDefaults.cardColors(containerColor = if (isSelected) Color(0xFF174968) else CardBlue),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(22.dp).border(2.dp, if (isSelected) Blue2 else TextMuted, RoundedCornerShape(50)),
                    contentAlignment = Alignment.Center
                ) {
                    if (isSelected) Box(Modifier.size(11.dp).clip(RoundedCornerShape(50)).background(Blue2))
                }
                Spacer(Modifier.width(12.dp))
                Text(option, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold)
            }
        }
    }
}

@Composable private fun MainShell(state: CoachState) {
    // Android system Back uses the same navigation history as in-app navigation.
    // A restored deep screen has no in-memory history, so CoachState supplies a safe parent fallback.
    BackHandler(enabled = state.canNavigateBack()) {
        state.navigateBack()
    }
    Scaffold(
        containerColor = Navy,
        bottomBar = { BottomNav(state) }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (state.selectedScreen) {
                Screen.DASHBOARD -> Dashboard(state)
                Screen.CALENDAR -> CalendarScreen(state)
                Screen.WORKOUT -> WorkoutDetail(state)
                Screen.STRUCTURE -> StructureScreen(state)
                Screen.PLAN -> PlanScreen(state)
                Screen.EVOLUTION -> EvolutionScreen(state)
                Screen.FEEDBACK -> FeedbackScreen(state)
                Screen.HISTORY -> HistoryScreen(state)
                Screen.PROFILE -> ProfileScreen(state)
                Screen.AVAILABILITY -> AvailabilityScreen(state)
                Screen.EXPORT -> ExportScreen(state)
                Screen.PACE_ZONES -> PaceZonesScreen(state)
                Screen.COOPER_TEST -> CooperTestScreen(state)
                Screen.TRAINING_LIBRARY -> TrainingLibraryScreen(state)
                Screen.RACES -> RaceManagementScreen(state)
                Screen.BACKUP -> BackupScreen(state)
            }
        }
    }
}

@Composable private fun Header(title: String, back: Boolean = false, onBack: () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (back) {
            Surface(
                modifier = Modifier.size(42.dp).clickable(onClick = onBack),
                shape = RoundedCornerShape(15.dp),
                color = Navy2
            ) { Box(contentAlignment = Alignment.Center) { Text("‹", fontSize = 30.sp, color = Blue2) } }
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("AI RUNNING COACH", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Text(title, fontSize = 23.sp, fontWeight = FontWeight.Bold, color = TextWhite)
        }
    }
}

@Composable private fun Dashboard(state: CoachState) {
    val activePlan = state.activePlanWorkouts()
    val firstVisibleWeek = activePlan.minOfOrNull { it.week } ?: 1
    val firstWeekSessions = activePlan.filter { it.week == firstVisibleWeek }
    val firstWeekRaces = state.eventsForPlanWeek(firstVisibleWeek).filter { it.status != "CANCELLED" }
    val firstWeekKm = firstWeekSessions.sumOf { it.distanceKm } + firstWeekRaces.sumOf { it.distanceKm }
    val nextWorkout = activePlan.firstOrNull { !it.done }
    val actualDistance = state.feedbackRecords.mapNotNull { it.actualDistanceKm }.sum()
    val weeklyReference = state.weeklyVolumeText.trim().replace(",", ".").toDoubleOrNull()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 22.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(start = 22.dp, end = 18.dp, top = 18.dp, bottom = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("TRAINING HUB", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.8.sp)
                Text("Olá, ${state.name}!", color = TextWhite, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text("Seu treinamento, em um só lugar.", color = TextMuted, fontSize = 13.sp)
            }
            Surface(shape = RoundedCornerShape(18.dp), color = CardBlue, modifier = Modifier.size(48.dp)) {
                Box(contentAlignment = Alignment.Center) { Text(state.name.take(1).uppercase(), color = Blue2, fontWeight = FontWeight.Bold, fontSize = 20.sp) }
            }
        }

        Surface(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            shape = RoundedCornerShape(28.dp),
            color = Color.Transparent
        ) {
            Column(
                Modifier.background(Brush.linearGradient(listOf(Color(0xFF263D62), Color(0xFF172B46), Color(0xFF183B50)))).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("SEU CICLO ATUAL", color = Color(0xFFCEDAFF), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                        Text("Plano de ${state.planWeeks} semanas", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    }
                    Surface(shape = RoundedCornerShape(50), color = Color(0x333FCEB7)) {
                        Text(if (state.workouts.isNotEmpty()) "ATIVO" else "PENDENTE", color = Color(0xFF9AF0D5), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp))
                    }
                }
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text(formatKmUi(firstWeekKm), fontSize = 38.sp, fontWeight = FontWeight.Black, color = Color.White)
                        Text("km estimados na semana 1", fontSize = 12.sp, color = Color(0xFFD0D9EA))
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("${firstWeekSessions.size + firstWeekRaces.size}", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("compromissos", fontSize = 12.sp, color = Color(0xFFD0D9EA))
                    }
                }
                ProgressTrack(progress = if (weeklyReference != null && weeklyReference > 0.0) (firstWeekKm / weeklyReference).toFloat().coerceIn(0f, 1f) else 0f, color = Color(0xFF9BE2D0), trackColor = Color(0x55FFFFFF))
                Text(
                    text = if (state.weeklyVolumeText.isNotBlank()) "Base informada: ${state.weeklyVolumeText} km/semana" else "Informe sua base recente para personalizar a carga",
                    color = Color(0xFFD0D9EA), fontSize = 11.sp
                )
            }
        }

        SectionHeading("Indicadores do atleta", "Dados do perfil")
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricPod("Volume de referência", state.weeklyVolumeText.takeIf { it.isNotBlank() }?.let { "$it km" } ?: "Não informado", "↗", Blue2, Modifier.weight(1f), "Média das últimas 4 semanas")
            MetricPod("Maior sessão", state.longestRecent.takeIf { it.isNotBlank() }?.let { "$it km" } ?: "Não informada", "◷", Color(0xFFFFD18A), Modifier.weight(1f), "Distância contínua recente")
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricPod("Recuperação", recoveryLabel(state.motorState?.recoveryStatus), "✦", Color(0xFF91D9C5), Modifier.weight(1f), "Baseada nos feedbacks registrados")
            MetricPod("Segurança", safetyLabel(state.motorState?.safetyStatus), "♥", if (state.motorState?.safetyStatus == "RED") Color(0xFFFF9292) else Color(0xFF91D9C5), Modifier.weight(1f), "Alertas conhecidos pelo treinador")
        }

        val cooperStatus = state.cooperReviewStatus()
        val currentZones = state.currentPaceZones()
        CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), containerColor = Color(0xFF1A2D43)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("ZONAS DE PACE", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                        Text(if (currentZones != null) "Perfil calibrado" else "Pace ainda não calibrado", color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                    StatusPill(if (cooperStatus.isDue) "REVISÃO" else if (currentZones != null) "Z1–Z5" else "PENDENTE", if (cooperStatus.isDue) Yellow else Green)
                }
                if (currentZones != null) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        currentZones.all().forEach { zone ->
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(zone.id, color = Blue2, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text(zone.range.label().removeSuffix(" min/km"), color = TextWhite, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Text(cooperStatus.message, color = TextMuted, fontSize = 10.sp)
                } else {
                    Text("Realize o Cooper de 12 minutos para gerar as cinco faixas individualizadas em mm:ss min/km.", color = TextMuted, fontSize = 11.sp)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SecondaryButton("Ver zonas", modifier = Modifier.weight(1f), horizontalPadding = 0) { state.navigateTo(Screen.PACE_ZONES) }
                    PrimaryButton("${if (cooperStatus.isDue) "Reavaliar" else "Teste Cooper"}", modifier = Modifier.weight(1f), horizontalPadding = 0) { state.navigateTo(Screen.COOPER_TEST) }
                }
            }
        }

        val upcomingRace = state.primaryUpcomingRace()
        if (upcomingRace != null) {
            SectionHeading("Próxima competição", "Gerenciar") { state.navigateTo(Screen.RACES) }
            CardSurface(Modifier.padding(horizontal = 16.dp).clickable { state.navigateTo(Screen.RACES) }, containerColor = Color(0xFF292747)) {
                Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("🏁", fontSize = 29.sp)
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(upcomingRace.name, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("${formatKmUi(upcomingRace.distanceKm)} km • ${RaceEventEngine.formatBrazilianDate(upcomingRace.eventDateIso)} • Prioridade ${upcomingRace.priority}", color = Color(0xFFD2BFFF), fontSize = 10.sp)
                        val raceDate = upcomingRace.dateOrNull()
                        if (raceDate != null) Text("${java.time.temporal.ChronoUnit.DAYS.between(LocalDate.now(), raceDate).coerceAtLeast(0)} dias até a prova", color = TextMuted, fontSize = 10.sp)
                    }
                    Text("›", color = Blue2, fontSize = 25.sp)
                }
            }
        }

        SectionHeading("Distribuição semanal", "Planejado")
        CardSurface(Modifier.padding(horizontal = 16.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(if (firstVisibleWeek == 1) "Semana 1 · em andamento" else "Semana $firstVisibleWeek do plano", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                if (firstWeekRaces.isNotEmpty()) Text("${firstWeekSessions.size} treinos + ${firstWeekRaces.size} prova(s)", color = Color(0xFFD2BFFF), fontSize = 10.sp)
                        Text("Distância prevista por dia", color = TextMuted, fontSize = 11.sp)
                    }
                    Text("${formatKmUi(firstWeekKm)} km", color = Blue2, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                SevenDayBreakdown(firstWeekSessions, firstWeekRaces)
                Text("Barras roxas indicam competição. O gráfico mostra compromissos planejados, não atividades realizadas.", color = TextMuted, fontSize = 10.sp)
            }
        }

        SectionHeading("Próximo treino", "Ver calendário") {
            state.navigateTo(Screen.CALENDAR)
        }
        if (nextWorkout != null) {
            NextWorkoutCard(nextWorkout) { state.selectWorkout(nextWorkout) }
        } else {
            EmptyStateCard("Nenhum treino pendente", "Gere um novo ciclo para visualizar suas próximas sessões.", "Criar ou revisar plano") {
                state.onboardingStep = if (state.weeklyVolumeText.isBlank()) 4 else 6
                state.persist()
            }
        }

        state.motorDecision?.let { decision ->
            SectionHeading("Leitura do treinador")
            CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF182B3D)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text(stimulusLabel(decision.stimulus), color = Blue2, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(decision.rationale, color = TextMuted, fontSize = 12.sp, lineHeight = 18.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        StatusPill("Confiança ${((decision.confidence * 100).toInt()).coerceIn(0, 100)}%", Color(0xFFB7C8FF))
                        StatusPill(safetyLabel(decision.safety), if (decision.safety == "RED") Color(0xFFFF9292) else Color(0xFF9BE2D0))
                    }
                }
            }
        }
        if (state.needsEngineRefresh) {
            NoteBlock("Há dados novos desde a última prescrição — atividade concluída, disponibilidade, competição ou atualização do motor. Recalcule para adaptar as próximas sessões; os treinos concluídos serão preservados.")
            PrimaryButton("Recalcular plano com os dados atuais") { state.createPlan() }
        }
        if (state.needsPacePlanRefresh) {
            NoteBlock("A Z2 recebeu uma calibração individual com base em registros consistentes do teste da fala. Recrie o plano para aplicar a nova faixa às próximas sessões; os treinos anteriores permanecem preservados.")
            PrimaryButton("Aplicar calibração e recalcular próximas sessões") {
                val updated = state.recalibratePlan()
                if (!updated && state.motorError.isBlank()) state.motorError = "Não foi possível aplicar a calibração. Confira o perfil e o histórico recente."
            }
            if (state.motorError.isNotBlank()) NoteBlock(state.motorError)
        }
        if (actualDistance > 0.0) {
            CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("Distância registrada", color = TextMuted, fontSize = 11.sp)
                        Text("${formatKmUi(actualDistance)} km", color = TextWhite, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("${state.completedWorkouts().size} concluídos", color = Green, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
    }
}

@Composable private fun MetricPod(label: String, value: String, icon: String, accent: Color, modifier: Modifier = Modifier, subtitle: String = "") {
    CardSurface(modifier.padding(vertical = 5.dp), containerColor = CardBlue) {
        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                Text(icon, color = accent, fontSize = 18.sp)
                Text(label, color = TextMuted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text(value, color = accent, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (subtitle.isNotBlank()) Text(subtitle, color = TextMuted, fontSize = 9.sp, lineHeight = 12.sp)
        }
    }
}

@Composable private fun CardBlock(title: String, main: String, note: String) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, color = Blue2, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(main, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = TextWhite)
            Text(note, color = TextMuted, fontSize = 12.sp, lineHeight = 17.sp)
        }
    }
}

@Composable private fun WorkoutCard(w: Workout, onClick: () -> Unit) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp).clickable(onClick = onClick)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            SessionGlyph(w, 44)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("${w.date}  •  ~${formatKmUi(w.distanceKm)} km estimados", color = TextMuted, fontSize = 10.sp)
                Text(w.title, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(workoutTypeLabel(w.type), color = Blue2, fontSize = 11.sp)
            }
            Text(if (w.done) "✓" else "›", color = if (w.done) Green else TextMuted, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable private fun CalendarScreen(state: CoachState) {
    var displayedMonth by remember { mutableStateOf(YearMonth.now()) }
    var selectedDate by remember { mutableStateOf(LocalDate.now()) }
    var viewMode by remember { mutableStateOf("MONTH") }
    val workoutsByDate = state.workouts.filter { it.scheduledDateIso.isNotBlank() }.map { if (it.selectedOption == "ALTERNATIVE") WorkoutAlternativeEngine.createAlternative(it) else it }.groupBy { it.scheduledDateIso }
    val eventsByDate = state.raceEvents.filter { it.status != "CANCELLED" }.groupBy { it.eventDateIso }
    val monthStart = displayedMonth.atDay(1).with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    val monthDays = (0 until 42).map { monthStart.plusDays(it.toLong()) }
    val nextRace = state.primaryUpcomingRace()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Calendário")
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20334D)) {
            Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("AGENDA ESPORTIVA", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
                Text("${state.workouts.size} treinos • ${state.raceEvents.count { it.status != "CANCELLED" }} provas", color = TextWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(nextRace?.let { "Próxima prova: ${it.name} • ${RaceEventEngine.formatBrazilianDate(it.eventDateIso)}" } ?: "Cadastre suas competições para o treinador organizar a preparação por data.", color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                PrimaryButton("Gerenciar competições", modifier = Modifier.fillMaxWidth()) { state.navigateTo(Screen.RACES) }
            }
        }

        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 13.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = viewMode == "MONTH", onClick = { viewMode = "MONTH" }, label = { Text("Mês") })
            FilterChip(selected = viewMode == "WEEK", onClick = { viewMode = "WEEK" }, label = { Text("Semana") })
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = {
                displayedMonth = displayedMonth.minusMonths(1)
                selectedDate = displayedMonth.atDay(1)
            }) { Text("‹", fontSize = 24.sp, color = Blue2) }
            Text(displayedMonth.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale("pt", "BR"))).replaceFirstChar { it.uppercase() }, color = TextWhite, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
            TextButton(onClick = {
                displayedMonth = displayedMonth.plusMonths(1)
                selectedDate = displayedMonth.atDay(1)
            }) { Text("›", fontSize = 24.sp, color = Blue2) }
        }

        if (viewMode == "WEEK") {
            val weekStart = selectedDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { selectedDate = selectedDate.minusWeeks(1); displayedMonth = YearMonth.from(selectedDate) }) { Text("‹ Semana anterior", color = Blue2, fontSize = 10.sp) }
                Spacer(Modifier.weight(1f))
                Text("${weekStart.format(DateTimeFormatter.ofPattern("dd/MM"))} – ${weekStart.plusDays(6).format(DateTimeFormatter.ofPattern("dd/MM"))}", color = TextMuted, fontSize = 10.sp)
                TextButton(onClick = { selectedDate = selectedDate.plusWeeks(1); displayedMonth = YearMonth.from(selectedDate) }) { Text("Próxima ›", color = Blue2, fontSize = 10.sp) }
            }
        }

        if (viewMode == "MONTH") {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                listOf("SEG", "TER", "QUA", "QUI", "SEX", "SÁB", "DOM").forEach { day ->
                    Text(day, modifier = Modifier.weight(1f), color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                }
            }
            monthDays.chunked(7).forEach { rowDays ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    rowDays.forEach { date ->
                        val dayWorkouts = workoutsByDate[date.toString()].orEmpty()
                        val dayEvents = eventsByDate[date.toString()].orEmpty()
                        val selected = date == selectedDate
                        val inMonth = date.month == displayedMonth.month
                        Card(
                            modifier = Modifier.weight(1f).height(62.dp).clickable { selectedDate = date; displayedMonth = YearMonth.from(date) },
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = when {
                                selected -> Color(0xFF304A73)
                                !inMonth -> Color(0xFF101B2A)
                                else -> Color(0xFF182A40)
                            })
                        ) {
                            Column(Modifier.fillMaxSize().padding(5.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceBetween) {
                                Text(date.dayOfMonth.toString(), color = if (inMonth) TextWhite else Color(0xFF607086), fontSize = 11.sp, fontWeight = if (selected) FontWeight.Black else FontWeight.Medium)
                                Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                    dayWorkouts.map { calendarCategory(it) }.distinct().take(4).forEach { category ->
                                        Box(Modifier.size(6.dp).clip(RoundedCornerShape(50)).background(calendarCategoryColor(category)))
                                    }
                                    if (dayEvents.isNotEmpty()) Box(Modifier.size(6.dp).clip(RoundedCornerShape(50)).background(Color(0xFFB79AF7)))
                                }
                                val dayLabels = dayWorkouts.map { calendarCategoryShort(calendarCategory(it)) }.distinct().take(2).joinToString("·")
                                Text(when { dayEvents.isNotEmpty() -> "PROVA"; dayLabels.isNotBlank() -> dayLabels; else -> "" }, color = if (dayEvents.isNotEmpty()) Color(0xFFD2BFFF) else TextMuted, fontSize = 7.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            }
                        }
                    }
                }
            }
        } else {
            val monday = selectedDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            (0..6).forEach { offset ->
                val date = monday.plusDays(offset.toLong())
                CalendarDayAgenda(
                    date = date,
                    workouts = workoutsByDate[date.toString()].orEmpty(),
                    events = eventsByDate[date.toString()].orEmpty(),
                    onWorkout = { state.selectWorkout(it) }
                )
            }
        }

        if (viewMode == "MONTH") {
            SectionHeading("${selectedDate.format(DateTimeFormatter.ofPattern("EEEE, dd 'de' MMMM", Locale("pt", "BR"))).replaceFirstChar { it.uppercase() }}")
            val selectedEvents = eventsByDate[selectedDate.toString()].orEmpty()
            val selectedWorkouts = workoutsByDate[selectedDate.toString()].orEmpty()
            if (selectedEvents.isEmpty() && selectedWorkouts.isEmpty()) {
                NoteBlock("Nenhum treino ou competição nesta data. Os dias livres ficam disponíveis para descanso e compromissos pessoais.")
            }
            selectedEvents.forEach { event -> RaceAgendaRow(event) }
            selectedWorkouts.forEach { workout -> SessionAgendaRow(workout) { state.selectWorkout(workout) } }
        }

        SectionHeading("Legenda")
        Column(Modifier.fillMaxWidth().padding(horizontal = 17.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                LegendDot("Regenerativo", calendarCategoryColor("REGENERATIVO"))
                LegendDot("Aeróbio", calendarCategoryColor("AERÓBIO"))
                LegendDot("Moderado", calendarCategoryColor("MODERADO"))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                LegendDot("Progressivo", calendarCategoryColor("PROGRESSIVO"))
                LegendDot("Qualidade/limiar", calendarCategoryColor("QUALIDADE"))
                LegendDot("Intervalado", calendarCategoryColor("INTERVALADO"))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                LegendDot("Fartlek", calendarCategoryColor("FARTLEK"))
                LegendDot("Longão", calendarCategoryColor("LONGÃO"))
                LegendDot("Prova", Color(0xFFB79AF7))
                LegendDot("Descanso", TextMuted)
            }
        }
        if (state.needsEngineRefresh) {
            NoteBlock("Sua disponibilidade semanal ou as competições foram alteradas. Recalcule o plano para redistribuir as sessões e ajustar a preparação. Treinos concluídos serão preservados.")
            PrimaryButton("Recalcular preparação") { state.createPlan() }
        }
    }
}

@Composable private fun CalendarDayAgenda(
    date: LocalDate,
    workouts: List<Workout>,
    events: List<RaceEvent>,
    onWorkout: (Workout) -> Unit
) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), containerColor = Color(0xFF142338)) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(date.format(DateTimeFormatter.ofPattern("EEEE, dd/MM", Locale("pt", "BR"))).replaceFirstChar { it.uppercase() }, color = Blue2, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            if (events.isEmpty() && workouts.isEmpty()) Text("Descanso / sem compromisso", color = TextMuted, fontSize = 10.sp)
            events.forEach { RaceAgendaRow(it) }
            workouts.forEach { SessionAgendaRow(it) { onWorkout(it) } }
        }
    }
}

@Composable private fun LegendDot(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Box(Modifier.size(8.dp).clip(RoundedCornerShape(50)).background(color))
        Text(label, color = TextMuted, fontSize = 9.sp)
    }
}

@Composable private fun RaceAgendaRow(event: RaceEvent) {
    CardSurface(containerColor = Color(0xFF2B2850)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("🏁", fontSize = 21.sp)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(event.name, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text("${formatKmUi(event.distanceKm)} km • ${event.priorityLabel()} • ${RaceEventEngine.formatBrazilianDate(event.eventDateIso)}", color = Color(0xFFD2BFFF), fontSize = 9.sp)
                if (event.targetTime.isNotBlank()) Text("Tempo-alvo: ${event.targetTime}", color = TextMuted, fontSize = 9.sp)
            }
            StatusPill(when (event.status) { "COMPLETED" -> "REALIZADA"; "CANCELLED" -> "CANCELADA"; else -> "PROVA" }, Color(0xFFB79AF7))
        }
    }
}

@Composable private fun RaceManagementScreen(state: CoachState) {
    val sortedEvents = state.raceEvents.sortedBy { it.eventDateIso }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 26.dp)) {
        Header("Competições")
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20334D)) {
            Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("PROVAS E OBJETIVOS", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
                Text("${sortedEvents.count { it.status == "PLANNED" }} provas programadas", color = TextWhite, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text("Cadastre datas e distâncias. A prova principal orienta o ciclo; provas B e C entram como eventos preparatórios ou de treinamento.", color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
            }
        }
        SectionHeading(if (state.editingRaceId.isBlank()) "Cadastrar competição" else "Editar competição")
        CardSurface(Modifier.padding(horizontal = 16.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(state.raceNameDraft, { state.raceNameDraft = it.take(80) }, label = { Text("Nome da prova") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(state.raceDistanceDraft, { state.raceDistanceDraft = it.filter { c -> c.isDigit() || c == ',' || c == '.' }.take(6) }, label = { Text("Distância (km)") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(state.raceDateDraft, { state.raceDateDraft = it.filter { c -> c.isDigit() || c == '/' }.take(10) }, label = { Text("Data (dd/mm/aaaa)") }, modifier = Modifier.weight(1.25f), singleLine = true)
                }
                Text("Prioridade da competição", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf("A", "B", "C").forEach { priority ->
                        FilterChip(
                            selected = state.racePriorityDraft == priority,
                            onClick = { state.racePriorityDraft = priority },
                            label = { Text("$priority • ${when (priority) { "A" -> "Principal"; "B" -> "Preparatória"; else -> "Treino" }}") }
                        )
                    }
                }
                OutlinedTextField(state.raceTargetTimeDraft, { state.raceTargetTimeDraft = it.filter { c -> c.isDigit() || c == ':' }.take(8) }, label = { Text("Tempo-alvo (opcional)") }, supportingText = { Text("mm:ss ou hh:mm:ss") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(state.raceLocationDraft, { state.raceLocationDraft = it.take(100) }, label = { Text("Local (opcional)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(state.raceNotesDraft, { state.raceNotesDraft = it.take(300) }, label = { Text("Observações (opcional)") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                if (state.raceFormError.isNotBlank()) Text(state.raceFormError, color = Color(0xFFFF9292), fontSize = 11.sp)
                PrimaryButton(if (state.editingRaceId.isBlank()) "Salvar competição" else "Salvar alterações") {
                    if (state.saveRaceDraft()) state.navigateTo(Screen.RACES)
                }
                if (state.editingRaceId.isNotBlank()) SecondaryButton("Cancelar edição") { state.resetRaceDraft() }
            }
        }
        SectionHeading("Competições cadastradas", sortedEvents.size.toString())
        if (sortedEvents.isEmpty()) EmptyStateCard("Nenhuma prova cadastrada", "Adicione sua competição principal para que o treinador organize o ciclo e a semana da prova.", "Cadastrar prova") { state.raceNameDraft = "Minha prova" }
        sortedEvents.forEach { event ->
            CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(event.name, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        StatusPill("PRIORIDADE ${event.priority}", if (event.priority == "A") Green else Blue2)
                    }
                    Text("${formatKmUi(event.distanceKm)} km • ${RaceEventEngine.formatBrazilianDate(event.eventDateIso)} • ${raceStatusLabel(event.status)}", color = TextMuted, fontSize = 11.sp)
                    if (event.location.isNotBlank()) Text(event.location, color = TextMuted, fontSize = 10.sp)
                    if (event.targetTime.isNotBlank()) Text("Tempo-alvo: ${event.targetTime}", color = Blue2, fontSize = 10.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SecondaryButton("Editar", modifier = Modifier.weight(1f), horizontalPadding = 0) { state.beginRaceEdit(event) }
                        if (event.status == "PLANNED" && event.dateOrNull()?.let { !it.isAfter(LocalDate.now()) } == true) {
                            SecondaryButton("Marcar realizada", modifier = Modifier.weight(1f), horizontalPadding = 0) { state.markRaceCompleted(event.id) }
                        }
                        SecondaryButton("Excluir", modifier = Modifier.weight(1f), horizontalPadding = 0) { state.deleteRace(event.id) }
                    }
                }
            }
        }
        if (state.racePlanNote.isNotBlank()) {
            SectionHeading("Integração com o plano")
            NoteBlock(state.racePlanNote)
            state.racePlanWarnings.forEach { NoteBlock(it) }
            if (state.needsEngineRefresh) PrimaryButton("Recalcular plano com as provas") { state.createPlan() }
        }
        NoteBlock("A prova é um compromisso de corrida e substitui uma sessão da frequência semanal. A prioridade A define o ciclo principal; a redução de carga e a recuperação dependem da distância, do histórico e do tempo disponível.")
    }
}

@Composable private fun WorkoutDetail(state: CoachState) {
    val workout = state.selectedWorkout()
    var showReschedule by remember(workout?.sessionId) { mutableStateOf(false) }
    var showAlternativeDialog by remember(workout?.sessionId) { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Header("Sessão de treinamento", true) { state.navigateBack(Screen.CALENDAR) }
        if (workout == null) {
            EmptyStateCard("Nenhuma sessão selecionada", "Escolha um treino no calendário ou no plano.", "Abrir calendário") { state.navigateTo(Screen.CALENDAR) }
            return@Column
        }

        val baseWorkout = state.selectedWorkoutBase() ?: workout
        val isAlternativeSelected = baseWorkout.selectedOption == "ALTERNATIVE"
        // Uma única prescrição fica visível. A alternativa só aparece quando solicitada.
        SessionHero(workout)
        Row(
            Modifier.fillMaxWidth().padding(start = 18.dp, end = 16.dp, top = 2.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    if (isAlternativeSelected) "ALTERNATIVA ESCOLHIDA" else "PRESCRIÇÃO RECOMENDADA",
                    color = if (isAlternativeSelected) Color(0xFFE5C16F) else Green,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Text("Há outra opção compatível com esta sessão.", color = TextMuted, fontSize = 10.sp)
            }
            if (!baseWorkout.done && baseWorkout.type != "Competição") {
                TextButton(
                    onClick = { showAlternativeDialog = true },
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text("⇄ Trocar treino", color = Blue2, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        SectionHeading("Objetivo da sessão")
        CardSurface(Modifier.padding(horizontal = 16.dp)) {
            Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(workout.objective, color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Text(workout.rationale, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
            }
        }

        // Distância, duração e pace já aparecem no SessionHero; removemos o resumo duplicado.
        SectionHeading("Estrutura do treino", "Ver todos") { state.navigateTo(Screen.STRUCTURE) }
        workout.segments.take(4).forEachIndexed { index, segment -> SegmentRow(index + 1, segment) }

        if (workout.manuallyRescheduled) {
            Text(
                "Sessão movida da data original ${workout.originalScheduledDateIso.takeIf { it.isNotBlank() } ?: "não registrada"}. Dose e blocos preservados.",
                color = TextMuted, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 18.dp, vertical = 4.dp)
            )
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (!workout.done) {
                SecondaryButton("Reagendar", modifier = Modifier.weight(1f), horizontalPadding = 0) {
                    state.scheduleActionMessage = ""
                    showReschedule = true
                }
            }
            SecondaryButton("Feedback", modifier = Modifier.weight(1f), horizontalPadding = 0) {
                state.navigateTo(Screen.FEEDBACK)
            }
        }
        PrimaryButton("Exportar para Pace Coach", modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth()) {
            state.navigateTo(Screen.EXPORT)
        }
    }

    if (showAlternativeDialog && workout != null) {
        val base = state.selectedWorkoutBase() ?: workout
        val returningToPrimary = base.selectedOption == "ALTERNATIVE"
        val candidate = if (returningToPrimary) base.copy(selectedOption = "PRIMARY") else WorkoutAlternativeEngine.createAlternative(base)
        AlertDialog(
            onDismissRequest = { showAlternativeDialog = false },
            containerColor = CardBlue,
            title = { Text(if (returningToPrimary) "Voltar ao treino recomendado?" else "Outra opção para hoje", color = TextWhite, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text(if (returningToPrimary) "PRESCRIÇÃO PRINCIPAL" else "ALTERNATIVA", color = if (returningToPrimary) Green else Color(0xFFE5C16F), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(candidate.title, color = TextWhite, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text("${formatKmUi(candidate.distanceKm)} km estimados • Tempo estimado: ~${candidate.durationMin} min", color = Blue2, fontSize = 12.sp)
                    candidate.primaryPaceRange()?.let { Text("Pace-alvo: $it min/km", color = Blue2, fontSize = 12.sp) }
                    Text(candidate.objective, color = TextWhite, fontSize = 12.sp)
                    Text(candidate.rationale, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                    Text("A escolha substitui a sessão atual. Não acrescenta treino nem volume à semana.", color = TextMuted, fontSize = 10.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    state.selectWorkoutOption(base.sessionId, if (returningToPrimary) "PRIMARY" else "ALTERNATIVE")
                    showAlternativeDialog = false
                }) { Text(if (returningToPrimary) "Voltar ao recomendado" else "Usar esta opção", color = Blue2, fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { showAlternativeDialog = false }) { Text("Manter atual", color = TextMuted) }
            }
        )
    }

    if (showReschedule && workout != null) {
        val candidates = state.availableRescheduleDates(workout)
        AlertDialog(
            onDismissRequest = { showReschedule = false },
            containerColor = CardBlue,
            title = { Text("Reagendar sessão", color = TextWhite) },
            text = {
                Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("Escolha um dia livre dentro da mesma semana. A sessão mantém distância, pace, blocos e identidade.", color = TextMuted, fontSize = 12.sp)
                    if (candidates.isEmpty()) Text("Não há outro dia seguro e livre nesta semana.", color = Yellow, fontSize = 12.sp)
                    candidates.forEach { date ->
                        OutlinedButton(onClick = {
                            if (state.rescheduleWorkout(workout, date)) showReschedule = false
                        }, modifier = Modifier.fillMaxWidth()) {
                            Text(date.format(DateTimeFormatter.ofPattern("EEEE, dd/MM", Locale("pt", "BR"))).replaceFirstChar { it.uppercase() }, color = Blue2)
                        }
                    }
                    if (state.scheduleActionMessage.isNotBlank()) Text(state.scheduleActionMessage, color = Yellow, fontSize = 11.sp)
                }
            },
            confirmButton = { TextButton(onClick = { showReschedule = false }) { Text("Fechar", color = Blue2) } }
        )
    }
}

@Composable private fun StructureScreen(state: CoachState) {
    val workout = state.selectedWorkout()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 22.dp)) {
        Header("Estrutura da sessão", true) { state.navigateBack(Screen.WORKOUT) }
        if (workout == null) {
            EmptyStateCard("Sessão não encontrada", "Selecione uma sessão para consultar os blocos.", "Voltar ao calendário") { state.navigateBack(Screen.CALENDAR) }
            return@Column
        }
        SessionHero(workout)
        SectionHeading("Blocos prescritos")
        if (workout.segments.isEmpty()) {
            NoteBlock("Esta sessão pertence a um plano antigo e não possui blocos detalhados. Gere um novo ciclo para receber a estrutura completa.")
        } else {
            workout.segments.forEachIndexed { index, segment -> SegmentRow(index + 1, segment) }
        }
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF1A2A3D)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("Orientação do treinador", color = Blue2, fontWeight = FontWeight.Bold)
                Text(workout.rationale, color = TextMuted, fontSize = 12.sp, lineHeight = 18.sp)
            }
        }
    }
}

@Composable private fun SessionHero(workout: Workout) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF243B5D), Color(0xFF17344B))))
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatusPill(workoutTypeLabel(workout.type).uppercase(), Color(0xFFBFD0FF))
            Spacer(Modifier.weight(1f))
            Text(if (workout.done) "CONCLUÍDO" else "PROGRAMADO", color = if (workout.done) Color(0xFF9BE2D0) else Color(0xFFCEDAFF), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
        }
        Text(workout.title, color = Color.White, fontSize = 23.sp, lineHeight = 27.sp, fontWeight = FontWeight.Bold)
        Text("${workout.date}  ·  Semana ${workout.week}  ·  ${phaseLabel(workout.phase)}", color = Color(0xFFD0D9EA), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SessionMetric("DISTÂNCIA", formatKmUi(workout.distanceKm), "km", Modifier.weight(1f))
            SessionMetric("TEMPO", "~${workout.durationMin}", "min", Modifier.weight(1f))
            SessionMetric("PACE", workout.primaryPaceRange() ?: "—", "min/km", Modifier.weight(1f), compact = true)
        }
    }
}

@Composable private fun SessionMetric(label: String, value: String, unit: String, modifier: Modifier = Modifier, compact: Boolean = false) {
    Column(
        modifier.clip(RoundedCornerShape(13.dp)).background(Color.White.copy(alpha = 0.055f)).padding(horizontal = 9.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Text(label, color = Color(0xFFB9C8DE), fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.45.sp, maxLines = 1)
        Text(value, color = Color.White, fontSize = if (compact) 13.sp else 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false, overflow = TextOverflow.Clip)
        Text(unit, color = Color(0xFFD0D9EA), fontSize = 9.sp, maxLines = 1)
    }
}

@Composable private fun SegmentRow(index: Int, segment: WorkoutSegment) {
    val dose = when {
        segment.targetMode == "TIME" && segment.repeatCount > 1 && segment.durationMin != null -> "${segment.repeatCount} × ${segment.durationMin} min"
        segment.targetMode == "TIME" && segment.durationMin != null -> "${segment.durationMin} min"
        segment.repeatCount > 1 && segment.distanceKm != null -> "${segment.repeatCount} × ${formatKmUi(segment.distanceKm)} km"
        segment.distanceKm != null -> "${formatKmUi(segment.distanceKm)} km"
        segment.durationMin != null -> "${segment.durationMin} min"
        else -> "Conforme orientação"
    }
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
            Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFF253A56), modifier = Modifier.size(34.dp)) {
                Box(contentAlignment = Alignment.Center) { Text(index.toString(), color = Blue2, fontWeight = FontWeight.Bold) }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(segment.name, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(dose, color = Blue2, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(segment.instruction, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                if (segment.targetPaceMinValue != null && segment.targetPaceMaxValue != null) {
                    Text("${segment.paceZone?.let { "$it • " } ?: ""}Pace-alvo: ${PaceRange(segment.targetPaceMinValue, segment.targetPaceMaxValue).label()}", color = Blue2, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    if (segment.zoneIntensityMinPercent != null && segment.zoneIntensityMaxPercent != null) {
                        Text("Faixa ativa: ${segment.zoneIntensityMinPercent}–${segment.zoneIntensityMaxPercent}% da zona", color = TextMuted, fontSize = 10.sp)
                    }
                } else {
                    Text("Pace individual ainda não calibrado", color = Yellow, fontSize = 10.sp)
                }
                Text("RPE ${segment.rpeRange}: referência complementar de esforço", color = TextMuted, fontSize = 10.sp)
            }
        }
    }
}

@Composable private fun PlanScreen(state: CoachState) {
    val groups = state.activePlanWorkouts().groupBy { it.week }.toSortedMap()
    var expandedWeek by remember(state.activePlanWorkouts().size) { mutableStateOf(groups.keys.firstOrNull() ?: 1) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 26.dp)) {
        Header("Plano de treinamento")
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).clip(RoundedCornerShape(28.dp)).background(Brush.linearGradient(listOf(Color(0xFF293F63), Color(0xFF182C45)))).padding(20.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
            Text("OBJETIVO PRINCIPAL", color = Color(0xFFCEDAFF), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
            Text(state.primaryUpcomingRace()?.let { "${it.name} • ${formatKmUi(it.distanceKm)} km" } ?: goalLabel(state), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
            Text("${state.level.ifBlank { "Nível não informado" }}  •  ${state.frequency} dias por semana", color = Color(0xFFD0D9EA), fontSize = 12.sp)
            HorizontalDivider(color = Color(0x446F8DB8))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                PlanStat("Duração", "${state.planWeeks} sem.")
                PlanStat("Base recente", "${state.weeklyVolumeText.ifBlank { "—" }} km")
                PlanStat("Maior treino", "${state.longestRecent.ifBlank { "—" }} km")
            }
        }
        SectionHeading("Periodização", "${groups.size} semanas no ciclo")
        if (state.motorDecision != null) {
            CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 2.dp), containerColor = Color(0xFF192B40)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("ESTRATÉGIA DO TREINADOR", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                    Text(stimulusLabel(state.motorDecision!!.stimulus), color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(state.motorDecision!!.rationale, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                }
            }
        }
        if (groups.isEmpty()) EmptyStateCard("Plano não criado", "Complete o perfil para o treinador organizar o seu ciclo.", "Revisar perfil") { state.onboardingStep = 4; state.persist() }
        groups.forEach { (week, sessions) ->
            TrainingWeekCard(
                week = week, sessions = sessions, expanded = expandedWeek == week,
                onToggle = { expandedWeek = if (expandedWeek == week) -1 else week },
                onSession = { state.selectWorkout(it) },
                events = state.eventsForPlanWeek(week)
            )
        }
        if (state.racePlanNote.isNotBlank()) {
            SectionHeading("Preparação para competição")
            NoteBlock(state.racePlanNote)
            state.racePlanWarnings.forEach { NoteBlock(it) }
        }
        if (state.raceEvents.isEmpty()) {
            CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 6.dp).clickable { state.navigateTo(Screen.RACES) }) {
                Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("Tem uma corrida marcada?", color = Blue2, fontWeight = FontWeight.Bold)
                    Text("Cadastre a prova para o treinador organizar a preparação, o taper e a recuperação.", color = TextMuted, fontSize = 11.sp)
                }
            }
        }
        NoteBlock("Os volumes representam a prescrição. A evolução real só é calculada quando as sessões são concluídas e a distância realizada é registrada.")
    }
}

@Composable private fun TrainingWeekCard(
    week: Int,
    sessions: List<Workout>,
    expanded: Boolean,
    onToggle: () -> Unit,
    onSession: (Workout) -> Unit,
    events: List<RaceEvent> = emptyList()
) {
    val trainingKm = sessions.sumOf { it.distanceKm }
    val raceKm = events.filter { it.status != "CANCELLED" }.sumOf { it.distanceKm }
    val totalKm = trainingKm + raceKm
    val longKm = sessions.filter { it.type == "Longo" }.sumOf { it.distanceKm }
    val qualityKm = sessions.filter { it.type == "Qualidade" }.sumOf { it.distanceKm }
    val easyKm = (trainingKm - longKm - qualityKm).coerceAtLeast(0.0)
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
            Row(Modifier.fillMaxWidth().clickable(onClick = onToggle), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(if (week == 1) "SEMANA 1 · EM ANDAMENTO" else "SEMANA $week", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                    Text(when {
                        events.any { it.status == "PLANNED" } -> "Semana de competição"
                        sessions.firstOrNull()?.phase == "TAPER" -> "Redução pré-prova"
                        sessions.firstOrNull()?.phase == "POST_RACE_RECOVERY" -> "Recuperação pós-prova"
                        else -> phaseLabel(sessions.firstOrNull()?.phase ?: "BASE")
                    }, color = TextWhite, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("~${formatKmUi(totalKm)} km", color = TextWhite, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text(if (events.isEmpty()) "${sessions.size} treinos" else "${sessions.size} treinos + ${events.size} provas", color = TextMuted, fontSize = 10.sp)
                }
                Spacer(Modifier.width(10.dp))
                Text(if (expanded) "⌃" else "⌄", color = Blue2, fontSize = 20.sp)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                if (totalKm > 0.0) {
                    if (easyKm > 0.0) Box(Modifier.weight((easyKm / totalKm).toFloat().coerceAtLeast(0.02f)).height(7.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF7BA9E8)))
                    if (qualityKm > 0.0) Box(Modifier.weight((qualityKm / totalKm).toFloat().coerceAtLeast(0.02f)).height(7.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFFE2B66E)))
                    if (longKm > 0.0) Box(Modifier.weight((longKm / totalKm).toFloat().coerceAtLeast(0.02f)).height(7.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF76CDB1)))
                    if (raceKm > 0.0) Box(Modifier.weight((raceKm / totalKm).toFloat().coerceAtLeast(0.02f)).height(7.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFFB79AF7)))
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Leves ${formatKmUi(easyKm)} km", color = TextMuted, fontSize = 9.sp)
                Text("Qualidade ${formatKmUi(qualityKm)} km", color = TextMuted, fontSize = 9.sp)
                Text("Longão ${formatKmUi(longKm)} km", color = TextMuted, fontSize = 9.sp)
            }
            if (events.isNotEmpty()) {
                Text("Provas ${formatKmUi(raceKm)} km", color = Color(0xFFD2BFFF), fontSize = 9.sp)
            }
            if (expanded) {
                HorizontalDivider(color = Color(0xFF31445A))
                events.sortedBy { it.eventDateIso }.forEach { RaceAgendaRow(it) }
                sessions.forEach { SessionAgendaRow(it) { onSession(it) } }
            } else {
                Text("Toque para expandir as sessões  ›", color = Blue2, fontSize = 10.sp, modifier = Modifier.clickable(onClick = onToggle))
            }
        }
    }
}

@Composable private fun SessionAgendaRow(workout: Workout, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(Color(0xFF142338)).clickable(onClick = onClick).padding(11.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        SessionGlyph(workout, 36)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(workout.title, color = TextWhite, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            Text("${workout.date}  •  ${calendarCategory(workout)}", color = calendarCategoryColor(calendarCategory(workout)), fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text("~${formatKmUi(workout.distanceKm)} km", color = Blue2, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(if (workout.done) "Concluído" else "Planejado", color = if (workout.done) Green else TextMuted, fontSize = 9.sp)
        }
    }
}

@Composable private fun EvolutionScreen(state: CoachState) {
    val completed = state.completedWorkouts()
    val feedbackEntries = state.feedbackRecords.sortedBy { record ->
        record.workoutDateIso.takeIf { it.isNotBlank() }
            ?.let { runCatching { LocalDate.parse(it).toEpochDay() }.getOrNull() }
            ?: record.savedAt / 86_400_000L
    }
    val recorded = feedbackEntries.mapNotNull { record -> record.actualDistanceKm?.let { record to it } }
    val totalDistance = recorded.sumOf { it.second }
    val paceObservations = feedbackEntries.mapNotNull { feedback ->
        val pace = feedback.actualPaceMinKm ?: return@mapNotNull null
        val date = feedback.workoutDateIso.takeIf { it.isNotBlank() }
            ?: runCatching { Instant.ofEpochMilli(feedback.savedAt).atZone(ZoneId.systemDefault()).toLocalDate().toString() }
                .getOrDefault(LocalDate.now().toString())
        PaceObservation(date, feedback.actualDistanceKm ?: 0.0, pace, feedback.workoutType, feedback.effort, feedback.feeling, feedback.painPresent)
    }
    val paceTrend = PerformanceMonitoringEngine.evaluate(paceObservations)
    val weeklyTotals = recorded.groupBy { (record, _) ->
        val date = record.workoutDateIso.takeIf { it.isNotBlank() }
            ?.let { raw -> runCatching { LocalDate.parse(raw) }.getOrNull() }
            ?: runCatching { Instant.ofEpochMilli(record.savedAt).atZone(ZoneId.systemDefault()).toLocalDate() }.getOrDefault(LocalDate.now())
        "S${date.get(java.time.temporal.WeekFields.ISO.weekOfWeekBasedYear())}"
    }.map { (week, items) -> week to items.sumOf { it.second } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Evolução")
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            MetricPod("Sessões concluídas", completed.size.toString(), "✓", Green, Modifier.weight(1f))
            MetricPod("Feedbacks salvos", feedbackEntries.size.toString(), "●", Blue2, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            MetricPod("Distância registrada", "${formatKmUi(totalDistance)} km", "↗", Blue2, Modifier.weight(1f))
            MetricPod("Com distância real", recorded.size.toString(), "◎", Green, Modifier.weight(1f))
        }

        SectionHeading("Monitoramento do pace")
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20344E)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                StatusPill(when (paceTrend.status) { "FASTER" -> "SINAL DE MELHORA"; "SLOWER" -> "ATENÇÃO"; "STABLE" -> "ESTÁVEL"; else -> "DADOS INSUFICIENTES" }, when (paceTrend.status) { "FASTER" -> Green; "SLOWER" -> Yellow; else -> Blue2 })
                Text(paceTrend.headline, color = TextWhite, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(paceTrend.explanation, color = TextMuted, fontSize = 11.sp, lineHeight = 17.sp)
                Text("Sessões comparáveis consideradas: ${paceTrend.comparableSessions}", color = Blue2, fontSize = 10.sp)
            }
        }

        SectionHeading("Zonas e calibração")
        val review = state.cooperReviewStatus()
        CardSurface(Modifier.padding(horizontal = 16.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                InfoRow("Último Cooper", state.cooperAssessments.lastOrNull()?.let { "${formatKmUi(it.distanceKm)} km • ${it.averagePace} min/km" } ?: "Não realizado")
                InfoRow("Revisão", if (review.isDue) "Disponível" else review.nextReviewDate?.format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy")) ?: "Pendente")
                Text("Os feedbacks orientam a recuperação; as zonas oficiais são atualizadas com novo Cooper ou confirmação consistente do teste da fala.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                SecondaryButton("Ver zonas Z1–Z5") { state.navigateTo(Screen.PACE_ZONES) }
                PrimaryButton("Registrar Cooper") { state.navigateTo(Screen.COOPER_TEST) }
            }
        }

        SectionHeading("Registro das sessões")
        Text("${feedbackEntries.size} feedbacks salvos", color = TextMuted, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 20.dp))
        if (feedbackEntries.isEmpty()) {
            EmptyStateCard("Nenhum feedback registrado", "Depois de concluir uma sessão e salvar esforço, sensação e segurança, o registro aparecerá aqui. Distância e tempo podem ser adicionados quando disponíveis.", "Ver treinos") { state.navigateTo(Screen.HISTORY) }
        } else {
            feedbackEntries.asReversed().forEach { FeedbackHistoryDetails(it) }
        }

        SectionHeading("Desempenho medido")
        if (recorded.isEmpty()) {
            NoteBlock("Os feedbacks acima estão salvos. Ainda não há distância real informada; preencha distância e tempo no feedback para alimentar os gráficos de volume e pace. O aplicativo não usa a distância planejada como resultado realizado.")
        } else {
            ChartCard("Quilômetros efetivamente registrados por semana", weeklyTotals)
            CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 7.dp)) {
                Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Resumo das métricas reais", color = Blue2, fontWeight = FontWeight.Bold)
                    InfoRow("Sessões com distância real", recorded.size.toString())
                    InfoRow("Distância total informada", "${formatKmUi(totalDistance)} km")
                    InfoRow("Sessões com pace calculado", paceObservations.size.toString())
                }
            }
        }
        NoteBlock("Esforço, sensação e segurança são mantidos como feedback mesmo sem distância ou tempo. Gráficos, pace real e carga por quilometragem usam exclusivamente métricas informadas pelo atleta.")
    }
}

@Composable private fun ChartCard(title: String, values: List<Pair<String, Double>>) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 7.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
            Text(title, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            if (values.isEmpty()) {
                Text("Sem dados suficientes para montar o gráfico.", color = TextMuted, fontSize = 11.sp)
            } else {
                val maxValue = (values.maxOfOrNull { it.second } ?: 0.0).coerceAtLeast(1.0)
                Row(Modifier.fillMaxWidth().height(132.dp), horizontalArrangement = Arrangement.spacedBy(9.dp), verticalAlignment = Alignment.Bottom) {
                    values.forEach { (label, value) ->
                        Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                            Text(formatKmUi(value), color = Blue2, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(5.dp))
                            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.BottomCenter) {
                                Box(Modifier.fillMaxWidth(0.68f).height((value / maxValue * 82.0).coerceAtLeast(5.0).dp).clip(RoundedCornerShape(topStart = 9.dp, topEnd = 9.dp)).background(Brush.verticalGradient(listOf(Color(0xFF9BB7FF), Color(0xFF5479BC)))))
                            }
                            Spacer(Modifier.height(7.dp))
                            Text(label, color = TextMuted, fontSize = 9.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun FeedbackScreen(state: CoachState) {
    val workout = state.selectedWorkout()
    val existingFeedback = workout?.let { state.feedbackForSession(it.sessionId) }
    var effort by remember(workout?.sessionId) { mutableStateOf(existingFeedback?.effort ?: "Leve") }
    var feeling by remember(workout?.sessionId) { mutableStateOf(existingFeedback?.feeling ?: "Bem") }
    var pain by remember(workout?.sessionId) { mutableStateOf(if (existingFeedback?.painPresent == true) "Sim" else "Não") }
    var notes by remember(workout?.sessionId) { mutableStateOf(existingFeedback?.notes ?: "") }
    var actualDistance by remember(workout?.sessionId) { mutableStateOf(existingFeedback?.actualDistanceKm?.let { formatKmUi(it) } ?: "") }
    var actualDuration by remember(workout?.sessionId) { mutableStateOf(existingFeedback?.actualDuration ?: "") }
    var talkTestPace by remember(workout?.sessionId) { mutableStateOf(existingFeedback?.talkTestPaceMmSs ?: "") }
    val talkTestEligible = workout?.let { TalkTestCalibrationRules.isEligibleWorkout(it.type) } == true
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Feedback da sessão", true) { state.navigateBack(Screen.WORKOUT) }
        if (workout != null) SessionHero(workout)
        else NoteBlock("Selecione uma sessão para registrar o feedback.")
        SectionHeading("Como foi o esforço?")
        FeedbackGroup("Esforço percebido", listOf("Muito leve", "Leve", "Ok", "Pesado", "Muito pesado"), effort) { effort = it }
        SectionHeading("Como você se sentiu?")
        FeedbackGroup("Sensação geral", listOf("Ótimo", "Bem", "Cansado", "Muito cansado"), feeling) { feeling = it }
        SectionHeading("Segurança")
        FeedbackGroup("Sentiu dor durante ou após o treino?", listOf("Não", "Sim"), pain) { pain = it }
        CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Métricas reais da sessão", color = TextWhite, fontWeight = FontWeight.Bold)
                Text("Esforço, sensação e segurança são salvos mesmo sem estes campos. Distância e tempo são opcionais; informe-os para alimentar os gráficos, o pace real e a análise de carga.", color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                OutlinedTextField(actualDistance, { actualDistance = it.filter { ch -> ch.isDigit() || ch == ',' || ch == '.' }.take(7) }, label = { Text("Distância realizada (km)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(actualDuration, { actualDuration = it.filter { ch -> ch.isDigit() || ch == ':' }.take(8) }, label = { Text("Tempo total (mm:ss ou hh:mm:ss)") }, supportingText = { Text("Exemplo: 42:30 ou 01:12:30") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                if (talkTestEligible) {
                    HorizontalDivider(color = Color(0x443F5878))
                    Text("Calibração individual da Z2", color = Blue2, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("Informe o pace do trecho estável em que conseguiu falar frases completas com conforto. Este dado é independente da distância e do tempo totais. Só observações confortáveis e sem dor entram na calibração; são necessários pelo menos dois registros consistentes.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                    OutlinedTextField(talkTestPace, { talkTestPace = it.filter { ch -> ch.isDigit() || ch == ':' }.take(5) }, label = { Text("Pace confortável (mm:ss min/km)") }, supportingText = { Text("Exemplo: 7:20. Registre apenas se a fala ficou confortável.") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    if (talkTestPace.isNotBlank() && PaceRange.parsePace(talkTestPace) == null) Text("Use mm:ss min/km, por exemplo 7:20.", color = Yellow, fontSize = 10.sp)
                }
                val actualKm = actualDistance.trim().replace(",", ".").toDoubleOrNull()
                val elapsed = PaceCalculator.parseDuration(actualDuration)
                if (actualKm != null && elapsed != null) {
                    val pace = PaceCalculator.paceFromDistanceAndDuration(actualKm, elapsed)
                    if (pace != null) Text("Pace realizado: ${PaceRange.format(pace)} min/km", color = Green, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                if (actualDuration.isNotBlank() && elapsed == null) Text("Informe o tempo como mm:ss ou hh:mm:ss.", color = Yellow, fontSize = 10.sp)
                OutlinedTextField(notes, { notes = it }, label = { Text("Observações (opcional)") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
            }
        }
        val talkEntryValid = talkTestPace.isBlank() ||
            TalkTestCalibrationRules.normalizeEntry(workout?.type.orEmpty(), talkTestPace) != null
        PrimaryButton(if (existingFeedback != null) "Atualizar registro da sessão" else "Salvar feedback e registrar sessão", enabled = workout != null && (actualDuration.isBlank() || PaceCalculator.parseDuration(actualDuration) != null) && talkEntryValid) {
            if (state.saveFeedback(effort, feeling, notes, pain == "Sim", actualDistance, actualDuration, talkTestPace)) {
                state.navigateTo(Screen.HISTORY)
            }
        }
        if (state.motorError.isNotBlank()) NoteBlock(state.motorError)
    }
}

@Composable private fun FeedbackGroup(title: String, options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text(title, color = TextMuted, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 20.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            options.forEach { option ->
                val active = option == selected
                Surface(
                    modifier = Modifier.clickable { onSelect(option) },
                    shape = RoundedCornerShape(50),
                    color = if (active) Color(0xFF344B78) else CardBlue,
                    border = if (active) androidx.compose.foundation.BorderStroke(1.dp, Blue2) else null
                ) { Text(option, color = if (active) Color.White else TextMuted, fontSize = 11.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) }
            }
        }
    }
}

@Composable private fun HistoryScreen(state: CoachState) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 22.dp)) {
        Header("Histórico de treinos")
        val completed = state.completedWorkouts().asReversed()
        val archivedFeedback = state.orphanFeedbackRecords().asReversed()
        if (completed.isEmpty() && archivedFeedback.isEmpty()) {
            EmptyStateCard("Nenhuma sessão concluída", "Quando registrar o feedback de uma sessão, ela ficará salva aqui mesmo depois de recalcular um novo plano.", "Voltar ao início") { state.navigateBack(Screen.DASHBOARD) }
        } else {
            SectionHeading("Sessões registradas", "${completed.size + archivedFeedback.size} no total")
            completed.forEach { workout ->
                WorkoutCard(workout) { state.selectWorkout(workout); state.navigateTo(Screen.FEEDBACK) }
                state.feedbackForSession(workout.sessionId)?.let { FeedbackHistoryDetails(it) }
            }
            if (archivedFeedback.isNotEmpty()) {
                SectionHeading("Registros preservados de ciclos anteriores")
                archivedFeedback.forEach { FeedbackHistoryDetails(it) }
            }
        }
    }
}

@Composable private fun FeedbackHistoryDetails(record: FeedbackRecord) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 3.dp), containerColor = Color(0xFF142338)) {
        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(record.workoutTitle.ifBlank { record.workoutType.ifBlank { "Feedback de treino" } }, color = Blue2, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            val dateLabel = record.workoutDateIso.takeIf { it.isNotBlank() }?.let {
                runCatching { LocalDate.parse(it).format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) }.getOrNull()
            } ?: "Data não informada"
            Text("$dateLabel • Esforço: ${record.effort} • Sensação: ${record.feeling}", color = TextMuted, fontSize = 10.sp)
            val distance = record.actualDistanceKm?.let { "${formatKmUi(it)} km reais" } ?: "Distância real não informada"
            val duration = record.actualDuration ?: "Tempo real não informado"
            val pace = record.actualPaceMinKm?.let { " • $it min/km" }.orEmpty()
            Text("$distance • $duration$pace", color = TextWhite, fontSize = 11.sp)
            record.talkTestPaceMmSs?.let { pace ->
                val usable = TalkTestCalibrationRules.canCalibrate(record.effort, record.feeling, record.painPresent)
                Text(
                    "Teste da fala: $pace min/km" + if (usable) " • observação válida para Z2" else " • armazenado, não usado na calibração",
                    color = if (usable) Green else TextMuted,
                    fontSize = 10.sp
                )
            }
            if (record.painPresent) Text("Dor relatada • revisar recuperação antes de nova carga", color = Color(0xFFFFA4A4), fontSize = 10.sp)
            if (record.notes.isNotBlank()) Text(record.notes, color = TextMuted, fontSize = 10.sp)
        }
    }
}

@Composable private fun PaceZonesScreen(state: CoachState) {
    val zones = state.currentPaceZones()
    val review = state.cooperReviewStatus()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Zonas de pace Z1–Z5", true) { state.navigateBack(Screen.PROFILE) }
        if (zones == null) {
            EmptyStateCard("Zonas ainda não calibradas", "Faça o Teste de Cooper de 12 minutos e informe a distância total em km. O treinador calculará as cinco faixas em mm:ss min/km.", "Calibrar pace") { state.navigateTo(Screen.COOPER_TEST) }
        } else {
            CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20344E)) {
                Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("REFERÊNCIA ATUAL", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                    Text(if (zones.z2CalibrationStatus == "TALK_TEST_CONFIRMED") "Z2 refinada pelo teste da fala" else "Faixas iniciais pela velocidade média do Cooper", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    InfoRow("VAM estimada (referência complementar)", "${zones.estimatedMasPace} min/km")
                    InfoRow("Segundo limiar estimado (complementar)", "${zones.estimatedSvt2Pace} min/km")
                    val z2StatusText = when (zones.z2CalibrationStatus) {
                        "TALK_TEST_CONFIRMED" -> "Z2 personalizada • ${zones.talkTestEvidenceCount} sessões consistentes"
                        "TALK_TEST_PENDING" -> "1 registro • falta confirmar em outra sessão aeróbia"
                        "TALK_TEST_INCONSISTENT" -> "Registros de fala divergentes • usando referência Cooper"
                        else -> "Z2 inicial • aguardando registros de fala confortável"
                    }
                    Text(z2StatusText, color = if (zones.z2CalibrationStatus == "TALK_TEST_CONFIRMED") Green else Yellow, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    if (zones.talkTestReferencePace.isNotBlank()) InfoRow("Pace de referência da fala", "${zones.talkTestReferencePace} min/km")
                    val last = state.cooperAssessments.lastOrNull()
                    if (last != null) {
                        InfoRow("Cooper", "${formatKmUi(last.distanceKm)} km em 12 min")
                        InfoRow("Pace médio", "${last.averagePace} min/km")
                        InfoRow("VO₂máx estimado pelo Cooper", String.format(Locale.US, "%.1f", last.estimatedVo2Max))
                    }
                    Text("Z1–Z4 são referências operacionais iniciais baseadas na velocidade média do Cooper e no teste da fala para a fronteira aeróbia. A Z5 usa a VAM estimada apenas como referência complementar quando a regressão é plausível; caso contrário, mantém a banda conservadora do Cooper. Nenhuma dessas faixas confirma VO₂máx ou limiar medido em laboratório.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                    Text("Cada treino usa uma faixa ativa dentro da zona. Nesta escala interna, 100% é o limite de pace mais rápido e 0% o mais lento; não é percentual de VO₂máx. Rodagens e longões usam subfaixas conservadoras diferentes.", color = Blue2, fontSize = 10.sp, lineHeight = 15.sp)
                    Text("A calibração da Z2 exige pelo menos dois registros consistentes do teste da fala. Uma nova avaliação Cooper limita a mudança de cada fronteira a 15 s por revisão, evitando saltos bruscos de pace.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                    Text(review.message, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                    CooperAssessmentEngine.improvementSincePrevious(state.cooperAssessments)?.let { change ->
                        val sign = if (change >= 0.0) "+" else ""
                        Text("Variação desde o Cooper anterior: $sign${String.format(Locale.US, "%.1f", change)}% na distância", color = if (change >= 0.0) Green else Yellow, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            zones.all().forEach { zone ->
                CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(zone.id, color = Blue2, fontSize = 19.sp, fontWeight = FontWeight.Black)
                            Spacer(Modifier.width(10.dp))
                            Text(zone.name, color = TextWhite, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Text(zone.range.label(), color = Green, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Text(zone.purpose, color = TextMuted, fontSize = 11.sp)
                        Text(zone.intensityBand, color = TextMuted, fontSize = 10.sp)
                    }
                }
            }
            NoteBlock("Z1–Z4 são faixas operacionais derivadas da velocidade média do Cooper; Z2 pode ser refinada por dois ou mais registros consistentes de trechos confortáveis, com frases completas, em rodagens fáceis ou longões. Z5 usa a VAM estimada apenas como referência auxiliar quando a regressão é plausível; caso contrário, usa a banda conservadora do Cooper. VO₂máx, VAM e segundo limiar permanecem estimativas de campo, não medições laboratoriais.")
            if (state.workouts.isNotEmpty()) {
                PrimaryButton("Aplicar calibração ao plano") {
                    val updated = state.recalibratePlan()
                    if (!updated && state.motorError.isBlank()) state.motorError = "Não foi possível recalibrar o plano. Confira o perfil e os dados de recuperação."
                }
                if (state.latestCooperMessage.isNotBlank()) NoteBlock(state.latestCooperMessage)
            }
        }
        PrimaryButton("Registrar novo Cooper") { state.navigateTo(Screen.COOPER_TEST) }
    }
}

@Composable private fun CooperTestScreen(state: CoachState) {
    var distanceText by remember(state.cooperDistanceText) { mutableStateOf(state.cooperDistanceText) }
    val distance = distanceText.trim().replace(",", ".").toDoubleOrNull()
    val preview = state.calculateZonesForCooper(distance)
    val review = state.cooperReviewStatus()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Teste de Cooper", true) { state.navigateBack(Screen.PROFILE) }
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20344E)) {
            Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("AVALIAÇÃO AERÓBIA", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                Text("12 minutos contínuos", color = TextWhite, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text("Corra a maior distância sustentável durante 12 minutos, em percurso plano, medido e com condições seguras. O teste deve substituir uma sessão intensa, não ser acrescentado ao volume da semana.", color = TextMuted, fontSize = 12.sp, lineHeight = 18.sp)
                StatusPill(if (review.isDue) "REVISÃO DISPONÍVEL" else "REVISÃO PROGRAMADA", if (review.isDue) Yellow else Green)
                Text(review.message, color = TextMuted, fontSize = 11.sp)
                CooperAssessmentEngine.improvementSincePrevious(state.cooperAssessments)?.let { change ->
                    val sign = if (change >= 0.0) "+" else ""
                    Text("Variação desde o Cooper anterior: $sign${String.format(Locale.US, "%.1f", change)}% na distância", color = if (change >= 0.0) Green else Yellow, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        SectionHeading("Resultado do teste")
        CardSurface(Modifier.padding(horizontal = 16.dp)) {
            Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = distanceText,
                    onValueChange = { value -> distanceText = value.filter { it.isDigit() || it == ',' || it == '.' }.take(6) },
                    label = { Text("Distância percorrida (km)") },
                    supportingText = { Text("Exemplo: 2,40 km. Duração fixa: 12 min.") },
                    modifier = Modifier.fillMaxWidth(), singleLine = true
                )
                if (preview != null) {
                    InfoRow("Pace médio do teste", "${PaceRange.format(preview.averageTestPaceValue)} min/km")
                    InfoRow("VAM estimada (referência complementar)", "${preview.estimatedMasPace} min/km")
                    InfoRow("Segundo limiar estimado (complementar)", "${preview.estimatedSvt2Pace} min/km")
                    InfoRow("VO₂máx estimado pelo Cooper", String.format(Locale.US, "%.1f", preview.estimatedVo2Max))
                    Text("VO₂máx é uma estimativa indireta pelo resultado do Cooper, não uma medição laboratorial. Z1–Z4 são referências operacionais iniciais derivadas da velocidade média do Cooper; a Z2 pode ser refinada com dois registros consistentes do teste da fala. A Z5 pode usar a VAM estimada como referência auxiliar, sem confirmar VO₂máx ou limiar medido. Use percepção de esforço e controle do treino junto às faixas.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                    HorizontalDivider(color = Color(0x443F5878))
                    preview.all().forEach { zone -> InfoRow("${zone.id} • ${zone.name}", zone.range.label()) }
                } else if (distanceText.isNotBlank()) {
                    Text("Informe uma distância válida entre 1,00 e 5,00 km.", color = Yellow, fontSize = 11.sp)
                }
            }
        }
        NoteBlock("Faça um aquecimento progressivo antes do teste. Não teste com dor, doença, tontura, falta de ar incomum ou recuperação insuficiente. Interrompa se surgirem sintomas. O cálculo é uma estimativa de campo, não diagnóstico médico.")
        if (state.latestCooperMessage.isNotBlank()) NoteBlock(state.latestCooperMessage)
        PrimaryButton("Salvar Cooper e atualizar plano", enabled = preview != null) {
            state.cooperDistanceText = distanceText
            val saved = state.saveCooperAndReplan(distanceText)
            if (saved) state.navigateTo(if (state.workouts.isNotEmpty()) Screen.PLAN else Screen.PACE_ZONES)
        }
        SectionHeading("Histórico de avaliações")
        if (state.cooperAssessments.isEmpty()) {
            EmptyStateCard("Nenhum teste registrado", "Quando salvar um Cooper válido, a avaliação ficará disponível aqui para comparação dos próximos ciclos.", "Voltar ao perfil") { state.navigateBack(Screen.PROFILE) }
        } else {
            state.cooperAssessments.asReversed().forEachIndexed { index, record ->
                CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(record.dateIso, color = Blue2, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("${formatKmUi(record.distanceKm)} km em 12 min • ${record.averagePace} min/km", color = TextWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text("VO₂máx estimado pelo Cooper ${String.format(Locale.US, "%.1f", record.estimatedVo2Max)} • não laboratorial", color = TextMuted, fontSize = 10.sp)
                        if (record.estimatedMasPace.isNotBlank()) Text("VAM estimada ${record.estimatedMasPace} min/km", color = TextMuted, fontSize = 10.sp)
                        if (record.estimatedSvt2Pace.isNotBlank()) Text("Segundo limiar ${record.estimatedSvt2Pace} min/km", color = TextMuted, fontSize = 10.sp)
                        Text("Modelo ${record.zoneModelVersion}", color = TextMuted, fontSize = 9.sp)
                        record.zoneRanges.toSortedMap().forEach { (zone, range) ->
                            Text("$zone • $range", color = Blue2, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun TrainingLibraryScreen(state: CoachState) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Biblioteca de treinos", true) { state.navigateBack(Screen.PROFILE) }
        CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), containerColor = Color(0xFF1B3048)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("COMO O TREINADOR USA A BIBLIOTECA", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text("Os estímulos são selecionados conforme objetivo, experiência, carga recente, recuperação e fase do ciclo. Nem todos aparecem no mesmo plano.", color = TextMuted, fontSize = 12.sp, lineHeight = 18.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                    StatusPill("Automático", Green)
                    StatusPill("Condicional", Blue2)
                    StatusPill("Não integrado", Yellow)
                }
            }
        }
        SectionHeading("Treinos da prescrição")
        TrainingTypeCatalog.all.forEach { item ->
            val status = TrainingTypeCatalog.prescriptionStatus(item.id)
            val statusColor = when {
                status.startsWith("Não integrado") -> Yellow
                status.startsWith("Condicional") || status == "Complementar" -> Blue2
                else -> Green
            }
            CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
                Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(item.title, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("Zona de referência: ${item.zone}", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                        }
                        StatusPill(status, statusColor)
                    }
                    Text(item.objective, color = TextWhite, fontSize = 12.sp, lineHeight = 17.sp)
                    Text(TrainingTypeCatalog.prescriptionDetail(item.id), color = statusColor, fontSize = 10.sp, lineHeight = 15.sp)
                    Text("Estrutura", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(item.structure, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                    Text("Quando entra: ${item.use}.", color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                }
            }
        }
        SectionHeading("Fortalecimento complementar")
        NoteBlock("As rotinas de força são sugestões complementares. Nesta versão, elas não são inseridas automaticamente no calendário de corrida.")
        StrengthTrainingCatalog.all.forEach { routine ->
            CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
                Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(routine.title, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        StatusPill(routine.duration, Blue2)
                    }
                    Text(routine.focus, color = Blue2, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Text(routine.exercises, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                    Text(routine.guidance, color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
                }
            }
        }
    }
}

@Composable private fun BackupScreen(state: CoachState) {
    var pendingRestoreUri by remember { mutableStateOf<Uri?>(null) }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) state.exportBackup(uri)
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) pendingRestoreUri = uri
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Backup e restauração", true) { state.navigateBack(Screen.PROFILE) }
        CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp), containerColor = Color(0xFF1B3048)) {
            Column(Modifier.fillMaxWidth().padding(17.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("SEUS DADOS, SOB SEU CONTROLE", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text("Crie um arquivo de backup para guardar fora do celular. Ao trocar de aparelho, importe esse arquivo para recuperar suas informações.", color = TextMuted, fontSize = 12.sp, lineHeight = 18.sp)
            }
        }
        SectionHeading("O que será protegido")
        listOf(
            "Perfil, objetivo, nível e disponibilidade semanal",
            "Plano de treinamento, sessões, blocos e alternativas selecionadas",
            "Histórico de sessões concluídas e feedbacks",
            "Testes de Cooper, calibrações e zonas de pace",
            "Competições, datas, prioridades e observações",
            "Estado e configurações persistidas do treinador"
        ).forEach { item ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 5.dp), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("✓", color = Green, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(item, color = TextWhite, fontSize = 12.sp, lineHeight = 17.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        PrimaryButton("Exportar backup completo") {
            exportLauncher.launch("AI-Running-Coach-backup-${LocalDate.now().format(DateTimeFormatter.ISO_DATE)}.json")
        }
        SecondaryButton("Importar backup de outro aparelho") {
            importLauncher.launch(arrayOf("application/json", "text/json", "application/octet-stream"))
        }
        if (state.backupMessage.isNotBlank()) {
            NoteBlock(state.backupMessage)
        }
        NoteBlock("A restauração substitui os dados atualmente salvos neste aparelho pelos dados do arquivo escolhido. Exporte um backup atual antes de restaurar. O arquivo JSON não é criptografado e contém dados pessoais e esportivos; guarde-o em local seguro.")
    }
    if (pendingRestoreUri != null) {
        AlertDialog(
            onDismissRequest = { pendingRestoreUri = null },
            title = { Text("Restaurar backup?") },
            text = { Text("Os dados atuais do AI Running Coach serão substituídos pelo conteúdo do arquivo selecionado. Recomendamos exportar um backup atual antes de continuar.") },
            confirmButton = {
                TextButton(onClick = {
                    val uri = pendingRestoreUri
                    pendingRestoreUri = null
                    if (uri != null) state.restoreBackup(uri)
                }) { Text("Restaurar") }
            },
            dismissButton = { TextButton(onClick = { pendingRestoreUri = null }) { Text("Cancelar") } }
        )
    }
}

@Composable private fun ProfileScreen(state: CoachState) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Perfil do atleta")
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20344E)) {
            Column(Modifier.padding(19.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Surface(shape = RoundedCornerShape(20.dp), color = Color(0xFF3C527A), modifier = Modifier.size(54.dp)) { Box(contentAlignment = Alignment.Center) { Text(state.name.take(1).uppercase(), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold) } }
                    Column {
                        Text(state.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("${state.level.ifBlank { "Nível não informado" }} • AI Running Coach", color = Color(0xFFD0D9EA), fontSize = 11.sp)
                    }
                }
                HorizontalDivider(color = Color(0x446F8DB8))
                InfoRow("Objetivo", goalLabel(state))
                InfoRow("Disponibilidade", state.availableTrainingDays.joinToString(", ") { dayLabel(it) }.ifBlank { "Não configurada" })
                InfoRow("Volume médio real", if (state.weeklyVolumeText.isBlank()) "Não informado" else "${state.weeklyVolumeText} km/semana")
                InfoRow("Maior sessão recente", if (state.longestRecent.isBlank()) "Não informado" else "${state.longestRecent} km")
                InfoRow("Último Cooper", state.cooperAssessments.lastOrNull()?.let { "${String.format(Locale.US, "%.2f", it.distanceKm)} km • ${it.averagePace} min/km" } ?: "Não realizado")
                InfoRow("Duração do ciclo", "${state.planWeeks} semanas")
            }
        }
        SectionHeading("Gerenciar perfil")
        val availabilitySummary = if (state.availableTrainingDays.isEmpty()) {
            "Definir dias de corrida e preferência do longão"
        } else {
            val longRun = state.preferredLongRunDay?.let { "Longão: ${dayLabel(it)}" } ?: "Longão não definido"
            "${state.availableTrainingDays.size} dias disponíveis • $longRun"
        }
        ProfileAction("Disponibilidade semanal", availabilitySummary, "▦") {
            state.scheduleActionMessage = ""
            state.navigateTo(Screen.AVAILABILITY)
        }
        ProfileAction("Revisar histórico e dados do atleta", "Atualizar volume, maior sessão e objetivo", "✎") { state.onboardingStep = 1; state.persist() }
        ProfileAction("Exportar sessão para Pace Coach", "Compartilhar uma prescrição estruturada", "⇧") { state.navigateTo(Screen.EXPORT) }
        ProfileAction("Teste de Cooper", "Registrar avaliação de 12 minutos e atualizar o plano", "◷") { state.navigateTo(Screen.COOPER_TEST) }
        ProfileAction("Zonas de pace Z1–Z5", "Consultar faixas atuais em mm:ss min/km", "⌁") { state.navigateTo(Screen.PACE_ZONES) }
        ProfileAction("Competições", "Cadastrar provas e ajustar a preparação", "🏁") { state.navigateTo(Screen.RACES) }
        ProfileAction("Biblioteca de treinos", "Consultar os estímulos reconhecidos pelo motor", "▤") { state.navigateTo(Screen.TRAINING_LIBRARY) }
        ProfileAction("Consultar sessões concluídas", "Ver feedback, distância e ritmo registrado", "◷") { state.navigateTo(Screen.HISTORY) }
        ProfileAction("Backup e restauração", "Exportar ou recuperar todos os dados do aplicativo", "⇄") { state.backupMessage = ""; state.navigateTo(Screen.BACKUP) }
        CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("Privacidade e funcionamento", color = Blue2, fontWeight = FontWeight.Bold)
                Text("O perfil, o plano e os feedbacks são armazenados localmente neste dispositivo. O Pace Coach continua responsável pela execução, GPS, áudio e registro das corridas.", color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
            }
        }
    }
}

@Composable private fun AvailabilityScreen(state: CoachState) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Minha disponibilidade semanal", true) { state.navigateBack(Screen.PROFILE) }
        Text(
            "Escolha os dias em que você consegue correr habitualmente. O treinador distribuirá as sessões somente nesses dias e respeitará sua preferência para o longão. As alterações são salvas automaticamente.",
            color = TextMuted,
            fontSize = 12.sp,
            lineHeight = 18.sp,
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 2.dp)
        )
        TrainingAvailabilityEditor(state, showLongRunPreference = true)
        if (state.needsEngineRefresh) {
            NoteBlock("Sua disponibilidade mudou. Recalcule o plano para redistribuir os treinos sem alterar sessões concluídas.")
            PrimaryButton("Recalcular plano com minha disponibilidade") { state.createPlan() }
        }
    }
}

@Composable private fun ProfileAction(title: String, description: String, icon: String, onClick: () -> Unit) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp).clickable(onClick = onClick)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Surface(shape = RoundedCornerShape(13.dp), color = Color(0xFF293E5C), modifier = Modifier.size(40.dp)) { Box(contentAlignment = Alignment.Center) { Text(icon, color = Blue2, fontSize = 18.sp) } }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text(description, color = TextMuted, fontSize = 10.sp)
            }
            Text("›", color = TextMuted, fontSize = 23.sp)
        }
    }
}

@Composable private fun ExportScreen(state: CoachState) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val workout = state.selectedWorkout()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Header("Compartilhar com Pace Coach", true) { state.navigateBack(Screen.WORKOUT) }
        CardSurface(Modifier.padding(horizontal = 16.dp), containerColor = Color(0xFF20344E)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("PRESCRIÇÃO ESTRUTURADA", color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                Text(workout?.title ?: "Nenhuma sessão selecionada", color = TextWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                if (workout != null) Text("${workout.date} • ~${formatKmUi(workout.distanceKm)} km estimados • ${workout.segments.size} blocos", color = TextMuted, fontSize = 11.sp)
                Text("O AI Running Coach planeja. O Pace Coach executa e registra o treino.", color = TextMuted, fontSize = 11.sp)
            }
        }
        SectionHeading("O que será compartilhado")
        val exportName = workout?.let { WorkoutExportNaming.name(it, state.workouts) }
        StepExport("01", "Nome do arquivo", exportName?.let { "$it.json" } ?: "Semana, número do treino, nome e data")
        StepExport("02", "Blocos de treino", workout?.let { "${it.segments.size} blocos • Aquecimento, estímulos, recuperação e desaquecimento" } ?: "Estrutura da sessão")
        StepExport("03", "Alvo de execução", workout?.let {
            val modes = it.segments.map { segment -> segment.targetMode }.distinct()
            val modeLabel = when (modes.size) { 2 -> "Tempo + distância"; 1 -> if (modes.first() == "TIME") "Tempo" else "Distância"; else -> "Sem blocos" }
            "$modeLabel • Pace ${it.primaryPaceRange() ?: "não calibrado"} min/km • RPE ${it.rpeRange} como apoio"
        } ?: "Etapas por tempo ou distância, com pace em min/km quando houver referência")
        NoteBlock("A transferência anexa um arquivo .json no formato nativo UserWorkoutJson do Pace Coach. Etapas são exportadas por tempo (ms) ou distância (m), com pace convertido para a unidade Garmin e repetições preservadas em grupos.")
        PrimaryButton("Compartilhar arquivo JSON", enabled = workout != null) {
            val selected = workout
            if (selected != null) {
                val prescription = selected.toPrescribedWorkout()
                val goalDistanceKm = when {
                    state.goal.startsWith("5") -> 5.0
                    state.goal.startsWith("10") -> 10.0
                    state.goal.startsWith("Meia") -> 21.1
                    state.goal.startsWith("Maratona") -> 42.2
                    state.goal == "Outro objetivo" -> state.customGoalKm.trim().replace(",", ".").toDoubleOrNull()
                    else -> 5.0
                }
                val friendlyName = WorkoutExportNaming.name(selected, state.workouts)
                val json = PaceCoachExporter.workoutToJson(prescription, state.goal, goalDistanceKm, friendlyName)
                val jsonFile = PaceCoachJsonAttachment.create(context.cacheDir, friendlyName, json)
                val contentUri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    jsonFile
                )
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    type = PaceCoachJsonAttachment.MIME_TYPE
                    putExtra(Intent.EXTRA_SUBJECT, "Prescrição — ${selected.title}")
                    putExtra(Intent.EXTRA_STREAM, contentUri)
                    clipData = ClipData.newUri(context.contentResolver, jsonFile.name, contentUri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(sendIntent, "Enviar treino compatível com o Pace Coach"))
            }
        }
    }
}

private fun Workout.primaryPaceRange(): String? {
    val preferred = segments.firstOrNull { it.name.contains("principal", true) || it.name.contains("aeróbio", true) || it.name.contains("longão", true) }
        ?: segments.firstOrNull { it.targetPaceMinValue != null && it.targetPaceMaxValue != null }
    val minPace = preferred?.targetPaceMinValue ?: return null
    val maxPace = preferred.targetPaceMaxValue ?: return null
    return "${PaceRange.format(minPace)}–${PaceRange.format(maxPace)}"
}

private fun Workout.toPrescribedWorkout(): PrescribedWorkout = PrescribedWorkout(
    day = date.substringBefore(","), date = date, scheduledDateIso = scheduledDateIso, title = title, type = type, objective = objective,
    stimulus = stimulus, sessionId = sessionId, distanceKm = distanceKm, durationMin = durationMin,
    intensity = intensity, paceMode = paceMode, rpeRange = rpeRange, detail = detail,
    rationale = rationale, week = week, phase = phase, segments = segments,
    paceCalibrationSnapshot = paceCalibrationSnapshot
)

@Composable private fun BottomNav(state: CoachState) {
    Row(
        Modifier.fillMaxWidth().background(Color(0xFF0D1726)).padding(horizontal = 9.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        DockItem(Modifier.weight(1f), "⌂", "Início", state.selectedScreen == Screen.DASHBOARD) { state.navigateTo(Screen.DASHBOARD) }
        DockItem(Modifier.weight(1f), "▦", "Agenda", state.selectedScreen == Screen.CALENDAR) { state.navigateTo(Screen.CALENDAR) }
        DockItem(Modifier.weight(1f), "≋", "Plano", state.selectedScreen == Screen.PLAN) { state.navigateTo(Screen.PLAN) }
        DockItem(Modifier.weight(1f), "↗", "Evolução", state.selectedScreen == Screen.EVOLUTION) { state.navigateTo(Screen.EVOLUTION) }
        DockItem(Modifier.weight(1f), "•••", "Mais", state.selectedScreen == Screen.PROFILE || state.selectedScreen == Screen.AVAILABILITY || state.selectedScreen == Screen.HISTORY || state.selectedScreen == Screen.RACES) { state.navigateTo(Screen.PROFILE) }
    }
}

@Composable private fun DockItem(modifier: Modifier, icon: String, label: String, selected: Boolean, onClick: () -> Unit) {
    Column(modifier.clickable(onClick = onClick).padding(vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Surface(shape = RoundedCornerShape(15.dp), color = if (selected) Color(0xFF2B4168) else Color.Transparent) {
            Box(Modifier.widthIn(min = 52.dp).height(32.dp).padding(horizontal = 13.dp), contentAlignment = Alignment.Center) {
                Text(icon, color = if (selected) Color.White else TextMuted, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            }
        }
        Text(label, color = if (selected) Blue2 else TextMuted, fontSize = 9.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium)
    }
}

@Composable private fun SectionHeading(title: String, action: String? = null, onAction: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 21.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = TextWhite, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (action != null) Text(
            action, color = Blue2, fontSize = 10.sp, fontWeight = FontWeight.Bold,
            maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = (if (onAction != null) Modifier.clickable(onClick = onAction) else Modifier).widthIn(max = 118.dp)
        )
    }
}

@Composable private fun CardSurface(modifier: Modifier = Modifier, containerColor: Color = CardBlue, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier = modifier, shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = containerColor), content = content)
}

@Composable private fun StatusPill(text: String, color: Color) {
    Surface(shape = RoundedCornerShape(50), color = color.copy(alpha = 0.13f), border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.35f))) {
        Text(text, color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp))
    }
}

@Composable private fun ProgressTrack(progress: Float, color: Color = Blue2, trackColor: Color = Color(0xFF2A3D55)) {
    Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)).background(trackColor)) {
        if (progress > 0f) Box(Modifier.fillMaxWidth(progress.coerceIn(0f, 1f)).fillMaxHeight().clip(RoundedCornerShape(50)).background(color))
    }
}

@Composable private fun SevenDayBreakdown(sessions: List<Workout>, races: List<RaceEvent> = emptyList()) {
    val labels = listOf("SEG", "TER", "QUA", "QUI", "SEX", "SÁB", "DOM")
    val values = MutableList(7) { 0.0 }
    val raceDays = mutableSetOf<Int>()
    sessions.forEach { workout ->
        val dayIndex = runCatching { LocalDate.parse(workout.scheduledDateIso).dayOfWeek.value - 1 }.getOrNull()
        if (dayIndex != null && dayIndex in 0..6) values[dayIndex] = values[dayIndex] + workout.distanceKm
    }
    races.filter { it.status != "CANCELLED" }.forEach { race ->
        val dayIndex = race.dateOrNull()?.dayOfWeek?.value?.minus(1)
        if (dayIndex != null && dayIndex in 0..6) {
            values[dayIndex] = values[dayIndex] + race.distanceKm
            raceDays += dayIndex
        }
    }
    val maxValue = (values.maxOrNull() ?: 0.0).coerceAtLeast(1.0)
    Row(Modifier.fillMaxWidth().height(126.dp), horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.Bottom) {
        values.forEachIndexed { index, value ->
            Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                if (value > 0.0) Text(formatKmUi(value), color = Blue2, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(5.dp))
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.BottomCenter) {
                    Box(Modifier.fillMaxWidth(0.62f).height(if (value > 0.0) (value / maxValue * 76.0).coerceAtLeast(10.0).dp else 4.dp).clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp)).background(
                        if (index in raceDays) Brush.verticalGradient(listOf(Color(0xFFD1B7FF), Color(0xFF8C6FC4)))
                        else if (value > 0.0) Brush.verticalGradient(listOf(Color(0xFFB4C8FF), Color(0xFF5E81C3)))
                        else Brush.verticalGradient(listOf(Color(0xFF34445A), Color(0xFF34445A)))
                    ))
                }
                Spacer(Modifier.height(7.dp))
                Text(labels[index], color = TextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable private fun NextWorkoutCard(workout: Workout, onClick: () -> Unit) {
    CardSurface(Modifier.padding(horizontal = 16.dp).clickable(onClick = onClick), containerColor = Color(0xFF1B3048)) {
        Row(Modifier.fillMaxWidth().padding(17.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(13.dp)) {
            SessionGlyph(workout, 48)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(workout.date.uppercase(), color = Blue2, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text(workout.title, color = TextWhite, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text("~${formatKmUi(workout.distanceKm)} km  •  Tempo estimado: ~${workout.durationMin} min  •  Pace ${workout.primaryPaceRange() ?: "a calibrar"}", color = TextMuted, fontSize = 10.sp)
            }
            Text("›", color = Blue2, fontSize = 27.sp)
        }
    }
}

@Composable private fun SessionGlyph(workout: Workout, size: Int) {
    val category = calendarCategory(workout)
    val done = workout.done
    val color = if (done) Color(0xFF1D4A43) else calendarCategoryColor(category).copy(alpha = 0.25f)
    val glyph = when (category) {
        "REGENERATIVO" -> "☾"
        "AERÓBIO" -> "◉"
        "PROGRESSIVO" -> "↗"
        "QUALIDADE", "LIMIAR" -> "⌁"
        "INTERVALADO" -> "⚡"
        "LONGÃO" -> "➚"
        else -> "•"
    }
    Surface(shape = RoundedCornerShape(16.dp), color = color, modifier = Modifier.size(size.dp)) {
        Box(contentAlignment = Alignment.Center) {
            Text(if (done) "✓" else glyph, color = if (done) Green else calendarCategoryColor(category), fontSize = if (size > 40) 19.sp else 15.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable private fun PlanStat(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, color = Color(0xFFD0D9EA), fontSize = 9.sp)
        Text(value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable private fun EmptyStateCard(title: String, description: String, action: String, onClick: () -> Unit) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
        Column(Modifier.fillMaxWidth().padding(19.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("◌", color = Blue2, fontSize = 26.sp)
            Text(title, color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(description, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
            Text(action + "  ›", color = Blue2, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable(onClick = onClick).padding(top = 3.dp))
        }
    }
}

@Composable private fun NoteBlock(text: String) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), containerColor = Color(0xFF1B2D42)) {
        Row(Modifier.padding(15.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Top) {
            Text("ⓘ", color = Blue2, fontSize = 17.sp)
            Text(text, color = Color(0xFFB9C8DD), fontSize = 11.sp, lineHeight = 17.sp, modifier = Modifier.weight(1f))
        }
    }
}

@Composable private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = TextMuted, fontSize = 11.sp, modifier = Modifier.weight(0.45f))
        Text(value, color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End, modifier = Modifier.weight(0.55f))
    }
}

@Composable private fun ListButton(text: String, onClick: () -> Unit) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 5.dp).clickable(onClick = onClick)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text(text, color = TextWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text("›", color = Blue2, fontSize = 22.sp)
        }
    }
}

@Composable private fun StepExport(n: String, title: String, desc: String) {
    CardSurface(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(n, color = Blue2, fontSize = 24.sp, fontWeight = FontWeight.Black)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(desc, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
            }
        }
    }
}

@Composable private fun SecondaryButton(
    text: String,
    modifier: Modifier = Modifier,
    horizontalPadding: Int = 16,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier.fillMaxWidth().padding(horizontal = horizontalPadding.dp).height(54.dp),
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = Blue2)
    ) {
        Text(text, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable private fun PrimaryButton(
    text: String,
    enabled: Boolean = true,
    modifier: Modifier = Modifier,
    horizontalPadding: Int = 16,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.fillMaxWidth().padding(horizontal = horizontalPadding.dp).height(54.dp),
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Blue, contentColor = Color(0xFF101827))
    ) {
        Text(text, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable private fun LazyColumnLike(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 16.dp), content = content)
}

private fun goalLabel(state: CoachState): String = when {
    state.goal == "Outro objetivo" -> "${state.customGoalKm} km"
    state.goal.isBlank() -> "Objetivo não definido"
    else -> state.goal
}

private fun formatKmUi(value: Double): String = String.format(Locale("pt", "BR"), "%.1f", value).replace(",0", "")
private fun recoveryLabel(status: String?): String = when (status) {
    "GOOD" -> "Boa"
    "MODERATE" -> "Moderada"
    "POOR" -> "Baixa"
    else -> "Não avaliada"
}
private fun safetyLabel(status: String?): String = when (status) {
    "RED" -> "Dor relatada"
    "YELLOW" -> "Atenção à fadiga"
    "GREEN" -> "Sem alerta"
    else -> "Não avaliada"
}
private fun raceStatusLabel(status: String): String = when (status) {
    "COMPLETED" -> "Realizada"
    "CANCELLED" -> "Cancelada"
    else -> "Programada"
}
private fun phaseLabel(phase: String): String = when (phase) {
    "ADAPTATION" -> "Adaptação"
    "CONSOLIDATION" -> "Consolidação"
    "PROGRESSION" -> "Progressão"
    "RECOVERY" -> "Regenerativa"
    "TAPER" -> "Redução pré-prova"
    "POST_RACE_RECOVERY" -> "Recuperação pós-prova"
    else -> "Base aeróbia"
}
private fun workoutTypeLabel(type: String): String = when (type) {
    "Longo" -> "Longão aeróbio"
    "Qualidade" -> "Treino de qualidade"
    "Aeróbio" -> "Rodagem aeróbia"
    "Recuperação" -> "Rodagem regenerativa"
    else -> type
}
private fun stimulusLabel(stimulus: String): String = when (stimulus) {
    "AEROBIC_BASE" -> "Desenvolvimento da base aeróbia"
    "AEROBIC_BASE_AND_CONTROLLED_QUALITY" -> "Base aeróbia com qualidade controlada"
    "LOW_INTENSITY_AEROBIC" -> "Recuperação e baixa intensidade"
    "NONE" -> "Prescrição suspensa por segurança"
    else -> "Desenvolvimento de resistência"
}

