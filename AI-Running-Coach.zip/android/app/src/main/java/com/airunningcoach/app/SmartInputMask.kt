package com.airunningcoach.app

/** Locale-aware input masks shared by onboarding, profile, feedback and race forms. */
internal object SmartInputMask {
    fun date(raw: String): String {
        val digits = raw.filter(Char::isDigit).take(8)
        return when {
            digits.length <= 2 -> digits
            digits.length <= 4 -> digits.substring(0, 2) + "/" + digits.substring(2)
            else -> digits.substring(0, 2) + "/" + digits.substring(2, 4) + "/" + digits.substring(4)
        }
    }

    /** Pace mask: 735 -> 7:35 and 0630 -> 06:30. */
    fun pace(raw: String): String {
        val digits = raw.filter(Char::isDigit).take(4)
        return when {
            digits.length <= 2 -> digits
            digits.length == 3 -> digits.substring(0, 1) + ":" + digits.substring(1)
            digits.startsWith("0") -> digits.substring(1, 2) + ":" + digits.substring(2)
            else -> digits.substring(0, 2) + ":" + digits.substring(2)
        }
    }

    /** Elapsed-time mask: 4230 -> 42:30 and 011230 -> 01:12:30. */
    fun duration(raw: String): String {
        val digits = raw.filter(Char::isDigit).take(6)
        return when {
            digits.length <= 2 -> digits
            digits.length <= 4 -> digits.dropLast(2) + ":" + digits.takeLast(2)
            else -> digits.dropLast(4) + ":" + digits.substring(digits.length - 4, digits.length - 2) + ":" + digits.takeLast(2)
        }
    }

    /** Accepts either decimal separator and presents Brazilian decimal notation. */
    fun distance(raw: String): String {
        val normalized = raw.trim().replace('.', ',')
        val output = StringBuilder()
        var separatorUsed = false
        normalized.forEach { char ->
            when {
                char.isDigit() -> output.append(char)
                char == ',' && !separatorUsed -> {
                    output.append(',')
                    separatorUsed = true
                }
            }
        }
        return output.toString().take(8)
    }

    fun normalizedDecimal(raw: String): Double? = distance(raw).replace(',', '.').toDoubleOrNull()
}
