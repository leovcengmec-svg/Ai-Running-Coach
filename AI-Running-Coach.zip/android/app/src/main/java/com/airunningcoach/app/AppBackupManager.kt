package com.airunningcoach.app

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.time.Instant

internal data class BackupOperationResult(val success: Boolean, val message: String)

/** Versioned, typed backup of the complete local SharedPreferences state. */
internal object AppBackupCodec {
    const val FORMAT = "ai-running-coach-backup"
    const val SCHEMA_VERSION = 1
    private const val APP_ID = "com.airunningcoach.app"
    private const val MAX_BACKUP_BYTES = 25 * 1024 * 1024
    private val transientKeys = setOf("selectedScreen", "selectedWorkoutIndex")
    private val jsonArrayKeys = setOf("racePlanWarnings", "raceEvents", "workouts", "feedbackRecords", "cooperAssessments")
    private val jsonObjectKeys = setOf("motorState", "motorDecision")
    private val expectedTypes = mapOf(
        "frequency" to "int", "onboardingStep" to "int", "planWeeks" to "int", "engineVersion" to "int",
        "cooperEnabled" to "boolean", "needsPacePlanRefresh" to "boolean", "needsEngineRefresh" to "boolean",
        "name" to "string", "goal" to "string", "customGoalKm" to "string", "level" to "string",
        "availableTrainingDays" to "string", "preferredLongRunDay" to "string", "targetDate" to "string",
        "planStartDateIso" to "string", "racePlanNote" to "string", "racePlanWarnings" to "string",
        "raceEvents" to "string", "volume" to "string", "weeklyVolumeText" to "string", "longestRecent" to "string",
        "cooperDistanceText" to "string", "cooperAssessmentDateText" to "string", "latestCooperMessage" to "string",
        "latestFeedbackHeadline" to "string", "latestFeedbackAdvice" to "string", "motorExplanation" to "string",
        "motorError" to "string", "motorState" to "string", "motorDecision" to "string", "workouts" to "string",
        "feedbackRecords" to "string", "cooperAssessments" to "string"
    )

    fun encode(preferences: Map<String, *>, createdAt: String = Instant.now().toString()): String {
        val saved = JSONObject()
        preferences.toSortedMap().forEach { (key, value) ->
            if (key !in transientKeys && value != null) saved.put(key, encodeTypedValue(value))
        }
        return JSONObject().apply {
            put("format", FORMAT)
            put("schemaVersion", SCHEMA_VERSION)
            put("appId", APP_ID)
            put("appVersion", "V48")
            put("createdAt", createdAt)
            put("preferences", saved)
        }.toString(2)
    }

    fun decode(raw: String): Map<String, Any> {
        require(raw.toByteArray(StandardCharsets.UTF_8).size <= MAX_BACKUP_BYTES) { "O arquivo de backup excede o limite permitido." }
        val root = JSONObject(raw)
        require(root.optString("format") == FORMAT) { "Este arquivo não é um backup do AI Running Coach." }
        require(root.optString("appId") == APP_ID) { "O backup pertence a outro aplicativo." }
        val schema = root.optInt("schemaVersion", -1)
        require(schema in 1..SCHEMA_VERSION) { "Versão de backup não suportada: $schema." }
        val saved = root.optJSONObject("preferences") ?: throw IllegalArgumentException("O backup não contém as informações salvas.")
        val restored = linkedMapOf<String, Any>()
        val keys = saved.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            require(key.isNotBlank() && key !in transientKeys) { "O backup contém uma chave de estado inválida." }
            val typed = saved.optJSONObject(key) ?: throw IllegalArgumentException("Registro inválido no backup: $key.")
            val expected = expectedTypes[key]
            if (expected != null) require(typed.optString("type") == expected) { "Tipo incompatível no registro $key." }
            restored[key] = decodeTypedValue(typed)
        }
        // Validate persisted JSON documents before touching the user's current preferences.
        jsonArrayKeys.forEach { key -> (restored[key] as? String)?.let { JSONArray(it) } }
        jsonObjectKeys.forEach { key -> (restored[key] as? String)?.let { JSONObject(it) } }
        return restored
    }

    private fun encodeTypedValue(value: Any): JSONObject = JSONObject().apply {
        when (value) {
            is String -> { put("type", "string"); put("value", value) }
            is Boolean -> { put("type", "boolean"); put("value", value) }
            is Int -> { put("type", "int"); put("value", value) }
            is Long -> { put("type", "long"); put("value", value) }
            is Float -> { put("type", "float"); put("value", value.toDouble()) }
            is Set<*> -> {
                require(value.all { it is String }) { "Conjunto de preferências contém valor incompatível." }
                put("type", "string_set")
                put("value", JSONArray(value.sortedBy { it as String }))
            }
            else -> throw IllegalArgumentException("Tipo de preferência não suportado: ${value::class.java.simpleName}.")
        }
    }

    private fun decodeTypedValue(entry: JSONObject): Any {
        val value = entry.opt("value")
        return when (entry.optString("type")) {
            "string" -> value as? String ?: throw IllegalArgumentException("Texto inválido no backup.")
            "boolean" -> value as? Boolean ?: throw IllegalArgumentException("Booleano inválido no backup.")
            "int" -> (value as? Number)?.toInt() ?: throw IllegalArgumentException("Número inteiro inválido no backup.")
            "long" -> (value as? Number)?.toLong() ?: throw IllegalArgumentException("Número longo inválido no backup.")
            "float" -> (value as? Number)?.toFloat() ?: throw IllegalArgumentException("Número decimal inválido no backup.")
            "string_set" -> {
                val array = value as? JSONArray ?: throw IllegalArgumentException("Lista inválida no backup.")
                buildSet { for (index in 0 until array.length()) add(array.getString(index)) }
            }
            else -> throw IllegalArgumentException("Tipo de dado desconhecido no backup.")
        }
    }
}

internal object AppBackupManager {
    private const val PREFS_NAME = "ai_running_coach"

    fun export(context: Context, uri: Uri): BackupOperationResult = runCatching {
        val preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).all
        val json = AppBackupCodec.encode(preferences)
        val output = context.contentResolver.openOutputStream(uri, "wt")
            ?: throw IllegalStateException("Não foi possível abrir o destino para salvar o backup.")
        output.use { stream -> stream.write(json.toByteArray(StandardCharsets.UTF_8)); stream.flush() }
        BackupOperationResult(true, "Backup completo exportado com sucesso. Guarde o arquivo em local seguro.")
    }.getOrElse { BackupOperationResult(false, "Falha ao exportar backup: ${it.message ?: "erro de gravação"}.") }

    fun restore(context: Context, uri: Uri): BackupOperationResult = runCatching {
        val input = context.contentResolver.openInputStream(uri)
            ?: throw IllegalStateException("Não foi possível abrir o arquivo selecionado.")
        val bytes = input.use { it.readBytes() }
        require(bytes.size <= 25 * 1024 * 1024) { "O arquivo de backup excede o limite permitido." }
        val restored = AppBackupCodec.decode(String(bytes, StandardCharsets.UTF_8))
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val editor = prefs.edit().clear()
        restored.forEach { (key, value) ->
            when (value) {
                is String -> editor.putString(key, value)
                is Boolean -> editor.putBoolean(key, value)
                is Int -> editor.putInt(key, value)
                is Long -> editor.putLong(key, value)
                is Float -> editor.putFloat(key, value)
                is Set<*> -> editor.putStringSet(key, value.filterIsInstance<String>().toMutableSet())
                else -> throw IllegalArgumentException("Tipo inválido ao restaurar $key.")
            }
        }
        check(editor.commit()) { "Não foi possível gravar os dados restaurados no aparelho." }
        BackupOperationResult(true, "Backup restaurado. Perfil, plano, sessões, histórico, avaliações e competições foram recuperados.")
    }.getOrElse { BackupOperationResult(false, "Não foi possível restaurar o backup: ${it.message ?: "arquivo inválido"}.") }
}
