package com.airunningcoach.app

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.time.Instant
import java.security.MessageDigest
import java.util.Locale

internal data class BackupOperationResult(val success: Boolean, val message: String)

/** Versioned, typed backup of the complete local SharedPreferences state. */
internal object AppBackupCodec {
    const val FORMAT = "ai-running-coach-backup"
    const val SCHEMA_VERSION = 5
    private const val APP_ID = "com.airunningcoach.app"
    private const val MAX_BACKUP_BYTES = 25 * 1024 * 1024
    private val transientKeys = setOf("selectedScreen", "selectedWorkoutIndex", "pendingBackupRecalibration", "importedBackupEngineVersion", "selectedRaceId", "fieldTestEntryPending")
    private val jsonArrayKeys = setOf("racePlanWarnings", "raceEvents", "workouts", "feedbackRecords", "cooperAssessments")
    private val jsonObjectKeys = setOf("motorState", "motorDecision", "adaptiveCalibrationState")
    private val expectedTypes = mapOf(
        "frequency" to "int", "onboardingStep" to "int", "planWeeks" to "int", "engineVersion" to "int", "activeWeeksLast4" to "int",
        "cooperEnabled" to "boolean", "needsPacePlanRefresh" to "boolean", "needsEngineRefresh" to "boolean",
        "name" to "string", "goal" to "string", "goalTargetTimeText" to "string", "personalBestTimeText" to "string", "historicalTestAgeText" to "string", "customGoalKm" to "string", "level" to "string", "runningExperienceDuration" to "string",
        "ageYearsText" to "string", "birthDateText" to "string", "referenceSex" to "string", "fitnessTestMethod" to "string", "threeKmTimeText" to "string",
        "availableTrainingDays" to "string", "preferredLongRunDay" to "string", "targetDate" to "string",
        "planStartDateIso" to "string", "racePlanNote" to "string", "racePlanWarnings" to "string",
        "raceEvents" to "string", "volume" to "string", "weeklyVolumeText" to "string", "longestRecent" to "string",
        "cooperDistanceText" to "string", "cooperAssessmentDateText" to "string", "latestCooperMessage" to "string",
        "latestFeedbackHeadline" to "string", "latestFeedbackAdvice" to "string", "motorExplanation" to "string",
        "motorError" to "string", "motorState" to "string", "motorDecision" to "string", "workouts" to "string",
        "feedbackRecords" to "string", "cooperAssessments" to "string", "adaptiveCalibrationState" to "string"
    )

    fun encode(preferences: Map<String, *>, createdAt: String = Instant.now().toString()): String {
        val saved = JSONObject()
        preferences.toSortedMap().forEach { (key, value) ->
            if (key !in transientKeys && value != null) saved.put(key, encodeTypedValue(value))
        }
        val manifest = JSONObject().apply {
            put("payloadSha256", sha256(canonicalPreferences(saved)))
            put("workoutCount", jsonArrayCount(saved, "workouts"))
            put("feedbackCount", jsonArrayCount(saved, "feedbackRecords"))
            put("cooperAssessmentCount", jsonArrayCount(saved, "cooperAssessments"))
            put("raceEventCount", jsonArrayCount(saved, "raceEvents"))
            put("hasPlanAnchor", saved.optJSONObject("planStartDateIso")?.optString("value")?.isNotBlank() == true)
            put("planWeeks", saved.optJSONObject("planWeeks")?.optInt("value", 0) ?: 0)
        }
        return JSONObject().apply {
            put("format", FORMAT)
            put("schemaVersion", SCHEMA_VERSION)
            put("appId", APP_ID)
            put("appVersion", "V90")
            put("createdAt", createdAt)
            put("manifest", manifest)
            put("preferences", saved)
        }.toString(2)
    }

    fun decode(raw: String, requireCompletePlan: Boolean = true): Map<String, Any> {
        require(raw.toByteArray(StandardCharsets.UTF_8).size <= MAX_BACKUP_BYTES) { "O arquivo de backup excede o limite permitido." }
        val root = JSONObject(raw)
        require(root.optString("format") == FORMAT) { "Este arquivo não é um backup do AI Running Coach." }
        require(root.optString("appId") == APP_ID) { "O backup pertence a outro aplicativo." }
        val schema = root.optInt("schemaVersion", -1)
        require(schema in 1..SCHEMA_VERSION) { "Versão de backup não suportada: $schema." }
        val saved = root.optJSONObject("preferences") ?: throw IllegalArgumentException("O backup não contém as informações salvas.")
        if (schema >= 2) validateManifest(root.optJSONObject("manifest"), saved, requireCompletePlan)
        val restored = linkedMapOf<String, Any>()
        val keys = saved.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            require(key.isNotBlank() && key !in transientKeys) { "O backup contém uma chave de estado inválida." }
            val typed = saved.optJSONObject(key) ?: throw IllegalArgumentException("Registro inválido no backup: $key.")
            val expected = expectedTypes[key]
            if (expected != null) require(typed.optString("type") == expected) { "Tipo incompatível no registro $key." }
            restored[key] = decodeTypedValue(typed)
        }
        // Validate persisted JSON documents before touching the user's current preferences.
        jsonArrayKeys.forEach { key -> (restored[key] as? String)?.let { JSONArray(it) } }
        jsonObjectKeys.forEach { key -> (restored[key] as? String)?.let { JSONObject(it) } }
        return restored
    }


    private fun validateManifest(manifest: JSONObject?, saved: JSONObject, requireCompletePlan: Boolean) {
        require(manifest != null) { "O backup não contém o manifesto de integridade." }
        val expectedHash = manifest.optString("payloadSha256")
        require(expectedHash.matches(Regex("[0-9a-f]{64}"))) { "Assinatura de integridade ausente ou inválida." }
        require(expectedHash == sha256(canonicalPreferences(saved))) { "O backup está incompleto ou foi alterado. A restauração foi cancelada para proteger seu plano." }
        listOf(
            "workouts" to "workoutCount",
            "feedbackRecords" to "feedbackCount",
            "cooperAssessments" to "cooperAssessmentCount",
            "raceEvents" to "raceEventCount"
        ).forEach { (preferenceKey, manifestKey) ->
            val expected = manifest.optInt(manifestKey, -1)
            require(expected >= 0 && expected == jsonArrayCount(saved, preferenceKey)) {
                "O backup não contém todos os registros de $preferenceKey. A restauração foi cancelada."
            }
        }
        val workoutCount = jsonArrayCount(saved, "workouts")
        if (requireCompletePlan && workoutCount > 0) {
            require(manifest.optBoolean("hasPlanAnchor", false) && manifest.optInt("planWeeks", 0) in 4..52) {
                "O backup possui sessões, mas não contém o ciclo completo do plano."
            }
        }
    }

    private fun jsonArrayCount(saved: JSONObject, key: String): Int {
        val typed = saved.optJSONObject(key) ?: return 0
        val value = typed.opt("value") as? String ?: return 0
        return runCatching { JSONArray(value).length() }.getOrDefault(-1)
    }

    private fun canonicalPreferences(saved: JSONObject): String = JSONObject().apply {
        saved.keys().asSequence().toList().sorted().forEach { key ->
            val entry = saved.getJSONObject(key)
            put(key, JSONObject().put("type", entry.optString("type")).put("value", entry.opt("value")))
        }
    }.toString()

    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(StandardCharsets.UTF_8))
        .joinToString("") { byte -> "%02x".format(byte) }

    private fun encodeTypedValue(value: Any): JSONObject = JSONObject().apply {
        when (value) {
            is String -> { put("type", "string"); put("value", value) }
            is Boolean -> { put("type", "boolean"); put("value", value) }
            is Int -> { put("type", "int"); put("value", value) }
            is Long -> { put("type", "long"); put("value", value) }
            is Float -> { put("type", "float"); put("value", value.toDouble()) }
            is Set<*> -> {
                require(value.all { it is String }) { "Conjunto de preferências contém valor incompatível." }
                put("type", "string_set")
                put("value", JSONArray(value.sortedBy { it as String }))
            }
            else -> throw IllegalArgumentException("Tipo de preferência não suportado: ${value::class.java.simpleName}.")
        }
    }

    private fun decodeTypedValue(entry: JSONObject): Any {
        val value = entry.opt("value")
        return when (entry.optString("type")) {
            "string" -> value as? String ?: throw IllegalArgumentException("Texto inválido no backup.")
            "boolean" -> value as? Boolean ?: throw IllegalArgumentException("Booleano inválido no backup.")
            "int" -> (value as? Number)?.toInt() ?: throw IllegalArgumentException("Número inteiro inválido no backup.")
            "long" -> (value as? Number)?.toLong() ?: throw IllegalArgumentException("Número longo inválido no backup.")
            "float" -> (value as? Number)?.toFloat() ?: throw IllegalArgumentException("Número decimal inválido no backup.")
            "string_set" -> {
                val array = value as? JSONArray ?: throw IllegalArgumentException("Lista inválida no backup.")
                buildSet { for (index in 0 until array.length()) add(array.getString(index)) }
            }
            else -> throw IllegalArgumentException("Tipo de dado desconhecido no backup.")
        }
    }
}


/**
 * Pure merge for selective history recovery. A relative legacy sessionId is never
 * sufficient to mark a local workout complete: the planned session date must match.
 * If a legacy ID collides with another date, the imported history is remapped to a
 * deterministic LEGACY identity and its feedback follows that identity.
 */
internal object CompletedActivityBackupMerger {
    data class Result(val workoutsJson: String, val feedbackJson: String, val addedWorkouts: Int, val addedFeedback: Int)

    private fun identityDate(item: JSONObject): String =
        item.optString("originalScheduledDateIso").trim().takeIf { it.isNotBlank() }
            ?: item.optString("scheduledDateIso").trim()

    private fun normalizedType(value: String): String = value.trim().uppercase(Locale.ROOT).replace(Regex("\\s+"), " ")

    private fun typesCompatible(first: String, second: String): Boolean =
        first.isBlank() || second.isBlank() || normalizedType(first) == normalizedType(second)

    private fun instanceKey(sessionId: String, date: String, type: String = ""): String =
        "${sessionId.trim()}|${date.trim().ifBlank { "<NO-DATE>" }}|${normalizedType(type)}"

    private fun feedbackIdentityDate(item: JSONObject): String =
        item.optString("workoutOriginalDateIso").trim().takeIf { it.isNotBlank() }
            ?: item.optString("workoutDateIso").trim()

    private fun feedbackKey(item: JSONObject): String {
        val fingerprint = item.optString("activityFingerprint").trim()
        val sessionId = item.optString("sessionId").trim()
        val plannedDate = feedbackIdentityDate(item)
        val plannedType = normalizedType(item.optString("workoutType"))
        val realizedDate = item.optString("realizedDateIso").trim()
        return when {
            fingerprint.isNotEmpty() -> "fp:$fingerprint"
            sessionId.isNotEmpty() && plannedDate.isNotEmpty() -> "session:$sessionId|$plannedDate|$plannedType"
            sessionId.isNotEmpty() && realizedDate.isNotEmpty() -> "session:$sessionId|actual:$realizedDate|$plannedType"
            sessionId.isNotEmpty() -> "session:$sessionId|unknown|$plannedType"
            else -> ""
        }
    }

    private fun hasActivityEvidence(item: JSONObject): Boolean =
        item.optDouble("actualDistanceKm", 0.0) > 0.0 ||
            item.optString("actualDuration").isNotBlank() ||
            item.optString("actualPaceMinKm").isNotBlank() ||
            item.optString("activityFingerprint").isNotBlank() ||
            item.optString("activitySourceFormat").isNotBlank() ||
            item.optString("realizedDateIso").isNotBlank() ||
            item.optString("activityStartedAtIso").isNotBlank()

    fun merge(localWorkoutsJson: String, localFeedbackJson: String, importedWorkoutsJson: String, importedFeedbackJson: String): Result {
        val localWorkouts = JSONArray(localWorkoutsJson.ifBlank { "[]" })
        val importedWorkouts = JSONArray(importedWorkoutsJson.ifBlank { "[]" })
        val localFeedback = JSONArray(localFeedbackJson.ifBlank { "[]" })
        val importedFeedback = JSONArray(importedFeedbackJson.ifBlank { "[]" })

        // Keep local entries as a list rather than associateBy(sessionId): legacy IDs
        // can repeat across different cycles and must not overwrite each other.
        val mergedWorkouts = mutableListOf<JSONObject>()
        for (i in 0 until localWorkouts.length()) {
            localWorkouts.optJSONObject(i)?.let { mergedWorkouts += JSONObject(it.toString()) }
        }
        val localIds = mergedWorkouts.map { it.optString("sessionId").trim() }
            .filter { it.isNotBlank() }.toMutableSet()
        val importedInstanceToResolvedId = linkedMapOf<String, String>()
        val importedResolvedIdsByLegacyId = linkedMapOf<String, MutableSet<String>>()
        val importedIdentityDatesByLegacyId = linkedMapOf<String, MutableSet<String>>()
        val importedTypesByLegacyId = linkedMapOf<String, MutableSet<String>>()
        val importedInstancesByLegacyId = linkedMapOf<String, MutableList<Triple<String, String, String>>>()
        val processedImportedInstances = mutableSetOf<String>()
        var addedWorkouts = 0

        fun allocateLegacyId(oldId: String, date: String, item: JSONObject): String {
            val discriminator = listOf(
                item.optString("type"), item.optString("title"),
                item.optString("stimulus"), item.optString("activityFingerprint")
            ).joinToString("|")
            var candidate = SessionIdentityEngine.remapLegacy(oldId, date, discriminator)
            var suffix = 2
            while (candidate in localIds) {
                candidate = "${SessionIdentityEngine.remapLegacy(oldId, date, discriminator)}-$suffix"
                suffix++
            }
            localIds += candidate
            return candidate
        }

        for (i in 0 until importedWorkouts.length()) {
            val imported = importedWorkouts.optJSONObject(i) ?: continue
            val oldId = imported.optString("sessionId").trim()
            if (oldId.isEmpty() || !imported.optBoolean("done", false)) continue // unfinished/future sessions are never imported
            val date = identityDate(imported)
            val type = imported.optString("type")
            val oldKey = instanceKey(oldId, date, type)
            if (!processedImportedInstances.add(oldKey)) continue

            val exactLocal = if (date.isBlank()) emptyList() else mergedWorkouts.filter { local ->
                local.optString("sessionId").trim() == oldId && identityDate(local) == date &&
                    typesCompatible(local.optString("type"), type)
            }
            val resolvedId = when {
                exactLocal.size == 1 -> {
                    exactLocal.single().put("done", true)
                    oldId
                }
                else -> {
                    val idCollision = oldId in localIds || exactLocal.size > 1
                    if (idCollision) allocateLegacyId(oldId, date, imported) else {
                        localIds += oldId
                        oldId
                    }
                }
            }

            importedInstanceToResolvedId[oldKey] = resolvedId
            importedResolvedIdsByLegacyId.getOrPut(oldId) { linkedSetOf() }.add(resolvedId)
            importedIdentityDatesByLegacyId.getOrPut(oldId) { linkedSetOf() }.add(date)
            importedTypesByLegacyId.getOrPut(oldId) { linkedSetOf() }.add(normalizedType(type))
            importedInstancesByLegacyId.getOrPut(oldId) { mutableListOf() }
                .add(Triple(date, normalizedType(type), resolvedId))
            if (exactLocal.size != 1) {
                mergedWorkouts += JSONObject(imported.toString()).put("sessionId", resolvedId)
                addedWorkouts++
            }
        }

        // Preserve local feedback by activity fingerprint first; without a fingerprint,
        // the planned date is part of the key so the same legacy ID can have two histories.
        val feedbackByKey = linkedMapOf<String, JSONObject>()
        for (i in 0 until localFeedback.length()) {
            val item = localFeedback.optJSONObject(i) ?: continue
            val key = feedbackKey(item)
            if (key.isNotEmpty()) feedbackByKey[key] = JSONObject(item.toString())
        }
        var addedFeedback = 0
        val processedImportedFeedback = mutableSetOf<String>()
        for (i in 0 until importedFeedback.length()) {
            val source = importedFeedback.optJSONObject(i) ?: continue
            val oldId = source.optString("sessionId").trim()
            if (oldId.isEmpty()) continue
            val plannedDate = feedbackIdentityDate(source)
            val plannedType = source.optString("workoutType")
            val oldKey = instanceKey(oldId, plannedDate, plannedType)
            val activityEvidence = hasActivityEvidence(source)
            val importedCandidates = importedInstancesByLegacyId[oldId].orEmpty().filter { (date, type, _) ->
                (plannedDate.isBlank() || date == plannedDate) &&
                    (plannedType.isBlank() || type.isBlank() || type == normalizedType(plannedType))
            }
            val matchedImportedInstance = importedCandidates.singleOrNull()
            val mappedImportedId = importedInstanceToResolvedId[oldKey]
                ?: matchedImportedInstance?.third
            val mapsToImportedWorkout = mappedImportedId != null || importedResolvedIdsByLegacyId[oldId]?.size == 1
            if (!activityEvidence && !mapsToImportedWorkout) continue

            val uniqueImportedId = importedResolvedIdsByLegacyId[oldId]?.singleOrNull()
            val uniqueImportedDate = importedIdentityDatesByLegacyId[oldId]?.singleOrNull()
            val resolvedId = when {
                mappedImportedId != null -> mappedImportedId
                uniqueImportedId != null -> uniqueImportedId
                plannedDate.isNotBlank() -> {
                    val exactLocal = mergedWorkouts.filter { local ->
                        local.optString("sessionId").trim() == oldId && identityDate(local) == plannedDate &&
                            typesCompatible(local.optString("type"), plannedType)
                    }
                    when {
                        exactLocal.size == 1 -> oldId
                        oldId in localIds -> allocateLegacyId(oldId, plannedDate, source)
                        else -> oldId
                    }
                }
                oldId in localIds -> allocateLegacyId(
                    oldId,
                    source.optString("realizedDateIso").ifBlank { source.optString("activityStartedAtIso") },
                    source
                )
                else -> oldId
            }
            val imported = JSONObject(source.toString()).put("sessionId", resolvedId)
            // V78-V81 feedback did not always persist the immutable planned date.
            // When exactly one imported workout with this legacy ID exists, its date
            // safely supplies the missing instance key for that historical record.
            val resolvedImportedDate = matchedImportedInstance?.first ?: uniqueImportedDate
            if (imported.optString("workoutOriginalDateIso").isBlank() && resolvedImportedDate != null &&
                imported.optString("workoutDateIso").isBlank()
            ) {
                imported.put("workoutOriginalDateIso", resolvedImportedDate)
            }
            val resolvedImportedType = matchedImportedInstance?.second?.takeIf { it.isNotBlank() }
                ?: importedTypesByLegacyId[oldId]?.singleOrNull()?.takeIf { it.isNotBlank() }
            if (imported.optString("workoutType").isBlank() && resolvedImportedType != null) {
                imported.put("workoutType", resolvedImportedType)
            }
            val key = feedbackKey(imported)
            val equivalentLegacyFeedbackExists = feedbackByKey.values.any { existing ->
                existing.optString("sessionId").trim() == imported.optString("sessionId").trim() &&
                    feedbackIdentityDate(existing) == feedbackIdentityDate(imported) &&
                    typesCompatible(existing.optString("workoutType"), imported.optString("workoutType"))
            }
            if (key.isNotEmpty() && key !in feedbackByKey && !equivalentLegacyFeedbackExists && processedImportedFeedback.add(key)) {
                feedbackByKey[key] = imported
                addedFeedback++
            }
        }

        // Feedback can complete only the exact scheduled instance (ID + workoutDateIso).
        // RealizedDateIso is the activity date and must not be used as a plan match.
        feedbackByKey.values.forEach { record ->
            val id = record.optString("sessionId").trim()
            val plannedDate = feedbackIdentityDate(record)
            if (id.isEmpty() || plannedDate.isEmpty()) return@forEach
            val feedbackType = record.optString("workoutType")
            val exact = mergedWorkouts.filter { workout ->
                workout.optString("sessionId").trim() == id && identityDate(workout) == plannedDate &&
                    typesCompatible(workout.optString("type"), feedbackType)
            }
            if (exact.size == 1) exact.single().put("done", true)
        }

        val mergedWorkoutsJson = JSONArray().apply { mergedWorkouts.forEach { put(it) } }.toString()
        val mergedFeedbackJson = JSONArray().apply { feedbackByKey.values.forEach { put(it) } }.toString()
        return Result(mergedWorkoutsJson, mergedFeedbackJson, addedWorkouts, addedFeedback)
    }
}

internal object AppBackupManager {
    private const val PREFS_NAME = "ai_running_coach"

    fun export(context: Context, uri: Uri): BackupOperationResult = runCatching {
        val preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).all
        val json = AppBackupCodec.encode(preferences)
        val output = context.contentResolver.openOutputStream(uri, "wt")
            ?: throw IllegalStateException("Não foi possível abrir o destino para salvar o backup.")
        output.use { stream -> stream.write(json.toByteArray(StandardCharsets.UTF_8)); stream.flush() }
        BackupOperationResult(true, "Backup completo exportado com sucesso. Guarde o arquivo em local seguro.")
    }.getOrElse { BackupOperationResult(false, "Falha ao exportar backup: ${it.message ?: "erro de gravação"}.") }

    fun restore(context: Context, uri: Uri): BackupOperationResult = runCatching {
        val input = context.contentResolver.openInputStream(uri)
            ?: throw IllegalStateException("Não foi possível abrir o arquivo selecionado.")
        val bytes = input.use { it.readBytes() }
        require(bytes.size <= 25 * 1024 * 1024) { "O arquivo de backup excede o limite permitido." }
        val restored = AppBackupCodec.decode(String(bytes, StandardCharsets.UTF_8))
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val editor = prefs.edit().clear()
        restored.forEach { (key, value) ->
            when (value) {
                is String -> editor.putString(key, value)
                is Boolean -> editor.putBoolean(key, value)
                is Int -> editor.putInt(key, value)
                is Long -> editor.putLong(key, value)
                is Float -> editor.putFloat(key, value)
                is Set<*> -> editor.putStringSet(key, value.filterIsInstance<String>().toMutableSet())
                else -> throw IllegalArgumentException("Tipo inválido ao restaurar $key.")
            }
        }
        check(editor.commit()) { "Não foi possível gravar os dados restaurados no aparelho." }
        BackupOperationResult(true, "Backup restaurado. Perfil, plano, sessões, histórico, avaliações e competições foram recuperados.")
    }.getOrElse { BackupOperationResult(false, "Não foi possível restaurar o backup: ${it.message ?: "arquivo inválido"}.") }

    fun importCompletedActivities(context: Context, uri: Uri): BackupOperationResult = runCatching {
        val input = context.contentResolver.openInputStream(uri)
            ?: throw IllegalStateException("Não foi possível abrir o arquivo selecionado.")
        val bytes = input.use { it.readBytes() }
        require(bytes.size <= 25 * 1024 * 1024) { "O arquivo de backup excede o limite permitido." }
        val imported = AppBackupCodec.decode(String(bytes, StandardCharsets.UTF_8), requireCompletePlan = false)
        val importedWorkouts = imported["workouts"] as? String ?: "[]"
        val importedFeedback = imported["feedbackRecords"] as? String ?: "[]"
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val merged = CompletedActivityBackupMerger.merge(
            prefs.getString("workouts", "[]") ?: "[]",
            prefs.getString("feedbackRecords", "[]") ?: "[]",
            importedWorkouts,
            importedFeedback
        )
        val editor = prefs.edit()
            .putString("workouts", merged.workoutsJson)
            .putString("feedbackRecords", merged.feedbackJson)
            .putBoolean("needsEngineRefresh", true)
        check(editor.commit()) { "Não foi possível salvar o histórico importado." }
        BackupOperationResult(true, "Histórico mesclado: ${merged.addedWorkouts} treino(s) concluído(s) e ${merged.addedFeedback} registro(s) novo(s). Plano e perfil atuais preservados; duplicados ignorados.")
    }.getOrElse { BackupOperationResult(false, "Não foi possível importar o histórico: ${it.message ?: "arquivo inválido"}.") }
}
