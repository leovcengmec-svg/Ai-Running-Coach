package com.airunningcoach.app

import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import java.time.temporal.TemporalAdjusters
import java.time.DayOfWeek
import java.time.format.DateTimeFormatter
import java.time.format.ResolverStyle
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

/** A running competition is a calendar event, not an ordinary training workout. */
internal data class RaceEvent(
    val id: String,
    val name: String,
    val distanceKm: Double,
    val eventDateIso: String,
    val priority: String = "A", // A = goal race, B = tune-up, C = training event
    val targetTime: String = "",
    val location: String = "",
    val notes: String = "",
    val status: String = "PLANNED" // PLANNED, COMPLETED, CANCELLED
) {
    fun dateOrNull(): LocalDate? = runCatching { LocalDate.parse(eventDateIso) }.getOrNull()
    fun priorityLabel(): String = when (priority) { "A" -> "Prova principal"; "B" -> "Preparatória"; else -> "Treinamento" }
}

internal data class PlanWindow(
    val startDate: LocalDate,
    val weeks: Int,
    val primaryRaceId: String? = null,
    val raceWeek: Int? = null,
    val raceInsideWindow: Boolean = false,
    val note: String = ""
)

internal data class RaceAdjustmentResult(
    val workouts: List<PrescribedWorkout>,
    val replacedSessionIds: List<String>,
    val taperedSessionIds: List<String>,
    val recoverySessionIds: List<String>,
    val warnings: List<String>
)

internal object RaceEventEngine {
    private val dateInput = DateTimeFormatter.ofPattern("dd/MM/uuuu", Locale.forLanguageTag("pt-BR")).withResolverStyle(ResolverStyle.STRICT)

    fun parseBrazilianDate(value: String): LocalDate? = runCatching {
        LocalDate.parse(value.trim(), dateInput)
    }.getOrNull()

    fun formatBrazilianDate(value: String): String = runCatching {
        LocalDate.parse(value).format(dateInput)
    }.getOrDefault(value)

    fun validate(
        name: String,
        distanceKm: Double?,
        dateText: String,
        priority: String,
        targetTime: String
    ): String? {
        if (name.trim().length !in 2..80) return "Informe o nome da competição (2 a 80 caracteres)."
        if (distanceKm == null || !distanceKm.isFinite() || distanceKm !in 1.0..200.0) {
            return "Informe a distância da prova entre 1 e 200 km."
        }
        if (parseBrazilianDate(dateText) == null) return "Informe a data da prova no formato dd/mm/aaaa."
        if (priority !in setOf("A", "B", "C")) return "Selecione a prioridade da competição."
        if (targetTime.isNotBlank() && PaceDuration.parse(targetTime) == null) {
            return "O tempo-alvo deve estar em mm:ss ou hh:mm:ss."
        }
        return null
    }

    fun create(
        id: String,
        name: String,
        distanceKm: Double,
        dateText: String,
        priority: String,
        targetTime: String = "",
        location: String = "",
        notes: String = "",
        status: String = "PLANNED"
    ): RaceEvent? {
        val date = parseBrazilianDate(dateText) ?: return null
        if (validate(name, distanceKm, dateText, priority, targetTime) != null) return null
        return RaceEvent(
            id = id,
            name = name.trim(),
            distanceKm = distanceKm,
            eventDateIso = date.toString(),
            priority = priority,
            targetTime = targetTime.trim(),
            location = location.trim(),
            notes = notes.trim(),
            status = status
        )
    }

    fun resolvePlanWindow(
        today: LocalDate,
        events: List<RaceEvent>,
        defaultWeeks: Int = 8,
        effectiveStartDate: LocalDate? = null
    ): PlanWindow {
        val start = (effectiveStartDate ?: today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)))
            .with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        // Only a priority-A event defines the macrocycle and can trigger taper/recovery.
        // B and C events remain calendar commitments and replace one workout in their week.
        val primary = events.asSequence()
            .filter { it.status == "PLANNED" && it.priority == "A" }
            .mapNotNull { event -> event.dateOrNull()?.let { event to it } }
            .filter { (_, date) -> !date.isBefore(today) && !date.isBefore(start) }
            .sortedBy { it.second }
            .firstOrNull()

        if (primary == null) {
            val hasTuneUp = events.any { it.status == "PLANNED" && it.priority in setOf("B", "C") && it.dateOrNull()?.isBefore(today) == false }
            val note = if (hasTuneUp) {
                "Ciclo geral de ${defaultWeeks.coerceIn(4, 52)} semanas. Provas B/C substituem uma sessão na semana do evento, sem taper nem recuperação automática; somente uma prova A organiza o ciclo principal."
            } else "Ciclo geral sem prova A cadastrada."
            return PlanWindow(start, defaultWeeks.coerceIn(4, 52), note = note)
        }

        val (event, date) = primary
        val eventMonday = date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val raceWeek = (ChronoUnit.DAYS.between(start, eventMonday) / 7L).toInt() + 1
        return when {
            raceWeek in 1..52 -> PlanWindow(
                startDate = start,
                weeks = if (raceWeek < 52) (raceWeek + 1).coerceAtLeast(4) else 52,
                primaryRaceId = event.id,
                raceWeek = raceWeek,
                raceInsideWindow = true,
                note = if (raceWeek < 52) {
                    "Ciclo organizado para a ${event.priorityLabel().lowercase(Locale.ROOT)} em ${formatBrazilianDate(event.eventDateIso)}, incluindo período posterior para recuperação."
                } else {
                    "A prova está na última semana do horizonte de 52 semanas. O período pós-prova deverá ser gerado como bloco de recuperação separado."
                }
            )
            raceWeek > 52 -> PlanWindow(
                startDate = start,
                weeks = 52,
                primaryRaceId = event.id,
                raceWeek = raceWeek,
                raceInsideWindow = false,
                note = "A prova está além do horizonte atual de 52 semanas. O ciclo atual desenvolve a base; reavalie o planejamento quando a competição entrar no horizonte de preparação."
            )
            else -> PlanWindow(
                startDate = start,
                weeks = 4,
                primaryRaceId = event.id,
                raceWeek = raceWeek,
                raceInsideWindow = false,
                note = "A prova está antes da primeira semana treinável deste ciclo. Ela permanece na Agenda, mas não desloca a periodização do plano que começa em ${start}."
            )
        }
    }

    fun applyToPlan(
        workouts: List<PrescribedWorkout>,
        events: List<RaceEvent>,
        planStartDate: LocalDate,
        frequency: Int,
        zones: TrainingPaceZones?,
        today: LocalDate = LocalDate.now(),
        protectedSessionIds: Set<String> = emptySet()
    ): RaceAdjustmentResult {
        if (workouts.isEmpty() || events.isEmpty()) {
            return RaceAdjustmentResult(workouts, emptyList(), emptyList(), emptyList(), emptyList())
        }

        val endExclusive = planStartDate.plusWeeks(((workouts.maxOfOrNull { it.week } ?: 1)).toLong())
        val plannedEvents = events.mapNotNull { event ->
            if (event.status != "PLANNED") return@mapNotNull null
            val date = event.dateOrNull() ?: return@mapNotNull null
            if (date.isBefore(today) || date.isBefore(planStartDate) || !date.isBefore(endExclusive)) return@mapNotNull null
            event to date
        }.sortedBy { it.second }
        if (plannedEvents.isEmpty()) return RaceAdjustmentResult(workouts, emptyList(), emptyList(), emptyList(), emptyList())

        // Tune-up (B) and training (C) events never activate macrocycle taper or post-race recovery.
        val activeGoalRace = plannedEvents
            .filter { it.first.priority == "A" }
            .minByOrNull { it.second }

        fun instanceKey(workout: PrescribedWorkout): String {
            val identityDate = SessionIdentityEngine.identityDate(
                workout.scheduledDateIso, workout.originalScheduledDateIso
            )
            return "${PlanMigrationEngine.sessionInstanceKey(workout.sessionId, identityDate)}|${SessionIdentityEngine.slotKey(identityDate, workout.type)}"
        }
        val tapered = mutableListOf<String>()
        val recovery = mutableListOf<String>()
        val transformed = workouts.map { workout ->
            val date = runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull() ?: return@map workout
            val goalDate = activeGoalRace?.second
            if (goalDate != null) {
                val daysToRace = ChronoUnit.DAYS.between(date, goalDate).toInt()
                val taperDays = taperDurationDays(activeGoalRace.first.distanceKm)
                when {
                    daysToRace in 1..7 -> {
                        tapered += workout.sessionId
                        taperFinalWeek(workout, zones)
                    }
                    daysToRace in 8..taperDays -> {
                        tapered += workout.sessionId
                        val taperFactor = if (daysToRace > 14) 0.88 else 0.80
                        scaleWorkout(workout, taperFactor, "TAPER", "Volume reduzido progressivamente para preservar a recuperação antes da competição.")
                    }
                    daysToRace in -recoveryDurationDays(activeGoalRace.first.distanceKm)..-1 -> {
                        recovery += workout.sessionId
                        recoveryAfterRace(workout, zones)
                    }
                    else -> workout
                }
            } else workout
        }.toMutableList()

        val replaced = mutableListOf<String>()
        val replacedInstances = mutableSetOf<String>()
        val warnings = mutableListOf<String>()
        val eventsByWeek = plannedEvents.groupBy { (_, date) -> weekIndex(date, planStartDate) }
        eventsByWeek.toSortedMap().forEach { (week, weekEvents) ->
            val weekStart = planStartDate.plusWeeks((week - 1).toLong())
            val weekEnd = weekStart.plusDays(6)
            weekEvents.forEach { (event, eventDate) ->
                val candidates = transformed.filter { workout ->
                    val date = runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull()
                    val key = instanceKey(workout)
                    date != null && date in weekStart..weekEnd && key !in replacedInstances &&
                        key !in protectedSessionIds && workout.sessionId !in protectedSessionIds
                }
                val selected = chooseSessionToReplace(candidates, eventDate, event.distanceKm)
                if (selected != null) {
                    val selectedKey = instanceKey(selected)
                    val incompatibleLongRun = transformed.firstOrNull { workout ->
                        val date = runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull()
                        date == eventDate && workout.type.equals("Longo", ignoreCase = true) &&
                            event.distanceKm + 0.1 < workout.distanceKm
                    }
                    val longRunCandidate = incompatibleLongRun
                        ?: selected.takeIf { it.type.equals("Longo", ignoreCase = true) && event.distanceKm + 0.1 < it.distanceKm }
                    val moveLongRunToDisplacedSlot = incompatibleLongRun != null &&
                        !selected.type.equals("Longo", ignoreCase = true) &&
                        runCatching { LocalDate.parse(selected.scheduledDateIso) }.getOrNull() != eventDate
                    if (longRunCandidate != null && selected.type.equals("Longo", ignoreCase = true)) {
                        warnings += "A prova ${event.name} (${event.distanceKm.toOneDecimal()} km) é menor que o longão de ${longRunCandidate.distanceKm.toOneDecimal()} km; o longão foi preservado porque não havia outra sessão segura para substituir. Revise a data da prova ou a agenda."
                    } else if (moveLongRunToDisplacedSlot) {
                        val longRunToMove = requireNotNull(longRunCandidate)
                        val destination = LocalDate.parse(selected.scheduledDateIso)
                        val longKey = instanceKey(longRunToMove)
                        transformed.removeAll { instanceKey(it) == selectedKey || instanceKey(it) == longKey }
                        val movedLongRun = longRunToMove.copy(
                            day = destination.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, Locale.forLanguageTag("pt-BR")),
                            date = "${destination.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, Locale.forLanguageTag("pt-BR")).replaceFirstChar { it.uppercase(Locale.forLanguageTag("pt-BR")) }}, ${destination.format(DateTimeFormatter.ofPattern("dd/MM"))}",
                            scheduledDateIso = destination.toString(),
                            originalScheduledDateIso = longRunToMove.originalScheduledDateIso.ifBlank { longRunToMove.scheduledDateIso },
                            rationale = longRunToMove.rationale + " Longão preservado e deslocado para ${formatBrazilianDate(destination.toString())}; a prova preparatória de ${event.distanceKm.toOneDecimal()} km não substitui esta sessão mais longa."
                        )
                        transformed += movedLongRun
                        warnings += "A prova ${event.name} (${event.distanceKm.toOneDecimal()} km) não substituiu o longão de ${longRunToMove.distanceKm.toOneDecimal()} km; o longão foi transferido para ${formatBrazilianDate(destination.toString())} e a sessão ${selected.title} foi substituída."
                    } else {
                        transformed.removeAll { instanceKey(it) == selectedKey }
                    }
                    replacedInstances += selectedKey
                    replaced += selected.sessionId
                } else {
                    warnings += "A competição ${event.name} não substituiu uma sessão na semana $week porque não havia sessão livre; os treinos manualmente reagendados foram preservados. Revise a agenda para evitar conflito."
                }
            }
            val plannedCommitments = weekEvents.size + transformed.count { workout ->
                val date = runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull()
                date != null && date in weekStart..weekEnd
            }
            if (plannedCommitments > frequency) {
                warnings += "A semana $week tem mais compromissos de corrida (${plannedCommitments}) que a frequência configurada ($frequency)."
            }
            if (weekEvents.size > frequency) {
                warnings += "Há mais competições na semana $week do que dias de corrida configurados. Revise os eventos."
            }
        }

        return RaceAdjustmentResult(
            workouts = transformed.sortedBy { it.scheduledDateIso },
            replacedSessionIds = replaced,
            taperedSessionIds = tapered.distinct(),
            recoverySessionIds = recovery.distinct(),
            warnings = warnings.distinct()
        )
    }

    fun eventsForWeek(events: List<RaceEvent>, planStartDate: LocalDate, week: Int): List<RaceEvent> {
        val start = planStartDate.plusWeeks((week - 1).toLong())
        val end = start.plusDays(6)
        return events.filter { it.status != "CANCELLED" && it.dateOrNull()?.let { date -> date in start..end } == true }
    }

    fun weekIndex(date: LocalDate, planStartDate: LocalDate): Int {
        val monday = date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val startMonday = planStartDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        return (ChronoUnit.DAYS.between(startMonday, monday) / 7L).toInt() + 1
    }

    private fun chooseSessionToReplace(
        candidates: List<PrescribedWorkout>,
        eventDate: LocalDate,
        eventDistanceKm: Double
    ): PrescribedWorkout? {
        if (candidates.isEmpty()) return null
        return candidates.minWithOrNull(compareBy<PrescribedWorkout> { workout ->
            val date = runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull()
            val incompatibleLongRun = workout.type.equals("Longo", ignoreCase = true) &&
                eventDistanceKm + 0.1 < workout.distanceKm
            when {
                date == eventDate && !incompatibleLongRun -> 0 // Compatible race or same-day non-long session.
                workout.type.equals("Qualidade", ignoreCase = true) -> 1
                workout.type.equals("Longo", ignoreCase = true) -> 3 // A shorter race cannot replace the long run.
                date == eventDate -> 4
                else -> 2
            }
        }.thenBy { workout ->
            val date = runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull()
            if (date == null) Int.MAX_VALUE else kotlin.math.abs(ChronoUnit.DAYS.between(date, eventDate).toInt())
        })
    }

    private fun Double.toOneDecimal(): String = String.format(Locale.US, "%.1f", this)

    private fun allocateTenths(totalKm: Double, weights: List<Double>): List<Double> {
        require(weights.isNotEmpty() && weights.all { it > 0.0 })
        val totalTenths = (kotlin.math.round(totalKm * 10.0)).toInt().coerceAtLeast(weights.size)
        val weightSum = weights.sum()
        var remaining = totalTenths
        return weights.mapIndexed { index, weight ->
            val slotsAfter = weights.size - index - 1
            val amount = if (slotsAfter == 0) remaining else {
                (totalTenths * weight / weightSum).roundToInt().coerceIn(1, (remaining - slotsAfter).coerceAtLeast(1))
            }
            remaining -= amount
            amount / 10.0
        }
    }

    private fun taperFinalWeek(workout: PrescribedWorkout, zones: TrainingPaceZones?): PrescribedWorkout {
        val reducedDuration = (workout.durationMin * 0.62).roundToInt().coerceAtLeast(12)
        val z1 = zones?.z1?.range
        val z1Active = z1?.let { ZoneIntensityBandEngine.activeRange(it, ZoneIntensityBandEngine.z1WarmupCoolDownBand) }
        val averageZ1Pace = z1Active?.let { (it.fastestPaceValue + it.slowestPaceValue) / 2.0 }
        val reducedDistance = (averageZ1Pace?.let { reducedDuration * 60.0 / it } ?: workout.distanceKm * 0.58).coerceAtLeast(1.0)
        val convertedQuality = workout.type == "Qualidade" || workout.type == "Longo"
        val segments = if (convertedQuality) {
            val doses = allocateTenths(reducedDistance, listOf(0.25, 0.50, 0.25))
            listOf(
                WorkoutSegment("Aquecimento leve", "Comece confortável, sem acumular fadiga.", durationMin = 8, distanceKm = doses[0], intensity = "LOW", rpeRange = "2-3", targetMode = "TIME", targetPaceMinValue = z1Active?.fastestPaceValue, targetPaceMaxValue = z1Active?.slowestPaceValue, paceZone = z1?.let { "Z1" }, zoneBasePaceFastValue = z1?.fastestPaceValue, zoneBasePaceSlowValue = z1?.slowestPaceValue, zoneIntensityMinPercent = 80, zoneIntensityMaxPercent = 100),
                WorkoutSegment("Corrida fácil", "Mantenha corrida fácil e confortável. Não faça estímulos fortes nesta sessão.", durationMin = 10, distanceKm = doses[1], intensity = "LOW", rpeRange = "2-3", targetMode = "TIME", targetPaceMinValue = z1Active?.fastestPaceValue, targetPaceMaxValue = z1Active?.slowestPaceValue, paceZone = z1?.let { "Z1" }, zoneBasePaceFastValue = z1?.fastestPaceValue, zoneBasePaceSlowValue = z1?.slowestPaceValue, zoneIntensityMinPercent = 80, zoneIntensityMaxPercent = 100),
                WorkoutSegment("Desaquecimento", "Encerre com sensação de facilidade.", durationMin = 5, distanceKm = doses[2], intensity = "LOW", rpeRange = "1-2", targetMode = "TIME", targetPaceMinValue = z1Active?.fastestPaceValue, targetPaceMaxValue = z1Active?.slowestPaceValue, paceZone = z1?.let { "Z1" }, zoneBasePaceFastValue = z1?.fastestPaceValue, zoneBasePaceSlowValue = z1?.slowestPaceValue, zoneIntensityMinPercent = 80, zoneIntensityMaxPercent = 100)
            )
        } else TrainingPrescriptionAudit.reconcileSegments(
            workout.segments.map { segment -> scaleSegment(segment, 0.62, null) }, reducedDistance
        )
        val estimatedDuration = WorkoutDurationEstimator.estimateMinutes(segments, reducedDistance, reducedDuration)
        return workout.copy(
            title = if (convertedQuality) "Ativação leve pré-prova" else workout.title,
            type = if (convertedQuality) "Recuperação" else workout.type,
            objective = if (convertedQuality) "Chegar descansado à competição." else workout.objective,
            stimulus = "RACE_TAPER_ACTIVATION",
            distanceKm = reducedDistance,
            durationMin = estimatedDuration,
            intensity = "LOW",
            rpeRange = "2-3",
            phase = "TAPER",
            segments = segments,
            rationale = "Semana da competição: volume reduzido e estímulos fortes retirados. A prova substitui uma sessão normal."
        )
    }

    private fun recoveryAfterRace(workout: PrescribedWorkout, zones: TrainingPaceZones?): PrescribedWorkout {
        val distance = (workout.distanceKm * 0.50).coerceAtLeast(1.0)
        val z1 = zones?.z1?.range
        val z1Active = z1?.let { ZoneIntensityBandEngine.activeRange(it, ZoneIntensityBandEngine.z1WarmupCoolDownBand) }
        val fallbackDuration = max(12, (workout.durationMin * 0.5).roundToInt())
        val segments = if (workout.segments.isEmpty()) emptyList() else listOf(
            WorkoutSegment("Corrida regenerativa", "Somente se estiver sem dor e com recuperação adequada. Caso contrário, descanse.", durationMin = fallbackDuration, distanceKm = distance, intensity = "LOW", rpeRange = "1-2", targetMode = "TIME", targetPaceMinValue = z1Active?.fastestPaceValue, targetPaceMaxValue = z1Active?.slowestPaceValue, paceZone = z1?.let { "Z1" }, zoneBasePaceFastValue = z1?.fastestPaceValue, zoneBasePaceSlowValue = z1?.slowestPaceValue, zoneIntensityMinPercent = 80, zoneIntensityMaxPercent = 100)
        )
        val estimatedDuration = WorkoutDurationEstimator.estimateMinutes(segments, distance, fallbackDuration)
        return workout.copy(
            title = "Recuperação pós-prova",
            type = "Recuperação",
            objective = "Recuperar-se da competição antes de retomar a progressão.",
            stimulus = "POST_RACE_RECOVERY",
            distanceKm = distance,
            durationMin = estimatedDuration,
            intensity = "LOW",
            rpeRange = "1-2",
            phase = "POST_RACE_RECOVERY",
            segments = segments,
            rationale = "Semana posterior à competição. Redução de carga; faça a sessão somente se a recuperação permitir e não houver dor."
        )
    }

    private fun scaleWorkout(workout: PrescribedWorkout, factor: Double, phase: String, rationale: String): PrescribedWorkout {
        val scaledDistance = (workout.distanceKm * factor).coerceAtLeast(1.0)
        val scaledSegments = TrainingPrescriptionAudit.reconcileSegments(
            workout.segments.map { scaleSegment(it, factor, null) }, scaledDistance
        )
        val reconciledDistance = if (scaledSegments.any { it.distanceKm != null }) TrainingPrescriptionAudit.estimatedSegmentDistanceKm(scaledSegments) else scaledDistance
        val fallbackDuration = (workout.durationMin * factor).roundToInt().coerceAtLeast(12)
        val estimatedDuration = WorkoutDurationEstimator.estimateMinutes(scaledSegments, reconciledDistance, fallbackDuration)
        return workout.copy(
            distanceKm = reconciledDistance,
            durationMin = estimatedDuration,
            phase = phase,
            segments = scaledSegments,
            rationale = rationale
        )
    }

    private fun scaleSegment(segment: WorkoutSegment, factor: Double, replacementPace: PaceRange?): WorkoutSegment = segment.copy(
        durationMin = if (segment.durationSeconds == null) segment.durationMin?.let { (it * factor).roundToInt().coerceAtLeast(1) } else null,
        durationSeconds = segment.durationSeconds?.let { (it * factor).roundToInt().coerceAtLeast(1) },
        distanceKm = segment.distanceKm?.let { (it * factor * 10.0).roundToInt() / 10.0 },
        targetPaceMinValue = replacementPace?.fastestPaceValue ?: segment.targetPaceMinValue,
        targetPaceMaxValue = replacementPace?.slowestPaceValue ?: segment.targetPaceMaxValue,
        paceZone = if (replacementPace != null) "Z1" else segment.paceZone,
        zoneBasePaceFastValue = if (replacementPace != null) replacementPace.fastestPaceValue else segment.zoneBasePaceFastValue,
        zoneBasePaceSlowValue = if (replacementPace != null) replacementPace.slowestPaceValue else segment.zoneBasePaceSlowValue,
        zoneIntensityMinPercent = if (replacementPace != null) null else segment.zoneIntensityMinPercent,
        zoneIntensityMaxPercent = if (replacementPace != null) null else segment.zoneIntensityMaxPercent,
        intensity = if (replacementPace != null) "LOW" else segment.intensity,
        rpeRange = if (replacementPace != null) "1-2" else segment.rpeRange
    )

    private fun taperDurationDays(distanceKm: Double): Int = when {
        distanceKm >= 42.0 -> 21
        distanceKm >= 21.0 -> 14
        distanceKm >= 10.0 -> 10
        else -> 7
    }

    private fun recoveryDurationDays(distanceKm: Double): Int = when {
        distanceKm >= 42.0 -> 21
        distanceKm >= 21.0 -> 14
        distanceKm >= 10.0 -> 7
        else -> 5
    }

    private fun priorityRank(priority: String): Int = when (priority) { "A" -> 0; "B" -> 1; else -> 2 }
}

/** Parses elapsed time for event targets; pace display remains mm:ss min/km elsewhere. */
internal object PaceDuration {
    fun parse(value: String): Int? {
        val raw = value.trim()
        val parts = raw.split(":")
        return when (parts.size) {
            2 -> {
                val m = parts[0].toIntOrNull() ?: return null
                val s = parts[1].toIntOrNull() ?: return null
                if (m < 0 || s !in 0..59) null else m * 60 + s
            }
            3 -> {
                val h = parts[0].toIntOrNull() ?: return null
                val m = parts[1].toIntOrNull() ?: return null
                val s = parts[2].toIntOrNull() ?: return null
                if (h < 0 || m !in 0..59 || s !in 0..59) null else h * 3600 + m * 60 + s
            }
            else -> null
        }?.takeIf { it > 0 && it <= 36_000 }
    }
}
