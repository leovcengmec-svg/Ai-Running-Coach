package com.airunningcoach.app

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters

/** Validation of the immutable, athlete-confirmed four-week load snapshot. */
internal object MeasuredLoadAdoptionPolicy {
    fun hasConfirmedSnapshot(
        confirmedThroughIso: String,
        weeklyKmText: String,
        longestKmText: String
    ): Boolean {
        val confirmedThrough = runCatching { LocalDate.parse(confirmedThroughIso) }.getOrNull() ?: return false
        val weeklyKm = weeklyKmText.replace(',', '.').toDoubleOrNull() ?: return false
        val longestKm = longestKmText.replace(',', '.').toDoubleOrNull() ?: return false
        return confirmedThrough.dayOfWeek == DayOfWeek.SUNDAY &&
            weeklyKm.isFinite() && weeklyKm > 0.0 && weeklyKm <= 300.0 &&
            longestKm.isFinite() && longestKm > 0.0 && longestKm <= 100.0
    }

    fun nextBlockMonday(today: LocalDate): LocalDate =
        today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)).plusWeeks(1)
}
