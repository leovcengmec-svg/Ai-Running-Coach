package com.airunningcoach.app

import java.time.LocalDate
import kotlin.math.abs
import kotlin.math.roundToInt

internal data class PaceObservation(
    val dateIso: String,
    val distanceKm: Double,
    val paceMmSs: String,
    val sessionType: String,
    val effort: String,
    val feeling: String,
    val painPresent: Boolean,
    val terrain: String = RunningTerrain.MIXED,
    val elevationGainMeters: Double? = null,
    /** Allows recovery of a missing pace when both elapsed time and measured distance exist. */
    val durationSeconds: Int? = null
)

internal data class PerformanceTrend(
    val status: String,
    val headline: String,
    val explanation: String,
    val comparableSessions: Int,
    val changePercent: Double? = null,
    val exclusionCounts: Map<String, Int> = emptyMap(),
    val evaluatedRecords: Int = 0
) {
    fun exclusionSummary(): String {
        val labels = mapOf(
            "OUTSIDE_WINDOW" to "fora de 28 dias",
            "MISSING_PACE" to "sem pace/tempo calculável",
            "SHORT_DISTANCE" to "distância ausente, inválida ou abaixo de 2 km",
            "NON_COMPARABLE_TYPE" to "tipo de sessão não comparável",
            "HIGH_EFFORT" to "esforço alto",
            "FATIGUE_OR_PAIN" to "fadiga, cansaço ou dor"
        )
        val parts = exclusionCounts.filterValues { it > 0 }.map { (key, count) ->
            "${labels[key] ?: key}: $count"
        }
        return if (parts.isEmpty()) "Nenhum registro foi excluído pelos filtros principais." else "Exclusões: ${parts.joinToString(" • ")}."
    }
}

/**
 * Compares only recent easy sessions with measured distance and defensible pace data.
 * It explains exclusions and can derive min/km from elapsed time/distance when the
 * explicit pace field is absent. This monitor never changes a zone by itself.
 */
internal object PerformanceMonitoringEngine {
    private const val REVIEW_DAYS = 28L
    private const val MIN_COMPARABLE_SESSIONS = 4
    private val easyTypes = setOf("aeróbio", "recuperação", "longo", "longão", "rodagem", "regenerativo")

    fun evaluate(observations: List<PaceObservation>, today: LocalDate = LocalDate.now()): PerformanceTrend {
        val exclusions = mutableMapOf<String, Int>()
        fun exclude(reason: String) { exclusions[reason] = (exclusions[reason] ?: 0) + 1 }
        val comparable = observations.mapNotNull { item ->
            val date = runCatching { LocalDate.parse(item.dateIso) }.getOrNull()
            if (date == null || date.isBefore(today.minusDays(REVIEW_DAYS - 1)) || date.isAfter(today)) {
                exclude("OUTSIDE_WINDOW")
                return@mapNotNull null
            }
            val distanceValid = item.distanceKm.isFinite() && item.distanceKm >= 2.0 && item.distanceKm <= 200.0
            if (!distanceValid) {
                exclude("SHORT_DISTANCE")
                return@mapNotNull null
            }
            val pace = PaceRange.parsePace(item.paceMmSs) ?: run {
                val duration = item.durationSeconds?.takeIf { it in 1..172_800 }
                if (duration != null) PaceCalculator.paceFromDistanceAndDuration(item.distanceKm, duration) else null
            }
            if (pace == null) {
                exclude("MISSING_PACE")
                return@mapNotNull null
            }
            if (item.sessionType.trim().lowercase(java.util.Locale.ROOT) !in easyTypes) {
                exclude("NON_COMPARABLE_TYPE")
                return@mapNotNull null
            }
            if (item.effort in setOf("Pesado", "Muito pesado")) {
                exclude("HIGH_EFFORT")
                return@mapNotNull null
            }
            if (item.feeling in setOf("Cansado", "Muito cansado") || item.painPresent) {
                exclude("FATIGUE_OR_PAIN")
                return@mapNotNull null
            }
            val terrain = RunningTerrain.normalize(item.terrain)
            val elevationPerKm = item.elevationGainMeters?.takeIf { it.isFinite() && it >= 0.0 && item.distanceKm > 0.0 }
                ?.div(item.distanceKm)
            ComparablePace(date, item.sessionType, terrain, pace, elevationPerKm)
        }.sortedBy { it.date }

        if (comparable.size < MIN_COMPARABLE_SESSIONS) {
            return PerformanceTrend(
                status = "INSUFFICIENT",
                headline = "Ainda não há sessões comparáveis suficientes",
                explanation = "São necessárias pelo menos quatro rodagens fáceis, com distância e pace medidos, dentro dos últimos 28 dias. Quando o pace estiver ausente, o aplicativo calcula min/km usando tempo total e distância. A mudança de zonas depende de revisão confirmada e de novo Cooper ou teste de 3 km válido. ${exclusionExplanation(exclusions)} Os dados monitoram tendências, mas não alteram zonas automaticamente.",
                comparableSessions = comparable.size,
                exclusionCounts = exclusions.toMap(),
                evaluatedRecords = observations.size
            )
        }

        val mostCommonKey = comparable.groupingBy { it.sessionType.trim().lowercase(java.util.Locale.ROOT) to it.terrain }
            .eachCount().maxByOrNull { it.value }?.key
        var selected = comparable.filter { (it.sessionType.trim().lowercase(java.util.Locale.ROOT) to it.terrain) == mostCommonKey }
        val elevationValues = selected.mapNotNull { it.elevationPerKm }
        if (elevationValues.size >= MIN_COMPARABLE_SESSIONS) {
            val referenceElevation = medianDouble(elevationValues)
            val elevationComparable = selected.filter { row ->
                row.elevationPerKm == null || kotlin.math.abs(row.elevationPerKm - referenceElevation) <= 12.0
            }
            if (elevationComparable.size >= MIN_COMPARABLE_SESSIONS) selected = elevationComparable
        }
        val sameType = selected.map { it.pace }
        if (sameType.size < MIN_COMPARABLE_SESSIONS) {
            return PerformanceTrend(
                "INSUFFICIENT", "Ainda não há sessões comparáveis suficientes",
                "Amostras válidas existem, mas não há quatro sessões do mesmo tipo e terreno em quantidade suficiente. Não misture longões com rodagens curtas para inferir evolução. ${exclusionExplanation(exclusions)}",
                sameType.size, exclusionCounts = exclusions.toMap(), evaluatedRecords = observations.size
            )
        }

        val split = (sameType.size / 2).coerceAtLeast(2)
        val early = median(sameType.take(split))
        val recent = median(sameType.takeLast(split))
        val change = ((early - recent) / early) * 100.0
        val rounded = (change * 10.0).roundToInt() / 10.0
        val excludedText = exclusionExplanation(exclusions)
        return when {
            change >= 2.0 -> PerformanceTrend(
                "FASTER", "Sinal de melhora nas rodagens comparáveis",
                "O ritmo recente está cerca de ${String.format(java.util.Locale.US, "%.1f", rounded)}% mais rápido. É um sinal para revisar a evolução, não uma autorização automática para acelerar zonas. ${excludedText}",
                sameType.size, rounded, exclusions.toMap(), observations.size
            )
            change <= -2.0 -> PerformanceTrend(
                "SLOWER", "Ritmos recentes ficaram mais lentos",
                "O ritmo recente está cerca de ${String.format(java.util.Locale.US, "%.1f", abs(rounded))}% mais lento. Verifique fadiga, clima, terreno e recuperação; não altere zonas com base em um período isolado. ${excludedText}",
                sameType.size, rounded, exclusions.toMap(), observations.size
            )
            else -> PerformanceTrend(
                "STABLE", "Ritmo estável nas rodagens comparáveis",
                "A variação recente está dentro da faixa de estabilidade adotada pelo aplicativo. Mantenha as zonas até a próxima revisão. ${excludedText}",
                sameType.size, rounded, exclusions.toMap(), observations.size
            )
        }
    }

    private fun exclusionExplanation(exclusions: Map<String, Int>): String {
        val labels = mapOf(
            "OUTSIDE_WINDOW" to "fora da janela de 28 dias",
            "MISSING_PACE" to "sem pace ou dados para calculá-lo",
            "SHORT_DISTANCE" to "distância ausente, inválida ou menor que 2 km",
            "NON_COMPARABLE_TYPE" to "sessão de intensidade não comparável",
            "HIGH_EFFORT" to "esforço alto",
            "FATIGUE_OR_PAIN" to "fadiga/cansaço ou dor"
        )
        val details = exclusions.filterValues { it > 0 }.map { (key, count) -> "${labels[key] ?: key}: $count" }
        return if (details.isEmpty()) "Nenhum registro foi excluído pelos filtros principais." else "Registros excluídos: ${details.joinToString("; ")}."
    }

    private data class ComparablePace(
        val date: LocalDate,
        val sessionType: String,
        val terrain: String,
        val pace: Int,
        val elevationPerKm: Double?
    )

    private fun medianDouble(values: List<Double>): Double {
        val sorted = values.sorted()
        val middle = sorted.size / 2
        return if (sorted.size % 2 == 0) (sorted[middle - 1] + sorted[middle]) / 2.0 else sorted[middle]
    }

    private fun median(values: List<Int>): Double {
        val sorted = values.sorted()
        val middle = sorted.size / 2
        return if (sorted.size % 2 == 0) (sorted[middle - 1] + sorted[middle]) / 2.0 else sorted[middle].toDouble()
    }
}
