package com.airunningcoach.app

import java.time.LocalDate
import kotlin.math.abs
import kotlin.math.roundToInt

internal data class PaceObservation(
    val dateIso: String,
    val distanceKm: Double,
    val paceMmSs: String,
    val sessionType: String,
    val effort: String,
    val feeling: String,
    val painPresent: Boolean,
    val terrain: String = RunningTerrain.MIXED,
    val elevationGainMeters: Double? = null,
    /** Allows recovery of a missing pace when both elapsed time and measured distance exist. */
    val durationSeconds: Int? = null
)

internal data class PerformanceTrend(
    val status: String,
    val headline: String,
    val explanation: String,
    val comparableSessions: Int,
    val changePercent: Double? = null,
    val exclusionCounts: Map<String, Int> = emptyMap(),
    val evaluatedRecords: Int = 0,
    /** Descriptive only while fewer than four comparable sessions are available. */
    val preliminaryMedianPaceSecondsPerKm: Int? = null,
    val preliminarySessionType: String? = null,
    val preliminaryTerrain: String? = null,
    val preliminarySessionDates: List<String> = emptyList(),
    val periodStartDateIso: String? = null,
    val periodEndDateIso: String? = null,
    val requiredComparableSessions: Int = 4
) {
    fun exclusionSummary(): String {
        val labels = mapOf(
            "OUTSIDE_WINDOW" to "fora de 28 dias",
            "MISSING_PACE" to "sem pace/tempo calculável",
            "SHORT_DISTANCE" to "distância ausente, inválida ou abaixo de 2 km",
            "NON_COMPARABLE_TYPE" to "tipo de sessão não comparável",
            "DIFFERENT_TYPE_OR_TERRAIN" to "tipo de sessão ou terreno diferente da amostra escolhida",
            "HIGH_EFFORT" to "esforço alto",
            "FATIGUE_OR_PAIN" to "fadiga, recuperação ruim ou dor"
        )
        val parts = exclusionCounts.filterValues { it > 0 }.map { (key, count) ->
            "${labels[key] ?: key}: $count"
        }
        return if (parts.isEmpty()) "Nenhum registro foi excluído pelos filtros principais." else "Exclusões: ${parts.joinToString(" • ")}."
    }
}

/**
 * Compares only recent easy sessions with measured distance and defensible pace data.
 * Missing pace can be derived from elapsed time/distance. Rodagem, regenerativo and
 * longão remain separate comparison groups; terrain and elevation are also respected.
 * With 1–3 matching sessions it reports a descriptive median only, never a trend % and
 * never a zone change. This monitor does not change zones by itself.
 */
internal object PerformanceMonitoringEngine {
    private const val REVIEW_DAYS = 28L
    private const val MIN_COMPARABLE_SESSIONS = 4
    private val easyTypes = setOf("aeróbio", "aerobio", "recuperação", "recuperacao", "longo", "longão", "longao", "rodagem", "regenerativo")

    fun evaluate(observations: List<PaceObservation>, today: LocalDate = LocalDate.now()): PerformanceTrend {
        val exclusions = mutableMapOf<String, Int>()
        fun exclude(reason: String) { exclusions[reason] = (exclusions[reason] ?: 0) + 1 }
        val comparable = observations.mapNotNull { item ->
            val date = runCatching { LocalDate.parse(item.dateIso) }.getOrNull()
            if (date == null || date.isBefore(today.minusDays(REVIEW_DAYS - 1)) || date.isAfter(today)) {
                exclude("OUTSIDE_WINDOW")
                return@mapNotNull null
            }
            if (!item.distanceKm.isFinite() || item.distanceKm < 2.0 || item.distanceKm > 200.0) {
                exclude("SHORT_DISTANCE")
                return@mapNotNull null
            }
            val pace = PaceRange.parsePace(item.paceMmSs) ?: run {
                val duration = item.durationSeconds?.takeIf { it in 1..172_800 }
                if (duration != null) PaceCalculator.paceFromDistanceAndDuration(item.distanceKm, duration) else null
            }
            if (pace == null) {
                exclude("MISSING_PACE")
                return@mapNotNull null
            }
            val typeKey = normalizeType(item.sessionType)
            if (typeKey !in easyTypes.map(::normalizeType).toSet()) {
                exclude("NON_COMPARABLE_TYPE")
                return@mapNotNull null
            }
            if (item.effort in setOf("Pesado", "Muito pesado")) {
                exclude("HIGH_EFFORT")
                return@mapNotNull null
            }
            if (item.feeling in setOf("Cansado", "Muito cansado") || item.painPresent) {
                exclude("FATIGUE_OR_PAIN")
                return@mapNotNull null
            }
            val terrain = RunningTerrain.normalize(item.terrain)
            val elevationPerKm = item.elevationGainMeters?.takeIf { it.isFinite() && it >= 0.0 && item.distanceKm > 0.0 }
                ?.div(item.distanceKm)
            ComparablePace(date, item.sessionType.trim(), typeKey, terrain, pace, elevationPerKm)
        }.sortedBy { it.date }

        if (comparable.isEmpty()) {
            return PerformanceTrend(
                status = "INSUFFICIENT",
                headline = "Ainda não há sessões comparáveis suficientes",
                explanation = "São necessárias pelo menos quatro sessões fáceis do mesmo tipo e terreno, com distância e pace medidos, dentro dos últimos 28 dias. O pace ausente pode ser calculado usando tempo total e distância. ${exclusionExplanation(exclusions)} Os dados monitoram tendências, mas não alteram zonas automaticamente.",
                comparableSessions = 0,
                exclusionCounts = exclusions.toMap(),
                evaluatedRecords = observations.size
            )
        }

        val group = comparable.groupBy { it.typeKey to it.terrain }
            .values
            .maxWithOrNull(compareBy<List<ComparablePace>> { it.size }.thenBy { it.maxOf { row -> row.date } })
            .orEmpty()
        val otherEligible = comparable.size - group.size
        if (otherEligible > 0) exclusions["DIFFERENT_TYPE_OR_TERRAIN"] = otherEligible

        var selected = group
        val elevationValues = selected.mapNotNull { it.elevationPerKm }
        if (elevationValues.size >= MIN_COMPARABLE_SESSIONS) {
            val referenceElevation = medianDouble(elevationValues)
            val elevationComparable = selected.filter { row ->
                row.elevationPerKm == null || abs(row.elevationPerKm - referenceElevation) <= 12.0
            }
            if (elevationComparable.size >= MIN_COMPARABLE_SESSIONS) selected = elevationComparable
        }

        val paces = selected.map { it.pace }
        val medianPace = median(paces).roundToInt()
        val typeLabel = selected.firstOrNull()?.sessionType
        val terrainLabel = selected.firstOrNull()?.terrain
        val dates = selected.map { it.date.toString() }
        val periodStart = dates.minOrNull()
        val periodEnd = dates.maxOrNull()
        if (selected.size < MIN_COMPARABLE_SESSIONS) {
            return PerformanceTrend(
                status = "INSUFFICIENT",
                headline = "Prévia descritiva — faltam ${MIN_COMPARABLE_SESSIONS - selected.size} sessão(ões)",
                explanation = "Há ${selected.size} de $MIN_COMPARABLE_SESSIONS sessões comparáveis de ${typeLabel ?: "mesmo tipo"}, em ${terrainLabel ?: "terreno equivalente"}. A mediana do ritmo é apenas descritiva; não há percentual de melhora/piora nem alteração de zonas antes do critério formal. ${exclusionExplanation(exclusions)}",
                comparableSessions = selected.size,
                exclusionCounts = exclusions.toMap(),
                evaluatedRecords = observations.size,
                preliminaryMedianPaceSecondsPerKm = medianPace,
                preliminarySessionType = typeLabel,
                preliminaryTerrain = terrainLabel,
                preliminarySessionDates = dates,
                periodStartDateIso = periodStart,
                periodEndDateIso = periodEnd
            )
        }

        val paceValues = selected.map { it.pace }
        val split = (paceValues.size / 2).coerceAtLeast(2)
        val early = median(paceValues.take(split))
        val recent = median(paceValues.takeLast(split))
        val change = ((early - recent) / early) * 100.0
        val rounded = (change * 10.0).roundToInt() / 10.0
        val excludedText = exclusionExplanation(exclusions)
        return when {
            change >= 2.0 -> PerformanceTrend(
                "FASTER", "Sinal de melhora nas rodagens comparáveis",
                "O ritmo recente está cerca de ${String.format(java.util.Locale.US, "%.1f", rounded)}% mais rápido. É um sinal para revisar a evolução, não uma autorização automática para acelerar zonas. ${excludedText}",
                selected.size, rounded, exclusions.toMap(), observations.size,
                medianPace, typeLabel, terrainLabel, dates, periodStart, periodEnd
            )
            change <= -2.0 -> PerformanceTrend(
                "SLOWER", "Ritmos recentes ficaram mais lentos",
                "O ritmo recente está cerca de ${String.format(java.util.Locale.US, "%.1f", abs(rounded))}% mais lento. Verifique fadiga, clima, terreno e recuperação; não altere zonas com base em um período isolado. ${excludedText}",
                selected.size, rounded, exclusions.toMap(), observations.size,
                medianPace, typeLabel, terrainLabel, dates, periodStart, periodEnd
            )
            else -> PerformanceTrend(
                "STABLE", "Ritmo estável nas rodagens comparáveis",
                "A variação recente está dentro da faixa de estabilidade adotada pelo aplicativo. Mantenha as zonas até a próxima revisão. ${excludedText}",
                selected.size, rounded, exclusions.toMap(), observations.size,
                medianPace, typeLabel, terrainLabel, dates, periodStart, periodEnd
            )
        }
    }

    private fun normalizeType(value: String): String = value.trim().lowercase(java.util.Locale.ROOT)
        .replace('á', 'a').replace('ã', 'a').replace('é', 'e').replace('ê', 'e')
        .replace('í', 'i').replace('ó', 'o').replace('ô', 'o').replace('ú', 'u')

    private fun exclusionExplanation(exclusions: Map<String, Int>): String {
        val labels = mapOf(
            "OUTSIDE_WINDOW" to "fora da janela de 28 dias",
            "MISSING_PACE" to "sem pace ou dados para calculá-lo",
            "SHORT_DISTANCE" to "distância ausente, inválida ou menor que 2 km",
            "NON_COMPARABLE_TYPE" to "sessão de intensidade não comparável",
            "DIFFERENT_TYPE_OR_TERRAIN" to "tipo de sessão ou terreno diferente da amostra escolhida",
            "HIGH_EFFORT" to "esforço alto",
            "FATIGUE_OR_PAIN" to "fadiga/cansaço ou dor"
        )
        val details = exclusions.filterValues { it > 0 }.map { (key, count) -> "${labels[key] ?: key}: $count" }
        return if (details.isEmpty()) "Nenhum registro foi excluído pelos filtros principais." else "Registros excluídos: ${details.joinToString("; ")}."
    }

    private data class ComparablePace(
        val date: LocalDate,
        val sessionType: String,
        val typeKey: String,
        val terrain: String,
        val pace: Int,
        val elevationPerKm: Double?
    )

    private fun medianDouble(values: List<Double>): Double {
        val sorted = values.sorted()
        val middle = sorted.size / 2
        return if (sorted.size % 2 == 0) (sorted[middle - 1] + sorted[middle]) / 2.0 else sorted[middle]
    }

    private fun median(values: List<Int>): Double {
        val sorted = values.sorted()
        val middle = sorted.size / 2
        return if (sorted.size % 2 == 0) (sorted[middle - 1] + sorted[middle]) / 2.0 else sorted[middle].toDouble()
    }
}
