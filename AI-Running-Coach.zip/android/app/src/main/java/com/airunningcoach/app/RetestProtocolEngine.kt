package com.airunningcoach.app

import kotlin.math.ceil

internal data class RetestProtocolPrescription(
    val method: String?,
    val title: String,
    val detail: String,
    val distanceKm: Double,
    val durationMin: Int,
    val segments: List<WorkoutSegment>,
    val rationale: String
)

/** Builds the scheduled retest without preselecting a protocol, then materializes the exact
 *  Cooper or 3 km prescription only after the athlete makes the choice on the test date. */
internal object RetestProtocolEngine {
    const val COOPER_12_MIN = "COOPER_12_MIN"
    const val THREE_KM = "THREE_KM"

    fun isMethodEligible(method: String, ageAtTest: Int?, referenceSex: String): Boolean {
        val age = ageAtTest ?: return false
        if (age !in 18..120 || referenceSex !in setOf(
                RunnerFitnessAssessmentEngine.MALE,
                RunnerFitnessAssessmentEngine.FEMALE
            )) return false
        return when (method) {
            COOPER_12_MIN -> true
            THREE_KM -> age in 18..39
            else -> false
        }
    }

    fun eligibilityMessage(method: String, ageAtTest: Int?, referenceSex: String): String? {
        if (ageAtTest == null || ageAtTest !in 18..120) {
            return "Informe uma idade válida no perfil para habilitar o teste fisiológico."
        }
        if (referenceSex !in setOf(RunnerFitnessAssessmentEngine.MALE, RunnerFitnessAssessmentEngine.FEMALE)) {
            return "Configure a referência fisiológica no perfil antes de realizar o teste."
        }
        if (method == THREE_KM && ageAtTest !in 18..39) {
            return "O protocolo de 3 km está disponível para atletas de 18 a 39 anos. Para outras idades, utilize o Cooper de 12 minutos."
        }
        if (method !in setOf(COOPER_12_MIN, THREE_KM)) return "Protocolo de teste inválido."
        return null
    }

    fun build(assessment: CooperAssessmentRecord, method: String? = null): RetestProtocolPrescription {
        val selectedMethod = method?.takeIf { it in setOf(COOPER_12_MIN, THREE_KM) }
        if (selectedMethod == null) {
            return RetestProtocolPrescription(
                method = null,
                title = "Reteste fisiológico • método a escolher",
                detail = "O reteste substitui o primeiro treino de corrida desta semana e não acrescenta carga ao calendário. No dia programado, escolha Cooper de 12 minutos ou corrida de 3 km; aquecimento, bloco principal, desaquecimento, distância e duração serão definidos após a escolha.",
                distanceKm = 0.0,
                durationMin = 0,
                segments = emptyList(),
                rationale = "O protocolo permanece indefinido até a escolha explícita do atleta no dia programado."
            )
        }

        val estimate = RetestDistanceEstimator.estimate(assessment, testMethodOverride = selectedMethod)
        val easyPace = estimate.easyPace
        val warmup = WorkoutSegment(
            name = "Aquecimento",
            instruction = "12 min em ritmo confortável, com mobilidade dinâmica leve. A distância é estimada pela faixa fácil individual.",
            durationMin = 12,
            distanceKm = estimate.warmupKm,
            intensity = "LOW",
            rpeRange = "2-3",
            targetMode = "TIME",
            targetPaceMinValue = easyPace?.fastestPaceValue,
            targetPaceMaxValue = easyPace?.slowestPaceValue,
            paceZone = easyPace?.let { "Z2" },
            zoneBasePaceFastValue = assessment.zoneRanges["Z2"]?.let(::parsePaceRange)?.fastestPaceValue,
            zoneBasePaceSlowValue = assessment.zoneRanges["Z2"]?.let(::parsePaceRange)?.slowestPaceValue,
            zoneIntensityMinPercent = easyPace?.let { 0 },
            zoneIntensityMaxPercent = easyPace?.let { 20 }
        )

        val main = when (selectedMethod) {
            COOPER_12_MIN -> WorkoutSegment(
                name = "Cooper • 12 minutos",
                instruction = "Após o aquecimento, percorra a maior distância sustentável em 12 minutos. Registre a distância exata em quilômetros, usando percurso medido e condições seguras. A distância exibida é apenas uma estimativa baseada na última referência disponível.",
                durationMin = 12,
                distanceKm = estimate.testKm,
                intensity = "HIGH",
                rpeRange = "8-9",
                targetMode = "TIME"
            )
            else -> {
                val estimatedSeconds = estimatedThreeKmDurationSeconds(assessment)
                WorkoutSegment(
                    name = "Teste de 3 km",
                    instruction = "Após o aquecimento, percorra exatamente 3 km no melhor esforço sustentável. Registre o tempo total real em mm:ss. ${estimatedSeconds?.let { "A duração mostrada é uma estimativa baseada na última referência e não substitui o tempo real." } ?: "A duração será conhecida após o registro do resultado."} Use percurso medido e condições seguras.",
                    durationMin = estimatedSeconds?.let { ceil(it / 60.0).toInt().coerceAtLeast(1) },
                    distanceKm = 3.0,
                    intensity = "HIGH",
                    rpeRange = "8-9",
                    targetMode = "DISTANCE"
                )
            }
        }

        val cooldown = WorkoutSegment(
            name = "Desaquecimento",
            instruction = "10 min muito leves; encerre se houver dor ou mal-estar. A distância é estimada pela faixa fácil individual.",
            durationMin = 10,
            distanceKm = estimate.cooldownKm,
            intensity = "LOW",
            rpeRange = "1-2",
            targetMode = "TIME",
            targetPaceMinValue = easyPace?.fastestPaceValue,
            targetPaceMaxValue = easyPace?.slowestPaceValue,
            paceZone = easyPace?.let { "Z2" },
            zoneBasePaceFastValue = assessment.zoneRanges["Z2"]?.let(::parsePaceRange)?.fastestPaceValue,
            zoneBasePaceSlowValue = assessment.zoneRanges["Z2"]?.let(::parsePaceRange)?.slowestPaceValue,
            zoneIntensityMinPercent = easyPace?.let { 0 },
            zoneIntensityMaxPercent = easyPace?.let { 20 }
        )

        val testDurationMinutes = when (selectedMethod) {
            COOPER_12_MIN -> 12
            else -> estimatedThreeKmDurationSeconds(assessment)?.let { ceil(it / 60.0).toInt() } ?: 0
        }
        val totalDuration = if (testDurationMinutes > 0) 12 + testDurationMinutes + 10 else 0
        val methodLabel = if (selectedMethod == COOPER_12_MIN) "Cooper de 12 minutos" else "corrida de 3 km"
        val estimateNote = if (estimate.isPartial) {
            "Parte da distância é estimada porque não há faixa individual suficiente para todos os blocos."
        } else {
            "A distância total é uma estimativa baseada nas zonas e no último resultado; o resultado real será registrado após o teste."
        }
        return RetestProtocolPrescription(
            method = selectedMethod,
            title = "Reteste fisiológico • ${if (selectedMethod == COOPER_12_MIN) "Cooper 12 min" else "3 km"}",
            detail = "Protocolo selecionado: $methodLabel. O reteste substitui o primeiro treino de corrida da semana e não acrescenta sessão ou carga. $estimateNote",
            distanceKm = estimate.totalKm,
            durationMin = totalDuration,
            segments = listOf(warmup, main, cooldown),
            rationale = "Sessão montada para $methodLabel após escolha explícita do atleta. Aquecimento e desaquecimento usam a faixa fácil individual; o bloco principal segue o protocolo selecionado."
        )
    }

    private fun estimatedThreeKmDurationSeconds(assessment: CooperAssessmentRecord): Int? {
        if (assessment.testMethod == THREE_KM) {
            assessment.testDurationSeconds?.takeIf { it in 1..3600 }?.let { return it }
        }
        val paceSeconds = PaceRange.parsePace(assessment.averagePace) ?: return null
        return (paceSeconds * 3).takeIf { it in 1..7200 }
    }

    private fun parsePaceRange(label: String): PaceRange? {
        val parts = label.substringBefore(" min/km").trim().replace('–', '-').split('-')
        if (parts.size != 2) return null
        val fast = PaceRange.parsePace(parts[0].trim()) ?: return null
        val slow = PaceRange.parsePace(parts[1].trim()) ?: return null
        return runCatching { PaceRange(fast, slow) }.getOrNull()
    }
}
