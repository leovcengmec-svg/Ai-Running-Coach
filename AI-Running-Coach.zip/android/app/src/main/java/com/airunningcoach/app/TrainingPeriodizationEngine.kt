package com.airunningcoach.app

import kotlin.math.ceil

/** Goal-specific macrocycle and session-selection rules. Reference durations are planning defaults, not mandates. */
internal object TrainingPeriodizationEngine {
    const val BASE = "BASE"
    const val DEVELOPMENT = "DEVELOPMENT"
    const val SPECIFIC = "SPECIFIC"
    const val RECOVERY = "RECOVERY"
    const val TAPER = "TAPER"
    const val POST_RACE = "POST_RACE"

    fun recommendedPlanWeeks(goalKm: Double, level: String, weeklyVolumeKm: Double): Int {
        val readinessAdjustment = when {
            weeklyVolumeKm <= 0.0 -> 4
            weeklyVolumeKm < 8.0 -> 2
            weeklyVolumeKm < 20.0 -> 0
            else -> -1
        }
        val base = when {
            goalKm <= 5.0 -> 8
            goalKm <= 10.0 -> 10
            goalKm <= 15.0 -> 12
            goalKm <= 21.1 -> 16
            goalKm <= 30.0 -> 16
            goalKm <= 42.2 -> 20
            goalKm <= 50.0 -> 24
            goalKm <= 100.0 -> 32
            else -> 36
        }
        val levelAdjustment = when (level) {
            "Iniciante" -> 2
            "Elite" -> -2
            else -> 0
        }
        return (base + readinessAdjustment + levelAdjustment).coerceIn(6, 52)
    }

    fun phaseForWeek(week: Int, totalWeeks: Int, recoveryWeek: Boolean): String {
        if (recoveryWeek) return RECOVERY
        val weeks = totalWeeks.coerceIn(4, 52)
        val current = week.coerceIn(1, weeks)
        val baseEnd = ceil(weeks * 0.25).toInt().coerceAtLeast(2)
        val developmentEnd = ceil(weeks * 0.62).toInt().coerceAtLeast(baseEnd + 1)
        return when {
            current <= baseEnd -> BASE
            current <= developmentEnd -> DEVELOPMENT
            else -> SPECIFIC
        }
    }

    fun hasRecentConsistencyEvidence(input: RunnerInput): Boolean = when (input.activeWeeksLast4) {
        in 3..4 -> true
        2 -> !input.recentActivityHistoryReliable && input.profileBaselineConfirmed
        -1 -> input.recentActivityHistoryReliable || input.profileBaselineConfirmed
        else -> false
    }

    /** Low-to-moderate aerobic quality may be used before threshold work is appropriate. */
    fun aerobicQualityEligible(input: RunnerInput, zones: TrainingPaceZones?): Boolean =
        input.goalCategory != "HEALTH" && zones != null && input.frequency >= 3 &&
            input.weeklyVolumeKm >= 8.0 && input.longestRecentKm >= 4.0 &&
            !input.painPresent && (input.recoveryScore == null || input.recoveryScore >= 60.0) &&
            (input.fatigueScore == null || input.fatigueScore < 75.0) &&
            hasRecentConsistencyEvidence(input)

    /** Threshold sessions depend on recent workload and recovery, not the VO2 fitness label. */
    fun thresholdEligible(input: RunnerInput, zones: TrainingPaceZones?): Boolean =
        input.goalCategory != "HEALTH" && zones != null &&
            input.frequency >= 3 && input.weeklyVolumeKm >= 16.0 && input.longestRecentKm >= 8.0 &&
            !input.painPresent && (input.recoveryScore == null || input.recoveryScore >= 75.0) &&
            (input.fatigueScore == null || input.fatigueScore < 65.0) && hasRecentConsistencyEvidence(input) &&
            input.terrainPreference != RunningTerrain.TRAIL

    /** Z4/Z5 power-aerobic sessions need a larger base, more days and stronger recovery evidence. */
    fun vo2Eligible(input: RunnerInput, zones: TrainingPaceZones?): Boolean =
        input.goalCategory != "HEALTH" && zones != null && input.frequency >= 4 &&
            input.weeklyVolumeKm >= 24.0 && input.longestRecentKm >= 10.0 &&
            !input.painPresent && (input.recoveryScore == null || input.recoveryScore >= 80.0) &&
            (input.fatigueScore == null || input.fatigueScore < 60.0) &&
            input.activeWeeksLast4 >= 3 && input.terrainPreference != RunningTerrain.TRAIL

    /**
     * Selects a named library protocol from the attached MOTOR V11 / PROTOCOLOS structure.
     * The athlete's goal intent changes the stimulus sequence; the distance alone does not.
     */
    fun selectProtocolCode(input: RunnerInput, phase: String, zones: TrainingPaceZones?, week: Int = 1): String? {
        if (phase == RECOVERY || phase == TAPER || phase == POST_RACE || input.goalCategory == "HEALTH") return null
        if (!aerobicQualityEligible(input, zones)) return null

        val threshold = thresholdEligible(input, zones)
        val vo2 = vo2Eligible(input, zones)
        val cycle = (week - 1).mod(4)
        val pbIntent = input.goalIntent == TrainingGoalIntent.PERSONAL_BEST || input.goalIntent == TrainingGoalIntent.TARGET_TIME

        if (!pbIntent) {
            return when (input.goalIntent) {
                // Continuous-running goals emphasize controlled aerobic progressions; do not
                // leave the athlete with only generic easy runs throughout the whole cycle.
                TrainingGoalIntent.CONTINUOUS -> when (phase) {
                    BASE -> if (cycle == 1) "F01" else null
                    DEVELOPMENT -> if (cycle == 0) "CC01" else if (cycle == 2) "F04" else null
                    SPECIFIC -> if (cycle == 0) "CC01" else null
                    else -> null
                }
                // Completing a distance still includes structured aerobic variety. Threshold
                // work is only selected after individual load/recovery criteria are met.
                else -> when (phase) {
                    BASE -> if (cycle == 1) "F01" else null
                    DEVELOPMENT -> when (cycle) {
                        0 -> "CC01"
                        2 -> if (threshold) "T01" else "F01"
                        else -> null
                    }
                    SPECIFIC -> if (cycle == 0) if (threshold) "T01" else "F04" else null
                    else -> null
                }
            }
        }

        return when (phase) {
            BASE -> when (cycle) {
                1 -> "F01"
                2 -> "F04"
                else -> null
            }
            DEVELOPMENT -> when (cycle) {
                0 -> if (threshold) "T01" else "F01"
                1 -> if (threshold) "I04" else "F01"
                2 -> if (threshold) "T04" else "F01"
                else -> null
            }
            SPECIFIC -> when {
                input.goalKm <= 5.0 -> when (cycle) {
                    0 -> if (threshold) "RP05" else "F01"
                    1 -> when { vo2 -> "F03"; threshold -> "I07"; else -> "F04" }
                    2 -> if (threshold) "T01" else "F01"
                    else -> null
                }
                input.goalKm <= 10.0 -> when (cycle) {
                    0 -> if (threshold) "RP10" else "F01"
                    1 -> if (threshold) "I09" else "F04"
                    2 -> if (threshold) "T04" else "F01"
                    else -> null
                }
                input.goalKm <= 21.1 -> when (cycle) {
                    0 -> if (threshold) "RP21" else "F01"
                    1 -> if (threshold) "T04" else "F04"
                    2 -> if (threshold) "T01" else "F01"
                    else -> null
                }
                input.goalKm <= 42.2 -> if (cycle == 0 && threshold) "T04" else if (cycle == 2 && threshold) "T01" else null
                else -> if (cycle == 1) "F01" else null
            }
            else -> null
        }
    }

    fun protocolKind(code: String?): String? = when (code) {
        "F01", "F02", "F04" -> "FARTLEK"
        "F03" -> "FARTLEK_PYRAMID_Z3_Z5"
        "I04", "I07", "I08", "I09", "RP05", "RP10", "RP21" -> "MIXED_INTERVAL_Z3_Z4"
        "T01" -> "TEMPO_RUN"
        "T04", "T05" -> "CRUISE_INTERVAL_Z3_Z4"
        "CC01" -> "PROGRESSIVE_RUN"
        else -> null
    }

    fun protocolTitle(code: String?): String = when (code) {
        "F01" -> "Fartlek leve"
        "F02" -> "Fartlek intenso controlado"
        "F03" -> "Fartlek piramidal"
        "F04" -> "Fartlek variável"
        "I04" -> "Intervalado 3 min"
        "I07" -> "Intervalado 600 m"
        "I08" -> "Intervalado 800 m"
        "I09" -> "Intervalado 1.000 m"
        "T01" -> "Tempo run"
        "T04" -> "Tempo intervalado"
        "T05" -> "Tempo intervalado progressivo"
        "RP05" -> "Ritmo específico 5 km"
        "RP10" -> "Ritmo específico 10 km"
        "RP21" -> "Ritmo específico meia maratona"
        "CC01" -> "Contínuo crescente"
        else -> "Sessão de desenvolvimento"
    }

    fun selectQualityKind(input: RunnerInput, phase: String, zones: TrainingPaceZones?, week: Int = 1): String =
        protocolKind(selectProtocolCode(input, phase, zones, week)) ?: when {
            input.goalCategory == "HEALTH" -> "STEADY_RUN"
            input.goalKm <= 21.1 -> "PROGRESSIVE_RUN"
            input.goalKm <= 42.2 -> "MARATHON_SPECIFIC"
            else -> "ULTRA_SPECIFIC"
        }

    fun longRunCapForGoal(goalKm: Double): Double = when {
        goalKm <= 1.7 -> 4.0
        goalKm <= 3.0 -> 5.0
        goalKm <= 5.0 -> 8.0
        goalKm <= 10.0 -> 14.0
        goalKm <= 15.0 -> 18.0
        goalKm <= 21.1 -> 22.0
        goalKm <= 30.0 -> 28.0
        goalKm <= 42.2 -> 34.0
        goalKm <= 50.0 -> 40.0
        goalKm <= 100.0 -> 55.0
        else -> 65.0
    }
}
