package com.airunningcoach.app

import kotlin.math.ceil
import kotlin.math.pow

/** Goal-specific macrocycle and session-selection rules. Reference durations are planning defaults, not mandates. */
internal object TrainingPeriodizationEngine {
    const val BASE = "BASE"
    const val DEVELOPMENT = "DEVELOPMENT"
    const val SPECIFIC = "SPECIFIC"
    const val RECOVERY = "RECOVERY"
    const val TAPER = "TAPER"
    const val POST_RACE = "POST_RACE"
    const val PREPARATION = "PREPARATION"

    internal data class GoalSpecificReadiness(
        val ready: Boolean,
        val stage: String,
        val minimumWeeklyKm: Double,
        val minimumLongRunKm: Double,
        val minimumFrequency: Int,
        val volumeBelowReference: Boolean,
        val longRunBelowReference: Boolean,
        val frequencyBelowReference: Boolean,
        val consistencyNotEstablished: Boolean,
        val baselineMismatch: Boolean,
        val missingRequirements: List<String>
    )

    /**
     * Specific-phase gates use the selected goal's stored weekly base, assumed prior
     * continuous distance and recommended training frequency. These are product planning
     * categories, not universal limits. Explicit athlete data replaces the defaults; missing
     * fields are hydrated before this engine runs. A 21K goal presumes 10-mile capacity;
     * a marathon presumes half-marathon capacity.
     */
    fun goalSpecificReadiness(input: RunnerInput): GoalSpecificReadiness {
        val loadReference = TrainingPlanReferenceCatalog.loadReference(input.goalKm, input.goalCategory)
        val minWeekly = loadReference.baseWeeklyKm
        val minLong = loadReference.assumedPreviousContinuousDistanceKm
        // Three weekly sessions are sufficient for the planner to run a specific-phase
        // structure when the stored base and prior continuous distance are met. The catalog
        // frequency remains the recommended pattern; it is not a hard four-day veto.
        val minFrequency = minOf(loadReference.recommendedFrequency, 3)
        val volumeBelow = input.weeklyVolumeKm + 0.05 < minWeekly
        val longBelow = input.longestRecentKm + 0.05 < minLong
        val frequencyBelow = input.frequency < minFrequency
        val consistencyNotEstablished = !hasRecentConsistencyEvidence(input)
        val recoveryNotReady = input.painPresent || (input.recoveryScore != null && input.recoveryScore < 60.0) ||
            (input.fatigueScore != null && input.fatigueScore >= 75.0)
        // If one isolated run is larger than 65% of the declared weekly volume,
        // treat the two self-reported baselines as potentially inconsistent. This is a
        // data-quality gate (not a medical risk rule); it prevents one long effort from
        // being mistaken for a sustainable weekly training base.
        val baselineMismatch = input.weeklyVolumeKm > 0.0 &&
            input.longestRecentKm > input.weeklyVolumeKm * 0.65 + 0.05
        val missing = buildList {
            if (volumeBelow) add("volume semanal abaixo de ${formatRequirement(minWeekly)} km")
            if (longBelow) add("maior sessão recente abaixo de ${formatRequirement(minLong)} km")
            if (frequencyBelow) add("frequência abaixo de $minFrequency dias/semana")
            if (consistencyNotEstablished) add("consistência recente ainda não comprovada")
            if (baselineMismatch) add("maior corrida informada é desproporcional ao volume semanal; confirme a média semanal")
            if (recoveryNotReady) add("recuperação ou dor precisa ser reavaliada")
        }
        val ready = missing.isEmpty()
        return GoalSpecificReadiness(
            ready = ready,
            stage = if (ready) "SPECIFIC_READY" else "PREPARATORY_BASE",
            minimumWeeklyKm = minWeekly,
            minimumLongRunKm = minLong,
            minimumFrequency = minFrequency,
            volumeBelowReference = volumeBelow,
            longRunBelowReference = longBelow,
            frequencyBelowReference = frequencyBelow,
            consistencyNotEstablished = consistencyNotEstablished,
            baselineMismatch = baselineMismatch,
            missingRequirements = missing
        )
    }

    private fun formatRequirement(value: Double): String =
        if (value % 1.0 == 0.0) value.toInt().toString() else String.format(java.util.Locale.US, "%.1f", value)

    /** Reference-plan durations use the attached O2 Corre/BR Corrida and NRC structures as defaults. */
    fun recommendedPlanWeeks(
        goalKm: Double,
        level: String,
        weeklyVolumeKm: Double,
        longestRecentKm: Double? = null
    ): Int = TrainingPlanReferenceCatalog.recommendedWeeks(goalKm, level, weeklyVolumeKm, longestRecentKm)

    fun phaseForWeek(week: Int, totalWeeks: Int, recoveryWeek: Boolean): String {
        if (recoveryWeek) return RECOVERY
        val weeks = totalWeeks.coerceIn(4, 52)
        val current = week.coerceIn(1, weeks)
        val baseEnd = ceil(weeks * 0.25).toInt().coerceAtLeast(2)
        val developmentEnd = ceil(weeks * 0.62).toInt().coerceAtLeast(baseEnd + 1)
        return when {
            current <= baseEnd -> BASE
            current <= developmentEnd -> DEVELOPMENT
            else -> SPECIFIC
        }
    }

    fun hasRecentConsistencyEvidence(input: RunnerInput): Boolean = when (input.activeWeeksLast4) {
        in 3..4 -> true
        2 -> !input.recentActivityHistoryReliable && input.profileBaselineConfirmed
        -1 -> input.recentActivityHistoryReliable || input.profileBaselineConfirmed
        else -> false
    }

    /** Low-to-moderate aerobic quality may be used before threshold work is appropriate. */
    fun aerobicQualityEligible(input: RunnerInput, zones: TrainingPaceZones?): Boolean =
        input.goalCategory != "HEALTH" && zones != null && input.frequency >= 3 &&
            input.weeklyVolumeKm >= 8.0 && input.longestRecentKm >= 4.0 &&
            !input.painPresent && (input.recoveryScore == null || input.recoveryScore >= 60.0) &&
            (input.fatigueScore == null || input.fatigueScore < 75.0) &&
            hasRecentConsistencyEvidence(input)

    /** Threshold sessions depend on recent workload and recovery, not the VO2 fitness label. */
    fun thresholdEligible(input: RunnerInput, zones: TrainingPaceZones?): Boolean =
        input.goalCategory != "HEALTH" && zones != null &&
            input.frequency >= 3 && input.weeklyVolumeKm >= 16.0 && input.longestRecentKm >= 8.0 &&
            !input.painPresent && (input.recoveryScore == null || input.recoveryScore >= 75.0) &&
            (input.fatigueScore == null || input.fatigueScore < 65.0) && hasRecentConsistencyEvidence(input) &&
            input.terrainPreference != RunningTerrain.TRAIL

    /** Z4/Z5 power-aerobic sessions need a larger base, more days and stronger recovery evidence. */
    fun vo2Eligible(input: RunnerInput, zones: TrainingPaceZones?): Boolean =
        input.goalCategory != "HEALTH" && zones != null && input.frequency >= 4 &&
            input.weeklyVolumeKm >= 24.0 && input.longestRecentKm >= 10.0 &&
            !input.painPresent && (input.recoveryScore == null || input.recoveryScore >= 80.0) &&
            (input.fatigueScore == null || input.fatigueScore < 60.0) &&
            input.activeWeeksLast4 >= 3 && input.terrainPreference != RunningTerrain.TRAIL

    /**
     * Selects a named library protocol from the attached MOTOR V11 / PROTOCOLOS structure.
     * The athlete's goal intent changes the stimulus sequence; the distance alone does not.
     */
    fun selectProtocolCode(input: RunnerInput, phase: String, zones: TrainingPaceZones?, week: Int = 1): String? {
        if (phase == RECOVERY || phase == TAPER || phase == POST_RACE || input.goalCategory == "HEALTH") return null
        if (!aerobicQualityEligible(input, zones)) return null

        val cycle = (week - 1).mod(4)
        if (phase == PREPARATION) {
            // The four priorities remain behaviorally distinct even during preparation.
            // They only select low/moderate aerobic options; threshold/VO2 and race-pace
            // work remain unavailable until the specific-readiness gates are met.
            return when (input.goalIntent) {
                TrainingGoalIntent.CONTINUOUS -> if (cycle == 1) "CC01" else null
                TrainingGoalIntent.PERSONAL_BEST -> if (cycle == 1) "F04" else null
                TrainingGoalIntent.TARGET_TIME -> if (cycle == 2) "CC01" else if (cycle == 1) "F01" else null
                else -> if (cycle == 1) "F01" else null
            }
        }

        val threshold = thresholdEligible(input, zones)
        val vo2 = vo2Eligible(input, zones)
        val pbIntent = input.goalIntent == TrainingGoalIntent.PERSONAL_BEST || input.goalIntent == TrainingGoalIntent.TARGET_TIME

        // Record-chasing and target-time plans now have separate stimulus calendars.
        // PB prioritizes varied interval/threshold development; target-time prioritizes
        // rehearsals of the selected race pace and sustained blocks.
        if (input.goalIntent == TrainingGoalIntent.PERSONAL_BEST) {
            return when (phase) {
                BASE -> when (cycle) {
                    1 -> if (input.recoveryScore != null && input.fatigueScore != null) "F04" else "F01"
                    2 -> "F04"
                    else -> null
                }
                DEVELOPMENT -> when (cycle) {
                    0 -> if (threshold) "T01" else "F04"
                    1 -> when { vo2 -> "I04"; threshold -> if (input.goalKm <= 10.0) "I07" else "I09"; else -> "F04" }
                    2 -> if (threshold) "T04" else "CC01"
                    else -> null
                }
                SPECIFIC -> when {
                    input.goalKm <= 5.0 -> when (cycle) {
                        0 -> if (threshold) "RP05" else "F04"
                        1 -> when { vo2 -> "F03"; threshold -> "I05"; else -> "F04" }
                        2 -> if (threshold) "T01" else "CC01"
                        else -> if (threshold) "I05" else "F04"
                    }
                    input.goalKm <= 10.0 -> when (cycle) {
                        0 -> if (threshold) "RP10" else "F04"
                        1 -> if (threshold) "I09" else "F04"
                        2 -> if (threshold) "T04" else "CC01"
                        else -> if (threshold) "I06" else "F04"
                    }
                    input.goalKm <= 15.5 -> when (cycle) {
                        0 -> if (threshold) "RP15" else "F04"
                        1 -> if (threshold) "I09" else "F04"
                        2 -> if (threshold) "T04" else "CC01"
                        else -> if (threshold) "T05" else "F04"
                    }
                    input.goalKm <= 21.1 -> when (cycle) {
                        0 -> if (threshold) "RP21" else "F04"
                        1 -> if (threshold) "I09" else "F04"
                        2 -> if (threshold) "T05" else "CC01"
                        else -> if (threshold) "T04" else "F04"
                    }
                    input.goalKm <= 42.2 -> when (cycle) {
                        0 -> if (threshold) "T04" else "F04"
                        1 -> if (threshold) "I10" else "F04"
                        2 -> if (threshold) "T05" else "CC01"
                        else -> null
                    }
                    else -> if (cycle == 1 && threshold) "I10" else null
                }
                else -> null
            }
        }
        if (input.goalIntent == TrainingGoalIntent.TARGET_TIME) {
            val racePaceCode = when {
                input.goalKm <= 5.0 -> "RP05"
                input.goalKm <= 10.0 -> "RP10"
                input.goalKm <= 15.5 -> "RP15"
                input.goalKm <= 21.1 -> "RP21"
                else -> "T04"
            }
            return when (phase) {
                BASE -> when (cycle) { 1 -> "F01"; 2 -> "CC01"; else -> null }
                DEVELOPMENT -> when (cycle) {
                    0 -> if (threshold) "T01" else "CC01"
                    1 -> if (threshold) "T04" else "F04"
                    2 -> if (threshold) "T05" else "CC01"
                    else -> null
                }
                SPECIFIC -> when (cycle) {
                    0 -> if (threshold) racePaceCode else "F04"
                    1 -> if (threshold) if (vo2 && input.goalKm <= 10.0) "I09" else "T04" else "F04"
                    2 -> if (threshold) "T05" else "CC01"
                    else -> if (threshold && input.goalKm <= 10.0) "I06" else "F04"
                }
                else -> null
            }
        }

        if (!pbIntent) {
            return when (input.goalIntent) {
                // Continuous-running goals emphasize controlled aerobic progressions; do not
                // leave the athlete with only generic easy runs throughout the whole cycle.
                TrainingGoalIntent.CONTINUOUS -> when (phase) {
                    BASE -> if (cycle == 1) "F01" else null
                    DEVELOPMENT -> when (cycle) {
                        0 -> if (input.goalKm <= 5.0) "CC01" else "F04"
                        2 -> if (input.goalKm >= 21.1 && threshold) "T01" else "CC01"
                        else -> null
                    }
                    SPECIFIC -> when {
                        cycle != 0 -> null
                        input.goalKm <= 5.0 -> "CC01"
                        input.goalKm <= 10.0 -> "F04"
                        input.goalKm <= 21.1 -> if (threshold) "T01" else "F04"
                        input.goalKm <= 42.2 -> if (threshold) "T04" else "F04"
                        else -> "F04"
                    }
                    else -> null
                }
                // Completing a distance receives a distance-appropriate aerobic stimulus.
                // Higher intensity remains gated by recent volume and recovery.
                else -> when (phase) {
                    BASE -> if (cycle == 1) "F01" else null
                    DEVELOPMENT -> when (cycle) {
                        0 -> if (input.goalKm <= 5.0) "CC01" else "F04"
                        2 -> if (threshold && input.goalKm >= 10.0) "T01" else "CC01"
                        else -> null
                    }
                    SPECIFIC -> if (cycle == 0) when {
                        input.goalKm <= 5.0 -> "F04"
                        input.goalKm <= 10.0 -> if (threshold) "T01" else "F04"
                        input.goalKm <= 21.1 -> if (threshold) "T04" else "F04"
                        input.goalKm <= 42.2 -> if (threshold) "T05" else "F04"
                        else -> "F04"
                    } else null
                    else -> null
                }
            }
        }

        return when (phase) {
            BASE -> when (cycle) {
                1 -> "F01"
                2 -> "F04"
                else -> null
            }
            DEVELOPMENT -> when (cycle) {
                0 -> if (threshold) "T01" else "F01"
                1 -> if (threshold) "I04" else "F01"
                2 -> if (threshold) "T04" else "F01"
                else -> null
            }
            SPECIFIC -> when {
                input.goalKm <= 5.0 -> when (cycle) {
                    0 -> if (threshold) "RP05" else "F01"
                    1 -> when { vo2 -> "F03"; threshold -> "I07"; else -> "F04" }
                    2 -> if (threshold) "T01" else "F01"
                    else -> if (threshold) "I05" else "F04"
                }
                input.goalKm <= 10.0 -> when (cycle) {
                    0 -> if (threshold) "RP10" else "F01"
                    1 -> if (threshold) "I09" else "F04"
                    2 -> if (threshold) "T04" else "F01"
                    else -> if (threshold) "I06" else "F04"
                }
                input.goalKm <= 15.5 -> when (cycle) {
                    0 -> if (threshold) "RP15" else "F01"
                    1 -> if (threshold) "I09" else "F04"
                    2 -> if (threshold) "T04" else "F01"
                    else -> if (threshold) "T05" else "F04"
                }
                input.goalKm <= 21.1 -> when (cycle) {
                    0 -> if (threshold) "RP21" else "F01"
                    1 -> if (threshold) "T04" else "F04"
                    2 -> if (threshold) "T05" else "F01"
                    else -> if (threshold) "I09" else "F04"
                }
                input.goalKm <= 42.2 -> when (cycle) {
                    0 -> if (threshold) "T04" else "F01"
                    1 -> "F04"
                    2 -> if (threshold) "T05" else "F01"
                    else -> null
                }
                else -> if (cycle == 1) "F01" else null
            }
            else -> null
        }
    }

    fun protocolKind(code: String?): String? = when (code) {
        "F01", "F02", "F04" -> "FARTLEK"
        "F03" -> "FARTLEK_PYRAMID_Z3_Z5"
        "I04", "I05", "I06", "I07", "I08", "I09", "I10", "RP05", "RP10", "RP15", "RP21", "T04", "T05" -> "EXPLICIT_INTERVAL"
        "T01" -> "TEMPO_RUN"
        "CC01" -> "PROGRESSIVE_RUN"
        else -> null
    }

    fun protocolTitle(code: String?): String = TrainingProtocolCatalog.title(code)

    fun selectQualityKind(input: RunnerInput, phase: String, zones: TrainingPaceZones?, week: Int = 1): String =
        protocolKind(selectProtocolCode(input, phase, zones, week)) ?: when {
            input.goalCategory == "HEALTH" -> "STEADY_RUN"
            input.goalKm <= 21.1 -> "PROGRESSIVE_RUN"
            input.goalKm <= 42.2 -> "MARATHON_SPECIFIC"
            else -> "ULTRA_SPECIFIC"
        }

    /**
     * Progressively releases the planned long-run ceiling across BUILD weeks instead of
     * freezing it at 110% of the longest session entered during onboarding. A real longer
     * activity becomes the new baseline when the load snapshot is recalculated.
     */
    fun plannedLongRunCap(
        goalKm: Double,
        longestRecentKm: Double,
        week: Int,
        recoveryAllowsProgression: Boolean
    ): Double {
        val goalCap = longRunCapForGoal(goalKm)
        val baseline = longestRecentKm.takeIf { it.isFinite() && it > 0.0 } ?: 1.0
        if (!recoveryAllowsProgression) return minOf(baseline, goalCap)
        val safeWeek = week.coerceAtLeast(1)
        val completedCycles = (safeWeek - 1) / 4
        val cyclePosition = (safeWeek - 1) % 4
        // Each 4-week cycle has three build weeks and one deload. The deload
        // temporarily lowers the long-run cap without erasing the build reference.
        val buildStep = completedCycles * 3 + minOf(cyclePosition, 2)
        val progressed = baseline * 1.05.pow(buildStep.toDouble())
        val planned = if (cyclePosition == 3) progressed * 0.80 else progressed
        return minOf(planned, goalCap)
    }

    fun longRunCapForGoal(goalKm: Double): Double = when {
        goalKm <= 1.7 -> 4.0
        goalKm <= 3.0 -> 5.0
        goalKm <= 5.0 -> 8.0
        goalKm <= 10.0 -> 14.0
        goalKm <= 15.0 -> 18.0
        goalKm <= 16.5 -> 20.0
        goalKm <= 21.1 -> 24.0
        goalKm <= 30.0 -> 30.0
        goalKm <= 42.2 -> 34.0
        goalKm <= 50.0 -> 40.0
        goalKm <= 100.0 -> 55.0
        else -> 65.0
    }
}
