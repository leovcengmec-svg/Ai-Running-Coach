package com.airunningcoach.app

/** Macrocycle and session selection rules. The output is a training emphasis, not a fixed calendar. */
internal object TrainingPeriodizationEngine {
    const val BASE = "BASE"
    const val DEVELOPMENT = "DEVELOPMENT"
    const val SPECIFIC = "SPECIFIC"
    const val RECOVERY = "RECOVERY"

    fun phaseForWeek(week: Int, totalWeeks: Int, recoveryWeek: Boolean): String {
        if (recoveryWeek) return RECOVERY
        val weeks = totalWeeks.coerceIn(4, 16)
        val current = week.coerceIn(1, weeks)
        val baseEnd = if (weeks <= 4) 1 else kotlin.math.ceil(weeks * 0.25).toInt().coerceAtLeast(2)
        val developmentEnd = if (weeks <= 4) 3 else kotlin.math.ceil(weeks * 0.62).toInt().coerceAtLeast(baseEnd + 1)
        return when {
            current <= baseEnd -> BASE
            current <= developmentEnd -> DEVELOPMENT
            else -> SPECIFIC
        }
    }

    fun thresholdEligible(input: RunnerInput, zones: TrainingPaceZones?): Boolean =
        input.goalCategory != "HEALTH" && zones != null && input.level in setOf("Intermediário", "Avançado", "Elite") &&
            input.frequency >= 3 && input.weeklyVolumeKm >= 16.0 && input.longestRecentKm >= 8.0 &&
            !input.painPresent && (input.recoveryScore == null || input.recoveryScore >= 75.0) &&
            (input.fatigueScore == null || input.fatigueScore < 65.0)

    fun vo2Eligible(input: RunnerInput, zones: TrainingPaceZones?): Boolean =
        input.goalCategory != "HEALTH" && zones != null && input.level in setOf("Avançado", "Elite") && input.frequency >= 3 &&
            input.weeklyVolumeKm >= 24.0 && input.longestRecentKm >= 10.0 &&
            !input.painPresent && (input.recoveryScore == null || input.recoveryScore >= 80.0) &&
            (input.fatigueScore == null || input.fatigueScore < 60.0)

    fun selectQualityKind(input: RunnerInput, phase: String, zones: TrainingPaceZones?): String {
        if (input.goalCategory == "HEALTH") return "STEADY_RUN"
        val threshold = thresholdEligible(input, zones)
        val vo2 = vo2Eligible(input, zones)
        val goal = input.goalKm

        if (!threshold) {
            return when {
                goal <= 10.0 -> if (goal <= 5.0) "PROGRESSIVE_RUN" else "AEROBIC_INTERVAL_Z2"
                goal <= 21.1 -> "STEADY_RUN"
                goal <= 42.2 -> "MARATHON_SPECIFIC"
                else -> "ULTRA_SPECIFIC"
            }
        }

        return when (phase) {
            BASE -> when {
                goal <= 10.0 -> "PROGRESSIVE_RUN"
                else -> "STEADY_RUN"
            }
            DEVELOPMENT -> when {
                goal <= 3.0 -> "MIXED_INTERVAL_Z3_Z4"
                goal <= 10.0 -> if (input.level == "Avançado" || input.level == "Elite") "MIXED_INTERVAL_Z3_Z4" else "AEROBIC_INTERVAL_Z2_Z3"
                goal <= 21.1 -> "THRESHOLD_INTERVAL_Z3_Z4"
                goal <= 42.2 -> "MARATHON_SPECIFIC"
                else -> "ULTRA_SPECIFIC"
            }
            SPECIFIC -> when {
                goal <= 3.0 -> if (vo2) "PYRAMID_INTERVAL_Z3_Z5" else "MIXED_INTERVAL_Z3_Z4"
                goal <= 5.0 -> if (vo2) "MIXED_INTERVAL_Z4_Z5" else "MIXED_INTERVAL_Z3_Z4"
                goal <= 10.0 -> if (vo2) "MIXED_INTERVAL_Z4_Z5" else "THRESHOLD_INTERVAL_Z3_Z4"
                goal <= 21.1 -> if (input.level == "Avançado" || input.level == "Elite") "THRESHOLD_INTERVAL_Z3_Z4" else "TEMPO_RUN"
                goal <= 42.2 -> "MARATHON_SPECIFIC"
                else -> "ULTRA_SPECIFIC"
            }
            else -> when {
                goal <= 10.0 -> "AEROBIC_INTERVAL_Z2"
                goal <= 21.1 -> "TEMPO_RUN"
                goal <= 42.2 -> "MARATHON_SPECIFIC"
                else -> "ULTRA_SPECIFIC"
            }
        }
    }

    fun longRunCapForGoal(goalKm: Double): Double = when {
        goalKm <= 1.7 -> 4.0
        goalKm <= 3.0 -> 5.0
        goalKm <= 5.0 -> 8.0
        goalKm <= 10.0 -> 14.0
        goalKm <= 15.0 -> 18.0
        goalKm <= 21.1 -> 22.0
        goalKm <= 42.2 -> 34.0
        else -> 45.0
    }
}
