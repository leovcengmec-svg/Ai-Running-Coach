package com.airunningcoach.app

import kotlin.math.ceil

/** Goal-specific macrocycle and session-selection rules. Reference durations are planning defaults, not mandates. */
internal object TrainingPeriodizationEngine {
    const val BASE = "BASE"
    const val DEVELOPMENT = "DEVELOPMENT"
    const val SPECIFIC = "SPECIFIC"
    const val RECOVERY = "RECOVERY"
    const val TAPER = "TAPER"
    const val POST_RACE = "POST_RACE"

    fun recommendedPlanWeeks(goalKm: Double, level: String, weeklyVolumeKm: Double): Int {
        val readinessAdjustment = when {
            weeklyVolumeKm <= 0.0 -> 4
            weeklyVolumeKm < 8.0 -> 2
            weeklyVolumeKm < 20.0 -> 0
            else -> -1
        }
        val base = when {
            goalKm <= 5.0 -> 8
            goalKm <= 10.0 -> 10
            goalKm <= 15.0 -> 12
            goalKm <= 21.1 -> 16
            goalKm <= 30.0 -> 16
            goalKm <= 42.2 -> 20
            goalKm <= 50.0 -> 24
            goalKm <= 100.0 -> 32
            else -> 36
        }
        val levelAdjustment = when (level) {
            "Iniciante" -> 2
            "Elite" -> -2
            else -> 0
        }
        return (base + readinessAdjustment + levelAdjustment).coerceIn(6, 52)
    }

    fun phaseForWeek(week: Int, totalWeeks: Int, recoveryWeek: Boolean): String {
        if (recoveryWeek) return RECOVERY
        val weeks = totalWeeks.coerceIn(4, 52)
        val current = week.coerceIn(1, weeks)
        val baseEnd = ceil(weeks * 0.25).toInt().coerceAtLeast(2)
        val developmentEnd = ceil(weeks * 0.62).toInt().coerceAtLeast(baseEnd + 1)
        return when {
            current <= baseEnd -> BASE
            current <= developmentEnd -> DEVELOPMENT
            else -> SPECIFIC
        }
    }

    fun hasRecentConsistencyEvidence(input: RunnerInput): Boolean = when (input.activeWeeksLast4) {
        in 3..4 -> true
        -1 -> input.recentActivityHistoryReliable
        else -> false
    }

    fun thresholdEligible(input: RunnerInput, zones: TrainingPaceZones?): Boolean =
        input.goalCategory != "HEALTH" && zones != null && input.level in setOf("Intermediário", "Avançado", "Elite") &&
            input.frequency >= 3 && input.weeklyVolumeKm >= 16.0 && input.longestRecentKm >= 8.0 &&
            !input.painPresent && (input.recoveryScore == null || input.recoveryScore >= 75.0) &&
            (input.fatigueScore == null || input.fatigueScore < 65.0) && hasRecentConsistencyEvidence(input) &&
            input.terrainPreference != RunningTerrain.TRAIL

    fun vo2Eligible(input: RunnerInput, zones: TrainingPaceZones?): Boolean =
        input.goalCategory != "HEALTH" && zones != null && input.level in setOf("Avançado", "Elite") && input.frequency >= 3 &&
            input.weeklyVolumeKm >= 24.0 && input.longestRecentKm >= 10.0 &&
            !input.painPresent && (input.recoveryScore == null || input.recoveryScore >= 80.0) &&
            (input.fatigueScore == null || input.fatigueScore < 60.0) && hasRecentConsistencyEvidence(input) &&
            input.terrainPreference != RunningTerrain.TRAIL

    fun selectQualityKind(input: RunnerInput, phase: String, zones: TrainingPaceZones?, week: Int = 1): String {
        if (input.goalCategory == "HEALTH") return "STEADY_RUN"
        val threshold = thresholdEligible(input, zones)
        val vo2 = vo2Eligible(input, zones)
        val goal = input.goalKm
        val rotation = week % 4

        // Base phase emphasizes aerobic development; no high-intensity work is selected here.
        if (phase == BASE || phase == RECOVERY) return when {
            goal <= 5.0 -> if (week % 2 == 0) "AEROBIC_INTERVAL_Z2_Z3" else "PROGRESSIVE_RUN"
            goal <= 21.1 -> if (week % 2 == 0) "AEROBIC_INTERVAL_Z2" else "STEADY_RUN"
            else -> if (goal <= 42.2) "MARATHON_SPECIFIC" else "ULTRA_SPECIFIC"
        }

        if (!threshold) return when {
            goal <= 5.0 -> if (week % 2 == 0) "AEROBIC_INTERVAL_Z2_Z3" else "PROGRESSIVE_RUN"
            goal <= 10.0 -> "AEROBIC_INTERVAL_Z2"
            goal <= 21.1 -> "STEADY_RUN"
            goal <= 42.2 -> "MARATHON_SPECIFIC"
            else -> "ULTRA_SPECIFIC"
        }

        return when (phase) {
            DEVELOPMENT -> when {
                goal <= 3.5 -> if (vo2 && rotation == 0) "MIXED_INTERVAL_Z4_Z5" else "MIXED_INTERVAL_Z3_Z4"
                goal <= 5.0 -> when {
                    vo2 && rotation == 0 -> "MIXED_INTERVAL_Z4_Z5"
                    vo2 && rotation == 2 -> "PYRAMID_INTERVAL_Z3_Z5"
                    rotation == 1 -> "FARTLEK"
                    else -> "AEROBIC_INTERVAL_Z2_Z3"
                }
                goal <= 10.0 -> when {
                    vo2 && rotation == 0 -> "MIXED_INTERVAL_Z4_Z5"
                    rotation == 1 -> "CRUISE_INTERVAL_Z3_Z4"
                    rotation == 2 -> "FARTLEK"
                    else -> "AEROBIC_INTERVAL_Z2_Z3"
                }
                goal <= 21.1 -> if (rotation == 0 || rotation == 2) "CRUISE_INTERVAL_Z3_Z4" else "TEMPO_RUN"
                goal <= 42.2 -> if (rotation == 0) "MARATHON_SPECIFIC" else "TEMPO_RUN"
                else -> "ULTRA_SPECIFIC"
            }
            SPECIFIC -> when {
                goal <= 3.5 -> if (vo2 && rotation == 0) "PYRAMID_INTERVAL_Z3_Z5" else "MIXED_INTERVAL_Z3_Z4"
                goal <= 5.0 -> when {
                    vo2 && rotation == 0 -> "MIXED_INTERVAL_Z4_Z5"
                    vo2 && rotation == 2 -> "PYRAMID_INTERVAL_Z3_Z5"
                    rotation == 1 -> "CRUISE_INTERVAL_Z3_Z4"
                    else -> "MIXED_INTERVAL_Z3_Z4"
                }
                goal <= 10.0 -> when {
                    vo2 && rotation == 0 -> "MIXED_INTERVAL_Z4_Z5"
                    rotation == 1 -> "CRUISE_INTERVAL_Z3_Z4"
                    rotation == 2 -> "FARTLEK"
                    else -> "MIXED_INTERVAL_Z3_Z4"
                }
                goal <= 21.1 -> when (rotation) {
                    0 -> "CRUISE_INTERVAL_Z3_Z4"
                    1 -> "TEMPO_RUN"
                    2 -> "FARTLEK"
                    else -> "AEROBIC_INTERVAL_Z2_Z3"
                }
                goal <= 42.2 -> if (rotation == 0) "MARATHON_SPECIFIC" else if (rotation == 2) "CRUISE_INTERVAL_Z3_Z4" else "TEMPO_RUN"
                else -> "ULTRA_SPECIFIC"
            }
            else -> when {
                goal <= 10.0 -> "AEROBIC_INTERVAL_Z2"
                goal <= 21.1 -> "TEMPO_RUN"
                goal <= 42.2 -> "MARATHON_SPECIFIC"
                else -> "ULTRA_SPECIFIC"
            }
        }
    }

    fun longRunCapForGoal(goalKm: Double): Double = when {
        goalKm <= 1.7 -> 4.0
        goalKm <= 3.0 -> 5.0
        goalKm <= 5.0 -> 8.0
        goalKm <= 10.0 -> 14.0
        goalKm <= 15.0 -> 18.0
        goalKm <= 21.1 -> 22.0
        goalKm <= 30.0 -> 28.0
        goalKm <= 42.2 -> 34.0
        goalKm <= 50.0 -> 40.0
        goalKm <= 100.0 -> 55.0
        else -> 65.0
    }
}
