package com.airunningcoach.app

import java.time.LocalDate
import java.time.Period
import java.time.format.DateTimeFormatter
import java.time.format.ResolverStyle

/** One demographic source for the athlete profile and date-specific historical assessments. */
internal object AthleteDemographicsEngine {
    private val birthDateFormatter = DateTimeFormatter.ofPattern("dd/MM/uuuu")
        .withResolverStyle(ResolverStyle.STRICT)

    fun parseBirthDate(value: String, today: LocalDate = LocalDate.now()): LocalDate? =
        value.trim().takeIf { it.isNotBlank() }
            ?.let { raw -> runCatching { LocalDate.parse(raw, birthDateFormatter) }.getOrNull() }
            ?.takeIf { !it.isAfter(today) }

    /** Legacy profiles with age only reuse that age; a saved birth date always wins. */
    fun ageAtDate(
        birthDateText: String,
        legacyCurrentAge: String,
        date: LocalDate,
        today: LocalDate = LocalDate.now()
    ): Int? {
        if (birthDateText.isNotBlank()) {
            val birthDate = parseBirthDate(birthDateText, today) ?: return null
            return Period.between(birthDate, date).years.takeIf { it in 18..100 }
        }
        return legacyCurrentAge.toIntOrNull()?.takeIf { it in 18..100 }
    }
}
