package com.airunningcoach.app

/** Exact-dose contracts for named interval protocols. Distances are meters, durations are minutes. */
internal data class TrainingProtocolDefinition(
    val code: String,
    val family: String,
    val repetitions: Int,
    val targetMode: String,
    val workDistanceMeters: Int? = null,
    val workDurationMinutes: Int? = null,
    val recoveryDurationMinutes: Int,
    val displayTitle: String,
    val purpose: String
) {
    init {
        require(targetMode == "DISTANCE" || targetMode == "TIME")
        require(repetitions >= 2)
        require(recoveryDurationMinutes in 1..10)
        if (targetMode == "DISTANCE") require(workDistanceMeters != null && workDistanceMeters > 0 && workDurationMinutes == null)
        if (targetMode == "TIME") require(workDurationMinutes != null && workDurationMinutes > 0 && workDistanceMeters == null)
    }
}

internal object TrainingProtocolCatalog {
    val all = listOf(
        TrainingProtocolDefinition("I04", "INTERVAL", 4, "TIME", workDurationMinutes = 3, recoveryDurationMinutes = 2, displayTitle = "Intervalado 4 × 3 min", purpose = "Repetições por tempo, com recuperação leve"),
        TrainingProtocolDefinition("I05", "INTERVAL", 6, "DISTANCE", workDistanceMeters = 400, recoveryDurationMinutes = 2, displayTitle = "Intervalado 6 × 400 m", purpose = "Repetições curtas de 400 metros para desenvolver velocidade controlada"),
        TrainingProtocolDefinition("I06", "INTERVAL", 4, "DISTANCE", workDistanceMeters = 800, recoveryDurationMinutes = 2, displayTitle = "Intervalado 4 × 800 m", purpose = "Repetições de 800 metros para desenvolver ritmo e resistência de velocidade"),
        TrainingProtocolDefinition("I07", "INTERVAL", 5, "DISTANCE", workDistanceMeters = 600, recoveryDurationMinutes = 2, displayTitle = "Intervalado 5 × 600 m", purpose = "Repetições de 600 metros, com recuperação leve"),
        TrainingProtocolDefinition("I08", "INTERVAL", 5, "DISTANCE", workDistanceMeters = 800, recoveryDurationMinutes = 2, displayTitle = "Intervalado 5 × 800 m", purpose = "Repetições de 800 metros, com recuperação leve"),
        TrainingProtocolDefinition("I09", "INTERVAL", 3, "DISTANCE", workDistanceMeters = 1_000, recoveryDurationMinutes = 3, displayTitle = "Intervalado 3 × 1.000 m", purpose = "Repetições de 1.000 metros, com recuperação leve"),
        TrainingProtocolDefinition("I10", "INTERVAL", 3, "DISTANCE", workDistanceMeters = 1_600, recoveryDurationMinutes = 3, displayTitle = "Intervalado 3 × 1.600 m", purpose = "Repetições longas para resistência em ritmo específico"),
        TrainingProtocolDefinition("RP05", "RACE_PACE", 4, "TIME", workDurationMinutes = 4, recoveryDurationMinutes = 2, displayTitle = "Ritmo específico 5 km · 4 × 4 min", purpose = "Sustentar o esforço de referência dos 5 km"),
        TrainingProtocolDefinition("RP10", "RACE_PACE", 3, "TIME", workDurationMinutes = 5, recoveryDurationMinutes = 2, displayTitle = "Ritmo específico 10 km · 3 × 5 min", purpose = "Sustentar o esforço de referência dos 10 km"),
        // 15 km is an app-owned bridge protocol; none of the supplied source plans is a dedicated 15 km plan.
        TrainingProtocolDefinition("RP15", "RACE_PACE", 3, "TIME", workDurationMinutes = 6, recoveryDurationMinutes = 2, displayTitle = "Ritmo específico 15 km · 3 × 6 min", purpose = "Desenvolver ritmo sustentado na transição entre 10 km e meia maratona"),
        TrainingProtocolDefinition("RP21", "RACE_PACE", 2, "TIME", workDurationMinutes = 8, recoveryDurationMinutes = 3, displayTitle = "Ritmo específico meia · 2 × 8 min", purpose = "Acumular blocos sustentáveis para meia maratona"),
        TrainingProtocolDefinition("T04", "TEMPO", 2, "TIME", workDurationMinutes = 10, recoveryDurationMinutes = 3, displayTitle = "Tempo intervalado · 2 × 10 min", purpose = "Acumular tempo controlado próximo ao limiar estimado"),
        TrainingProtocolDefinition("T05", "TEMPO", 3, "TIME", workDurationMinutes = 8, recoveryDurationMinutes = 2, displayTitle = "Tempo intervalado · 3 × 8 min", purpose = "Acumular blocos de ritmo sustentado")
    )

    fun find(code: String?): TrainingProtocolDefinition? = all.firstOrNull { it.code == code }

    fun title(code: String?): String = find(code)?.displayTitle ?: when (code) {
        "F01" -> "Fartlek leve"
        "F02" -> "Fartlek intenso controlado"
        "F03" -> "Fartlek piramidal"
        "F04" -> "Fartlek variável"
        "T01" -> "Tempo Run"
        "CC01" -> "Rodagem progressiva"
        else -> "Sessão de desenvolvimento"
    }

    /** Returns explicit violations instead of silently accepting a title/dose mismatch. */
    fun validateNamedProtocol(code: String, segments: List<WorkoutSegment>): List<String> {
        val protocol = find(code) ?: return emptyList()
        val workSegments = segments.filter { it.name.equals("Intervalo", ignoreCase = true) || it.name.startsWith("Intervalo ", true) }
        val recoverySegments = segments.filter { it.name.contains("recuperação", ignoreCase = true) }
        val workCount = workSegments.sumOf { it.repeatCount }
        val recoveryCount = recoverySegments.sumOf { it.repeatCount }
        val expectedRecoveryCount = (protocol.repetitions - 1).coerceAtLeast(0)
        val expectedWorkDose = when (protocol.targetMode) {
            "DISTANCE" -> protocol.workDistanceMeters!! / 1_000.0
            else -> null
        }
        val errors = mutableListOf<String>()
        if (workCount != protocol.repetitions) errors += "${protocol.displayTitle}: esperado ${protocol.repetitions} repetições, encontrado $workCount."
        if (recoveryCount != expectedRecoveryCount) errors += "${protocol.displayTitle}: esperado $expectedRecoveryCount recuperações entre repetições, encontrado $recoveryCount."
        if (protocol.targetMode == "DISTANCE") {
            if (workSegments.any { it.targetMode != "DISTANCE" || it.durationMin != null || kotlin.math.abs((it.distanceKm ?: -1.0) - expectedWorkDose!!) > 0.001 }) {
                errors += "${protocol.displayTitle}: cada repetição precisa manter exatamente ${protocol.workDistanceMeters} m."
            }
        } else if (workSegments.any { it.targetMode != "TIME" || it.durationMin != protocol.workDurationMinutes }) {
            errors += "${protocol.displayTitle}: cada repetição precisa manter exatamente ${protocol.workDurationMinutes} min."
        }
        if (recoverySegments.any { it.targetMode != "TIME" || it.durationMin != protocol.recoveryDurationMinutes }) {
            errors += "${protocol.displayTitle}: recuperação precisa manter ${protocol.recoveryDurationMinutes} min."
        }
        return errors
    }
}
