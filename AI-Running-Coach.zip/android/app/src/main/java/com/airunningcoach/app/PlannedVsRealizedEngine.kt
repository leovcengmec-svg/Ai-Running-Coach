package com.airunningcoach.app

import java.time.LocalDate
import kotlin.math.roundToInt

internal data class PlannedSessionEvidence(
    val sessionId: String,
    val date: LocalDate,
    val plannedDistanceKm: Double,
    val completed: Boolean
)

internal data class RealizedActivityEvidence(
    val sessionId: String,
    val date: LocalDate,
    val actualDistanceKm: Double
)

internal data class PlannedVsRealizedSnapshot(
    val windowDays: Int,
    val plannedSessions: Int,
    val completedSessions: Int,
    val adherencePercent: Int?,
    val plannedDistanceKm: Double,
    val realizedDistanceKm: Double,
    val activitiesWithMeasuredDistance: Int
)

/**
 * Compares sessions scheduled in the selected window with activities whose real distance
 * was recorded/imported. Completion without a measured distance counts for adherence only.
 * An unmatched completed activity can contribute to realized kilometres, but never changes
 * the denominator of planned-session adherence.
 */
internal object PlannedVsRealizedEngine {
    fun summarize(
        planned: List<PlannedSessionEvidence>,
        realized: List<RealizedActivityEvidence>,
        today: LocalDate = LocalDate.now(),
        windowDays: Int = 28
    ): PlannedVsRealizedSnapshot {
        require(windowDays in 1..366)
        val start = today.minusDays((windowDays - 1).toLong())
        val validPlanned = planned.filter { item ->
            !item.date.isBefore(start) && !item.date.isAfter(today) &&
                item.plannedDistanceKm.isFinite() && item.plannedDistanceKm in 0.0..200.0
        }.distinctBy { it.sessionId.ifBlank { "${it.date}:${it.plannedDistanceKm}" } }
        val validRealized = realized.filter { item ->
            !item.date.isBefore(start) && !item.date.isAfter(today) &&
                item.actualDistanceKm.isFinite() && item.actualDistanceKm in 0.001..200.0
        }.distinctBy { it.sessionId.ifBlank { "${it.date}:${it.actualDistanceKm}" } }
        val completed = validPlanned.count { it.completed }
        val adherence = if (validPlanned.isNotEmpty()) {
            (completed * 100.0 / validPlanned.size).roundToInt().coerceIn(0, 100)
        } else null
        return PlannedVsRealizedSnapshot(
            windowDays = windowDays,
            plannedSessions = validPlanned.size,
            completedSessions = completed,
            adherencePercent = adherence,
            plannedDistanceKm = round1(validPlanned.sumOf { it.plannedDistanceKm }),
            realizedDistanceKm = round1(validRealized.sumOf { it.actualDistanceKm }),
            activitiesWithMeasuredDistance = validRealized.size
        )
    }

    private fun round1(value: Double): Double = (value * 10.0).roundToInt() / 10.0
}
