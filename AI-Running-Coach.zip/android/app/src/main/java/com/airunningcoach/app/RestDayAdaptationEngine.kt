package com.airunningcoach.app

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.time.temporal.TemporalAdjusters
import java.time.DayOfWeek

/** Evidence used when an athlete asks to run on a day that was planned as recovery. */
internal data class RestDaySessionEvidence(
    val sessionId: String,
    val date: LocalDate,
    val title: String,
    val type: String,
    val distanceKm: Double,
    val done: Boolean,
    val optionalExtra: Boolean = false
)

internal data class RestDayFeedbackEvidence(
    val date: LocalDate,
    val effort: String,
    val feeling: String,
    val painPresent: Boolean,
    val actualDistanceKm: Double? = null
)

internal data class RestDayRecommendation(
    val targetDate: LocalDate,
    val action: String, // ADD_EASY (offers choices) or KEEP_REST
    val title: String,
    val explanation: String,
    val durationMin: Int = 0,
    val estimatedDistanceKm: Double = 0.0,
    val rpeRange: String = "2-3",
    val runWalkPattern: Boolean = false,
    val normalAvailable: Boolean = false,
    val normalDurationMin: Int = 0,
    val normalEstimatedDistanceKm: Double = 0.0,
    val normalRpeRange: String = "3-4",
    val normalRiskText: String = ""
) {
    val canAddWorkout: Boolean get() = action == "ADD_EASY"
}

/**
 * One-off day-off decisions. This never moves missed sessions or adds quality work.
 * It combines the current ISO week, the athlete's recent feedback and measured load.
 */
internal object RestDayAdaptationEngine {
    fun recommend(
        targetDate: LocalDate,
        today: LocalDate,
        sessions: List<RestDaySessionEvidence>,
        feedback: List<RestDayFeedbackEvidence>,
        raceDates: Set<LocalDate>,
        weeklyBaselineKm: Double?,
        longestRunLast30DaysKm: Double?,
        noviceOrReturner: Boolean,
        maxWeeklySessions: Int = 3
    ): RestDayRecommendation {
        fun rest(title: String, explanation: String) = RestDayRecommendation(
            targetDate, "KEEP_REST", title, explanation
        )

        if (targetDate.isBefore(today)) return rest("Dia passado", "A data selecionada já passou. O treinador não cria sessões retroativas.")
        if (targetDate.isAfter(today.plusDays(14))) return rest("Planejamento futuro", "A sugestão pontual fica limitada aos próximos 14 dias para não substituir a periodização futura.")
        if (targetDate in raceDates) return rest("Dia de competição", "Há uma competição cadastrada nesta data. Preserve a prova e não acrescente uma corrida.")
        if (sessions.any { it.date == targetDate }) return rest("Já existe uma sessão", "Este dia já possui treino no calendário. Use a sessão existente ou altere-a pelo fluxo de reagendamento.")

        val weekStart = targetDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val weekEnd = weekStart.plusDays(6)
        val weekSessions = sessions.filter { !it.date.isBefore(weekStart) && !it.date.isAfter(weekEnd) }
        if (weekSessions.any { it.optionalExtra }) return rest("Sessão adicional já utilizada", "O plano já recebeu uma sessão extra nesta semana. Evite acrescentar outra dose fora da programação.")
        val missedEarlierSession = sessions.any { session ->
            session.date.isBefore(today) && !session.done &&
                !session.date.isBefore(weekStart) && !session.date.isAfter(targetDate)
        }
        val unresolvedEarlierSession = sessions.any { session ->
            !session.done && !session.optionalExtra && !session.date.isBefore(today) && session.date.isBefore(targetDate)
        }
        if (unresolvedEarlierSession) {
            return rest("Aguarde a sessão programada", "Ainda existe um treino desta semana previsto antes da data escolhida. Conclua ou registre essa sessão primeiro e consulte novamente; assim o treinador decide com base no que realmente foi executado.")
        }
        val weeklyLimit = maxWeeklySessions.coerceIn(2, 6)
        // A missed past session is not counted as training load or as a used running day.
        // Future scheduled sessions still reserve their planned slots.
        val effectiveWeekSessions = weekSessions.count { it.done || !it.date.isBefore(today) }
        if (effectiveWeekSessions >= weeklyLimit) return rest("Frequência semanal já preenchida", "Há $effectiveWeekSessions sessões concluídas ou ainda programadas nesta semana, atingindo a frequência prevista de $weeklyLimit dias. Não é necessário acrescentar outra corrida.")

        val recentFeedback = feedback.filter { !it.date.isAfter(today) && !it.date.isBefore(today.minusDays(14)) }
            .sortedByDescending { it.date }
        if (recentFeedback.any { it.painPresent }) {
            return rest("Recuperação prioritária", "Há relato de dor nos últimos 14 dias. Não é apropriado adicionar corrida; retome apenas quando estiver sem dor e, se persistir, procure avaliação profissional.")
        }
        val highFatigueSignals = recentFeedback.take(3).count {
            it.effort in setOf("Pesado", "Muito pesado") || it.feeling in setOf("Cansado", "Muito cansado")
        }
        if (highFatigueSignals >= 2 || recentFeedback.firstOrNull()?.let {
                it.effort == "Muito pesado" || it.feeling == "Muito cansado"
            } == true
        ) {
            return rest("Fadiga elevada", "Os feedbacks recentes indicam esforço ou cansaço elevado. Não acrescente uma sessão; priorize recuperação e reavalie a próxima sessão programada.")
        }

        val recentWindow = sessions.filter { it.done && !it.date.isAfter(targetDate) && !it.date.isBefore(targetDate.minusDays(14)) }
        val closeHardSession = sessions.any { session ->
            val gap = kotlin.math.abs(ChronoUnit.DAYS.between(session.date, targetDate))
            session.done && session.date != targetDate && gap in 0..2 && isDemanding(session)
        }
        if (closeHardSession) {
            return rest("Proteja a recuperação", "Há um treino exigente ou longão previsto/realizado dentro dos últimos dois dias de calendário. Como o horário exato não está registrado, o treinador usa uma margem conservadora e recomenda descanso ou mobilidade leve.")
        }
        val priorRunDays = recentWindow.map { it.date }.distinct().size
        if (priorRunDays == 0) return rest("Base insuficiente", "Não há atividade recente suficiente para calcular uma sessão adicional com segurança. Siga a programação principal e atualize o histórico.")

        val recentLongest = longestRunLast30DaysKm?.takeIf { it > 0.0 }
        val profileBaseline = weeklyBaselineKm?.takeIf { it > 0.0 }
        if (recentLongest == null && profileBaseline == null) {
            return rest("Carga sem referência", "O treinador ainda não tem volume semanal ou maior corrida recente confiáveis. Atualize o perfil ou registre uma atividade antes de acrescentar treino.")
        }
        // Extra doses are deliberately short and scaled to both the profile baseline
        // and the longest recent run; this is not treated as a universal 10% rule.
        val easyKm = minOf(
            2.0,
            (recentLongest ?: (profileBaseline!! * 0.25)) * 0.35,
            profileBaseline?.let { it * 0.12 } ?: Double.POSITIVE_INFINITY
        ).coerceAtLeast(0.8)
        val easyDuration = if (noviceOrReturner) {
            if (easyKm >= 1.5) 15 else 12
        } else (easyKm * 7.5).toInt().coerceIn(15, 20)
        val easyRunningMinutes = if (noviceOrReturner) ((easyDuration - 4).coerceAtLeast(6) * 2 / 3) else easyDuration
        val easyEstimatedKm = (easyRunningMinutes / 7.5).coerceAtMost(easyKm)

        // The second option is deliberately a modest aerobic (Z2) session, not quality.
        // It carries a higher load and is shown with an explicit risk statement for consent.
        val normalKm = minOf(
            3.0,
            (recentLongest ?: (profileBaseline!! * 0.25)) * 0.50,
            profileBaseline?.let { it * 0.18 } ?: Double.POSITIVE_INFINITY
        )
        val normalAvailable = normalKm >= 1.5 && priorRunDays >= 1
        val normalDuration = if (noviceOrReturner) 18 else (normalKm * 7.5).toInt().coerceIn(15, 25)
        val normalEstimatedKm = if (noviceOrReturner) {
            val mainMinutes = (normalDuration - 6).coerceAtLeast(6)
            val runMinutes = 2 * (mainMinutes / 3).coerceAtLeast(2)
            runMinutes / 7.5
        } else minOf(normalKm, normalDuration / 7.5)
        val missedNote = if (missedEarlierSession) " Há sessão anterior sem registro: esta opção não a repõe nem transfere; é uma atividade extra e voluntária." else ""

        return RestDayRecommendation(
            targetDate = targetDate,
            action = "ADD_EASY",
            title = "Duas opções para este dia livre",
            explanation = "O treinador considerou os treinos realmente concluídos, a carga recente e os feedbacks. Você pode escolher uma opção leve ou uma rodagem aeróbia normal; nenhuma será inserida sem sua confirmação. A programação principal permanece intacta.$missedNote",
            durationMin = easyDuration,
            estimatedDistanceKm = easyEstimatedKm,
            rpeRange = "2-3",
            runWalkPattern = noviceOrReturner,
            normalAvailable = normalAvailable,
            normalDurationMin = normalDuration,
            normalEstimatedDistanceKm = normalEstimatedKm,
            normalRpeRange = "3-4",
            normalRiskText = "Carga maior que a opção leve: aumenta o volume semanal e pode gerar fadiga antes da próxima sessão. Mantenha Z2 confortável, sem acelerar; escolha apenas se estiver descansado e sem dor."
        )
    }

    private fun isDemanding(session: RestDaySessionEvidence): Boolean {
        val text = "${session.type} ${session.title}".lowercase()
        return text.contains("qualidade") || text.contains("limiar") || text.contains("interval") ||
            text.contains("fartlek") || text.contains("tempo") || text.contains("long") ||
            text.contains("progress") || session.distanceKm >= 12.0
    }
}
