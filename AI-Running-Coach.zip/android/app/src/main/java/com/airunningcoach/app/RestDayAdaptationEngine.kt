package com.airunningcoach.app

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.time.temporal.TemporalAdjusters
import java.time.DayOfWeek

/** Evidence used when an athlete asks to run on a day that was planned as recovery. */
internal data class RestDaySessionEvidence(
    val sessionId: String,
    val date: LocalDate,
    val title: String,
    val type: String,
    val distanceKm: Double,
    val done: Boolean,
    val optionalExtra: Boolean = false
)

internal data class RestDayFeedbackEvidence(
    val date: LocalDate,
    val effort: String,
    val feeling: String,
    val painPresent: Boolean,
    val actualDistanceKm: Double? = null
)

internal data class RestDayRecommendation(
    val targetDate: LocalDate,
    val action: String, // ADD_EASY (offers choices) or KEEP_REST
    val title: String,
    val explanation: String,
    val durationMin: Int = 0,
    val estimatedDistanceKm: Double = 0.0,
    val rpeRange: String = "2-3",
    val runWalkPattern: Boolean = false,
    val normalAvailable: Boolean = false,
    val normalDurationMin: Int = 0,
    val normalEstimatedDistanceKm: Double = 0.0,
    val normalRpeRange: String = "3-4",
    val normalRiskText: String = "",
    val riskLevel: String = "LOW",
    val riskText: String = ""
) {
    val canAddWorkout: Boolean get() = action == "ADD_EASY"
}

/**
 * One-off day-off decisions. This never moves missed sessions or adds quality work.
 * It combines the current ISO week, the athlete's recent feedback and measured load.
 */
internal object RestDayAdaptationEngine {
    fun recommend(
        targetDate: LocalDate,
        today: LocalDate,
        sessions: List<RestDaySessionEvidence>,
        feedback: List<RestDayFeedbackEvidence>,
        raceDates: Set<LocalDate>,
        weeklyBaselineKm: Double?,
        longestRunLast30DaysKm: Double?,
        noviceOrReturner: Boolean,
        maxWeeklySessions: Int = 3
    ): RestDayRecommendation {
        fun rest(title: String, explanation: String) = RestDayRecommendation(
            targetDate, "KEEP_REST", title, explanation
        )

        if (targetDate.isBefore(today)) return rest("Data passada", "A sessão adicional só pode ser inserida hoje ou em uma data futura.")
        if (sessions.any { it.date == targetDate }) {
            return rest("Dia com treino programado", "A consulta de treino extra está disponível somente em dias livres/descanso. Esta data já possui uma sessão programada.")
        }
        if (targetDate in raceDates) {
            return rest("Dia de competição", "A consulta de treino extra está disponível somente em dias livres/descanso. Esta data possui uma competição cadastrada.")
        }
        val warnings = mutableListOf<String>()
        if (targetDate.isAfter(today.plusDays(14))) {
            warnings += "A data está a mais de 14 dias. A opção é uma projeção com base no condicionamento atual; reavalie a carga e a recuperação mais perto do dia escolhido. A decisão de incluir continua sendo sua."
        }
        val weekStart = targetDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val weekEnd = weekStart.plusDays(6)
        val weekSessions = sessions.filter { !it.date.isBefore(weekStart) && !it.date.isAfter(weekEnd) }
        val missedEarlierSession = sessions.any { session ->
            session.date.isBefore(today) && !session.done && !session.date.isBefore(weekStart) && !session.date.isAfter(targetDate)
        }
        val unresolvedEarlierSession = sessions.any { session ->
            !session.done && !session.optionalExtra && !session.date.isBefore(today) && session.date.isBefore(targetDate)
        }
        val effectiveWeekSessions = weekSessions.count { it.done || !it.date.isBefore(today) }
        val weeklyLimit = maxWeeklySessions.coerceIn(2, 6)
        if (effectiveWeekSessions >= weeklyLimit) {
            warnings += "A semana já tem $effectiveWeekSessions sessões concluídas ou programadas (referência do perfil: $weeklyLimit). A sessão extra aumentará a frequência planejada."
        }
        if (unresolvedEarlierSession) {
            warnings += "Há treino programado antes desta data ainda sem registro. A sessão extra não substitui nem cancela esse treino; confira sua recuperação antes de decidir."
        }
        if (missedEarlierSession) {
            warnings += "Há sessão anterior sem registro. Esta opção é adicional: não repõe, transfere nem apaga o treino perdido."
        }
        if (weekSessions.any { it.optionalExtra }) {
            warnings += "Esta semana já contém uma sessão extra. Uma nova inclusão elevará ainda mais o volume semanal."
        }
        val recentFeedback = feedback.filter { !it.date.isAfter(today) && !it.date.isBefore(today.minusDays(14)) }
            .sortedByDescending { it.date }
        val hasRecentPain = recentFeedback.any { it.painPresent }
        if (hasRecentPain) {
            warnings += "ALERTA DE DOR: existe relato de dor nos últimos 14 dias. O treinador não recomenda corrida adicional enquanto houver dor; priorize descanso e avaliação adequada. A decisão de inclusão permanece com o corredor."
        }
        val highFatigueSignals = recentFeedback.take(3).count {
            it.effort in setOf("Pesado", "Muito pesado") || it.feeling in setOf("Cansado", "Muito cansado")
        }
        val severeFatigue = highFatigueSignals >= 2 || recentFeedback.firstOrNull()?.let {
            it.effort == "Muito pesado" || it.feeling == "Muito cansado"
        } == true
        if (severeFatigue) {
            warnings += "ALERTA DE FADIGA: os feedbacks recentes indicam cansaço/esforço elevado. Uma sessão extra pode atrasar a recuperação; considere descanso ou apenas caminhada leve."
        }

        val recentWindow = sessions.filter { it.done && !it.date.isAfter(targetDate) && !it.date.isBefore(targetDate.minusDays(14)) }
        val closeHardSession = sessions.any { session ->
            val gap = kotlin.math.abs(ChronoUnit.DAYS.between(session.date, targetDate))
            gap in 0..2 && isDemanding(session)
        }
        if (closeHardSession) {
            warnings += "Existe treino exigente ou longão dentro de dois dias. A atividade adicional pode reduzir a recuperação e comprometer a próxima sessão."
        }
        val priorRunDays = recentWindow.map { it.date }.distinct().size
        if (priorRunDays == 0) {
            warnings += "Há poucos registros de corrida recente para estimar sua resposta individual. A opção leve será curta e conservadora."
        }

        val recentLongest = longestRunLast30DaysKm?.takeIf { it > 0.0 }
        val profileBaseline = weeklyBaselineKm?.takeIf { it > 0.0 }
        val hasLoadReference = recentLongest != null || profileBaseline != null
        if (!hasLoadReference) {
            warnings += "O histórico não oferece volume semanal nem maior corrida recente confiáveis. A distância não será estimada; a opção será orientada por tempo."
        }

        // The 3-5 km range depends on demonstrated/reported load, not only the
        // experience label. An athlete marked as beginner may still have a stable
        // 16 km/week base and a recent 10 km run; in that case the distance is valid,
        // while the session can still use run/walk and a slower duration estimate.
        val supportsThreeToFiveKm =
            (profileBaseline ?: 0.0) >= 14.0 && (recentLongest ?: 0.0) >= 7.0
        val readinessMultiplier = when {
            hasRecentPain -> 0.60
            severeFatigue -> 0.75
            highFatigueSignals == 1 -> 0.90
            closeHardSession -> 0.85
            else -> 1.0
        }
        val easyBaseKm = if (supportsThreeToFiveKm) {
            minOf(5.0, profileBaseline!! * 0.22, recentLongest!! * 0.45)
        } else if (hasLoadReference) {
            minOf(2.0, (recentLongest ?: (profileBaseline!! * 0.25)) * 0.35,
                profileBaseline?.let { it * 0.12 } ?: Double.POSITIVE_INFINITY).coerceAtLeast(0.8)
        } else 0.0
        val normalBaseKm = if (supportsThreeToFiveKm) {
            minOf(5.0, profileBaseline!! * 0.28, recentLongest!! * 0.55)
        } else if (hasLoadReference) {
            minOf(3.0, (recentLongest ?: (profileBaseline!! * 0.25)) * 0.50,
                profileBaseline?.let { it * 0.18 } ?: Double.POSITIVE_INFINITY)
        } else 0.0
        fun roundKm(value: Double): Double = kotlin.math.round(value * 10.0) / 10.0
        val easyKm = if (hasLoadReference) roundKm(easyBaseKm * readinessMultiplier) else 0.0
        val normalKm = if (hasLoadReference) roundKm(normalBaseKm * readinessMultiplier) else 0.0
        val durationPace = if (noviceOrReturner) 9.0 else 7.5
        fun estimatedDuration(distanceKm: Double): Int {
            val target = (distanceKm * durationPace + 0.5).toInt().coerceIn(15, 50)
            if (!noviceOrReturner) return target.coerceIn(15, 40)
            // Keep duration aligned with the 2-min run / 1-min walk segment repeats
            // that are actually generated when the athlete is in run-walk mode.
            val repetitions = kotlin.math.ceil((target - 6).coerceAtLeast(6) / 3.0).toInt().coerceAtLeast(2)
            return 6 + repetitions * 3
        }
        val easyDuration = when {
            !hasLoadReference -> 12
            supportsThreeToFiveKm -> estimatedDuration(easyKm)
            noviceOrReturner -> if (easyKm >= 1.5) 15 else 12
            else -> estimatedDuration(easyKm)
        }
        val easyRunningMinutes = if (noviceOrReturner) {
            ((easyDuration - 4).coerceAtLeast(6) * 2 / 3)
        } else easyDuration
        val easyEstimatedKm = if (!hasLoadReference) 0.0 else if (supportsThreeToFiveKm) easyKm
            else roundKm((easyRunningMinutes / 7.5).coerceAtMost(easyKm))

        // Always offer a second, moderate Z2 choice. Its distance grows only when the
        // weekly baseline and recent longest run support it; the athlete retains the choice.
        val normalAvailable = true
        val normalDuration = when {
            !hasLoadReference -> 15
            supportsThreeToFiveKm -> estimatedDuration(normalKm)
            noviceOrReturner -> 18
            else -> estimatedDuration(normalKm)
        }
        val normalEstimatedKm = if (!hasLoadReference) 0.0 else if (supportsThreeToFiveKm) normalKm else if (noviceOrReturner) {
            val mainMinutes = (normalDuration - 6).coerceAtLeast(6)
            val runMinutes = 2 * (mainMinutes / 3).coerceAtLeast(2)
            roundKm((runMinutes / 7.5).coerceAtMost(normalKm))
        } else roundKm(minOf(normalKm, normalDuration / 7.5))

        val highRisk = hasRecentPain || severeFatigue
        val riskLevel = when {
            highRisk -> "HIGH"
            warnings.isNotEmpty() -> "MODERATE"
            else -> "LOW"
        }
        if (supportsThreeToFiveKm && readinessMultiplier == 1.0) {
            warnings += "Volume semanal e maior corrida recente permitem opções adicionais entre 3 e 5 km; a dose leve e a moderada são limitadas pelo histórico de carga."
        } else if (supportsThreeToFiveKm && readinessMultiplier < 1.0) {
            warnings += "Os sinais recentes de recuperação reduziram a distância sugerida; não force a faixa de 3 a 5 km quando houver fadiga ou dor."
        } else if (!supportsThreeToFiveKm) {
            warnings += "O histórico ainda não permite estimar uma distância extra de 3 a 5 km. A opção permanece curta ou por tempo; a falta de dados não ativa corrida/caminhada automaticamente."
        }
        val riskText = warnings.distinct().joinToString("\n")
            .ifBlank { "Sem alerta adicional identificado pelos dados disponíveis. A sessão continua sendo opcional e aumenta a carga semanal." }
        val missedNote = if (missedEarlierSession) " Há sessão anterior sem registro; esta atividade não a repõe nem transfere." else ""

        return RestDayRecommendation(
            targetDate = targetDate,
            action = "ADD_EASY",
            title = "Opções de treino extra para este dia",
            explanation = "O treinador apresenta opções e os riscos estimados. Nenhuma sessão será inserida automaticamente; o corredor decide se aceita, sabendo que a programação principal não será alterada.$missedNote",
            durationMin = easyDuration,
            estimatedDistanceKm = easyEstimatedKm,
            rpeRange = if (highRisk) "1-2" else "2-3",
            runWalkPattern = noviceOrReturner,
            normalAvailable = normalAvailable,
            normalDurationMin = normalDuration,
            normalEstimatedDistanceKm = normalEstimatedKm,
            normalRpeRange = "3-4",
            normalRiskText = if (hasLoadReference) {
                "Carga superior à opção leve: aumenta volume e fadiga. Mantenha Z2 confortável; não acelere nem tente compensar treinos perdidos."
            } else {
                "Sem histórico suficiente para estimar distância ou resposta individual. Esta opção é somente por tempo, sem presumir pausas de caminhada; mantenha corrida contínua apenas se já tiver essa capacidade."
            },
            riskLevel = riskLevel,
            riskText = riskText
        )
    }

    private fun isDemanding(session: RestDaySessionEvidence): Boolean {
        val text = "${session.type} ${session.title}".lowercase()
        return text.contains("qualidade") || text.contains("limiar") || text.contains("interval") ||
            text.contains("fartlek") || text.contains("tempo") || text.contains("long") ||
            text.contains("progress") || session.distanceKm >= 12.0
    }
}
