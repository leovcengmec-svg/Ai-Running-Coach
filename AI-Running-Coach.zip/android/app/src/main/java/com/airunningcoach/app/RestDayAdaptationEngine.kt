package com.airunningcoach.app

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.time.temporal.TemporalAdjusters
import java.time.DayOfWeek

/** Evidence used when an athlete asks to run on a day that was planned as recovery. */
internal data class RestDaySessionEvidence(
    val sessionId: String,
    val date: LocalDate,
    val title: String,
    val type: String,
    val distanceKm: Double,
    val done: Boolean,
    val optionalExtra: Boolean = false
)

internal data class RestDayFeedbackEvidence(
    val date: LocalDate,
    val effort: String,
    val feeling: String,
    val painPresent: Boolean,
    val actualDistanceKm: Double? = null
)

internal data class RestDayRecommendation(
    val targetDate: LocalDate,
    val action: String, // ADD_EASY or KEEP_REST
    val title: String,
    val explanation: String,
    val durationMin: Int = 0,
    val estimatedDistanceKm: Double = 0.0,
    val rpeRange: String = "2-3",
    val runWalkPattern: Boolean = false
) {
    val canAddWorkout: Boolean get() = action == "ADD_EASY"
}

/**
 * One-off day-off decisions. This never moves missed sessions or adds quality work.
 * It combines the current ISO week, the athlete's recent feedback and measured load.
 */
internal object RestDayAdaptationEngine {
    fun recommend(
        targetDate: LocalDate,
        today: LocalDate,
        sessions: List<RestDaySessionEvidence>,
        feedback: List<RestDayFeedbackEvidence>,
        raceDates: Set<LocalDate>,
        weeklyBaselineKm: Double?,
        longestRunLast30DaysKm: Double?,
        noviceOrReturner: Boolean,
        maxWeeklySessions: Int = 3
    ): RestDayRecommendation {
        fun rest(title: String, explanation: String) = RestDayRecommendation(
            targetDate, "KEEP_REST", title, explanation
        )

        if (targetDate.isBefore(today)) return rest("Dia passado", "A data selecionada já passou. O treinador não cria sessões retroativas.")
        if (targetDate.isAfter(today.plusDays(14))) return rest("Planejamento futuro", "A sugestão pontual fica limitada aos próximos 14 dias para não substituir a periodização futura.")
        if (targetDate in raceDates) return rest("Dia de competição", "Há uma competição cadastrada nesta data. Preserve a prova e não acrescente uma corrida.")
        if (sessions.any { it.date == targetDate }) return rest("Já existe uma sessão", "Este dia já possui treino no calendário. Use a sessão existente ou altere-a pelo fluxo de reagendamento.")

        val weekStart = targetDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val weekEnd = weekStart.plusDays(6)
        val weekSessions = sessions.filter { !it.date.isBefore(weekStart) && !it.date.isAfter(weekEnd) }
        if (weekSessions.any { it.optionalExtra }) return rest("Sessão adicional já utilizada", "O plano já recebeu uma sessão extra nesta semana. Evite acrescentar outra dose fora da programação.")
        val missedEarlierSession = sessions.any { session ->
            session.date.isBefore(today) && !session.done &&
                !session.date.isBefore(weekStart) && !session.date.isAfter(targetDate)
        }
        if (missedEarlierSession) {
            return rest("Não compense treino perdido", "Há uma sessão anterior da semana sem registro de conclusão. O treinador não transfere nem repõe automaticamente um treino perdido em um dia de descanso.")
        }
        val unresolvedEarlierSession = sessions.any { session ->
            !session.done && !session.optionalExtra && !session.date.isBefore(today) && session.date.isBefore(targetDate)
        }
        if (unresolvedEarlierSession) {
            return rest("Aguarde a sessão programada", "Ainda existe um treino desta semana previsto antes da data escolhida. Conclua ou registre essa sessão primeiro e consulte novamente; assim o treinador decide com base no que realmente foi executado.")
        }
        val weeklyLimit = maxWeeklySessions.coerceIn(2, 6)
        if (weekSessions.size >= weeklyLimit) return rest("Carga semanal suficiente", "Já há ${weekSessions.size} sessões previstas ou realizadas nesta semana, atingindo a frequência planejada de $weeklyLimit dias. O melhor ajuste é preservar a recuperação.")

        val recentFeedback = feedback.filter { !it.date.isAfter(today) && !it.date.isBefore(today.minusDays(14)) }
            .sortedByDescending { it.date }
        if (recentFeedback.any { it.painPresent }) {
            return rest("Recuperação prioritária", "Há relato de dor nos últimos 14 dias. Não é apropriado adicionar corrida; retome apenas quando estiver sem dor e, se persistir, procure avaliação profissional.")
        }
        val highFatigueSignals = recentFeedback.take(3).count {
            it.effort in setOf("Pesado", "Muito pesado") || it.feeling in setOf("Cansado", "Muito cansado")
        }
        if (highFatigueSignals >= 2 || recentFeedback.firstOrNull()?.let {
                it.effort == "Muito pesado" || it.feeling == "Muito cansado"
            } == true
        ) {
            return rest("Fadiga elevada", "Os feedbacks recentes indicam esforço ou cansaço elevado. Não acrescente uma sessão; priorize recuperação e reavalie a próxima sessão programada.")
        }

        val recentWindow = sessions.filter { it.done && !it.date.isAfter(targetDate) && !it.date.isBefore(targetDate.minusDays(14)) }
        val closeHardSession = sessions.any { session ->
            val gap = kotlin.math.abs(ChronoUnit.DAYS.between(session.date, targetDate))
            session.date != targetDate && gap in 0..2 && isDemanding(session)
        }
        if (closeHardSession) {
            return rest("Proteja a recuperação", "Há um treino exigente ou longão previsto/realizado dentro dos últimos dois dias de calendário. Como o horário exato não está registrado, o treinador usa uma margem conservadora e recomenda descanso ou mobilidade leve.")
        }
        val priorRunDays = recentWindow.map { it.date }.distinct().size
        if (priorRunDays == 0) return rest("Base insuficiente", "Não há atividade recente suficiente para calcular uma sessão adicional com segurança. Siga a programação principal e atualize o histórico.")

        val recentLongest = longestRunLast30DaysKm?.takeIf { it > 0.0 }
        val profileBaseline = weeklyBaselineKm?.takeIf { it > 0.0 }
        if (recentLongest == null && profileBaseline == null) {
            return rest("Carga sem referência", "O treinador ainda não tem volume semanal ou maior corrida recente confiáveis. Atualize o perfil ou registre uma atividade antes de acrescentar treino.")
        }
        // Extra dose is deliberately short, Z1-only and smaller than a recent long run.
        // Weekly baseline scales the proposed dose; it is not treated as a universal 10% rule.
        val maxExtraKm = minOf(
            2.5,
            (recentLongest ?: (profileBaseline!! * 0.25)) * 0.35,
            profileBaseline?.let { it * 0.12 } ?: Double.POSITIVE_INFINITY
        )
        val maxDuration = if (noviceOrReturner) 15 else 20
        val duration = (maxExtraKm * 7.5).toInt().coerceIn(if (noviceOrReturner) 12 else 15, maxDuration)
        val estimatedRunningMinutes = if (noviceOrReturner) {
            2 * (((duration - 6).coerceAtLeast(6)) / 3).coerceAtLeast(2)
        } else duration
        val estimatedKm = estimatedRunningMinutes / 7.5
        if (recentLongest != null && estimatedKm > recentLongest * 0.35 + 0.05) {
            return rest("Dose adicional excessiva", "Mesmo uma sessão leve ultrapassaria a margem conservadora calculada a partir da maior corrida recente.")
        }

        return RestDayRecommendation(
            targetDate = targetDate,
            action = "ADD_EASY",
            title = if (noviceOrReturner) "Corrida-caminhada muito leve" else "Rodagem extra de recuperação",
            explanation = "O treinador considerou as sessões da semana, a distância recente e os feedbacks. Há espaço para uma única sessão curta em Z1, sem intervalos e sem alterar os treinos principais. Interrompa se surgir dor ou o esforço deixar de ser confortável.",
            durationMin = duration,
            estimatedDistanceKm = estimatedKm,
            rpeRange = "2-3",
            runWalkPattern = noviceOrReturner
        )
    }

    private fun isDemanding(session: RestDaySessionEvidence): Boolean {
        val text = "${session.type} ${session.title}".lowercase()
        return text.contains("qualidade") || text.contains("limiar") || text.contains("interval") ||
            text.contains("fartlek") || text.contains("tempo") || text.contains("long") ||
            text.contains("progress") || session.distanceKm >= 12.0
    }
}
