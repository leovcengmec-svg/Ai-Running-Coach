package com.airunningcoach.app

/** Maps measured pace samples and device laps to pace zones without filling timestamp gaps. */
internal object ActivityZoneTimeEngine {
    private const val MAX_TRACK_SAMPLE_SECONDS = 120
    private const val MAX_EXPLICIT_LAP_SECONDS = 7_200
    private val aggregateSources = setOf(
        "EXPLICIT_LAP", "EXPLICIT_LAP_AGGREGATED", "LAP_RECONSTRUCTED", "TRACK_SPLIT_RECONSTRUCTED"
    )

    /** Full-lap and reconstructed kilometre splits may represent several minutes; raw GPS samples may not. */
    fun maxDurationForSource(sourceType: String): Int =
        if (sourceType in aggregateSources) MAX_EXPLICIT_LAP_SECONDS else MAX_TRACK_SAMPLE_SECONDS

    fun summarize(segments: List<ActivityPaceSegment>, zones: List<PaceZone>): Map<String, Int> {
        if (segments.isEmpty() || zones.isEmpty()) return emptyMap()
        val totals = mutableMapOf<String, Int>()
        segments.forEach { segment ->
            if (segment.durationSeconds !in 1..maxDurationForSource(segment.sourceType) ||
                segment.paceSecondsPerKm !in 120..1800) return@forEach
            val zone = zones.firstOrNull { segment.paceSecondsPerKm in it.range.fastestPaceValue..it.range.slowestPaceValue }
                ?: return@forEach
            totals[zone.id] = (totals[zone.id] ?: 0) + segment.durationSeconds
        }
        return totals.toSortedMap()
    }
}
