package com.airunningcoach.app

/** Maps timestamped pace segments to the active pace-zone bands without filling data gaps. */
internal object ActivityZoneTimeEngine {
    fun summarize(segments: List<ActivityPaceSegment>, zones: List<PaceZone>): Map<String, Int> {
        if (segments.isEmpty() || zones.isEmpty()) return emptyMap()
        val totals = mutableMapOf<String, Int>()
        segments.forEach { segment ->
            if (segment.sourceType == "EXPLICIT_LAP" || segment.paceSecondsPerKm !in 120..1800 || segment.durationSeconds !in 1..120) return@forEach
            val zone = zones.firstOrNull { segment.paceSecondsPerKm in it.range.fastestPaceValue..it.range.slowestPaceValue }
                ?: return@forEach
            totals[zone.id] = (totals[zone.id] ?: 0) + segment.durationSeconds
        }
        return totals.toSortedMap()
    }
}
