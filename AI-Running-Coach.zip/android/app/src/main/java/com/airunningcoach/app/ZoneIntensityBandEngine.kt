package com.airunningcoach.app

/** A faixa é a posição percentual dentro da zona operacional (0=lento, 100=rápido). */
internal data class ActiveZoneBand(val minPercent: Int, val maxPercent: Int) {
    init { require(minPercent in 0..99 && maxPercent in 1..100 && minPercent < maxPercent) }
}

internal object ZoneIntensityBandEngine {
    /** Política legada/conservadora para iniciantes e sessões sem perfil de experiência. */
    val z1WarmupCoolDownBand = ActiveZoneBand(80, 100)
    /** Transição aeróbia: borda lenta da Z2. */
    val z2EasyTransitionBand = ActiveZoneBand(0, 20)

    fun paceAtPercent(fullZone: PaceRange, percent: Int): Int {
        val p = percent.coerceIn(0, 100)
        val span = fullZone.slowestPaceValue - fullZone.fastestPaceValue
        return (fullZone.slowestPaceValue - span * (p / 100.0)).toInt()
    }

    fun activeRange(fullZone: PaceRange, band: ActiveZoneBand): PaceRange {
        val faster = paceAtPercent(fullZone, band.maxPercent)
        val slower = paceAtPercent(fullZone, band.minPercent)
        return PaceRange(faster.coerceAtLeast(fullZone.fastestPaceValue), slower.coerceAtMost(fullZone.slowestPaceValue))
    }

    /** Public helper used by protocol builders: any valid sub-range can be assigned in Z2–Z5. */
    fun applyBand(segment: WorkoutSegment, zone: PaceZone, band: ActiveZoneBand): WorkoutSegment {
        val range = activeRange(zone.range, band)
        return segment.copy(
            paceZone = zone.id,
            targetPaceMinValue = range.fastestPaceValue,
            targetPaceMaxValue = range.slowestPaceValue,
            zoneBasePaceFastValue = zone.range.fastestPaceValue,
            zoneBasePaceSlowValue = zone.range.slowestPaceValue,
            zoneIntensityMinPercent = band.minPercent,
            zoneIntensityMaxPercent = band.maxPercent
        )
    }

    fun apply(workout: PrescribedWorkout): PrescribedWorkout {
        val isRunWalk = workout.stimulus.startsWith("BEGINNER_RUN_WALK")
        val segments = workout.segments.map { segment ->
            val transition = isWarmupOrCooldown(segment.name) && workout.experienceMonths >= 6 && !isRunWalk
            if (transition) applyExperiencedTransition(segment, workout.paceCalibrationSnapshot?.zoneRanges)
            else apply(workout.type, workout.title, workout.phase, segment)
        }
        return workout.copy(segments = segments,
            durationMin = WorkoutDurationEstimator.estimateMinutes(segments, workout.distanceKm, workout.durationMin))
    }

    fun apply(workout: Workout): Workout {
        val isRunWalk = workout.stimulus.startsWith("BEGINNER_RUN_WALK")
        val segments = workout.segments.map { segment ->
            val transition = isWarmupOrCooldown(segment.name) && workout.experienceMonths >= 6 && !isRunWalk
            if (transition) applyExperiencedTransition(segment, workout.paceCalibrationSnapshot?.zoneRanges)
            else apply(workout.type, workout.title, workout.phase, segment)
        }
        return workout.copy(segments = segments,
            durationMin = WorkoutDurationEstimator.estimateMinutes(segments, workout.distanceKm, workout.durationMin))
    }

    fun apply(type: String, title: String, phase: String, segment: WorkoutSegment): WorkoutSegment {
        if (segment.recoveryMode == "PASSIVE") return segment.copy(
            targetMode = "TIME", distanceKm = null,
            targetPaceMinValue = null, targetPaceMaxValue = null, paceZone = null,
            zoneBasePaceFastValue = null, zoneBasePaceSlowValue = null,
            zoneIntensityMinPercent = null, zoneIntensityMaxPercent = null
        )
        if (segment.recoveryMode == "WALK") return segment.copy(
            targetPaceMinValue = null, targetPaceMaxValue = null, paceZone = null,
            zoneBasePaceFastValue = null, zoneBasePaceSlowValue = null,
            zoneIntensityMinPercent = null, zoneIntensityMaxPercent = null
        )
        if (segment.paceZone == null) return segment
        val currentFast = segment.targetPaceMinValue ?: return segment
        val currentSlow = segment.targetPaceMaxValue ?: return segment
        val fullFast = segment.zoneBasePaceFastValue ?: currentFast
        val fullSlow = segment.zoneBasePaceSlowValue ?: currentSlow
        if (fullFast <= 0 || fullSlow <= fullFast) return segment

        val hasExplicitBand = segment.zoneIntensityMinPercent != null && segment.zoneIntensityMaxPercent != null
        val selectedBand = if (hasExplicitBand) ActiveZoneBand(segment.zoneIntensityMinPercent!!, segment.zoneIntensityMaxPercent!!)
            else chooseBand(type, title, segment)
        val session = "$type $title".lowercase()
        val recoveryPhase = phase.equals("RECOVERY", ignoreCase = true) || session.contains("regener") || session.contains("recuper")
        // Explicitly authored bands are never silently narrowed by a recovery-week heuristic.
        val band = if (recoveryPhase && !hasExplicitBand) {
            ActiveZoneBand(selectedBand.minPercent.coerceAtMost(10), minOf(selectedBand.maxPercent, 40).coerceAtLeast(selectedBand.minPercent.coerceAtMost(10) + 1))
        } else selectedBand
        val active = activeRange(PaceRange(fullFast, fullSlow), band)
        return segment.copy(targetPaceMinValue = active.fastestPaceValue, targetPaceMaxValue = active.slowestPaceValue,
            zoneBasePaceFastValue = fullFast, zoneBasePaceSlowValue = fullSlow,
            zoneIntensityMinPercent = band.minPercent, zoneIntensityMaxPercent = band.maxPercent)
    }

    private fun applyExperiencedTransition(segment: WorkoutSegment, zoneRanges: Map<String, String>?): WorkoutSegment {
        val z2 = zoneRanges?.get("Z2")?.let(::parseRange)
        if (z2 == null) return segment.copy(
            instruction = "Etapa de transição em Z2 0–20%. O ritmo numérico aparecerá após um teste de desempenho válido.",
            paceZone = "Z2", targetPaceMinValue = null, targetPaceMaxValue = null,
            zoneBasePaceFastValue = null, zoneBasePaceSlowValue = null,
            zoneIntensityMinPercent = 0, zoneIntensityMaxPercent = 20
        )
        val band = z2EasyTransitionBand
        val active = activeRange(z2, band)
        val isWarmup = segment.name.contains("aquec", true) || segment.name.contains("warmup", true)
        val instruction = if (isWarmup) "Aqueça em Z2 na faixa 0–20%: comece na parte mais lenta da zona e acelere somente se a respiração estiver confortável."
            else "Desaqueça em Z2 na faixa 0–20%: reduza gradualmente sem precisar correr artificialmente lento em Z1."
        return segment.copy(instruction = instruction, paceZone = "Z2",
            targetPaceMinValue = active.fastestPaceValue, targetPaceMaxValue = active.slowestPaceValue,
            zoneBasePaceFastValue = z2.fastestPaceValue, zoneBasePaceSlowValue = z2.slowestPaceValue,
            zoneIntensityMinPercent = band.minPercent, zoneIntensityMaxPercent = band.maxPercent)
    }

    private fun parseRange(label: String): PaceRange? {
        val text = label.substringBefore(" min/km").trim()
        val parts = text.split('–', '-')
        if (parts.size != 2) return null
        val fast = PaceRange.parsePace(parts[0].trim()) ?: return null
        val slow = PaceRange.parsePace(parts[1].trim()) ?: return null
        return runCatching { PaceRange(fast, slow) }.getOrNull()
    }

    private fun isWarmupOrCooldown(name: String): Boolean =
        name.contains("aquec", true) || name.contains("warmup", true) ||
            name.contains("desaquec", true) || name.contains("cooldown", true)

    private fun chooseBand(type: String, title: String, segment: WorkoutSegment): ActiveZoneBand {
        val name = segment.name.lowercase()
        val session = "$type $title".lowercase()
        val zone = segment.paceZone?.uppercase() ?: return ActiveZoneBand(0, 100)
        return when {
            name.contains("recuper") || name.contains("caminhada") || name.contains("pausa") -> ActiveZoneBand(0, 20)
            isWarmupOrCooldown(segment.name) && zone == "Z1" -> z1WarmupCoolDownBand
            zone == "Z1" -> ActiveZoneBand(0, 40)
            zone == "Z2" && session.contains("longo") -> ActiveZoneBand(10, 55)
            zone == "Z2" -> ActiveZoneBand(20, 65)
            zone == "Z3" -> ActiveZoneBand(20, 60)
            zone == "Z4" -> ActiveZoneBand(25, 65)
            zone == "Z5" -> ActiveZoneBand(20, 60)
            else -> ActiveZoneBand(10, 55)
        }
    }
}
