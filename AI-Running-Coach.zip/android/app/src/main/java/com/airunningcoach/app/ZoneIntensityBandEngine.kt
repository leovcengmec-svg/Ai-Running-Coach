package com.airunningcoach.app

/** A faixa é a posição percentual dentro da zona operacional (0=lento, 100=rápido). */
internal data class ActiveZoneBand(val minPercent: Int, val maxPercent: Int) {
    init { require(minPercent in 0..99 && maxPercent in 1..100 && minPercent < maxPercent) }
}

internal data class RecoveryCompatibilityMigrationResult(
    val workouts: List<Workout>,
    val changed: Boolean
)

internal object ZoneIntensityBandEngine {
    /** Política legada/conservadora para iniciantes e sessões sem perfil de experiência. */
    val z1WarmupCoolDownBand = ActiveZoneBand(80, 100)
    /** Transição aeróbia/aquecimento: borda lenta da Z2. */
    val z2EasyTransitionBand = ActiveZoneBand(0, 20)
    /** Recuperação ativa em Z2: borda lenta/confortável, distinta do bloco de trabalho Z2 (20–65%). */
    val z2ActiveRecoveryBand = ActiveZoneBand(0, 20)
    /** Fartlek usa a mesma política única de recuperação ativa Z2; evita esforço e recuperação iguais. */
    val fartlekActiveRecoveryBand: ActiveZoneBand get() = z2ActiveRecoveryBand
    /** Z1 permanece disponível somente para protocolos de maior intensidade que a indiquem explicitamente. */
    val z1ActiveRecoveryBand = ActiveZoneBand(90, 100)

    fun paceAtPercent(fullZone: PaceRange, percent: Int): Int {
        val p = percent.coerceIn(0, 100)
        val span = fullZone.slowestPaceValue - fullZone.fastestPaceValue
        return (fullZone.slowestPaceValue - span * (p / 100.0)).toInt()
    }

    fun activeRange(fullZone: PaceRange, band: ActiveZoneBand): PaceRange {
        val faster = paceAtPercent(fullZone, band.maxPercent)
        val slower = paceAtPercent(fullZone, band.minPercent)
        return PaceRange(faster.coerceAtLeast(fullZone.fastestPaceValue), slower.coerceAtMost(fullZone.slowestPaceValue))
    }

    /** Public helper used by protocol builders: any valid sub-range can be assigned in Z2–Z5. */
    fun applyBand(segment: WorkoutSegment, zone: PaceZone, band: ActiveZoneBand): WorkoutSegment {
        val range = activeRange(zone.range, band)
        return segment.copy(
            paceZone = zone.id,
            targetPaceMinValue = range.fastestPaceValue,
            targetPaceMaxValue = range.slowestPaceValue,
            zoneBasePaceFastValue = zone.range.fastestPaceValue,
            zoneBasePaceSlowValue = zone.range.slowestPaceValue,
            zoneIntensityMinPercent = band.minPercent,
            zoneIntensityMaxPercent = band.maxPercent
        )
    }

    fun apply(workout: PrescribedWorkout): PrescribedWorkout {
        val isRunWalk = workout.stimulus.startsWith("BEGINNER_RUN_WALK")
        val mappedSegments = workout.segments.map { segment ->
            val transition = isWarmupOrCooldown(segment.name) && workout.experienceMonths > 11 && !isRunWalk
            if (transition) applyExperiencedTransition(segment, workout.paceCalibrationSnapshot?.zoneRanges)
            else apply(workout.type, workout.title, workout.phase, segment)
        }
        val recoveryNormalized = normalizeFartlekRecoveries(
            mappedSegments, workout.stimulus, workout.paceCalibrationSnapshot?.zoneRanges
        )
        val progressionNormalized = normalizeProgressionBands(
            recoveryNormalized, workout.stimulus, workout.paceCalibrationSnapshot?.zoneRanges
        )
        val compatibleSegments = enforceRecoveryCompatibility(progressionNormalized)
        // Recovery blocks have fixed protocol duration and a distance estimated from their
        // easy-Z2 pace. Reallocate the remaining session kilometre budget across work blocks
        // so segment estimates still reconcile with the planned session volume. TIME and pace
        // remain the primary targets; distance is an accounting estimate for weekly load.
        val segments = reconcileFartlekDistances(compatibleSegments, workout.stimulus, workout.distanceKm)
        return workout.copy(segments = segments,
            durationMin = WorkoutDurationEstimator.estimateMinutes(segments, workout.distanceKm, workout.durationMin))
    }

    fun apply(workout: Workout): Workout {
        val isRunWalk = workout.stimulus.startsWith("BEGINNER_RUN_WALK")
        val mappedSegments = workout.segments.map { segment ->
            val transition = isWarmupOrCooldown(segment.name) && workout.experienceMonths > 11 && !isRunWalk
            if (transition) applyExperiencedTransition(segment, workout.paceCalibrationSnapshot?.zoneRanges)
            else apply(workout.type, workout.title, workout.phase, segment)
        }
        val recoveryNormalized = normalizeFartlekRecoveries(
            mappedSegments, workout.stimulus, workout.paceCalibrationSnapshot?.zoneRanges
        )
        val progressionNormalized = normalizeProgressionBands(
            recoveryNormalized, workout.stimulus, workout.paceCalibrationSnapshot?.zoneRanges
        )
        val compatibleSegments = enforceRecoveryCompatibility(progressionNormalized)
        // Recovery blocks have fixed protocol duration and a distance estimated from their
        // easy-Z2 pace. Reallocate the remaining session kilometre budget across work blocks
        // so segment estimates still reconcile with the planned session volume. TIME and pace
        // remain the primary targets; distance is an accounting estimate for weekly load.
        val segments = reconcileFartlekDistances(compatibleSegments, workout.stimulus, workout.distanceKm)
        return workout.copy(segments = segments,
            durationMin = WorkoutDurationEstimator.estimateMinutes(segments, workout.distanceKm, workout.durationMin))
    }

    /**
     * Fartlek recoveries use easy Z2, not the very slow edge of Z1. The recovery zone is
     * local to the athlete's own calibration; exact overlap with warm-up/cool-down is not
     * a physiologically meaningful gate and must not turn an easy jog into a walk.
     */
    private fun normalizeFartlekRecoveries(
        segments: List<WorkoutSegment>,
        stimulus: String,
        zoneRanges: Map<String, String>?
    ): List<WorkoutSegment> {
        val normalizedStimulus = stimulus.uppercase()
        if (!normalizedStimulus.contains("FARTLEK")) return segments
        val z2Range = zoneRanges?.get("Z2")?.let(::parseRange)
        val isF01 = normalizedStimulus.contains("F01")
        return segments.map { segment ->
            val label = segment.name.lowercase()
            val isRecovery = label.contains("recuper") || label.contains("recovery")
            val migrationReason = segment.instruction.lowercase()
            // Both known V84 texts are covered: the screenshot wording and the exact
            // fallback emitted by V84's engine implementation. Do not match generic WALK.
            val wasAutoWalkedByV84 = segment.recoveryMode == "WALK" &&
                label.contains("entre blocos") && (
                    migrationReason.contains("não é compatível com o desaquecimento") ||
                    migrationReason.contains("não possui uma faixa ativa z1 compatível")
                )
            if (!isRecovery || segment.recoveryMode == "PASSIVE" ||
                (segment.recoveryMode == "WALK" && !wasAutoWalkedByV84)) {
                segment
            } else {
                val active = z2Range?.let { activeRange(it, fartlekActiveRecoveryBand) }
                val duration = if (isF01) 2 else (segment.durationMin ?: 2)
                val estimatedDistance = active?.let { range ->
                    val midpoint = (range.fastestPaceValue + range.slowestPaceValue) / 2.0
                    if (midpoint > 0) kotlin.math.round((duration * 60.0 / midpoint) * 100.0) / 100.0 else null
                } ?: segment.distanceKm
                segment.copy(
                    name = "Recuperação ativa Z2 entre blocos",
                    instruction = "Recupere com trote leve em Z2 confortável (0–20% da zona). Esta faixa é mais leve que o bloco de trabalho; caminhe apenas se não conseguir controlar a respiração.",
                    durationMin = duration,
                    distanceKm = estimatedDistance,
                    targetMode = "TIME",
                    intensity = "LOW",
                    rpeRange = "2-3",
                    targetPaceMinValue = active?.fastestPaceValue,
                    targetPaceMaxValue = active?.slowestPaceValue,
                    paceZone = "Z2",
                    zoneBasePaceFastValue = z2Range?.fastestPaceValue,
                    zoneBasePaceSlowValue = z2Range?.slowestPaceValue,
                    zoneIntensityMinPercent = fartlekActiveRecoveryBand.minPercent,
                    zoneIntensityMaxPercent = fartlekActiveRecoveryBand.maxPercent,
                    recoveryMode = "ACTIVE_Z2"
                )
            }
        }
    }

    /**
     * Normalizes stored progressive/regressive library sessions so the main work never
     * repeats the separate warm-up band. It operates only on well-known library stimuli.
     * With an athlete calibration, paces are recalculated from the frozen zone snapshot;
     * without one, stale numeric paces are cleared while the semantic bands are retained.
     */
    private fun normalizeProgressionBands(
        segments: List<WorkoutSegment>,
        stimulus: String,
        zoneRanges: Map<String, String>?
    ): List<WorkoutSegment> {
        val code = stimulus.uppercase()
        val progressive = code.contains("PROGRESSIVE") || code.contains("PROGRESSION_RUN")
        val regressive = code.contains("REGRESSIVE")
        if (!progressive && !regressive) return segments

        val mainIndexes = segments.indices.filter { index ->
            val segment = segments[index]
            val name = segment.name.lowercase()
            val mainName = name.contains("bloco") || name.contains("final progressivo") ||
                name.contains("final confortável") || name.contains("final confortavel") ||
                name.contains("início moderado") || name.contains("inicio moderado")
            mainName && segment.paceZone?.uppercase() in setOf("Z2", "Z3") && !isWarmupOrCooldown(segment.name)
        }
        if (mainIndexes.size < 2) return segments

        val z2Bands = when {
            mainIndexes.size >= 3 && progressive -> listOf(
                ActiveZoneBand(20, 35), ActiveZoneBand(35, 50), ActiveZoneBand(50, 65)
            )
            mainIndexes.size >= 3 -> listOf(
                ActiveZoneBand(50, 65), ActiveZoneBand(35, 50), ActiveZoneBand(20, 35)
            )
            progressive -> listOf(ActiveZoneBand(20, 40), ActiveZoneBand(40, 65))
            else -> listOf(ActiveZoneBand(40, 65), ActiveZoneBand(20, 40))
        }
        var z2Index = 0
        val result = segments.toMutableList()
        mainIndexes.forEach { index ->
            val segment = result[index]
            val zoneId = segment.paceZone?.uppercase() ?: return@forEach
            val band = if (zoneId == "Z3") ActiveZoneBand(0, 20)
                else z2Bands.getOrNull(z2Index++) ?: return@forEach
            val fullRange = zoneRanges?.get(zoneId)?.let(::parseRange)
            result[index] = if (fullRange != null) {
                val active = activeRange(fullRange, band)
                segment.copy(
                    targetPaceMinValue = active.fastestPaceValue,
                    targetPaceMaxValue = active.slowestPaceValue,
                    zoneBasePaceFastValue = fullRange.fastestPaceValue,
                    zoneBasePaceSlowValue = fullRange.slowestPaceValue,
                    zoneIntensityMinPercent = band.minPercent,
                    zoneIntensityMaxPercent = band.maxPercent
                )
            } else {
                segment.copy(
                    targetPaceMinValue = null,
                    targetPaceMaxValue = null,
                    zoneBasePaceFastValue = null,
                    zoneBasePaceSlowValue = null,
                    zoneIntensityMinPercent = band.minPercent,
                    zoneIntensityMaxPercent = band.maxPercent
                )
            }
        }
        return result
    }

    /**
     * An ACTIVE_Z2 recovery is already bounded to the athlete's easy aerobic zone and remains
     * active even when its pace band does not intersect the cool-down band exactly. This is
     * important for Fartlek: the recovery must be easier than the work, not identical to the
     * cool-down. Explicit Z1 recoveries in high-intensity protocols keep the conservative check.
     */
    internal fun enforceRecoveryCompatibility(segments: List<WorkoutSegment>): List<WorkoutSegment> {
        val coolDown = segments.lastOrNull { isCoolDown(it.name) }
            ?: segments.firstOrNull { isWarmup(it.name) }
        val referenceFast = coolDown?.targetPaceMinValue
        val referenceSlow = coolDown?.targetPaceMaxValue
        return segments.map { segment ->
            val label = segment.name.lowercase()
            val isInterBlockRecovery = label.contains("recuper") || label.contains("recovery") ||
                (segment.recoveryMode == "ACTIVE_Z1" || segment.recoveryMode == "ACTIVE_Z2")
            if (!isInterBlockRecovery || segment.recoveryMode == "PASSIVE" || segment.recoveryMode == "WALK") {
                segment
            } else if (segment.recoveryMode == "ACTIVE_Z2" || segment.paceZone?.equals("Z2", ignoreCase = true) == true) {
                segment.copy(recoveryMode = "ACTIVE_Z2")
            } else {
                val recoveryFast = segment.targetPaceMinValue
                val recoverySlow = segment.targetPaceMaxValue
                val compatible = referenceFast != null && referenceSlow != null &&
                    recoveryFast != null && recoverySlow != null &&
                    maxOf(referenceFast, recoveryFast) <= minOf(referenceSlow, recoverySlow)
                if (compatible) {
                    segment.copy(recoveryMode = segment.recoveryMode ?: when (segment.paceZone?.uppercase()) {
                        "Z1" -> "ACTIVE_Z1"
                        "Z2" -> "ACTIVE_Z2"
                        else -> null
                    })
                } else {
                    segment.copy(
                        name = "Recuperação caminhando entre blocos",
                        instruction = "Caminhe durante a recuperação. Este protocolo de maior intensidade não possui uma faixa ativa Z1 compatível com a calibração atual; retome o próximo bloco somente quando a respiração estiver controlada.",
                        intensity = "LOW", rpeRange = "2-3", recoveryMode = "WALK",
                        targetPaceMinValue = null, targetPaceMaxValue = null, paceZone = null,
                        zoneBasePaceFastValue = null, zoneBasePaceSlowValue = null,
                        zoneIntensityMinPercent = null, zoneIntensityMaxPercent = null
                    )
                }
            }
        }
    }

    /** Migrates only pending sessions; completed workouts are immutable historical records. */
    internal fun migrateUnfinishedWorkouts(workouts: List<Workout>): RecoveryCompatibilityMigrationResult {
        var changed = false
        val migrated = workouts.map { workout ->
            if (workout.done || workout.segments.isEmpty()) workout else {
                val normalized = normalizeFartlekRecoveries(
                    workout.segments, workout.stimulus, workout.paceCalibrationSnapshot?.zoneRanges
                )
                val progressionNormalized = normalizeProgressionBands(
                    normalized, workout.stimulus, workout.paceCalibrationSnapshot?.zoneRanges
                )
                val compatibleSegments = enforceRecoveryCompatibility(progressionNormalized)
                val segments = reconcileFartlekDistances(compatibleSegments, workout.stimulus, workout.distanceKm)
                if (segments == workout.segments) workout else {
                    changed = true
                    workout.copy(
                        segments = segments,
                        durationMin = WorkoutDurationEstimator.estimateMinutes(
                            segments, workout.distanceKm, workout.durationMin
                        )
                    )
                }
            }
        }
        return RecoveryCompatibilityMigrationResult(migrated, changed)
    }


    /**
     * Rebalances only Fartlek work-block distance estimates after fixed-duration recoveries
     * are normalized. Warm-up, cool-down and recovery estimates are retained; the remaining
     * planned session distance is distributed proportionally over work blocks. This prevents
     * 2-minute recoveries from silently inflating weekly volume while preserving their duration,
     * active-Z2 pace and intensity band.
     */
    private fun reconcileFartlekDistances(
        segments: List<WorkoutSegment>,
        stimulus: String,
        targetKm: Double
    ): List<WorkoutSegment> {
        if (!stimulus.contains("FARTLEK", ignoreCase = true) || segments.isEmpty() || targetKm <= 0.0) {
            return segments
        }
        val isFixedContribution: (WorkoutSegment) -> Boolean = { segment ->
            isWarmupOrCooldown(segment.name) ||
                segment.recoveryMode in setOf("ACTIVE_Z1", "ACTIVE_Z2", "WALK", "PASSIVE") ||
                segment.name.contains("recuper", ignoreCase = true) ||
                segment.name.contains("recovery", ignoreCase = true)
        }
        val fixedKm = segments.filter(isFixedContribution).sumOf {
            (it.distanceKm ?: 0.0) * it.repeatCount.coerceAtLeast(1)
        }
        val workIndexes = segments.indices.filter { index ->
            val segment = segments[index]
            !isFixedContribution(segment) && segment.distanceKm != null
        }
        if (workIndexes.isEmpty()) return segments
        val currentWorkKm = workIndexes.sumOf { index ->
            val segment = segments[index]
            (segment.distanceKm ?: 0.0) * segment.repeatCount.coerceAtLeast(1)
        }
        val targetWorkKm = targetKm - fixedKm
        if (currentWorkKm <= 0.0 || targetWorkKm <= 0.0) return segments

        val factor = targetWorkKm / currentWorkKm
        val result = segments.toMutableList()
        workIndexes.forEach { index ->
            val segment = result[index]
            val adjusted = kotlin.math.round(((segment.distanceKm ?: 0.0) * factor) * 100.0) / 100.0
            if (adjusted >= 0.01) result[index] = segment.copy(distanceKm = adjusted)
        }
        // Correct centesimal rounding on the final work block, never on recovery/cool-down.
        val actualWorkKm = workIndexes.sumOf { index ->
            val segment = result[index]
            (segment.distanceKm ?: 0.0) * segment.repeatCount.coerceAtLeast(1)
        }
        val residual = targetWorkKm - actualWorkKm
        val lastIndex = workIndexes.last()
        val last = result[lastIndex]
        val lastRepeat = last.repeatCount.coerceAtLeast(1)
        val correctedLast = (last.distanceKm ?: 0.0) + residual / lastRepeat
        if (correctedLast >= 0.01) {
            result[lastIndex] = last.copy(distanceKm = kotlin.math.round(correctedLast * 100.0) / 100.0)
        }
        return result
    }

    private fun isWarmup(name: String): Boolean =
        name.contains("aquec", true) || name.contains("warmup", true)

    private fun isCoolDown(name: String): Boolean =
        name.contains("desaquec", true) || name.contains("cooldown", true)

    fun apply(type: String, title: String, phase: String, segment: WorkoutSegment): WorkoutSegment {
        if (segment.recoveryMode == "PASSIVE") return segment.copy(
            targetMode = "TIME", distanceKm = null,
            targetPaceMinValue = null, targetPaceMaxValue = null, paceZone = null,
            zoneBasePaceFastValue = null, zoneBasePaceSlowValue = null,
            zoneIntensityMinPercent = null, zoneIntensityMaxPercent = null
        )
        if (segment.recoveryMode == "WALK") return segment.copy(
            targetPaceMinValue = null, targetPaceMaxValue = null, paceZone = null,
            zoneBasePaceFastValue = null, zoneBasePaceSlowValue = null,
            zoneIntensityMinPercent = null, zoneIntensityMaxPercent = null
        )
        if (segment.paceZone == null) return segment
        val currentFast = segment.targetPaceMinValue ?: return segment
        val currentSlow = segment.targetPaceMaxValue ?: return segment
        val fullFast = segment.zoneBasePaceFastValue ?: currentFast
        val fullSlow = segment.zoneBasePaceSlowValue ?: currentSlow
        if (fullFast <= 0 || fullSlow <= fullFast) return segment

        val hasExplicitBand = segment.zoneIntensityMinPercent != null && segment.zoneIntensityMaxPercent != null
        val session = "$type $title".lowercase()
        val recoveryPhase = phase.equals("RECOVERY", ignoreCase = true) || session.contains("regener") || session.contains("recuper")
        val longRunSession = session.contains("long") || session.contains("longão") || session.contains("longao")
        val selectedBand = if (hasExplicitBand) ActiveZoneBand(segment.zoneIntensityMinPercent!!, segment.zoneIntensityMaxPercent!!)
            else when {
                longRunSession && segment.paceZone.equals("Z2", ignoreCase = true) && recoveryPhase -> ActiveZoneBand(20, 45)
                longRunSession && segment.paceZone.equals("Z2", ignoreCase = true) -> ActiveZoneBand(25, 65)
                else -> chooseBand(type, title, segment)
            }
        // Explicitly authored bands are never silently narrowed by a recovery-week heuristic.
        val band = if (recoveryPhase && !hasExplicitBand && !longRunSession) {
            ActiveZoneBand(selectedBand.minPercent.coerceAtMost(10), minOf(selectedBand.maxPercent, 40).coerceAtLeast(selectedBand.minPercent.coerceAtMost(10) + 1))
        } else selectedBand
        val active = activeRange(PaceRange(fullFast, fullSlow), band)
        return segment.copy(targetPaceMinValue = active.fastestPaceValue, targetPaceMaxValue = active.slowestPaceValue,
            zoneBasePaceFastValue = fullFast, zoneBasePaceSlowValue = fullSlow,
            zoneIntensityMinPercent = band.minPercent, zoneIntensityMaxPercent = band.maxPercent)
    }

    private fun applyExperiencedTransition(segment: WorkoutSegment, zoneRanges: Map<String, String>?): WorkoutSegment {
        val z2 = zoneRanges?.get("Z2")?.let(::parseRange)
        if (z2 == null) return segment.copy(
            instruction = "Etapa de transição em Z2 0–20%. O ritmo numérico aparecerá após um teste de desempenho válido.",
            paceZone = "Z2", targetPaceMinValue = null, targetPaceMaxValue = null,
            zoneBasePaceFastValue = null, zoneBasePaceSlowValue = null,
            zoneIntensityMinPercent = 0, zoneIntensityMaxPercent = 20
        )
        val band = z2EasyTransitionBand
        val active = activeRange(z2, band)
        val isWarmup = segment.name.contains("aquec", true) || segment.name.contains("warmup", true)
        val instruction = if (isWarmup) "Aqueça em Z2 na faixa 0–20%: comece na parte mais lenta da zona e acelere somente se a respiração estiver confortável."
            else "Desaqueça em Z2 na faixa 0–20%: reduza gradualmente sem precisar correr artificialmente lento em Z1."
        return segment.copy(instruction = instruction, paceZone = "Z2",
            targetPaceMinValue = active.fastestPaceValue, targetPaceMaxValue = active.slowestPaceValue,
            zoneBasePaceFastValue = z2.fastestPaceValue, zoneBasePaceSlowValue = z2.slowestPaceValue,
            zoneIntensityMinPercent = band.minPercent, zoneIntensityMaxPercent = band.maxPercent)
    }

    private fun parseRange(label: String): PaceRange? {
        val text = label.substringBefore(" min/km").trim()
        val parts = text.split('–', '-')
        if (parts.size != 2) return null
        val fast = PaceRange.parsePace(parts[0].trim()) ?: return null
        val slow = PaceRange.parsePace(parts[1].trim()) ?: return null
        return runCatching { PaceRange(fast, slow) }.getOrNull()
    }

    private fun isWarmupOrCooldown(name: String): Boolean =
        name.contains("aquec", true) || name.contains("warmup", true) ||
            name.contains("desaquec", true) || name.contains("cooldown", true)

    private fun chooseBand(type: String, title: String, segment: WorkoutSegment): ActiveZoneBand {
        val name = segment.name.lowercase()
        val session = "$type $title".lowercase()
        val zone = segment.paceZone?.uppercase() ?: return ActiveZoneBand(0, 100)
        return when {
            name.contains("recuper") || name.contains("caminhada") || name.contains("pausa") ->
                if (zone == "Z1") z1ActiveRecoveryBand else z2ActiveRecoveryBand
            isWarmupOrCooldown(segment.name) && zone == "Z1" -> z1WarmupCoolDownBand
            zone == "Z1" -> ActiveZoneBand(0, 40)
            zone == "Z2" && (session.contains("longo") || session.contains("longão") || session.contains("longao")) -> ActiveZoneBand(25, 65)
            zone == "Z2" -> ActiveZoneBand(20, 65)
            zone == "Z3" -> ActiveZoneBand(20, 60)
            zone == "Z4" -> ActiveZoneBand(25, 65)
            zone == "Z5" -> ActiveZoneBand(20, 60)
            else -> ActiveZoneBand(10, 55)
        }
    }
}
