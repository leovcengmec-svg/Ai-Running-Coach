package com.airunningcoach.app

/**
 * Converte uma zona operacional ampla em uma faixa ativa mais conservadora para cada sessão.
 * A escala é linear dentro da própria zona: 100% = limite mais rápido; 0% = limite mais lento.
 * Não representa %VO2máx, frequência cardíaca ou esforço fisiológico medido.
 */
internal data class ActiveZoneBand(val minPercent: Int, val maxPercent: Int) {
    init {
        require(minPercent in 0..100 && maxPercent in 0..100 && minPercent < maxPercent)
    }
}

internal object ZoneIntensityBandEngine {
    fun paceAtPercent(fullZone: PaceRange, percent: Int): Int {
        val p = percent.coerceIn(0, 100)
        val span = fullZone.slowestPaceValue - fullZone.fastestPaceValue
        return (fullZone.slowestPaceValue - span * (p / 100.0)).toInt()
    }

    fun activeRange(fullZone: PaceRange, band: ActiveZoneBand): PaceRange {
        val faster = paceAtPercent(fullZone, band.maxPercent)
        val slower = paceAtPercent(fullZone, band.minPercent)
        return PaceRange(faster.coerceAtLeast(fullZone.fastestPaceValue), slower.coerceAtMost(fullZone.slowestPaceValue))
    }

    fun apply(workout: PrescribedWorkout): PrescribedWorkout {
        val segments = workout.segments.map { apply(workout.type, workout.title, workout.phase, it) }
        return workout.copy(
            segments = segments,
            durationMin = WorkoutDurationEstimator.estimateMinutes(segments, workout.distanceKm, workout.durationMin)
        )
    }

    fun apply(workout: Workout): Workout {
        val segments = workout.segments.map { apply(workout.type, workout.title, workout.phase, it) }
        return workout.copy(
            segments = segments,
            durationMin = WorkoutDurationEstimator.estimateMinutes(segments, workout.distanceKm, workout.durationMin)
        )
    }

    fun apply(type: String, title: String, phase: String, segment: WorkoutSegment): WorkoutSegment {
        if (segment.paceZone == null) return segment
        val currentFast = segment.targetPaceMinValue ?: return segment
        val currentSlow = segment.targetPaceMaxValue ?: return segment
        val fullFast = segment.zoneBasePaceFastValue ?: currentFast
        val fullSlow = segment.zoneBasePaceSlowValue ?: currentSlow
        if (fullFast <= 0 || fullSlow <= fullFast) return segment

        val band = chooseBand(type, title, phase, segment)
        val active = activeRange(PaceRange(fullFast, fullSlow), band)
        return segment.copy(
            targetPaceMinValue = active.fastestPaceValue,
            targetPaceMaxValue = active.slowestPaceValue,
            zoneBasePaceFastValue = fullFast,
            zoneBasePaceSlowValue = fullSlow,
            zoneIntensityMinPercent = band.minPercent,
            zoneIntensityMaxPercent = band.maxPercent
        )
    }

    private fun chooseBand(type: String, title: String, phase: String, segment: WorkoutSegment): ActiveZoneBand {
        val name = segment.name.lowercase()
        val session = "$type $title".lowercase()
        val zone = segment.paceZone?.uppercase() ?: return ActiveZoneBand(0, 100)
        val recoveryPhase = phase.equals("RECOVERY", ignoreCase = true) ||
            session.contains("regener") || session.contains("recuper")

        val base = when {
            name.contains("aquec") || name.contains("warmup") -> ActiveZoneBand(0, 35)
            name.contains("desaquec") || name.contains("cooldown") -> ActiveZoneBand(0, 25)
            name.contains("recuper") || name.contains("caminhada") || name.contains("pausa") -> ActiveZoneBand(0, 20)
            zone == "Z1" -> ActiveZoneBand(0, 40)
            zone == "Z2" && session.contains("longo") -> ActiveZoneBand(10, 55)
            zone == "Z2" -> ActiveZoneBand(20, 65)
            zone == "Z3" -> ActiveZoneBand(20, 60)
            zone == "Z4" -> ActiveZoneBand(25, 65)
            zone == "Z5" -> ActiveZoneBand(20, 60)
            else -> ActiveZoneBand(10, 55)
        }
        // Nas semanas de recuperação, a faixa ativa nunca avança para a metade rápida da zona.
        return if (recoveryPhase) ActiveZoneBand(base.minPercent.coerceAtMost(10), minOf(base.maxPercent, 40)) else base
    }
}
