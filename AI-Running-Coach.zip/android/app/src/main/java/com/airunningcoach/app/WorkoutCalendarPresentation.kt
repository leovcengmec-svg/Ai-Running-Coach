package com.airunningcoach.app

import java.time.LocalDate

/** Short, stable calendar taxonomy. Full workout titles remain available in day/week details. */
internal object WorkoutCalendarCategory {
    const val INICIACAO = "INICIACAO"
    const val REGENERATIVO = "REGENERATIVO"
    const val RODAGEM = "RODAGEM"
    const val FARTLEK = "FARTLEK"
    const val TEMPO_RUN = "TEMPO_RUN"
    const val INTERVALADO_QUALIDADE = "INTERVALADO_QUALIDADE"
    // Compatibility aliases for older call sites; both now share the INT family.
    const val INTERVALADO = INTERVALADO_QUALIDADE
    const val LIMIAR_QUALIDADE = INTERVALADO_QUALIDADE
    const val LONGAO = "LONGAO"
    const val PROVA = "PROVA"
    const val TESTE = "TESTE"

    fun shortCode(category: String): String = when (category) {
        INICIACAO -> "INI"
        REGENERATIVO -> "REG"
        RODAGEM -> "ROD"
        FARTLEK -> "FAR"
        TEMPO_RUN -> "TMP"
        INTERVALADO_QUALIDADE -> "INT"
        LONGAO -> "LNG"
        PROVA -> "PRV"
        TESTE -> "TES"
        else -> "ROD"
    }

    fun label(category: String): String = when (category) {
        INICIACAO -> "Iniciação"
        REGENERATIVO -> "Regenerativo"
        RODAGEM -> "Rodagem"
        FARTLEK -> "Fartlek"
        TEMPO_RUN -> "Tempo Run"
        INTERVALADO_QUALIDADE -> "Intervalado"
        LONGAO -> "Longão"
        PROVA -> "Prova"
        TESTE -> "Teste"
        else -> "Rodagem"
    }

    /** Kept for non-visual legacy callers; the calendar UI uses custom vector icons. */
    fun glyph(category: String): String = shortCode(category)

    fun opacity(status: CalendarWorkoutStatus): Float = when (status) {
        CalendarWorkoutStatus.MISSED -> 0.34f
        CalendarWorkoutStatus.COMPLETED, CalendarWorkoutStatus.PENDING -> 1.0f
    }

    fun resolve(type: String, stimulus: String, title: String): String {
        val t = type.trim().uppercase()
        val s = stimulus.trim().uppercase()
        val name = title.trim().uppercase()
        val protocolCode = Regex("(?:^|:)(F0[1-4]|T0[1-5]|I\\d{2}|RP\\d{2}|CC01)$")
            .find(s)?.groupValues?.getOrNull(1)
        val explicitRunWalk = t in setOf("INICIACAO", "INICIAÇÃO", "CAMINHADA E CORRIDA", "CAMINHADA/CORRIDA", "RUN_WALK") ||
            listOf("RUN_WALK", "WALK_RUN", "RUNWALK_PROTOCOL", "WALK_RUN_PROTOCOL").any(s::contains)
        return when {
            explicitRunWalk -> INICIACAO
            t == "TESTE" || t == "TESTE FISIOLÓGICO" || s.contains("PHYSIOLOGICAL_TEST") || s.contains("COOPER_TEST") || s.contains("THREE_KM_TEST") -> TESTE
            t == "PROVA" || t == "COMPETIÇÃO" || s == "RACE_EVENT" || s.startsWith("RACE_EVENT_") -> PROVA
            t == "RECUPERAÇÃO" || t == "REGENERATIVO" || s.startsWith("RECOVERY") || s.contains("REGENERATIVE") || name.contains("REGENERATIV") -> REGENERATIVO
            t == "LONGO" || t == "LONGÃO" || s.startsWith("LONG_RUN") || s.contains("ENDURANCE_LONG") || name.contains("LONGÃO") || name.contains("LONGAO") -> LONGAO
            protocolCode in setOf("F01", "F02", "F03", "F04") || s.contains("FARTLEK") || name.contains("FARTLEK") -> FARTLEK
            protocolCode == "T01" || s.contains("TEMPO_RUN") || name.contains("TEMPO RUN") ||
                (name.contains("TEMPO") && !name.contains("INTERVAL")) -> TEMPO_RUN
            protocolCode == "CC01" -> RODAGEM
            protocolCode in setOf("T04", "T05") || protocolCode?.startsWith("I") == true || protocolCode?.startsWith("RP") == true ||
                s.contains("THRESHOLD_INTERVAL") || s.contains("TEMPO_INTERVAL") || s.contains("INTERVAL") ||
                s.contains("VO2_MAX") || name.contains("LIMIAR") || name.contains("TEMPO INTERVAL") ||
                name.contains("INTERVAL") || name.contains("TIROS") ||
                t in setOf("INTERVALADO", "TREINO INTERVALADO", "LIMIAR") || name.contains("QUALIDADE INTERVALADA") -> INTERVALADO_QUALIDADE
            else -> RODAGEM
        }
    }
}

internal enum class CalendarWorkoutStatus { COMPLETED, MISSED, PENDING }

/** A past planned date without a completion record is missed; today remains pending until the day ends. */
internal object WorkoutCalendarStatusResolver {
    fun resolve(scheduledDateIso: String, today: LocalDate, completed: Boolean): CalendarWorkoutStatus {
        if (completed) return CalendarWorkoutStatus.COMPLETED
        val scheduled = runCatching { LocalDate.parse(scheduledDateIso) }.getOrNull()
            ?: return CalendarWorkoutStatus.PENDING
        return if (scheduled.isBefore(today)) CalendarWorkoutStatus.MISSED else CalendarWorkoutStatus.PENDING
    }
}
