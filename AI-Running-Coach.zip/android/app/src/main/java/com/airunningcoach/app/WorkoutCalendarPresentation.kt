package com.airunningcoach.app

import java.time.LocalDate

/** Eight stable, user-facing workout families. Derived from structured type/stimulus, with title fallback for legacy data. */
internal object WorkoutCalendarCategory {
    const val REGENERATIVO = "REGENERATIVO"
    const val RODAGEM = "RODAGEM"
    const val INTERVALADO = "INTERVALADO"
    const val FARTLEK = "FARTLEK"
    const val LIMIAR_QUALIDADE = "LIMIAR_QUALIDADE"
    const val LONGAO = "LONGÃO"
    const val PROVA = "PROVA"
    const val TESTE = "TESTE"

    fun resolve(type: String, stimulus: String, title: String): String {
        val t = type.trim().uppercase()
        val s = stimulus.trim().uppercase()
        val name = title.trim().uppercase()
        return when {
            t == "TESTE" || t == "TESTE FISIOLÓGICO" || s.contains("PHYSIOLOGICAL_TEST") || s.contains("COOPER_TEST") || s.contains("THREE_KM_TEST") -> TESTE
            t == "PROVA" || t == "COMPETIÇÃO" || s == "RACE_EVENT" || s.startsWith("RACE_EVENT_") -> PROVA
            t == "RECUPERAÇÃO" || s.startsWith("RECOVERY") || s.contains("REGENERATIVE") || name.contains("REGENERATIV") -> REGENERATIVO
            t == "LONGO" || t == "LONGÃO" || s.startsWith("LONG_RUN") || s.contains("ENDURANCE_LONG") || name.contains("LONGÃO") || name.contains("LONGAO") -> LONGAO
            s.contains("FARTLEK") || name.contains("FARTLEK") -> FARTLEK
            s.contains("TEMPO") || s.contains("THRESHOLD") || s.startsWith("RACE_PACE") || name.contains("LIMIAR") || name.contains("TEMPO RUN") -> LIMIAR_QUALIDADE
            s.contains("INTERVAL") || s.contains("VO2_MAX") || name.contains("INTERVAL") || name.contains("INTERVALADO") || name.contains("TIROS") -> INTERVALADO
            t == "QUALIDADE" || name.contains("QUALIDADE") -> LIMIAR_QUALIDADE
            else -> RODAGEM
        }
    }
}

internal enum class CalendarWorkoutStatus { COMPLETED, MISSED, PENDING }

/** A past planned date without a completion record is missed; today remains pending until the day ends. */
internal object WorkoutCalendarStatusResolver {
    fun resolve(scheduledDateIso: String, today: LocalDate, completed: Boolean): CalendarWorkoutStatus {
        if (completed) return CalendarWorkoutStatus.COMPLETED
        val scheduled = runCatching { LocalDate.parse(scheduledDateIso) }.getOrNull()
            ?: return CalendarWorkoutStatus.PENDING
        return if (scheduled.isBefore(today)) CalendarWorkoutStatus.MISSED else CalendarWorkoutStatus.PENDING
    }
}
