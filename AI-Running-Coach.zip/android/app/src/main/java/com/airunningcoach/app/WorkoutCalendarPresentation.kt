package com.airunningcoach.app

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.TemporalAdjusters

/** Eight stable, user-facing workout families. Derived from structured type/stimulus, with title fallback for legacy data. */
internal object WorkoutCalendarCategory {
    const val REGENERATIVO = "REGENERATIVO"
    const val RODAGEM = "RODAGEM"
    const val INTERVALADO = "INTERVALADO"
    const val FARTLEK = "FARTLEK"
    const val LIMIAR_QUALIDADE = "LIMIAR_QUALIDADE"
    const val LONGAO = "LONGÃO"
    const val PROVA = "PROVA"
    const val TESTE = "TESTE"

    fun shortCode(category: String): String = when (category) {
        REGENERATIVO -> "REG"
        RODAGEM -> "ROD"
        INTERVALADO -> "INT"
        FARTLEK -> "FAR"
        LIMIAR_QUALIDADE -> "LIM"
        LONGAO -> "LNG"
        PROVA -> "PRV"
        TESTE -> "TST"
        else -> category.take(3)
    }

    fun displayName(category: String): String = when (category) {
        REGENERATIVO -> "Regenerativo"
        RODAGEM -> "Rodagem"
        INTERVALADO -> "Intervalado"
        FARTLEK -> "Fartlek"
        LIMIAR_QUALIDADE -> "Limiar/Qualidade"
        LONGAO -> "Longão"
        PROVA -> "Prova"
        TESTE -> "Teste"
        else -> "Treino"
    }

    fun glyph(category: String): String = when (category) {
        REGENERATIVO -> "☾"
        RODAGEM -> "◉"
        INTERVALADO -> "ϟ"
        FARTLEK -> "∿"
        LIMIAR_QUALIDADE -> "⌁"
        LONGAO -> "➚"
        PROVA -> "🏁"
        TESTE -> "⌖"
        else -> "•"
    }

    fun opacity(status: CalendarWorkoutStatus): Float = when (status) {
        CalendarWorkoutStatus.MISSED -> 0.30f
        CalendarWorkoutStatus.COMPLETED, CalendarWorkoutStatus.PENDING -> 1.0f
    }

    fun resolve(type: String, stimulus: String, title: String): String {
        val t = type.trim().uppercase()
        val s = stimulus.trim().uppercase()
        val name = title.trim().uppercase()
        return when {
            t == "TESTE" || t == "TESTE FISIOLÓGICO" || s.contains("PHYSIOLOGICAL_TEST") || s.contains("COOPER_TEST") || s.contains("THREE_KM_TEST") -> TESTE
            t == "PROVA" || t == "COMPETIÇÃO" || s == "RACE_EVENT" || s.startsWith("RACE_EVENT_") -> PROVA
            t == "RECUPERAÇÃO" || s.startsWith("RECOVERY") || s.contains("REGENERATIVE") || name.contains("REGENERATIV") -> REGENERATIVO
            t == "LONGO" || t == "LONGÃO" || s.startsWith("LONG_RUN") || s.contains("ENDURANCE_LONG") || name.contains("LONGÃO") || name.contains("LONGAO") -> LONGAO
            s.contains("FARTLEK") || name.contains("FARTLEK") -> FARTLEK
            s.contains("TEMPO") || s.contains("THRESHOLD") || s.startsWith("RACE_PACE") || name.contains("LIMIAR") || name.contains("TEMPO RUN") -> LIMIAR_QUALIDADE
            s.contains("INTERVAL") || s.contains("VO2_MAX") || name.contains("INTERVAL") || name.contains("INTERVALADO") || name.contains("TIROS") -> INTERVALADO
            t == "QUALIDADE" || name.contains("QUALIDADE") -> LIMIAR_QUALIDADE
            else -> RODAGEM
        }
    }
}

/** Monday-first compact month grid with only the weeks needed by the displayed month. */
internal object WorkoutCalendarGrid {
    fun monthDates(month: YearMonth): List<LocalDate> {
        val first = month.atDay(1).with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val last = month.atEndOfMonth().with(TemporalAdjusters.nextOrSame(DayOfWeek.SUNDAY))
        val days = java.time.temporal.ChronoUnit.DAYS.between(first, last).toInt() + 1
        return (0 until days).map { first.plusDays(it.toLong()) }
    }

    fun weekCount(month: YearMonth): Int = monthDates(month).size / 7
}

internal enum class CalendarWorkoutStatus { COMPLETED, MISSED, PENDING }

/** A past planned date without a completion record is missed; today remains pending until the day ends. */
internal object WorkoutCalendarStatusResolver {
    fun resolve(scheduledDateIso: String, today: LocalDate, completed: Boolean): CalendarWorkoutStatus {
        if (completed) return CalendarWorkoutStatus.COMPLETED
        val scheduled = runCatching { LocalDate.parse(scheduledDateIso) }.getOrNull()
            ?: return CalendarWorkoutStatus.PENDING
        return if (scheduled.isBefore(today)) CalendarWorkoutStatus.MISSED else CalendarWorkoutStatus.PENDING
    }
}
