package com.airunningcoach.app

/** Stable identity and reversible lifecycle for saved physiological assessments. */
internal object CooperAssessmentManagementEngine {
    fun ensureStableIds(records: List<CooperAssessmentRecord>): List<CooperAssessmentRecord> =
        records.mapIndexed { index, record ->
            if (record.recordId.isNotBlank()) record else record.copy(
                recordId = legacyId(record, index)
            )
        }

    private fun legacyId(record: CooperAssessmentRecord, index: Int): String = buildString {
        append("legacy-")
        append(record.dateIso.replace(Regex("[^0-9]"), ""))
        append('-')
        append(if (record.testMethod == "THREE_KM") "3k" else "cooper")
        append('-')
        append(index)
    }

    fun active(records: List<CooperAssessmentRecord>): List<CooperAssessmentRecord> =
        records.filter { it.deletedAtIso.isBlank() }

    fun removed(records: List<CooperAssessmentRecord>): List<CooperAssessmentRecord> =
        records.filter { it.deletedAtIso.isNotBlank() }

    fun latestActive(records: List<CooperAssessmentRecord>): CooperAssessmentRecord? =
        active(records).maxWithOrNull(compareBy<CooperAssessmentRecord> { it.dateIso }.thenBy { it.updatedAtIso })

    fun softDelete(
        records: List<CooperAssessmentRecord>, recordId: String, deletedAtIso: String
    ): List<CooperAssessmentRecord> {
        if (recordId.isBlank() || deletedAtIso.isBlank()) return records
        return records.map { record ->
            if (record.recordId == recordId && record.deletedAtIso.isBlank()) {
                record.copy(deletedAtIso = deletedAtIso, updatedAtIso = deletedAtIso)
            } else record
        }
    }

    fun restore(
        records: List<CooperAssessmentRecord>, recordId: String, restoredAtIso: String
    ): List<CooperAssessmentRecord> {
        if (recordId.isBlank()) return records
        return records.map { record ->
            if (record.recordId == recordId && record.deletedAtIso.isNotBlank()) {
                record.copy(deletedAtIso = "", updatedAtIso = restoredAtIso)
            } else record
        }
    }

    fun replace(
        records: List<CooperAssessmentRecord>, replacement: CooperAssessmentRecord
    ): List<CooperAssessmentRecord> {
        if (replacement.recordId.isBlank()) return records
        val found = records.any { it.recordId == replacement.recordId }
        val updated = if (found) records.map { if (it.recordId == replacement.recordId) replacement else it }
            else records + replacement
        return updated.sortedWith(compareBy<CooperAssessmentRecord> { it.dateIso }.thenBy { it.recordId })
    }
}

