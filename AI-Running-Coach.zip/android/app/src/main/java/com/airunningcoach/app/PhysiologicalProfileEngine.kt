package com.airunningcoach.app

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.pow
import kotlin.math.sqrt

/** User intent is separate from race distance: completing a distance is not the same as chasing a time. */
internal object TrainingGoalIntent {
    const val COMPLETE = "COMPLETE"
    const val CONTINUOUS = "CONTINUOUS"
    const val PERSONAL_BEST = "PERSONAL_BEST"
    const val TARGET_TIME = "TARGET_TIME"
    const val HEALTH = "HEALTH"

    fun normalize(value: String, health: Boolean = false): String = when {
        health -> HEALTH
        value in setOf(COMPLETE, CONTINUOUS, PERSONAL_BEST, TARGET_TIME) -> value
        else -> COMPLETE
    }

    val performanceOptions = listOf(
        "Completar a distância",
        "Correr continuamente",
        "Melhorar meu recorde pessoal",
        "Alcançar um tempo definido"
    )

    fun fromLabel(label: String): String = when (label.trim()) {
        "Correr continuamente" -> CONTINUOUS
        "Melhorar meu recorde pessoal" -> PERSONAL_BEST
        "Alcançar um tempo definido" -> TARGET_TIME
        else -> COMPLETE
    }

    fun label(value: String): String = when (value) {
        CONTINUOUS -> "Correr continuamente"
        PERSONAL_BEST -> "Melhorar meu recorde pessoal"
        TARGET_TIME -> "Alcançar um tempo definido"
        HEALTH -> "Saúde e qualidade de vida"
        else -> "Completar a distância"
    }
}

internal object RunningTerrain {
    const val ROAD = "ROAD"
    const val TRACK = "TRACK"
    const val TRAIL = "TRAIL"
    const val MIXED = "MIXED"

    val options = listOf("Rua/asfalto", "Pista", "Trilha/montanha", "Misto")

    fun fromLabel(value: String): String = when (value.trim()) {
        "Pista" -> TRACK
        "Trilha/montanha" -> TRAIL
        "Misto" -> MIXED
        else -> ROAD
    }

    fun normalize(value: String): String = when (value) {
        ROAD, TRACK, TRAIL, MIXED -> value
        else -> ROAD
    }

    fun label(value: String): String = when (value) {
        TRACK -> "Pista"
        TRAIL -> "Trilha/montanha"
        MIXED -> "Misto"
        else -> "Rua/asfalto"
    }
}

internal data class PerformanceTestObservation(
    val date: LocalDate,
    val distanceKm: Double,
    val durationSeconds: Int,
    val effortRating: Int,
    val painPresent: Boolean = false,
    val isRaceOrTest: Boolean = false,
    val terrain: String = RunningTerrain.ROAD
)

internal data class CriticalSpeedSnapshot(
    val status: String,
    val criticalSpeedMetersPerSecond: Double? = null,
    val criticalSpeedPaceSecondsPerKm: Int? = null,
    val dPrimeMeters: Double? = null,
    val rSquared: Double? = null,
    val evidenceCount: Int = 0,
    val explanation: String
) {
    val paceLabel: String
        get() = criticalSpeedPaceSecondsPerKm?.let(PaceRange::format)?.plus(" min/km") ?: "Não estimada"
}

internal data class GoalTimeProjection(
    val status: String,
    val sourceDistanceKm: Double? = null,
    val sourceTimeSeconds: Int? = null,
    val projectedTimeSeconds: Int? = null,
    val targetPaceSecondsPerKm: Int? = null,
    val explanation: String
)

/**
 * Uses race/test-like efforts as supporting field evidence. It never labels a field estimate as
 * laboratory LT2/VO2 and never overwrites the app's five zones automatically.
 */
internal object PhysiologicalProfileEngine {
    private const val MAX_AGE_DAYS = 90L

    fun estimateCriticalSpeed(
        observations: List<PerformanceTestObservation>,
        today: LocalDate = LocalDate.now()
    ): CriticalSpeedSnapshot {
        val valid = observations.filter { item ->
            val age = ChronoUnit.DAYS.between(item.date, today)
            item.distanceKm.isFinite() && item.distanceKm in 1.5..20.0 &&
                item.durationSeconds in 180..3600 && item.effortRating >= 7 &&
                (item.isRaceOrTest || item.effortRating >= 9) && !item.painPresent && age in 0..MAX_AGE_DAYS
        }.distinctBy { Triple(it.date, it.distanceKm, it.durationSeconds) }
            .sortedBy { it.durationSeconds }

        if (valid.size < 3) return CriticalSpeedSnapshot(
            status = "INSUFFICIENT_EVIDENCE",
            evidenceCount = valid.size,
            explanation = "A velocidade crítica é uma referência complementar. Registre pelo menos três esforços fortes ou provas/testes recentes, em distâncias e durações diferentes, sem dor."
        )
        val distances = valid.map { it.distanceKm }
        val durations = valid.map { it.durationSeconds.toDouble() }
        val timeSpread = durations.maxOrNull()!! / durations.minOrNull()!!
        if (distances.distinct().size < 2 || timeSpread < 1.20) return CriticalSpeedSnapshot(
            status = "INSUFFICIENT_VARIATION",
            evidenceCount = valid.size,
            explanation = "Os esforços precisam representar durações suficientemente diferentes; repetições semelhantes não definem a relação distância-tempo."
        )

        val x = durations
        val y = distances.map { it * 1000.0 }
        val meanX = x.average()
        val meanY = y.average()
        val covariance = x.indices.sumOf { (x[it] - meanX) * (y[it] - meanY) }
        val varianceX = x.sumOf { (it - meanX) * (it - meanX) }
        if (varianceX <= 0.0) return CriticalSpeedSnapshot(
            status = "INVALID_MODEL", evidenceCount = valid.size,
            explanation = "Não foi possível ajustar a relação distância-tempo dos esforços registrados."
        )
        val slope = covariance / varianceX
        val intercept = meanY - slope * meanX
        val predicted = x.map { slope * it + intercept }
        val residual = y.indices.sumOf { (y[it] - predicted[it]).pow(2) }
        val total = y.sumOf { (it - meanY).pow(2) }
        val rSquared = if (total > 0.0) 1.0 - residual / total else 0.0
        val plausible = slope in 2.0..6.5 && intercept in 50.0..600.0 && rSquared >= 0.90
        if (!plausible) return CriticalSpeedSnapshot(
            status = "CONFLICTING_EVIDENCE",
            criticalSpeedMetersPerSecond = slope.takeIf { it.isFinite() },
            dPrimeMeters = intercept.takeIf { it.isFinite() },
            rSquared = rSquared.takeIf { it.isFinite() },
            evidenceCount = valid.size,
            explanation = "Os resultados apresentam dispersão ou parâmetros fora da faixa plausível. Mantenha as zonas atuais e repita os testes em condições comparáveis."
        )
        val pace = (1000.0 / slope).toInt()
        return CriticalSpeedSnapshot(
            status = "FIELD_ESTIMATE",
            criticalSpeedMetersPerSecond = slope,
            criticalSpeedPaceSecondsPerKm = pace,
            dPrimeMeters = intercept,
            rSquared = rSquared,
            evidenceCount = valid.size,
            explanation = "Estimativa de campo baseada em ${valid.size} esforços recentes (R²=${"%.2f".format(java.util.Locale.US, rSquared)}). É uma referência complementar, não uma medição laboratorial nem autorização automática para alterar Z4/Z5."
        )
    }

    /** Riegel-style projection is an estimate with explicit uncertainty, not a promised race result. */
    fun projectGoalTime(
        sourceDistanceKm: Double?,
        sourceTimeSeconds: Int?,
        targetDistanceKm: Double,
        exponent: Double = 1.06
    ): GoalTimeProjection {
        if (sourceDistanceKm == null || sourceTimeSeconds == null ||
            !sourceDistanceKm.isFinite() || sourceDistanceKm !in 1.0..100.0 ||
            sourceTimeSeconds !in 180..36_000 || !targetDistanceKm.isFinite() || targetDistanceKm !in 1.0..42.2
        ) return GoalTimeProjection(
            status = "INSUFFICIENT_EVIDENCE",
            explanation = "Registre uma prova ou teste recente válido para obter uma projeção de tempo."
        )
        val distanceRatio = targetDistanceKm / sourceDistanceKm
        if (distanceRatio !in 0.25..4.0) return GoalTimeProjection(
            status = "INSUFFICIENT_EVIDENCE",
            sourceDistanceKm = sourceDistanceKm,
            sourceTimeSeconds = sourceTimeSeconds,
            explanation = "A distância do resultado de origem é muito diferente da meta para uma projeção confiável. Registre uma prova ou teste mais próximo da distância-alvo."
        )
        val projected = sourceTimeSeconds * distanceRatio.pow(exponent)
        if (!projected.isFinite() || projected !in 180.0..172_800.0) return GoalTimeProjection(
            status = "OUT_OF_RANGE", explanation = "A projeção está fora do intervalo suportado. Projeções automáticas não são aplicadas a ultradistâncias; revise distância e tempo de origem."
        )
        val seconds = projected.toInt()
        val pace = (seconds / targetDistanceKm).toInt()
        return GoalTimeProjection(
            status = "ESTIMATE",
            sourceDistanceKm = sourceDistanceKm,
            sourceTimeSeconds = sourceTimeSeconds,
            projectedTimeSeconds = seconds,
            targetPaceSecondsPerKm = pace,
            explanation = "Projeção matemática de desempenho a partir de ${sourceDistanceKm} km. Não substitui preparação específica, condições do percurso ou avaliação de prontidão."
        )
    }

    fun parseTargetTime(value: String): Int? = PaceDuration.parse(value)

    fun formatDuration(seconds: Int): String {
        val safe = seconds.coerceAtLeast(0)
        val hours = safe / 3600
        val minutes = (safe % 3600) / 60
        val remainder = safe % 60
        return if (hours > 0) "%02d:%02d:%02d".format(hours, minutes, remainder)
        else "%02d:%02d".format(minutes, remainder)
    }
}
