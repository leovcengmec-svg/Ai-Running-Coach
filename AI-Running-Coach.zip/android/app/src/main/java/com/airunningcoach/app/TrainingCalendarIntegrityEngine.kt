package com.airunningcoach.app

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.time.temporal.TemporalAdjusters

/** Final guard applied after generation, race replacement and manual-date restoration. */
internal object TrainingCalendarIntegrityEngine {
    fun validate(
        workouts: List<Workout>,
        races: List<RaceEvent>,
        weeklyFrequency: Int,
        today: LocalDate = LocalDate.now()
    ): List<String> {
        val issues = mutableListOf<String>()
        if (weeklyFrequency !in 1..7) {
            issues += "A frequência semanal configurada é inválida."
            return issues
        }
        val firstMonday = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val activeWorkouts = workouts.mapNotNull { workout ->
            val date = runCatching { LocalDate.parse(workout.scheduledDateIso) }.getOrNull() ?: return@mapNotNull null
            if (date.isBefore(firstMonday)) null else workout to date
        }
        activeWorkouts.groupBy { it.second }.filterValues { it.size > 1 }.forEach { (date, rows) ->
            issues += "Há ${rows.size} sessões no mesmo dia (${date}). Mantenha no máximo um treino por data."
        }
        val activeRaces = races.filter { it.status == "PLANNED" }.mapNotNull { race ->
            race.dateOrNull()?.takeUnless { it.isBefore(firstMonday) }?.let { race to it }
        }
        val activeWorkoutDates = activeWorkouts.map { it.second }.toSet()
        activeRaces.filter { it.second in activeWorkoutDates }.forEach { (race, date) ->
            issues += "A prova '${race.name}' conflita com um treino em ${date}. A competição deve substituir ou deslocar essa sessão."
        }
        val commitments = (activeWorkouts.filterNot { it.first.isOptionalExtra }.map { it.second } + activeRaces.map { it.second })
            .groupBy { date -> date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)) }
        commitments.forEach { (weekStart, dates) ->
            val commitmentCount = dates.size
            if (commitmentCount > weeklyFrequency) {
                val weekEnd = weekStart.plusDays(6)
                issues += "A semana ${weekStart} a ${weekEnd} possui $commitmentCount compromissos (treinos e provas), acima dos $weeklyFrequency dias configurados."
            }

            // The long-run share is checked after races have replaced/displaced sessions,
            // so the denominator is the real planned weekly total including race distance.
            val weekEnd = weekStart.plusDays(6)
            val weekWorkouts = activeWorkouts.filter { it.second in weekStart..weekEnd }.map { it.first }
            val weekRaces = activeRaces.filter { it.second in weekStart..weekEnd }.map { it.first }
            val totalKm = weekWorkouts.sumOf { it.distanceKm.coerceAtLeast(0.0) } +
                weekRaces.sumOf { it.distanceKm.coerceAtLeast(0.0) }
            val longRuns = weekWorkouts.filter { it.type.equals("Longo", ignoreCase = true) }
            if (longRuns.size > 1) {
                issues += "A semana ${weekStart} possui ${longRuns.size} sessões de longão. Deve existir no máximo um longão principal."
            }
            val longRun = longRuns.maxByOrNull { it.distanceKm }
            if (longRun != null && totalKm > 0.0) {
                val share = longRun.distanceKm / totalKm
                if (share > 0.40 + 1e-9) {
                    issues += "O longão de ${String.format(java.util.Locale.US, "%.1f", longRun.distanceKm)} km representa ${String.format(java.util.Locale.US, "%.1f", share * 100.0)}% do volume da semana ${weekStart}, incluindo provas. O limite é 40%; revise a distribuição antes de aplicar o plano."
                }
                val secondLargest = weekWorkouts.filterNot { it === longRun }.maxOfOrNull { it.distanceKm }
                if (secondLargest != null && longRun.distanceKm <= secondLargest + 1e-9) {
                    issues += "O longão da semana ${weekStart} não é maior que a segunda maior sessão. Revise a distribuição semanal."
                }
            }
        }
        return issues.distinct()
    }

    fun weekStart(date: LocalDate): LocalDate = date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))

    fun weekOffset(date: LocalDate, anchor: LocalDate): Int =
        (ChronoUnit.DAYS.between(weekStart(anchor), weekStart(date)) / 7L).toInt()
}
