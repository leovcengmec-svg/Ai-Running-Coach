package com.airunningcoach.app

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.time.temporal.TemporalAdjusters
import java.util.Locale

/** Final guard applied after generation, race replacement and manual-date restoration. */
internal object TrainingCalendarIntegrityEngine {
    private data class DatedWorkout(val workout: Workout, val date: LocalDate) {
        val instanceKey: String
            get() = buildString {
                append(workout.sessionId.ifBlank { workout.title })
                append('|').append(date)
                append('|').append(workout.type.trim().uppercase(Locale.ROOT))
            }

        // A scheduled four-week retest has no distance until the athlete chooses Cooper or 3 km.
        // It is a valid calendar commitment, not a zero-kilometre workout or malformed activity.
        val isUndecidedPhysiologicalRetest: Boolean
            get() = workout.stimulus.startsWith("PHYSIOLOGICAL_RETEST") &&
                workout.type.equals("Teste fisiológico", ignoreCase = true) &&
                workout.retestMethod.isBlank() && workout.distanceKm == 0.0
    }

    private data class DatedRace(val race: RaceEvent, val date: LocalDate) {
        val instanceKey: String get() = "${race.id}|$date"
    }

    fun validate(
        workouts: List<Workout>,
        races: List<RaceEvent>,
        weeklyFrequency: Int,
        today: LocalDate = LocalDate.now()
    ): List<String> {
        val issues = mutableListOf<String>()
        if (weeklyFrequency !in 1..7) {
            issues += "A frequência semanal configurada é inválida."
            return issues
        }

        val currentMonday = weekStart(today)
        val datedWorkouts = workouts.mapNotNull { workout ->
            val rawDate = workout.scheduledDateIso.trim()
            if (rawDate.isBlank()) return@mapNotNull null // Legacy sessions can be display-only.
            val date = runCatching { LocalDate.parse(rawDate) }.getOrNull()
            if (date == null) {
                issues += "A sessão '${workout.title.ifBlank { workout.type }}' possui uma data inválida ('$rawDate'). Corrija a data antes de aplicar o plano."
                return@mapNotNull null
            }
            DatedWorkout(workout, date)
        }.distinctBy { it.instanceKey }

        val currentSunday = currentMonday.plusDays(6)
        val datedRaces = races.asSequence()
            // Planned future races are prospective load; a completed race in the current
            // week contributes realized load but never reserves a future day.
            .mapNotNull { race ->
                val date = race.dateOrNull() ?: return@mapNotNull null
                val contributesLoad = (race.status == "PLANNED" && !date.isBefore(today)) ||
                    (race.status == "COMPLETED" && date in currentMonday..currentSunday)
                if (contributesLoad) DatedRace(race, date) else null
            }
            .distinctBy { it.instanceKey }
            .toList()

        // Future frequency and conflicts are based only on unfinished commitments from today.
        // Completed sessions remain available for historical/load context, but never reserve a future day.
        val pendingFutureWorkouts = datedWorkouts.filter { !it.workout.done && !it.date.isBefore(today) }
        val pendingFutureRaces = datedRaces.filter { it.race.status == "PLANNED" && !it.date.isBefore(today) }

        pendingFutureWorkouts.groupBy { it.date }.filterValues { it.size > 1 }.forEach { (date, rows) ->
            val names = rows.joinToString(", ") { it.workout.title.ifBlank { it.workout.type } }
            issues += "Há ${rows.size} sessões pendentes no mesmo dia (${date}): $names. Mantenha no máximo um treino por data."
        }

        val pendingWorkoutDates = pendingFutureWorkouts.map { it.date }.toSet()
        pendingFutureRaces.filter { it.date in pendingWorkoutDates }.forEach { (race, date) ->
            val conflicting = pendingFutureWorkouts.filter { it.date == date }
                .joinToString(", ") { it.workout.title.ifBlank { it.workout.type } }
            issues += "A prova '${race.name}' conflita com treino(s) pendente(s) em ${date}: $conflicting. A competição deve substituir ou deslocar essa sessão."
        }

        // Count distinct calendar days, not list entries. A workout and a race on the same
        // day are one frequency day (the overlap is reported separately as a conflict).
        val commitmentDatesByWeek = (pendingFutureWorkouts.filterNot { it.workout.isOptionalExtra }.map { it.date } +
            pendingFutureRaces.map { it.date })
            .distinct()
            .groupBy { weekStart(it) }
        commitmentDatesByWeek.forEach { (weekMonday, dates) ->
            if (dates.size > weeklyFrequency) {
                val weekEnd = weekMonday.plusDays(6)
                issues += "A semana ${weekMonday} a ${weekEnd} possui ${dates.size} dias com compromissos futuros (treinos e provas), acima dos $weeklyFrequency dias configurados."
            }
        }

        // Weekly load uses the unique planned/realized instances, including completed sessions
        // retained in the current week and each planned race exactly once. Optional extras add
        // physiological load but do not consume a primary training-frequency day.
        val relevantWeeks = (datedWorkouts.map { weekStart(it.date) } + datedRaces.map { weekStart(it.date) })
            .filter { !it.isBefore(currentMonday) }
            .distinct()
            .sorted()

        relevantWeeks.forEach { weekMonday ->
            val weekEnd = weekMonday.plusDays(6)
            val weekWorkouts = datedWorkouts.filter { it.date in weekMonday..weekEnd }
            val weekRaces = datedRaces.filter { it.date in weekMonday..weekEnd }

            val invalidDistance = weekWorkouts.firstOrNull {
                !it.isUndecidedPhysiologicalRetest &&
                    (!it.workout.distanceKm.isFinite() || it.workout.distanceKm <= 0.0)
            }
            if (invalidDistance != null) {
                issues += "A sessão '${invalidDistance.workout.title.ifBlank { invalidDistance.workout.type }}' da semana ${weekMonday} possui distância inválida; a participação do longão não pode ser validada."
                return@forEach
            }
            val invalidRace = weekRaces.firstOrNull { !it.race.distanceKm.isFinite() || it.race.distanceKm <= 0.0 }
            if (invalidRace != null) {
                issues += "A prova '${invalidRace.race.name}' da semana ${weekMonday} possui distância inválida; a participação do longão não pode ser validada."
                return@forEach
            }

            // A week already in progress may have only its remaining sessions after onboarding
            // or restoration. Apply the 40% check only when the configured number of distinct
            // primary days is represented by realized sessions, future sessions and races.
            val currentWeekEvidenceDays = (weekWorkouts.filterNot { it.workout.isOptionalExtra }.map { it.date } +
                weekRaces.map { it.date }).distinct().size
            val isPartialCurrentWeek = weekMonday == currentMonday && today.isAfter(currentMonday) &&
                currentWeekEvidenceDays < weeklyFrequency
            if (isPartialCurrentWeek) return@forEach

            val longRuns = weekWorkouts.filter {
                !it.workout.isOptionalExtra && it.workout.type.equals("Longo", ignoreCase = true)
            }
            if (longRuns.size > 1) {
                issues += "A semana ${weekMonday} possui ${longRuns.size} sessões de longão. Deve existir no máximo um longão principal."
            }
            val longRun = longRuns.maxByOrNull { it.workout.distanceKm } ?: return@forEach
            val knownWorkoutKm = weekWorkouts.filterNot { it.isUndecidedPhysiologicalRetest }
                .sumOf { it.workout.distanceKm }
            val totalKm = knownWorkoutKm + weekRaces.sumOf { it.race.distanceKm }
            if (totalKm <= 0.0) return@forEach
            val share = longRun.workout.distanceKm / totalKm
            val undecidedRetests = weekWorkouts.filter { it.isUndecidedPhysiologicalRetest }

            // Cooper accepts 1.00–5.00 km; 5 km is the largest possible distance before
            // protocol selection. If even that upper-bound distance cannot bring the long
            // run to <=40%, the week is definitely invalid. Otherwise defer only this check
            // until the athlete chooses the protocol; never pretend the pending test is 0 km.
            val maximumPendingRetestKm = undecidedRetests.size * 5.0
            val minimumPossibleShare = longRun.workout.distanceKm / (totalKm + maximumPendingRetestKm)
            val shareIsDefinitelyOverLimit = if (undecidedRetests.isEmpty()) {
                share > 0.40 + 1e-9
            } else {
                minimumPossibleShare > 0.40 + 1e-9
            }

            if (shareIsDefinitelyOverLimit) {
                val workoutBreakdown = weekWorkouts.sortedBy { it.date }.joinToString("; ") { row ->
                    val label = row.workout.title.ifBlank { row.workout.type }
                    val flags = buildList {
                        if (row.workout.sessionId.isNotBlank()) add("id=${row.workout.sessionId}")
                        if (row.workout.isOptionalExtra) add("extra opcional")
                        if (row.workout.manuallyRescheduled) add("reagendada manualmente")
                        add(if (row.workout.done) "concluído" else "planejado")
                    }.joinToString(", ")
                    if (row.isUndecidedPhysiologicalRetest) {
                        "$label (método a definir; distância pendente; ${row.date}; $flags)"
                    } else {
                        "$label ${formatKm(row.workout.distanceKm)} km (${row.date}; $flags)"
                    }
                }.ifBlank { "nenhuma sessão" }
                val raceBreakdown = weekRaces.sortedBy { it.date }.joinToString("; ") { row ->
                    "Prova ${row.race.name} ${formatKm(row.race.distanceKm)} km (${row.date}; id=${row.race.id}; ${row.race.status})"
                }
                val breakdown = listOf(workoutBreakdown, raceBreakdown).filter { it.isNotBlank() }.joinToString("; ")
                val storedTarget = weekWorkouts.mapNotNull { it.workout.weeklyTargetKm }
                    .filter { it.isFinite() && it > 0.0 }.maxOrNull()
                val targetNote = storedTarget?.let {
                    " Meta semanal registrada: ${formatKm(it)} km; composição considerada: ${formatKm(totalKm)} km."
                }.orEmpty()
                val raceQualifier = if (weekRaces.isNotEmpty()) ", incluindo provas" else ""
                val shareMessage = if (undecidedRetests.isEmpty()) {
                    "representa ${formatPercent(share)}% do volume conhecido"
                } else {
                    "representa pelo menos ${formatPercent(minimumPossibleShare)}% do volume, mesmo considerando até ${formatKm(maximumPendingRetestKm)} km para os retestes ainda sem protocolo"
                }
                issues += "O longão de ${formatKm(longRun.workout.distanceKm)} km $shareMessage na semana ${weekMonday}$raceQualifier. O limite é 40%; revise a distribuição antes de aplicar o plano. Sessões/provas consideradas: $breakdown.$targetNote"
            }

            val secondLargestWorkout = weekWorkouts
                .filter { it.instanceKey != longRun.instanceKey }
                .maxOfOrNull { it.workout.distanceKm }
            if (secondLargestWorkout != null && longRun.workout.distanceKm <= secondLargestWorkout + 1e-9) {
                issues += "O longão da semana ${weekMonday} não é maior que a segunda maior sessão. Revise a distribuição semanal."
            }
        }
        return issues.distinct()
    }

    fun weekStart(date: LocalDate): LocalDate = date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))

    fun weekOffset(date: LocalDate, anchor: LocalDate): Int =
        (ChronoUnit.DAYS.between(weekStart(anchor), weekStart(date)) / 7L).toInt()

    private fun formatKm(value: Double): String = String.format(Locale.US, "%.1f", value)
    private fun formatPercent(value: Double): String = String.format(Locale.US, "%.1f", value * 100.0)
}
