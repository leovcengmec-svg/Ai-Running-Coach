package com.airunningcoach.app

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.time.temporal.TemporalAdjusters
import java.util.Locale

/** Final guard applied after generation, race replacement and manual-date restoration. */
internal object TrainingCalendarIntegrityEngine {
    private data class DatedWorkout(val workout: Workout, val date: LocalDate) {
        val instanceKey: String
            get() = buildString {
                append(workout.sessionId.ifBlank { workout.title })
                append('|').append(date)
                append('|').append(workout.type.trim().uppercase(Locale.ROOT))
            }

        // A scheduled four-week retest has no distance until the athlete chooses Cooper or 3 km.
        // It is a valid calendar commitment, not a zero-kilometre workout or malformed activity.
        val isUndecidedPhysiologicalRetest: Boolean
            get() = workout.stimulus.startsWith("PHYSIOLOGICAL_RETEST") &&
                workout.type.equals("Teste fisiológico", ignoreCase = true) &&
                workout.retestMethod.isBlank() && workout.distanceKm == 0.0
    }

    private data class DatedRace(val race: RaceEvent, val date: LocalDate) {
        val instanceKey: String get() = "${race.id}|$date"
    }

    fun validate(
        workouts: List<Workout>,
        races: List<RaceEvent>,
        weeklyFrequency: Int,
        today: LocalDate = LocalDate.now(),
        retestAssessment: CooperAssessmentRecord? = null
    ): List<String> {
        val issues = mutableListOf<String>()
        if (weeklyFrequency !in 1..7) {
            issues += "A frequência semanal configurada é inválida."
            return issues
        }

        val currentMonday = weekStart(today)
        val datedWorkouts = workouts.mapNotNull { workout ->
            val rawDate = workout.scheduledDateIso.trim()
            if (rawDate.isBlank()) return@mapNotNull null // Legacy sessions can be display-only.
            val date = runCatching { LocalDate.parse(rawDate) }.getOrNull()
            if (date == null) {
                issues += "A sessão '${workout.title.ifBlank { workout.type }}' possui uma data inválida ('$rawDate'). Corrija a data antes de aplicar o plano."
                return@mapNotNull null
            }
            DatedWorkout(workout, date)
        }.distinctBy { it.instanceKey }

        val currentSunday = currentMonday.plusDays(6)
        val datedRaces = races.asSequence()
            // Planned future races are prospective load; a completed race in the current
            // week contributes realized load but never reserves a future day.
            .mapNotNull { race ->
                val date = race.dateOrNull() ?: return@mapNotNull null
                val contributesLoad = (race.status == "PLANNED" && !date.isBefore(today)) ||
                    (race.status == "COMPLETED" && date in currentMonday..currentSunday)
                if (contributesLoad) DatedRace(race, date) else null
            }
            .distinctBy { it.instanceKey }
            .toList()

        // Future frequency and conflicts are based only on unfinished commitments from today.
        // Completed sessions remain available for historical/load context, but never reserve a future day.
        val pendingFutureWorkouts = datedWorkouts.filter { !it.workout.done && !it.date.isBefore(today) }
        val pendingFutureRaces = datedRaces.filter { it.race.status == "PLANNED" && !it.date.isBefore(today) }

        pendingFutureWorkouts.groupBy { it.date }.filterValues { it.size > 1 }.forEach { (date, rows) ->
            val names = rows.joinToString(", ") { it.workout.title.ifBlank { it.workout.type } }
            issues += "Há ${rows.size} sessões pendentes no mesmo dia (${date}): $names. Mantenha no máximo um treino por data."
        }

        val pendingWorkoutDates = pendingFutureWorkouts.map { it.date }.toSet()
        pendingFutureRaces.filter { it.date in pendingWorkoutDates }.forEach { (race, date) ->
            val conflicting = pendingFutureWorkouts.filter { it.date == date }
                .joinToString(", ") { it.workout.title.ifBlank { it.workout.type } }
            issues += "A prova '${race.name}' conflita com treino(s) pendente(s) em ${date}: $conflicting. A competição deve substituir ou deslocar essa sessão."
        }

        // Count distinct calendar days, not list entries. A workout and a race on the same
        // day are one frequency day (the overlap is reported separately as a conflict).
        val commitmentDatesByWeek = (pendingFutureWorkouts.filterNot { it.workout.isOptionalExtra }.map { it.date } +
            pendingFutureRaces.map { it.date })
            .distinct()
            .groupBy { weekStart(it) }
        commitmentDatesByWeek.forEach { (weekMonday, dates) ->
            if (dates.size > weeklyFrequency) {
                val weekEnd = weekMonday.plusDays(6)
                issues += "A semana ${weekMonday} a ${weekEnd} possui ${dates.size} dias com compromissos futuros (treinos e provas), acima dos $weeklyFrequency dias configurados."
            }
        }

        // Weekly load uses the unique planned/realized instances, including completed sessions
        // retained in the current week and each planned race exactly once. Optional extras add
        // physiological load but do not consume a primary training-frequency day.
        val relevantWeeks = (datedWorkouts.map { weekStart(it.date) } + datedRaces.map { weekStart(it.date) })
            .filter { !it.isBefore(currentMonday) }
            .distinct()
            .sorted()

        relevantWeeks.forEach { weekMonday ->
            val weekEnd = weekMonday.plusDays(6)
            val weekWorkouts = datedWorkouts.filter { it.date in weekMonday..weekEnd }
            val weekRaces = datedRaces.filter { it.date in weekMonday..weekEnd }

            val invalidDistance = weekWorkouts.firstOrNull {
                !it.isUndecidedPhysiologicalRetest &&
                    (!it.workout.distanceKm.isFinite() || it.workout.distanceKm <= 0.0)
            }
            if (invalidDistance != null) {
                issues += "A sessão '${invalidDistance.workout.title.ifBlank { invalidDistance.workout.type }}' da semana ${weekMonday} possui distância inválida; a participação do longão não pode ser validada."
                return@forEach
            }
            val invalidRace = weekRaces.firstOrNull { !it.race.distanceKm.isFinite() || it.race.distanceKm <= 0.0 }
            if (invalidRace != null) {
                issues += "A prova '${invalidRace.race.name}' da semana ${weekMonday} possui distância inválida; a participação do longão não pode ser validada."
                return@forEach
            }

            // A week already in progress may have only its remaining sessions after onboarding
            // or restoration. Apply the 40% check only when the configured number of distinct
            // primary days is represented by realized sessions, future sessions and races.
            val currentWeekEvidenceDays = (weekWorkouts.filterNot { it.workout.isOptionalExtra }.map { it.date } +
                weekRaces.map { it.date }).distinct().size
            val isPartialCurrentWeek = weekMonday == currentMonday && today.isAfter(currentMonday) &&
                currentWeekEvidenceDays < weeklyFrequency
            if (isPartialCurrentWeek) return@forEach

            val longRuns = weekWorkouts.filter {
                !it.workout.isOptionalExtra && it.workout.type.equals("Longo", ignoreCase = true)
            }
            if (longRuns.size > 1) {
                issues += "A semana ${weekMonday} possui ${longRuns.size} sessões de longão. Deve existir no máximo um longão principal."
            }
            val longRun = longRuns.maxByOrNull { it.workout.distanceKm } ?: return@forEach
            val knownWorkoutKm = weekWorkouts.filterNot { it.isUndecidedPhysiologicalRetest }
                .sumOf { it.workout.distanceKm }
            val weekRacesKm = weekRaces.sumOf { it.race.distanceKm }
            val undecidedRetests = weekWorkouts.filter { it.isUndecidedPhysiologicalRetest }
            val retestBudgets = undecidedRetests.associate { retest ->
                retest.instanceKey to resolvePendingRetestBudget(retest.workout, retestAssessment)
            }
            val unresolvedRetests = retestBudgets.filterValues { it.distanceKm == null }
            val reservedRetestKm = retestBudgets.values.mapNotNull { it.distanceKm }.sum()
            // A pending retest replaces the original session slot. Prefer its persisted
            // snapshot distance; otherwise use a complete protocol estimate. Never add the
            // retest to the old session and never substitute a generic 5 km constant.
            val totalKm = knownWorkoutKm + weekRacesKm + reservedRetestKm
            if (totalKm <= 0.0) return@forEach

            // If any legacy retest has neither a valid slot snapshot nor a complete estimate,
            // defer only the exact 40% and long-run-dominance checks until protocol selection.
            // The agenda commitment and all date/frequency/conflict checks remain active.
            val hasCompleteRetestBudget = unresolvedRetests.isEmpty()
            val share = longRun.workout.distanceKm / totalKm
            val shareIsOverLimit = hasCompleteRetestBudget && share > 0.40 + 1e-9

            if (shareIsOverLimit) {
                val workoutBreakdown = weekWorkouts.sortedBy { it.date }.joinToString("; ") { row ->
                    val label = row.workout.title.ifBlank { row.workout.type }
                    val flags = buildList {
                        if (row.workout.sessionId.isNotBlank()) add("id=${row.workout.sessionId}")
                        if (row.workout.isOptionalExtra) add("extra opcional")
                        if (row.workout.manuallyRescheduled) add("reagendada manualmente")
                        add(if (row.workout.done) "concluído" else "planejado")
                    }.joinToString(", ")
                    if (row.isUndecidedPhysiologicalRetest) {
                        val budget = retestBudgets[row.instanceKey]
                        val reservation = budget?.distanceKm?.let { "; vaga original reservada ${formatKm(it)} km (${budget.source})" }
                            ?: "; vaga original sem orçamento confiável; validação pendente"
                        "$label (método a definir$reservation; ${row.date}; $flags)"
                    } else {
                        "$label ${formatKm(row.workout.distanceKm)} km (${row.date}; $flags)"
                    }
                }.ifBlank { "nenhuma sessão" }
                val raceBreakdown = weekRaces.sortedBy { it.date }.joinToString("; ") { row ->
                    "Prova ${row.race.name} ${formatKm(row.race.distanceKm)} km (${row.date}; id=${row.race.id}; ${row.race.status})"
                }
                val breakdown = listOf(workoutBreakdown, raceBreakdown).filter { it.isNotBlank() }.joinToString("; ")
                val storedTarget = weekWorkouts.mapNotNull { it.workout.weeklyTargetKm }
                    .filter { it.isFinite() && it > 0.0 }.maxOrNull()
                val targetNote = storedTarget?.let {
                    " Meta semanal registrada: ${formatKm(it)} km; composição considerada: ${formatKm(totalKm)} km."
                }.orEmpty()
                val raceQualifier = if (weekRaces.isNotEmpty()) ", incluindo provas" else ""
                issues += "O longão de ${formatKm(longRun.workout.distanceKm)} km representa ${formatPercent(share)}% do volume reservado na semana ${weekMonday}$raceQualifier. O limite é 40%; revise a distribuição antes de aplicar o plano. Sessões/provas consideradas: $breakdown.$targetNote"
            }

            if (hasCompleteRetestBudget) {
                val secondLargestWorkout = weekWorkouts
                    .filter { it.instanceKey != longRun.instanceKey }
                    .mapNotNull { row ->
                        if (row.isUndecidedPhysiologicalRetest) retestBudgets[row.instanceKey]?.distanceKm
                        else row.workout.distanceKm
                    }
                    .maxOrNull()
                if (secondLargestWorkout != null && longRun.workout.distanceKm <= secondLargestWorkout + 1e-9) {
                    issues += "O longão da semana ${weekMonday} não é maior que a segunda maior sessão. Revise a distribuição semanal."
                }
            }
        }
        return issues.distinct()
    }

    private data class PendingRetestBudget(val distanceKm: Double?, val source: String)

    private fun resolvePendingRetestBudget(
        workout: Workout,
        assessment: CooperAssessmentRecord?
    ): PendingRetestBudget {
        val snapshotKm = workout.retestOriginalSession?.distanceKm
            ?.takeIf { it.isFinite() && it > 0.0 }
        if (snapshotKm != null) return PendingRetestBudget(snapshotKm, "snapshot da sessão substituída")

        val activeAssessment = assessment ?: return PendingRetestBudget(null, "sem avaliação fisiológica ativa")
        val eligibleMethods = listOf(RetestProtocolEngine.COOPER_12_MIN, RetestProtocolEngine.THREE_KM)
            .filter { method ->
                RetestProtocolEngine.isMethodEligible(
                    method = method,
                    ageAtTest = activeAssessment.ageAtTest,
                    referenceSex = activeAssessment.referenceSex
                )
            }
        if (eligibleMethods.isEmpty()) return PendingRetestBudget(null, "nenhum protocolo elegível com dados demográficos")

        val estimates = eligibleMethods.map { method ->
            RetestDistanceEstimator.estimate(activeAssessment, testMethodOverride = method)
        }
        // A complete estimate is required for every eligible method because the athlete may
        // choose either protocol. A partial estimate could understate the eventual full session.
        if (estimates.any { it.isPartial || !it.totalKm.isFinite() || it.totalKm <= 0.0 }) {
            return PendingRetestBudget(null, "estimativa incompleta do protocolo")
        }
        val maximumCompleteEstimate = estimates.maxOf { it.totalKm }
        return PendingRetestBudget(maximumCompleteEstimate, "maior sessão completa entre os protocolos elegíveis")
    }

    fun weekStart(date: LocalDate): LocalDate = date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))

    fun weekOffset(date: LocalDate, anchor: LocalDate): Int =
        (ChronoUnit.DAYS.between(weekStart(anchor), weekStart(date)) / 7L).toInt()

    private fun formatKm(value: Double): String = String.format(Locale.US, "%.1f", value)
    private fun formatPercent(value: Double): String = String.format(Locale.US, "%.1f", value * 100.0)
}
