package com.airunningcoach.app

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Friendly and stable name shared by the preview, JSON workoutName and .json attachment. */
internal object WorkoutExportNaming {
    private val dateFormatter = DateTimeFormatter.ofPattern("dd.MM", Locale.ROOT)

    fun name(workout: Workout, allWorkouts: List<Workout>): String {
        val week = workout.week.coerceAtLeast(1)
        val sameWeek = allWorkouts
            .filter { it.week.coerceAtLeast(1) == week }
            .sortedWith(compareBy<Workout> { it.scheduledDateIso }.thenBy { it.sessionId })
        val trainingNumber = (sameWeek.indexOfFirst { it.sessionId == workout.sessionId } + 1).coerceAtLeast(1)
        val date = runCatching { LocalDate.parse(workout.scheduledDateIso).format(dateFormatter) }
            .getOrElse { "data" }
        val title = WorkoutTitleSanitizer.clean(workout.title)
        return "Semana $week · Treino $trainingNumber · $title · $date"
    }

    fun safeFileBaseName(name: String): String = name
        .replace(Regex("[\\/:*?\"<>|\\p{Cntrl}]"), "")
        .replace(Regex("\\s+"), " ")
        .trim(' ', '.', '_', '-')
        .take(120)
        .ifBlank { "Treino" }
}
