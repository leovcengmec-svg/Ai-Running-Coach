package com.airunningcoach.app

import java.text.Normalizer
import java.util.Locale

/** Stable compact identifier shared by export preview, UserWorkoutJson workoutName and attachment. */
internal object WorkoutExportNaming {
    private val protocolSuffix = Regex("(?i)(?:^|:)(F0[1-4]|T0[1-5]|I\\d{2}|RP\\d{2}|CC01)$")
    private val dosePattern = Regex("(?i)(\\d+)\\s*[x×]\\s*(\\d+(?:[.,]\\d+)?)\\s*(min(?:utos?)?|m|km)")
    private val canonicalExportName = Regex("(?i)^S\\d+_T\\d+_(INI|REG|ROD|FAR|TMP|INT|LNG|PRV|TES)_[A-Z0-9]+(?:_[A-Z0-9]+)*$")

    fun name(workout: Workout, allWorkouts: List<Workout>): String {
        val week = workout.week.coerceAtLeast(1)
        val sameWeek = allWorkouts
            .filter { it.week.coerceAtLeast(1) == week }
            .sortedWith(compareBy<Workout> { it.scheduledDateIso }.thenBy { it.sessionId })
        val workoutIdentityDate = SessionIdentityEngine.identityDate(
            workout.scheduledDateIso, workout.originalScheduledDateIso
        )
        val trainingNumber = (sameWeek.indexOfFirst { candidate ->
            candidate.sessionId == workout.sessionId &&
                SessionIdentityEngine.identityDate(candidate.scheduledDateIso, candidate.originalScheduledDateIso) == workoutIdentityDate &&
                candidate.type == workout.type
        } + 1).coerceAtLeast(1)
        return compactName(
            week, trainingNumber, workout.type, workout.stimulus, workout.title, workout.segments
        )
    }

    /** Fallback used by direct exporter callers that do not have the full week list. */
    fun name(workout: PrescribedWorkout, trainingNumber: Int = 1): String = compactName(
        workout.week, trainingNumber, workout.type, workout.stimulus, workout.title, workout.segments
    )

    /**
     * The exporter accepts an optional preview name only when it already follows the compact
     * contract. Legacy/descriptive labels are presentation text and must never leak into the
     * attachment name or UserWorkoutJson.workoutName.
     */
    fun normalizeForExport(workout: PrescribedWorkout, proposedName: String?): String {
        val candidate = proposedName?.trim().orEmpty()
        return if (canonicalExportName.matches(candidate)) safeFileBaseName(candidate)
        else name(workout, trainingNumber = 1)
    }

    private fun compactName(
        rawWeek: Int,
        rawTrainingNumber: Int,
        type: String,
        stimulus: String,
        title: String,
        segments: List<WorkoutSegment>
    ): String {
        val week = rawWeek.coerceAtLeast(1)
        val trainingNumber = rawTrainingNumber.coerceAtLeast(1)
        val category = WorkoutCalendarCategory.resolve(type, stimulus, title)
        val modality = WorkoutCalendarCategory.shortCode(category)
        val protocolCode = protocolSuffix.find(stimulus.trim())?.groupValues?.getOrNull(1)?.uppercase(Locale.ROOT)
        val variant = protocolDoseVariant(protocolCode, segments)
            ?: titleVariant(title, category, protocolCode, segments)
        return safeFileBaseName("S${week}_T${trainingNumber}_${modality}_${variant}")
    }

    private fun protocolDoseVariant(code: String?, segments: List<WorkoutSegment>): String? {
        val protocol = TrainingProtocolCatalog.find(code) ?: return null
        val workCount = segments
            .filter { it.name.equals("Intervalo", true) || it.name.startsWith("Intervalo ", true) }
            .sumOf { it.repeatCount }
            .takeIf { it > 0 } ?: protocol.repetitions
        val dose = when (protocol.targetMode) {
            "DISTANCE" -> "${protocol.workDistanceMeters}m"
            else -> "${protocol.workDurationMinutes}min"
        }
        return if (protocol.family == "RACE_PACE") "Ritmo${code?.removePrefix("RP") ?: ""}km_${workCount}x$dose"
        else "${workCount}x$dose"
    }

    private fun titleVariant(
        title: String,
        category: String,
        protocolCode: String?,
        segments: List<WorkoutSegment>
    ): String {
        if (protocolCode == "T01" || category == WorkoutCalendarCategory.TEMPO_RUN) {
            val zone = segments.asSequence()
                .filterNot { segment ->
                    val name = segment.name.lowercase(Locale.ROOT)
                    name.contains("aquec") || name.contains("desaquec") || name.contains("recuper")
                }
                .mapNotNull { it.paceZone }
                .firstOrNull { it in setOf("Z3", "Z4") }
            return "Continuo${zone.orEmpty()}"
        }
        if (category == WorkoutCalendarCategory.RODAGEM) {
            val upperTitle = title.uppercase(Locale.ROOT)
            val zones = (Regex("Z[1-5]").findAll(upperTitle).map { it.value } +
                segments.mapNotNull { it.paceZone }).distinct().joinToString("")
            return when {
                upperTitle.contains("PROGRESS") -> "Progressiva${zones.ifBlank { "Z2" }}"
                upperTitle.contains("REGRESS") -> "Regressiva${zones.ifBlank { "Z2" }}"
                upperTitle.contains("ACELERA") || upperTitle.contains("STRIDES") -> "Aceleracoes"
                else -> "Continua${zones.ifBlank { "Z2" }}"
            }
        }
        dosePattern.find(title)?.let { match ->
            val reps = match.groupValues[1]
            val rawDose = match.groupValues[2].replace(',', '.')
            val dose = if (rawDose.endsWith(".0")) rawDose.dropLast(2) else rawDose
            val unit = when {
                match.groupValues[3].startsWith("min", true) -> "min"
                match.groupValues[3].equals("km", true) -> "km"
                else -> "m"
            }
            return "${reps}x$dose$unit"
        }

        val cleaned = Normalizer.normalize(WorkoutTitleSanitizer.clean(title), Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
            .replace(Regex("(?i)longao|longo|rodagem|fartlek|tempo\\s*run|tempo\\s*intervalado|intervalado|regenerativo|recuperacao|iniciacao|prova|teste"), " ")
        val tokens = Regex("[A-Za-z]+|Z[1-5]|\\d+").findAll(cleaned).map { it.value }.toList()
        val compact = tokens.joinToString("") { token ->
            when {
                token.matches(Regex("(?i)Z[1-5]")) -> token.uppercase(Locale.ROOT)
                token.all(Char::isDigit) -> token
                else -> token.lowercase(Locale.ROOT).replaceFirstChar { it.titlecase(Locale.ROOT) }
            }
        }
        if (compact.isNotBlank()) return compact.take(36)
        return when (category) {
            WorkoutCalendarCategory.REGENERATIVO -> "Leve"
            WorkoutCalendarCategory.RODAGEM -> "ContinuaZ2"
            WorkoutCalendarCategory.FARTLEK -> "Variavel"
            WorkoutCalendarCategory.TEMPO_RUN -> "Continuo"
            WorkoutCalendarCategory.INTERVALADO_QUALIDADE -> "Intervalado"
            WorkoutCalendarCategory.LONGAO -> "ProgressivoZ2"
            WorkoutCalendarCategory.INICIACAO -> "CorridaCaminhada"
            WorkoutCalendarCategory.PROVA -> "Evento"
            WorkoutCalendarCategory.TESTE -> "Fisiologico"
            else -> "Treino"
        }
    }

    fun safeFileBaseName(name: String): String = name
        .replace(Regex("[\\/:*?\"<>|\\p{Cntrl}]"), "")
        .replace(Regex("\\s+"), " ")
        .trim(' ', '.', '_', '-')
        .take(120)
        .ifBlank { "Treino" }
}
