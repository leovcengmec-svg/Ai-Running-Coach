package com.airunningcoach.app

/** Stable filename shared by export preview, UserWorkoutJson workoutName and JSON attachment. */
internal object WorkoutExportNaming {
    fun name(workout: Workout, allWorkouts: List<Workout>): String {
        val week = workout.week.coerceAtLeast(1)
        val sameWeek = allWorkouts
            .filter { it.week.coerceAtLeast(1) == week }
            .sortedWith(compareBy<Workout> { it.scheduledDateIso }.thenBy { it.sessionId })
        val workoutIdentityDate = SessionIdentityEngine.identityDate(
            workout.scheduledDateIso, workout.originalScheduledDateIso
        )
        val trainingNumber = (sameWeek.indexOfFirst { candidate ->
            candidate.sessionId == workout.sessionId &&
                SessionIdentityEngine.identityDate(candidate.scheduledDateIso, candidate.originalScheduledDateIso) == workoutIdentityDate &&
                candidate.type == workout.type
        } + 1).coerceAtLeast(1)
        val title = WorkoutTitleSanitizer.clean(workout.title)
        return "S${week}_T${trainingNumber}_${title}"
    }

    fun safeFileBaseName(name: String): String = name
        .replace(Regex("[\\/:*?\"<>|\\p{Cntrl}]"), "")
        .replace(Regex("\\s+"), " ")
        .trim(' ', '.', '_', '-')
        .take(120)
        .ifBlank { "Treino" }
}
