package com.airunningcoach.app

/**
 * Gate for a beginner run/walk workout path.
 * Blank load fields are not evidence of being a beginner: they are populated from the
 * selected-goal reference. This ordinary pathway requires an explicit zero/zero declaration.
 * Return-from-injury programming is intentionally a separate, explicit workflow and must
 * never be inferred from a pain flag or missing activity history.
 */
internal object RunWalkEligibilityEngine {
    fun isEligible(
        goalKm: Double,
        physiologicalLevel: String,
        experienceMonths: Int,
        weeklyKmEntered: Double?,
        longestContinuousKmEntered: Double?,
        hasCompletedFiveKm: Boolean
    ): Boolean {
        val trueBeginner = RunnerFitnessAssessmentEngine.normalizeLevel(physiologicalLevel) == "Iniciante" &&
            experienceMonths in 0..6
        val explicitlyNoRecentRunning = weeklyKmEntered == 0.0 && longestContinuousKmEntered == 0.0
        val hasFiveKmEvidence = hasCompletedFiveKm || (longestContinuousKmEntered ?: 0.0) >= 5.0
        return goalKm in 1.0..5.5 && trueBeginner && explicitlyNoRecentRunning && !hasFiveKmEvidence
    }
}
