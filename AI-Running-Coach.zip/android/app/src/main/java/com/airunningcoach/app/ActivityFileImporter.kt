package com.airunningcoach.app

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import java.time.Instant
import java.io.StringReader
import java.time.format.DateTimeParseException
import javax.xml.parsers.DocumentBuilderFactory
import org.w3c.dom.Element
import org.w3c.dom.Node
import org.w3c.dom.NodeList
import org.xml.sax.InputSource
import javax.xml.XMLConstants
import kotlin.math.*

/** Parsed running metrics. Heart-rate data is deliberately ignored by V81; legacy model fields stay nullable for backup compatibility. */
internal data class ImportedActivity(
    val sourceFormat: String,
    val fingerprint: String,
    val startedAtIso: String?,
    /** TRACK_POINT, SESSION or METADATA; documents the timestamp provenance. */
    val startedAtSource: String = "",
    val distanceKm: Double?,
    val elapsedSeconds: Int?,
    val averagePaceMmSs: String?,
    val elevationGainMeters: Double?,
    /** Legacy-only fields: the V81 importer never populates or uses them. */
    val averageHeartRateBpm: Int? = null,
    val maxHeartRateBpm: Int? = null,
    val averageCadenceSpm: Int?,
    val maxCadenceSpm: Int?,
    val routePointCount: Int,
    val splitPacesMmSs: List<String>,
    val splitDetails: List<ActivitySplit> = emptyList(),
    val encodedRoute: String,
    /** Time-weighted pace samples derived from timestamped track points; empty when unavailable. */
    val paceSegments: List<ActivityPaceSegment> = emptyList()
)

internal data class ActivitySplit(
    val label: String,
    val distanceMeters: Double,
    val durationSeconds: Int?,
    val paceSecondsPerKm: Int?,
    val sourceType: String,
    val startDistanceMeters: Double? = null
)

internal data class ActivityPaceSegment(
    val paceSecondsPerKm: Int,
    val durationSeconds: Int,
    /** Seconds from the activity start to this measured sample. Null for legacy backups. */
    val startElapsedSeconds: Int? = null,
    /** Cumulative distance at the beginning of this sample. */
    val startDistanceMeters: Double? = null,
    val distanceMeters: Double? = null,
    /** Legacy-only backup field: retained for old records, never populated by V81 imports. */
    val averageHeartRateBpm: Int? = null,
    val averageCadenceSpm: Int? = null,
    /** EXPLICIT_LAP when taken from device/file lap boundaries; TRACK_SAMPLE for reconstructed GPS intervals. */
    val sourceType: String = "TRACK_SAMPLE",
    val sourceBlockIndex: Int? = null
)

internal class ActivityImportException(message: String) : Exception(message)

/** Offline GPX 1.1, TCX and common FIT record/session importer. */
internal object ActivityFileImporter {
    private const val MAX_FILE_BYTES = 25 * 1024 * 1024
    private const val EARTH_RADIUS_METERS = 6_371_000.0
    private const val PACECOACH_NAMESPACE = "https://pacecoach.app/gpx/1"
    private val fitEpoch = Instant.parse("1989-12-31T00:00:00Z")

    fun import(input: InputStream, filename: String): ImportedActivity {
        val bytes = input.use { stream ->
            val output = ByteArrayOutputStream()
            val buffer = ByteArray(16 * 1024)
            var total = 0
            while (true) {
                val count = stream.read(buffer)
                if (count < 0) break
                total += count
                if (total > MAX_FILE_BYTES) throw ActivityImportException("O arquivo excede o limite de 25 MB.")
                output.write(buffer, 0, count)
            }
            output.toByteArray()
        }
        if (bytes.isEmpty()) throw ActivityImportException("O arquivo selecionado está vazio.")
        val extension = filename.substringAfterLast('.', "").lowercase()
        val format = when (extension) {
            "gpx" -> "GPX"
            "tcx" -> "TCX"
            "fit" -> "FIT"
            else -> throw ActivityImportException("Formato não reconhecido. Selecione um arquivo GPX, FIT ou TCX.")
        }
        val fingerprint = MessageDigest.getInstance("SHA-256").digest(bytes)
            .joinToString("") { "%02x".format(it) }
        val parsed = try {
            when (format) {
                "GPX" -> parseGpx(bytes)
                "TCX" -> parseTcx(bytes)
                else -> parseFit(bytes)
            }
        } catch (error: ActivityImportException) {
            throw error
        } catch (error: Exception) {
            throw ActivityImportException("Não foi possível interpretar o arquivo $format: ${error.message ?: "estrutura inválida"}.")
        }
        val distance = parsed.distanceMeters?.takeIf { it.isFinite() && it in 20.0..200_000.0 }
        val elapsed = parsed.elapsedSeconds?.takeIf { it in 1..172_800 }
        val pace = if (distance != null && elapsed != null) {
            PaceCalculator.paceFromDistanceAndDuration(distance / 1000.0, elapsed)?.let(PaceRange::format)
        } else null
        if (distance == null && parsed.points.count { it.latitude != null && it.longitude != null } < 2) {
            throw ActivityImportException("O arquivo não contém distância nem pontos GPS suficientes para calculá-la.")
        }
        val splitDetails = buildActivitySplits(parsed.explicitLapSegments, parsed.points, distance, elapsed)
        // The legacy compact list represents a continuous sequence of completed split bins.
        // Stop at the first unknown bin instead of presenting a later residual fragment as
        // though the missing kilometre had been measured continuously.
        val normalizedSplitPaces = splitDetails.takeWhile { it.paceSecondsPerKm != null }
            .mapNotNull { it.paceSecondsPerKm?.let(PaceRange::format) }
        return ImportedActivity(
            sourceFormat = format,
            fingerprint = fingerprint,
            startedAtIso = parsed.startedAt?.toString(),
            startedAtSource = parsed.startedAtSource,
            distanceKm = distance?.div(1000.0),
            elapsedSeconds = elapsed,
            averagePaceMmSs = pace,
            elevationGainMeters = parsed.elevationGainMeters?.takeIf { it.isFinite() && it >= 0.0 },
            // V78 intentionally ignores HR even when the source FIT/TCX/GPX contains it.
            averageHeartRateBpm = null,
            maxHeartRateBpm = null,
            averageCadenceSpm = parsed.averageCadenceSpm?.takeIf { it in 30..260 },
            maxCadenceSpm = parsed.maxCadenceSpm?.takeIf { it in 30..300 },
            routePointCount = parsed.points.count { it.latitude != null && it.longitude != null },
            splitPacesMmSs = normalizedSplitPaces.ifEmpty { parsed.splitPaces },
            splitDetails = splitDetails,
            encodedRoute = encodeRoute(parsed.points),
            paceSegments = parsed.explicitLapSegments.takeIf { it.isNotEmpty() } ?: calculatePaceSegments(parsed.points)
        )
    }

    private data class TrackPoint(
        val latitude: Double? = null,
        val longitude: Double? = null,
        val elevationMeters: Double? = null,
        val time: Instant? = null,
        val cadenceSpm: Int? = null,
        val cumulativeDistanceMeters: Double? = null,
        /** Prevents artificial straight-line distance across separate GPX/TCX tracks. */
        val segmentId: Int = 0
    )

    private data class ParsedActivity(
        val points: List<TrackPoint>,
        val distanceMeters: Double?,
        val elapsedSeconds: Int?,
        val startedAt: Instant?,
        val startedAtSource: String,
        val elevationGainMeters: Double?,
        val averageHeartRateBpm: Int?,
        val maxHeartRateBpm: Int?,
        val averageCadenceSpm: Int?,
        val maxCadenceSpm: Int?,
        val splitPaces: List<String>,
        val explicitLapSegments: List<ActivityPaceSegment> = emptyList()
    )

    private fun parseGpx(bytes: ByteArray): ParsedActivity {
        val root = secureXml(bytes)
        var elements = descendants(root, "trkpt")
        if (elements.isEmpty()) elements = descendants(root, "rtept")
        val trackSegments = descendants(root, "trkseg")
        val pointGroups = when {
            trackSegments.isNotEmpty() -> trackSegments.mapIndexed { segmentIndex, segment ->
                descendants(segment, "trkpt").map { segmentIndex to it }
            }.filter { it.isNotEmpty() }
            elements.isNotEmpty() -> listOf(elements.map { 0 to it })
            else -> emptyList()
        }
        val points = pointGroups.flatMap { group -> group.map { (segmentIndex, element) ->
            val lat = element.getAttribute("lat").toDoubleOrNull()?.takeIf { it in -90.0..90.0 }
            val lon = element.getAttribute("lon").toDoubleOrNull()?.takeIf { it in -180.0..180.0 }
            TrackPoint(
                latitude = lat,
                longitude = lon,
                elevationMeters = childText(element, "ele")?.toDoubleOrNull()?.takeIf { it.isFinite() },
                time = parseInstant(childText(element, "time")),
                cadenceSpm = extensionValue(element, setOf("cad", "cadence"))?.toDoubleOrNull()?.roundToInt(),
                segmentId = segmentIndex
            )
        } }
        val derived = deriveFromPoints(points)

        // RunnerUp/Pace Coach GPX exports include authoritative activity totals and
        // lap blocks in the pacecoach namespace. Prefer those values over GPS-derived
        // totals, which can differ slightly because of sampling and coordinate rounding.
        val activity = descendants(root, "activity").firstOrNull { element ->
            element.namespaceURI == PACECOACH_NAMESPACE &&
                (element.hasAttribute("distance") || element.hasAttribute("time"))
        }
        val declaredDistance = activity?.getAttribute("distance")?.toDoubleOrNull()
            ?.takeIf { it.isFinite() && it in 20.0..200_000.0 }
        val declaredElapsed = activity?.getAttribute("time")?.toDoubleOrNull()
            ?.takeIf { it.isFinite() && it in 1.0..172_800.0 }?.roundToInt()
        val metadataStart = descendants(root, "metadata").firstOrNull()
            ?.let { metadata -> parseInstant(childText(metadata, "time")) }
        val structuredLaps = descendants(root, "lap")
            .filter { it.namespaceURI == PACECOACH_NAMESPACE }
            .mapNotNull { lap ->
                val distance = lap.getAttribute("distance").toDoubleOrNull()
                val seconds = lap.getAttribute("time").toDoubleOrNull()
                if (distance == null || seconds == null || distance !in 5.0..20_000.0 || seconds !in 1.0..7_200.0) null
                else Triple(distance, seconds, lap.getAttribute("start").takeIf { it.isNotBlank() }?.let(::parseInstant))
            }
        var lapStartDistance = 0.0
        var lapElapsed = 0
        val explicitLapSegments = structuredLaps.mapIndexed { index, (distance, seconds, start) ->
            val duration = seconds.roundToInt()
            val pace = (duration * 1000.0 / distance).roundToInt()
            val segment = ActivityPaceSegment(
                paceSecondsPerKm = pace.coerceIn(120, 1_800), durationSeconds = duration,
                startElapsedSeconds = start?.let { lapStart ->
                    val base = derived.startedAt ?: metadataStart
                    base?.let { java.time.Duration.between(it, lapStart).seconds.toInt().coerceAtLeast(0) }
                } ?: lapElapsed,
                startDistanceMeters = lapStartDistance, distanceMeters = distance,
                sourceType = "EXPLICIT_LAP", sourceBlockIndex = index
            )
            lapStartDistance += distance
            lapElapsed += duration
            segment
        }
        val lapPaces = structuredLaps.mapNotNull { (distance, seconds, _) ->
            // Only expose approximately kilometre-long laps as kilometre splits.
            if (distance !in 900.0..1_100.0) null
            else PaceCalculator.paceFromDistanceAndDuration(distance / 1000.0, seconds.roundToInt())
                ?.let(PaceRange::format)
        }

        return derived.copy(
            distanceMeters = declaredDistance ?: derived.distanceMeters,
            elapsedSeconds = declaredElapsed ?: derived.elapsedSeconds,
            // GPX metadata time often represents file creation/export time. The first
            // timestamped track point is the authoritative activity start when present.
            startedAt = derived.startedAt ?: metadataStart,
            startedAtSource = when {
                derived.startedAt != null -> "TRACK_POINT"
                metadataStart != null -> "METADATA"
                else -> ""
            },
            splitPaces = lapPaces.takeIf { it.isNotEmpty() } ?: derived.splitPaces,
            explicitLapSegments = explicitLapSegments
        )
    }

    private fun parseTcx(bytes: ByteArray): ParsedActivity {
        val root = secureXml(bytes)
        val lapElements = descendants(root, "Lap")
        val trackpoints = descendants(root, "Trackpoint")
        val tracks = descendants(root, "Track")
        val pointGroups = if (tracks.isNotEmpty()) tracks.mapIndexed { segmentIndex, track ->
            descendants(track, "Trackpoint").map { segmentIndex to it }
        }.filter { it.isNotEmpty() } else listOf(trackpoints.map { 0 to it })
        val points = pointGroups.flatMap { group -> group.map { (segmentIndex, element) ->
            val position = descendants(element, "Position").firstOrNull()
            val lat = position?.let { childText(it, "LatitudeDegrees")?.toDoubleOrNull() }?.takeIf { it in -90.0..90.0 }
            val lon = position?.let { childText(it, "LongitudeDegrees")?.toDoubleOrNull() }?.takeIf { it in -180.0..180.0 }
            TrackPoint(
                latitude = lat,
                longitude = lon,
                elevationMeters = childText(element, "AltitudeMeters")?.toDoubleOrNull()?.takeIf { it.isFinite() },
                time = parseInstant(childText(element, "Time")),
                cadenceSpm = childText(element, "Cadence")?.toIntOrNull(),
                cumulativeDistanceMeters = childText(element, "DistanceMeters")?.toDoubleOrNull()?.takeIf { it >= 0.0 },
                segmentId = segmentIndex
            )
        } }
        val derived = deriveFromPoints(points)
        val lapDistances = lapElements.mapNotNull { childText(it, "DistanceMeters")?.toDoubleOrNull()?.takeIf { v -> v > 0.0 } }
        val lapDurations = lapElements.mapNotNull { childText(it, "TotalTimeSeconds")?.toDoubleOrNull()?.takeIf { v -> v > 0.0 } }
        val avgCadence = points.mapNotNull { it.cadenceSpm }.takeIf { it.isNotEmpty() }?.average()?.roundToInt()
        val activityStart = descendants(root, "Activity").firstOrNull()?.let { activity ->
            parseInstant(childText(activity, "Id"))
        }
        val lapStart = lapElements.firstOrNull()?.getAttribute("StartTime")?.let(::parseInstant)
        var lapDistanceOffset = 0.0
        var lapElapsedOffset = 0
        val explicitLapSegments = lapElements.mapIndexedNotNull { index, lap ->
            val distance = childText(lap, "DistanceMeters")?.toDoubleOrNull()?.takeIf { it in 5.0..20_000.0 }
            val seconds = childText(lap, "TotalTimeSeconds")?.toDoubleOrNull()?.takeIf { it in 1.0..7_200.0 }
            if (distance == null || seconds == null) return@mapIndexedNotNull null
            val duration = seconds.roundToInt()
            val start = lap.getAttribute("StartTime").takeIf { it.isNotBlank() }?.let(::parseInstant)
            val base = activityStart ?: derived.startedAt
            val elapsedStart = start?.let { startAt -> base?.let { java.time.Duration.between(it, startAt).seconds.toInt().coerceAtLeast(0) } }
                ?: lapElapsedOffset
            val pace = (duration * 1000.0 / distance).roundToInt()
            ActivityPaceSegment(
                paceSecondsPerKm = pace.coerceIn(120, 1_800), durationSeconds = duration,
                startElapsedSeconds = elapsedStart, startDistanceMeters = lapDistanceOffset,
                distanceMeters = distance, sourceType = "EXPLICIT_LAP", sourceBlockIndex = index
            ).also { lapDistanceOffset += distance; lapElapsedOffset += duration }
        }
        return derived.copy(
            distanceMeters = lapDistances.sum().takeIf { it > 0.0 } ?: derived.distanceMeters,
            elapsedSeconds = lapDurations.sum().roundToInt().takeIf { it > 0 } ?: derived.elapsedSeconds,
            startedAt = derived.startedAt ?: activityStart ?: lapStart,
            startedAtSource = when {
                derived.startedAt != null -> "TRACK_POINT"
                activityStart != null -> "SESSION"
                lapStart != null -> "LAP"
                else -> ""
            },
            averageCadenceSpm = avgCadence ?: derived.averageCadenceSpm,
            explicitLapSegments = explicitLapSegments
        )
    }

    private data class FitField(val number: Int, val size: Int, val baseType: Int)
    private data class FitDefinition(
        val globalMessage: Int,
        val bigEndian: Boolean,
        val fields: List<FitField>,
        val developerFieldsSize: Int
    )

    private fun parseFit(bytes: ByteArray): ParsedActivity {
        if (bytes.size < 14) throw ActivityImportException("Arquivo FIT incompleto.")
        val headerSize = bytes[0].toInt() and 0xFF
        if (headerSize !in 12..14 || bytes.size <= headerSize + 2) throw ActivityImportException("Cabeçalho FIT inválido.")
        if (bytes[8] != '.'.code.toByte() || bytes[9] != 'F'.code.toByte() ||
            bytes[10] != 'I'.code.toByte() || bytes[11] != 'T'.code.toByte()) {
            throw ActivityImportException("Assinatura .FIT ausente ou inválida.")
        }
        val dataSizeLong = readUInt32(bytes, 4, false)
        val dataStart = headerSize
        val availableDataBytes = bytes.size - dataStart - 2 // final FIT CRC
        if (dataSizeLong <= 0L || dataSizeLong > availableDataBytes.toLong()) {
            throw ActivityImportException("O FIT está truncado ou declara um tamanho de dados inválido.")
        }
        val dataSize = dataSizeLong.toInt()
        val dataEnd = dataStart + dataSize
        if (dataEnd <= dataStart) throw ActivityImportException("O FIT não contém mensagens de atividade.")

        val definitions = mutableMapOf<Int, FitDefinition>()
        val points = mutableListOf<TrackPoint>()
        var sessionDistanceMeters: Double? = null
        var sessionElapsedSeconds: Int? = null
        var sessionAverageCadence: Int? = null
        var sessionMaxCadence: Int? = null
        var sessionStart: Instant? = null
        data class RawFitLap(val start: Instant?, val durationSeconds: Int, val distanceMeters: Double)
        val rawLaps = mutableListOf<RawFitLap>()
        var lastTimestampSeconds: Long? = null
        var offset = dataStart

        while (offset < dataEnd) {
            val header = bytes[offset++].toInt() and 0xFF
            val compressed = (header and 0x80) != 0
            val localMessage = if (compressed) (header shr 5) and 0x03 else header and 0x0F
            val isDefinition = !compressed && (header and 0x40) != 0
            if (isDefinition) {
                if (offset + 5 > dataEnd) break
                offset++ // reserved
                val architecture = bytes[offset++].toInt() and 0xFF
                val bigEndian = architecture == 1
                val global = readUInt16(bytes, offset, bigEndian)
                offset += 2
                val fieldCount = bytes[offset++].toInt() and 0xFF
                if (fieldCount > 64 || offset + fieldCount * 3 > dataEnd) break
                val fields = mutableListOf<FitField>()
                repeat(fieldCount) {
                    val number = bytes[offset++].toInt() and 0xFF
                    val size = bytes[offset++].toInt() and 0xFF
                    val base = bytes[offset++].toInt() and 0xFF
                    fields += FitField(number, size, base)
                }
                var developerFieldsSize = 0
                if ((header and 0x20) != 0) {
                    if (offset >= dataEnd) break
                    val developerCount = bytes[offset++].toInt() and 0xFF
                    if (offset + developerCount * 3 > dataEnd) break
                    repeat(developerCount) {
                        offset++ // developer field number
                        developerFieldsSize += bytes[offset++].toInt() and 0xFF
                        offset++ // developer data index
                    }
                }
                definitions[localMessage] = FitDefinition(global, bigEndian, fields, developerFieldsSize)
                continue
            }
            val definition = definitions[localMessage] ?: throw ActivityImportException("Mensagem FIT sem definição local.")
            val messageBytes = definition.fields.sumOf { it.size } + definition.developerFieldsSize
            if (offset + messageBytes > dataEnd) break
            val values = mutableMapOf<Int, Double>()
            definition.fields.forEach { field ->
                val value = decodeFitNumber(bytes, offset, field.size, field.baseType, definition.bigEndian)
                if (value != null) values[field.number] = value
                offset += field.size
            }
            // Developer fields vary by device/profile. Skip their declared bytes
            // without interpreting them so subsequent standard messages stay aligned.
            offset += definition.developerFieldsSize
            val timestamp = values[253]?.toLong()?.takeIf { it in 1..0xFFFF_FFFEL }
                ?: if (compressed && lastTimestampSeconds != null) {
                    val compressedOffset = header and 0x1F
                    var candidate = (lastTimestampSeconds!! and 0xFFFF_FFE0L) + compressedOffset
                    if (candidate < lastTimestampSeconds!!) candidate += 32
                    candidate
                } else null
            if (timestamp != null) lastTimestampSeconds = timestamp
            val instant = timestamp?.let { fitEpoch.plusSeconds(it) }
            when (definition.globalMessage) {
                20 -> {
                    val lat = values[0]?.let { it / 2_147_483_648.0 * 180.0 }?.takeIf { it in -90.0..90.0 }
                    val lon = values[1]?.let { it / 2_147_483_648.0 * 180.0 }?.takeIf { it in -180.0..180.0 }
                    val altitude = values[2]?.let { it / 5.0 - 500.0 }
                    points += TrackPoint(
                        latitude = lat, longitude = lon, elevationMeters = altitude,
                        time = instant,
                        cadenceSpm = values[4]?.roundToInt(),
                        cumulativeDistanceMeters = values[5]?.div(100.0)
                    )
                }
                19 -> {
                    val duration = values[7]?.div(1000.0)?.roundToInt()
                    val distance = values[9]?.div(100.0)
                    if (duration != null && duration in 1..7_200 && distance != null && distance in 5.0..20_000.0) {
                        rawLaps += RawFitLap(values[2]?.toLong()?.let { fitEpoch.plusSeconds(it) }, duration, distance)
                    }
                }
                18 -> {
                    sessionStart = values[2]?.toLong()?.let { fitEpoch.plusSeconds(it) } ?: sessionStart
                    sessionElapsedSeconds = values[7]?.div(1000.0)?.roundToInt()?.takeIf { it > 0 } ?: sessionElapsedSeconds
                    sessionDistanceMeters = values[9]?.div(100.0)?.takeIf { it > 0.0 } ?: sessionDistanceMeters
                    sessionAverageCadence = values[17]?.roundToInt() ?: sessionAverageCadence
                    sessionMaxCadence = values[18]?.roundToInt() ?: sessionMaxCadence
                }
            }
        }
        val derived = deriveFromPoints(points)
        val resolvedStart = sessionStart ?: derived.startedAt
        var lapDistanceOffset = 0.0
        var lapElapsedOffset = 0
        val explicitLapSegments = rawLaps.mapIndexed { index, lap ->
            val elapsedStart = lap.start?.let { start -> resolvedStart?.let { java.time.Duration.between(it, start).seconds.toInt().coerceAtLeast(0) } }
                ?: lapElapsedOffset
            val pace = (lap.durationSeconds * 1000.0 / lap.distanceMeters).roundToInt()
            ActivityPaceSegment(
                paceSecondsPerKm = pace.coerceIn(120, 1_800), durationSeconds = lap.durationSeconds,
                startElapsedSeconds = elapsedStart, startDistanceMeters = lapDistanceOffset,
                distanceMeters = lap.distanceMeters, sourceType = "EXPLICIT_LAP", sourceBlockIndex = index
            ).also { lapDistanceOffset += lap.distanceMeters; lapElapsedOffset += lap.durationSeconds }
        }
        return derived.copy(
            distanceMeters = sessionDistanceMeters ?: points.mapNotNull { it.cumulativeDistanceMeters }.maxOrNull() ?: derived.distanceMeters,
            elapsedSeconds = sessionElapsedSeconds ?: derived.elapsedSeconds,
            startedAt = resolvedStart,
            startedAtSource = if (sessionStart != null) "SESSION" else derived.startedAtSource,
            averageCadenceSpm = sessionAverageCadence ?: derived.averageCadenceSpm,
            maxCadenceSpm = sessionMaxCadence ?: derived.maxCadenceSpm,
            explicitLapSegments = explicitLapSegments
        )
    }

    private fun deriveFromPoints(rawPoints: List<TrackPoint>): ParsedActivity {
        if (rawPoints.isEmpty()) return ParsedActivity(
            points = emptyList(), distanceMeters = null, elapsedSeconds = null, startedAt = null,
            startedAtSource = "", elevationGainMeters = null, averageHeartRateBpm = null,
            maxHeartRateBpm = null, averageCadenceSpm = null, maxCadenceSpm = null, splitPaces = emptyList()
        )
        var geometricDistance = 0.0
        var elevationGain = 0.0
        var previousCoordinate: TrackPoint? = null
        var previousElevation: Double? = null
        var cumulative = 0.0
        var lastSegmentId = -1
        var segmentDistanceOffset = 0.0
        val points = rawPoints.map { point ->
            val suppliedDistanceAtSegmentStart = point.cumulativeDistanceMeters
            if (point.segmentId != lastSegmentId) {
                // Some TCX exporters reset DistanceMeters at the start of each Track;
                // rebase those tracks without joining the GPS gap between them.
                segmentDistanceOffset = if (suppliedDistanceAtSegmentStart != null && suppliedDistanceAtSegmentStart < cumulative - 1.0) cumulative else 0.0
                previousCoordinate = null
                previousElevation = null
                lastSegmentId = point.segmentId
            }
            val previous = previousCoordinate
            val sameTrackSegment = previous != null && previous.segmentId == point.segmentId
            val previousLatitude = previous?.latitude
            val previousLongitude = previous?.longitude
            if (sameTrackSegment && point.latitude != null && point.longitude != null && previousLatitude != null && previousLongitude != null) {
                val step = haversine(previousLatitude, previousLongitude, point.latitude, point.longitude)
                // Ignore isolated GPS jumps that cannot represent a running segment.
                if (step.isFinite() && step in 0.5..2000.0) geometricDistance += step
            }
            if (point.latitude != null && point.longitude != null) previousCoordinate = point
            else if (previousCoordinate?.segmentId != point.segmentId) previousCoordinate = null
            val elevation = point.elevationMeters
            if (elevation != null && previousElevation != null) {
                val delta = elevation - previousElevation!!
                if (delta in 0.5..20.0) elevationGain += delta
            }
            if (elevation != null) previousElevation = elevation
            val suppliedDistance = point.cumulativeDistanceMeters?.takeIf { it >= 0.0 }?.plus(segmentDistanceOffset)
            if (suppliedDistance != null) cumulative = max(cumulative, suppliedDistance)
            else if (point.latitude != null && point.longitude != null && sameTrackSegment && previousLatitude != null && previousLongitude != null) {
                val step = haversine(previousLatitude, previousLongitude, point.latitude, point.longitude)
                if (step.isFinite() && step in 0.5..2000.0) cumulative += step
            }
            point.copy(cumulativeDistanceMeters = cumulative)
        }
        val validTimes = points.mapNotNull { it.time }
        val startedAt = validTimes.minOrNull()
        val endedAt = validTimes.maxOrNull()
        val elapsed = if (startedAt != null && endedAt != null && validTimes.size >= 2) {
            java.time.Duration.between(startedAt, endedAt).seconds
                .takeIf { it in 1L..172_800L }?.toInt()
        } else null
        val cadence = points.mapNotNull { it.cadenceSpm }.filter { it in 30..300 }
        val distance = points.mapNotNull { it.cumulativeDistanceMeters }.maxOrNull()?.takeIf { it > 0.0 }
            ?: geometricDistance.takeIf { it > 0.0 }
        val splits = calculateSplits(points)
        return ParsedActivity(
            points = points,
            distanceMeters = distance,
            elapsedSeconds = elapsed,
            startedAt = startedAt,
            startedAtSource = if (startedAt != null) "TRACK_POINT" else "",
            elevationGainMeters = elevationGain,
            averageHeartRateBpm = null,
            maxHeartRateBpm = null,
            averageCadenceSpm = cadence.takeIf { it.isNotEmpty() }?.average()?.roundToInt(),
            maxCadenceSpm = cadence.maxOrNull(),
            splitPaces = splits
        )
    }

    /**
     * Rebuilds an activity as cumulative whole-kilometre splits plus one final partial split.
     * Irregular device laps are proportionally apportioned only when a kilometre boundary cuts
     * through a lap; those rows are explicitly marked as reconstructed. Unknown coverage stays
     * visible without an invented pace.
     */
    private fun buildActivitySplits(
        explicit: List<ActivityPaceSegment>,
        points: List<TrackPoint>,
        totalDistanceMeters: Double?,
        totalElapsedSeconds: Int?
    ): List<ActivitySplit> {
        val total = totalDistanceMeters?.takeIf { it.isFinite() && it > 0.0 }
        if (total == null) {
            return explicit.mapIndexedNotNull { index, segment ->
                val distance = segment.distanceMeters ?: return@mapIndexedNotNull null
                if (distance <= 0.0) return@mapIndexedNotNull null
                ActivitySplit(
                    label = "Volta ${index + 1}", distanceMeters = distance,
                    durationSeconds = segment.durationSeconds, paceSecondsPerKm = segment.paceSecondsPerKm,
                    sourceType = "EXPLICIT_LAP", startDistanceMeters = segment.startDistanceMeters
                )
            }.ifEmpty { calculateSplitDetails(points, null) }
        }

        val gpsSplits = calculateSplitDetails(points, total)
        val lapSplits = aggregateExplicitLaps(explicit, total)
        val count = kotlin.math.ceil(total / 1000.0).toInt().coerceIn(1, 200)
        val output = ArrayList<ActivitySplit>(count)
        for (index in 0 until count) {
            val start = index * 1000.0
            val end = minOf(total, (index + 1) * 1000.0)
            val distance = (end - start).coerceAtLeast(0.0)
            if (distance <= 0.0) continue
            val lap = lapSplits.getOrNull(index)?.takeIf { it.distanceMeters >= distance - 20.0 }
            val gps = gpsSplits.getOrNull(index)?.takeIf { it.distanceMeters >= distance - 20.0 }
            val selected = when {
                // Prefer densely timed GPS when that exact bin has a duration; otherwise a
                // complete device-lap reconstruction is a better source than an unknown GPS bin.
                gps?.durationSeconds != null -> gps
                lap?.durationSeconds != null -> lap
                gps != null -> gps
                lap != null -> lap
                else -> null
            }
            val label = splitLabel(index, distance)
            output += if (selected != null) selected.copy(
                label = label, distanceMeters = distance, startDistanceMeters = start
            ) else ActivitySplit(
                label = label, distanceMeters = distance, durationSeconds = null,
                paceSecondsPerKm = null, sourceType = "ACTIVITY_SEGMENT_UNKNOWN", startDistanceMeters = start
            )
        }

        // If the file declares elapsed time but some distance bins have no measured/reconstructed
        // duration, do not distribute the remainder across them. Their pace remains unknown.
        // The activity total is retained independently and visible in the session metrics.
        return output
    }

    private fun aggregateExplicitLaps(
        explicit: List<ActivityPaceSegment>,
        totalDistanceMeters: Double
    ): List<ActivitySplit> {
        if (explicit.isEmpty()) return emptyList()
        data class LapInterval(val start: Double, val end: Double, val duration: Int, val pace: Int)
        var cursor = 0.0
        val laps = explicit.mapNotNull { segment ->
            val distance = segment.distanceMeters?.takeIf { it.isFinite() && it > 0.0 } ?: return@mapNotNull null
            val start = segment.startDistanceMeters?.takeIf { it.isFinite() && it >= 0.0 } ?: cursor
            val end = minOf(totalDistanceMeters, start + distance)
            cursor = maxOf(cursor, start + distance)
            val duration = segment.durationSeconds.takeIf { it > 0 } ?: return@mapNotNull null
            val pace = (duration * 1000.0 / distance).roundToInt().takeIf { it in 120..1800 }
                ?: segment.paceSecondsPerKm.takeIf { it in 120..1800 }
                ?: return@mapNotNull null
            if (end <= start) return@mapNotNull null
            LapInterval(start, end, duration, pace)
        }
        if (laps.isEmpty()) return emptyList()
        val count = kotlin.math.ceil(totalDistanceMeters / 1000.0).toInt().coerceIn(1, 200)
        return (0 until count).map { index ->
            val start = index * 1000.0
            val end = minOf(totalDistanceMeters, (index + 1) * 1000.0)
            val binDistance = end - start
            val overlaps = laps.mapNotNull { lap ->
                val overlap = (minOf(end, lap.end) - maxOf(start, lap.start)).coerceAtLeast(0.0)
                if (overlap <= 0.0) null else lap to overlap
            }
            val covered = overlaps.sumOf { it.second }
            val complete = covered >= binDistance - 5.0 && overlaps.isNotEmpty()
            val seconds = if (complete) overlaps.sumOf { (lap, overlap) -> lap.duration * (overlap / (lap.end - lap.start)) }
                .roundToInt().takeIf { it > 0 } else null
            val pace = seconds?.let { (it * 1000.0 / binDistance).roundToInt().takeIf { value -> value in 120..1800 } }
            val reconstructed = overlaps.size != 1 || overlaps.any { (lap, overlap) ->
                overlap < (lap.end - lap.start) - 1.0
            }
            ActivitySplit(
                label = splitLabel(index, binDistance),
                distanceMeters = binDistance, durationSeconds = seconds, paceSecondsPerKm = pace,
                sourceType = if (reconstructed) "EXPLICIT_LAP_AGGREGATED" else "EXPLICIT_LAP",
                startDistanceMeters = start
            )
        }
    }

    private fun splitLabel(index: Int, distanceMeters: Double): String =
        if (distanceMeters >= 999.5) "${index + 1}º km"
        else "Parcial final (${String.format(java.util.Locale.forLanguageTag("pt-BR"), "%.2f", distanceMeters / 1000.0)} km)"

    private fun calculateSplitDetails(points: List<TrackPoint>, declaredDistanceMeters: Double?): List<ActivitySplit> {
        data class TimedPoint(val distance: Double, val epoch: Long, val segmentId: Int)
        val timed = points.mapNotNull { point ->
            val distance = point.cumulativeDistanceMeters ?: return@mapNotNull null
            val time = point.time?.epochSecond ?: return@mapNotNull null
            TimedPoint(distance, time, point.segmentId)
        }
        if (timed.size < 2) {
            // Some GPX files contain a complete route but no point timestamps. Preserve
            // kilometer distance bins without fabricating durations or pace values.
            val routeDistances = points.mapNotNull { it.cumulativeDistanceMeters?.takeIf { value -> value.isFinite() && value >= 0.0 } }
            if (routeDistances.size < 2) return emptyList()
            val trackStart = routeDistances.first()
            val trackEnd = routeDistances.last()
            val total = declaredDistanceMeters?.takeIf { it.isFinite() && it > 0.0 } ?: trackEnd
            if (total <= trackStart) return emptyList()
            val count = kotlin.math.ceil(total / 1000.0).toInt().coerceIn(1, 200)
            return (0 until count).map { index ->
                val start = index * 1000.0
                val end = minOf(total, (index + 1) * 1000.0)
                val distance = end - start
                val fullyCovered = trackStart <= start + 5.0 && trackEnd >= end - 5.0
                ActivitySplit(
                    label = splitLabel(index, distance), distanceMeters = distance,
                    durationSeconds = null, paceSecondsPerKm = null,
                    sourceType = if (fullyCovered) "TRACK_DISTANCE_ONLY" else "ACTIVITY_SEGMENT_UNKNOWN",
                    startDistanceMeters = start
                )
            }
        }
        val trackStart = timed.first().distance
        val trackEnd = timed.last().distance
        val total = declaredDistanceMeters?.takeIf { it.isFinite() && it > 0.0 } ?: trackEnd
        if (total <= trackStart) return emptyList()

        fun timeAt(target: Double): Pair<Double, Int>? {
            val pair = timed.zipWithNext().firstOrNull { (a, b) ->
                val elapsedGap = b.epoch - a.epoch
                val distanceGap = b.distance - a.distance
                a.segmentId == b.segmentId && a.distance <= target && b.distance >= target &&
                    distanceGap > 0.0 && distanceGap <= 1_000.0 && elapsedGap in 1L..600L
            } ?: return null
            val fraction = (target - pair.first.distance) / (pair.second.distance - pair.first.distance)
            return (pair.first.epoch + fraction * (pair.second.epoch - pair.first.epoch)) to pair.first.segmentId
        }

        val count = kotlin.math.ceil(total / 1000.0).toInt().coerceIn(1, 200)
        return (0 until count).map { index ->
            val start = index * 1000.0
            val end = minOf(total, (index + 1) * 1000.0)
            val binDistance = end - start
            val actualStart = maxOf(start, trackStart)
            val actualEnd = minOf(end, trackEnd)
            val startTime = if (actualStart >= trackStart && actualStart <= trackEnd) {
                if (actualStart == trackStart) timed.first().epoch.toDouble() to timed.first().segmentId else timeAt(actualStart)
            } else null
            val endTime = if (actualEnd >= trackStart && actualEnd <= trackEnd) {
                if (actualEnd == trackEnd) timed.last().epoch.toDouble() to timed.last().segmentId else timeAt(actualEnd)
            } else null
            val fullyCoveredByTrack = actualStart <= start + 20.0 && actualEnd >= end - 20.0
            val seconds = if (fullyCoveredByTrack && startTime != null && endTime != null && startTime.second == endTime.second) {
                (endTime.first - startTime.first).roundToInt().takeIf { it > 0 }
            } else null
            val pace = seconds?.let { (it * 1000.0 / binDistance).roundToInt().takeIf { value -> value in 120..1800 } }
            ActivitySplit(
                label = splitLabel(index, binDistance),
                distanceMeters = binDistance, durationSeconds = seconds, paceSecondsPerKm = pace,
                sourceType = if (fullyCoveredByTrack && seconds != null) "TRACK_POINT" else "TRACK_DISTANCE_ONLY",
                startDistanceMeters = start
            )
        }
    }

    /**
     * Converts adjacent timestamped track points into measured pace segments. Very short,
     * implausible or long gaps are skipped rather than inventing zone time. Missing intervals
     * therefore remain unknown and are never filled from split estimates.
     */
    private fun calculatePaceSegments(points: List<TrackPoint>): List<ActivityPaceSegment> {
        val activityStart = points.mapNotNull { it.time }.minOrNull() ?: return emptyList()
        return points.zipWithNext().mapNotNull { (a, b) ->
            if (a.segmentId != b.segmentId) return@mapNotNull null
            val aDistance = a.cumulativeDistanceMeters ?: return@mapNotNull null
            val bDistance = b.cumulativeDistanceMeters ?: return@mapNotNull null
            val aTime = a.time?.epochSecond ?: return@mapNotNull null
            val bTime = b.time?.epochSecond ?: return@mapNotNull null
            val elapsed = bTime - aTime
            val distanceMeters = bDistance - aDistance
            // Long timestamp gaps, pauses and impossible jumps remain unknown rather than
            // being interpolated into a false pace or training-zone exposure.
            if (elapsed !in 1L..120L || !distanceMeters.isFinite() || distanceMeters !in 5.0..1_000.0) {
                return@mapNotNull null
            }
            val pace = (elapsed * 1000.0 / distanceMeters).roundToInt()
            if (pace !in 120..1800) return@mapNotNull null
            val cadenceValues = listOfNotNull(a.cadenceSpm, b.cadenceSpm).filter { it in 30..300 }
            ActivityPaceSegment(
                paceSecondsPerKm = pace,
                durationSeconds = elapsed.toInt(),
                startElapsedSeconds = (aTime - activityStart.epochSecond).coerceAtLeast(0).toInt(),
                startDistanceMeters = aDistance,
                distanceMeters = distanceMeters,
                averageHeartRateBpm = null,
                averageCadenceSpm = cadenceValues.takeIf { it.isNotEmpty() }?.average()?.roundToInt()
            )
        }
    }

    private fun calculateSplits(points: List<TrackPoint>): List<String> {
        data class TimedPoint(val distanceMeters: Double, val epochSeconds: Long, val segmentId: Int)
        // Keep source order and segment identity. Sorting only by distance could join the
        // end of one disconnected track to the beginning of another and invent a split.
        val timed = points.mapNotNull { point ->
            val distance = point.cumulativeDistanceMeters
            val time = point.time
            if (distance != null && time != null) TimedPoint(distance, time.epochSecond, point.segmentId) else null
        }
        if (timed.size < 2) return emptyList()
        data class SplitBoundary(val kilometer: Int, val epochSeconds: Double, val segmentId: Int)
        fun boundaryAt(targetMeters: Double, kilometer: Int): SplitBoundary? {
            val pair = timed.zipWithNext().firstOrNull { (a, b) ->
                a.segmentId == b.segmentId &&
                    a.distanceMeters <= targetMeters && b.distanceMeters >= targetMeters &&
                    b.distanceMeters > a.distanceMeters && b.epochSeconds > a.epochSeconds
            } ?: return null
            val fraction = (targetMeters - pair.first.distanceMeters) /
                (pair.second.distanceMeters - pair.first.distanceMeters)
            val seconds = pair.first.epochSeconds + fraction * (pair.second.epochSeconds - pair.first.epochSeconds)
            return SplitBoundary(kilometer, seconds, pair.first.segmentId)
        }
        val maxDistance = timed.maxOfOrNull { it.distanceMeters } ?: return emptyList()
        val count = floor(maxDistance / 1000.0).toInt().coerceAtMost(200)
        val boundaries = (0..count).mapNotNull { km -> boundaryAt(km * 1000.0, km) }
        return boundaries.zipWithNext().mapNotNull { (a, b) ->
            if (a.segmentId != b.segmentId) return@mapNotNull null
            val duration = b.epochSeconds - a.epochSeconds
            if (duration <= 0.0 || !duration.isFinite()) null else PaceRange.format(duration.roundToInt())
        }
    }

    private fun encodeRoute(points: List<TrackPoint>): String {
        val coordinates = points.mapNotNull { point ->
            if (point.latitude != null && point.longitude != null) point.latitude to point.longitude else null
        }
        if (coordinates.size < 2) return ""
        val output = StringBuilder()
        var lastLat = 0
        var lastLon = 0
        coordinates.forEach { (lat, lon) ->
            val nextLat = (lat * 100_000).roundToInt()
            val nextLon = (lon * 100_000).roundToInt()
            encodeDelta(nextLat - lastLat, output)
            encodeDelta(nextLon - lastLon, output)
            lastLat = nextLat
            lastLon = nextLon
        }
        return output.toString()
    }

    private fun encodeDelta(delta: Int, output: StringBuilder) {
        var value = if (delta < 0) (delta shl 1).inv() else delta shl 1
        while (value >= 0x20) {
            output.append(((0x20 or (value and 0x1F)) + 63).toChar())
            value = value shr 5
        }
        output.append((value + 63).toChar())
    }

    private fun haversine(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val p1 = Math.toRadians(lat1)
        val p2 = Math.toRadians(lat2)
        val dLat = p2 - p1
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2) + cos(p1) * cos(p2) * sin(dLon / 2).pow(2)
        return 2 * EARTH_RADIUS_METERS * asin(sqrt(a.coerceIn(0.0, 1.0)))
    }

    private fun secureXml(bytes: ByteArray): Element {
        // The Android XML provider on some devices does not recognize Apache's
        // disallow-doctype feature. Reject DTDs explicitly, then apply every supported
        // parser hardening option on a best-effort basis and block external resolution.
        val xmlProbe = String(bytes, Charsets.ISO_8859_1).replace("\u0000", "")
        if (xmlProbe.contains("<!DOCTYPE", ignoreCase = true)) {
            throw ActivityImportException("O GPX contém uma declaração DOCTYPE não permitida.")
        }
        val factory = DocumentBuilderFactory.newInstance().apply {
            isNamespaceAware = true
            runCatching { setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true) }
            runCatching { setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) }
            runCatching { setFeature("http://xml.org/sax/features/external-general-entities", false) }
            runCatching { setFeature("http://xml.org/sax/features/external-parameter-entities", false) }
            runCatching { setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false) }
            // Use JAXP property URI literals instead of XMLConstants.ACCESS_EXTERNAL_*.
            // Those constants are missing from some Android SDK stubs even though the
            // parser may support the properties at runtime. Keep this best-effort; the
            // DTD pre-scan, disabled external-entity features and empty EntityResolver
            // remain the portable protections on Android providers.
            runCatching { setAttribute("http://javax.xml.XMLConstants/property/accessExternalDTD", "") }
            runCatching { setAttribute("http://javax.xml.XMLConstants/property/accessExternalSchema", "") }
            runCatching { setXIncludeAware(false) }
            runCatching { isExpandEntityReferences = false }
        }
        val builder = factory.newDocumentBuilder()
        builder.setEntityResolver { _, _ -> InputSource(StringReader("")) }
        val document = builder.parse(bytes.inputStream())
        if (document.doctype != null) {
            throw ActivityImportException("O GPX contém uma declaração DOCTYPE não permitida.")
        }
        return document.documentElement
    }

    private fun descendants(parent: Element, localName: String): List<Element> {
        val result = mutableListOf<Element>()
        fun visit(node: Node) {
            val children = node.childNodes
            for (index in 0 until children.length) {
                val child = children.item(index)
                if (child.nodeType == Node.ELEMENT_NODE) {
                    val element = child as Element
                    val local = element.localName ?: element.tagName.substringAfter(':')
                    if (local.equals(localName, ignoreCase = true)) result += element
                    visit(element)
                }
            }
        }
        visit(parent)
        return result
    }

    private fun childText(parent: Element, localName: String): String? =
        descendants(parent, localName).firstOrNull()?.textContent?.trim()?.takeIf { it.isNotBlank() }

    private fun extensionValue(point: Element, acceptedNames: Set<String>): String? {
        val extensions = descendants(point, "extensions").firstOrNull() ?: return null
        fun visit(node: Node): String? {
            val children = node.childNodes
            for (index in 0 until children.length) {
                val child = children.item(index)
                if (child.nodeType == Node.ELEMENT_NODE) {
                    val element = child as Element
                    val name = (element.localName ?: element.tagName.substringAfter(':')).lowercase()
                    if (name in acceptedNames) return element.textContent?.trim()
                    visit(element)?.let { return it }
                }
            }
            return null
        }
        return visit(extensions)
    }

    private fun parseInstant(value: String?): Instant? = try {
        value?.let { Instant.parse(it) }
    } catch (_: DateTimeParseException) { null }

    private fun readUInt16(bytes: ByteArray, offset: Int, bigEndian: Boolean): Int =
        if (bigEndian) ((bytes[offset].toInt() and 0xFF) shl 8) or (bytes[offset + 1].toInt() and 0xFF)
        else (bytes[offset].toInt() and 0xFF) or ((bytes[offset + 1].toInt() and 0xFF) shl 8)

    private fun readUInt32(bytes: ByteArray, offset: Int, bigEndian: Boolean): Long =
        if (bigEndian) ((bytes[offset].toLong() and 0xFF) shl 24) or ((bytes[offset + 1].toLong() and 0xFF) shl 16) or
            ((bytes[offset + 2].toLong() and 0xFF) shl 8) or (bytes[offset + 3].toLong() and 0xFF)
        else (bytes[offset].toLong() and 0xFF) or ((bytes[offset + 1].toLong() and 0xFF) shl 8) or
            ((bytes[offset + 2].toLong() and 0xFF) shl 16) or ((bytes[offset + 3].toLong() and 0xFF) shl 24)

    private fun decodeFitNumber(bytes: ByteArray, offset: Int, size: Int, baseType: Int, bigEndian: Boolean): Double? {
        if (size <= 0) return null
        val type = baseType and 0xFF
        val byteOrder = if (bigEndian) ByteOrder.BIG_ENDIAN else ByteOrder.LITTLE_ENDIAN
        val actualSize = when (type) {
            0x00, 0x01, 0x02, 0x07, 0x0A, 0x0D -> 1
            0x83, 0x84, 0x8B -> 2
            0x85, 0x86, 0x88, 0x8C -> 4
            0x8E, 0x8F, 0x90, 0x89 -> 8
            else -> return null
        }
        if (size < actualSize || offset + actualSize > bytes.size) return null
        val buffer = ByteBuffer.wrap(bytes, offset, actualSize).order(byteOrder)
        val value = when (type) {
            0x01 -> buffer.get().toInt().toDouble()
            0x00, 0x02, 0x0D -> (buffer.get().toInt() and 0xFF).toDouble().takeIf { it != 0xFF.toDouble() }
            0x0A -> (buffer.get().toInt() and 0xFF).toDouble().takeIf { it != 0.0 }
            0x83 -> buffer.short.toDouble()
            0x84 -> (buffer.short.toInt() and 0xFFFF).toDouble().takeIf { it != 0xFFFF.toDouble() }
            0x8B -> (buffer.short.toInt() and 0xFFFF).toDouble().takeIf { it != 0.0 }
            0x85 -> buffer.int.toDouble()
            0x86 -> (buffer.int.toLong() and 0xFFFF_FFFFL).toDouble().takeIf { it != 4_294_967_295.0 }
            0x8C -> (buffer.int.toLong() and 0xFFFF_FFFFL).toDouble().takeIf { it != 0.0 }
            0x88 -> buffer.float.toDouble().takeIf { it.isFinite() }
            0x89 -> buffer.double.takeIf { it.isFinite() }
            0x8E -> buffer.long.toDouble()
            0x8F -> buffer.long.let { if (it == -1L) null else it.toULong().toDouble() }
            0x90 -> buffer.long.let { if (it == 0L) null else it.toULong().toDouble() }
            else -> null
        }
        return value?.takeIf { it.isFinite() }
    }
}
