package com.airunningcoach.app

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import java.time.Instant
import java.time.format.DateTimeParseException
import javax.xml.parsers.DocumentBuilderFactory
import org.w3c.dom.Element
import org.w3c.dom.Node
import org.w3c.dom.NodeList
import kotlin.math.*

/** Parsed activity metrics. Null means that the source file did not provide enough data. */
internal data class ImportedActivity(
    val sourceFormat: String,
    val fingerprint: String,
    val startedAtIso: String?,
    val distanceKm: Double?,
    val elapsedSeconds: Int?,
    val averagePaceMmSs: String?,
    val elevationGainMeters: Double?,
    val averageHeartRateBpm: Int?,
    val maxHeartRateBpm: Int?,
    val averageCadenceSpm: Int?,
    val maxCadenceSpm: Int?,
    val routePointCount: Int,
    val splitPacesMmSs: List<String>,
    val encodedRoute: String
)

internal class ActivityImportException(message: String) : Exception(message)

/** Offline GPX 1.1, TCX and common FIT record/session importer. */
internal object ActivityFileImporter {
    private const val MAX_FILE_BYTES = 25 * 1024 * 1024
    private const val EARTH_RADIUS_METERS = 6_371_000.0
    private val fitEpoch = Instant.parse("1989-12-31T00:00:00Z")

    fun import(input: InputStream, filename: String): ImportedActivity {
        val bytes = input.use { stream ->
            val output = ByteArrayOutputStream()
            val buffer = ByteArray(16 * 1024)
            var total = 0
            while (true) {
                val count = stream.read(buffer)
                if (count < 0) break
                total += count
                if (total > MAX_FILE_BYTES) throw ActivityImportException("O arquivo excede o limite de 25 MB.")
                output.write(buffer, 0, count)
            }
            output.toByteArray()
        }
        if (bytes.isEmpty()) throw ActivityImportException("O arquivo selecionado está vazio.")
        val extension = filename.substringAfterLast('.', "").lowercase()
        val format = when (extension) {
            "gpx" -> "GPX"
            "tcx" -> "TCX"
            "fit" -> "FIT"
            else -> throw ActivityImportException("Formato não reconhecido. Selecione um arquivo GPX, FIT ou TCX.")
        }
        val fingerprint = MessageDigest.getInstance("SHA-256").digest(bytes)
            .joinToString("") { "%02x".format(it) }
        val parsed = try {
            when (format) {
                "GPX" -> parseGpx(bytes)
                "TCX" -> parseTcx(bytes)
                else -> parseFit(bytes)
            }
        } catch (error: ActivityImportException) {
            throw error
        } catch (error: Exception) {
            throw ActivityImportException("Não foi possível interpretar o arquivo $format: ${error.message ?: "estrutura inválida"}.")
        }
        val distance = parsed.distanceMeters?.takeIf { it.isFinite() && it in 20.0..200_000.0 }
        val elapsed = parsed.elapsedSeconds?.takeIf { it in 1..86_399 }
        val pace = if (distance != null && elapsed != null) {
            PaceCalculator.paceFromDistanceAndDuration(distance / 1000.0, elapsed)?.let(PaceRange::format)
        } else null
        if (distance == null && parsed.points.count { it.latitude != null && it.longitude != null } < 2) {
            throw ActivityImportException("O arquivo não contém distância nem pontos GPS suficientes para calculá-la.")
        }
        return ImportedActivity(
            sourceFormat = format,
            fingerprint = fingerprint,
            startedAtIso = parsed.startedAt?.toString(),
            distanceKm = distance?.div(1000.0),
            elapsedSeconds = elapsed,
            averagePaceMmSs = pace,
            elevationGainMeters = parsed.elevationGainMeters?.takeIf { it.isFinite() && it >= 0.0 },
            averageHeartRateBpm = parsed.averageHeartRateBpm?.takeIf { it in 30..240 },
            maxHeartRateBpm = parsed.maxHeartRateBpm?.takeIf { it in 30..260 },
            averageCadenceSpm = parsed.averageCadenceSpm?.takeIf { it in 30..260 },
            maxCadenceSpm = parsed.maxCadenceSpm?.takeIf { it in 30..300 },
            routePointCount = parsed.points.count { it.latitude != null && it.longitude != null },
            splitPacesMmSs = parsed.splitPaces,
            encodedRoute = encodeRoute(parsed.points)
        )
    }

    private data class TrackPoint(
        val latitude: Double? = null,
        val longitude: Double? = null,
        val elevationMeters: Double? = null,
        val time: Instant? = null,
        val heartRateBpm: Int? = null,
        val cadenceSpm: Int? = null,
        val cumulativeDistanceMeters: Double? = null
    )

    private data class ParsedActivity(
        val points: List<TrackPoint>,
        val distanceMeters: Double?,
        val elapsedSeconds: Int?,
        val startedAt: Instant?,
        val elevationGainMeters: Double?,
        val averageHeartRateBpm: Int?,
        val maxHeartRateBpm: Int?,
        val averageCadenceSpm: Int?,
        val maxCadenceSpm: Int?,
        val splitPaces: List<String>
    )

    private fun parseGpx(bytes: ByteArray): ParsedActivity {
        val root = secureXml(bytes)
        var elements = descendants(root, "trkpt")
        if (elements.isEmpty()) elements = descendants(root, "rtept")
        val points = elements.map { element ->
            val lat = element.getAttribute("lat").toDoubleOrNull()?.takeIf { it in -90.0..90.0 }
            val lon = element.getAttribute("lon").toDoubleOrNull()?.takeIf { it in -180.0..180.0 }
            TrackPoint(
                latitude = lat,
                longitude = lon,
                elevationMeters = childText(element, "ele")?.toDoubleOrNull()?.takeIf { it.isFinite() },
                time = parseInstant(childText(element, "time")),
                heartRateBpm = extensionValue(element, setOf("hr", "heartrate"))?.toDoubleOrNull()?.roundToInt(),
                cadenceSpm = extensionValue(element, setOf("cad", "cadence"))?.toDoubleOrNull()?.roundToInt()
            )
        }
        val derived = deriveFromPoints(points)
        return derived
    }

    private fun parseTcx(bytes: ByteArray): ParsedActivity {
        val root = secureXml(bytes)
        val lapElements = descendants(root, "Lap")
        val trackpoints = descendants(root, "Trackpoint")
        val points = trackpoints.map { element ->
            val position = descendants(element, "Position").firstOrNull()
            val lat = position?.let { childText(it, "LatitudeDegrees")?.toDoubleOrNull() }?.takeIf { it in -90.0..90.0 }
            val lon = position?.let { childText(it, "LongitudeDegrees")?.toDoubleOrNull() }?.takeIf { it in -180.0..180.0 }
            TrackPoint(
                latitude = lat,
                longitude = lon,
                elevationMeters = childText(element, "AltitudeMeters")?.toDoubleOrNull()?.takeIf { it.isFinite() },
                time = parseInstant(childText(element, "Time")),
                heartRateBpm = descendants(element, "Value").firstOrNull()?.textContent?.trim()?.toIntOrNull(),
                cadenceSpm = childText(element, "Cadence")?.toIntOrNull(),
                cumulativeDistanceMeters = childText(element, "DistanceMeters")?.toDoubleOrNull()?.takeIf { it >= 0.0 }
            )
        }
        val derived = deriveFromPoints(points)
        val lapDistances = lapElements.mapNotNull { childText(it, "DistanceMeters")?.toDoubleOrNull()?.takeIf { v -> v > 0.0 } }
        val lapDurations = lapElements.mapNotNull { childText(it, "TotalTimeSeconds")?.toDoubleOrNull()?.takeIf { v -> v > 0.0 } }
        val avgHrs = lapElements.mapNotNull { lap -> descendants(lap, "AverageHeartRateBpm").firstOrNull()?.let { childText(it, "Value")?.toIntOrNull() } }
        val maxHrs = lapElements.mapNotNull { lap -> descendants(lap, "MaximumHeartRateBpm").firstOrNull()?.let { childText(it, "Value")?.toIntOrNull() } }
        val avgCadence = points.mapNotNull { it.cadenceSpm }.takeIf { it.isNotEmpty() }?.average()?.roundToInt()
        return derived.copy(
            distanceMeters = lapDistances.sum().takeIf { it > 0.0 } ?: derived.distanceMeters,
            elapsedSeconds = lapDurations.sum().roundToInt().takeIf { it > 0 } ?: derived.elapsedSeconds,
            averageHeartRateBpm = avgHrs.takeIf { it.isNotEmpty() }?.average()?.roundToInt() ?: derived.averageHeartRateBpm,
            maxHeartRateBpm = maxHrs.maxOrNull() ?: derived.maxHeartRateBpm,
            averageCadenceSpm = avgCadence ?: derived.averageCadenceSpm
        )
    }

    private data class FitField(val number: Int, val size: Int, val baseType: Int)
    private data class FitDefinition(
        val globalMessage: Int,
        val bigEndian: Boolean,
        val fields: List<FitField>,
        val developerFieldsSize: Int
    )

    private fun parseFit(bytes: ByteArray): ParsedActivity {
        if (bytes.size < 14) throw ActivityImportException("Arquivo FIT incompleto.")
        val headerSize = bytes[0].toInt() and 0xFF
        if (headerSize !in 12..14 || bytes.size <= headerSize + 2) throw ActivityImportException("Cabeçalho FIT inválido.")
        if (bytes[8] != '.'.code.toByte() || bytes[9] != 'F'.code.toByte() ||
            bytes[10] != 'I'.code.toByte() || bytes[11] != 'T'.code.toByte()) {
            throw ActivityImportException("Assinatura .FIT ausente ou inválida.")
        }
        val dataSizeLong = readUInt32(bytes, 4, false)
        val dataStart = headerSize
        val availableDataBytes = bytes.size - dataStart - 2 // final FIT CRC
        if (dataSizeLong <= 0L || dataSizeLong > availableDataBytes.toLong()) {
            throw ActivityImportException("O FIT está truncado ou declara um tamanho de dados inválido.")
        }
        val dataSize = dataSizeLong.toInt()
        val dataEnd = dataStart + dataSize
        if (dataEnd <= dataStart) throw ActivityImportException("O FIT não contém mensagens de atividade.")

        val definitions = mutableMapOf<Int, FitDefinition>()
        val points = mutableListOf<TrackPoint>()
        var sessionDistanceMeters: Double? = null
        var sessionElapsedSeconds: Int? = null
        var sessionAverageHr: Int? = null
        var sessionMaxHr: Int? = null
        var sessionAverageCadence: Int? = null
        var sessionMaxCadence: Int? = null
        var sessionStart: Instant? = null
        var lastTimestampSeconds: Long? = null
        var offset = dataStart

        while (offset < dataEnd) {
            val header = bytes[offset++].toInt() and 0xFF
            val compressed = (header and 0x80) != 0
            val localMessage = if (compressed) (header shr 5) and 0x03 else header and 0x0F
            val isDefinition = !compressed && (header and 0x40) != 0
            if (isDefinition) {
                if (offset + 5 > dataEnd) break
                offset++ // reserved
                val architecture = bytes[offset++].toInt() and 0xFF
                val bigEndian = architecture == 1
                val global = readUInt16(bytes, offset, bigEndian)
                offset += 2
                val fieldCount = bytes[offset++].toInt() and 0xFF
                if (fieldCount > 64 || offset + fieldCount * 3 > dataEnd) break
                val fields = mutableListOf<FitField>()
                repeat(fieldCount) {
                    val number = bytes[offset++].toInt() and 0xFF
                    val size = bytes[offset++].toInt() and 0xFF
                    val base = bytes[offset++].toInt() and 0xFF
                    fields += FitField(number, size, base)
                }
                var developerFieldsSize = 0
                if ((header and 0x20) != 0) {
                    if (offset >= dataEnd) break
                    val developerCount = bytes[offset++].toInt() and 0xFF
                    if (offset + developerCount * 3 > dataEnd) break
                    repeat(developerCount) {
                        offset++ // developer field number
                        developerFieldsSize += bytes[offset++].toInt() and 0xFF
                        offset++ // developer data index
                    }
                }
                definitions[localMessage] = FitDefinition(global, bigEndian, fields, developerFieldsSize)
                continue
            }
            val definition = definitions[localMessage] ?: throw ActivityImportException("Mensagem FIT sem definição local.")
            val messageBytes = definition.fields.sumOf { it.size } + definition.developerFieldsSize
            if (offset + messageBytes > dataEnd) break
            val values = mutableMapOf<Int, Double>()
            definition.fields.forEach { field ->
                val value = decodeFitNumber(bytes, offset, field.size, field.baseType, definition.bigEndian)
                if (value != null) values[field.number] = value
                offset += field.size
            }
            // Developer fields vary by device/profile. Skip their declared bytes
            // without interpreting them so subsequent standard messages stay aligned.
            offset += definition.developerFieldsSize
            val timestamp = values[253]?.toLong()?.takeIf { it in 1..0xFFFF_FFFEL }
                ?: if (compressed && lastTimestampSeconds != null) {
                    val compressedOffset = header and 0x1F
                    var candidate = (lastTimestampSeconds!! and 0xFFFF_FFE0L) + compressedOffset
                    if (candidate < lastTimestampSeconds!!) candidate += 32
                    candidate
                } else null
            if (timestamp != null) lastTimestampSeconds = timestamp
            val instant = timestamp?.let { fitEpoch.plusSeconds(it) }
            when (definition.globalMessage) {
                20 -> {
                    val lat = values[0]?.let { it / 2_147_483_648.0 * 180.0 }?.takeIf { it in -90.0..90.0 }
                    val lon = values[1]?.let { it / 2_147_483_648.0 * 180.0 }?.takeIf { it in -180.0..180.0 }
                    val altitude = values[2]?.let { it / 5.0 - 500.0 }
                    points += TrackPoint(
                        latitude = lat, longitude = lon, elevationMeters = altitude,
                        time = instant,
                        heartRateBpm = values[3]?.roundToInt(),
                        cadenceSpm = values[4]?.roundToInt(),
                        cumulativeDistanceMeters = values[5]?.div(100.0)
                    )
                }
                18 -> {
                    sessionStart = values[2]?.toLong()?.let { fitEpoch.plusSeconds(it) } ?: sessionStart
                    sessionElapsedSeconds = values[7]?.div(1000.0)?.roundToInt()?.takeIf { it > 0 } ?: sessionElapsedSeconds
                    sessionDistanceMeters = values[9]?.div(100.0)?.takeIf { it > 0.0 } ?: sessionDistanceMeters
                    sessionAverageHr = values[15]?.roundToInt() ?: sessionAverageHr
                    sessionMaxHr = values[16]?.roundToInt() ?: sessionMaxHr
                    sessionAverageCadence = values[17]?.roundToInt() ?: sessionAverageCadence
                    sessionMaxCadence = values[18]?.roundToInt() ?: sessionMaxCadence
                }
            }
        }
        val derived = deriveFromPoints(points)
        return derived.copy(
            distanceMeters = sessionDistanceMeters ?: points.mapNotNull { it.cumulativeDistanceMeters }.maxOrNull() ?: derived.distanceMeters,
            elapsedSeconds = sessionElapsedSeconds ?: derived.elapsedSeconds,
            startedAt = sessionStart ?: derived.startedAt,
            averageHeartRateBpm = sessionAverageHr ?: derived.averageHeartRateBpm,
            maxHeartRateBpm = sessionMaxHr ?: derived.maxHeartRateBpm,
            averageCadenceSpm = sessionAverageCadence ?: derived.averageCadenceSpm,
            maxCadenceSpm = sessionMaxCadence ?: derived.maxCadenceSpm
        )
    }

    private fun deriveFromPoints(rawPoints: List<TrackPoint>): ParsedActivity {
        if (rawPoints.isEmpty()) return ParsedActivity(emptyList(), null, null, null, null, null, null, null, null, emptyList())
        var geometricDistance = 0.0
        var elevationGain = 0.0
        var previousCoordinate: TrackPoint? = null
        var previousElevation: Double? = null
        var cumulative = 0.0
        val points = rawPoints.map { point ->
            val previous = previousCoordinate
            if (previous != null && point.latitude != null && point.longitude != null && previous.latitude != null && previous.longitude != null) {
                val step = haversine(previous.latitude, previous.longitude, point.latitude, point.longitude)
                // Ignore isolated GPS jumps that cannot represent a running segment.
                if (step.isFinite() && step in 0.5..2000.0) geometricDistance += step
            }
            if (point.latitude != null && point.longitude != null) previousCoordinate = point
            val elevation = point.elevationMeters
            if (elevation != null && previousElevation != null) {
                val delta = elevation - previousElevation!!
                if (delta in 0.5..20.0) elevationGain += delta
            }
            if (elevation != null) previousElevation = elevation
            val suppliedDistance = point.cumulativeDistanceMeters
            if (suppliedDistance != null && suppliedDistance >= 0.0) cumulative = max(cumulative, suppliedDistance)
            else if (point.latitude != null && point.longitude != null && previous != null && previous.latitude != null && previous.longitude != null) {
                val step = haversine(previous.latitude, previous.longitude, point.latitude, point.longitude)
                if (step.isFinite() && step in 0.5..2000.0) cumulative += step
            }
            point.copy(cumulativeDistanceMeters = suppliedDistance ?: cumulative)
        }
        val validTimes = points.mapNotNull { it.time }.sorted()
        val startedAt = validTimes.firstOrNull()
        val elapsed = if (validTimes.size >= 2) {
            java.time.Duration.between(validTimes.first(), validTimes.last()).seconds.toInt().takeIf { it > 0 }
        } else null
        val hr = points.mapNotNull { it.heartRateBpm }.filter { it in 30..240 }
        val cadence = points.mapNotNull { it.cadenceSpm }.filter { it in 30..300 }
        val distance = points.mapNotNull { it.cumulativeDistanceMeters }.maxOrNull()?.takeIf { it > 0.0 }
            ?: geometricDistance.takeIf { it > 0.0 }
        val splits = calculateSplits(points)
        return ParsedActivity(
            points = points,
            distanceMeters = distance,
            elapsedSeconds = elapsed,
            startedAt = startedAt,
            elevationGainMeters = elevationGain,
            averageHeartRateBpm = hr.takeIf { it.isNotEmpty() }?.average()?.roundToInt(),
            maxHeartRateBpm = hr.maxOrNull(),
            averageCadenceSpm = cadence.takeIf { it.isNotEmpty() }?.average()?.roundToInt(),
            maxCadenceSpm = cadence.maxOrNull(),
            splitPaces = splits
        )
    }

    private fun calculateSplits(points: List<TrackPoint>): List<String> {
        val timed = points.mapNotNull { point ->
            val distance = point.cumulativeDistanceMeters
            val time = point.time
            if (distance != null && time != null) distance to time.epochSecond else null
        }.sortedBy { it.first }
        if (timed.size < 2) return emptyList()
        fun secondsAt(targetMeters: Double): Double? {
            val pair = timed.zipWithNext().firstOrNull { (a, b) -> a.first <= targetMeters && b.first >= targetMeters && b.first > a.first } ?: return null
            val fraction = (targetMeters - pair.first.first) / (pair.second.first - pair.first.first)
            return pair.first.second + fraction * (pair.second.second - pair.first.second)
        }
        val maxDistance = timed.last().first
        val count = floor(maxDistance / 1000.0).toInt().coerceAtMost(200)
        val boundaries = (0..count).mapNotNull { km -> secondsAt(km * 1000.0)?.let { km to it } }
        return boundaries.zipWithNext().mapNotNull { (a, b) ->
            val duration = b.second - a.second
            if (duration <= 0.0 || !duration.isFinite()) null else PaceRange.format(duration.roundToInt())
        }
    }

    private fun encodeRoute(points: List<TrackPoint>): String {
        val coordinates = points.mapNotNull { point ->
            if (point.latitude != null && point.longitude != null) point.latitude to point.longitude else null
        }
        if (coordinates.size < 2) return ""
        val output = StringBuilder()
        var lastLat = 0
        var lastLon = 0
        coordinates.forEach { (lat, lon) ->
            val nextLat = (lat * 100_000).roundToInt()
            val nextLon = (lon * 100_000).roundToInt()
            encodeDelta(nextLat - lastLat, output)
            encodeDelta(nextLon - lastLon, output)
            lastLat = nextLat
            lastLon = nextLon
        }
        return output.toString()
    }

    private fun encodeDelta(delta: Int, output: StringBuilder) {
        var value = if (delta < 0) (delta shl 1).inv() else delta shl 1
        while (value >= 0x20) {
            output.append(((0x20 or (value and 0x1F)) + 63).toChar())
            value = value shr 5
        }
        output.append((value + 63).toChar())
    }

    private fun haversine(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val p1 = Math.toRadians(lat1)
        val p2 = Math.toRadians(lat2)
        val dLat = p2 - p1
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2) + cos(p1) * cos(p2) * sin(dLon / 2).pow(2)
        return 2 * EARTH_RADIUS_METERS * asin(sqrt(a.coerceIn(0.0, 1.0)))
    }

    private fun secureXml(bytes: ByteArray): Element {
        val factory = DocumentBuilderFactory.newInstance().apply {
            isNamespaceAware = true
            setFeature("http://apache.org/xml/features/disallow-doctype-decl", true)
            setFeature("http://xml.org/sax/features/external-general-entities", false)
            setFeature("http://xml.org/sax/features/external-parameter-entities", false)
            setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false)
            setXIncludeAware(false)
            isExpandEntityReferences = false
        }
        return factory.newDocumentBuilder().parse(bytes.inputStream()).documentElement
    }

    private fun descendants(parent: Element, localName: String): List<Element> {
        val result = mutableListOf<Element>()
        fun visit(node: Node) {
            val children = node.childNodes
            for (index in 0 until children.length) {
                val child = children.item(index)
                if (child.nodeType == Node.ELEMENT_NODE) {
                    val element = child as Element
                    val local = element.localName ?: element.tagName.substringAfter(':')
                    if (local.equals(localName, ignoreCase = true)) result += element
                    visit(element)
                }
            }
        }
        visit(parent)
        return result
    }

    private fun childText(parent: Element, localName: String): String? =
        descendants(parent, localName).firstOrNull()?.textContent?.trim()?.takeIf { it.isNotBlank() }

    private fun extensionValue(point: Element, acceptedNames: Set<String>): String? {
        val extensions = descendants(point, "extensions").firstOrNull() ?: return null
        fun visit(node: Node): String? {
            val children = node.childNodes
            for (index in 0 until children.length) {
                val child = children.item(index)
                if (child.nodeType == Node.ELEMENT_NODE) {
                    val element = child as Element
                    val name = (element.localName ?: element.tagName.substringAfter(':')).lowercase()
                    if (name in acceptedNames) return element.textContent?.trim()
                    visit(element)?.let { return it }
                }
            }
            return null
        }
        return visit(extensions)
    }

    private fun parseInstant(value: String?): Instant? = try {
        value?.let { Instant.parse(it) }
    } catch (_: DateTimeParseException) { null }

    private fun readUInt16(bytes: ByteArray, offset: Int, bigEndian: Boolean): Int =
        if (bigEndian) ((bytes[offset].toInt() and 0xFF) shl 8) or (bytes[offset + 1].toInt() and 0xFF)
        else (bytes[offset].toInt() and 0xFF) or ((bytes[offset + 1].toInt() and 0xFF) shl 8)

    private fun readUInt32(bytes: ByteArray, offset: Int, bigEndian: Boolean): Long =
        if (bigEndian) ((bytes[offset].toLong() and 0xFF) shl 24) or ((bytes[offset + 1].toLong() and 0xFF) shl 16) or
            ((bytes[offset + 2].toLong() and 0xFF) shl 8) or (bytes[offset + 3].toLong() and 0xFF)
        else (bytes[offset].toLong() and 0xFF) or ((bytes[offset + 1].toLong() and 0xFF) shl 8) or
            ((bytes[offset + 2].toLong() and 0xFF) shl 16) or ((bytes[offset + 3].toLong() and 0xFF) shl 24)

    private fun decodeFitNumber(bytes: ByteArray, offset: Int, size: Int, baseType: Int, bigEndian: Boolean): Double? {
        if (size <= 0) return null
        val type = baseType and 0xFF
        val byteOrder = if (bigEndian) ByteOrder.BIG_ENDIAN else ByteOrder.LITTLE_ENDIAN
        val actualSize = when (type) {
            0x00, 0x01, 0x02, 0x07, 0x0A, 0x0D -> 1
            0x83, 0x84, 0x8B -> 2
            0x85, 0x86, 0x88, 0x8C -> 4
            0x8E, 0x8F, 0x90, 0x89 -> 8
            else -> return null
        }
        if (size < actualSize || offset + actualSize > bytes.size) return null
        val buffer = ByteBuffer.wrap(bytes, offset, actualSize).order(byteOrder)
        val value = when (type) {
            0x01 -> buffer.get().toInt().toDouble()
            0x00, 0x02, 0x0D -> (buffer.get().toInt() and 0xFF).toDouble().takeIf { it != 0xFF.toDouble() }
            0x0A -> (buffer.get().toInt() and 0xFF).toDouble().takeIf { it != 0.0 }
            0x83 -> buffer.short.toDouble()
            0x84 -> (buffer.short.toInt() and 0xFFFF).toDouble().takeIf { it != 0xFFFF.toDouble() }
            0x8B -> (buffer.short.toInt() and 0xFFFF).toDouble().takeIf { it != 0.0 }
            0x85 -> buffer.int.toDouble()
            0x86 -> (buffer.int.toLong() and 0xFFFF_FFFFL).toDouble().takeIf { it != 4_294_967_295.0 }
            0x8C -> (buffer.int.toLong() and 0xFFFF_FFFFL).toDouble().takeIf { it != 0.0 }
            0x88 -> buffer.float.toDouble().takeIf { it.isFinite() }
            0x89 -> buffer.double.takeIf { it.isFinite() }
            0x8E -> buffer.long.toDouble()
            0x8F -> buffer.long.let { if (it == -1L) null else it.toULong().toDouble() }
            0x90 -> buffer.long.let { if (it == 0L) null else it.toULong().toDouble() }
            else -> null
        }
        return value?.takeIf { it.isFinite() }
    }
}
