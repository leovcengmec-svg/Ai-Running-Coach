package com.airunningcoach.app

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

internal data class AdaptiveZoneObservation(
    val sessionId: String,
    val dateIso: String,
    val zone: String,
    val actualPaceSecondsPerKm: Int,
    val targetFastestPaceSecondsPerKm: Int,
    val targetSlowestPaceSecondsPerKm: Int,
    val effort: String,
    val feeling: String,
    val painPresent: Boolean,
    val workoutType: String,
    /** Stable identity of the prescribed block; used to prevent evidence reuse across lots. */
    val blockId: String = ""
)

internal data class AdaptiveZoneCalibrationAudit(
    val dateIso: String,
    val testReferenceDateIso: String,
    val zone: String,
    val previousRange: String,
    val newRange: String,
    val estimatedImprovementPercent: Double,
    val appliedChangePercent: Double,
    val cumulativeChangePercent: Double,
    val evidenceCount: Int,
    val sessionCount: Int,
    val decision: String = "APPLIED",
    /** Contribution from this source zone before downstream propagation. */
    val sourceContributionPercent: Double = appliedChangePercent,
    /** Exact block identities consumed by this accepted lot/review. */
    val evidenceKeys: List<String> = emptyList(),
    /** Human-readable lot breakdown (A/B) for the history screen. */
    val lotSummary: String = "",
    val evidenceThroughDateIso: String = ""
)

internal data class AdaptiveZoneCalibrationState(
    val referenceTestDateIso: String = "",
    val lastReviewDateIso: String = "",
    val cumulativePercentByZone: Map<String, Double> = emptyMap(),
    val history: List<AdaptiveZoneCalibrationAudit> = emptyList(),
    /** Protocol attached to the current physiological reference (never mix Cooper and 3 km). */
    val referenceTestMethod: String = "",
    /** Cooper distance in km or 3 km time in seconds; only compared within the same protocol. */
    val lastTestAssessmentValue: Double? = null,
    val testComparisonStatus: String = "UNCLASSIFIED",
    /** True after a worse same-protocol test; existing credits must not be discarded. */
    val antiResetLock: Boolean = false,
    /** Credits earned under a different test protocol stay visible but are not applied. */
    val calibrationSuspended: Boolean = false,
    val pendingPercentByZone: Map<String, Double> = emptyMap(),
    /** Protocol that produced the held credits, when known. */
    val pendingTestMethod: String = "",
    /** Per-zone block IDs already consumed by accepted calibration lots. */
    val consumedEvidenceKeysByZone: Map<String, List<String>> = emptyMap(),
    /** Latest date consumed in an accepted lot for each source zone. */
    val evidenceThroughDateByZone: Map<String, String> = emptyMap()
)

internal data class AdaptiveZoneProposal(
    val zone: String,
    val previousRange: PaceRange,
    val proposedRange: PaceRange,
    val estimatedImprovementPercent: Double,
    val appliedChangePercent: Double,
    val cumulativeAfterPercent: Double,
    val evidenceCount: Int,
    val sessionCount: Int,
    val explanation: String,
    /** Direct contribution stored against this source zone (0–5%). */
    val sourceContributionAfterPercent: Double = 0.0,
    val evidenceKeys: List<String> = emptyList(),
    val evidenceThroughDateIso: String = "",
    val lotSummary: String = ""
)

internal data class AdaptiveZoneLotProgress(
    val acceptedSourceContributionPercent: Double = 0.0,
    val nextLot: String = "A",
    val lotABlocksAvailable: Int = 0,
    val lotASessionsAvailable: Int = 0,
    val lotBBlocksAvailable: Int = 0,
    val lotBSessionsAvailable: Int = 0
)

internal data class AdaptiveZoneCalibrationReview(
    val status: String,
    val reviewDateIso: String,
    val nextReviewDateIso: String?,
    val daysUntilReview: Long?,
    val proposals: List<AdaptiveZoneProposal>,
    val evidenceCounts: Map<String, Int>,
    val explanations: Map<String, String>,
    val lotProgressByZone: Map<String, AdaptiveZoneLotProgress> = emptyMap()
) {
    val hasProposals: Boolean get() = proposals.isNotEmpty()
}

/**
 * Evidence-gated V104 pace adaptation. Direct contributions are capped at 5% per source zone.
 * Contributions cascade down to slower zones: Z3 affects Z3/Z2/Z1, Z2 affects Z2/Z1,
 * and Z1 affects only Z1. Effective maxima are therefore Z3=5%, Z2=10%, Z1=15%.
 * Z4–Z5 remain anchored to the latest valid field test.
 */
internal object AdaptiveZoneCalibrationEngine {
    const val NOT_DUE = "NOT_DUE"
    const val READY = "READY"
    const val INSUFFICIENT = "INSUFFICIENT"
    const val NO_CHANGE = "NO_CHANGE"
    const val LIMIT_REACHED = "LIMIT_REACHED"
    const val BLOCKED = "BLOCKED"

    const val MIN_PROPOSAL_PERCENT = 2.0
    /** Lot A can contribute up to 3%; a distinct Lot B can add 2% in the same review. */
    const val MAX_CHANGE_PER_REVIEW_PERCENT = 3.0
    const val MAX_CUMULATIVE_PERCENT = 5.0
    const val REVIEW_INTERVAL_DAYS = 28L
    const val RETEST_INTERVAL_DAYS = 29L
    const val RETEST_WINDOW_START_DAYS = 29L
    const val MIN_BLOCK_OBSERVATIONS = 5
    const val MIN_DISTINCT_SESSIONS = 3

    private val adaptiveZones = listOf("Z1", "Z2", "Z3")
    /** Engineering guard: never allow a zone band to collapse below ten seconds. */
    private const val MIN_ZONE_WIDTH_SECONDS = 10
    private val safeEffort = setOf("Muito leve", "Leve", "Ok")
    private val z1Effort = setOf("Muito leve", "Leve")
    private val safeFeeling = setOf("Ótimo", "Bem")

    private data class EvidenceLot(
        val rows: List<Pair<AdaptiveZoneObservation, Double>>,
        val keys: List<String>,
        val sessionCount: Int,
        val throughDateIso: String,
        val improvementPercent: Double
    )

    /**
     * Synchronizes the active test date without destroying accepted calibration credits.
     * This is used for restore/edit/delete reconciliation. A genuinely new test must go
     * through registerValidTest(), which classifies its result before changing credits.
     */
    /**
     * Synchronizes metadata after a historical edit, restore or deletion. It never
     * grants/clears credits. If the selected reference protocol changed, active credits
     * are moved to the pending bucket and not applied to the new protocol.
     */
    fun synchronizeReferenceTest(
        previous: AdaptiveZoneCalibrationState,
        test: CooperAssessmentRecord,
        previousReferenceTest: CooperAssessmentRecord? = null
    ): AdaptiveZoneCalibrationState {
        val date = runCatching { LocalDate.parse(test.dateIso) }.getOrNull()?.toString().orEmpty()
        val method = test.testMethod.takeIf { it in setOf("COOPER_12_MIN", "THREE_KM") }.orEmpty()
        val metric = assessmentValue(test)
        if (date.isBlank() || method.isBlank() || metric == null) return previous
        val hasPreviousReference = previous.referenceTestDateIso.isNotBlank() ||
            previous.referenceTestMethod.isNotBlank() || previous.lastTestAssessmentValue != null
        val previousMethod = previous.referenceTestMethod.ifBlank { previousReferenceTest?.testMethod.orEmpty() }
        val protocolUnknownWithCredits = hasPreviousReference && previousMethod.isBlank() &&
            previous.cumulativePercentByZone.values.any { it > 0.0 }
        val protocolChanged = previousMethod.isNotBlank() && previousMethod != method
        val mustHoldCredits = protocolChanged || protocolUnknownWithCredits
        if (date == previous.referenceTestDateIso && method == previous.referenceTestMethod && metric == previous.lastTestAssessmentValue && !protocolChanged && !protocolUnknownWithCredits) return previous
        val currentCredits = previous.cumulativePercentByZone.mapValues { (_, value) -> value.coerceIn(0.0, MAX_CUMULATIVE_PERCENT) }
        val oldPending = previous.pendingPercentByZone.mapValues { (_, value) -> value.coerceIn(0.0, MAX_CUMULATIVE_PERCENT) }
        val pending = if (mustHoldCredits) adaptiveZones.associateWith { zone ->
            max(oldPending[zone] ?: 0.0, currentCredits[zone] ?: 0.0)
        } else oldPending
        return previous.copy(
            referenceTestDateIso = date,
            lastReviewDateIso = if (date != previous.referenceTestDateIso || mustHoldCredits) date else previous.lastReviewDateIso,
            referenceTestMethod = method,
            lastTestAssessmentValue = metric,
            testComparisonStatus = when {
                mustHoldCredits -> "INCOMPARABLE"
                !hasPreviousReference -> "INITIAL"
                date != previous.referenceTestDateIso || metric != previous.lastTestAssessmentValue -> "UNVERIFIED"
                else -> previous.testComparisonStatus
            },
            antiResetLock = previous.antiResetLock || mustHoldCredits,
            calibrationSuspended = previous.calibrationSuspended || mustHoldCredits,
            cumulativePercentByZone = if (mustHoldCredits) adaptiveZones.associateWith { 0.0 } else currentCredits,
            pendingPercentByZone = pending,
            pendingTestMethod = if (mustHoldCredits && currentCredits.values.any { it > 0.0 }) previousMethod
                else previous.pendingTestMethod,
            consumedEvidenceKeysByZone = if (mustHoldCredits) emptyMap() else previous.consumedEvidenceKeysByZone,
            evidenceThroughDateByZone = if (mustHoldCredits) emptyMap() else previous.evidenceThroughDateByZone
        )
    }

    @Suppress("UNUSED_PARAMETER")
    fun resetForValidTest(
        previous: AdaptiveZoneCalibrationState,
        testDateIso: String,
        forceNewTest: Boolean = false
    ): AdaptiveZoneCalibrationState {
        val validDate = runCatching { LocalDate.parse(testDateIso) }.getOrNull()?.toString().orEmpty()
        if (validDate.isBlank()) return previous
        if (previous.referenceTestDateIso == validDate) return previous
        val hasPriorState = previous.referenceTestDateIso.isNotBlank() ||
            previous.cumulativePercentByZone.values.any { it > 0.0 } || previous.history.isNotEmpty()
        return previous.copy(
            referenceTestDateIso = validDate,
            lastReviewDateIso = validDate,
            cumulativePercentByZone = if (hasPriorState) previous.cumulativePercentByZone
                else adaptiveZones.associateWith { 0.0 },
            // Legacy state is retained safely. A genuine new test must be classified by registerValidTest().
        )
    }

    /**
     * Records a new physiological test. Cooper is compared only with Cooper (distance);
     * a 3 km test is compared only with another 3 km test (time). A >=2% improvement
     * starts a new calibration phase. Equivalent or worse tests preserve earned credits;
     * worse tests additionally set an anti-reset lock. Protocol changes hold old credits
     * separately and suspend their application instead of converting them.
     */
    fun registerValidTest(
        previous: AdaptiveZoneCalibrationState,
        priorAssessments: List<CooperAssessmentRecord>,
        current: CooperAssessmentRecord,
        equivalenceTolerancePercent: Double = 2.0
    ): AdaptiveZoneCalibrationState {
        val date = runCatching { LocalDate.parse(current.dateIso) }.getOrNull()?.toString().orEmpty()
        val method = current.testMethod.takeIf { it in setOf("COOPER_12_MIN", "THREE_KM") }.orEmpty()
        val metric = assessmentValue(current)
        if (date.isBlank() || method.isBlank() || metric == null) return previous

        val priorReference = priorAssessments.firstOrNull { it.deletedAtIso.isBlank() && it.dateIso == previous.referenceTestDateIso }
        val priorMethod = previous.referenceTestMethod.ifBlank { priorReference?.testMethod.orEmpty() }
        val priorMetric = previous.lastTestAssessmentValue ?: priorReference?.let(::assessmentValue)
        val hasPreviousReference = previous.referenceTestDateIso.isNotBlank() || priorReference != null

        if (!hasPreviousReference) {
            return previous.copy(
                referenceTestDateIso = date,
                lastReviewDateIso = date,
                cumulativePercentByZone = if (previous.cumulativePercentByZone.isEmpty()) adaptiveZones.associateWith { 0.0 }
                    else previous.cumulativePercentByZone,
                referenceTestMethod = method,
                lastTestAssessmentValue = metric,
                testComparisonStatus = "INITIAL",
                antiResetLock = false,
                calibrationSuspended = false,
                pendingPercentByZone = previous.pendingPercentByZone,
                consumedEvidenceKeysByZone = emptyMap(),
                evidenceThroughDateByZone = emptyMap()
            )
        }

        val currentCredits = previous.cumulativePercentByZone.mapValues { (_, value) -> value.coerceIn(0.0, MAX_CUMULATIVE_PERCENT) }
        val oldPending = previous.pendingPercentByZone.mapValues { (_, value) -> value.coerceIn(0.0, MAX_CUMULATIVE_PERCENT) }
        if (hasPreviousReference && priorMethod.isBlank()) {
            val pending = adaptiveZones.associateWith { zone ->
                max(oldPending[zone] ?: 0.0, currentCredits[zone] ?: 0.0)
            }
            return previous.copy(
                referenceTestDateIso = date,
                lastReviewDateIso = date,
                cumulativePercentByZone = adaptiveZones.associateWith { 0.0 },
                referenceTestMethod = method,
                lastTestAssessmentValue = metric,
                testComparisonStatus = "INCOMPARABLE",
                antiResetLock = true,
                calibrationSuspended = true,
                pendingPercentByZone = pending,
                pendingTestMethod = previous.pendingTestMethod,
                consumedEvidenceKeysByZone = emptyMap(),
                evidenceThroughDateByZone = emptyMap()
            )
        }

        if (priorMethod.isNotBlank() && priorMethod != method) {
            val pending = adaptiveZones.associateWith { zone ->
                max(oldPending[zone] ?: 0.0, currentCredits[zone] ?: 0.0)
            }
            return previous.copy(
                referenceTestDateIso = date,
                lastReviewDateIso = date,
                cumulativePercentByZone = adaptiveZones.associateWith { 0.0 },
                referenceTestMethod = method,
                lastTestAssessmentValue = metric,
                testComparisonStatus = "INCOMPARABLE",
                antiResetLock = true,
                calibrationSuspended = true,
                pendingPercentByZone = pending,
                pendingTestMethod = if (currentCredits.values.any { it > 0.0 }) priorMethod else previous.pendingTestMethod,
                consumedEvidenceKeysByZone = emptyMap(),
                evidenceThroughDateByZone = emptyMap()
            )
        }

        val comparisonValue = priorMetric.takeIf { priorMethod == method }
        val improvement = comparisonValue?.takeIf { it > 0.0 }?.let { previousValue ->
            if (method == "THREE_KM") (previousValue - metric) / previousValue * 100.0
            else (metric - previousValue) / previousValue * 100.0
        }
        val classification = when {
            improvement == null -> "UNVERIFIED"
            improvement >= equivalenceTolerancePercent -> "IMPROVED"
            improvement <= -equivalenceTolerancePercent -> "WORSE"
            else -> "EQUIVALENT"
        }
        val improved = classification == "IMPROVED"
        val canResumeCurrentProtocol = priorMethod == method
        return previous.copy(
            referenceTestDateIso = date,
            lastReviewDateIso = date,
            cumulativePercentByZone = when {
                improved -> adaptiveZones.associateWith { 0.0 }
                else -> currentCredits
            },
            referenceTestMethod = method,
            lastTestAssessmentValue = metric,
            testComparisonStatus = classification,
            antiResetLock = when (classification) {
                "IMPROVED" -> false
                "WORSE" -> true
                else -> previous.antiResetLock
            },
            // A comparable next test establishes the new protocol-specific baseline again;
            // any old cross-protocol credit remains pending and is never applied automatically.
            calibrationSuspended = if (improved) false else if (canResumeCurrentProtocol) false else previous.calibrationSuspended,
            pendingPercentByZone = oldPending,
            consumedEvidenceKeysByZone = if (improved) emptyMap() else previous.consumedEvidenceKeysByZone,
            evidenceThroughDateByZone = if (improved) emptyMap() else previous.evidenceThroughDateByZone
        )
    }

    private fun assessmentValue(record: CooperAssessmentRecord): Double? = when (record.testMethod) {
        "THREE_KM" -> record.testDurationSeconds?.takeIf { it > 0 }?.toDouble()
        "COOPER_12_MIN" -> record.distanceKm.takeIf { it.isFinite() && it > 0.0 }
        else -> null
    }

    /** Direct contribution assigned to a source zone; each source may contribute at most 5%. */
    fun sourceContributionPercent(state: AdaptiveZoneCalibrationState, zone: String): Double =
        state.cumulativePercentByZone[zone.uppercase()]?.coerceIn(0.0, MAX_CUMULATIVE_PERCENT) ?: 0.0

    /** Effective cumulative shift received by this zone after faster-zone propagation. */
    fun cumulativePercent(state: AdaptiveZoneCalibrationState, zone: String): Double = when (zone.uppercase()) {
        "Z3" -> sourceContributionPercent(state, "Z3")
        "Z2" -> sourceContributionPercent(state, "Z3") + sourceContributionPercent(state, "Z2")
        "Z1" -> sourceContributionPercent(state, "Z3") + sourceContributionPercent(state, "Z2") + sourceContributionPercent(state, "Z1")
        else -> 0.0
    }

    fun maximumEffectivePercent(zone: String): Double = when (zone.uppercase()) {
        "Z1" -> 15.0
        "Z2" -> 10.0
        "Z3" -> 5.0
        else -> 0.0
    }

    /**
     * Applies accepted cumulative adjustments to the test-derived base while keeping
     * all five bands contiguous. Shared boundaries are resolved conservatively using
     * the larger accepted shift from the two neighboring adaptive zones.
     */
    private fun adjustedBoundaryValues(
        base: TrainingPaceZones,
        state: AdaptiveZoneCalibrationState
    ): List<Int>? {
        val cumulative = adaptiveZones.associateWith { cumulativePercent(state, it) }
        val boundaries = ZoneCalibrationEngine.boundaryValues(base)
        if (boundaries.size != 6 || boundaries.any { it !in 120..1800 }) return null

        fun shifted(index: Int, percent: Double): Int =
            (boundaries[index] * (1.0 - percent / 100.0)).roundToInt()

        // Boundary order: Z5-fast, Z5-slow, Z4-slow, Z3-slow, Z2-slow, Z1-slow.
        // The shared boundary of each slower zone receives the sum of all faster-zone
        // source contributions that propagate into it.
        val adjusted = boundaries.toMutableList()
        adjusted[3] = shifted(3, cumulative.getValue("Z3"))
        adjusted[4] = shifted(4, cumulative.getValue("Z2"))
        adjusted[5] = shifted(5, cumulative.getValue("Z1"))

        if (adjusted.any { it !in 120..1800 }) return null
        if (adjusted.zipWithNext().any { (faster, slower) -> slower - faster < MIN_ZONE_WIDTH_SECONDS }) return null
        return adjusted
    }

    fun apply(
        base: TrainingPaceZones,
        state: AdaptiveZoneCalibrationState
    ): TrainingPaceZones {
        if (state.calibrationSuspended) return base
        val cumulative = adaptiveZones.associateWith { cumulativePercent(state, it) }
        val adjusted = adjustedBoundaryValues(base, state) ?: return base

        fun zone(source: PaceZone, fastIndex: Int, slowIndex: Int): PaceZone = source.copy(
            range = PaceRange(adjusted[fastIndex], adjusted[slowIndex]),
            intensityBand = if (source.id in adaptiveZones && cumulative.getValue(source.id) > 0.0) {
                "Faixa adaptada por evidências reais • ${cumulative.getValue(source.id).formatPercent()}% acumulados desde o último teste"
            } else source.intensityBand
        )

        return base.copy(
            z1 = zone(base.z1, 4, 5),
            z2 = zone(base.z2, 3, 4),
            z3 = zone(base.z3, 2, 3),
            z1CalibrationStatus = if (cumulative.getValue("Z1") > 0.0) ZoneCalibrationEngine.CALIBRATED else base.z1CalibrationStatus,
            z2CalibrationStatus = if (cumulative.getValue("Z2") > 0.0) ZoneCalibrationEngine.CALIBRATED else base.z2CalibrationStatus,
            z3CalibrationStatus = if (cumulative.getValue("Z3") > 0.0) ZoneCalibrationEngine.CALIBRATED else base.z3CalibrationStatus
        )
    }

    private fun sessionKey(row: AdaptiveZoneObservation): String = "${row.sessionId}|${row.dateIso}"

    private fun evidenceKey(row: AdaptiveZoneObservation): String =
        "${row.zone.uppercase()}|${sessionKey(row)}|${row.blockId}"

    private fun legacyEvidenceThroughDate(state: AdaptiveZoneCalibrationState, zone: String): LocalDate? {
        val persisted = state.evidenceThroughDateByZone[zone]
            ?.let { raw -> runCatching { LocalDate.parse(raw) }.getOrNull() }
        if (persisted != null) return persisted
        // V103 did not store consumed block IDs. The accepted audit date is a safe migration
        // boundary: do not let any evidence on/before that date be reused for the next lot.
        val auditDate = state.history.lastOrNull { it.zone == zone && it.decision == "APPLIED" }
            ?.dateIso?.let { raw -> runCatching { LocalDate.parse(raw) }.getOrNull() }
        if (auditDate != null) return auditDate
        return state.lastReviewDateIso.takeIf { it.isNotBlank() }
            ?.let { raw -> runCatching { LocalDate.parse(raw) }.getOrNull() }
    }

    private fun progressCounts(groups: List<Map.Entry<String, List<Pair<AdaptiveZoneObservation, Double>>>>): Pair<Int, Int> {
        val rows = groups.flatMap { it.value }
        return min(rows.size, MIN_BLOCK_OBSERVATIONS) to min(groups.size, MIN_DISTINCT_SESSIONS)
    }

    /** Select exactly five blocks across at least three distinct sessions, deterministically. */
    private fun findEvidenceLot(
        groups: List<Map.Entry<String, List<Pair<AdaptiveZoneObservation, Double>>>>
    ): EvidenceLot? {
        if (groups.size < MIN_DISTINCT_SESSIONS) return null
        for (a in 0 until groups.size - 2) {
            for (b in a + 1 until groups.size - 1) {
                for (c in b + 1 until groups.size) {
                    val selectedGroups = listOf(groups[a], groups[b], groups[c])
                    if (selectedGroups.sumOf { it.value.size } < MIN_BLOCK_OBSERVATIONS) continue
                    val oneFromEach = selectedGroups.mapNotNull { it.value.firstOrNull() }
                    if (oneFromEach.size < MIN_DISTINCT_SESSIONS) continue
                    val selectedKeys = oneFromEach.map { evidenceKey(it.first) }.toSet()
                    val remaining = selectedGroups.flatMap { it.value }
                        .filterNot { evidenceKey(it.first) in selectedKeys }
                    val selected = (oneFromEach + remaining).take(MIN_BLOCK_OBSERVATIONS)
                    if (selected.size == MIN_BLOCK_OBSERVATIONS) return EvidenceLot(
                        rows = selected,
                        keys = selected.map { evidenceKey(it.first) }.distinct(),
                        sessionCount = selected.map { sessionKey(it.first) }.distinct().size,
                        throughDateIso = selected.maxOfOrNull { it.first.dateIso }.orEmpty(),
                        improvementPercent = median(selected.map { it.second })
                    )
                }
            }
        }
        return null
    }

    fun evaluate(
        base: TrainingPaceZones,
        observations: List<AdaptiveZoneObservation>,
        state: AdaptiveZoneCalibrationState,
        today: LocalDate = LocalDate.now(),
        latestValidTestDateIso: String = state.referenceTestDateIso
    ): AdaptiveZoneCalibrationReview {
        val testDate = runCatching { LocalDate.parse(latestValidTestDateIso) }.getOrNull()
            ?: return AdaptiveZoneCalibrationReview(BLOCKED, today.toString(), null, null, emptyList(), emptyMap(),
                adaptiveZones.associateWith { "Registre um teste fisiológico válido antes de revisar as zonas." })
        if (state.referenceTestDateIso != testDate.toString()) {
            return AdaptiveZoneCalibrationReview(BLOCKED, today.toString(), null, null, emptyList(), emptyMap(),
                adaptiveZones.associateWith { "A referência de calibração precisa ser sincronizada com o último teste válido." })
        }
        if (state.calibrationSuspended) {
            return AdaptiveZoneCalibrationReview(BLOCKED, today.toString(), null, null, emptyList(), emptyMap(),
                adaptiveZones.associateWith { "Créditos de calibração em espera: Cooper e teste de 3 km não são convertidos automaticamente. Registre um novo teste do mesmo protocolo para restabelecer uma referência comparável; os créditos anteriores permanecem no histórico." })
        }

        val lastReview = runCatching { LocalDate.parse(state.lastReviewDateIso) }.getOrNull() ?: testDate
        val nextPeriodicReview = lastReview.plusDays(REVIEW_INTERVAL_DAYS)
        val periodicReviewDue = !today.isBefore(nextPeriodicReview)
        val cutoff = today.minusDays(REVIEW_INTERVAL_DAYS - 1)
        val consumedByZone = state.consumedEvidenceKeysByZone.mapValues { it.value.toSet() }

        val validRows = observations.mapIndexedNotNull { index, original ->
            val date = runCatching { LocalDate.parse(original.dateIso) }.getOrNull() ?: return@mapIndexedNotNull null
            val zone = original.zone.uppercase()
            val effortAllowed = when (zone) {
                "Z1" -> z1Effort
                "Z3" -> setOf("Muito leve", "Leve", "Ok", "Pesado")
                else -> safeEffort
            }
            if (zone !in adaptiveZones || !date.isAfter(testDate) || date.isBefore(cutoff) || date.isAfter(today) ||
                original.sessionId.isBlank() ||
                original.actualPaceSecondsPerKm !in 120..1800 ||
                original.targetFastestPaceSecondsPerKm !in 120..1800 ||
                original.targetSlowestPaceSecondsPerKm !in 120..1800 ||
                original.targetSlowestPaceSecondsPerKm <= original.targetFastestPaceSecondsPerKm ||
                original.painPresent || original.effort !in effortAllowed || original.feeling !in safeFeeling) return@mapIndexedNotNull null
            if (zone == "Z1" && !ZoneCalibrationEngine.isRecoveryWorkoutType(original.workoutType)) return@mapIndexedNotNull null
            val row = original.copy(zone = zone, blockId = original.blockId.ifBlank { "legacy-$index" })
            if (evidenceKey(row) in consumedByZone[zone].orEmpty()) return@mapIndexedNotNull null
            val targetMid = (row.targetFastestPaceSecondsPerKm + row.targetSlowestPaceSecondsPerKm) / 2.0
            if (targetMid <= 0.0) return@mapIndexedNotNull null
            val improvement = ((targetMid - row.actualPaceSecondsPerKm) / targetMid) * 100.0
            row to improvement
        }.distinctBy { (row, _) -> evidenceKey(row) }

        val evidenceCounts = mutableMapOf<String, Int>()
        val explanations = mutableMapOf<String, String>()
        val progressByZone = mutableMapOf<String, AdaptiveZoneLotProgress>()
        val proposedChanges = mutableMapOf<String, Double>()
        val proposalDetails = mutableMapOf<String, Triple<EvidenceLot?, EvidenceLot?, String>>()
        val currentContributionByZone = adaptiveZones.associateWith { sourceContributionPercent(state, it) }

        adaptiveZones.forEach { zone ->
            val rows = validRows.filter { it.first.zone == zone }
            val allGroups = rows.groupBy { sessionKey(it.first) }
                .entries.sortedBy { entry -> entry.value.minOf { it.first.dateIso } }
            evidenceCounts[zone] = rows.size
            val currentContribution = currentContributionByZone.getValue(zone)

            if (currentContribution >= MAX_CUMULATIVE_PERCENT - 0.0001) {
                progressByZone[zone] = AdaptiveZoneLotProgress(
                    acceptedSourceContributionPercent = currentContribution,
                    nextLot = "COMPLETO"
                )
                explanations[zone] = "Limite próprio de 5% atingido. A zona continua recebendo a propagação das zonas mais rápidas; somente um novo teste fisiológico melhor reinicia os créditos ativos."
                return@forEach
            }

            if (currentContribution > 0.0001) {
                // Existing V103 states migrate safely: if consumed IDs are absent, the accepted
                // audit date is the cutoff. All new lot-B evidence must be strictly later.
                val throughDate = legacyEvidenceThroughDate(state, zone)
                val lotBGroups = allGroups.filter { group ->
                    val groupDate = runCatching { LocalDate.parse(group.value.minOf { it.first.dateIso }) }.getOrNull()
                    groupDate != null && (throughDate == null || groupDate.isAfter(throughDate))
                }
                val (blocksB, sessionsB) = progressCounts(lotBGroups)
                progressByZone[zone] = AdaptiveZoneLotProgress(
                    acceptedSourceContributionPercent = currentContribution,
                    nextLot = "B",
                    lotBBlocksAvailable = blocksB,
                    lotBSessionsAvailable = sessionsB
                )
                val lotB = findEvidenceLot(lotBGroups)
                if (lotB == null) {
                    explanations[zone] = "Lote B em andamento: $blocksB/$MIN_BLOCK_OBSERVATIONS blocos em $sessionsB/$MIN_DISTINCT_SESSIONS sessões posteriores às evidências já confirmadas. A revisão complementar será liberada assim que o lote ficar completo, sem aguardar mais 28 dias."
                    return@forEach
                }
                val gainB = lotB.improvementPercent
                if (gainB < MIN_PROPOSAL_PERCENT) {
                    explanations[zone] = "Lote B completo, mas a melhora mediana foi ${gainB.formatPercent()}%, abaixo do mínimo de 2%. As evidências permanecem disponíveis para uma nova avaliação; nenhum crédito foi consumido."
                    return@forEach
                }
                val remaining = (MAX_CUMULATIVE_PERCENT - currentContribution).coerceAtLeast(0.0)
                val amount = min(min(gainB, 2.0), remaining)
                if (amount < MIN_PROPOSAL_PERCENT) {
                    explanations[zone] = "Saldo de contribuição de ${remaining.formatPercent()}% é inferior ao mínimo de 2% para uma nova proposta."
                    return@forEach
                }
                proposedChanges[zone] = amount
                proposalDetails[zone] = Triple(null, lotB, "Lote B: ${lotB.rows.size} blocos/${lotB.sessionCount} sessões • melhora mediana ${gainB.formatPercent()}%. Lote A já confirmado: ${currentContribution.formatPercent()}%.")
                explanations[zone] = "Lote B completo e independente. A revisão complementar é liberada imediatamente, sem esperar a revisão periódica de 28 dias."
                return@forEach
            }

            val (blocksA, sessionsA) = progressCounts(allGroups)
            val lotA = findEvidenceLot(allGroups)
            if (!periodicReviewDue) {
                val laterGroups = if (lotA != null) allGroups.filter { group ->
                    val groupDate = runCatching { LocalDate.parse(group.value.minOf { it.first.dateIso }) }.getOrNull()
                    groupDate != null && groupDate.isAfter(runCatching { LocalDate.parse(lotA.throughDateIso) }.getOrNull() ?: testDate)
                } else emptyList()
                val (blocksB, sessionsB) = progressCounts(laterGroups)
                progressByZone[zone] = AdaptiveZoneLotProgress(
                    acceptedSourceContributionPercent = currentContribution,
                    nextLot = if (lotA != null) "B" else "A",
                    lotABlocksAvailable = if (lotA != null) MIN_BLOCK_OBSERVATIONS else blocksA,
                    lotASessionsAvailable = if (lotA != null) lotA.sessionCount else sessionsA,
                    lotBBlocksAvailable = blocksB,
                    lotBSessionsAvailable = sessionsB
                )
                explanations[zone] = "${if (lotA != null) "Lote A completo; Lote B: $blocksB/$MIN_BLOCK_OBSERVATIONS blocos em $sessionsB/$MIN_DISTINCT_SESSIONS sessões posteriores." else "Lote A: $blocksA/$MIN_BLOCK_OBSERVATIONS blocos em $sessionsA/$MIN_DISTINCT_SESSIONS sessões."} Primeira revisão periódica em $nextPeriodicReview. Z1, Z2 e Z3 mantêm seus próprios lotes independentes."
                return@forEach
            }
            if (lotA == null) {
                progressByZone[zone] = AdaptiveZoneLotProgress(
                    acceptedSourceContributionPercent = currentContribution,
                    nextLot = "A",
                    lotABlocksAvailable = blocksA,
                    lotASessionsAvailable = sessionsA
                )
                explanations[zone] = "Lote A incompleto: $blocksA/$MIN_BLOCK_OBSERVATIONS blocos válidos em $sessionsA/$MIN_DISTINCT_SESSIONS sessões distintas."
                return@forEach
            }
            val gainA = lotA.improvementPercent
            if (gainA < MIN_PROPOSAL_PERCENT) {
                progressByZone[zone] = AdaptiveZoneLotProgress(
                    acceptedSourceContributionPercent = currentContribution,
                    nextLot = "A",
                    lotABlocksAvailable = blocksA,
                    lotASessionsAvailable = sessionsA
                )
                explanations[zone] = "Lote A completo, mas a melhora mediana foi ${gainA.formatPercent()}%, abaixo do mínimo de 2%. A faixa permanece preservada."
                return@forEach
            }

            val laterGroups = allGroups.filter { group ->
                val groupDate = runCatching { LocalDate.parse(group.value.minOf { it.first.dateIso }) }.getOrNull()
                groupDate != null && groupDate.isAfter(runCatching { LocalDate.parse(lotA.throughDateIso) }.getOrNull() ?: testDate)
            }
            val (blocksB, sessionsB) = progressCounts(laterGroups)
            val lotB = findEvidenceLot(laterGroups)
            progressByZone[zone] = AdaptiveZoneLotProgress(
                acceptedSourceContributionPercent = currentContribution,
                nextLot = "B",
                lotABlocksAvailable = MIN_BLOCK_OBSERVATIONS,
                lotASessionsAvailable = lotA.sessionCount,
                lotBBlocksAvailable = blocksB,
                lotBSessionsAvailable = sessionsB
            )
            var amount = min(gainA, MAX_CHANGE_PER_REVIEW_PERCENT)
            var gainB: Double? = null
            var appliedB = 0.0
            if (lotB != null) {
                gainB = lotB.improvementPercent
                if (gainB >= MIN_PROPOSAL_PERCENT) {
                    appliedB = min(gainB, 2.0)
                }
            }
            val total = amount + appliedB
            if (total < MIN_PROPOSAL_PERCENT) {
                explanations[zone] = "A evidência não permite ajuste mínimo de 2%; nenhuma alteração será proposta."
                return@forEach
            }
            proposedChanges[zone] = total
            val details = when {
                lotB != null && appliedB >= MIN_PROPOSAL_PERCENT ->
                    "Lote A: ${lotA.rows.size} blocos/${lotA.sessionCount} sessões, ${gainA.formatPercent()}% → até 3%; Lote B: ${lotB.rows.size} blocos/${lotB.sessionCount} sessões, ${requireNotNull(gainB).formatPercent()}% → até 2%."
                lotB != null ->
                    "Lote A: ${lotA.rows.size} blocos/${lotA.sessionCount} sessões, ${gainA.formatPercent()}% → até 3%. Lote B tem ${gainB?.formatPercent()}% de melhora, abaixo de 2%; seus blocos não serão consumidos."
                else ->
                    "Lote A: ${lotA.rows.size} blocos/${lotA.sessionCount} sessões, ${gainA.formatPercent()}% → até 3%. Lote B: $blocksB/$MIN_BLOCK_OBSERVATIONS blocos em $sessionsB/$MIN_DISTINCT_SESSIONS sessões posteriores."
            }
            proposalDetails[zone] = Triple(lotA, if (appliedB >= MIN_PROPOSAL_PERCENT) lotB else null, details)
            explanations[zone] = details
        }

        val previousZones = apply(base, state)
        val finalContributions = adaptiveZones.associateWith { zone ->
            (sourceContributionPercent(state, zone) + (proposedChanges[zone] ?: 0.0)).coerceAtMost(MAX_CUMULATIVE_PERCENT)
        }
        val proposedState = state.copy(cumulativePercentByZone = finalContributions)
        val proposedBoundaries = adjustedBoundaryValues(base, proposedState)
        if (proposedBoundaries == null && proposedChanges.isNotEmpty()) {
            proposedChanges.keys.forEach { zone ->
                explanations[zone] = "A proposta excederia a largura mínima de 10 segundos entre zonas ou os limites operacionais. Nenhuma faixa foi alterada; aguarde novas evidências ou um teste fisiológico válido."
            }
            return AdaptiveZoneCalibrationReview(
                status = BLOCKED,
                reviewDateIso = today.toString(),
                nextReviewDateIso = nextPeriodicReview.toString(),
                daysUntilReview = if (today.isBefore(nextPeriodicReview)) ChronoUnit.DAYS.between(today, nextPeriodicReview) else 0,
                proposals = emptyList(),
                evidenceCounts = evidenceCounts,
                explanations = explanations,
                lotProgressByZone = progressByZone
            )
        }
        val proposedZones = apply(base, proposedState)
        val proposals = proposedChanges.mapNotNull { (zone, amount) ->
            val before = previousZones.zone(zone)?.range ?: return@mapNotNull null
            val after = proposedZones.zone(zone)?.range ?: return@mapNotNull null
            val (lotA, lotB, summary) = proposalDetails[zone] ?: Triple(null, null, "")
            val selectedRows = (lotA?.rows.orEmpty() + lotB?.rows.orEmpty())
            val keys = selectedRows.map { evidenceKey(it.first) }.distinct()
            val through = selectedRows.maxOfOrNull { it.first.dateIso }.orEmpty()
            AdaptiveZoneProposal(
                zone = zone,
                previousRange = before,
                proposedRange = after,
                estimatedImprovementPercent = max(lotA?.improvementPercent ?: 0.0, lotB?.improvementPercent ?: 0.0),
                appliedChangePercent = amount,
                cumulativeAfterPercent = cumulativePercent(proposedState, zone),
                evidenceCount = keys.size,
                sessionCount = selectedRows.map { sessionKey(it.first) }.distinct().size,
                explanation = summary,
                sourceContributionAfterPercent = finalContributions[zone] ?: 0.0,
                evidenceKeys = keys,
                evidenceThroughDateIso = through,
                lotSummary = summary
            )
        }

        val hasBInProgress = progressByZone.any { (zone, progress) ->
            currentContributionByZone.getValue(zone) > 0.0 &&
                (progress.lotBBlocksAvailable < MIN_BLOCK_OBSERVATIONS || progress.lotBSessionsAvailable < MIN_DISTINCT_SESSIONS)
        }
        val hasNoChangeEvidence = explanations.values.any { it.contains("abaixo do mínimo de 2%") }
        val hasLimit = explanations.values.any { it.startsWith("Limite próprio") || it.startsWith("Saldo de contribuição") }
        val status = when {
            proposals.isNotEmpty() -> READY
            hasLimit -> LIMIT_REACHED
            !periodicReviewDue && (adaptiveZones.none { currentContributionByZone.getValue(it) > 0.0 } || hasBInProgress) -> NOT_DUE
            hasNoChangeEvidence -> NO_CHANGE
            else -> INSUFFICIENT
        }
        return AdaptiveZoneCalibrationReview(
            status = status,
            reviewDateIso = today.toString(),
            nextReviewDateIso = nextPeriodicReview.toString(),
            daysUntilReview = if (today.isBefore(nextPeriodicReview)) ChronoUnit.DAYS.between(today, nextPeriodicReview) else 0,
            proposals = proposals,
            evidenceCounts = evidenceCounts,
            explanations = explanations,
            lotProgressByZone = progressByZone
        )
    }

    fun acceptReview(
        state: AdaptiveZoneCalibrationState,
        review: AdaptiveZoneCalibrationReview
    ): AdaptiveZoneCalibrationState {
        if (review.status != READY || review.proposals.isEmpty()) return state
        val cumulative = state.cumulativePercentByZone.toMutableMap()
        val consumed = state.consumedEvidenceKeysByZone.mapValues { it.value.toMutableList() }.toMutableMap()
        val throughDates = state.evidenceThroughDateByZone.toMutableMap()
        val audit = review.proposals.map { proposal ->
            cumulative[proposal.zone] = proposal.sourceContributionAfterPercent
            consumed[proposal.zone] = (consumed[proposal.zone].orEmpty() + proposal.evidenceKeys).distinct().toMutableList()
            if (proposal.evidenceThroughDateIso.isNotBlank()) {
                val previousDate = throughDates[proposal.zone]
                val latest = listOfNotNull(previousDate, proposal.evidenceThroughDateIso).maxOrNull().orEmpty()
                throughDates[proposal.zone] = latest
            }
            AdaptiveZoneCalibrationAudit(
                dateIso = review.reviewDateIso,
                testReferenceDateIso = state.referenceTestDateIso,
                zone = proposal.zone,
                previousRange = proposal.previousRange.label(),
                newRange = proposal.proposedRange.label(),
                estimatedImprovementPercent = proposal.estimatedImprovementPercent,
                appliedChangePercent = proposal.appliedChangePercent,
                cumulativeChangePercent = proposal.cumulativeAfterPercent,
                evidenceCount = proposal.evidenceCount,
                sessionCount = proposal.sessionCount,
                sourceContributionPercent = proposal.sourceContributionAfterPercent,
                evidenceKeys = proposal.evidenceKeys,
                lotSummary = proposal.lotSummary,
                evidenceThroughDateIso = proposal.evidenceThroughDateIso
            )
        }
        return state.copy(
            lastReviewDateIso = review.reviewDateIso,
            cumulativePercentByZone = cumulative,
            history = (state.history + audit).takeLast(100),
            consumedEvidenceKeysByZone = consumed.mapValues { it.value.distinct() },
            evidenceThroughDateByZone = throughDates
        )
    }

    @Suppress("UNUSED_PARAMETER")
    fun dismissReview(state: AdaptiveZoneCalibrationState, review: AdaptiveZoneCalibrationReview): AdaptiveZoneCalibrationState =
        // Only accepting a proposal advances lastReviewDateIso. Merely opening/dismissing an
        // insufficient or unchanged preview must never postpone the next evidence check.
        state

    /** First opportunity after four complete 28-day weeks. The first day is retained historically. */
    fun retestWindowStartDate(latestValidTestDateIso: String?): LocalDate? =
        latestValidTestDateIso?.let { raw -> runCatching { LocalDate.parse(raw).plusDays(RETEST_WINDOW_START_DAYS) }.getOrNull() }

    fun retestDueDate(latestValidTestDateIso: String?): LocalDate? =
        latestValidTestDateIso?.let { raw -> runCatching { LocalDate.parse(raw).plusDays(RETEST_INTERVAL_DAYS) }.getOrNull() }

    internal data class RetestPresentation(
        val status: String,
        val displayDateIso: String?,
        val initialOpportunityDateIso: String?,
        val overdueDays: Long = 0L
    )

    /** Uses the next real calendar slot when present; never presents an expired date as upcoming. */
    fun retestPresentation(
        latestValidTestDateIso: String?,
        today: LocalDate,
        nextScheduledRetestDateIso: String? = null
    ): RetestPresentation {
        val initial = retestDueDate(latestValidTestDateIso)
        val scheduled = nextScheduledRetestDateIso
            ?.let { raw -> runCatching { LocalDate.parse(raw) }.getOrNull() }
            ?.takeIf { !it.isBefore(today) }
        if (scheduled != null) {
            return RetestPresentation("SCHEDULED", scheduled.toString(), initial?.toString(), 0L)
        }
        if (initial == null) return RetestPresentation("NO_REFERENCE", null, null, 0L)
        if (today.isAfter(initial)) {
            return RetestPresentation("OVERDUE", initial.toString(), initial.toString(), ChronoUnit.DAYS.between(initial, today))
        }
        return RetestPresentation("WAITING", initial.toString(), initial.toString(), 0L)
    }

    private fun median(values: List<Double>): Double {
        if (values.isEmpty()) return 0.0
        val sorted = values.sorted()
        val middle = sorted.size / 2
        return if (sorted.size % 2 == 0) (sorted[middle - 1] + sorted[middle]) / 2.0 else sorted[middle]
    }

    private fun Double.formatPercent(): String = String.format(java.util.Locale.US, "%.1f", this)
}
