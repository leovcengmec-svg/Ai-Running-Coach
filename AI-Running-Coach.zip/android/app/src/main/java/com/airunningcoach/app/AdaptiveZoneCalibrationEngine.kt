package com.airunningcoach.app

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

internal data class AdaptiveZoneObservation(
    val sessionId: String,
    val dateIso: String,
    val zone: String,
    val actualPaceSecondsPerKm: Int,
    val targetFastestPaceSecondsPerKm: Int,
    val targetSlowestPaceSecondsPerKm: Int,
    val effort: String,
    val feeling: String,
    val painPresent: Boolean,
    val workoutType: String
)

internal data class AdaptiveZoneCalibrationAudit(
    val dateIso: String,
    val testReferenceDateIso: String,
    val zone: String,
    val previousRange: String,
    val newRange: String,
    val estimatedImprovementPercent: Double,
    val appliedChangePercent: Double,
    val cumulativeChangePercent: Double,
    val evidenceCount: Int,
    val sessionCount: Int,
    val decision: String = "APPLIED",
    /** Contribution from this source zone before downstream propagation. */
    val sourceContributionPercent: Double = appliedChangePercent
)

internal data class AdaptiveZoneCalibrationState(
    val referenceTestDateIso: String = "",
    val lastReviewDateIso: String = "",
    val cumulativePercentByZone: Map<String, Double> = emptyMap(),
    val history: List<AdaptiveZoneCalibrationAudit> = emptyList()
)

internal data class AdaptiveZoneProposal(
    val zone: String,
    val previousRange: PaceRange,
    val proposedRange: PaceRange,
    val estimatedImprovementPercent: Double,
    val appliedChangePercent: Double,
    val cumulativeAfterPercent: Double,
    val evidenceCount: Int,
    val sessionCount: Int,
    val explanation: String,
    /** Direct contribution stored against this source zone (0–5%). */
    val sourceContributionAfterPercent: Double = 0.0
)

internal data class AdaptiveZoneCalibrationReview(
    val status: String,
    val reviewDateIso: String,
    val nextReviewDateIso: String?,
    val daysUntilReview: Long?,
    val proposals: List<AdaptiveZoneProposal>,
    val evidenceCounts: Map<String, Int>,
    val explanations: Map<String, String>
) {
    val hasProposals: Boolean get() = proposals.isNotEmpty()
}

/**
 * Evidence-gated V93 pace adaptation. Direct contributions are capped at 5% per source zone.
 * Contributions cascade down to slower zones: Z3 affects Z3/Z2/Z1, Z2 affects Z2/Z1,
 * and Z1 affects only Z1. Effective maxima are therefore Z3=5%, Z2=10%, Z1=15%.
 * Z4–Z5 remain anchored to the latest valid field test.
 */
internal object AdaptiveZoneCalibrationEngine {
    const val NOT_DUE = "NOT_DUE"
    const val READY = "READY"
    const val INSUFFICIENT = "INSUFFICIENT"
    const val NO_CHANGE = "NO_CHANGE"
    const val LIMIT_REACHED = "LIMIT_REACHED"
    const val BLOCKED = "BLOCKED"

    const val MIN_PROPOSAL_PERCENT = 2.0
    const val MAX_CHANGE_PER_REVIEW_PERCENT = 3.0
    const val MAX_CUMULATIVE_PERCENT = 5.0
    const val REVIEW_INTERVAL_DAYS = 28L
    const val RETEST_INTERVAL_DAYS = 56L
    const val RETEST_WINDOW_START_DAYS = 49L
    const val MIN_BLOCK_OBSERVATIONS = 5
    const val MIN_DISTINCT_SESSIONS = 3

    private val adaptiveZones = listOf("Z1", "Z2", "Z3")
    /** Engineering guard: never allow a zone band to collapse below ten seconds. */
    private const val MIN_ZONE_WIDTH_SECONDS = 10
    private val safeEffort = setOf("Muito leve", "Leve", "Ok")
    private val z1Effort = setOf("Muito leve", "Leve")
    private val safeFeeling = setOf("Ótimo", "Bem")

    fun resetForValidTest(
        previous: AdaptiveZoneCalibrationState,
        testDateIso: String,
        forceNewTest: Boolean = false
    ): AdaptiveZoneCalibrationState {
        val validDate = runCatching { LocalDate.parse(testDateIso) }.getOrNull()?.toString().orEmpty()
        if (validDate.isBlank()) return previous
        if (!forceNewTest && previous.referenceTestDateIso == validDate) return previous
        return previous.copy(
            referenceTestDateIso = validDate,
            lastReviewDateIso = validDate,
            cumulativePercentByZone = adaptiveZones.associateWith { 0.0 }
        )
    }

    /** Direct contribution assigned to a source zone; each source may contribute at most 5%. */
    fun sourceContributionPercent(state: AdaptiveZoneCalibrationState, zone: String): Double =
        state.cumulativePercentByZone[zone.uppercase()]?.coerceIn(0.0, MAX_CUMULATIVE_PERCENT) ?: 0.0

    /** Effective cumulative shift received by this zone after faster-zone propagation. */
    fun cumulativePercent(state: AdaptiveZoneCalibrationState, zone: String): Double = when (zone.uppercase()) {
        "Z3" -> sourceContributionPercent(state, "Z3")
        "Z2" -> sourceContributionPercent(state, "Z3") + sourceContributionPercent(state, "Z2")
        "Z1" -> sourceContributionPercent(state, "Z3") + sourceContributionPercent(state, "Z2") + sourceContributionPercent(state, "Z1")
        else -> 0.0
    }

    fun maximumEffectivePercent(zone: String): Double = when (zone.uppercase()) {
        "Z1" -> 15.0
        "Z2" -> 10.0
        "Z3" -> 5.0
        else -> 0.0
    }

    /**
     * Applies accepted cumulative adjustments to the test-derived base while keeping
     * all five bands contiguous. Shared boundaries are resolved conservatively using
     * the larger accepted shift from the two neighboring adaptive zones.
     */
    private fun adjustedBoundaryValues(
        base: TrainingPaceZones,
        state: AdaptiveZoneCalibrationState
    ): List<Int>? {
        val cumulative = adaptiveZones.associateWith { cumulativePercent(state, it) }
        val boundaries = ZoneCalibrationEngine.boundaryValues(base)
        if (boundaries.size != 6 || boundaries.any { it !in 120..1800 }) return null

        fun shifted(index: Int, percent: Double): Int =
            (boundaries[index] * (1.0 - percent / 100.0)).roundToInt()

        // Boundary order: Z5-fast, Z5-slow, Z4-slow, Z3-slow, Z2-slow, Z1-slow.
        // The shared boundary of each slower zone receives the sum of all faster-zone
        // source contributions that propagate into it.
        val adjusted = boundaries.toMutableList()
        adjusted[3] = shifted(3, cumulative.getValue("Z3"))
        adjusted[4] = shifted(4, cumulative.getValue("Z2"))
        adjusted[5] = shifted(5, cumulative.getValue("Z1"))

        if (adjusted.any { it !in 120..1800 }) return null
        if (adjusted.zipWithNext().any { (faster, slower) -> slower - faster < MIN_ZONE_WIDTH_SECONDS }) return null
        return adjusted
    }

    fun apply(
        base: TrainingPaceZones,
        state: AdaptiveZoneCalibrationState
    ): TrainingPaceZones {
        val cumulative = adaptiveZones.associateWith { cumulativePercent(state, it) }
        val adjusted = adjustedBoundaryValues(base, state) ?: return base

        fun zone(source: PaceZone, fastIndex: Int, slowIndex: Int): PaceZone = source.copy(
            range = PaceRange(adjusted[fastIndex], adjusted[slowIndex]),
            intensityBand = if (source.id in adaptiveZones && cumulative.getValue(source.id) > 0.0) {
                "Faixa adaptada por evidências reais • ${cumulative.getValue(source.id).formatPercent()}% acumulados desde o último teste"
            } else source.intensityBand
        )

        return base.copy(
            z1 = zone(base.z1, 4, 5),
            z2 = zone(base.z2, 3, 4),
            z3 = zone(base.z3, 2, 3),
            z1CalibrationStatus = if (cumulative.getValue("Z1") > 0.0) ZoneCalibrationEngine.CALIBRATED else base.z1CalibrationStatus,
            z2CalibrationStatus = if (cumulative.getValue("Z2") > 0.0) ZoneCalibrationEngine.CALIBRATED else base.z2CalibrationStatus,
            z3CalibrationStatus = if (cumulative.getValue("Z3") > 0.0) ZoneCalibrationEngine.CALIBRATED else base.z3CalibrationStatus
        )
    }

    fun evaluate(
        base: TrainingPaceZones,
        observations: List<AdaptiveZoneObservation>,
        state: AdaptiveZoneCalibrationState,
        today: LocalDate = LocalDate.now(),
        latestValidTestDateIso: String = state.referenceTestDateIso
    ): AdaptiveZoneCalibrationReview {
        val testDate = runCatching { LocalDate.parse(latestValidTestDateIso) }.getOrNull()
            ?: return AdaptiveZoneCalibrationReview(BLOCKED, today.toString(), null, null, emptyList(), emptyMap(),
                adaptiveZones.associateWith { "Registre um teste fisiológico válido antes de revisar as zonas." })
        if (state.referenceTestDateIso != testDate.toString()) {
            return AdaptiveZoneCalibrationReview(BLOCKED, today.toString(), null, null, emptyList(), emptyMap(),
                adaptiveZones.associateWith { "A referência de calibração precisa ser reiniciada pelo último teste válido." })
        }
        val lastReview = runCatching { LocalDate.parse(state.lastReviewDateIso) }.getOrNull() ?: testDate
        val nextReview = lastReview.plusDays(REVIEW_INTERVAL_DAYS)
        if (today.isBefore(nextReview)) {
            return AdaptiveZoneCalibrationReview(
                NOT_DUE, today.toString(), nextReview.toString(), ChronoUnit.DAYS.between(today, nextReview),
                emptyList(), emptyMap(), adaptiveZones.associateWith { "Próxima revisão de evidências em ${nextReview}." }
            )
        }

        val cutoff = today.minusDays(REVIEW_INTERVAL_DAYS - 1)
        val validRows = observations.mapNotNull { row ->
            val date = runCatching { LocalDate.parse(row.dateIso) }.getOrNull() ?: return@mapNotNull null
            val zone = row.zone.uppercase()
            val effortAllowed = when (zone) {
                "Z1" -> z1Effort
                "Z3" -> setOf("Muito leve", "Leve", "Ok", "Pesado")
                else -> safeEffort
            }
            if (zone !in adaptiveZones || date.isBefore(cutoff) || date.isAfter(today) ||
                row.actualPaceSecondsPerKm !in 120..1800 ||
                row.targetFastestPaceSecondsPerKm !in 120..1800 ||
                row.targetSlowestPaceSecondsPerKm !in 120..1800 ||
                row.targetSlowestPaceSecondsPerKm <= row.targetFastestPaceSecondsPerKm ||
                row.painPresent || row.effort !in effortAllowed || row.feeling !in safeFeeling) return@mapNotNull null
            if (zone == "Z1" && !ZoneCalibrationEngine.isRecoveryWorkoutType(row.workoutType)) return@mapNotNull null
            val targetMid = (row.targetFastestPaceSecondsPerKm + row.targetSlowestPaceSecondsPerKm) / 2.0
            if (targetMid <= 0.0) return@mapNotNull null
            val improvement = ((targetMid - row.actualPaceSecondsPerKm) / targetMid) * 100.0
            row.copy(zone = zone) to improvement
        }

        val evidenceCounts = mutableMapOf<String, Int>()
        val explanations = mutableMapOf<String, String>()
        val estimated = mutableMapOf<String, Double>()
        val sessions = mutableMapOf<String, Int>()
        val usable = mutableMapOf<String, List<Pair<AdaptiveZoneObservation, Double>>>()

        adaptiveZones.forEach { zone ->
            val rows = validRows.filter { it.first.zone == zone }
            val sessionCount = rows.map { "${it.first.sessionId}|${it.first.dateIso}" }.distinct().size
            evidenceCounts[zone] = rows.size
            sessions[zone] = sessionCount
            usable[zone] = rows
            if (rows.size < MIN_BLOCK_OBSERVATIONS || sessionCount < MIN_DISTINCT_SESSIONS) {
                explanations[zone] = "Evidência insuficiente: ${rows.size}/$MIN_BLOCK_OBSERVATIONS blocos válidos em $sessionCount/$MIN_DISTINCT_SESSIONS sessões distintas."
                return@forEach
            }
            val improvements = rows.map { it.second }.sorted()
            val medianImprovement = median(improvements)
            estimated[zone] = medianImprovement
            when {
                medianImprovement < MIN_PROPOSAL_PERCENT -> {
                    explanations[zone] = "Sem proposta: a melhora mediana foi ${medianImprovement.formatPercent()}%, abaixo do mínimo de 2%. A faixa fica preservada."
                }
                sourceContributionPercent(state, zone) >= MAX_CUMULATIVE_PERCENT - 0.0001 -> {
                    explanations[zone] = "Limite de contribuição de 5% desta zona atingido. A contribuição já foi propagada às zonas mais lentas; um novo teste válido reinicia os limites."
                }
                MAX_CUMULATIVE_PERCENT - sourceContributionPercent(state, zone) < MIN_PROPOSAL_PERCENT -> {
                    val remaining = MAX_CUMULATIVE_PERCENT - sourceContributionPercent(state, zone)
                    explanations[zone] = "Saldo de contribuição de ${remaining.formatPercent()}% é inferior ao mínimo de 2% por proposta. Aguarde um novo teste válido para reiniciar o limite."
                }
                else -> explanations[zone] = "Evidência consistente: ${medianImprovement.formatPercent()}% de melhora mediana com esforço controlado e sem dor."
            }
        }

        val proposedChanges = adaptiveZones.mapNotNull { zone ->
            val improvement = estimated[zone] ?: return@mapNotNull null
            if (improvement < MIN_PROPOSAL_PERCENT || !explanations[zone].orEmpty().startsWith("Evidência consistente")) return@mapNotNull null
            val currentContribution = sourceContributionPercent(state, zone)
            val remaining = MAX_CUMULATIVE_PERCENT - currentContribution
            val applied = min(min(improvement, MAX_CHANGE_PER_REVIEW_PERCENT), remaining)
            if (applied < MIN_PROPOSAL_PERCENT) return@mapNotNull null
            zone to applied
        }.toMap()
        val finalContributions = adaptiveZones.associateWith { zone ->
            (sourceContributionPercent(state, zone) + (proposedChanges[zone] ?: 0.0)).coerceAtMost(MAX_CUMULATIVE_PERCENT)
        }
        val previousZones = apply(base, state)
        val proposedState = state.copy(cumulativePercentByZone = finalContributions)
        val proposedBoundaries = adjustedBoundaryValues(base, proposedState)
        if (proposedBoundaries == null) {
            proposedChanges.keys.forEach { zone ->
                explanations[zone] = "A proposta excederia a largura mínima de 10 segundos entre zonas ou os limites operacionais. Nenhuma faixa foi alterada; aguarde novas evidências ou um teste fisiológico válido."
            }
            return AdaptiveZoneCalibrationReview(
                status = BLOCKED,
                reviewDateIso = today.toString(),
                nextReviewDateIso = today.plusDays(REVIEW_INTERVAL_DAYS).toString(),
                daysUntilReview = 0,
                proposals = emptyList(),
                evidenceCounts = evidenceCounts,
                explanations = explanations
            )
        }
        val proposedZones = apply(base, proposedState)
        val proposals = proposedChanges.mapNotNull { (zone, applied) ->
            val before = previousZones.zone(zone)?.range ?: return@mapNotNull null
            val after = proposedZones.zone(zone)?.range ?: return@mapNotNull null
            val evidence = usable[zone].orEmpty()
            AdaptiveZoneProposal(
                zone = zone,
                previousRange = before,
                proposedRange = after,
                estimatedImprovementPercent = estimated[zone] ?: 0.0,
                appliedChangePercent = applied,
                cumulativeAfterPercent = cumulativePercent(proposedState, zone),
                evidenceCount = evidence.size,
                sessionCount = sessions[zone] ?: 0,
                explanation = explanations[zone].orEmpty(),
                sourceContributionAfterPercent = finalContributions[zone] ?: 0.0
            )
        }
        val hasEnoughEvidence = adaptiveZones.any { zone ->
            (evidenceCounts[zone] ?: 0) >= MIN_BLOCK_OBSERVATIONS &&
                (sessions[zone] ?: 0) >= MIN_DISTINCT_SESSIONS
        }
        return AdaptiveZoneCalibrationReview(
            status = when {
                proposals.isNotEmpty() -> READY
                explanations.values.any { it.startsWith("Limite") || it.startsWith("Saldo restante") } -> LIMIT_REACHED
                !hasEnoughEvidence -> INSUFFICIENT
                else -> NO_CHANGE
            },
            reviewDateIso = today.toString(),
            nextReviewDateIso = today.plusDays(REVIEW_INTERVAL_DAYS).toString(),
            daysUntilReview = 0,
            proposals = proposals,
            evidenceCounts = evidenceCounts,
            explanations = explanations
        )
    }

    fun acceptReview(
        state: AdaptiveZoneCalibrationState,
        review: AdaptiveZoneCalibrationReview
    ): AdaptiveZoneCalibrationState {
        if (review.status != READY || review.proposals.isEmpty()) return state
        val cumulative = state.cumulativePercentByZone.toMutableMap()
        val audit = review.proposals.map { proposal ->
            cumulative[proposal.zone] = proposal.sourceContributionAfterPercent
            AdaptiveZoneCalibrationAudit(
                dateIso = review.reviewDateIso,
                testReferenceDateIso = state.referenceTestDateIso,
                zone = proposal.zone,
                previousRange = proposal.previousRange.label(),
                newRange = proposal.proposedRange.label(),
                estimatedImprovementPercent = proposal.estimatedImprovementPercent,
                appliedChangePercent = proposal.appliedChangePercent,
                cumulativeChangePercent = proposal.cumulativeAfterPercent,
                evidenceCount = proposal.evidenceCount,
                sessionCount = proposal.sessionCount,
                sourceContributionPercent = proposal.sourceContributionAfterPercent
            )
        }
        return state.copy(
            lastReviewDateIso = review.reviewDateIso,
            cumulativePercentByZone = cumulative,
            history = (state.history + audit).takeLast(100)
        )
    }

    fun dismissReview(state: AdaptiveZoneCalibrationState, review: AdaptiveZoneCalibrationReview): AdaptiveZoneCalibrationState =
        if (review.status == READY || review.status == NO_CHANGE || review.status == INSUFFICIENT || review.status == LIMIT_REACHED) {
            state.copy(lastReviewDateIso = review.reviewDateIso)
        } else state

    /** Start of week 8 (day 49); the 56-day mark remains the end of the preferred window. */
    fun retestWindowStartDate(latestValidTestDateIso: String?): LocalDate? =
        latestValidTestDateIso?.let { raw -> runCatching { LocalDate.parse(raw).plusDays(RETEST_WINDOW_START_DAYS) }.getOrNull() }

    fun retestDueDate(latestValidTestDateIso: String?): LocalDate? =
        latestValidTestDateIso?.let { raw -> runCatching { LocalDate.parse(raw).plusDays(RETEST_INTERVAL_DAYS) }.getOrNull() }

    private fun median(values: List<Double>): Double {
        if (values.isEmpty()) return 0.0
        val sorted = values.sorted()
        val middle = sorted.size / 2
        return if (sorted.size % 2 == 0) (sorted[middle - 1] + sorted[middle]) / 2.0 else sorted[middle]
    }

    private fun Double.formatPercent(): String = String.format(java.util.Locale.US, "%.1f", this)
}
