package com.airunningcoach.app

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

internal data class AdaptiveZoneObservation(
    val sessionId: String,
    val dateIso: String,
    val zone: String,
    val actualPaceSecondsPerKm: Int,
    val targetFastestPaceSecondsPerKm: Int,
    val targetSlowestPaceSecondsPerKm: Int,
    val effort: String,
    val feeling: String,
    val painPresent: Boolean,
    val workoutType: String
)

internal data class AdaptiveZoneCalibrationAudit(
    val dateIso: String,
    val testReferenceDateIso: String,
    val zone: String,
    val previousRange: String,
    val newRange: String,
    val estimatedImprovementPercent: Double,
    val appliedChangePercent: Double,
    val cumulativeChangePercent: Double,
    val evidenceCount: Int,
    val sessionCount: Int,
    val decision: String = "APPLIED",
    /** Contribution from this source zone before downstream propagation. */
    val sourceContributionPercent: Double = appliedChangePercent
)

internal data class AdaptiveZoneCalibrationState(
    val referenceTestDateIso: String = "",
    val lastReviewDateIso: String = "",
    val cumulativePercentByZone: Map<String, Double> = emptyMap(),
    val history: List<AdaptiveZoneCalibrationAudit> = emptyList(),
    /** Protocol attached to the current physiological reference (never mix Cooper and 3 km). */
    val referenceTestMethod: String = "",
    /** Cooper distance in km or 3 km time in seconds; only compared within the same protocol. */
    val lastTestAssessmentValue: Double? = null,
    val testComparisonStatus: String = "UNCLASSIFIED",
    /** True after a worse same-protocol test; existing credits must not be discarded. */
    val antiResetLock: Boolean = false,
    /** Credits earned under a different test protocol stay visible but are not applied. */
    val calibrationSuspended: Boolean = false,
    val pendingPercentByZone: Map<String, Double> = emptyMap(),
    /** Protocol that produced the held credits, when known. */
    val pendingTestMethod: String = ""
)

internal data class AdaptiveZoneProposal(
    val zone: String,
    val previousRange: PaceRange,
    val proposedRange: PaceRange,
    val estimatedImprovementPercent: Double,
    val appliedChangePercent: Double,
    val cumulativeAfterPercent: Double,
    val evidenceCount: Int,
    val sessionCount: Int,
    val explanation: String,
    /** Direct contribution stored against this source zone (0–5%). */
    val sourceContributionAfterPercent: Double = 0.0
)

internal data class AdaptiveZoneCalibrationReview(
    val status: String,
    val reviewDateIso: String,
    val nextReviewDateIso: String?,
    val daysUntilReview: Long?,
    val proposals: List<AdaptiveZoneProposal>,
    val evidenceCounts: Map<String, Int>,
    val explanations: Map<String, String>
) {
    val hasProposals: Boolean get() = proposals.isNotEmpty()
}

/**
 * Evidence-gated V103 pace adaptation. Direct contributions are capped at 5% per source zone.
 * Contributions cascade down to slower zones: Z3 affects Z3/Z2/Z1, Z2 affects Z2/Z1,
 * and Z1 affects only Z1. Effective maxima are therefore Z3=5%, Z2=10%, Z1=15%.
 * Z4–Z5 remain anchored to the latest valid field test.
 */
internal object AdaptiveZoneCalibrationEngine {
    const val NOT_DUE = "NOT_DUE"
    const val READY = "READY"
    const val INSUFFICIENT = "INSUFFICIENT"
    const val NO_CHANGE = "NO_CHANGE"
    const val LIMIT_REACHED = "LIMIT_REACHED"
    const val BLOCKED = "BLOCKED"

    const val MIN_PROPOSAL_PERCENT = 2.0
    /** Lot A can contribute up to 3%; a distinct Lot B can add 2% in the same review. */
    const val MAX_CHANGE_PER_REVIEW_PERCENT = 3.0
    const val MAX_CUMULATIVE_PERCENT = 5.0
    const val REVIEW_INTERVAL_DAYS = 28L
    const val RETEST_INTERVAL_DAYS = 29L
    const val RETEST_WINDOW_START_DAYS = 29L
    const val MIN_BLOCK_OBSERVATIONS = 5
    const val MIN_DISTINCT_SESSIONS = 3

    private val adaptiveZones = listOf("Z1", "Z2", "Z3")
    /** Engineering guard: never allow a zone band to collapse below ten seconds. */
    private const val MIN_ZONE_WIDTH_SECONDS = 10
    private val safeEffort = setOf("Muito leve", "Leve", "Ok")
    private val z1Effort = setOf("Muito leve", "Leve")
    private val safeFeeling = setOf("Ótimo", "Bem")

    /**
     * Synchronizes the active test date without destroying accepted calibration credits.
     * This is used for restore/edit/delete reconciliation. A genuinely new test must go
     * through registerValidTest(), which classifies its result before changing credits.
     */
    /**
     * Synchronizes metadata after a historical edit, restore or deletion. It never
     * grants/clears credits. If the selected reference protocol changed, active credits
     * are moved to the pending bucket and not applied to the new protocol.
     */
    fun synchronizeReferenceTest(
        previous: AdaptiveZoneCalibrationState,
        test: CooperAssessmentRecord,
        previousReferenceTest: CooperAssessmentRecord? = null
    ): AdaptiveZoneCalibrationState {
        val date = runCatching { LocalDate.parse(test.dateIso) }.getOrNull()?.toString().orEmpty()
        val method = test.testMethod.takeIf { it in setOf("COOPER_12_MIN", "THREE_KM") }.orEmpty()
        val metric = assessmentValue(test)
        if (date.isBlank() || method.isBlank() || metric == null) return previous
        val hasPreviousReference = previous.referenceTestDateIso.isNotBlank() ||
            previous.referenceTestMethod.isNotBlank() || previous.lastTestAssessmentValue != null
        val previousMethod = previous.referenceTestMethod.ifBlank { previousReferenceTest?.testMethod.orEmpty() }
        val protocolUnknownWithCredits = hasPreviousReference && previousMethod.isBlank() &&
            previous.cumulativePercentByZone.values.any { it > 0.0 }
        val protocolChanged = previousMethod.isNotBlank() && previousMethod != method
        val mustHoldCredits = protocolChanged || protocolUnknownWithCredits
        if (date == previous.referenceTestDateIso && method == previous.referenceTestMethod && metric == previous.lastTestAssessmentValue && !protocolChanged && !protocolUnknownWithCredits) return previous
        val currentCredits = previous.cumulativePercentByZone.mapValues { (_, value) -> value.coerceIn(0.0, MAX_CUMULATIVE_PERCENT) }
        val oldPending = previous.pendingPercentByZone.mapValues { (_, value) -> value.coerceIn(0.0, MAX_CUMULATIVE_PERCENT) }
        val pending = if (mustHoldCredits) adaptiveZones.associateWith { zone ->
            max(oldPending[zone] ?: 0.0, currentCredits[zone] ?: 0.0)
        } else oldPending
        return previous.copy(
            referenceTestDateIso = date,
            lastReviewDateIso = if (date != previous.referenceTestDateIso || mustHoldCredits) date else previous.lastReviewDateIso,
            referenceTestMethod = method,
            lastTestAssessmentValue = metric,
            testComparisonStatus = when {
                mustHoldCredits -> "INCOMPARABLE"
                !hasPreviousReference -> "INITIAL"
                date != previous.referenceTestDateIso || metric != previous.lastTestAssessmentValue -> "UNVERIFIED"
                else -> previous.testComparisonStatus
            },
            antiResetLock = previous.antiResetLock || mustHoldCredits,
            calibrationSuspended = previous.calibrationSuspended || mustHoldCredits,
            cumulativePercentByZone = if (mustHoldCredits) adaptiveZones.associateWith { 0.0 } else currentCredits,
            pendingPercentByZone = pending,
            pendingTestMethod = if (mustHoldCredits && currentCredits.values.any { it > 0.0 }) previousMethod
                else previous.pendingTestMethod
        )
    }

    @Suppress("UNUSED_PARAMETER")
    fun resetForValidTest(
        previous: AdaptiveZoneCalibrationState,
        testDateIso: String,
        forceNewTest: Boolean = false
    ): AdaptiveZoneCalibrationState {
        val validDate = runCatching { LocalDate.parse(testDateIso) }.getOrNull()?.toString().orEmpty()
        if (validDate.isBlank()) return previous
        if (previous.referenceTestDateIso == validDate) return previous
        val hasPriorState = previous.referenceTestDateIso.isNotBlank() ||
            previous.cumulativePercentByZone.values.any { it > 0.0 } || previous.history.isNotEmpty()
        return previous.copy(
            referenceTestDateIso = validDate,
            lastReviewDateIso = validDate,
            cumulativePercentByZone = if (hasPriorState) previous.cumulativePercentByZone
                else adaptiveZones.associateWith { 0.0 },
            // Legacy state is retained safely. A genuine new test must be classified by registerValidTest().
        )
    }

    /**
     * Records a new physiological test. Cooper is compared only with Cooper (distance);
     * a 3 km test is compared only with another 3 km test (time). A >=2% improvement
     * starts a new calibration phase. Equivalent or worse tests preserve earned credits;
     * worse tests additionally set an anti-reset lock. Protocol changes hold old credits
     * separately and suspend their application instead of converting them.
     */
    fun registerValidTest(
        previous: AdaptiveZoneCalibrationState,
        priorAssessments: List<CooperAssessmentRecord>,
        current: CooperAssessmentRecord,
        equivalenceTolerancePercent: Double = 2.0
    ): AdaptiveZoneCalibrationState {
        val date = runCatching { LocalDate.parse(current.dateIso) }.getOrNull()?.toString().orEmpty()
        val method = current.testMethod.takeIf { it in setOf("COOPER_12_MIN", "THREE_KM") }.orEmpty()
        val metric = assessmentValue(current)
        if (date.isBlank() || method.isBlank() || metric == null) return previous

        val priorReference = priorAssessments.firstOrNull { it.deletedAtIso.isBlank() && it.dateIso == previous.referenceTestDateIso }
        val priorMethod = previous.referenceTestMethod.ifBlank { priorReference?.testMethod.orEmpty() }
        val priorMetric = previous.lastTestAssessmentValue ?: priorReference?.let(::assessmentValue)
        val hasPreviousReference = previous.referenceTestDateIso.isNotBlank() || priorReference != null

        if (!hasPreviousReference) {
            return previous.copy(
                referenceTestDateIso = date,
                lastReviewDateIso = date,
                cumulativePercentByZone = if (previous.cumulativePercentByZone.isEmpty()) adaptiveZones.associateWith { 0.0 }
                    else previous.cumulativePercentByZone,
                referenceTestMethod = method,
                lastTestAssessmentValue = metric,
                testComparisonStatus = "INITIAL",
                antiResetLock = false,
                calibrationSuspended = false,
                pendingPercentByZone = previous.pendingPercentByZone
            )
        }

        val currentCredits = previous.cumulativePercentByZone.mapValues { (_, value) -> value.coerceIn(0.0, MAX_CUMULATIVE_PERCENT) }
        val oldPending = previous.pendingPercentByZone.mapValues { (_, value) -> value.coerceIn(0.0, MAX_CUMULATIVE_PERCENT) }
        if (hasPreviousReference && priorMethod.isBlank()) {
            val pending = adaptiveZones.associateWith { zone ->
                max(oldPending[zone] ?: 0.0, currentCredits[zone] ?: 0.0)
            }
            return previous.copy(
                referenceTestDateIso = date,
                lastReviewDateIso = date,
                cumulativePercentByZone = adaptiveZones.associateWith { 0.0 },
                referenceTestMethod = method,
                lastTestAssessmentValue = metric,
                testComparisonStatus = "INCOMPARABLE",
                antiResetLock = true,
                calibrationSuspended = true,
                pendingPercentByZone = pending,
                pendingTestMethod = previous.pendingTestMethod
            )
        }

        if (priorMethod.isNotBlank() && priorMethod != method) {
            val pending = adaptiveZones.associateWith { zone ->
                max(oldPending[zone] ?: 0.0, currentCredits[zone] ?: 0.0)
            }
            return previous.copy(
                referenceTestDateIso = date,
                lastReviewDateIso = date,
                cumulativePercentByZone = adaptiveZones.associateWith { 0.0 },
                referenceTestMethod = method,
                lastTestAssessmentValue = metric,
                testComparisonStatus = "INCOMPARABLE",
                antiResetLock = true,
                calibrationSuspended = true,
                pendingPercentByZone = pending,
                pendingTestMethod = if (currentCredits.values.any { it > 0.0 }) priorMethod else previous.pendingTestMethod
            )
        }

        val comparisonValue = priorMetric.takeIf { priorMethod == method }
        val improvement = comparisonValue?.takeIf { it > 0.0 }?.let { previousValue ->
            if (method == "THREE_KM") (previousValue - metric) / previousValue * 100.0
            else (metric - previousValue) / previousValue * 100.0
        }
        val classification = when {
            improvement == null -> "UNVERIFIED"
            improvement >= equivalenceTolerancePercent -> "IMPROVED"
            improvement <= -equivalenceTolerancePercent -> "WORSE"
            else -> "EQUIVALENT"
        }
        val improved = classification == "IMPROVED"
        val canResumeCurrentProtocol = priorMethod == method
        return previous.copy(
            referenceTestDateIso = date,
            lastReviewDateIso = date,
            cumulativePercentByZone = when {
                improved -> adaptiveZones.associateWith { 0.0 }
                else -> currentCredits
            },
            referenceTestMethod = method,
            lastTestAssessmentValue = metric,
            testComparisonStatus = classification,
            antiResetLock = when (classification) {
                "IMPROVED" -> false
                "WORSE" -> true
                else -> previous.antiResetLock
            },
            // A comparable next test establishes the new protocol-specific baseline again;
            // any old cross-protocol credit remains pending and is never applied automatically.
            calibrationSuspended = if (improved) false else if (canResumeCurrentProtocol) false else previous.calibrationSuspended,
            pendingPercentByZone = oldPending
        )
    }

    private fun assessmentValue(record: CooperAssessmentRecord): Double? = when (record.testMethod) {
        "THREE_KM" -> record.testDurationSeconds?.takeIf { it > 0 }?.toDouble()
        "COOPER_12_MIN" -> record.distanceKm.takeIf { it.isFinite() && it > 0.0 }
        else -> null
    }

    /** Direct contribution assigned to a source zone; each source may contribute at most 5%. */
    fun sourceContributionPercent(state: AdaptiveZoneCalibrationState, zone: String): Double =
        state.cumulativePercentByZone[zone.uppercase()]?.coerceIn(0.0, MAX_CUMULATIVE_PERCENT) ?: 0.0

    /** Effective cumulative shift received by this zone after faster-zone propagation. */
    fun cumulativePercent(state: AdaptiveZoneCalibrationState, zone: String): Double = when (zone.uppercase()) {
        "Z3" -> sourceContributionPercent(state, "Z3")
        "Z2" -> sourceContributionPercent(state, "Z3") + sourceContributionPercent(state, "Z2")
        "Z1" -> sourceContributionPercent(state, "Z3") + sourceContributionPercent(state, "Z2") + sourceContributionPercent(state, "Z1")
        else -> 0.0
    }

    fun maximumEffectivePercent(zone: String): Double = when (zone.uppercase()) {
        "Z1" -> 15.0
        "Z2" -> 10.0
        "Z3" -> 5.0
        else -> 0.0
    }

    /**
     * Applies accepted cumulative adjustments to the test-derived base while keeping
     * all five bands contiguous. Shared boundaries are resolved conservatively using
     * the larger accepted shift from the two neighboring adaptive zones.
     */
    private fun adjustedBoundaryValues(
        base: TrainingPaceZones,
        state: AdaptiveZoneCalibrationState
    ): List<Int>? {
        val cumulative = adaptiveZones.associateWith { cumulativePercent(state, it) }
        val boundaries = ZoneCalibrationEngine.boundaryValues(base)
        if (boundaries.size != 6 || boundaries.any { it !in 120..1800 }) return null

        fun shifted(index: Int, percent: Double): Int =
            (boundaries[index] * (1.0 - percent / 100.0)).roundToInt()

        // Boundary order: Z5-fast, Z5-slow, Z4-slow, Z3-slow, Z2-slow, Z1-slow.
        // The shared boundary of each slower zone receives the sum of all faster-zone
        // source contributions that propagate into it.
        val adjusted = boundaries.toMutableList()
        adjusted[3] = shifted(3, cumulative.getValue("Z3"))
        adjusted[4] = shifted(4, cumulative.getValue("Z2"))
        adjusted[5] = shifted(5, cumulative.getValue("Z1"))

        if (adjusted.any { it !in 120..1800 }) return null
        if (adjusted.zipWithNext().any { (faster, slower) -> slower - faster < MIN_ZONE_WIDTH_SECONDS }) return null
        return adjusted
    }

    fun apply(
        base: TrainingPaceZones,
        state: AdaptiveZoneCalibrationState
    ): TrainingPaceZones {
        if (state.calibrationSuspended) return base
        val cumulative = adaptiveZones.associateWith { cumulativePercent(state, it) }
        val adjusted = adjustedBoundaryValues(base, state) ?: return base

        fun zone(source: PaceZone, fastIndex: Int, slowIndex: Int): PaceZone = source.copy(
            range = PaceRange(adjusted[fastIndex], adjusted[slowIndex]),
            intensityBand = if (source.id in adaptiveZones && cumulative.getValue(source.id) > 0.0) {
                "Faixa adaptada por evidências reais • ${cumulative.getValue(source.id).formatPercent()}% acumulados desde o último teste"
            } else source.intensityBand
        )

        return base.copy(
            z1 = zone(base.z1, 4, 5),
            z2 = zone(base.z2, 3, 4),
            z3 = zone(base.z3, 2, 3),
            z1CalibrationStatus = if (cumulative.getValue("Z1") > 0.0) ZoneCalibrationEngine.CALIBRATED else base.z1CalibrationStatus,
            z2CalibrationStatus = if (cumulative.getValue("Z2") > 0.0) ZoneCalibrationEngine.CALIBRATED else base.z2CalibrationStatus,
            z3CalibrationStatus = if (cumulative.getValue("Z3") > 0.0) ZoneCalibrationEngine.CALIBRATED else base.z3CalibrationStatus
        )
    }

    fun evaluate(
        base: TrainingPaceZones,
        observations: List<AdaptiveZoneObservation>,
        state: AdaptiveZoneCalibrationState,
        today: LocalDate = LocalDate.now(),
        latestValidTestDateIso: String = state.referenceTestDateIso
    ): AdaptiveZoneCalibrationReview {
        val testDate = runCatching { LocalDate.parse(latestValidTestDateIso) }.getOrNull()
            ?: return AdaptiveZoneCalibrationReview(BLOCKED, today.toString(), null, null, emptyList(), emptyMap(),
                adaptiveZones.associateWith { "Registre um teste fisiológico válido antes de revisar as zonas." })
        if (state.referenceTestDateIso != testDate.toString()) {
            return AdaptiveZoneCalibrationReview(BLOCKED, today.toString(), null, null, emptyList(), emptyMap(),
                adaptiveZones.associateWith { "A referência de calibração precisa ser reiniciada pelo último teste válido." })
        }
        if (state.calibrationSuspended) {
            return AdaptiveZoneCalibrationReview(BLOCKED, today.toString(), null, null, emptyList(), emptyMap(),
                adaptiveZones.associateWith { "Créditos de calibração em espera: Cooper e teste de 3 km não são convertidos automaticamente. Registre um novo teste do mesmo protocolo para restabelecer uma referência comparável; os créditos anteriores permanecem no histórico." })
        }
        val lastReview = runCatching { LocalDate.parse(state.lastReviewDateIso) }.getOrNull() ?: testDate
        val nextReview = lastReview.plusDays(REVIEW_INTERVAL_DAYS)
        if (today.isBefore(nextReview)) {
            return AdaptiveZoneCalibrationReview(
                NOT_DUE, today.toString(), nextReview.toString(), ChronoUnit.DAYS.between(today, nextReview),
                emptyList(), emptyMap(), adaptiveZones.associateWith { "Próxima revisão de evidências em ${nextReview}." }
            )
        }

        val cutoff = today.minusDays(REVIEW_INTERVAL_DAYS - 1)
        val validRows = observations.mapNotNull { row ->
            val date = runCatching { LocalDate.parse(row.dateIso) }.getOrNull() ?: return@mapNotNull null
            val zone = row.zone.uppercase()
            val effortAllowed = when (zone) {
                "Z1" -> z1Effort
                "Z3" -> setOf("Muito leve", "Leve", "Ok", "Pesado")
                else -> safeEffort
            }
            if (zone !in adaptiveZones || !date.isAfter(testDate) || date.isBefore(cutoff) || date.isAfter(today) ||
                row.actualPaceSecondsPerKm !in 120..1800 ||
                row.targetFastestPaceSecondsPerKm !in 120..1800 ||
                row.targetSlowestPaceSecondsPerKm !in 120..1800 ||
                row.targetSlowestPaceSecondsPerKm <= row.targetFastestPaceSecondsPerKm ||
                row.painPresent || row.effort !in effortAllowed || row.feeling !in safeFeeling) return@mapNotNull null
            if (zone == "Z1" && !ZoneCalibrationEngine.isRecoveryWorkoutType(row.workoutType)) return@mapNotNull null
            val targetMid = (row.targetFastestPaceSecondsPerKm + row.targetSlowestPaceSecondsPerKm) / 2.0
            if (targetMid <= 0.0) return@mapNotNull null
            val improvement = ((targetMid - row.actualPaceSecondsPerKm) / targetMid) * 100.0
            row.copy(zone = zone) to improvement
        }

        val evidenceCounts = mutableMapOf<String, Int>()
        val explanations = mutableMapOf<String, String>()
        val estimated = mutableMapOf<String, Double>()
        val sessions = mutableMapOf<String, Int>()
        val usable = mutableMapOf<String, List<Pair<AdaptiveZoneObservation, Double>>>()
        val proposedAmounts = mutableMapOf<String, Double>()

        // One evidence lot = >=5 valid blocks distributed across three distinct sessions.
        // A second lot must use three later, different sessions. This lets the athlete
        // reach 3% + 2% in the same 28-day review window when both independent lots exist.
        fun findEvidenceLot(
            groups: List<Map.Entry<String, List<Pair<AdaptiveZoneObservation, Double>>>>
        ): List<Pair<AdaptiveZoneObservation, Double>>? {
            if (groups.size < MIN_DISTINCT_SESSIONS) return null
            for (a in 0 until groups.size - 2) {
                for (b in a + 1 until groups.size - 1) {
                    for (c in b + 1 until groups.size) {
                        val selected = listOf(groups[a], groups[b], groups[c])
                        val blocks = selected.sumOf { it.value.size }
                        if (blocks >= MIN_BLOCK_OBSERVATIONS) return selected.flatMap { it.value }
                    }
                }
            }
            return null
        }

        adaptiveZones.forEach { zone ->
            val rows = validRows.filter { it.first.zone == zone }
            val grouped = rows.groupBy { "${it.first.sessionId}|${it.first.dateIso}" }
                .entries.sortedBy { entry -> entry.value.minOf { it.first.dateIso } }
            val sessionCount = grouped.size
            evidenceCounts[zone] = rows.size
            sessions[zone] = sessionCount
            usable[zone] = rows
            if (rows.size < MIN_BLOCK_OBSERVATIONS || sessionCount < MIN_DISTINCT_SESSIONS) {
                explanations[zone] = "Evidência insuficiente: ${rows.size}/$MIN_BLOCK_OBSERVATIONS blocos válidos em $sessionCount/$MIN_DISTINCT_SESSIONS sessões distintas."
                return@forEach
            }

            val currentContribution = sourceContributionPercent(state, zone)
            if (currentContribution >= MAX_CUMULATIVE_PERCENT - 0.0001) {
                explanations[zone] = "Limite acumulado de 5% atingido. Somente um novo teste fisiológico melhor poderá iniciar outro ciclo de contribuição."
                return@forEach
            }
            val alreadyHasFirstLot = currentContribution >= MIN_PROPOSAL_PERCENT - 0.0001
            val firstLot: List<Pair<AdaptiveZoneObservation, Double>>?
            val secondLot: List<Pair<AdaptiveZoneObservation, Double>>?
            if (alreadyHasFirstLot) {
                // The previous review already accepted lot A (up to 3%). Current-window
                // observations are a fresh lot B; prior blocks have fallen outside the window.
                firstLot = rows
                secondLot = null
            } else {
                firstLot = findEvidenceLot(grouped)
                val firstKeys = firstLot?.map { "${it.first.sessionId}|${it.first.dateIso}" }?.toSet().orEmpty()
                val firstEndDate = firstLot?.maxOfOrNull { it.first.dateIso }
                val laterGroups = grouped.filter { entry ->
                    entry.key !in firstKeys && firstEndDate != null && entry.value.minOf { it.first.dateIso } > firstEndDate
                }
                secondLot = if (firstLot != null) findEvidenceLot(laterGroups) else null
            }

            if (firstLot == null) {
                explanations[zone] = "Lote A ainda incompleto: são necessários pelo menos $MIN_BLOCK_OBSERVATIONS blocos válidos em $MIN_DISTINCT_SESSIONS sessões distintas."
                return@forEach
            }

            val firstMedian = median(firstLot.map { it.second }.sorted())
            estimated[zone] = firstMedian
            if (firstMedian < MIN_PROPOSAL_PERCENT) {
                explanations[zone] = "Sem proposta: o primeiro lote apresentou melhora mediana de ${firstMedian.formatPercent()}%, abaixo do mínimo de 2%. A faixa fica preservada."
                return@forEach
            }

            val remaining = MAX_CUMULATIVE_PERCENT - currentContribution
            val primaryCap = if (alreadyHasFirstLot) 2.0 else MAX_CHANGE_PER_REVIEW_PERCENT
            val firstApplied = min(min(firstMedian, primaryCap), remaining)
            var secondApplied = 0.0
            var secondMedian: Double? = null
            if (!alreadyHasFirstLot && secondLot != null) {
                secondMedian = median(secondLot.map { it.second }.sorted())
                if (secondMedian >= MIN_PROPOSAL_PERCENT) {
                    secondApplied = min(min(secondMedian, 2.0), (remaining - firstApplied).coerceAtLeast(0.0))
                }
            }
            val totalApplied = firstApplied + secondApplied
            if (totalApplied < MIN_PROPOSAL_PERCENT) {
                explanations[zone] = when {
                    remaining < MIN_PROPOSAL_PERCENT -> "Saldo de contribuição de ${remaining.formatPercent()}% é inferior ao mínimo de 2% por proposta. Aguarde novo teste fisiológico para reiniciar o limite."
                    else -> "A evidência não permite ajuste mínimo de 2%; a faixa permanece preservada."
                }
                return@forEach
            }
            proposedAmounts[zone] = totalApplied
            explanations[zone] = when {
                alreadyHasFirstLot -> "Lote B consistente: nova melhora mediana de ${firstMedian.formatPercent()}% em evidências posteriores e distintas. Crédito adicional limitado a 2%; os 3% do Lote A já estavam confirmados."
                secondLot != null && secondApplied >= MIN_PROPOSAL_PERCENT -> "Dois lotes independentes confirmados: Lote A ${firstMedian.formatPercent()}% (até 3%) + Lote B ${requireNotNull(secondMedian).formatPercent()}% (até 2%), em seis sessões distintas ou mais."
                secondLot != null -> "Lote A consistente: ${firstMedian.formatPercent()}% de melhora mediana. O segundo lote ainda não comprovou melhora mínima de 2%; contribuição limitada ao primeiro lote (até 3%)."
                else -> "Lote A consistente: ${firstMedian.formatPercent()}% de melhora mediana em $MIN_DISTINCT_SESSIONS sessões distintas. O Lote B exige outras três sessões distintas e pelo menos cinco blocos válidos; por enquanto, contribuição limitada a 3%."
            }
        }

        val proposedChanges = adaptiveZones.mapNotNull { zone ->
            val amount = proposedAmounts[zone] ?: return@mapNotNull null
            if (amount < MIN_PROPOSAL_PERCENT) return@mapNotNull null
            zone to amount
        }.toMap()
        val finalContributions = adaptiveZones.associateWith { zone ->
            (sourceContributionPercent(state, zone) + (proposedChanges[zone] ?: 0.0)).coerceAtMost(MAX_CUMULATIVE_PERCENT)
        }
        val previousZones = apply(base, state)
        val proposedState = state.copy(cumulativePercentByZone = finalContributions)
        val proposedBoundaries = adjustedBoundaryValues(base, proposedState)
        if (proposedBoundaries == null) {
            proposedChanges.keys.forEach { zone ->
                explanations[zone] = "A proposta excederia a largura mínima de 10 segundos entre zonas ou os limites operacionais. Nenhuma faixa foi alterada; aguarde novas evidências ou um teste fisiológico válido."
            }
            return AdaptiveZoneCalibrationReview(
                status = BLOCKED,
                reviewDateIso = today.toString(),
                nextReviewDateIso = today.plusDays(REVIEW_INTERVAL_DAYS).toString(),
                daysUntilReview = 0,
                proposals = emptyList(),
                evidenceCounts = evidenceCounts,
                explanations = explanations
            )
        }
        val proposedZones = apply(base, proposedState)
        val proposals = proposedChanges.mapNotNull { (zone, applied) ->
            val before = previousZones.zone(zone)?.range ?: return@mapNotNull null
            val after = proposedZones.zone(zone)?.range ?: return@mapNotNull null
            val evidence = usable[zone].orEmpty()
            AdaptiveZoneProposal(
                zone = zone,
                previousRange = before,
                proposedRange = after,
                estimatedImprovementPercent = estimated[zone] ?: 0.0,
                appliedChangePercent = applied,
                cumulativeAfterPercent = cumulativePercent(proposedState, zone),
                evidenceCount = evidence.size,
                sessionCount = sessions[zone] ?: 0,
                explanation = explanations[zone].orEmpty(),
                sourceContributionAfterPercent = finalContributions[zone] ?: 0.0
            )
        }
        val hasEnoughEvidence = adaptiveZones.any { zone ->
            val explanation = explanations[zone].orEmpty()
            explanation.startsWith("Sem proposta") || explanation.startsWith("Lote A consistente") ||
                explanation.startsWith("Dois lotes independentes") || explanation.startsWith("Lote B consistente") ||
                explanation.startsWith("Saldo de contribuição")
        }
        return AdaptiveZoneCalibrationReview(
            status = when {
                proposals.isNotEmpty() -> READY
                explanations.values.any { it.startsWith("Limite") || it.startsWith("Saldo restante") || it.startsWith("Saldo de contribuição") } -> LIMIT_REACHED
                !hasEnoughEvidence -> INSUFFICIENT
                else -> NO_CHANGE
            },
            reviewDateIso = today.toString(),
            nextReviewDateIso = today.plusDays(REVIEW_INTERVAL_DAYS).toString(),
            daysUntilReview = 0,
            proposals = proposals,
            evidenceCounts = evidenceCounts,
            explanations = explanations
        )
    }

    fun acceptReview(
        state: AdaptiveZoneCalibrationState,
        review: AdaptiveZoneCalibrationReview
    ): AdaptiveZoneCalibrationState {
        if (review.status != READY || review.proposals.isEmpty()) return state
        val cumulative = state.cumulativePercentByZone.toMutableMap()
        val audit = review.proposals.map { proposal ->
            cumulative[proposal.zone] = proposal.sourceContributionAfterPercent
            AdaptiveZoneCalibrationAudit(
                dateIso = review.reviewDateIso,
                testReferenceDateIso = state.referenceTestDateIso,
                zone = proposal.zone,
                previousRange = proposal.previousRange.label(),
                newRange = proposal.proposedRange.label(),
                estimatedImprovementPercent = proposal.estimatedImprovementPercent,
                appliedChangePercent = proposal.appliedChangePercent,
                cumulativeChangePercent = proposal.cumulativeAfterPercent,
                evidenceCount = proposal.evidenceCount,
                sessionCount = proposal.sessionCount,
                sourceContributionPercent = proposal.sourceContributionAfterPercent
            )
        }
        return state.copy(
            lastReviewDateIso = review.reviewDateIso,
            cumulativePercentByZone = cumulative,
            history = (state.history + audit).takeLast(100)
        )
    }

    fun dismissReview(state: AdaptiveZoneCalibrationState, review: AdaptiveZoneCalibrationReview): AdaptiveZoneCalibrationState =
        if (review.status == READY || review.status == NO_CHANGE || review.status == INSUFFICIENT || review.status == LIMIT_REACHED) {
            state.copy(lastReviewDateIso = review.reviewDateIso)
        } else state

    /** Four-week operational review block; retest is placed after four completed weeks, subject to adherence. */
    fun retestWindowStartDate(latestValidTestDateIso: String?): LocalDate? =
        latestValidTestDateIso?.let { raw -> runCatching { LocalDate.parse(raw).plusDays(RETEST_WINDOW_START_DAYS) }.getOrNull() }

    fun retestDueDate(latestValidTestDateIso: String?): LocalDate? =
        latestValidTestDateIso?.let { raw -> runCatching { LocalDate.parse(raw).plusDays(RETEST_INTERVAL_DAYS) }.getOrNull() }

    private fun median(values: List<Double>): Double {
        if (values.isEmpty()) return 0.0
        val sorted = values.sorted()
        val middle = sorted.size / 2
        return if (sorted.size % 2 == 0) (sorted[middle - 1] + sorted[middle]) / 2.0 else sorted[middle]
    }

    private fun Double.formatPercent(): String = String.format(java.util.Locale.US, "%.1f", this)
}
