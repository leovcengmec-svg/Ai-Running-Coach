package com.airunningcoach.app

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Test

class PerformanceMonitoringEngineV63Test {
    @Test
    fun `monitoramento nao mistura terreno e compara somente condicoes semelhantes`() {
        val today = LocalDate.of(2026, 11, 17)
        val observations = (0 until 6).map { index ->
            PaceObservation(
                dateIso = today.minusDays((24 - index * 4).toLong()).toString(),
                distanceKm = 5.0,
                paceMmSs = if (index < 4) "07:20" else "06:50",
                sessionType = "Aeróbio",
                effort = "Leve",
                feeling = "Bem",
                painPresent = false,
                terrain = if (index == 0) RunningTerrain.TRAIL else RunningTerrain.ROAD,
                elevationGainMeters = if (index == 1) 120.0 else 20.0
            )
        }
        val result = PerformanceMonitoringEngine.evaluate(observations, today)
        assertEquals("FASTER", result.status)
        assertEquals(4, result.comparableSessions)
    }
}
