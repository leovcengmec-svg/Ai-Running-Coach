package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ActivityZoneTimeEngineTest {
    @Test fun `soma somente segundos medidos dentro de faixas de pace`() {
        val zones = listOf(
            PaceZone("Z1", "Leve", "", PaceRange(600, 720), ""),
            PaceZone("Z2", "Aeróbia", "", PaceRange(480, 599), ""),
            PaceZone("Z3", "Moderada", "", PaceRange(420, 479), "")
        )
        val segments = listOf(
            ActivityPaceSegment(650, 30),
            ActivityPaceSegment(520, 45),
            ActivityPaceSegment(450, 20),
            ActivityPaceSegment(900, 15), // Outside supplied zone ranges.
            ActivityPaceSegment(520, 0),  // Invalid duration.
            ActivityPaceSegment(520, 180) // Long gap is not a measured segment.
        )
        assertEquals(mapOf("Z1" to 30, "Z2" to 45, "Z3" to 20), ActivityZoneTimeEngine.summarize(segments, zones))
    }

    @Test fun `ausencia de zonas ou amostras nao cria tempo medido`() {
        assertTrue(ActivityZoneTimeEngine.summarize(emptyList(), emptyList()).isEmpty())
        assertTrue(ActivityZoneTimeEngine.summarize(listOf(ActivityPaceSegment(500, 30)), emptyList()).isEmpty())
    }
}
