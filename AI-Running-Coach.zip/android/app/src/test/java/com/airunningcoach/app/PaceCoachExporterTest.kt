package com.airunningcoach.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PaceCoachExporterTest {
    private fun workout(segments: List<WorkoutSegment>, stimulus: String = "INTERVALS", title: String = "Treino de teste"): PrescribedWorkout = PrescribedWorkout(
        day = "Segunda-feira",
        date = "Segunda-feira, 09/11",
        scheduledDateIso = "2026-11-09",
        title = title,
        type = "Qualidade",
        objective = "Testar interoperabilidade",
        stimulus = stimulus,
        sessionId = "W1-MONDAY-QUALITY",
        distanceKm = 8.0,
        durationMin = 48,
        intensity = "MODERATE",
        paceMode = "PACE_RANGE",
        rpeRange = "5-7",
        detail = "Teste",
        rationale = "Fixture de interoperabilidade",
        segments = segments
    )

    @Test
    fun `exporta wrapper UserWorkoutJson exatamente como o arquivo padrao`() {
        val sampleLike = workout(
            listOf(
                WorkoutSegment("Aquecimento", "Aqueça", durationMin = 8, intensity = "LOW"),
                WorkoutSegment("Intervalo principal", "Corra forte", durationMin = 8, targetPaceMinValue = 250, targetPaceMaxValue = 250, paceZone = "Z4"),
                WorkoutSegment("Recuperação", "Recupere", durationMin = 2, intensity = "LOW"),
                WorkoutSegment("Desaquecimento", "Reduza", durationMin = 5, intensity = "LOW")
            )
        )

        val root = JSONObject(PaceCoachExporter.workoutToJson(sampleLike, "5 km", 5.0))
        assertEquals(1, root.length())
        assertTrue(root.has("com.garmin.connect.workout.json.UserWorkoutJson"))
        val userWorkout = root.getJSONObject(PaceCoachExporter.USER_WORKOUT_JSON_KEY)
        assertTrue(userWorkout.getLong("workoutId") > 0L)
        assertEquals("Treino de teste", userWorkout.getString("workoutName"))
        assertTrue(userWorkout.getString("createdDate").endsWith(" GMT"))
        assertTrue(userWorkout.getString("updatedDate").endsWith(" GMT"))
        assertEquals(0, userWorkout.getInt("ownerId"))
        assertEquals("running", userWorkout.getString("sportTypeKey"))

        val steps = userWorkout.getJSONArray("workoutSteps")
        assertEquals(4, steps.length())
        val warmup = steps.getJSONObject(0)
        assertEquals(1, warmup.getInt("stepOrder"))
        assertEquals("warmup", warmup.getString("stepTypeKey"))
        assertTrue(warmup.getInt("groupId") > 0)
        assertFalse(warmup.has("parentGroupId"))
        assertEquals("time", warmup.getString("endConditionTypeKey"))
        assertEquals(480000.0, warmup.getDouble("endConditionValue"), 0.0)
        assertEquals(41, warmup.getInt("endConditionUnitPk"))

        val active = steps.getJSONObject(1)
        assertEquals("interval", active.getString("stepTypeKey"))
        assertEquals("active", active.getString("intensityTypeKey"))
        assertEquals("pace.zone", active.getString("targetTypeKey"))
        assertEquals(7, active.getInt("targetValueUnitPk"))
        assertEquals("centimetersPerMillisecond", active.getString("targetValueUnitKey"))
        assertEquals(0.4, active.getDouble("targetValueOne"), 0.000001)
        assertEquals(0.4, active.getDouble("targetValueTwo"), 0.000001)
        assertEquals("04:10", active.getString("targetOneDisplayValue"))
        assertEquals("04:10", active.getString("targetTwoDisplayValue"))

        val recovery = steps.getJSONObject(2)
        assertEquals("recovery", recovery.getString("stepTypeKey"))
        assertEquals("rest", recovery.getString("intensityTypeKey"))
        assertEquals("no.target", recovery.getString("targetTypeKey"))
        assertEquals("dimensionless", recovery.getString("targetValueUnitKey"))

        assertEquals("cooldown", steps.getJSONObject(3).getString("stepTypeKey"))
    }

    @Test
    fun `distancia e exportada em metros conforme leitura do Pace Coach`() {
        val value = workout(
            listOf(WorkoutSegment("Rodagem aeróbia", "Ritmo fácil", distanceKm = 1.25, targetPaceMinValue = 420, targetPaceMaxValue = 450))
        )
        val exported = JSONObject(PaceCoachExporter.workoutToJson(value, "5 km", 5.0))
            .getJSONObject(PaceCoachExporter.USER_WORKOUT_JSON_KEY)
            .getJSONArray("workoutSteps").getJSONObject(0)

        assertEquals("distance", exported.getString("endConditionTypeKey"))
        assertEquals(1250.0, exported.getDouble("endConditionValue"), 0.0)
        assertEquals(1, exported.getInt("endConditionUnitPk"))
        assertEquals("meter", exported.getString("endConditionUnitKey"))
        assertEquals("Meters", exported.getString("endConditionDisplayUnit"))
        assertEquals("pace.zone", exported.getString("targetTypeKey"))
        assertTrue(exported.getDouble("targetValueOne") < exported.getDouble("targetValueTwo"))
        assertFalse(exported.has("distanceKm"))
    }

    @Test
    fun `distancias comuns mantem exatamente os metros no Pace Coach`() {
        val values = listOf(0.2, 0.4, 0.6, 1.0, 1.1, 1.5, 5.0)
        values.forEach { km ->
            val segment = WorkoutSegment("Rodagem", "Executar", distanceKm = km)
            val exported = JSONObject(PaceCoachExporter.workoutToJson(workout(listOf(segment)), "5 km", 5.0))
                .getJSONObject(PaceCoachExporter.USER_WORKOUT_JSON_KEY)
                .getJSONArray("workoutSteps").getJSONObject(0)
            assertEquals((km * 1000.0).toLong().toDouble(), exported.getDouble("endConditionValue"), 0.0)
            assertEquals("meter", exported.getString("endConditionUnitKey"))
        }
    }

    @Test
    fun `recuperacao ativa preserva ritmo e recuperacao passiva permanece sem alvo`() {
        val activeRecovery = WorkoutSegment(
            "Recuperação Z1", "Trote confortável", durationMin = 2,
            targetPaceMinValue = 490, targetPaceMaxValue = 520, paceZone = "Z1"
        )
        val passiveRecovery = WorkoutSegment(
            "Pausa parada", "Recupere parado", durationMin = 1,
            recoveryMode = "PASSIVE"
        )
        val steps = JSONObject(PaceCoachExporter.workoutToJson(workout(listOf(activeRecovery, passiveRecovery)), "5 km", 5.0))
            .getJSONObject(PaceCoachExporter.USER_WORKOUT_JSON_KEY).getJSONArray("workoutSteps")
        assertEquals("pace.zone", steps.getJSONObject(0).getString("targetTypeKey"))
        assertTrue(steps.getJSONObject(0).has("targetValueOne"))
        assertEquals("no.target", steps.getJSONObject(1).getString("targetTypeKey"))
        assertFalse(steps.getJSONObject(1).has("targetValueOne"))
    }

    @Test
    fun `repeticoes agrupadas legadas sao exportadas como etapas individuais alternadas`() {
        val value = workout(
            listOf(
                WorkoutSegment("Aquecimento", "Aqueça", durationMin = 5),
                WorkoutSegment("Corrida leve", "Corra", durationMin = 2, repeatCount = 3),
                WorkoutSegment("Caminhada de recuperação", "Caminhe", durationMin = 2, repeatCount = 3),
                WorkoutSegment("Desaquecimento", "Finalize", durationMin = 5)
            )
        )
        val steps = JSONObject(PaceCoachExporter.workoutToJson(value, "5 km", 5.0))
            .getJSONObject(PaceCoachExporter.USER_WORKOUT_JSON_KEY)
            .getJSONArray("workoutSteps")

        assertEquals(8, steps.length())
        assertEquals("interval", steps.getJSONObject(1).getString("stepTypeKey"))
        assertEquals("recovery", steps.getJSONObject(2).getString("stepTypeKey"))
        assertEquals("interval", steps.getJSONObject(3).getString("stepTypeKey"))
        assertEquals("recovery", steps.getJSONObject(4).getString("stepTypeKey"))
        assertEquals("interval", steps.getJSONObject(5).getString("stepTypeKey"))
        assertEquals("recovery", steps.getJSONObject(6).getString("stepTypeKey"))
        assertEquals("cooldown", steps.getJSONObject(7).getString("stepTypeKey"))
        assertEquals((1..8).toList(), (0 until steps.length()).map { steps.getJSONObject(it).getInt("stepOrder") })
        assertTrue((0 until steps.length()).none { steps.getJSONObject(it).getString("stepTypeKey") == "repeat" })
    }

    @Test
    fun `todas as etapas possuem ids unicos e ordem sequencial`() {
        val value = workout(
            listOf(
                WorkoutSegment("Aquecimento", "Aqueça", durationMin = 5),
                WorkoutSegment("Série", "Execute", durationMin = 3, repeatCount = 4),
                WorkoutSegment("Recuperação", "Recupere", durationMin = 2, repeatCount = 4),
                WorkoutSegment("Desaquecimento", "Finalize", distanceKm = 0.5)
            )
        )
        val steps = JSONObject(PaceCoachExporter.workoutToJson(value, "10 km", 10.0))
            .getJSONObject(PaceCoachExporter.USER_WORKOUT_JSON_KEY)
            .getJSONArray("workoutSteps")
        val ids = (0 until steps.length()).map { steps.getJSONObject(it).getLong("stepId") }
        val orders = (0 until steps.length()).map { steps.getJSONObject(it).getInt("stepOrder") }
        assertEquals(ids.size, ids.toSet().size)
        assertEquals((1..steps.length()).toList(), orders)
    }
    @Test
    fun `grupo repetitivo e expandido em etapas do Pace Coach sem bloco repeat`() {
        val value = workout(
            listOf(
                WorkoutSegment("Aquecimento", "Aqueça", distanceKm = 1.0, targetPaceMinValue = 360, targetPaceMaxValue = 390),
                WorkoutSegment("Intervalo", "Execute", durationMin = 4, repeatCount = 4),
                WorkoutSegment("Recuperação", "Recupere", durationMin = 2, repeatCount = 4),
                WorkoutSegment("Desaquecimento", "Finalize", distanceKm = 1.0, targetPaceMinValue = 360, targetPaceMaxValue = 390)
            )
        )
        val steps = JSONObject(PaceCoachExporter.workoutToJson(value, "5 km", 5.0))
            .getJSONObject(PaceCoachExporter.USER_WORKOUT_JSON_KEY)
            .getJSONArray("workoutSteps")
        assertEquals(10, steps.length())
        val kinds = (0 until steps.length()).map { steps.getJSONObject(it).getString("stepTypeKey") }
        assertEquals(listOf("warmup", "interval", "recovery", "interval", "recovery", "interval", "recovery", "interval", "recovery", "cooldown"), kinds)
        assertTrue((0 until steps.length()).none { steps.getJSONObject(it).has("parentGroupId") })
        assertEquals(1, steps.getJSONObject(1).getInt("coachRhythm"))
        assertEquals(1, steps.getJSONObject(2).getInt("coachRhythm"))
    }

    @Test
    fun `protocolo 6x400 exporta exatamente 14 etapas individuais`() {
        val segments = mutableListOf(
            WorkoutSegment("Aquecimento leve", "Aqueça", distanceKm = 0.8),
            WorkoutSegment("Preparação em Z2", "Prepare o ritmo", distanceKm = 0.7, paceZone = "Z2")
        )
        repeat(6) { index ->
            segments += WorkoutSegment("Intervalo", "400 metros em Z4", distanceKm = 0.4, paceZone = "Z4", targetPaceMinValue = 360, targetPaceMaxValue = 380)
            if (index < 5) segments += WorkoutSegment("Recuperação caminhando", "Caminhe por 2 minutos", durationMin = 2, targetMode = "TIME", recoveryMode = "WALK")
        }
        segments += WorkoutSegment("Desaquecimento", "Finalize", distanceKm = 0.8)
        assertTrue("${TrainingProtocolCatalog.validateNamedProtocol("I05", segments)}", TrainingProtocolCatalog.validateNamedProtocol("I05", segments).isEmpty())
        val steps = JSONObject(PaceCoachExporter.workoutToJson(workout(segments, stimulus = "INTERVAL:I05", title = "Intervalado 6 × 400 m"), "5 km", 5.0))
            .getJSONObject(PaceCoachExporter.USER_WORKOUT_JSON_KEY).getJSONArray("workoutSteps")
        assertEquals(14, steps.length())
        assertTrue((0 until steps.length()).none { steps.getJSONObject(it).getString("stepTypeKey") == "repeat" })
    }

    @Test
    fun `duracoes em segundos sao exportadas em milissegundos sem arredondar para minuto`() {
        val value = workout(listOf(
            WorkoutSegment("Aceleração", "Rápida e relaxada", durationSeconds = 12, targetMode = "TIME"),
            WorkoutSegment("Recuperação caminhando", "Caminhe", durationSeconds = 75, targetMode = "TIME", recoveryMode = "WALK")
        ))
        val steps = JSONObject(PaceCoachExporter.workoutToJson(value, "5 km", 5.0))
            .getJSONObject(PaceCoachExporter.USER_WORKOUT_JSON_KEY).getJSONArray("workoutSteps")
        assertEquals(12_000.0, steps.getJSONObject(0).getDouble("endConditionValue"), 0.0)
        assertEquals(75_000.0, steps.getJSONObject(1).getDouble("endConditionValue"), 0.0)
    }

    @Test
    fun `nome amigavel da semana e gravado em workoutName`() {
        val value = workout(listOf(WorkoutSegment("Rodagem aeróbia", "Ritmo confortável", distanceKm = 5.0)))
        val root = JSONObject(PaceCoachExporter.workoutToJson(
            value, "5 km", 5.0, "Semana 1 · Treino 1 · Rodagem Aeróbica · 11.11"
        ))
        val userWorkout = root.getJSONObject(PaceCoachExporter.USER_WORKOUT_JSON_KEY)
        assertEquals("Semana 1 · Treino 1 · Rodagem Aeróbica · 11.11", userWorkout.getString("workoutName"))
    }

}
