package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TrainingPeriodizationEngineTest {
    private fun input(goal: Double, level: String = "Intermediário", weekly: Double = 20.0, longest: Double = 10.0) = RunnerInput(
        goalKm = goal, level = level, frequency = 4, weeklyVolumeKm = weekly, longestRecentKm = longest
    )

    @Test fun `macrociclo separa base desenvolvimento especifico e recuperacao`() {
        assertEquals(TrainingPeriodizationEngine.BASE, TrainingPeriodizationEngine.phaseForWeek(1, 8, false))
        assertEquals(TrainingPeriodizationEngine.DEVELOPMENT, TrainingPeriodizationEngine.phaseForWeek(3, 8, false))
        assertEquals(TrainingPeriodizationEngine.SPECIFIC, TrainingPeriodizationEngine.phaseForWeek(7, 8, false))
        assertEquals(TrainingPeriodizationEngine.RECOVERY, TrainingPeriodizationEngine.phaseForWeek(4, 8, true))
    }

    @Test fun `objetivos curtos e longos selecionam estimulos diferentes`() {
        val zones = PaceCalculator.calculateCooper(2.4)
        assertEquals("PROGRESSIVE_RUN", TrainingPeriodizationEngine.selectQualityKind(input(5.0), TrainingPeriodizationEngine.BASE, zones))
        assertEquals("THRESHOLD_INTERVAL_Z3_Z4", TrainingPeriodizationEngine.selectQualityKind(input(21.1, "Avançado", 30.0, 12.0), TrainingPeriodizationEngine.DEVELOPMENT, zones))
        assertEquals("MARATHON_SPECIFIC", TrainingPeriodizationEngine.selectQualityKind(input(42.195, "Avançado", 50.0, 20.0), TrainingPeriodizationEngine.SPECIFIC, zones))
        assertEquals("ULTRA_SPECIFIC", TrainingPeriodizationEngine.selectQualityKind(input(50.0, "Avançado", 55.0, 25.0), TrainingPeriodizationEngine.SPECIFIC, zones))
    }

    @Test fun `objetivo de saude nao libera limiar nem vo2 automaticamente`() {
        val zones = PaceCalculator.calculateCooper(2.4)
        val health = input(5.0, "Avançado", 30.0, 12.0).copy(goalCategory = "HEALTH")
        assertFalse(TrainingPeriodizationEngine.thresholdEligible(health, zones))
        assertFalse(TrainingPeriodizationEngine.vo2Eligible(health, zones))
        assertEquals("STEADY_RUN", TrainingPeriodizationEngine.selectQualityKind(health, TrainingPeriodizationEngine.SPECIFIC, zones))
    }

    @Test fun `intervalados z4 z5 exigem perfil volume distancia recuperacao`() {
        val zones = PaceCalculator.calculateCooper(2.6)
        val eligible = input(5.0, "Avançado", 30.0, 12.0).copy(recoveryScore = 85.0, fatigueScore = 30.0)
        assertTrue(TrainingPeriodizationEngine.vo2Eligible(eligible, zones))
        assertEquals("MIXED_INTERVAL_Z4_Z5", TrainingPeriodizationEngine.selectQualityKind(eligible, TrainingPeriodizationEngine.SPECIFIC, zones))
        val beginner = eligible.copy(level = "Iniciante")
        assertFalse(TrainingPeriodizationEngine.vo2Eligible(beginner, zones))
    }
}
