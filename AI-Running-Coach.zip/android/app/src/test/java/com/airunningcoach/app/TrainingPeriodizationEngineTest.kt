package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TrainingPeriodizationEngineTest {
    private fun input(goal: Double, level: String = "Intermediário", weekly: Double = 20.0, longest: Double = 10.0) = RunnerInput(
        goalKm = goal, level = level, frequency = 4, weeklyVolumeKm = weekly, longestRecentKm = longest,
        activeWeeksLast4 = 4, goalIntent = TrainingGoalIntent.PERSONAL_BEST,
        calibratedPaceZones = PaceCalculator.calculateCooper(2.4)
    )

    @Test fun `macrociclo separa base desenvolvimento especifico e recuperacao`() {
        assertEquals(TrainingPeriodizationEngine.BASE, TrainingPeriodizationEngine.phaseForWeek(1, 8, false))
        assertEquals(TrainingPeriodizationEngine.DEVELOPMENT, TrainingPeriodizationEngine.phaseForWeek(3, 8, false))
        assertEquals(TrainingPeriodizationEngine.SPECIFIC, TrainingPeriodizationEngine.phaseForWeek(7, 8, false))
        assertEquals(TrainingPeriodizationEngine.RECOVERY, TrainingPeriodizationEngine.phaseForWeek(4, 8, true))
    }

    @Test fun `5k para recorde usa fartlek tempo intervalado e especifico em fases diferentes`() {
        val runner = input(5.0, level = "Iniciante", weekly = 16.0, longest = 10.0).copy(frequency = 3)
        val zones = runner.calibratedPaceZones
        assertEquals("F01", TrainingPeriodizationEngine.selectProtocolCode(runner, TrainingPeriodizationEngine.BASE, zones, 2))
        assertEquals("F04", TrainingPeriodizationEngine.selectProtocolCode(runner, TrainingPeriodizationEngine.BASE, zones, 3))
        assertEquals("T01", TrainingPeriodizationEngine.selectProtocolCode(runner, TrainingPeriodizationEngine.DEVELOPMENT, zones, 5))
        assertEquals("I04", TrainingPeriodizationEngine.selectProtocolCode(runner, TrainingPeriodizationEngine.DEVELOPMENT, zones, 6))
        assertEquals("T04", TrainingPeriodizationEngine.selectProtocolCode(runner, TrainingPeriodizationEngine.DEVELOPMENT, zones, 7))
        assertEquals("RP05", TrainingPeriodizationEngine.selectProtocolCode(runner, TrainingPeriodizationEngine.SPECIFIC, zones, 9))
        assertEquals("FARTLEK", TrainingPeriodizationEngine.selectQualityKind(runner, TrainingPeriodizationEngine.BASE, zones, 2))
    }

    @Test fun `classificacao fisiologica nao bloqueia qualidade quando carga e recuperacao sustentam`() {
        val zones = PaceCalculator.calculateCooper(2.4)
        val beginner = input(5.0, "Iniciante", 16.0, 10.0).copy(frequency = 3, recoveryScore = 82.0, fatigueScore = 25.0)
        assertTrue(TrainingPeriodizationEngine.aerobicQualityEligible(beginner, zones))
        assertTrue(TrainingPeriodizationEngine.thresholdEligible(beginner, zones))
        assertFalse(TrainingPeriodizationEngine.vo2Eligible(beginner, zones))
    }

    @Test fun `vo2 de alta intensidade exige base maior e quatro dias`() {
        val zones = PaceCalculator.calculateCooper(2.6)
        val fit = input(5.0, "Iniciante", 28.0, 12.0).copy(frequency = 4, recoveryScore = 85.0, fatigueScore = 30.0)
        assertTrue(TrainingPeriodizationEngine.vo2Eligible(fit, zones))
        val lowerVolume = fit.copy(weeklyVolumeKm = 18.0)
        assertFalse(TrainingPeriodizationEngine.vo2Eligible(lowerVolume, zones))
    }

    @Test fun `objetivo saude nao libera sessao de qualidade`() {
        val zones = PaceCalculator.calculateCooper(2.4)
        val health = input(5.0, "Performance", 30.0, 12.0).copy(goalCategory = "HEALTH", goalIntent = TrainingGoalIntent.HEALTH)
        assertFalse(TrainingPeriodizationEngine.thresholdEligible(health, zones))
        assertFalse(TrainingPeriodizationEngine.vo2Eligible(health, zones))
        assertNull(TrainingPeriodizationEngine.selectProtocolCode(health, TrainingPeriodizationEngine.DEVELOPMENT, zones, 5))
    }

    @Test fun `consistencia desconhecida pode usar base declarada mas historico de zero a uma semana nao libera`() {
        val declared = input(10.0, "Iniciante", 16.0, 8.0).copy(
            activeWeeksLast4 = -1, recentActivityHistoryReliable = false, profileBaselineConfirmed = true
        )
        assertTrue(TrainingPeriodizationEngine.hasRecentConsistencyEvidence(declared))
        assertTrue(TrainingPeriodizationEngine.aerobicQualityEligible(declared, declared.calibratedPaceZones))
        assertFalse(TrainingPeriodizationEngine.hasRecentConsistencyEvidence(declared.copy(activeWeeksLast4 = 1)))
        assertFalse(TrainingPeriodizationEngine.hasRecentConsistencyEvidence(declared.copy(activeWeeksLast4 = 0)))
    }

    @Test fun `ciclo de recorde para 5 km usa estimulos distintos e semanas de descarga`() {
        val runner = input(5.0, level = "Iniciante", weekly = 16.0, longest = 10.0).copy(
            frequency = 3, recoveryScore = 82.0, fatigueScore = 25.0,
            activeWeeksLast4 = 3, recentActivityHistoryReliable = true,
            profileBaselineConfirmed = true
        )
        val zones = runner.calibratedPaceZones
        val protocols = listOf(2, 3, 5, 6, 7, 9, 10).mapNotNull { week ->
            val phase = when (week) {
                2, 3 -> TrainingPeriodizationEngine.BASE
                5, 6, 7 -> TrainingPeriodizationEngine.DEVELOPMENT
                else -> TrainingPeriodizationEngine.SPECIFIC
            }
            TrainingPeriodizationEngine.selectProtocolCode(runner, phase, zones, week)
        }
        assertTrue(protocols.containsAll(listOf("F01", "F04", "T01", "I04", "T04", "RP05", "I07")))
        assertEquals(7, protocols.distinct().size)
    }

    @Test fun `piramide fartlek fica reservada a quatro dias e elegibilidade VO2`() {
        val runner = input(5.0, level = "Performance", weekly = 28.0, longest = 12.0).copy(
            frequency = 4, recoveryScore = 85.0, fatigueScore = 25.0,
            activeWeeksLast4 = 4, recentActivityHistoryReliable = true
        )
        assertEquals("F03", TrainingPeriodizationEngine.selectProtocolCode(runner, TrainingPeriodizationEngine.SPECIFIC, runner.calibratedPaceZones, 10))
    }

    @Test fun `15km tem periodizacao de transicao propria e protocolo especifico do aplicativo`() {
        val runner = input(15.0, "Intermediário", 20.0, 10.0).copy(
            frequency = 4, recoveryScore = 82.0, fatigueScore = 25.0,
            activeWeeksLast4 = 4, recentActivityHistoryReliable = true
        )
        val code = TrainingPeriodizationEngine.selectProtocolCode(runner, TrainingPeriodizationEngine.SPECIFIC, runner.calibratedPaceZones, 9)
        assertEquals("RP15", code)
        assertEquals("EXPLICIT_INTERVAL", TrainingPeriodizationEngine.protocolKind(code))
        assertTrue(TrainingProtocolCatalog.find("RP15")!!.purpose.contains("transição"))
    }


    @Test fun `distancias principais selecionam protocolos especificos proprios`() {
        val runner = input(5.0, "Performance", 32.0, 14.0).copy(
            frequency = 4, recoveryScore = 85.0, fatigueScore = 25.0,
            activeWeeksLast4 = 4, recentActivityHistoryReliable = true,
            personalBestTimeSeconds = 1500, targetTimeSeconds = 1450
        )
        val expected = mapOf(
            5.0 to "RP05",
            10.0 to "RP10",
            15.0 to "RP15",
            21.1 to "RP21",
            42.2 to "T04"
        )
        expected.forEach { (distance, code) ->
            assertEquals(
                "Protocolo para $distance km",
                code,
                TrainingPeriodizationEngine.selectProtocolCode(
                    runner.copy(goalKm = distance), TrainingPeriodizationEngine.SPECIFIC,
                    runner.calibratedPaceZones, 9
                )
            )
        }
    }

    @Test fun `prioridade altera a selecao do estimulo especifico sem depender de FC`() {
        val runner = input(5.0, "Performance", 32.0, 14.0).copy(
            frequency = 4, recoveryScore = 85.0, fatigueScore = 25.0,
            activeWeeksLast4 = 4, recentActivityHistoryReliable = true,
            personalBestTimeSeconds = 1500, targetTimeSeconds = 1450
        )
        val zones = runner.calibratedPaceZones
        val complete = TrainingPeriodizationEngine.selectProtocolCode(
            runner.copy(goalIntent = TrainingGoalIntent.COMPLETE), TrainingPeriodizationEngine.SPECIFIC, zones, 9
        )
        val continuous = TrainingPeriodizationEngine.selectProtocolCode(
            runner.copy(goalIntent = TrainingGoalIntent.CONTINUOUS), TrainingPeriodizationEngine.SPECIFIC, zones, 9
        )
        val personalBest = TrainingPeriodizationEngine.selectProtocolCode(
            runner.copy(goalIntent = TrainingGoalIntent.PERSONAL_BEST), TrainingPeriodizationEngine.SPECIFIC, zones, 9
        )
        val targetTime = TrainingPeriodizationEngine.selectProtocolCode(
            runner.copy(goalIntent = TrainingGoalIntent.TARGET_TIME), TrainingPeriodizationEngine.SPECIFIC, zones, 9
        )
        assertEquals("F04", complete)
        assertEquals("CC01", continuous)
        assertEquals("RP05", personalBest)
        assertEquals("RP05", targetTime)
    }

    @Test fun `ausencia de zonas nao libera protocolo baseado em pace`() {
        val runner = input(5.0, "Performance", 24.0, 10.0).copy(calibratedPaceZones = null)
        assertNull(TrainingPeriodizationEngine.selectProtocolCode(runner, TrainingPeriodizationEngine.DEVELOPMENT, null, 5))
    }

    @Test fun `objetivos completar e continuo variam estimulo por distancia`() {
        val base = input(5.0, "Performance", 32.0, 14.0).copy(
            frequency = 4, recoveryScore = 85.0, fatigueScore = 25.0,
            activeWeeksLast4 = 4, recentActivityHistoryReliable = true
        )
        val fiveKm = TrainingPeriodizationEngine.selectProtocolCode(
            base.copy(goalIntent = TrainingGoalIntent.CONTINUOUS), TrainingPeriodizationEngine.SPECIFIC, base.calibratedPaceZones, 9
        )
        val tenKm = TrainingPeriodizationEngine.selectProtocolCode(
            base.copy(goalKm = 10.0, goalIntent = TrainingGoalIntent.CONTINUOUS), TrainingPeriodizationEngine.SPECIFIC, base.calibratedPaceZones, 9
        )
        val half = TrainingPeriodizationEngine.selectProtocolCode(
            base.copy(goalKm = 21.1, goalIntent = TrainingGoalIntent.COMPLETE), TrainingPeriodizationEngine.SPECIFIC, base.calibratedPaceZones, 9
        )
        assertEquals("CC01", fiveKm)
        assertEquals("F04", tenKm)
        assertEquals("T04", half)
    }

}
