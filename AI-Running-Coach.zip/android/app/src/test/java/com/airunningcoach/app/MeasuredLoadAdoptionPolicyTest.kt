package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.DayOfWeek
import java.time.LocalDate

class MeasuredLoadAdoptionPolicyTest {
    @Test fun `snapshot confirmado continua valido depois da virada de segunda-feira`() {
        val confirmedThrough = LocalDate.parse("2026-11-22") // domingo, fim das quatro semanas
        assertTrue(
            MeasuredLoadAdoptionPolicy.hasConfirmedSnapshot(
                confirmedThroughIso = confirmedThrough.toString(),
                weeklyKmText = "8.5",
                longestKmText = "6.6"
            )
        )
        // A janela móvel já teria avançado em 30/11; o snapshot confirmado continua válido.
        assertEquals(LocalDate.parse("2026-11-30"), MeasuredLoadAdoptionPolicy.nextBlockMonday(LocalDate.parse("2026-11-26")))
        assertEquals(LocalDate.parse("2026-12-07"), MeasuredLoadAdoptionPolicy.nextBlockMonday(LocalDate.parse("2026-11-30")))
    }

    @Test fun `snapshot incompleto ou com datas que nao encerram semana e recusado`() {
        assertFalse(MeasuredLoadAdoptionPolicy.hasConfirmedSnapshot("", "8.5", "6.6"))
        assertFalse(MeasuredLoadAdoptionPolicy.hasConfirmedSnapshot("2026-11-23", "8.5", "6.6")) // segunda
        assertFalse(MeasuredLoadAdoptionPolicy.hasConfirmedSnapshot("2026-11-22", "", "6.6"))
        assertFalse(MeasuredLoadAdoptionPolicy.hasConfirmedSnapshot("2026-11-22", "NaN", "6.6"))
        assertFalse(MeasuredLoadAdoptionPolicy.hasConfirmedSnapshot("2026-11-22", "8.5", "0"))
    }

    @Test fun `snapshot usa os valores confirmados e nao a janela movel`() {
        assertTrue(MeasuredLoadAdoptionPolicy.hasConfirmedSnapshot("2026-11-22", "8,5", "6,6"))
        assertEquals(DayOfWeek.MONDAY, MeasuredLoadAdoptionPolicy.nextBlockMonday(LocalDate.parse("2026-11-26")).dayOfWeek)
    }
}
