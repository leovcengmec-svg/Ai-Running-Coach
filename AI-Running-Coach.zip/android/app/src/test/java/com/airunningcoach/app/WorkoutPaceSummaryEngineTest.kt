package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class WorkoutPaceSummaryEngineTest {
    @Test fun `calcula media ponderada de todos os blocos por distancia`() {
        val segments = listOf(
            WorkoutSegment("Bloco 1", "", distanceKm = 2.0, targetMode = "DISTANCE", targetPaceMinValue = 350, targetPaceMaxValue = 370),
            WorkoutSegment("Bloco 2", "", distanceKm = 1.0, targetMode = "DISTANCE", targetPaceMinValue = 470, targetPaceMaxValue = 490)
        )
        // Midpoints: 360 s/km for 2 km and 480 s/km for 1 km => 400 s/km.
        assertEquals(400, WorkoutPaceSummaryEngine.plannedAveragePaceSecondsPerKm(segments))
    }

    @Test fun `pausa passiva nao entra na media`() {
        val segments = listOf(
            WorkoutSegment("Corrida", "", distanceKm = 1.0, targetMode = "DISTANCE", targetPaceMinValue = 350, targetPaceMaxValue = 370),
            WorkoutSegment("Pausa", "", durationMin = 2, targetMode = "TIME", recoveryMode = "PASSIVE")
        )
        assertEquals(360, WorkoutPaceSummaryEngine.plannedAveragePaceSecondsPerKm(segments))
    }

    @Test fun `sem blocos com ritmo nao inventa media`() {
        assertNull(WorkoutPaceSummaryEngine.plannedAveragePaceSecondsPerKm(emptyList()))
    }
}
