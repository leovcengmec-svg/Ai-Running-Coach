package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TalkTestCalibrationRulesTest {
    @Test fun `pace da fala pode ser salvo sem distancia ou tempo total`() {
        assertEquals("7:20", TalkTestCalibrationRules.normalizeEntry("Aeróbio", "07:20"))
        assertEquals("7:20", TalkTestCalibrationRules.normalizeEntry("Longo", "7:20"))
    }

    @Test fun `somente rodagem aerobia e longo alimentam teste da fala`() {
        assertTrue(TalkTestCalibrationRules.isEligibleWorkout("Aeróbio"))
        assertTrue(TalkTestCalibrationRules.isEligibleWorkout("Longão"))
        assertFalse(TalkTestCalibrationRules.isEligibleWorkout("Intervalado"))
        assertNull(TalkTestCalibrationRules.normalizeEntry("Intervalado", "5:00"))
    }

    @Test fun `observacao so calibra com esforco confortavel sensacao boa e sem dor`() {
        assertTrue(TalkTestCalibrationRules.canCalibrate("Leve", "Bem", false))
        assertFalse(TalkTestCalibrationRules.canCalibrate("Pesado", "Bem", false))
        assertFalse(TalkTestCalibrationRules.canCalibrate("Leve", "Cansado", false))
        assertFalse(TalkTestCalibrationRules.canCalibrate("Leve", "Bem", true))
    }

    @Test fun `pace invalido nao e persistido como observacao de fala`() {
        assertNull(TalkTestCalibrationRules.normalizeEntry("Aeróbio", "8:99"))
        assertNull(TalkTestCalibrationRules.normalizeEntry("Aeróbio", "abc"))
    }
}
