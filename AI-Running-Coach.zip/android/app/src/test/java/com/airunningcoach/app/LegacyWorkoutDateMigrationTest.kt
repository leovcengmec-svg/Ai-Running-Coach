package com.airunningcoach.app

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Test

class LegacyWorkoutDateMigrationTest {
    @Test fun `recovers Friday date from Portuguese legacy label`() {
        assertEquals(
            "2026-11-13",
            LegacyWorkoutDateMigration.resolve("Sexta-feira, 13/11", "2026-11-11", LocalDate.of(2026, 11, 15))
        )
    }

    @Test fun `moves January label to following year when plan began in December`() {
        assertEquals(
            "2027-01-08",
            LegacyWorkoutDateMigration.resolve("Sexta-feira, 08/01", "2026-12-28", LocalDate.of(2026, 12, 30))
        )
    }

    @Test fun `keeps explicit year`() {
        assertEquals(
            "2025-11-13",
            LegacyWorkoutDateMigration.resolve("13/11/2025", "2026-11-11", LocalDate.of(2026, 11, 15))
        )
    }
}
