package com.airunningcoach.app

import java.time.LocalDate
import kotlin.math.roundToInt
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AdaptiveZoneCalibrationEngineTest {
    private val testDate = LocalDate.of(2026, 11, 1)
    private val base = requireNotNull(PaceCalculator.calculateCooper(2.5))

    private fun observations(
        zone: String,
        reviewDate: LocalDate,
        improvements: List<Double> = List(5) { 3.5 }
    ): List<AdaptiveZoneObservation> {
        val range = requireNotNull(base.zone(zone)).range
        val midpoint = (range.fastestPaceValue + range.slowestPaceValue) / 2.0
        val offsets = listOf(8L, 10L, 12L, 14L, 16L)
        return improvements.mapIndexed { index, improvement ->
            AdaptiveZoneObservation(
                sessionId = "${zone.lowercase()}-session-${index / 2 + 1}",
                dateIso = reviewDate.minusDays(offsets[index]).toString(),
                zone = zone,
                actualPaceSecondsPerKm = (midpoint * (1.0 - improvement / 100.0)).roundToInt(),
                targetFastestPaceSecondsPerKm = range.fastestPaceValue,
                targetSlowestPaceSecondsPerKm = range.slowestPaceValue,
                effort = when (zone) {
                    "Z3" -> "Pesado"
                    "Z1" -> "Muito leve"
                    else -> "Leve"
                },
                feeling = "Bem",
                painPresent = false,
                workoutType = if (zone == "Z1") "Recuperação" else "Aeróbio"
            )
        }
    }

    @Test
    fun `nao revisa antes de completar 28 dias desde a referencia`() {
        val state = AdaptiveZoneCalibrationEngine.resetForValidTest(
            AdaptiveZoneCalibrationState(), testDate.toString()
        )
        val review = AdaptiveZoneCalibrationEngine.evaluate(
            base, emptyList(), state, testDate.plusDays(27), testDate.toString()
        )
        assertEquals(AdaptiveZoneCalibrationEngine.NOT_DUE, review.status)
        assertEquals(testDate.plusDays(28).toString(), review.nextReviewDateIso)
    }

    @Test
    fun `propoe ajustes por zona limitados a tres por revisao e preserva z4 z5`() {
        val state = AdaptiveZoneCalibrationEngine.resetForValidTest(
            AdaptiveZoneCalibrationState(), testDate.toString()
        )
        val reviewDate = testDate.plusDays(28)
        val rows = listOf("Z1", "Z2", "Z3").flatMap { observations(it, reviewDate) }
        val review = AdaptiveZoneCalibrationEngine.evaluate(base, rows, state, reviewDate, testDate.toString())

        assertEquals(AdaptiveZoneCalibrationEngine.READY, review.status)
        assertEquals(setOf("Z1", "Z2", "Z3"), review.proposals.map { it.zone }.toSet())
        assertTrue(review.proposals.all { it.appliedChangePercent in 2.0..3.0 })
        val accepted = AdaptiveZoneCalibrationEngine.acceptReview(state, review)
        assertTrue(accepted.cumulativePercentByZone.values.all { it <= 3.0 })

        val adapted = AdaptiveZoneCalibrationEngine.apply(base, accepted)
        assertEquals(base.z4.range, adapted.z4.range)
        assertEquals(base.z5.range, adapted.z5.range)
        val boundaries = ZoneCalibrationEngine.boundaryValues(adapted)
        assertTrue(boundaries.zipWithNext().all { (first, second) -> first < second })
    }

    @Test
    fun `cada zona exige e recebe sua propria evidencia`() {
        val state = AdaptiveZoneCalibrationEngine.resetForValidTest(
            AdaptiveZoneCalibrationState(), testDate.toString()
        )
        val reviewDate = testDate.plusDays(28)
        val review = AdaptiveZoneCalibrationEngine.evaluate(
            base, observations("Z1", reviewDate), state, reviewDate, testDate.toString()
        )
        assertEquals(AdaptiveZoneCalibrationEngine.READY, review.status)
        assertEquals(listOf("Z1"), review.proposals.map { it.zone })
        assertEquals(0, review.evidenceCounts["Z2"])
        assertTrue(review.explanations["Z2"].orEmpty().contains("Evidência insuficiente"))
        assertTrue(review.explanations["Z3"].orEmpty().contains("Evidência insuficiente"))
    }

    @Test
    fun `exige melhora mediana minima de dois por cento`() {
        val state = AdaptiveZoneCalibrationEngine.resetForValidTest(
            AdaptiveZoneCalibrationState(), testDate.toString()
        )
        val reviewDate = testDate.plusDays(28)
        val below = listOf("Z1", "Z2", "Z3").flatMap { observations(it, reviewDate, List(5) { 1.9 }) }
        val belowReview = AdaptiveZoneCalibrationEngine.evaluate(base, below, state, reviewDate, testDate.toString())
        assertTrue(belowReview.proposals.isEmpty())
        assertEquals(AdaptiveZoneCalibrationEngine.NO_CHANGE, belowReview.status)
        assertTrue(belowReview.explanations.values.all { it.contains("abaixo do mínimo de 2%") })

        val above = listOf("Z1", "Z2", "Z3").flatMap { observations(it, reviewDate, List(5) { 2.5 }) }
        val aboveReview = AdaptiveZoneCalibrationEngine.evaluate(base, above, state, reviewDate, testDate.toString())
        assertEquals(AdaptiveZoneCalibrationEngine.READY, aboveReview.status)
        assertTrue(aboveReview.proposals.all { it.appliedChangePercent >= 2.0 })
    }

    @Test
    fun `limite acumulado de cinco por cento exige novo teste valido`() {
        var state = AdaptiveZoneCalibrationEngine.resetForValidTest(
            AdaptiveZoneCalibrationState(), testDate.toString()
        )
        val firstDate = testDate.plusDays(28)
        val first = AdaptiveZoneCalibrationEngine.evaluate(
            base, listOf("Z1", "Z2", "Z3").flatMap { observations(it, firstDate, List(5) { 4.0 }) },
            state, firstDate, testDate.toString()
        )
        state = AdaptiveZoneCalibrationEngine.acceptReview(state, first)
        assertTrue(state.cumulativePercentByZone.values.all { it == 3.0 })

        val secondDate = firstDate.plusDays(28)
        val second = AdaptiveZoneCalibrationEngine.evaluate(
            base, listOf("Z1", "Z2", "Z3").flatMap { observations(it, secondDate, List(5) { 4.5 }) },
            state, secondDate, testDate.toString()
        )
        assertEquals(AdaptiveZoneCalibrationEngine.READY, second.status)
        assertTrue(second.proposals.all { it.appliedChangePercent == 2.0 && it.sourceContributionAfterPercent == 5.0 })
        assertEquals(5.0, second.proposals.single { it.zone == "Z3" }.cumulativeAfterPercent, 0.001)
        assertEquals(10.0, second.proposals.single { it.zone == "Z2" }.cumulativeAfterPercent, 0.001)
        assertEquals(15.0, second.proposals.single { it.zone == "Z1" }.cumulativeAfterPercent, 0.001)
        state = AdaptiveZoneCalibrationEngine.acceptReview(state, second)

        val thirdDate = secondDate.plusDays(28)
        val third = AdaptiveZoneCalibrationEngine.evaluate(
            base, listOf("Z1", "Z2", "Z3").flatMap { observations(it, thirdDate, List(5) { 4.5 }) },
            state, thirdDate, testDate.toString()
        )
        assertEquals(AdaptiveZoneCalibrationEngine.LIMIT_REACHED, third.status)
        assertTrue(third.proposals.isEmpty())
        assertEquals(5.0, AdaptiveZoneCalibrationEngine.sourceContributionPercent(state, "Z1"), 0.001)
        assertEquals(5.0, AdaptiveZoneCalibrationEngine.sourceContributionPercent(state, "Z2"), 0.001)
        assertEquals(5.0, AdaptiveZoneCalibrationEngine.sourceContributionPercent(state, "Z3"), 0.001)
        assertEquals(15.0, AdaptiveZoneCalibrationEngine.cumulativePercent(state, "Z1"), 0.001)
        assertEquals(10.0, AdaptiveZoneCalibrationEngine.cumulativePercent(state, "Z2"), 0.001)
        assertEquals(5.0, AdaptiveZoneCalibrationEngine.cumulativePercent(state, "Z3"), 0.001)

        val reset = AdaptiveZoneCalibrationEngine.resetForValidTest(state, testDate.toString(), forceNewTest = true)
        assertTrue(reset.cumulativePercentByZone.values.all { it == 0.0 })
        assertEquals(testDate.toString(), reset.referenceTestDateIso)
    }

    @Test
    fun `saldo acumulado inferior a dois por cento nao gera ajuste pequeno artificial`() {
        val state = AdaptiveZoneCalibrationState(
            referenceTestDateIso = testDate.toString(),
            lastReviewDateIso = testDate.plusDays(28).toString(),
            cumulativePercentByZone = mapOf("Z1" to 4.5, "Z2" to 4.5, "Z3" to 4.5)
        )
        val reviewDate = testDate.plusDays(56)
        val rows = listOf("Z1", "Z2", "Z3").flatMap { observations(it, reviewDate, List(5) { 4.0 }) }
        val review = AdaptiveZoneCalibrationEngine.evaluate(base, rows, state, reviewDate, testDate.toString())
        assertEquals(AdaptiveZoneCalibrationEngine.LIMIT_REACHED, review.status)
        assertTrue(review.proposals.isEmpty())
        assertTrue(review.explanations.values.all { it.contains("inferior ao mínimo de 2%") })
    }

    @Test
    fun `calibracao em cascata propaga Z3 para Z2 e Z1 e Z2 para Z1`() {
        val z3Only = AdaptiveZoneCalibrationState(
            referenceTestDateIso = testDate.toString(),
            cumulativePercentByZone = mapOf("Z3" to 5.0)
        )
        val baseBoundaries = ZoneCalibrationEngine.boundaryValues(base)
        val z3Boundaries = ZoneCalibrationEngine.boundaryValues(AdaptiveZoneCalibrationEngine.apply(base, z3Only))
        assertEquals(5.0, AdaptiveZoneCalibrationEngine.cumulativePercent(z3Only, "Z3"), 0.001)
        assertEquals(5.0, AdaptiveZoneCalibrationEngine.cumulativePercent(z3Only, "Z2"), 0.001)
        assertEquals(5.0, AdaptiveZoneCalibrationEngine.cumulativePercent(z3Only, "Z1"), 0.001)
        for (index in 3..5) assertTrue(z3Boundaries[index] < baseBoundaries[index])

        val z2Also = z3Only.copy(cumulativePercentByZone = mapOf("Z3" to 5.0, "Z2" to 5.0))
        val z2Boundaries = ZoneCalibrationEngine.boundaryValues(AdaptiveZoneCalibrationEngine.apply(base, z2Also))
        assertEquals(5.0, AdaptiveZoneCalibrationEngine.cumulativePercent(z2Also, "Z3"), 0.001)
        assertEquals(10.0, AdaptiveZoneCalibrationEngine.cumulativePercent(z2Also, "Z2"), 0.001)
        assertEquals(10.0, AdaptiveZoneCalibrationEngine.cumulativePercent(z2Also, "Z1"), 0.001)
        assertEquals(z3Boundaries[3], z2Boundaries[3])
        assertTrue(z2Boundaries[4] < z3Boundaries[4])
        assertTrue(z2Boundaries[5] < z3Boundaries[5])

        val allZones = z2Also.copy(cumulativePercentByZone = mapOf("Z3" to 5.0, "Z2" to 5.0, "Z1" to 5.0))
        val allBoundaries = ZoneCalibrationEngine.boundaryValues(AdaptiveZoneCalibrationEngine.apply(base, allZones))
        assertEquals(15.0, AdaptiveZoneCalibrationEngine.cumulativePercent(allZones, "Z1"), 0.001)
        assertEquals(10.0, AdaptiveZoneCalibrationEngine.cumulativePercent(allZones, "Z2"), 0.001)
        assertEquals(5.0, AdaptiveZoneCalibrationEngine.cumulativePercent(allZones, "Z3"), 0.001)
        assertEquals(z2Boundaries[4], allBoundaries[4])
        assertTrue(allBoundaries[5] < z2Boundaries[5])
        assertEquals(base.z4.range, AdaptiveZoneCalibrationEngine.apply(base, allZones).z4.range)
        assertEquals(base.z5.range, AdaptiveZoneCalibrationEngine.apply(base, allZones).z5.range)
    }

    @Test
    fun `bloqueia proposta que comprime faixa abaixo da largura minima`() {
        val narrowZ1 = base.z1.copy(
            range = PaceRange(base.z2.range.slowestPaceValue, base.z2.range.slowestPaceValue + 10)
        )
        val narrowBase = base.copy(z1 = narrowZ1)
        val state = AdaptiveZoneCalibrationEngine.resetForValidTest(
            AdaptiveZoneCalibrationState(), testDate.toString()
        )
        val reviewDate = testDate.plusDays(28)
        val review = AdaptiveZoneCalibrationEngine.evaluate(
            narrowBase, observations("Z1", reviewDate), state, reviewDate, testDate.toString()
        )
        assertEquals(AdaptiveZoneCalibrationEngine.BLOCKED, review.status)
        assertTrue(review.proposals.isEmpty())
        assertTrue(review.explanations["Z1"].orEmpty().contains("largura mínima de 10 segundos"))
    }

    @Test
    fun `reteste preferencial e calculado para oito semanas`() {
        assertEquals(testDate.plusDays(49), AdaptiveZoneCalibrationEngine.retestWindowStartDate(testDate.toString()))
        assertEquals(testDate.plusDays(56), AdaptiveZoneCalibrationEngine.retestDueDate(testDate.toString()))
        assertNull(AdaptiveZoneCalibrationEngine.retestDueDate(null))
    }
}
