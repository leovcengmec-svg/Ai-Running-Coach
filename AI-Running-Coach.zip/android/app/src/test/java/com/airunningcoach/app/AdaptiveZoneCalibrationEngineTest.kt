package com.airunningcoach.app

import java.time.LocalDate
import kotlin.math.roundToInt
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AdaptiveZoneCalibrationEngineTest {
    private val testDate = LocalDate.of(2026, 11, 1)
    private val base = requireNotNull(PaceCalculator.calculateCooper(2.5))

    private fun observations(
        zone: String,
        reviewDate: LocalDate,
        improvements: List<Double> = List(5) { 3.5 }
    ): List<AdaptiveZoneObservation> {
        val range = requireNotNull(base.zone(zone)).range
        val midpoint = (range.fastestPaceValue + range.slowestPaceValue) / 2.0
        val offsets = listOf(8L, 10L, 12L, 14L, 16L)
        return improvements.mapIndexed { index, improvement ->
            AdaptiveZoneObservation(
                sessionId = "${zone.lowercase()}-session-${index / 2 + 1}",
                dateIso = reviewDate.minusDays(offsets[index / 2 + 1]).toString(),
                zone = zone,
                actualPaceSecondsPerKm = (midpoint * (1.0 - improvement / 100.0)).roundToInt(),
                targetFastestPaceSecondsPerKm = range.fastestPaceValue,
                targetSlowestPaceSecondsPerKm = range.slowestPaceValue,
                effort = when (zone) {
                    "Z3" -> "Pesado"
                    "Z1" -> "Muito leve"
                    else -> "Leve"
                },
                feeling = "Bem",
                painPresent = false,
                workoutType = if (zone == "Z1") "Recuperação" else "Aeróbio",
                blockId = "${zone.lowercase()}-block-$index"
            )
        }
    }

    @Test
    fun `nao revisa antes de completar 28 dias desde a referencia`() {
        val state = AdaptiveZoneCalibrationEngine.resetForValidTest(
            AdaptiveZoneCalibrationState(), testDate.toString()
        )
        val review = AdaptiveZoneCalibrationEngine.evaluate(
            base, emptyList(), state, testDate.plusDays(27), testDate.toString()
        )
        assertEquals(AdaptiveZoneCalibrationEngine.NOT_DUE, review.status)
        assertEquals(testDate.plusDays(28).toString(), review.nextReviewDateIso)
    }

    @Test
    fun `propoe ajustes por zona limitados a tres por revisao e preserva z4 z5`() {
        val state = AdaptiveZoneCalibrationEngine.resetForValidTest(
            AdaptiveZoneCalibrationState(), testDate.toString()
        )
        val reviewDate = testDate.plusDays(28)
        val rows = listOf("Z1", "Z2", "Z3").flatMap { observations(it, reviewDate) }
        val review = AdaptiveZoneCalibrationEngine.evaluate(base, rows, state, reviewDate, testDate.toString())

        assertEquals(AdaptiveZoneCalibrationEngine.READY, review.status)
        assertEquals(setOf("Z1", "Z2", "Z3"), review.proposals.map { it.zone }.toSet())
        assertTrue(review.proposals.all { it.appliedChangePercent in 2.0..3.0 })
        val accepted = AdaptiveZoneCalibrationEngine.acceptReview(state, review)
        assertTrue(accepted.cumulativePercentByZone.values.all { it <= 3.0 })

        val adapted = AdaptiveZoneCalibrationEngine.apply(base, accepted)
        assertEquals(base.z4.range, adapted.z4.range)
        assertEquals(base.z5.range, adapted.z5.range)
        val boundaries = ZoneCalibrationEngine.boundaryValues(adapted)
        assertTrue(boundaries.zipWithNext().all { (first, second) -> first < second })
    }

    @Test
    fun `cada zona exige e recebe sua propria evidencia`() {
        val state = AdaptiveZoneCalibrationEngine.resetForValidTest(
            AdaptiveZoneCalibrationState(), testDate.toString()
        )
        val reviewDate = testDate.plusDays(28)
        val review = AdaptiveZoneCalibrationEngine.evaluate(
            base, observations("Z1", reviewDate), state, reviewDate, testDate.toString()
        )
        assertEquals(AdaptiveZoneCalibrationEngine.READY, review.status)
        assertEquals(listOf("Z1"), review.proposals.map { it.zone })
        assertEquals(0, review.evidenceCounts["Z2"])
        assertTrue(review.explanations["Z2"].orEmpty().contains("Lote A incompleto: 0/5"))
        assertTrue(review.explanations["Z3"].orEmpty().contains("Lote A incompleto: 0/5"))
    }


    @Test
    fun `lote B e liberado assim que completar evidencias sem esperar mais 28 dias`() {
        val acceptedDate = testDate.plusDays(28)
        val state = AdaptiveZoneCalibrationState(
            referenceTestDateIso = testDate.toString(),
            lastReviewDateIso = acceptedDate.toString(),
            cumulativePercentByZone = mapOf("Z1" to 0.0, "Z2" to 3.0, "Z3" to 0.0),
            history = listOf(
                AdaptiveZoneCalibrationAudit(
                    dateIso = acceptedDate.toString(), testReferenceDateIso = testDate.toString(),
                    zone = "Z2", previousRange = "old", newRange = "new", estimatedImprovementPercent = 3.5,
                    appliedChangePercent = 3.0, cumulativeChangePercent = 3.0, evidenceCount = 5,
                    sessionCount = 3, sourceContributionPercent = 3.0
                )
            )
        )
        val rows = (0 until 3).flatMap { session ->
            val date = acceptedDate.plusDays((session + 1).toLong())
            (0 until 2).map { block ->
                val range = requireNotNull(base.zone("Z2")).range
                val midpoint = (range.fastestPaceValue + range.slowestPaceValue) / 2.0
                AdaptiveZoneObservation(
                    sessionId = "lot-b-session-$session", dateIso = date.toString(), zone = "Z2",
                    actualPaceSecondsPerKm = (midpoint * 0.96).roundToInt(),
                    targetFastestPaceSecondsPerKm = range.fastestPaceValue,
                    targetSlowestPaceSecondsPerKm = range.slowestPaceValue,
                    effort = "Leve", feeling = "Bem", painPresent = false, workoutType = "Aeróbio",
                    blockId = "lot-b-$session-$block"
                )
            }
        }
        val today = acceptedDate.plusDays(4) // 24 days before the 28-day periodic review.
        val review = AdaptiveZoneCalibrationEngine.evaluate(base, rows, state, today, testDate.toString())
        assertEquals(AdaptiveZoneCalibrationEngine.READY, review.status)
        val proposal = review.proposals.single()
        assertEquals("Z2", proposal.zone)
        assertEquals(2.0, proposal.appliedChangePercent, 0.001)
        assertEquals(5, proposal.evidenceCount)
        assertEquals(3, proposal.sessionCount)
        val accepted = AdaptiveZoneCalibrationEngine.acceptReview(state, review)
        assertEquals(5.0, AdaptiveZoneCalibrationEngine.sourceContributionPercent(accepted, "Z2"), 0.001)
        assertEquals(5, accepted.consumedEvidenceKeysByZone["Z2"]?.size)
    }

    @Test
    fun `atividade reimportada nao vira tres sessoes apenas porque recebeu novos ids de feedback`() {
        val state = AdaptiveZoneCalibrationEngine.resetForValidTest(
            AdaptiveZoneCalibrationState(), testDate.toString()
        )
        val reviewDate = testDate.plusDays(28)
        val rows = observations("Z2", reviewDate).mapIndexed { index, row ->
            row.copy(
                sessionId = "feedback-recriado-$index",
                activityFingerprint = "sha256-atividade-original",
                blockId = "bloco-recriado-$index"
            )
        }
        val review = AdaptiveZoneCalibrationEngine.evaluate(base, rows, state, reviewDate, testDate.toString())
        assertEquals(AdaptiveZoneCalibrationEngine.INSUFFICIENT, review.status)
        assertEquals(1, review.lotProgressByZone["Z2"]?.lotASessionsAvailable)
        assertTrue(review.proposals.isEmpty())
    }

    @Test
    fun `estado legado V103 libera lote B antes de 21 de dezembro e ignora evidencias anteriores a 23 de novembro`() {
        val testReference = LocalDate.of(2026, 10, 11)
        val acceptedDate = LocalDate.of(2026, 11, 23)
        val today = LocalDate.of(2026, 11, 27)
        val state = AdaptiveZoneCalibrationState(
            referenceTestDateIso = testReference.toString(),
            lastReviewDateIso = acceptedDate.toString(),
            cumulativePercentByZone = mapOf("Z1" to 0.0, "Z2" to 3.0, "Z3" to 0.0),
            history = listOf(
                AdaptiveZoneCalibrationAudit(
                    dateIso = acceptedDate.toString(), testReferenceDateIso = testReference.toString(),
                    zone = "Z2", previousRange = "old", newRange = "new", estimatedImprovementPercent = 5.9,
                    appliedChangePercent = 3.0, cumulativeChangePercent = 3.0, evidenceCount = 15,
                    sessionCount = 5, sourceContributionPercent = 3.0
                )
            )
        )
        val range = requireNotNull(base.zone("Z2")).range
        val midpoint = (range.fastestPaceValue + range.slowestPaceValue) / 2.0
        val dates = listOf(
            LocalDate.of(2026, 11, 20), LocalDate.of(2026, 11, 21), LocalDate.of(2026, 11, 22),
            LocalDate.of(2026, 11, 24), LocalDate.of(2026, 11, 25), LocalDate.of(2026, 11, 26)
        )
        val rows = dates.flatMapIndexed { session, date -> (0 until 2).map { block ->
            AdaptiveZoneObservation(
                sessionId = "legacy-recovery-$session", dateIso = date.toString(), zone = "Z2",
                actualPaceSecondsPerKm = (midpoint * 0.96).roundToInt(),
                targetFastestPaceSecondsPerKm = range.fastestPaceValue,
                targetSlowestPaceSecondsPerKm = range.slowestPaceValue,
                effort = "Leve", feeling = "Bem", painPresent = false, workoutType = "Aeróbio",
                blockId = "legacy-b-$session-$block"
            )
        } }
        val review = AdaptiveZoneCalibrationEngine.evaluate(base, rows, state, today, testReference.toString())
        assertEquals(AdaptiveZoneCalibrationEngine.READY, review.status)
        val proposal = review.proposals.single()
        assertEquals("Z2", proposal.zone)
        assertEquals(2.0, proposal.appliedChangePercent, 0.001)
        assertEquals(5, proposal.evidenceCount)
        assertTrue(proposal.evidenceKeys.none { it.contains("legacy-recovery-0") || it.contains("legacy-recovery-1") || it.contains("legacy-recovery-2") })
    }

    @Test
    fun `evidencias do lote A sao consumidas e nao podem ser reutilizadas no lote B`() {
        val state = AdaptiveZoneCalibrationEngine.resetForValidTest(AdaptiveZoneCalibrationState(), testDate.toString())
        val reviewDate = testDate.plusDays(28)
        val rows = observations("Z2", reviewDate)
        val first = AdaptiveZoneCalibrationEngine.evaluate(base, rows, state, reviewDate, testDate.toString())
        assertEquals(AdaptiveZoneCalibrationEngine.READY, first.status)
        val accepted = AdaptiveZoneCalibrationEngine.acceptReview(state, first)
        assertEquals(5, accepted.consumedEvidenceKeysByZone["Z2"]?.size)
        val repeated = AdaptiveZoneCalibrationEngine.evaluate(
            base, rows, accepted, reviewDate.plusDays(1), testDate.toString()
        )
        assertEquals(AdaptiveZoneCalibrationEngine.NOT_DUE, repeated.status)
        assertEquals(0, repeated.lotProgressByZone["Z2"]?.lotBBlocksAvailable)
        assertTrue(repeated.explanations["Z2"].orEmpty().contains("Lote B em andamento"))
    }

    @Test
    fun `lotes proprios das tres zonas permanecem independentes incluindo Z1`() {
        val state = AdaptiveZoneCalibrationEngine.resetForValidTest(AdaptiveZoneCalibrationState(), testDate.toString())
        val reviewDate = testDate.plusDays(28)
        val z1Only = AdaptiveZoneCalibrationEngine.evaluate(
            base, observations("Z1", reviewDate), state, reviewDate, testDate.toString()
        )
        assertEquals(AdaptiveZoneCalibrationEngine.READY, z1Only.status)
        assertEquals(listOf("Z1"), z1Only.proposals.map { it.zone })
        val accepted = AdaptiveZoneCalibrationEngine.acceptReview(state, z1Only)
        assertEquals(3.0, AdaptiveZoneCalibrationEngine.sourceContributionPercent(accepted, "Z1"), 0.001)
        assertEquals(0.0, AdaptiveZoneCalibrationEngine.sourceContributionPercent(accepted, "Z2"), 0.001)
        assertEquals(0.0, AdaptiveZoneCalibrationEngine.sourceContributionPercent(accepted, "Z3"), 0.001)
        assertEquals(3.0, AdaptiveZoneCalibrationEngine.cumulativePercent(accepted, "Z1"), 0.001)
    }

    @Test
    fun `lote proprio de Z1 mantem lote B e pode completar cinco por cento antes da revisao periodica`() {
        val acceptedDate = testDate.plusDays(28)
        val state = AdaptiveZoneCalibrationState(
            referenceTestDateIso = testDate.toString(),
            lastReviewDateIso = acceptedDate.toString(),
            cumulativePercentByZone = mapOf("Z1" to 3.0, "Z2" to 0.0, "Z3" to 0.0),
            history = listOf(
                AdaptiveZoneCalibrationAudit(
                    dateIso = acceptedDate.toString(), testReferenceDateIso = testDate.toString(),
                    zone = "Z1", previousRange = "old", newRange = "new", estimatedImprovementPercent = 3.5,
                    appliedChangePercent = 3.0, cumulativeChangePercent = 3.0, evidenceCount = 5,
                    sessionCount = 3, sourceContributionPercent = 3.0
                )
            )
        )
        val rows = observations("Z1", acceptedDate.plusDays(4)).mapIndexed { index, row ->
            row.copy(
                dateIso = acceptedDate.plusDays(index / 2 + 1L).toString(),
                sessionId = "z1-lot-b-session-${index / 2 + 1}",
                blockId = "z1-lot-b-$index",
                workoutType = "Recuperação",
                effort = "Muito leve"
            )
        }
        val today = acceptedDate.plusDays(4)
        val review = AdaptiveZoneCalibrationEngine.evaluate(base, rows, state, today, testDate.toString())
        assertEquals(AdaptiveZoneCalibrationEngine.READY, review.status)
        assertEquals(listOf("Z1"), review.proposals.map { it.zone })
        assertEquals(2.0, review.proposals.single().appliedChangePercent, 0.001)
        val accepted = AdaptiveZoneCalibrationEngine.acceptReview(state, review)
        assertEquals(5.0, AdaptiveZoneCalibrationEngine.sourceContributionPercent(accepted, "Z1"), 0.001)
        assertEquals(5.0, AdaptiveZoneCalibrationEngine.cumulativePercent(accepted, "Z1"), 0.001)
    }

    @Test
    fun `reteste vencido e identificado e agenda futura prevalece sobre a data historica`() {
        val currentDate = LocalDate.of(2026, 11, 27)
        val overdue = AdaptiveZoneCalibrationEngine.retestPresentation("2026-10-11", currentDate)
        assertEquals("OVERDUE", overdue.status)
        assertEquals("2026-11-09", overdue.displayDateIso)
        assertEquals(18L, overdue.overdueDays)
        val scheduled = AdaptiveZoneCalibrationEngine.retestPresentation("2026-10-11", currentDate, "2026-12-07")
        assertEquals("SCHEDULED", scheduled.status)
        assertEquals("2026-12-07", scheduled.displayDateIso)
        assertEquals("2026-11-09", scheduled.initialOpportunityDateIso)
    }

    @Test
    fun `dispensar revisao insuficiente nao posterga a proxima verificacao`() {
        val state = AdaptiveZoneCalibrationEngine.resetForValidTest(AdaptiveZoneCalibrationState(), testDate.toString())
        val reviewDate = testDate.plusDays(28)
        val review = AdaptiveZoneCalibrationEngine.evaluate(base, emptyList(), state, reviewDate, testDate.toString())
        val dismissed = AdaptiveZoneCalibrationEngine.dismissReview(state, review)
        assertEquals(state.lastReviewDateIso, dismissed.lastReviewDateIso)
    }

    @Test
    fun `exige melhora mediana minima de dois por cento`() {
        val state = AdaptiveZoneCalibrationEngine.resetForValidTest(
            AdaptiveZoneCalibrationState(), testDate.toString()
        )
        val reviewDate = testDate.plusDays(28)
        val below = listOf("Z1", "Z2", "Z3").flatMap { observations(it, reviewDate, List(5) { 1.9 }) }
        val belowReview = AdaptiveZoneCalibrationEngine.evaluate(base, below, state, reviewDate, testDate.toString())
        assertTrue(belowReview.proposals.isEmpty())
        assertEquals(AdaptiveZoneCalibrationEngine.NO_CHANGE, belowReview.status)
        assertTrue(belowReview.explanations.values.all { it.contains("abaixo do mínimo de 2%") })

        val above = listOf("Z1", "Z2", "Z3").flatMap { observations(it, reviewDate, List(5) { 2.5 }) }
        val aboveReview = AdaptiveZoneCalibrationEngine.evaluate(base, above, state, reviewDate, testDate.toString())
        assertEquals(AdaptiveZoneCalibrationEngine.READY, aboveReview.status)
        assertTrue(aboveReview.proposals.all { it.appliedChangePercent >= 2.0 })
    }

    @Test
    fun `limite acumulado de cinco por cento exige novo teste valido`() {
        var state = AdaptiveZoneCalibrationEngine.resetForValidTest(
            AdaptiveZoneCalibrationState(), testDate.toString()
        )
        val firstDate = testDate.plusDays(28)
        val first = AdaptiveZoneCalibrationEngine.evaluate(
            base, listOf("Z1", "Z2", "Z3").flatMap { observations(it, firstDate, List(5) { 4.0 }) },
            state, firstDate, testDate.toString()
        )
        state = AdaptiveZoneCalibrationEngine.acceptReview(state, first)
        assertTrue(state.cumulativePercentByZone.values.all { it == 3.0 })

        val secondDate = firstDate.plusDays(28)
        val second = AdaptiveZoneCalibrationEngine.evaluate(
            base, listOf("Z1", "Z2", "Z3").flatMap { observations(it, secondDate, List(5) { 4.5 }) },
            state, secondDate, testDate.toString()
        )
        assertEquals(AdaptiveZoneCalibrationEngine.READY, second.status)
        assertTrue(second.proposals.all { it.appliedChangePercent == 2.0 && it.sourceContributionAfterPercent == 5.0 })
        assertEquals(5.0, second.proposals.single { it.zone == "Z3" }.cumulativeAfterPercent, 0.001)
        assertEquals(10.0, second.proposals.single { it.zone == "Z2" }.cumulativeAfterPercent, 0.001)
        assertEquals(15.0, second.proposals.single { it.zone == "Z1" }.cumulativeAfterPercent, 0.001)
        state = AdaptiveZoneCalibrationEngine.acceptReview(state, second)

        val thirdDate = secondDate.plusDays(28)
        val third = AdaptiveZoneCalibrationEngine.evaluate(
            base, listOf("Z1", "Z2", "Z3").flatMap { observations(it, thirdDate, List(5) { 4.5 }) },
            state, thirdDate, testDate.toString()
        )
        assertEquals(AdaptiveZoneCalibrationEngine.LIMIT_REACHED, third.status)
        assertTrue(third.proposals.isEmpty())
        assertEquals(5.0, AdaptiveZoneCalibrationEngine.sourceContributionPercent(state, "Z1"), 0.001)
        assertEquals(5.0, AdaptiveZoneCalibrationEngine.sourceContributionPercent(state, "Z2"), 0.001)
        assertEquals(5.0, AdaptiveZoneCalibrationEngine.sourceContributionPercent(state, "Z3"), 0.001)
        assertEquals(15.0, AdaptiveZoneCalibrationEngine.cumulativePercent(state, "Z1"), 0.001)
        assertEquals(10.0, AdaptiveZoneCalibrationEngine.cumulativePercent(state, "Z2"), 0.001)
        assertEquals(5.0, AdaptiveZoneCalibrationEngine.cumulativePercent(state, "Z3"), 0.001)

        val synchronized = AdaptiveZoneCalibrationEngine.resetForValidTest(state, testDate.toString(), forceNewTest = true)
        assertEquals(state.cumulativePercentByZone, synchronized.cumulativePercentByZone)
        assertEquals(testDate.toString(), synchronized.referenceTestDateIso)
    }

    @Test
    fun `saldo acumulado inferior a dois por cento nao gera ajuste pequeno artificial`() {
        val state = AdaptiveZoneCalibrationState(
            referenceTestDateIso = testDate.toString(),
            lastReviewDateIso = testDate.plusDays(28).toString(),
            cumulativePercentByZone = mapOf("Z1" to 4.5, "Z2" to 4.5, "Z3" to 4.5)
        )
        val reviewDate = testDate.plusDays(56)
        val rows = listOf("Z1", "Z2", "Z3").flatMap { observations(it, reviewDate, List(5) { 4.0 }) }
        val review = AdaptiveZoneCalibrationEngine.evaluate(base, rows, state, reviewDate, testDate.toString())
        assertEquals(AdaptiveZoneCalibrationEngine.LIMIT_REACHED, review.status)
        assertTrue(review.proposals.isEmpty())
        assertTrue(review.explanations.values.all { it.contains("inferior ao mínimo de 2%") })
    }

    @Test
    fun `calibracao em cascata propaga Z3 para Z2 e Z1 e Z2 para Z1`() {
        val z3Only = AdaptiveZoneCalibrationState(
            referenceTestDateIso = testDate.toString(),
            cumulativePercentByZone = mapOf("Z3" to 5.0)
        )
        val baseBoundaries = ZoneCalibrationEngine.boundaryValues(base)
        val z3Boundaries = ZoneCalibrationEngine.boundaryValues(AdaptiveZoneCalibrationEngine.apply(base, z3Only))
        assertEquals(5.0, AdaptiveZoneCalibrationEngine.cumulativePercent(z3Only, "Z3"), 0.001)
        assertEquals(5.0, AdaptiveZoneCalibrationEngine.cumulativePercent(z3Only, "Z2"), 0.001)
        assertEquals(5.0, AdaptiveZoneCalibrationEngine.cumulativePercent(z3Only, "Z1"), 0.001)
        for (index in 3..5) assertTrue(z3Boundaries[index] < baseBoundaries[index])

        val z2Also = z3Only.copy(cumulativePercentByZone = mapOf("Z3" to 5.0, "Z2" to 5.0))
        val z2Boundaries = ZoneCalibrationEngine.boundaryValues(AdaptiveZoneCalibrationEngine.apply(base, z2Also))
        assertEquals(5.0, AdaptiveZoneCalibrationEngine.cumulativePercent(z2Also, "Z3"), 0.001)
        assertEquals(10.0, AdaptiveZoneCalibrationEngine.cumulativePercent(z2Also, "Z2"), 0.001)
        assertEquals(10.0, AdaptiveZoneCalibrationEngine.cumulativePercent(z2Also, "Z1"), 0.001)
        assertEquals(z3Boundaries[3], z2Boundaries[3])
        assertTrue(z2Boundaries[4] < z3Boundaries[4])
        assertTrue(z2Boundaries[5] < z3Boundaries[5])

        val allZones = z2Also.copy(cumulativePercentByZone = mapOf("Z3" to 5.0, "Z2" to 5.0, "Z1" to 5.0))
        val allBoundaries = ZoneCalibrationEngine.boundaryValues(AdaptiveZoneCalibrationEngine.apply(base, allZones))
        assertEquals(15.0, AdaptiveZoneCalibrationEngine.cumulativePercent(allZones, "Z1"), 0.001)
        assertEquals(10.0, AdaptiveZoneCalibrationEngine.cumulativePercent(allZones, "Z2"), 0.001)
        assertEquals(5.0, AdaptiveZoneCalibrationEngine.cumulativePercent(allZones, "Z3"), 0.001)
        assertEquals(z2Boundaries[4], allBoundaries[4])
        assertTrue(allBoundaries[5] < z2Boundaries[5])
        assertEquals(base.z4.range, AdaptiveZoneCalibrationEngine.apply(base, allZones).z4.range)
        assertEquals(base.z5.range, AdaptiveZoneCalibrationEngine.apply(base, allZones).z5.range)
    }

    @Test
    fun `bloqueia proposta que comprime faixa abaixo da largura minima`() {
        val narrowZ1 = base.z1.copy(
            range = PaceRange(base.z2.range.slowestPaceValue, base.z2.range.slowestPaceValue + 10)
        )
        val narrowBase = base.copy(z1 = narrowZ1)
        val state = AdaptiveZoneCalibrationEngine.resetForValidTest(
            AdaptiveZoneCalibrationState(), testDate.toString()
        )
        val reviewDate = testDate.plusDays(28)
        val review = AdaptiveZoneCalibrationEngine.evaluate(
            narrowBase, observations("Z1", reviewDate), state, reviewDate, testDate.toString()
        )
        assertEquals(AdaptiveZoneCalibrationEngine.BLOCKED, review.status)
        assertTrue(review.proposals.isEmpty())
        assertTrue(review.explanations["Z1"].orEmpty().contains("largura mínima de 10 segundos"))
    }

    @Test
    fun `reteste e considerado apos quatro semanas completas`() {
        assertEquals(testDate.plusDays(29), AdaptiveZoneCalibrationEngine.retestWindowStartDate(testDate.toString()))
        assertEquals(testDate.plusDays(29), AdaptiveZoneCalibrationEngine.retestDueDate(testDate.toString()))
        assertNull(AdaptiveZoneCalibrationEngine.retestDueDate(null))
    }

    @Test
    fun `dois lotes independentes podem atingir cinco por cento antes do reteste`() {
        val state = AdaptiveZoneCalibrationEngine.resetForValidTest(
            AdaptiveZoneCalibrationState(), testDate.toString()
        )
        val reviewDate = testDate.plusDays(28)
        val range = requireNotNull(base.zone("Z2")).range
        val midpoint = (range.fastestPaceValue + range.slowestPaceValue) / 2.0
        val rows = (0 until 6).flatMap { session ->
            val date = testDate.plusDays(10L + session)
            (0 until 2).map { blockIndex ->
                AdaptiveZoneObservation(
                    sessionId = "two-lot-session-$session",
                    dateIso = date.toString(),
                    zone = "Z2",
                    actualPaceSecondsPerKm = (midpoint * 0.96).roundToInt(),
                    targetFastestPaceSecondsPerKm = range.fastestPaceValue,
                    targetSlowestPaceSecondsPerKm = range.slowestPaceValue,
                    effort = "Leve", feeling = "Bem", painPresent = false,
                    workoutType = "Aeróbio",
                    blockId = "two-lot-block-$session-$blockIndex"
                )
            }
        }
        val review = AdaptiveZoneCalibrationEngine.evaluate(base, rows, state, reviewDate, testDate.toString())
        assertEquals(AdaptiveZoneCalibrationEngine.READY, review.status)
        val proposal = review.proposals.single()
        assertEquals("Z2", proposal.zone)
        assertEquals(5.0, proposal.appliedChangePercent, 0.001)
        assertEquals(5.0, proposal.sourceContributionAfterPercent, 0.001)
        assertTrue(proposal.explanation.contains("Lote A:") && proposal.explanation.contains("Lote B:"))
    }

    @Test
    fun `novo Cooper melhor reinicia creditos e atualiza referencia sem suavizacao`() {
        val previousRecord = requireNotNull(CooperAssessmentEngine.createRecord(2.5, testDate))
        val state = AdaptiveZoneCalibrationState(
            referenceTestDateIso = testDate.toString(),
            lastReviewDateIso = testDate.plusDays(28).toString(),
            cumulativePercentByZone = mapOf("Z1" to 3.0, "Z2" to 2.0, "Z3" to 3.0),
            referenceTestMethod = "COOPER_12_MIN",
            lastTestAssessmentValue = 2.5
        )
        val current = requireNotNull(CooperAssessmentEngine.createRecord(2.7, testDate.plusDays(29)))
        val updated = AdaptiveZoneCalibrationEngine.registerValidTest(state, listOf(previousRecord), current)
        assertEquals("IMPROVED", updated.testComparisonStatus)
        assertTrue(updated.cumulativePercentByZone.values.all { it == 0.0 })
        assertFalse(updated.antiResetLock)
        assertFalse(updated.calibrationSuspended)
        assertEquals(2.7, updated.lastTestAssessmentValue!!, 0.001)
        assertEquals(current.dateIso, updated.referenceTestDateIso)
    }

    @Test
    fun `teste equivalente preserva creditos e teste pior ativa trava anti reset`() {
        val previousRecord = requireNotNull(CooperAssessmentEngine.createRecord(2.5, testDate))
        val state = AdaptiveZoneCalibrationState(
            referenceTestDateIso = testDate.toString(),
            lastReviewDateIso = testDate.plusDays(28).toString(),
            cumulativePercentByZone = mapOf("Z1" to 3.0, "Z2" to 2.0, "Z3" to 1.0),
            referenceTestMethod = "COOPER_12_MIN",
            lastTestAssessmentValue = 2.5
        )
        val equivalent = requireNotNull(CooperAssessmentEngine.createRecord(2.52, testDate.plusDays(29)))
        val preserved = AdaptiveZoneCalibrationEngine.registerValidTest(state, listOf(previousRecord), equivalent)
        assertEquals("EQUIVALENT", preserved.testComparisonStatus)
        assertEquals(state.cumulativePercentByZone, preserved.cumulativePercentByZone)
        assertFalse(preserved.antiResetLock)

        val worse = requireNotNull(CooperAssessmentEngine.createRecord(2.4, testDate.plusDays(30)))
        val protected = AdaptiveZoneCalibrationEngine.registerValidTest(state, listOf(previousRecord), worse)
        assertEquals("WORSE", protected.testComparisonStatus)
        assertEquals(state.cumulativePercentByZone, protected.cumulativePercentByZone)
        assertTrue(protected.antiResetLock)
    }

    @Test
    fun `edicao do registro de referencia nao simula novo teste nem apaga creditos`() {
        val original = requireNotNull(CooperAssessmentEngine.createRecord(2.5, testDate))
        val edited = original.copy(distanceKm = 2.62, estimatedVo2Max = original.estimatedVo2Max + 1.0)
        val state = AdaptiveZoneCalibrationState(
            referenceTestDateIso = testDate.toString(),
            lastReviewDateIso = testDate.plusDays(28).toString(),
            cumulativePercentByZone = mapOf("Z1" to 2.5, "Z2" to 3.0, "Z3" to 1.5),
            referenceTestMethod = "COOPER_12_MIN",
            lastTestAssessmentValue = 2.5
        )
        val synchronized = AdaptiveZoneCalibrationEngine.synchronizeReferenceTest(state, edited, original)
        assertEquals(state.cumulativePercentByZone, synchronized.cumulativePercentByZone)
        assertEquals("UNVERIFIED", synchronized.testComparisonStatus)
        assertEquals(2.62, synchronized.lastTestAssessmentValue!!, 0.001)
        assertFalse(synchronized.calibrationSuspended)
    }

    @Test
    fun `edicao com protocolo desconhecido conserva creditos em espera`() {
        val edited = requireNotNull(CooperAssessmentEngine.createThreeKmRecord(
            timeSeconds = 900, date = testDate, referenceSex = RunnerFitnessAssessmentEngine.MALE, ageAtTest = 30
        ))
        val state = AdaptiveZoneCalibrationState(
            referenceTestDateIso = testDate.toString(),
            cumulativePercentByZone = mapOf("Z1" to 3.0, "Z2" to 2.0, "Z3" to 1.0)
        )
        val synchronized = AdaptiveZoneCalibrationEngine.synchronizeReferenceTest(state, edited)
        assertTrue(synchronized.calibrationSuspended)
        assertTrue(synchronized.cumulativePercentByZone.values.all { it == 0.0 })
        assertEquals(3.0, synchronized.pendingPercentByZone["Z1"]!!, 0.001)
    }

    @Test
    fun `mudanca de protocolo coloca creditos em espera e nao os aplica`() {
        val previousCooper = requireNotNull(CooperAssessmentEngine.createRecord(2.5, testDate))
        val state = AdaptiveZoneCalibrationState(
            referenceTestDateIso = testDate.toString(),
            lastReviewDateIso = testDate.toString(),
            cumulativePercentByZone = mapOf("Z1" to 3.0, "Z2" to 2.0, "Z3" to 1.0),
            referenceTestMethod = "COOPER_12_MIN",
            lastTestAssessmentValue = 2.5
        )
        val threeKm = requireNotNull(CooperAssessmentEngine.createThreeKmRecord(
            timeSeconds = 900, date = testDate.plusDays(29), referenceSex = RunnerFitnessAssessmentEngine.MALE, ageAtTest = 30
        ))
        val switched = AdaptiveZoneCalibrationEngine.registerValidTest(state, listOf(previousCooper), threeKm)
        assertEquals("INCOMPARABLE", switched.testComparisonStatus)
        assertTrue(switched.calibrationSuspended)
        assertTrue(switched.cumulativePercentByZone.values.all { it == 0.0 })
        assertEquals(3.0, switched.pendingPercentByZone["Z1"]!!, 0.001)
        assertEquals(base.z1.range, AdaptiveZoneCalibrationEngine.apply(base, switched).z1.range)

        val nextThreeKm = requireNotNull(CooperAssessmentEngine.createThreeKmRecord(
            timeSeconds = 880, date = testDate.plusDays(58), referenceSex = RunnerFitnessAssessmentEngine.MALE, ageAtTest = 30
        ))
        val resumed = AdaptiveZoneCalibrationEngine.registerValidTest(switched, listOf(previousCooper, threeKm), nextThreeKm)
        assertFalse(resumed.calibrationSuspended)
        assertTrue(resumed.pendingPercentByZone["Z1"]!! > 0.0)
        assertEquals("IMPROVED", resumed.testComparisonStatus)
    }

    @Test
    fun `reset manual reavalia evidencias historicas anteriores ao reset sem perder treinos`() {
        val reference = AdaptiveZoneCalibrationEngine.resetForValidTest(AdaptiveZoneCalibrationState(), testDate.toString())
        val reviewDate = testDate.plusDays(70)
        val historicalRows = observations("Z2", reviewDate)
        val beforeReset = reference.copy(
            lastReviewDateIso = testDate.plusDays(28).toString(),
            cumulativePercentByZone = mapOf("Z1" to 3.0, "Z2" to 3.0, "Z3" to 0.0)
        )
        val reset = AdaptiveZoneCalibrationEngine.resetManually(
            beforeReset, base, reviewDate.toString(), "cycle-after-reset"
        )
        assertEquals(0.0, AdaptiveZoneCalibrationEngine.sourceContributionPercent(reset, "Z2"), 0.0001)
        assertTrue(reset.reprocessHistoricalEvidence)
        assertTrue(reset.history.any { it.decision == "MANUAL_RESET" })
        val review = AdaptiveZoneCalibrationEngine.evaluate(base, historicalRows, reset, reviewDate, testDate.toString())
        assertEquals(AdaptiveZoneCalibrationEngine.READY, review.status)
        assertTrue(review.proposals.any { it.zone == "Z2" })
    }

    @Test
    fun `lote A pronto com zero contribuicao nunca aparece como confirmado`() {
        val state = AdaptiveZoneCalibrationEngine.resetForValidTest(AdaptiveZoneCalibrationState(), testDate.toString())
        val today = testDate.plusDays(10)
        val range = requireNotNull(base.zone("Z3")).range
        val midpoint = (range.fastestPaceValue + range.slowestPaceValue) / 2.0
        val rows = (0 until 5).map { index ->
            val session = index / 2
            AdaptiveZoneObservation(
                sessionId = "z3-ready-session-$session", dateIso = testDate.plusDays((session + 2).toLong()).toString(),
                zone = "Z3", actualPaceSecondsPerKm = (midpoint * 0.96).roundToInt(),
                targetFastestPaceSecondsPerKm = range.fastestPaceValue,
                targetSlowestPaceSecondsPerKm = range.slowestPaceValue,
                effort = "Pesado", feeling = "Bem", painPresent = false, workoutType = "Aeróbio",
                blockId = "z3-ready-block-$index"
            )
        }
        val review = AdaptiveZoneCalibrationEngine.evaluate(
            base, rows, state, today, testDate.toString()
        )
        val progress = requireNotNull(review.lotProgressByZone["Z3"])
        assertEquals("A_READY", progress.nextLot)
        assertFalse(progress.lotAConfirmed)
        assertEquals(0.0, progress.acceptedSourceContributionPercent, 0.0001)
    }

}
