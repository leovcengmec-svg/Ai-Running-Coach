package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class WorkoutAlternativeEngineTest {
    private val snapshot = PaceCalibrationSnapshot(
        assessmentDateIso = "2026-11-09",
        distanceKm = 2.4,
        averagePaceMmSs = "5:00",
        estimatedVo2Max = 42.3,
        estimatedMasPaceMmSs = "4:30",
        estimatedSvt2PaceMmSs = "4:55",
        modelVersion = "TEST_ZONES",
        zoneRanges = mapOf(
            "Z1" to "8:00–9:30 min/km",
            "Z2" to "7:00–8:00 min/km",
            "Z3" to "6:00–7:00 min/km",
            "Z4" to "5:00–6:00 min/km",
            "Z5" to "4:30–5:00 min/km"
        )
    )

    private fun workout(type: String, title: String, segments: List<WorkoutSegment>, distance: Double): Workout = Workout(
        date = "Segunda-feira, 09/11",
        scheduledDateIso = "2026-11-09",
        title = title,
        detail = "Sessão original",
        type = type,
        objective = "Objetivo original",
        stimulus = if (type == "Qualidade") "THRESHOLD_INTERVAL_Z4" else "EASY_AEROBIC_Z2",
        distanceKm = distance,
        sessionId = "session-1",
        durationMin = 45,
        paceMode = "PACE_RANGE",
        rationale = "Motivo original",
        segments = segments,
        paceCalibrationSnapshot = snapshot
    )

    @Test
    fun `alternativa saudavel de qualidade preserva Z4 e redistribui as repeticoes`() {
        val primary = workout(
            "Qualidade", "Intervalos de limiar",
            listOf(
                WorkoutSegment("Aquecimento", "Leve", durationMin = 8, distanceKm = 1.0, targetMode = "TIME", paceZone = "Z1", targetPaceMinValue = 480, targetPaceMaxValue = 570),
                WorkoutSegment("Intervalos de limiar", "Repetir", distanceKm = 0.5, repeatCount = 6, paceZone = "Z4", targetPaceMinValue = 300, targetPaceMaxValue = 360),
                WorkoutSegment("Recuperação", "Leve", distanceKm = 0.25, repeatCount = 4, paceZone = "Z1", targetPaceMinValue = 480, targetPaceMaxValue = 570),
                WorkoutSegment("Desaquecimento", "Leve", durationMin = 7, distanceKm = 1.0, targetMode = "TIME", paceZone = "Z1", targetPaceMinValue = 480, targetPaceMaxValue = 570)
            ), 6.0
        )

        val alternative = WorkoutAlternativeEngine.createAlternative(primary)
        assertEquals("Limiar equivalente Z4", alternative.title)
        assertEquals("Qualidade", alternative.type)
        assertEquals(6.0, alternative.distanceKm, 0.001)
        assertEquals("THRESHOLD_INTERVAL_Z4", alternative.stimulus)
        assertEquals(primary.sessionId, alternative.sessionId)
        assertEquals("ALTERNATIVE", alternative.selectedOption)
        assertEquals(6.0, alternative.segments.sumOf { (it.distanceKm ?: 0.0) * it.repeatCount }, 0.001)
        val main = alternative.segments.single { it.name == "Intervalo alternativo Z4" }
        assertEquals("Z4", main.paceZone)
        assertEquals(5, main.repeatCount)
        assertEquals(0.6, main.distanceKm!!, 0.001)
        assertEquals(300, main.targetPaceMinValue)
        assertEquals(321, main.targetPaceMaxValue)
        assertEquals(65, main.zoneIntensityMinPercent)
        assertEquals(100, main.zoneIntensityMaxPercent)
        assertEquals(4, alternative.segments.single { it.name == "Recuperação" }.repeatCount)
    }

    @Test
    fun `alternativa de progressivo Z2 preserva todas as etapas e a ordem crescente`() {
        val primary = workout("Aeróbio", "Rodagem progressiva Z2", listOf(
            WorkoutSegment("Aquecimento", "Z2 leve", distanceKm = 1.0, paceZone = "Z2", targetPaceMinValue = 420, targetPaceMaxValue = 480,
                zoneBasePaceFastValue = 420, zoneBasePaceSlowValue = 480, zoneIntensityMinPercent = 0, zoneIntensityMaxPercent = 20),
            WorkoutSegment("Bloco 1", "Primeira etapa", distanceKm = 1.0, paceZone = "Z2", targetPaceMinValue = 468, targetPaceMaxValue = 480,
                zoneBasePaceFastValue = 420, zoneBasePaceSlowValue = 480, zoneIntensityMinPercent = 0, zoneIntensityMaxPercent = 20),
            WorkoutSegment("Bloco 2", "Segunda etapa", distanceKm = 1.0, paceZone = "Z2", targetPaceMinValue = 456, targetPaceMaxValue = 468,
                zoneBasePaceFastValue = 420, zoneBasePaceSlowValue = 480, zoneIntensityMinPercent = 20, zoneIntensityMaxPercent = 40),
            WorkoutSegment("Bloco 3", "Terceira etapa", distanceKm = 1.0, paceZone = "Z2", targetPaceMinValue = 444, targetPaceMaxValue = 456,
                zoneBasePaceFastValue = 420, zoneBasePaceSlowValue = 480, zoneIntensityMinPercent = 40, zoneIntensityMaxPercent = 60),
            WorkoutSegment("Desaquecimento", "Z2 leve", distanceKm = 1.0, paceZone = "Z2", targetPaceMinValue = 420, targetPaceMaxValue = 432,
                zoneBasePaceFastValue = 420, zoneBasePaceSlowValue = 480, zoneIntensityMinPercent = 80, zoneIntensityMaxPercent = 100)
        ), 5.0).copy(stimulus = "PROGRESSIVE_RUN_Z2")

        val alternative = WorkoutAlternativeEngine.createAlternative(primary)
        assertEquals("Rodagem progressiva equivalente Z2", alternative.title)
        val stages = alternative.segments.filter { it.name.startsWith("Etapa progressiva") }
        assertEquals(3, stages.size)
        assertEquals(listOf(1.0, 1.0, 1.0), stages.map { it.distanceKm })
        assertEquals(listOf(20, 40, 60), stages.map { it.zoneIntensityMinPercent })
        assertEquals(listOf(40, 60, 80), stages.map { it.zoneIntensityMaxPercent })
        assertEquals(5.0, alternative.distanceKm, 0.001)
    }

    @Test
    fun `alternativa nao transforma corredor desconhecido em corrida caminhada sem estimulo iniciante`() {
        val primary = workout(
            "Longo", "Longão aeróbio",
            listOf(
                WorkoutSegment("Aquecimento", "Leve", distanceKm = 0.5, paceZone = "Z1", targetPaceMinValue = 480, targetPaceMaxValue = 570),
                WorkoutSegment("Longão aeróbio", "Constante", distanceKm = 6.0, paceZone = "Z2", targetPaceMinValue = 420, targetPaceMaxValue = 480),
                WorkoutSegment("Desaquecimento", "Leve", distanceKm = 0.5, paceZone = "Z1", targetPaceMinValue = 480, targetPaceMaxValue = 570)
            ), 7.0
        )
        val alternative = WorkoutAlternativeEngine.createAlternative(primary, allowRunWalk = true)
        assertEquals("Longão contínuo aeróbio — variação", alternative.title)
        assertEquals(7.0, alternative.distanceKm, 0.001)
        val main = alternative.segments.single { it.name == "Longão contínuo Z2" }
        assertEquals("Z2", main.paceZone)
        assertTrue(alternative.segments.none { it.name.contains("caminhada", ignoreCase = true) })
    }

    @Test
    fun `alternativa de longao padrao mantem corrida continua sem pausas de caminhada`() {
        val primary = workout(
            "Longo", "Longão aeróbio",
            listOf(
                WorkoutSegment("Aquecimento", "Leve", distanceKm = 0.5, paceZone = "Z1", targetPaceMinValue = 480, targetPaceMaxValue = 570),
                WorkoutSegment("Longão aeróbio", "Constante", distanceKm = 6.0, paceZone = "Z2", targetPaceMinValue = 420, targetPaceMaxValue = 480),
                WorkoutSegment("Desaquecimento", "Leve", distanceKm = 0.5, paceZone = "Z1", targetPaceMinValue = 480, targetPaceMaxValue = 570)
            ), 7.0
        )
        val alternative = WorkoutAlternativeEngine.createAlternative(primary)
        assertEquals("Longão contínuo aeróbio — variação", alternative.title)
        assertTrue(alternative.segments.any { it.name == "Longão contínuo Z2" })
        assertTrue(alternative.segments.none { it.name.contains("caminhada", ignoreCase = true) })
    }

    @Test
    fun `alternativa de rodagem preserva Z2 e recalcula faixa ativa`() {
        val primary = workout(
            "Aeróbio", "Rodagem aeróbia",
            listOf(WorkoutSegment("Bloco aeróbio", "Conversável", distanceKm = 5.0, paceZone = "Z2", targetPaceMinValue = 420, targetPaceMaxValue = 480)),
            5.0
        )
        val alternative = WorkoutAlternativeEngine.createAlternative(primary)
        assertEquals("Rodagem aeróbia equivalente", alternative.title)
        assertEquals(5.0, alternative.distanceKm, 0.001)
        val segment = alternative.segments.single()
        assertEquals("Z2", segment.paceZone)
        assertEquals(444, segment.targetPaceMinValue)
        assertEquals(468, segment.targetPaceMaxValue)
        assertEquals(420, segment.zoneBasePaceFastValue)
        assertEquals(480, segment.zoneBasePaceSlowValue)
        assertEquals(20, segment.zoneIntensityMinPercent)
        assertEquals(60, segment.zoneIntensityMaxPercent)
    }

    @Test
    fun `sem snapshot de calibracao alternativa nao inventa pace`() {
        val primary = workout(
            "Aeróbio", "Rodagem aeróbia",
            listOf(WorkoutSegment("Bloco aeróbio", "Conversável", distanceKm = 5.0, paceZone = "Z2", targetPaceMinValue = 420, targetPaceMaxValue = 480)),
            5.0
        ).copy(paceCalibrationSnapshot = null, paceMode = "PACE_NOT_CALIBRATED")
        val alternative = WorkoutAlternativeEngine.createAlternative(primary)
        val segment = alternative.segments.single()
        assertEquals("Z2", segment.paceZone)
        assertNull(segment.targetPaceMinValue)
        assertNull(segment.targetPaceMaxValue)
    }

    @Test
    fun `run walk alternative requires explicit beginner run walk stimulus and profile eligibility`() {
        val primary = workout("Longo", "Longão corrida caminhada", listOf(
            WorkoutSegment("Corrida ativa", "Correr", durationMin = 3, distanceKm = 0.3, targetMode = "TIME"),
            WorkoutSegment("Caminhada de recuperação", "Caminhar", durationMin = 2, distanceKm = 0.1, targetMode = "TIME", recoveryMode = "WALK")
        ), 0.4).copy(stimulus = "BEGINNER_RUN_WALK_LONG", experienceMonths = 3)
        val alternative = WorkoutAlternativeEngine.createAlternative(primary, allowRunWalk = true)
        assertEquals("Longão com pausas de caminhada", alternative.title)
    }

    @Test
    fun `poor recovery receives a lower demand substitute instead of quality equivalent`() {
        val primary = workout("Qualidade", "Intervalado Z5", listOf(
            WorkoutSegment("Intervalo", "Forte", distanceKm = 0.4, repeatCount = 5, paceZone = "Z5",
                targetPaceMinValue = 270, targetPaceMaxValue = 300, zoneBasePaceFastValue = 270, zoneBasePaceSlowValue = 300),
            WorkoutSegment("Desaquecimento", "Finalizar", distanceKm = 1.0, paceZone = "Z1", targetPaceMinValue = 480, targetPaceMaxValue = 570)
        ), 3.0)
        val alternative = WorkoutAlternativeEngine.createAlternative(primary, preserveQualityStimulus = false)
        assertEquals("Sessão reduzida por recuperação", alternative.title)
        assertTrue(alternative.distanceKm < primary.distanceKm)
    }

    @Test
    fun `alternativa preserva agendamento semana e identidade`() {
        val primary = workout(
            "Aeróbio", "Rodagem aeróbia",
            listOf(WorkoutSegment("Bloco aeróbio", "Conversável", distanceKm = 5.0, paceZone = "Z2", targetPaceMinValue = 420, targetPaceMaxValue = 480)),
            5.0
        ).copy(week = 3, phase = "PROGRESSION", manuallyRescheduled = true, originalScheduledDateIso = "2026-11-08")
        val alternative = WorkoutAlternativeEngine.createAlternative(primary)
        assertEquals(primary.sessionId, alternative.sessionId)
        assertEquals(primary.scheduledDateIso, alternative.scheduledDateIso)
        assertEquals(primary.week, alternative.week)
        assertEquals(primary.phase, alternative.phase)
        assertEquals(primary.originalScheduledDateIso, alternative.originalScheduledDateIso)
        assertEquals(primary.paceCalibrationSnapshot, alternative.paceCalibrationSnapshot)
        assertNotNull(alternative.rationale)
    }
    @Test fun `segunda alternativa reduz exigencia e volume sem criar outra sessao`() {
        val primary = workout(
            "Qualidade", "Intervalos de limiar",
            listOf(
                WorkoutSegment("Aquecimento", "Leve", durationMin = 8, distanceKm = 1.0, targetMode = "TIME", paceZone = "Z1"),
                WorkoutSegment("Intervalos de limiar", "Repetir", distanceKm = 0.5, repeatCount = 6, paceZone = "Z4"),
                WorkoutSegment("Recuperação", "Leve", distanceKm = 0.25, repeatCount = 4, paceZone = "Z1", recoveryMode = "ACTIVE_Z1"),
                WorkoutSegment("Desaquecimento", "Leve", durationMin = 7, distanceKm = 1.0, targetMode = "TIME", paceZone = "Z1")
            ), 6.0
        )
        val easier = WorkoutAlternativeEngine.createEasierAlternative(primary)
        assertEquals("ALTERNATIVE_EASIER", easier.selectedOption)
        assertEquals(primary.sessionId, easier.sessionId)
        assertEquals(primary.scheduledDateIso, easier.scheduledDateIso)
        assertTrue(easier.distanceKm < primary.distanceKm)
        assertTrue(easier.distanceKm <= primary.distanceKm)
        assertTrue(easier.rationale.contains("menor exigência"))
        assertEquals("LOW", easier.intensity)
        assertTrue(easier.segments.none { it.paceZone == "Z4" })
    }



    @Test
    fun `alternativa equivalente de longao progressivo preserva zonas progressivas`() {
        val primary = workout(
            "Longo", "Longão progressivo Z2–Z3", listOf(
                WorkoutSegment("Aquecimento", "Leve", distanceKm = 0.8, paceZone = "Z2"),
                WorkoutSegment("Longão Z2", "Base confortável", distanceKm = 3.0, paceZone = "Z2"),
                WorkoutSegment("Longão Z3", "Final progressivo", distanceKm = 1.5, paceZone = "Z3"),
                WorkoutSegment("Desaquecimento", "Leve", distanceKm = 0.7, paceZone = "Z2")
            ), 6.0
        ).copy(stimulus = "LONG_RUN_PROGRESSIVE_Z2_Z3")

        val alternative = WorkoutAlternativeEngine.createAlternative(primary)
        assertEquals("Rodagem progressiva equivalente Z2–Z3", alternative.title)
        assertEquals(primary.distanceKm, alternative.distanceKm, 0.001)
        assertEquals(listOf("Z2", "Z2", "Z3", "Z2"), alternative.segments.mapNotNull { it.paceZone })
        assertEquals("ALTERNATIVE", alternative.selectedOption)
    }

    @Test
    fun `alternativa equivalente de fartlek preserva alternancia e ordem dos blocos`() {
        val primary = workout(
            "Qualidade", "Fartlek leve", listOf(
                WorkoutSegment("Aquecimento", "Leve", distanceKm = 0.6, paceZone = "Z2"),
                WorkoutSegment("Ritmo confortável", "Primeira variação", distanceKm = 0.8, paceZone = "Z2"),
                WorkoutSegment("Recuperação ativa", "Solte", distanceKm = 0.2, paceZone = "Z1", recoveryMode = "ACTIVE_Z1"),
                WorkoutSegment("Ritmo moderado", "Segunda variação", distanceKm = 0.6, paceZone = "Z3"),
                WorkoutSegment("Recuperação ativa", "Solte", distanceKm = 0.2, paceZone = "Z1", recoveryMode = "ACTIVE_Z1"),
                WorkoutSegment("Desaquecimento", "Leve", distanceKm = 0.6, paceZone = "Z2")
            ), 3.0
        ).copy(stimulus = "FARTLEK_Z2_Z3")

        val alternative = WorkoutAlternativeEngine.createAlternative(primary)
        assertEquals("Fartlek equivalente Z2–Z3", alternative.title)
        assertEquals(primary.distanceKm, alternative.distanceKm, 0.001)
        assertEquals(
            listOf("Aquecimento", "Variação Fartlek Z2 1", "Recuperação ativa", "Variação Fartlek Z3 2", "Recuperação ativa", "Desaquecimento"),
            alternative.segments.map { it.name }
        )
        assertEquals("ALTERNATIVE", alternative.selectedOption)
    }

    @Test fun `alternativa leve de rodagem reduz dose principal sem reduzir transicoes`() {
        val primary = workout(
            "Aeróbio", "Rodagem contínua Z2",
            listOf(
                WorkoutSegment("Aquecimento", "Leve", distanceKm = 0.5, paceZone = "Z2"),
                WorkoutSegment("Rodagem contínua", "Confortável", distanceKm = 4.0, paceZone = "Z2"),
                WorkoutSegment("Desaquecimento", "Leve", distanceKm = 0.5, paceZone = "Z2")
            ), 5.0
        )
        val easier = WorkoutAlternativeEngine.createEasierAlternative(primary)
        assertTrue(easier.distanceKm < primary.distanceKm)
        assertEquals(0.5, easier.segments.first().distanceKm!!, 0.001)
        assertEquals(0.5, easier.segments.last().distanceKm!!, 0.001)
        assertEquals(3.6, easier.segments[1].distanceKm!!, 0.001)
    }

}
