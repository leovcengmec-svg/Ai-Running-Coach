package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class WorkoutAlternativeEngineTest {
    private val snapshot = PaceCalibrationSnapshot(
        assessmentDateIso = "2026-11-09",
        distanceKm = 2.4,
        averagePaceMmSs = "5:00",
        estimatedVo2Max = 42.3,
        estimatedMasPaceMmSs = "4:30",
        estimatedSvt2PaceMmSs = "4:55",
        modelVersion = "TEST_ZONES",
        zoneRanges = mapOf(
            "Z1" to "8:00–9:30 min/km",
            "Z2" to "7:00–8:00 min/km",
            "Z3" to "6:00–7:00 min/km",
            "Z4" to "5:00–6:00 min/km",
            "Z5" to "4:30–5:00 min/km"
        )
    )

    private fun workout(type: String, title: String, segments: List<WorkoutSegment>, distance: Double): Workout = Workout(
        date = "Segunda-feira, 09/11",
        scheduledDateIso = "2026-11-09",
        title = title,
        detail = "Sessão original",
        type = type,
        objective = "Objetivo original",
        stimulus = if (type == "Qualidade") "THRESHOLD_INTERVAL_Z4" else "EASY_AEROBIC_Z2",
        distanceKm = distance,
        sessionId = "session-1",
        durationMin = 45,
        paceMode = "PACE_RANGE",
        rationale = "Motivo original",
        segments = segments,
        paceCalibrationSnapshot = snapshot
    )

    @Test
    fun `alternativa de qualidade troca intervalos por bloco continuo Z2 e conserva dose`() {
        val primary = workout(
            "Qualidade", "Intervalos de limiar",
            listOf(
                WorkoutSegment("Aquecimento", "Leve", durationMin = 8, distanceKm = 1.0, targetMode = "TIME", paceZone = "Z1", targetPaceMinValue = 480, targetPaceMaxValue = 570),
                WorkoutSegment("Intervalos de limiar", "Repetir", distanceKm = 0.5, repeatCount = 6, paceZone = "Z4", targetPaceMinValue = 300, targetPaceMaxValue = 360),
                WorkoutSegment("Recuperação", "Leve", distanceKm = 0.25, repeatCount = 4, paceZone = "Z1", targetPaceMinValue = 480, targetPaceMaxValue = 570),
                WorkoutSegment("Desaquecimento", "Leve", durationMin = 7, distanceKm = 1.0, targetMode = "TIME", paceZone = "Z1", targetPaceMinValue = 480, targetPaceMaxValue = 570)
            ), 6.0
        )

        val alternative = WorkoutAlternativeEngine.createAlternative(primary)
        assertEquals("Rodagem aeróbia contínua", alternative.title)
        assertEquals("Aeróbio", alternative.type)
        assertEquals(6.0, alternative.distanceKm, 0.001)
        assertEquals(45, alternative.durationMin)
        assertEquals(primary.sessionId, alternative.sessionId)
        assertEquals("ALTERNATIVE", alternative.selectedOption)
        assertEquals(6.0, alternative.segments.sumOf { (it.distanceKm ?: 0.0) * it.repeatCount }, 0.001)
        val main = alternative.segments.single { it.name == "Bloco aeróbio contínuo" }
        assertEquals("Z2", main.paceZone)
        assertEquals(420, main.targetPaceMinValue)
        assertEquals(480, main.targetPaceMaxValue)
        assertTrue(alternative.segments.filter { it.name != main.name }.all { it.paceZone == "Z1" })
    }

    @Test
    fun `alternativa de longao troca o bloco principal para corrida caminhada Z1`() {
        val primary = workout(
            "Longo", "Longão aeróbio",
            listOf(
                WorkoutSegment("Aquecimento", "Leve", distanceKm = 0.5, paceZone = "Z1", targetPaceMinValue = 480, targetPaceMaxValue = 570),
                WorkoutSegment("Longão aeróbio", "Constante", distanceKm = 6.0, paceZone = "Z2", targetPaceMinValue = 420, targetPaceMaxValue = 480),
                WorkoutSegment("Desaquecimento", "Leve", distanceKm = 0.5, paceZone = "Z1", targetPaceMinValue = 480, targetPaceMaxValue = 570)
            ), 7.0
        )
        val alternative = WorkoutAlternativeEngine.createAlternative(primary)
        assertEquals("Longão com pausas confortáveis", alternative.title)
        assertEquals(7.0, alternative.distanceKm, 0.001)
        val main = alternative.segments.single { it.name == "Longão com pausas de caminhada" }
        assertEquals("Z1", main.paceZone)
        assertEquals(480, main.targetPaceMinValue)
        assertEquals(570, main.targetPaceMaxValue)
    }

    @Test
    fun `alternativa de rodagem usa Z1 e nao preserva pace numerico da Z2`() {
        val primary = workout(
            "Aeróbio", "Rodagem aeróbia",
            listOf(WorkoutSegment("Bloco aeróbio", "Conversável", distanceKm = 5.0, paceZone = "Z2", targetPaceMinValue = 420, targetPaceMaxValue = 480)),
            5.0
        )
        val alternative = WorkoutAlternativeEngine.createAlternative(primary)
        assertEquals("Corrida-caminhada leve", alternative.title)
        assertEquals(5.0, alternative.distanceKm, 0.001)
        val segment = alternative.segments.single()
        assertEquals("Z1", segment.paceZone)
        assertEquals(480, segment.targetPaceMinValue)
        assertEquals(570, segment.targetPaceMaxValue)
        assertFalse(segment.targetPaceMinValue == 420)
        assertEquals(480, segment.zoneBasePaceFastValue)
        assertEquals(570, segment.zoneBasePaceSlowValue)
        assertNull(segment.zoneIntensityMinPercent)
        assertNull(segment.zoneIntensityMaxPercent)
    }

    @Test
    fun `sem snapshot de calibracao alternativa nao inventa pace`() {
        val primary = workout(
            "Aeróbio", "Rodagem aeróbia",
            listOf(WorkoutSegment("Bloco aeróbio", "Conversável", distanceKm = 5.0, paceZone = "Z2", targetPaceMinValue = 420, targetPaceMaxValue = 480)),
            5.0
        ).copy(paceCalibrationSnapshot = null, paceMode = "PACE_NOT_CALIBRATED")
        val alternative = WorkoutAlternativeEngine.createAlternative(primary)
        val segment = alternative.segments.single()
        assertEquals("Z1", segment.paceZone)
        assertNull(segment.targetPaceMinValue)
        assertNull(segment.targetPaceMaxValue)
    }

    @Test
    fun `alternativa preserva agendamento semana e identidade`() {
        val primary = workout(
            "Aeróbio", "Rodagem aeróbia",
            listOf(WorkoutSegment("Bloco aeróbio", "Conversável", distanceKm = 5.0, paceZone = "Z2", targetPaceMinValue = 420, targetPaceMaxValue = 480)),
            5.0
        ).copy(week = 3, phase = "PROGRESSION", manuallyRescheduled = true, originalScheduledDateIso = "2026-11-08")
        val alternative = WorkoutAlternativeEngine.createAlternative(primary)
        assertEquals(primary.sessionId, alternative.sessionId)
        assertEquals(primary.scheduledDateIso, alternative.scheduledDateIso)
        assertEquals(primary.week, alternative.week)
        assertEquals(primary.phase, alternative.phase)
        assertEquals(primary.originalScheduledDateIso, alternative.originalScheduledDateIso)
        assertEquals(primary.paceCalibrationSnapshot, alternative.paceCalibrationSnapshot)
        assertNotNull(alternative.rationale)
    }
}
