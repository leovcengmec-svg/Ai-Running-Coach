package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Test

class WorkoutExportNamingTest {
    private fun workout(id: String, week: Int, title: String, date: String) = Workout(
        date = "Data", scheduledDateIso = date, title = title, detail = "", type = "Aeróbio",
        objective = "Base", stimulus = "EASY", distanceKm = 5.0, sessionId = id, week = week
    )

    @Test fun `nome usa semana treino e titulo sem data no formato Sx Ty`() {
        val first = workout("s1", 1, "Rodagem Aeróbica", "2026-11-11")
        val second = workout("s2", 1, "Longão aeróbio", "2026-11-13")
        assertEquals("S1_T1_Rodagem Aeróbica", WorkoutExportNaming.name(first, listOf(first, second)))
        assertEquals("S1_T2_Longão aeróbio", WorkoutExportNaming.name(second, listOf(first, second)))
    }

    @Test fun `nome de semana legada zero e normalizado para semana um`() {
        val value = workout("s1", 0, "Rodagem", "2026-11-11")
        assertEquals("S1_T1_Rodagem", WorkoutExportNaming.name(value, listOf(value)))
    }

    @Test fun `nome do anexo remove apenas caracteres reservados de caminho`() {
        assertEquals("S1_T1_Rodagem Aeróbica", WorkoutExportNaming.safeFileBaseName("S1_T1_Rodagem Aeróbica"))
        assertEquals("Treino ruim", WorkoutExportNaming.safeFileBaseName("../Treino: ruim/"))
    }

    @Test fun `nome da segunda semana segue exatamente o padrao solicitado`() {
        val first = workout("s2t1", 2, "Rodagem Progressiva Z2 Z3", "2026-11-18")
        assertEquals("S2_T1_Rodagem Progressiva Z2 Z3", WorkoutExportNaming.name(first, listOf(first)))
    }

}
