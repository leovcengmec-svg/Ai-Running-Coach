package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Test

class WorkoutExportNamingTest {
    private fun workout(
        id: String,
        week: Int,
        title: String,
        date: String,
        type: String = "Aeróbio",
        stimulus: String = "EASY",
        segments: List<WorkoutSegment> = emptyList()
    ) = Workout(
        date = "Data", scheduledDateIso = date, title = title, detail = "", type = type,
        objective = "Base", stimulus = stimulus, distanceKm = 5.0, sessionId = id,
        week = week, segments = segments
    )

    @Test fun `nome de qualidade usa sigla INT e dose compacta`() {
        val first = workout("s3t1", 3, "Rodagem leve", "2026-12-02")
        val second = workout(
            "s3t2", 3, "Tempo intervalado 2 × 10 min", "2026-12-04", "Qualidade",
            "TEMPO_INTERVAL_10MIN:T04",
            listOf(
                WorkoutSegment("Intervalo 1", "", durationMin = 10),
                WorkoutSegment("Intervalo 2", "", durationMin = 10)
            )
        )
        assertEquals("S3_T2_INT_2x10min", WorkoutExportNaming.name(second, listOf(first, second)))
    }

    @Test fun `nome do longao remove palavras genericas e preserva variante e zona`() {
        val first = workout("s3t1", 3, "Rodagem leve", "2026-12-02")
        val second = workout("s3t2", 3, "Fartlek variável Z2 Z3", "2026-12-04", "Qualidade", "FARTLEK_Z2_Z3:F04")
        val longRun = workout("s3t3", 3, "Longão progressivo Z2", "2026-12-06", "Longo", "LONG_RUN_PROGRESSIVE_Z2")
        assertEquals("S3_T3_LNG_ProgressivoZ2", WorkoutExportNaming.name(longRun, listOf(first, second, longRun)))
    }

    @Test fun `tempo run continuo recebe modalidade TMP e zona real`() {
        val tempo = workout(
            "s4t2", 4, "Tempo Run contínuo Z3", "2026-12-11", "Qualidade", "TEMPO_RUN_ESTIMATED",
            listOf(WorkoutSegment("Bloco contínuo", "", durationMin = 18, paceZone = "Z3"))
        )
        assertEquals("S4_T1_TMP_ContinuoZ3", WorkoutExportNaming.name(tempo, listOf(tempo)))
    }

    @Test fun `nome de semana legada zero e normalizado para semana um`() {
        val value = workout("s1", 0, "Rodagem", "2026-11-11")
        assertEquals("S1_T1_ROD_ContinuaZ2", WorkoutExportNaming.name(value, listOf(value)))
    }

    @Test fun `nome do anexo remove apenas caracteres reservados de caminho`() {
        assertEquals("S1_T1_INT_2x10min", WorkoutExportNaming.safeFileBaseName("S1_T1_INT_2x10min"))
        assertEquals("Treino ruim", WorkoutExportNaming.safeFileBaseName("../Treino: ruim/"))
    }

    @Test fun `ids relativos iguais em datas diferentes recebem numeros de treino distintos`() {
        val first = workout("W1-MON-AER", 1, "Rodagem leve", "2026-11-09")
        val second = workout("W1-MON-AER", 1, "Rodagem progressiva Z2 Z3", "2026-11-16")
        assertEquals("S1_T1_ROD_ContinuaZ2", WorkoutExportNaming.name(first, listOf(first, second)))
        assertEquals("S1_T2_ROD_ProgressivaZ2Z3", WorkoutExportNaming.name(second, listOf(first, second)))
    }
}
