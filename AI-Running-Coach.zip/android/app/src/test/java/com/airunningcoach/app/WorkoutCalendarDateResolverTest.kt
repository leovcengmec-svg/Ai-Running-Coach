package com.airunningcoach.app

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Test

class WorkoutCalendarDateResolverTest {
    @Test fun `atividade concluida usa a data real e preserva a planejada`() {
        val resolved = WorkoutCalendarDateResolver.resolve(
            scheduledDateIso = "2026-11-20",
            actualDate = LocalDate.parse("2026-11-13"),
            completed = true
        )
        assertEquals(LocalDate.parse("2026-11-13"), resolved.bucketDate)
        assertEquals(LocalDate.parse("2026-11-20"), resolved.plannedDate)
        assertEquals(LocalDate.parse("2026-11-13"), resolved.actualDate)
        assertEquals("Realizado 13/11/2026 • planejado 20/11/2026", resolved.displayLabel)
    }

    @Test fun `atividade futura ou nao concluida permanece na data programada`() {
        val resolved = WorkoutCalendarDateResolver.resolve(
            scheduledDateIso = "2026-11-20",
            actualDate = LocalDate.parse("2026-11-13"),
            completed = false
        )
        assertEquals(LocalDate.parse("2026-11-20"), resolved.bucketDate)
        assertEquals(null, resolved.actualDate)
    }
}
