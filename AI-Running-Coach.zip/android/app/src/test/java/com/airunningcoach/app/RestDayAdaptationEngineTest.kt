package com.airunningcoach.app

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RestDayAdaptationEngineTest {
    private val today = LocalDate.of(2026, 11, 14)
    private val sunday = LocalDate.of(2026, 11, 15)

    private fun weekSessions() = listOf(
        RestDaySessionEvidence("wed", LocalDate.of(2026, 11, 11), "Rodagem aeróbia", "Aeróbio", 5.0, true),
        RestDaySessionEvidence("fri", LocalDate.of(2026, 11, 13), "Rodagem aeróbia", "Aeróbio", 5.0, true)
    )

    private fun decide(
        sessions: List<RestDaySessionEvidence> = weekSessions(),
        feedback: List<RestDayFeedbackEvidence> = emptyList(),
        raceDates: Set<LocalDate> = emptySet()
    ) = RestDayAdaptationEngine.recommend(
        targetDate = sunday,
        today = today,
        sessions = sessions,
        feedback = feedback,
        raceDates = raceDates,
        weeklyBaselineKm = 18.0,
        longestRunLast30DaysKm = 7.0,
        noviceOrReturner = false
    )

    @Test fun `runner with sufficient base receives an adaptive 3-5 km extra option`() {
        val result = decide()
        assertTrue(result.canAddWorkout)
        assertTrue(result.estimatedDistanceKm in 3.0..5.0)
        assertTrue(result.normalEstimatedDistanceKm in 3.0..5.0)
        assertTrue(result.durationMin in 20..40)
        assertTrue(result.rpeRange == "2-3")
        assertTrue(result.riskText.contains("3 e 5 km", ignoreCase = true))
    }


    @Test fun `iniciante com base real de 16 km e maior corrida de 10 km recebe opcoes entre 3 e 5 km em corrida caminhada`() {
        val result = RestDayAdaptationEngine.recommend(
            targetDate = sunday, today = today, sessions = weekSessions(), feedback = emptyList(),
            raceDates = emptySet(), weeklyBaselineKm = 16.0, longestRunLast30DaysKm = 10.0,
            noviceOrReturner = true
        )
        assertTrue(result.canAddWorkout)
        assertEquals(3.5, result.estimatedDistanceKm, 0.0)
        assertEquals(4.5, result.normalEstimatedDistanceKm, 0.0)
        assertTrue(result.runWalkPattern)
        assertTrue(result.durationMin in 30..35)
        assertTrue(result.normalDurationMin in 40..45)
    }

    @Test fun `dor e fadiga reduzem a distancia sugerida em relacao ao perfil descansado`() {
        val rested = decide()
        val pain = decide(feedback = listOf(
            RestDayFeedbackEvidence(today.minusDays(1), "Leve", "Bem", true, 5.0)
        ))
        assertTrue(pain.estimatedDistanceKm < rested.estimatedDistanceKm)
        assertTrue(pain.normalEstimatedDistanceKm < rested.normalEstimatedDistanceKm)
        assertEquals("HIGH", pain.riskLevel)
    }

    @Test fun `sessao exigente recente reduz a opcao extra mesmo sem feedback de fadiga`() {
        val hardSessions = weekSessions() + RestDaySessionEvidence(
            "quality", today.minusDays(1), "Tempo run", "Qualidade", 5.0, true
        )
        val result = decide(sessions = hardSessions)
        assertTrue(result.canAddWorkout)
        assertTrue(result.estimatedDistanceKm < 3.2)
        assertTrue(result.riskText.contains("exigente", ignoreCase = true))
    }

    @Test fun `pain in recent feedback is a high risk warning but the athlete retains the choice`() {
        val result = decide(feedback = listOf(
            RestDayFeedbackEvidence(today.minusDays(1), "Leve", "Bem", true, 5.0)
        ))
        assertTrue(result.canAddWorkout)
        assertEquals("HIGH", result.riskLevel)
        assertTrue(result.riskText.contains("dor", ignoreCase = true))
    }

    @Test fun `two strong fatigue signals are disclosed without blocking the athlete`() {
        val result = decide(feedback = listOf(
            RestDayFeedbackEvidence(today.minusDays(1), "Pesado", "Cansado", false, 5.0),
            RestDayFeedbackEvidence(today.minusDays(3), "Muito pesado", "Muito cansado", false, 6.0)
        ))
        assertTrue(result.canAddWorkout)
        assertEquals("HIGH", result.riskLevel)
        assertTrue(result.riskText.contains("fadiga", ignoreCase = true))
    }

    @Test fun `weekly frequency reference is shown as a warning rather than a prohibition`() {
        val sessions = weekSessions() + RestDaySessionEvidence(
            "mon", LocalDate.of(2026, 11, 9), "Rodagem", "Aeróbio", 4.0, true
        )
        val result = decide(sessions = sessions)
        assertTrue(result.canAddWorkout)
        assertTrue(result.riskText.contains("frequência", ignoreCase = true))
    }

    @Test fun `quality session within 48 hours is disclosed as a risk without blocking the choice`() {
        val sessions = weekSessions() + RestDaySessionEvidence(
            "sat-quality", LocalDate.of(2026, 11, 14), "Intervalado", "Qualidade", 4.0, true
        )
        val result = decide(sessions = sessions)
        assertTrue(result.canAddWorkout)
        assertTrue(result.riskText.contains("exigente", ignoreCase = true))
    }

    @Test fun `long run on Friday keeps Sunday as recovery because session times are unknown`() {
        val sessions = listOf(
            RestDaySessionEvidence("wed", LocalDate.of(2026, 11, 11), "Rodagem aeróbia", "Aeróbio", 5.0, true),
            RestDaySessionEvidence("fri", LocalDate.of(2026, 11, 13), "Longão aeróbio", "Longão", 7.0, true)
        )
        val result = decide(sessions = sessions)
        assertTrue(result.canAddWorkout)
        assertTrue(result.riskText.contains("longão", ignoreCase = true))
    }

    @Test fun `future session earlier than the selected rest day is disclosed as a risk`() {
        val wednesday = LocalDate.of(2026, 11, 11)
        val friday = LocalDate.of(2026, 11, 13)
        val sundayTarget = LocalDate.of(2026, 11, 15)
        val sessions = listOf(
            RestDaySessionEvidence("wed", wednesday, "Rodagem aeróbia", "Aeróbio", 5.0, true),
            RestDaySessionEvidence("fri", friday, "Rodagem aeróbia", "Aeróbio", 5.0, false)
        )
        val result = RestDayAdaptationEngine.recommend(sundayTarget, wednesday, sessions, emptyList(), emptySet(), 18.0, 7.0, false)
        assertTrue(result.canAddWorkout)
        assertTrue(result.riskText.contains("sem registro", ignoreCase = true))
    }

    @Test fun `competition day is not eligible for rest-day consultation`() {
        val result = decide(raceDates = setOf(sunday))
        assertFalse(result.canAddWorkout)
        assertTrue(result.title.contains("competição", ignoreCase = true))
    }

    @Test fun `day with scheduled workout is not eligible for rest-day consultation`() {
        val result = RestDayAdaptationEngine.recommend(
            targetDate = today, today = today,
            sessions = listOf(RestDaySessionEvidence("today", today, "Rodagem", "Aeróbio", 4.0, false)),
            feedback = emptyList(), raceDates = emptySet(), weeklyBaselineKm = 18.0,
            longestRunLast30DaysKm = 7.0, noviceOrReturner = false
        )
        assertFalse(result.canAddWorkout)
        assertTrue(result.title.contains("treino programado", ignoreCase = true))
    }

    @Test fun `missing load history still offers a short time based option and states the uncertainty`() {
        val result = RestDayAdaptationEngine.recommend(
            targetDate = sunday, today = today, sessions = emptyList(), feedback = emptyList(),
            raceDates = emptySet(), weeklyBaselineKm = null, longestRunLast30DaysKm = null,
            noviceOrReturner = true
        )
        assertTrue(result.canAddWorkout)
        assertEquals(12, result.durationMin)
        assertEquals(0.0, result.estimatedDistanceKm, 0.0)
        assertTrue(result.riskText.contains("distância não será estimada", ignoreCase = true))
        assertTrue(result.normalAvailable)
        assertEquals(0.0, result.normalEstimatedDistanceKm, 0.0)
        assertEquals(15, result.normalDurationMin)
        assertTrue(result.normalRiskText.contains("Sem histórico", ignoreCase = true))
    }

    @Test fun `past dates remain unavailable but distant future dates are advisory only`() {
        val past = RestDayAdaptationEngine.recommend(
            today.minusDays(1), today, weekSessions(), emptyList(), emptySet(), 18.0, 7.0, false
        )
        val distant = RestDayAdaptationEngine.recommend(
            today.plusDays(30), today, weekSessions(), emptyList(), emptySet(), 18.0, 7.0, false
        )
        assertFalse(past.canAddWorkout)
        assertTrue(distant.canAddWorkout)
        assertTrue(distant.riskText.contains("mais de 14 dias", ignoreCase = true))
    }

    @Test fun `a previous optional extra is disclosed without blocking another choice`() {
        val sessions = weekSessions() + RestDaySessionEvidence(
            "extra", LocalDate.of(2026, 11, 14), "Rodagem extra", "Recuperação", 2.0, false, true
        )
        val result = decide(sessions = sessions)
        assertTrue(result.canAddWorkout)
        assertTrue(result.riskText.contains("sessão extra", ignoreCase = true))
    }

    @Test fun `missed earlier workout is not transferred but optional choices remain available`() {
        val sessions = weekSessions() + RestDaySessionEvidence(
            "missed-mon", LocalDate.of(2026, 11, 9), "Tempo controlado", "Qualidade", 5.0, false
        )
        val result = decide(sessions = sessions)
        assertTrue(result.canAddWorkout)
        assertTrue(result.explanation.contains("não a repõe"))
        assertTrue(result.normalAvailable)
    }

    @Test fun `two completed sessions leave room for one easy optional session when schedule allows three`() {
        val result = decide(sessions = weekSessions())
        assertTrue(result.canAddWorkout)
        assertEquals(sunday, result.targetDate)
        assertEquals("2-3", result.rpeRange)
        assertTrue(result.normalAvailable)
        assertTrue(result.normalDurationMin >= result.durationMin)
    }

    @Test fun `one 5 km completed run and a missed session allow light and normal options when load supports them`() {
        val sessions = listOf(
            RestDaySessionEvidence("wed", LocalDate.of(2026, 11, 11), "Rodagem aeróbia", "Aeróbio", 5.0, true),
            RestDaySessionEvidence("fri-missed", LocalDate.of(2026, 11, 13), "Rodagem aeróbia", "Aeróbio", 5.0, false)
        )
        val result = RestDayAdaptationEngine.recommend(
            targetDate = sunday, today = sunday, sessions = sessions, feedback = emptyList(),
            raceDates = emptySet(), weeklyBaselineKm = 18.0, longestRunLast30DaysKm = 5.1,
            noviceOrReturner = false, maxWeeklySessions = 3
        )
        assertTrue(result.canAddWorkout)
        assertTrue(result.estimatedDistanceKm > 0.0)
        assertTrue(result.normalAvailable)
        assertTrue(result.normalRiskText.isNotBlank())
    }
}
