package com.airunningcoach.app

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RestDayAdaptationEngineTest {
    private val today = LocalDate.of(2026, 11, 14)
    private val sunday = LocalDate.of(2026, 11, 15)

    private fun weekSessions() = listOf(
        RestDaySessionEvidence("wed", LocalDate.of(2026, 11, 11), "Rodagem aeróbia", "Aeróbio", 5.0, true),
        RestDaySessionEvidence("fri", LocalDate.of(2026, 11, 13), "Rodagem aeróbia", "Aeróbio", 5.0, true)
    )

    private fun decide(
        sessions: List<RestDaySessionEvidence> = weekSessions(),
        feedback: List<RestDayFeedbackEvidence> = emptyList(),
        raceDates: Set<LocalDate> = emptySet()
    ) = RestDayAdaptationEngine.recommend(
        targetDate = sunday,
        today = today,
        sessions = sessions,
        feedback = feedback,
        raceDates = raceDates,
        weeklyBaselineKm = 18.0,
        longestRunLast30DaysKm = 7.0,
        noviceOrReturner = false
    )

    @Test fun `suggests short Z1-only session when week has room and recovery is adequate`() {
        val result = decide()
        assertTrue(result.canAddWorkout)
        assertTrue(result.durationMin in 15..20)
        assertTrue(result.estimatedDistanceKm <= 2.5)
        assertTrue(result.rpeRange == "2-3")
    }

    @Test fun `pain in recent feedback always blocks extra running`() {
        val result = decide(feedback = listOf(
            RestDayFeedbackEvidence(today.minusDays(1), "Leve", "Bem", true, 5.0)
        ))
        assertFalse(result.canAddWorkout)
        assertTrue(result.explanation.contains("dor", ignoreCase = true))
    }

    @Test fun `two strong fatigue signals lead to recovery recommendation`() {
        val result = decide(feedback = listOf(
            RestDayFeedbackEvidence(today.minusDays(1), "Pesado", "Cansado", false, 5.0),
            RestDayFeedbackEvidence(today.minusDays(3), "Muito pesado", "Muito cansado", false, 6.0)
        ))
        assertFalse(result.canAddWorkout)
        assertTrue(result.title.contains("Fadiga"))
    }

    @Test fun `third planned or completed run prevents a fourth session`() {
        val sessions = weekSessions() + RestDaySessionEvidence(
            "mon", LocalDate.of(2026, 11, 9), "Rodagem", "Aeróbio", 4.0, true
        )
        assertFalse(decide(sessions = sessions).canAddWorkout)
    }

    @Test fun `quality session within 48 hours blocks the rest-day addition`() {
        val sessions = weekSessions() + RestDaySessionEvidence(
            "sat-quality", LocalDate.of(2026, 11, 14), "Intervalado", "Qualidade", 4.0, true
        )
        val result = decide(sessions = sessions)
        assertFalse(result.canAddWorkout)
        assertTrue(result.title.contains("recuperação", ignoreCase = true))
    }

    @Test fun `long run on Friday keeps Sunday as recovery because session times are unknown`() {
        val sessions = listOf(
            RestDaySessionEvidence("wed", LocalDate.of(2026, 11, 11), "Rodagem aeróbia", "Aeróbio", 5.0, true),
            RestDaySessionEvidence("fri", LocalDate.of(2026, 11, 13), "Longão aeróbio", "Longão", 7.0, true)
        )
        val result = decide(sessions = sessions)
        assertFalse(result.canAddWorkout)
        assertTrue(result.explanation.contains("horário exato"))
    }

    @Test fun `future session earlier than selected rest day must be resolved first`() {
        val wednesday = LocalDate.of(2026, 11, 11)
        val friday = LocalDate.of(2026, 11, 13)
        val sundayTarget = LocalDate.of(2026, 11, 15)
        val sessions = listOf(
            RestDaySessionEvidence("wed", wednesday, "Rodagem aeróbia", "Aeróbio", 5.0, true),
            RestDaySessionEvidence("fri", friday, "Rodagem aeróbia", "Aeróbio", 5.0, false)
        )
        val result = RestDayAdaptationEngine.recommend(sundayTarget, wednesday, sessions, emptyList(), emptySet(), 18.0, 7.0, false)
        assertFalse(result.canAddWorkout)
        assertTrue(result.title.contains("Aguarde"))
    }

    @Test fun `race date never receives an additional session`() {
        val result = decide(raceDates = setOf(sunday))
        assertFalse(result.canAddWorkout)
        assertTrue(result.title.contains("competição", ignoreCase = true))
    }

    @Test fun `past or excessively distant dates are rejected`() {
        val past = RestDayAdaptationEngine.recommend(
            today.minusDays(1), today, weekSessions(), emptyList(), emptySet(), 18.0, 7.0, false
        )
        val distant = RestDayAdaptationEngine.recommend(
            today.plusDays(15), today, weekSessions(), emptyList(), emptySet(), 18.0, 7.0, false
        )
        assertFalse(past.canAddWorkout)
        assertFalse(distant.canAddWorkout)
    }

    @Test fun `duplicate extra in same week prevents another extra`() {
        val sessions = weekSessions() + RestDaySessionEvidence(
            "extra", LocalDate.of(2026, 11, 14), "Rodagem extra", "Recuperação", 2.0, false, true
        )
        assertFalse(decide(sessions = sessions).canAddWorkout)
    }

    @Test fun `missed earlier workout is not transferred to the requested rest day`() {
        val sessions = weekSessions() + RestDaySessionEvidence(
            "missed-mon", LocalDate.of(2026, 11, 9), "Tempo controlado", "Qualidade", 5.0, false
        )
        val result = decide(sessions = sessions)
        assertFalse(result.canAddWorkout)
        assertTrue(result.title.contains("Não compense"))
    }

    @Test fun `two completed sessions leave room for one easy optional session when schedule allows three`() {
        val result = decide(sessions = weekSessions())
        assertTrue(result.canAddWorkout)
        assertEquals(sunday, result.targetDate)
        assertEquals("2-3", result.rpeRange)
    }
}
