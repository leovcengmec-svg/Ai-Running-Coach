package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RetestProtocolEngineTest {
    private fun assessment(method: String = RetestProtocolEngine.COOPER_12_MIN) = CooperAssessmentRecord(
        dateIso = "2026-11-01",
        distanceKm = if (method == RetestProtocolEngine.THREE_KM) 3.0 else 2.4,
        estimatedVo2Max = 35.0,
        averagePace = "5:00",
        zoneRanges = mapOf("Z1" to "8:00–9:30 min/km", "Z2" to "7:00–8:00 min/km", "Z3" to "6:00–7:00 min/km"),
        testMethod = method,
        testDurationSeconds = if (method == RetestProtocolEngine.THREE_KM) 900 else null,
        referenceSex = RunnerFitnessAssessmentEngine.MALE,
        ageAtTest = 35
    )

    @Test fun `reteste futuro permanece sem protocolo e sem blocos`() {
        val prescription = RetestProtocolEngine.build(assessment())
        assertNull(prescription.method)
        assertTrue(prescription.segments.isEmpty())
        assertEquals(0.0, prescription.distanceKm, 0.001)
        assertEquals(0, prescription.durationMin)
        assertTrue(prescription.detail.contains("escolha"))
    }

    @Test fun `escolha Cooper materializa aquecimento teste de 12 minutos e desaquecimento`() {
        val prescription = RetestProtocolEngine.build(assessment(), RetestProtocolEngine.COOPER_12_MIN)
        assertEquals(RetestProtocolEngine.COOPER_12_MIN, prescription.method)
        assertEquals(listOf("Aquecimento", "Cooper • 12 minutos", "Desaquecimento"), prescription.segments.map { it.name })
        assertEquals("TIME", prescription.segments[1].targetMode)
        assertEquals(12, prescription.segments[1].durationMin)
        assertEquals(2.4, prescription.segments[1].distanceKm!!, 0.001)
        assertEquals(34, prescription.durationMin)
    }

    @Test fun `escolha 3 km materializa distancia fixa e tempo estimado em mmss`() {
        val prescription = RetestProtocolEngine.build(assessment(), RetestProtocolEngine.THREE_KM)
        assertEquals(RetestProtocolEngine.THREE_KM, prescription.method)
        assertEquals("DISTANCE", prescription.segments[1].targetMode)
        assertEquals(3.0, prescription.segments[1].distanceKm!!, 0.001)
        assertEquals(15, prescription.segments[1].durationMin)
        assertTrue(prescription.detail.contains("3 km"))
    }

    @Test fun `troca do ultimo teste de 3 km para Cooper gera estimativa Cooper sem reutilizar 3 km como resultado`() {
        val prescription = RetestProtocolEngine.build(assessment(RetestProtocolEngine.THREE_KM), RetestProtocolEngine.COOPER_12_MIN)
        assertEquals(RetestProtocolEngine.COOPER_12_MIN, prescription.method)
        assertEquals(2.4, prescription.segments[1].distanceKm!!, 0.001)
        assertEquals("TIME", prescription.segments[1].targetMode)
    }

    @Test fun `elegibilidade respeita protocolo e faixa etaria`() {
        assertTrue(RetestProtocolEngine.isMethodEligible(RetestProtocolEngine.COOPER_12_MIN, 55, RunnerFitnessAssessmentEngine.FEMALE))
        assertTrue(RetestProtocolEngine.isMethodEligible(RetestProtocolEngine.THREE_KM, 39, RunnerFitnessAssessmentEngine.MALE))
        assertFalse(RetestProtocolEngine.isMethodEligible(RetestProtocolEngine.THREE_KM, 40, RunnerFitnessAssessmentEngine.MALE))
        assertFalse(RetestProtocolEngine.isMethodEligible(RetestProtocolEngine.COOPER_12_MIN, 17, RunnerFitnessAssessmentEngine.MALE))
        assertFalse(RetestProtocolEngine.isMethodEligible(RetestProtocolEngine.COOPER_12_MIN, 35, ""))
        assertTrue(RetestProtocolEngine.eligibilityMessage(RetestProtocolEngine.THREE_KM, 40, RunnerFitnessAssessmentEngine.MALE) != null)
    }
}
