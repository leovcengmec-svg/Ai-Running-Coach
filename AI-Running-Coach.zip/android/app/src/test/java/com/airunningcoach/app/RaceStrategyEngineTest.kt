package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class RaceStrategyEngineTest {
    private val today = LocalDate.of(2026, 11, 20)
    private val zones = PaceCalculator.calculateCooper(2.6)

    private fun evidence(distance: Double, pace: Int, zone: String = "Z3", index: Int = 0) = RacePaceEvidence(
        date = today.minusDays(index.toLong() + 1), distanceKm = distance, paceSecondsPerKm = pace,
        effort = "Ok", feeling = "Bem", painPresent = false, source = "ACTIVITY",
        workoutType = if (distance >= 10.0) "LONGÃO" else "RODAGEM", sessionId = "session-$index"
    )

    @Test fun `estrategia possui tres fases e cobre distancia da prova de cinco km`() {
        val event = RaceEvent("5k", "Corrida 5 km", 5.0, today.plusDays(30).toString(), "A", "25:00")
        val result = RaceStrategyEngine.build(event, TrainingGoalIntent.PERSONAL_BEST, zones, listOf(
            evidence(5.0, 330, index = 0), evidence(5.0, 328, index = 1), evidence(5.0, 332, index = 2)
        ), today)
        assertEquals(3, result.phases.size)
        assertEquals(5.0, result.phases.sumOf { it.distanceKm }, 0.0001)
        assertEquals("Estratégia de 5 km", result.title)
        assertTrue(result.phases.all { it.fastestPaceSecondsPerKm == null || it.slowestPaceSecondsPerKm!! >= it.fastestPaceSecondsPerKm!! })
    }

    @Test fun `estrategias diferenciam distancias curtas meia e maratona`() {
        fun build(distance: Double) = RaceStrategyEngine.build(
            RaceEvent("race-$distance", "Evento", distance, today.plusDays(40).toString()),
            TrainingGoalIntent.COMPLETE, zones,
            listOf(evidence(15.0, 390, index = 0), evidence(18.0, 395, index = 1), evidence(16.0, 392, index = 2)), today
        )
        val five = build(5.0)
        val tenMiles = build(16.09)
        val half = build(21.1)
        val marathon = build(42.195)
        assertEquals("Z4", five.phases[1].zone)
        assertEquals("Z3", tenMiles.phases[1].zone)
        assertEquals("Z3", half.phases[1].zone)
        assertEquals("Z2", marathon.phases[1].zone)
        assertNotEquals(five.title, marathon.title)
        assertNotNull(marathon.readinessNote)
    }

    @Test fun `prioridade C recebe orientacao de prova de treinamento`() {
        val event = RaceEvent("c", "Prova treino", 10.0, today.plusDays(20).toString(), "C", "50:00")
        val result = RaceStrategyEngine.build(event, TrainingGoalIntent.COMPLETE, zones, listOf(evidence(10.0, 360)), today)
        assertTrue(result.pacingNotes.any { it.contains("estímulo de treinamento") })
    }

    @Test fun `bloco curto nao vira referencia direta de ritmo para a prova`() {
        val event = RaceEvent("short", "10 km", 10.0, today.plusDays(30).toString(), "A", "")
        val shortInterval = RacePaceEvidence(
            date = today.minusDays(1), distanceKm = 0.4, paceSecondsPerKm = 250,
            effort = "Ok", feeling = "Bem", painPresent = false, source = "BLOCK",
            zone = "Z4", sessionId = "interval-session", durationSeconds = 100
        )
        val withoutEvidence = RaceStrategyEngine.build(event, TrainingGoalIntent.COMPLETE, zones, emptyList(), today)
        val withShortInterval = RaceStrategyEngine.build(event, TrainingGoalIntent.COMPLETE, zones, listOf(shortInterval), today)
        assertEquals(withoutEvidence.phases[1].fastestPaceSecondsPerKm, withShortInterval.phases[1].fastestPaceSecondsPerKm)
        assertEquals(0, withShortInterval.evidenceCount)
    }

    @Test fun `bloco sustentado pode contribuir para a estrategia na sua zona`() {
        val event = RaceEvent("sustained", "10 km", 10.0, today.plusDays(30).toString(), "A", "")
        val sustainedBlock = RacePaceEvidence(
            date = today.minusDays(1), distanceKm = 1.2, paceSecondsPerKm = 300,
            effort = "Ok", feeling = "Bem", painPresent = false, source = "BLOCK",
            zone = "Z4", sessionId = "tempo-session", durationSeconds = 420
        )
        val result = RaceStrategyEngine.build(event, TrainingGoalIntent.COMPLETE, zones, listOf(sustainedBlock), today)
        assertEquals(1, result.evidenceCount)
        assertEquals(304, (result.phases[1].fastestPaceSecondsPerKm!! + result.phases[1].slowestPaceSecondsPerKm!!) / 2)
    }

    @Test fun `tempo alvo isolado sem zonas nem treinos nao vira prescricao de ritmo`() {
        val event = RaceEvent("sem-evidencia", "Prova sem histórico", 10.0, today.plusDays(30).toString(), "A", "50:00")
        val result = RaceStrategyEngine.build(event, TrainingGoalIntent.COMPLETE, null, emptyList(), today)
        assertTrue(result.phases.all { it.fastestPaceSecondsPerKm == null && it.slowestPaceSecondsPerKm == null })
        assertTrue(result.targetAssessment.contains("zonas individualizadas"))
        assertNull(result.estimatedTimeMinSeconds)
    }

    @Test fun `meta muito mais rapida que evidencias nao vira ritmo garantido`() {
        val event = RaceEvent("fast", "Meta agressiva", 5.0, today.plusDays(30).toString(), "A", "10:00")
        val result = RaceStrategyEngine.build(event, TrainingGoalIntent.PERSONAL_BEST, zones, listOf(
            evidence(5.0, 360), evidence(5.0, 355, index = 1), evidence(5.0, 358, index = 2)
        ), today)
        assertTrue(result.targetAssessment.contains("mais rápida") || result.targetAssessment.contains("acima"))
        assertTrue(result.pacingNotes.any { it.contains("não foi usado") })
    }
}
