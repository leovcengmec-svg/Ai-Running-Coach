package com.airunningcoach.app

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CooperAssessmentEngineTest {
    @Test
    fun `salva distancia do cooper em km e pace em mm ss`() {
        val record = CooperAssessmentEngine.createRecord(2.4, LocalDate.of(2026, 11, 6))
        assertNotNull(record)
        assertEquals(2.4, record!!.distanceKm, 0.001)
        assertEquals("5:00", record.averagePace)
        assertEquals("4:23", record.estimatedMasPace)
        assertEquals("5:01", record.estimatedSvt2Pace)
        assertTrue(record.estimatedVo2Max > 0.0)
        assertEquals(PaceCalculator.ZONE_MODEL_VERSION, record.zoneModelVersion)
        assertEquals(setOf("Z1", "Z2", "Z3", "Z4", "Z5"), record.zoneRanges.keys)
        assertTrue(record.zoneRanges.values.all { it.endsWith("min/km") })
    }


    @Test
    fun `registro Cooper ignora observacoes legadas de teste da fala para Z2`() {
        val record = CooperAssessmentEngine.createRecord(
            2.1,
            LocalDate.of(2026, 11, 7),
            listOf(440, 445, 443)
        )!!
        val baseline = PaceCalculator.calculateCooper(2.1)!!
        assertEquals(ZoneCalibrationEngine.INITIAL, record.z2CalibrationStatus)
        assertEquals(0, record.talkTestEvidenceCount)
        assertEquals("", record.talkTestReferencePaceMmSs)
        assertEquals(baseline.z2.range.label(), record.zoneRanges["Z2"])
    }

    @Test
    fun `revisao de quatro semanas analisa evidencias sem exigir novo teste maximo`() {
        val date = LocalDate.of(2026, 11, 6)
        val record = CooperAssessmentEngine.createRecord(2.4, date)!!
        assertFalse(CooperAssessmentEngine.reviewStatus(listOf(record), date.plusDays(27)).isDue)
        val review = CooperAssessmentEngine.reviewStatus(listOf(record), date.plusDays(28))
        assertTrue(review.isDue)
        assertTrue(review.message.contains("não é necessário repetir agora um teste máximo"))
        assertTrue(review.message.contains("7ª e a 8ª semana"))
    }

    @Test
    fun `data de cooper no onboarding deve estar no passado e ter ate oito semanas`() {
        val today = LocalDate.of(2026, 11, 6)
        assertEquals(LocalDate.of(2026, 10, 10), CooperAssessmentEngine.parseAssessmentDate("10/10/2026"))
        assertNull(CooperAssessmentEngine.parseAssessmentDate("31/02/2026"))
        assertTrue(CooperAssessmentEngine.isRecentAssessmentDate(today.minusDays(56), today))
        assertFalse(CooperAssessmentEngine.isRecentAssessmentDate(today.minusDays(57), today))
        assertFalse(CooperAssessmentEngine.isRecentAssessmentDate(today.plusDays(1), today))
    }

    @Test
    fun `calibracao encontra o cooper anterior ao resultado atual mesmo com historico fora de ordem`() {
        val older = CooperAssessmentEngine.createRecord(2.20, LocalDate.of(2026, 9, 1))!!
        val previous = CooperAssessmentEngine.createRecord(2.35, LocalDate.of(2026, 10, 1))!!
        val current = CooperAssessmentEngine.createRecord(2.50, LocalDate.of(2026, 11, 1))!!

        assertEquals(2.35, CooperAssessmentEngine.previousAssessmentDistance(
            listOf(current, older, previous), current.dateIso
        )!!, 0.001)
        assertEquals(2.50, CooperAssessmentEngine.previousAssessmentDistance(
            listOf(current, older, previous), null
        )!!, 0.001)
        assertNull(CooperAssessmentEngine.previousAssessmentDistance(listOf(current), current.dateIso))
    }

    @Test
    fun `melhora de distancia do cooper e calculada em ordem cronologica`() {
        val first = CooperAssessmentEngine.createRecord(2.3, LocalDate.of(2026, 10, 1))!!
        val second = CooperAssessmentEngine.createRecord(2.4, LocalDate.of(2026, 10, 29))!!
        assertEquals(100.0 * (2.4 - 2.3) / 2.3, CooperAssessmentEngine.improvementSincePrevious(listOf(second, first))!!, 0.001)
        assertNull(CooperAssessmentEngine.improvementSincePrevious(listOf(first)))
    }

    @Test
    fun `data da ultima avaliacao e escolhida mesmo se historico vier fora de ordem`() {
        val old = CooperAssessmentEngine.createRecord(2.2, LocalDate.of(2026, 10, 1))!!
        val recent = CooperAssessmentEngine.createRecord(2.4, LocalDate.of(2026, 11, 1))!!
        val status = CooperAssessmentEngine.reviewStatus(listOf(recent, old), LocalDate.of(2026, 11, 20))
        assertEquals(LocalDate.of(2026, 11, 29), status.nextReviewDate)
    }

    @Test fun `registro de 3 km preserva metodo tempo idade e referencia fisiologica`() {
        val record = CooperAssessmentEngine.createThreeKmRecord(
            timeSeconds = 15 * 60,
            date = java.time.LocalDate.of(2026, 11, 17),
            referenceSex = RunnerFitnessAssessmentEngine.MALE,
            ageAtTest = 32
        )!!
        assertEquals("THREE_KM", record.testMethod)
        assertEquals(900, record.testDurationSeconds)
        assertEquals(3.0, record.distanceKm, 0.001)
        assertEquals(RunnerFitnessAssessmentEngine.MALE, record.referenceSex)
        assertEquals(32, record.ageAtTest)
        assertTrue(record.zoneRanges.keys.containsAll(listOf("Z1", "Z2", "Z3", "Z4", "Z5")))
    }
}
