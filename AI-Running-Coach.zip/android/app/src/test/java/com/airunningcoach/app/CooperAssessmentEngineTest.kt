package com.airunningcoach.app

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CooperAssessmentEngineTest {
    @Test
    fun `salva distancia do cooper em km e pace em mm ss`() {
        val record = CooperAssessmentEngine.createRecord(2.4, LocalDate.of(2026, 11, 6))
        assertNotNull(record)
        assertEquals(2.4, record!!.distanceKm, 0.001)
        assertEquals("5:00", record.averagePace)
        assertEquals("4:23", record.estimatedMasPace)
        assertEquals("5:01", record.estimatedSvt2Pace)
        assertTrue(record.estimatedVo2Max > 0.0)
        assertEquals(PaceCalculator.ZONE_MODEL_VERSION, record.zoneModelVersion)
        assertEquals(setOf("Z1", "Z2", "Z3", "Z4", "Z5"), record.zoneRanges.keys)
        assertTrue(record.zoneRanges.values.all { it.endsWith("min/km") })
    }


    @Test
    fun `registro cooper congela z2 personalizada quando ha duas observacoes consistentes`() {
        val record = CooperAssessmentEngine.createRecord(
            2.1,
            LocalDate.of(2026, 11, 7),
            listOf(440, 445)
        )!!
        assertEquals("TALK_TEST_CONFIRMED", record.z2CalibrationStatus)
        assertEquals(2, record.talkTestEvidenceCount)
        assertEquals("7:23", record.talkTestReferencePaceMmSs)
        assertEquals("7:33–8:10 min/km", record.zoneRanges["Z2"])
    }

    @Test
    fun `revisao fica disponivel depois de quatro semanas`() {
        val date = LocalDate.of(2026, 11, 6)
        val record = CooperAssessmentEngine.createRecord(2.4, date)!!
        assertFalse(CooperAssessmentEngine.reviewStatus(listOf(record), date.plusDays(27)).isDue)
        assertTrue(CooperAssessmentEngine.reviewStatus(listOf(record), date.plusDays(28)).isDue)
    }

    @Test
    fun `data de cooper no onboarding deve estar no passado e ter ate oito semanas`() {
        val today = LocalDate.of(2026, 11, 6)
        assertEquals(LocalDate.of(2026, 10, 10), CooperAssessmentEngine.parseAssessmentDate("10/10/2026"))
        assertNull(CooperAssessmentEngine.parseAssessmentDate("31/02/2026"))
        assertTrue(CooperAssessmentEngine.isRecentAssessmentDate(today.minusDays(56), today))
        assertFalse(CooperAssessmentEngine.isRecentAssessmentDate(today.minusDays(57), today))
        assertFalse(CooperAssessmentEngine.isRecentAssessmentDate(today.plusDays(1), today))
    }

    @Test
    fun `calibracao encontra o cooper anterior ao resultado atual mesmo com historico fora de ordem`() {
        val older = CooperAssessmentEngine.createRecord(2.20, LocalDate.of(2026, 9, 1))!!
        val previous = CooperAssessmentEngine.createRecord(2.35, LocalDate.of(2026, 10, 1))!!
        val current = CooperAssessmentEngine.createRecord(2.50, LocalDate.of(2026, 11, 1))!!

        assertEquals(2.35, CooperAssessmentEngine.previousAssessmentDistance(
            listOf(current, older, previous), current.dateIso
        )!!, 0.001)
        assertEquals(2.50, CooperAssessmentEngine.previousAssessmentDistance(
            listOf(current, older, previous), null
        )!!, 0.001)
        assertNull(CooperAssessmentEngine.previousAssessmentDistance(listOf(current), current.dateIso))
    }

    @Test
    fun `melhora de distancia do cooper e calculada em ordem cronologica`() {
        val first = CooperAssessmentEngine.createRecord(2.3, LocalDate.of(2026, 10, 1))!!
        val second = CooperAssessmentEngine.createRecord(2.4, LocalDate.of(2026, 10, 29))!!
        assertEquals(100.0 * (2.4 - 2.3) / 2.3, CooperAssessmentEngine.improvementSincePrevious(listOf(second, first))!!, 0.001)
        assertNull(CooperAssessmentEngine.improvementSincePrevious(listOf(first)))
    }

    @Test
    fun `data da ultima avaliacao e escolhida mesmo se historico vier fora de ordem`() {
        val old = CooperAssessmentEngine.createRecord(2.2, LocalDate.of(2026, 10, 1))!!
        val recent = CooperAssessmentEngine.createRecord(2.4, LocalDate.of(2026, 11, 1))!!
        val status = CooperAssessmentEngine.reviewStatus(listOf(recent, old), LocalDate.of(2026, 11, 20))
        assertEquals(LocalDate.of(2026, 11, 29), status.nextReviewDate)
    }
}
