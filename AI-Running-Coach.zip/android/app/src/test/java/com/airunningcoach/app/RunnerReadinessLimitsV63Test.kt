package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Test

class RunnerReadinessLimitsV63Test {
    @Test
    fun `matriz aceita volumes e maiores sessoes de ultradistancia`() {
        val result = RunnerReadinessEngine.evaluate(
            RunnerReadinessInput(
                goalKm = 160.934,
                goalCategory = "PERFORMANCE",
                declaredLevel = "Elite",
                experienceMonths = 120,
                selectedFrequency = 6,
                weeklyVolumeKm = 180.0,
                longestRecentKm = 70.0,
                activeWeeksLast4 = 4
            )
        )
        assertEquals("Elite", result.prescriptionLevel)
        assertEquals(180.0, result.initialRecommendedWeeklyKm, 0.01)
    }
}
