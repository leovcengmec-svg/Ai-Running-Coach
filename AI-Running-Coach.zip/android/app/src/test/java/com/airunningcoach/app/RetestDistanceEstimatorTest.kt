package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RetestDistanceEstimatorTest {
    private fun assessment(method: String = "COOPER_12_MIN", distance: Double = 2.4, zones: Map<String, String> = mapOf(
        "Z1" to "8:00–9:30 min/km",
        "Z2" to "7:00–8:00 min/km",
        "Z3" to "6:00–7:00 min/km"
    )) = CooperAssessmentRecord(
        dateIso = "2026-11-01", distanceKm = distance, estimatedVo2Max = 35.0,
        averagePace = "5:00", zoneRanges = zones, testMethod = method
    )

    @Test fun `Cooper soma aquecimento ultimo resultado e desaquecimento estimados`() {
        val estimate = RetestDistanceEstimator.estimate(assessment())
        assertEquals(2.4, estimate.testKm!!, 0.001)
        assertEquals(1.52, estimate.warmupKm!!, 0.01)
        assertEquals(1.27, estimate.cooldownKm!!, 0.01)
        assertEquals(5.19, estimate.totalKm, 0.02)
        assertFalse(estimate.isPartial)
    }

    @Test fun `teste de tres km usa distancia fixa mais blocos faceis estimados`() {
        val estimate = RetestDistanceEstimator.estimate(assessment(method = "THREE_KM", distance = 3.0))
        assertEquals(3.0, estimate.testKm!!, 0.001)
        assertEquals(5.79, estimate.totalKm, 0.03)
        assertFalse(estimate.isPartial)
    }

    @Test fun `Cooper pode ser estimado a partir do ritmo medio de um ultimo teste de 3 km`() {
        val estimate = RetestDistanceEstimator.estimate(
            assessment(method = "THREE_KM", distance = 3.0),
            testMethodOverride = "COOPER_12_MIN"
        )
        assertEquals(2.4, estimate.testKm!!, 0.001)
    }

    @Test fun `sem zona facil informa estimativa parcial sem inventar aquecimento`() {
        val estimate = RetestDistanceEstimator.estimate(assessment(zones = emptyMap()))
        assertEquals(2.4, estimate.totalKm, 0.001)
        assertTrue(estimate.warmupKm == null)
        assertTrue(estimate.cooldownKm == null)
        assertTrue(estimate.isPartial)
    }
}
