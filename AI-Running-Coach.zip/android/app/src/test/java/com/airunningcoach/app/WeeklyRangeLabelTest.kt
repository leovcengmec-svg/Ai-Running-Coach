package com.airunningcoach.app

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Test

class WeeklyRangeLabelTest {
    @Test fun `same month shows Monday through Sunday dates`() {
        assertEquals("09–15/11", WeeklyRangeLabel.fromActivityDate(LocalDate.of(2026, 11, 11)))
    }

    @Test fun `cross month shows both month and day`() {
        assertEquals("30/11–06/12", WeeklyRangeLabel.fromActivityDate(LocalDate.of(2026, 12, 2)))
    }

    @Test fun `cross year shows full dates`() {
        assertEquals("28/12/2026–03/01/2027", WeeklyRangeLabel.fromActivityDate(LocalDate.of(2026, 12, 30)))
    }
}
