package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LoadPrescriptionEngineV63Test {
    @Test fun `sem volume informado usa base fixa do objetivo em vez de tres km`() {
        val plan = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(
                currentWeeklyKm = 0.0, activeWeeksLast4 = -1, measuredHistoryReliable = false,
                weeks = 8, longestRecentKm = 0.0, profileBaselineConfirmed = true,
                goalBaseKm = 45.0, explicitNoRecentTraining = false, referenceMaxKm = 80.0
            )
        )
        assertEquals(45.0, plan.first().targetKm, 0.01)
        assertTrue(plan[1].targetKm > plan[0].targetKm)
    }

    @Test fun `zero semanal e zero percurso declarados preservam reintroducao`() {
        val plan = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(
                currentWeeklyKm = 0.0, activeWeeksLast4 = 0, measuredHistoryReliable = false,
                weeks = 8, longestRecentKm = 0.0, goalBaseKm = 45.0,
                explicitNoRecentTraining = true, referenceMaxKm = 80.0
            )
        )
        assertEquals(3.0, plan.first().targetKm, 0.01)
        assertTrue(plan.first().rationale.contains("Reintrodução"))
    }

    @Test
    fun `historico confiavel permite progressao moderada sem ultrapassar referencia`() {
        val plan = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(
                currentWeeklyKm = 28.0,
                activeWeeksLast4 = 4,
                measuredHistoryReliable = true,
                recoveryScore = 85.0,
                fatigueScore = 30.0,
                weeks = 8,
                longestRecentKm = 12.0,
                recentLoadTrendRatio = 0.9,
                averageRpe = 4.5,
                referenceMaxKm = 35.0
            )
        )
        assertEquals(28.0, plan.first().targetKm, 0.01)
        assertTrue(plan[1].targetKm > plan[0].targetKm)
        assertEquals(5, plan[1].maxGrowthPercent)
    }

    @Test
    fun `um sinal moderado reduz mas nao congela todo o ciclo`() {
        val highRpe = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(20.0, 4, true, 80.0, 20.0, 8, averageRpe = 8.0)
        )
        val highTrend = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(20.0, 4, true, 80.0, 20.0, 8, recentLoadTrendRatio = 1.5)
        )
        assertEquals(2, highRpe[1].maxGrowthPercent)
        assertEquals(2, highTrend[1].maxGrowthPercent)
        assertTrue(highRpe[1].targetKm > highRpe[0].targetKm)
        assertTrue(highTrend[1].targetKm > highTrend[0].targetKm)
    }

    @Test
    fun `sinais moderados simultaneos reduzem progressao a um por cento`() {
        val plan = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(20.0, 4, true, 70.0, 68.0, 8, averageRpe = 8.0, recentLoadTrendRatio = 1.5)
        )
        assertEquals(1, plan[1].maxGrowthPercent)
        assertTrue(plan[1].targetKm > plan[0].targetKm)
    }

    @Test
    fun `recuperacao muito baixa ou fadiga severa segura progressao`() {
        val lowRecovery = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(20.0, 4, true, 45.0, 20.0, 8)
        )
        val severeFatigue = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(20.0, 4, true, 80.0, 80.0, 8)
        )
        assertEquals(0, lowRecovery[1].maxGrowthPercent)
        assertEquals(0, severeFatigue[1].maxGrowthPercent)
        assertTrue(lowRecovery[1].rationale.contains("suspensa"))
    }

    @Test
    fun `perfil 5k com base 16km nao fica limitado a repeticao de 16km`() {
        val plan = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(
                currentWeeklyKm = 16.0, activeWeeksLast4 = 4, measuredHistoryReliable = true,
                recoveryScore = 80.0, fatigueScore = 20.0, weeks = 8, longestRecentKm = 10.0,
                averageRpe = 8.0, referenceMinKm = 12.0, referenceMaxKm = 22.5
            )
        )
        assertEquals(16.0, plan[0].targetKm, 0.01)
        assertEquals(16.3, plan[1].targetKm, 0.01)
        assertEquals(16.6, plan[2].targetKm, 0.01)
        assertTrue(plan[4].targetKm > plan[2].targetKm)
        assertTrue(plan.drop(1).all { it.targetKm <= 22.5 })
    }

    @Test
    fun `progressao nao ultrapassa teto de referencia`() {
        val plan = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(
                currentWeeklyKm = 34.0,
                activeWeeksLast4 = 4,
                measuredHistoryReliable = true,
                recoveryScore = 90.0,
                fatigueScore = 20.0,
                weeks = 8,
                longestRecentKm = 14.0,
                recentLoadTrendRatio = 0.9,
                averageRpe = 4.0,
                referenceMaxKm = 35.0
            )
        )
        assertEquals(35.0, plan[1].targetKm, 0.01)
        assertTrue(plan.drop(1).all { it.targetKm <= 35.0 })
    }

    @Test
    fun `base acima da referencia nao e reduzida e recupera apos semana leve`() {
        val plan = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(
                currentWeeklyKm = 40.0,
                activeWeeksLast4 = 4,
                measuredHistoryReliable = true,
                recoveryScore = 90.0,
                fatigueScore = 20.0,
                weeks = 8,
                longestRecentKm = 16.0,
                recentLoadTrendRatio = 0.9,
                averageRpe = 4.0,
                referenceMaxKm = 35.0
            )
        )
        assertEquals(40.0, plan.first().targetKm, 0.01)
        assertEquals(40.0, plan[1].targetKm, 0.01)
        assertTrue(plan[4].targetKm > plan[3].targetKm)
        assertTrue(plan.all { it.targetKm <= 40.0 })
    }

    @Test
    fun `volume e maior sessao suportam ultradistancia sem faixa antiga truncada`() {
        val plan = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(180.0, 4, true, 85.0, 25.0, 8, longestRecentKm = 60.0, referenceMaxKm = 200.0)
        )
        assertEquals(180.0, plan.first().targetKm, 0.01)
    }
    @Test
    fun `deload nao apaga referencia de construcao e volume retoma acima do ciclo anterior`() {
        val plan = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(
                currentWeeklyKm = 16.0, activeWeeksLast4 = 4, measuredHistoryReliable = true,
                recoveryScore = 85.0, fatigueScore = 30.0, weeks = 8, longestRecentKm = 10.0,
                recentLoadTrendRatio = 0.9, averageRpe = 4.5, referenceMinKm = 20.0, referenceMaxKm = 30.0
            )
        )
        assertEquals(16.0, plan[0].targetKm, 0.01)
        assertEquals(16.8, plan[1].targetKm, 0.01)
        assertEquals(17.6, plan[2].targetKm, 0.01)
        assertEquals(13.2, plan[3].targetKm, 0.11)
        assertTrue(plan[4].targetKm > plan[2].targetKm)
        assertTrue(plan[4].rationale.contains("limite inferior de referência"))
    }

    @Test fun `consistencia desconhecida ou retorno nao congelam a progressao`() {
        val unknown = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(
                currentWeeklyKm = 16.0, activeWeeksLast4 = -1, measuredHistoryReliable = false,
                recoveryScore = 85.0, fatigueScore = 30.0, weeks = 8, longestRecentKm = 10.0
            )
        )
        val returning = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(
                currentWeeklyKm = 0.0, activeWeeksLast4 = 0, measuredHistoryReliable = false,
                recoveryScore = 85.0, fatigueScore = 30.0, weeks = 8, longestRecentKm = 0.0
            )
        )
        assertTrue(unknown[1].targetKm > unknown[0].targetKm)
        assertTrue(unknown[4].targetKm > unknown[2].targetKm)
        assertTrue(returning[1].targetKm > returning[0].targetKm)
        assertTrue(returning[4].targetKm > returning[2].targetKm)
    }

    @Test fun `ausencia de semanas registradas nao reduz pela metade uma dose semanal declarada com maior corrida recente`() {
        val plan = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(
                currentWeeklyKm = 6.0, activeWeeksLast4 = 0, measuredHistoryReliable = false,
                recoveryScore = null, fatigueScore = null, weeks = 8, longestRecentKm = 10.0,
                profileBaselineConfirmed = false
            )
        )
        assertEquals(6.0, plan.first().targetKm, 0.01)
        assertTrue(plan[1].targetKm >= plan[0].targetKm)
        assertEquals(4.5, plan[3].targetKm, 0.11)
        assertTrue(plan[4].targetKm > plan[3].targetKm)
    }

}
