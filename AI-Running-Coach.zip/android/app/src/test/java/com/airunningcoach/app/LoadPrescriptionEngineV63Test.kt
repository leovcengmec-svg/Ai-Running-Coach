package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LoadPrescriptionEngineV63Test {
    @Test
    fun `historico confiavel permite progressao moderada sem ultrapassar referencia`() {
        val plan = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(
                currentWeeklyKm = 28.0,
                activeWeeksLast4 = 4,
                measuredHistoryReliable = true,
                recoveryScore = 85.0,
                fatigueScore = 30.0,
                weeks = 8,
                longestRecentKm = 12.0,
                recentLoadTrendRatio = 0.9,
                averageRpe = 4.5,
                referenceMaxKm = 35.0
            )
        )
        assertEquals(28.0, plan.first().targetKm, 0.01)
        assertTrue(plan[1].targetKm > plan[0].targetKm)
        assertEquals(5, plan[1].maxGrowthPercent)
    }

    @Test
    fun `RPE alto ou tendencia sRPE muito elevada interrompe progressao`() {
        val highRpe = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(20.0, 4, true, 80.0, 20.0, 8, averageRpe = 8.0)
        )
        val highTrend = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(20.0, 4, true, 80.0, 20.0, 8, recentLoadTrendRatio = 1.5)
        )
        assertEquals(0, highRpe[1].maxGrowthPercent)
        assertEquals(0, highTrend[1].maxGrowthPercent)
    }

    @Test
    fun `progressao nao ultrapassa teto de referencia`() {
        val plan = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(
                currentWeeklyKm = 34.0,
                activeWeeksLast4 = 4,
                measuredHistoryReliable = true,
                recoveryScore = 90.0,
                fatigueScore = 20.0,
                weeks = 8,
                longestRecentKm = 14.0,
                recentLoadTrendRatio = 0.9,
                averageRpe = 4.0,
                referenceMaxKm = 35.0
            )
        )
        assertEquals(35.0, plan[1].targetKm, 0.01)
        assertTrue(plan.drop(1).all { it.targetKm <= 35.0 })
    }

    @Test
    fun `base acima da referencia nao e reduzida e recupera apos semana leve`() {
        val plan = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(
                currentWeeklyKm = 40.0,
                activeWeeksLast4 = 4,
                measuredHistoryReliable = true,
                recoveryScore = 90.0,
                fatigueScore = 20.0,
                weeks = 8,
                longestRecentKm = 16.0,
                recentLoadTrendRatio = 0.9,
                averageRpe = 4.0,
                referenceMaxKm = 35.0
            )
        )
        assertEquals(40.0, plan.first().targetKm, 0.01)
        assertEquals(40.0, plan[1].targetKm, 0.01)
        assertTrue(plan[4].targetKm > plan[3].targetKm)
        assertTrue(plan.all { it.targetKm <= 40.0 })
    }

    @Test
    fun `volume e maior sessao suportam ultradistancia sem faixa antiga truncada`() {
        val plan = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(180.0, 4, true, 85.0, 25.0, 8, longestRecentKm = 60.0, referenceMaxKm = 200.0)
        )
        assertEquals(180.0, plan.first().targetKm, 0.01)
    }
    @Test
    fun `deload nao apaga referencia de construcao e volume retoma acima do ciclo anterior`() {
        val plan = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(
                currentWeeklyKm = 16.0, activeWeeksLast4 = 4, measuredHistoryReliable = true,
                recoveryScore = 85.0, fatigueScore = 30.0, weeks = 8, longestRecentKm = 10.0,
                recentLoadTrendRatio = 0.9, averageRpe = 4.5, referenceMinKm = 20.0, referenceMaxKm = 30.0
            )
        )
        assertEquals(16.0, plan[0].targetKm, 0.01)
        assertEquals(16.8, plan[1].targetKm, 0.01)
        assertEquals(17.6, plan[2].targetKm, 0.01)
        assertEquals(15.0, plan[3].targetKm, 0.11)
        assertTrue(plan[4].targetKm > plan[2].targetKm)
        assertTrue(plan[4].rationale.contains("limite inferior de referência"))
    }

    @Test fun `consistencia desconhecida ou retorno nao congelam a progressao`() {
        val unknown = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(
                currentWeeklyKm = 16.0, activeWeeksLast4 = -1, measuredHistoryReliable = false,
                recoveryScore = 85.0, fatigueScore = 30.0, weeks = 8, longestRecentKm = 10.0
            )
        )
        val returning = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(
                currentWeeklyKm = 0.0, activeWeeksLast4 = 0, measuredHistoryReliable = false,
                recoveryScore = 85.0, fatigueScore = 30.0, weeks = 8, longestRecentKm = 0.0
            )
        )
        assertTrue(unknown[1].targetKm > unknown[0].targetKm)
        assertTrue(unknown[4].targetKm > unknown[2].targetKm)
        assertTrue(returning[1].targetKm > returning[0].targetKm)
        assertTrue(returning[4].targetKm > returning[2].targetKm)
    }

}
