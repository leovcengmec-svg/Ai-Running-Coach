package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LoadPrescriptionEngineV63Test {
    @Test
    fun `historico confiavel permite progressao moderada sem ultrapassar referencia`() {
        val plan = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(
                currentWeeklyKm = 28.0,
                activeWeeksLast4 = 4,
                measuredHistoryReliable = true,
                recoveryScore = 85.0,
                fatigueScore = 30.0,
                weeks = 8,
                longestRecentKm = 12.0,
                recentLoadTrendRatio = 0.9,
                averageRpe = 4.5,
                referenceMaxKm = 35.0
            )
        )
        assertEquals(28.0, plan.first().targetKm, 0.01)
        assertTrue(plan[1].targetKm > plan[0].targetKm)
        assertEquals(5, plan[1].maxGrowthPercent)
    }

    @Test
    fun `RPE alto ou tendencia sRPE muito elevada interrompe progressao`() {
        val highRpe = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(20.0, 4, true, 80.0, 20.0, 8, averageRpe = 8.0)
        )
        val highTrend = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(20.0, 4, true, 80.0, 20.0, 8, recentLoadTrendRatio = 1.5)
        )
        assertEquals(0, highRpe[1].maxGrowthPercent)
        assertEquals(0, highTrend[1].maxGrowthPercent)
    }

    @Test
    fun `progressao nao ultrapassa teto de referencia`() {
        val plan = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(
                currentWeeklyKm = 34.0,
                activeWeeksLast4 = 4,
                measuredHistoryReliable = true,
                recoveryScore = 90.0,
                fatigueScore = 20.0,
                weeks = 8,
                longestRecentKm = 14.0,
                recentLoadTrendRatio = 0.9,
                averageRpe = 4.0,
                referenceMaxKm = 35.0
            )
        )
        assertEquals(35.0, plan[1].targetKm, 0.01)
        assertTrue(plan.drop(1).all { it.targetKm <= 35.0 })
    }

    @Test
    fun `base acima da referencia nao e reduzida e recupera apos semana leve`() {
        val plan = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(
                currentWeeklyKm = 40.0,
                activeWeeksLast4 = 4,
                measuredHistoryReliable = true,
                recoveryScore = 90.0,
                fatigueScore = 20.0,
                weeks = 8,
                longestRecentKm = 16.0,
                recentLoadTrendRatio = 0.9,
                averageRpe = 4.0,
                referenceMaxKm = 35.0
            )
        )
        assertEquals(40.0, plan.first().targetKm, 0.01)
        assertEquals(40.0, plan[1].targetKm, 0.01)
        assertTrue(plan[4].targetKm > plan[3].targetKm)
        assertTrue(plan.all { it.targetKm <= 40.0 })
    }

    @Test
    fun `volume e maior sessao suportam ultradistancia sem faixa antiga truncada`() {
        val plan = LoadPrescriptionEngine.build(
            LoadPrescriptionInput(180.0, 4, true, 85.0, 25.0, 8, longestRecentKm = 60.0, referenceMaxKm = 200.0)
        )
        assertEquals(180.0, plan.first().targetKm, 0.01)
    }
}
