package com.airunningcoach.app

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TrainingLoadEngineTest {
    private val today = LocalDate.of(2026, 11, 9)

    @Test
    fun `historico parcial nao substitui o volume informado no perfil`() {
        val activities = listOf(
            LoggedRunActivity(today.minusDays(2), 5.0),
            LoggedRunActivity(today.minusDays(8), 6.0),
            LoggedRunActivity(today.minusDays(15), 7.0),
            LoggedRunActivity(today.minusDays(25), 4.0)
        )
        val snapshot = TrainingLoadEngine.summarize(activities, today)
        assertFalse(snapshot.reliable)
        assertEquals(5.5, snapshot.averageWeeklyKmLast28Days!!, 0.01)
        assertEquals(4, snapshot.recordedRunsLast28Days)
    }

    @Test
    fun `historico suficiente calcula media real das ultimas quatro semanas`() {
        val activities = listOf(
            LoggedRunActivity(today.minusDays(1), 5.0),
            LoggedRunActivity(today.minusDays(3), 4.0),
            LoggedRunActivity(today.minusDays(8), 6.0),
            LoggedRunActivity(today.minusDays(10), 5.0),
            LoggedRunActivity(today.minusDays(15), 7.0),
            LoggedRunActivity(today.minusDays(16), 5.0)
        )
        val snapshot = TrainingLoadEngine.summarize(activities, today)
        assertFalse(snapshot.reliable)
        val reconciled = TrainingLoadEngine.summarize(activities, today, LocalDate.of(2026, 11, 8))
        assertTrue(reconciled.reliable)
        assertEquals(32.0, snapshot.totalKmLast28Days, 0.01)
        assertEquals(8.0, snapshot.averageWeeklyKmLast28Days!!, 0.01)
        assertEquals(8.0, reconciled.completeFourWeekAverageKm!!, 0.01)
        assertEquals(7.0, reconciled.completeFourWeekLongestRunKm!!, 0.01)
        assertEquals(7.0, snapshot.longestRunLast30DaysKm!!, 0.01)
        assertEquals(3, snapshot.activeWeeksLast28Days)
        assertEquals(LocalDate.of(2026, 10, 12), snapshot.completeFourWeekStart)
        assertEquals(LocalDate.of(2026, 11, 8), snapshot.completeFourWeekEnd)
    }

    @Test
    fun `seis atividades em tres semanas no inicio da terceira semana nao liberam historico`() {
        val activities = listOf(
            LoggedRunActivity(today.minusDays(1), 5.8),
            LoggedRunActivity(today.minusDays(4), 5.0),
            LoggedRunActivity(today.minusDays(8), 6.0),
            LoggedRunActivity(today.minusDays(10), 5.0),
            LoggedRunActivity(today.minusDays(12), 4.0),
            LoggedRunActivity(today.minusDays(15), 5.0)
        )
        val snapshot = TrainingLoadEngine.summarize(activities, today)
        assertEquals(6, snapshot.recordedRunsLast28Days)
        assertTrue(snapshot.activeWeeksLast28Days >= 3)
        assertFalse(snapshot.reliable)
    }

    @Test
    fun `atividade fora da janela nao entra no volume nem na maior corrida`() {
        val activities = listOf(
            LoggedRunActivity(today.minusDays(3), 5.0),
            LoggedRunActivity(today.minusDays(10), 5.0),
            LoggedRunActivity(today.minusDays(17), 5.0),
            LoggedRunActivity(today.minusDays(25), 5.0),
            LoggedRunActivity(today.minusDays(31), 25.0)
        )
        val snapshot = TrainingLoadEngine.summarize(activities, today)
        assertEquals(20.0, snapshot.totalKmLast28Days, 0.01)
        assertEquals(5.0, snapshot.longestRunLast30DaysKm!!, 0.01)
    }

    @Test
    fun `media de 42 dias e descritiva mesmo com historico parcial`() {
        val enough = listOf(
            LoggedRunActivity(today.minusDays(1), 5.0),
            LoggedRunActivity(today.minusDays(3), 4.0),
            LoggedRunActivity(today.minusDays(8), 6.0),
            LoggedRunActivity(today.minusDays(10), 5.0),
            LoggedRunActivity(today.minusDays(22), 7.0),
            LoggedRunActivity(today.minusDays(25), 5.0)
        )
        val snapshot = TrainingLoadEngine.summarize(enough, today)
        assertEquals(6, snapshot.recordedRunsLast42Days)
        assertTrue(snapshot.activeWeeksLast42Days >= 3)
        assertEquals(5.3, snapshot.averageWeeklyKmLast42Days!!, 0.01)

        val insufficient = TrainingLoadEngine.summarize(enough.take(5), today)
        assertEquals(4.5, insufficient.averageWeeklyKmLast42Days!!, 0.01)
        assertFalse(insufficient.reliable)
        assertEquals(5, insufficient.recordedRunsLast42Days)
    }

    @Test
    fun `ignora distancia ausente negativa nao finita e data futura`() {
        val activities = listOf(
            LoggedRunActivity(today.minusDays(1), 5.0),
            LoggedRunActivity(today.minusDays(4), -3.0),
            LoggedRunActivity(today.minusDays(7), Double.NaN),
            LoggedRunActivity(today.plusDays(1), 12.0)
        )
        val snapshot = TrainingLoadEngine.summarize(activities, today)
        assertEquals(1, snapshot.recordedRunsLast28Days)
        assertEquals(5.0, snapshot.totalKmLast28Days, 0.01)
    }
}
