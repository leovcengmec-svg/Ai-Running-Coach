package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId
import java.time.Instant

class ActivityDateResolverTest {
    private val zone = ZoneId.of("America/Sao_Paulo")

    @Test fun `timestamp original importado vence data persistida antiga e data planejada`() {
        val date = ActivityDateResolver.resolve(
            realizedDateIso = "2026-11-15",
            activityStartedAtIso = "2026-11-17T02:30:00Z",
            activitySourceFormat = "FIT",
            scheduledDateIso = "2026-11-16",
            savedAtMillis = 0L,
            zoneId = zone
        )
        assertEquals(LocalDate.parse("2026-11-16"), date)
    }

    @Test fun `timestamp original importado tem prioridade sobre a data persistida`() {
        val date = ActivityDateResolver.resolve(
            realizedDateIso = "2026-11-15",
            activityStartedAtIso = "2026-11-17T02:30:00Z",
            activitySourceFormat = "FIT",
            scheduledDateIso = "2026-11-14",
            savedAtMillis = Instant.parse("2026-11-18T12:00:00Z").toEpochMilli(),
            zoneId = zone
        )
        assertEquals(LocalDate.parse("2026-11-16"), date)
    }

    @Test fun `registro antigo importado sem timestamp usa data de salvamento e nao data planejada`() {
        val date = ActivityDateResolver.resolve(
            realizedDateIso = "",
            activityStartedAtIso = "",
            activitySourceFormat = "GPX",
            scheduledDateIso = "2026-11-10",
            savedAtMillis = Instant.parse("2026-11-17T02:30:00Z").toEpochMilli(),
            zoneId = zone
        )
        assertEquals(LocalDate.parse("2026-11-16"), date)
    }

    @Test fun `feedback manual legado preserva fallback para data programada`() {
        val date = ActivityDateResolver.resolve(
            realizedDateIso = "",
            activityStartedAtIso = "",
            activitySourceFormat = "",
            scheduledDateIso = "2026-11-10",
            savedAtMillis = 0L,
            zoneId = zone
        )
        assertEquals(LocalDate.parse("2026-11-10"), date)
    }
}
