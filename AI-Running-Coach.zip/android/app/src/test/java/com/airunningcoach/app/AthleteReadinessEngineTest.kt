package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Test

class AthleteReadinessEngineTest {
    @Test fun `sem feedback os indicadores ficam nao avaliados`() {
        val result = AthleteReadinessEngine.evaluate(emptyList())
        assertEquals("UNKNOWN", result.recoveryStatus)
        assertEquals("UNASSESSED", result.safetyStatus)
        assertEquals(null, result.recoveryScore)
    }

    @Test fun `um unico feedback confortavel ainda nao avalia prontidao`() {
        val result = AthleteReadinessEngine.evaluate(listOf(ReadinessFeedback("Leve", "Bem", false)))
        assertEquals(null, result.recoveryScore)
        assertEquals("UNKNOWN", result.recoveryStatus)
        assertEquals("UNASSESSED", result.safetyStatus)
    }

    @Test fun `dois feedbacks confortaveis indicam boa recuperacao e seguranca verde`() {
        val result = AthleteReadinessEngine.evaluate(listOf(
            ReadinessFeedback("Leve", "Bem", false),
            ReadinessFeedback("Ok", "Otimo", false)
        ))
        assertEquals(80.0, result.recoveryScore!!, 0.0)
        assertEquals("GOOD", result.recoveryStatus)
        assertEquals("GREEN", result.safetyStatus)
    }

    @Test fun `um feedback de cansaco gera atencao amarela`() {
        val result = AthleteReadinessEngine.evaluate(listOf(ReadinessFeedback("Leve", "Cansado", false)))
        assertEquals(60.0, result.recoveryScore!!, 0.0)
        assertEquals("MODERATE", result.recoveryStatus)
        assertEquals("YELLOW", result.safetyStatus)
    }

    @Test fun `duas sessoes com fadiga geram alerta amarelo`() {
        val result = AthleteReadinessEngine.evaluate(listOf(
            ReadinessFeedback("Pesado", "Bem", false),
            ReadinessFeedback("Leve", "Muito cansado", false)
        ))
        assertEquals(35.0, result.recoveryScore!!, 0.0)
        assertEquals("POOR", result.recoveryStatus)
        assertEquals("YELLOW", result.safetyStatus)
    }

    @Test fun `dor gera alerta vermelho independente dos demais feedbacks`() {
        val result = AthleteReadinessEngine.evaluate(listOf(ReadinessFeedback("Leve", "Bem", false), ReadinessFeedback("Leve", "Bem", true)))
        assertEquals("POOR", result.recoveryStatus)
        assertEquals("RED", result.safetyStatus)
        assertEquals(true, result.painReported)
    }
}
