package com.airunningcoach.app

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class PlannedVsRealizedEngineV63Test {
    @Test
    fun `distancia concluida sem valor real conta para aderencia mas nao para km realizados`() {
        val today = LocalDate.of(2026, 11, 17)
        val snapshot = PlannedVsRealizedEngine.summarize(
            planned = listOf(
                PlannedSessionEvidence("a", today.minusDays(2), 5.0, completed = true),
                PlannedSessionEvidence("b", today.minusDays(1), 4.0, completed = true),
                PlannedSessionEvidence("c", today, 6.0, completed = false)
            ),
            realized = listOf(RealizedActivityEvidence("a", today.minusDays(2), 4.8)),
            today = today
        )
        assertEquals(3, snapshot.plannedSessions)
        assertEquals(2, snapshot.completedSessions)
        assertEquals(67, snapshot.adherencePercent)
        assertEquals(15.0, snapshot.plannedDistanceKm, 0.01)
        assertEquals(4.8, snapshot.realizedDistanceKm, 0.01)
        assertEquals(1, snapshot.activitiesWithMeasuredDistance)
    }

    @Test
    fun `atividades fora da janela nao entram e sem plano aderencia fica nula`() {
        val today = LocalDate.of(2026, 11, 17)
        val snapshot = PlannedVsRealizedEngine.summarize(
            planned = listOf(PlannedSessionEvidence("old", today.minusDays(35), 8.0, true)),
            realized = listOf(RealizedActivityEvidence("old", today.minusDays(35), 8.0)),
            today = today,
            windowDays = 28
        )
        assertEquals(0, snapshot.plannedSessions)
        assertEquals(0, snapshot.activitiesWithMeasuredDistance)
        assertEquals(0.0, snapshot.plannedDistanceKm, 0.01)
        assertEquals(0.0, snapshot.realizedDistanceKm, 0.01)
        assertNull(snapshot.adherencePercent)
    }
    @Test
    fun `ids relativos repetidos em datas diferentes nao colapsam sessoes planejadas nem realizadas`() {
        val today = LocalDate.of(2026, 11, 22)
        val id = "W1-MON-AER"
        val snapshot = PlannedVsRealizedEngine.summarize(
            planned = listOf(
                PlannedSessionEvidence(id, today.minusDays(7), 5.0, completed = true),
                PlannedSessionEvidence(id, today.minusDays(1), 5.0, completed = false)
            ),
            realized = listOf(
                RealizedActivityEvidence(id, today.minusDays(7), 4.8),
                RealizedActivityEvidence(id, today.minusDays(1), 4.9)
            ),
            today = today
        )
        assertEquals(2, snapshot.plannedSessions)
        assertEquals(1, snapshot.completedSessions)
        assertEquals(2, snapshot.activitiesWithMeasuredDistance)
        assertEquals(9.7, snapshot.realizedDistanceKm, 0.01)
    }

    @Test fun `mesmo ID e data com tipos diferentes permanecem instancias distintas`() {
        val today = LocalDate.of(2026, 11, 22)
        val snapshot = PlannedVsRealizedEngine.summarize(
            planned = listOf(
                PlannedSessionEvidence("legacy", today.minusDays(1), 5.0, true, "Aeróbio"),
                PlannedSessionEvidence("legacy", today.minusDays(1), 4.0, false, "Qualidade")
            ),
            realized = listOf(
                RealizedActivityEvidence("legacy", today.minusDays(1), 4.8, "Aeróbio"),
                RealizedActivityEvidence("legacy", today.minusDays(1), 3.9, "Qualidade")
            ),
            today = today
        )
        assertEquals(2, snapshot.plannedSessions)
        assertEquals(1, snapshot.completedSessions)
        assertEquals(2, snapshot.activitiesWithMeasuredDistance)
    }

}
