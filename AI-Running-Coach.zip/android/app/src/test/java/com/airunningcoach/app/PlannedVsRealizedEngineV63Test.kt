package com.airunningcoach.app

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class PlannedVsRealizedEngineV63Test {
    @Test
    fun `distancia concluida sem valor real conta para aderencia mas nao para km realizados`() {
        val today = LocalDate.of(2026, 11, 17)
        val snapshot = PlannedVsRealizedEngine.summarize(
            planned = listOf(
                PlannedSessionEvidence("a", today.minusDays(2), 5.0, completed = true),
                PlannedSessionEvidence("b", today.minusDays(1), 4.0, completed = true),
                PlannedSessionEvidence("c", today, 6.0, completed = false)
            ),
            realized = listOf(RealizedActivityEvidence("a", today.minusDays(2), 4.8)),
            today = today
        )
        assertEquals(3, snapshot.plannedSessions)
        assertEquals(2, snapshot.completedSessions)
        assertEquals(67, snapshot.adherencePercent)
        assertEquals(15.0, snapshot.plannedDistanceKm, 0.01)
        assertEquals(4.8, snapshot.realizedDistanceKm, 0.01)
        assertEquals(1, snapshot.activitiesWithMeasuredDistance)
    }

    @Test
    fun `atividades fora da janela nao entram e sem plano aderencia fica nula`() {
        val today = LocalDate.of(2026, 11, 17)
        val snapshot = PlannedVsRealizedEngine.summarize(
            planned = listOf(PlannedSessionEvidence("old", today.minusDays(35), 8.0, true)),
            realized = listOf(RealizedActivityEvidence("old", today.minusDays(35), 8.0)),
            today = today,
            windowDays = 28
        )
        assertEquals(0, snapshot.plannedSessions)
        assertEquals(0, snapshot.activitiesWithMeasuredDistance)
        assertEquals(0.0, snapshot.plannedDistanceKm, 0.01)
        assertEquals(0.0, snapshot.realizedDistanceKm, 0.01)
        assertNull(snapshot.adherencePercent)
    }
}
