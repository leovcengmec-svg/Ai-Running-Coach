package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class PersonalRecordsEngineTest {
    @Test fun `distancias oficiais agrupam tolerancias e top tres ordena tempo`() {
        val category = requireNotNull(PersonalRecordsEngine.category(5.02))
        assertEquals("5 km", category.label)
        val records = listOf(2400, 2250, 2300, 2500).mapIndexed { index, seconds ->
            PersonalRecordResult("r$index", 5.0, seconds, "2026-11-${10 + index}", "Prova $index", source = "APP")
        }
        assertEquals(listOf(2250, 2300, 2400), PersonalRecordsEngine.topThree(records, category).map { it.durationSeconds })
    }

    @Test fun `cadastro manual preserva data vazia sem inventar data`() {
        val record = PersonalRecordsEngine.manualRecord(5.0, 1500, "", "Prova antiga", "", "")
        assertNotNull(record)
        assertEquals("", record?.dateIso)
    }

    @Test fun `registro manual rejeita distancia e tempo fora dos limites`() {
        assertNull(PersonalRecordsEngine.manualRecord(0.0, 1500, "", "", "", ""))
        assertNull(PersonalRecordsEngine.manualRecord(5.0, 0, "", "", "", ""))
    }
}
