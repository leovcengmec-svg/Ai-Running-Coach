package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class FeedbackRpeScaleTest {
    @Test fun `rotulos atuais do feedback alimentam a escala sRPE`() {
        assertEquals(2, FeedbackRpeScale.valueFor("Muito leve"))
        assertEquals(3, FeedbackRpeScale.valueFor("Leve"))
        assertEquals(5, FeedbackRpeScale.valueFor("Ok"))
        assertEquals(7, FeedbackRpeScale.valueFor("Pesado"))
        assertEquals(9, FeedbackRpeScale.valueFor("Muito pesado"))
    }

    @Test fun `rotulo moderado legado continua compativel`() {
        assertEquals(5, FeedbackRpeScale.valueFor("Moderado"))
        assertNull(FeedbackRpeScale.valueFor("desconhecido"))
    }
}
