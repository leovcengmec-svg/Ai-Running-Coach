package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WeeklySessionDistributionEngineTest {
    @Test fun `meta cinco km e semana de dezesseis distribui seis cinco cinco`() {
        val result = WeeklySessionDistributionEngine.distribute(
            requestedWeeklyKm = 16.0,
            sessionCount = 3,
            maxSessionKm = 10.0,
            minSessionKm = 5.0
        )
        assertEquals(16.0, result.actualWeeklyKm, 0.001)
        assertEquals(6.0, result.longRunKm, 0.001)
        assertEquals(listOf(5.0, 5.0), result.nonLongRunKm)
        assertTrue(result.longRunShare <= 0.40)
        assertTrue(result.strongDominanceSatisfied)
    }

    @Test fun `nao cria sessao regular abaixo do piso para completar volume`() {
        val result = runCatching {
            WeeklySessionDistributionEngine.distribute(16.0, 4, maxSessionKm = 10.0, minSessionKm = 5.0)
        }
        assertTrue(result.isFailure)
        assertTrue(result.exceptionOrNull()?.message.orEmpty().contains("piso de 5 km"))
    }

    @Test fun `longao nao ultrapassa quarenta por cento e abre diferenca visivel`() {
        val result = WeeklySessionDistributionEngine.distribute(18.0, 3, maxSessionKm = 10.0, minSessionKm = 0.5)
        val second = result.nonLongRunKm.maxOrNull()!!
        assertTrue(result.longRunShare <= 0.40)
        assertTrue(result.longRunKm >= second + 0.8)
        assertTrue(result.longRunKm >= second * 1.15)
    }

    @Test fun `dois dias nao conseguem respeitar simultaneamente teto e longao maior`() {
        val result = runCatching {
            WeeklySessionDistributionEngine.distribute(16.0, 2, maxSessionKm = 12.0)
        }
        assertTrue(result.isFailure)
        assertTrue(result.exceptionOrNull()?.message.orEmpty().contains("2 dias de corrida"))
    }



    @Test fun `prioriza longao com diferenca visivel antes de aceitar semana cheia`() {
        val result = WeeklySessionDistributionEngine.distribute(
            requestedWeeklyKm = 18.0,
            sessionCount = 3,
            maxSessionKm = 6.4,
            minSessionKm = 0.5
        )
        assertEquals(17.4, result.actualWeeklyKm, 0.001)
        assertEquals(6.4, result.longRunKm, 0.001)
        assertEquals(listOf(5.5, 5.5), result.nonLongRunKm)
        assertTrue(result.wasReduced)
        assertTrue(result.strongDominanceSatisfied)
    }

    @Test fun `nao aceita diferenca insignificante como se fosse longao`() {
        val result = runCatching {
            WeeklySessionDistributionEngine.distribute(
                15.1, 3, maxSessionKm = 10.0, minSessionKm = 5.0, requireStrongDominance = true
            )
        }
        assertTrue(result.isFailure)
        assertTrue(result.exceptionOrNull()?.message.orEmpty().contains("diferença mínima"))
    }

    @Test fun `distribuicao nao aumenta volume pedido`() {
        val result = WeeklySessionDistributionEngine.distribute(16.1, 3, maxSessionKm = 10.0, minSessionKm = 5.0)
        assertFalse(result.actualWeeklyKm > 16.1)
    }
}
