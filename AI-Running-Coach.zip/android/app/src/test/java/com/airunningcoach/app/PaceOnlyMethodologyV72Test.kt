package com.airunningcoach.app

import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PaceOnlyMethodologyV72Test {
    @Test fun `distribuicao planejada considera nivel sem depender de frequencia cardiaca`() {
        val beginner = IntensityDistributionEngine.target("RACE", "Iniciante", TrainingPeriodizationEngine.BASE)
        val intermediate = IntensityDistributionEngine.target("RACE", "Intermediário", TrainingPeriodizationEngine.BASE)
        val advanced = IntensityDistributionEngine.target("RACE", "Performance", TrainingPeriodizationEngine.BASE)
        assertNotEquals(beginner, intermediate)
        assertNotEquals(intermediate, advanced)
        assertTrue(beginner.lowMinPercent > advanced.lowMinPercent)
    }

    @Test fun `zonas pace sao calculadas por desempenho de campo`() {
        val fromCooper = PaceCalculator.calculateCooper(2.4)
        assertTrue(fromCooper.all().all { it.range.fastestPaceValue > 0 && it.range.slowestPaceValue >= it.range.fastestPaceValue })
    }
}
