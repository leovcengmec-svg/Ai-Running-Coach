package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TrainingProtocolCatalogTest {
    @Test fun `I07 exige cinco repeticoes exatas de 600 metros e recuperacao de dois minutos`() {
        val work = WorkoutSegment("Intervalo", "600 m", distanceKm = 0.6, repeatCount = 4, targetMode = "DISTANCE")
        val recovery = WorkoutSegment("Recuperação", "Leve", durationMin = 2, distanceKm = 0.25, repeatCount = 4, targetMode = "TIME")
        val finalWork = work.copy(repeatCount = 1)
        assertTrue(TrainingProtocolCatalog.validateNamedProtocol("I07", listOf(work, recovery, finalWork)).isEmpty())
        assertEquals(5, listOf(work, finalWork).sumOf { it.repeatCount })
    }

    @Test fun `I07 rejeita bloco por tempo com nome de distancia`() {
        val wrong = WorkoutSegment("Intervalo", "3 min", durationMin = 3, distanceKm = 0.4, repeatCount = 5, targetMode = "TIME")
        val recovery = WorkoutSegment("Recuperação", "2 min", durationMin = 2, distanceKm = 0.25, repeatCount = 4, targetMode = "TIME")
        assertTrue(TrainingProtocolCatalog.validateNamedProtocol("I07", listOf(wrong, recovery)).isNotEmpty())
    }

    @Test fun `I07 rejeita quantidade incorreta de recuperacoes`() {
        val work = WorkoutSegment("Intervalo", "600 m", distanceKm = 0.6, repeatCount = 4, targetMode = "DISTANCE")
        val recovery = WorkoutSegment("Recuperação", "Leve", durationMin = 2, distanceKm = 0.25, repeatCount = 3, targetMode = "TIME")
        val finalWork = work.copy(repeatCount = 1)
        assertTrue(TrainingProtocolCatalog.validateNamedProtocol("I07", listOf(work, recovery, finalWork)).isNotEmpty())
    }


    @Test fun `todos os protocolos tipados respeitam dose modalidade e recuperacao declaradas`() {
        TrainingProtocolCatalog.all.forEach { protocol ->
            val work = WorkoutSegment(
                name = "Intervalo",
                instruction = protocol.displayTitle,
                durationMin = protocol.workDurationMinutes,
                distanceKm = protocol.workDistanceMeters?.div(1000.0) ?: 0.35,
                repeatCount = protocol.repetitions,
                targetMode = protocol.targetMode
            )
            val recovery = WorkoutSegment(
                name = "Recuperação",
                instruction = "Leve",
                durationMin = protocol.recoveryDurationMinutes,
                distanceKm = 0.2,
                repeatCount = protocol.repetitions - 1,
                targetMode = "TIME"
            )
            assertTrue("${protocol.code}: ${protocol.displayTitle}", TrainingProtocolCatalog.validateNamedProtocol(protocol.code, listOf(work, recovery)).isEmpty())
        }
    }

    @Test fun `protocolo por tempo permanece tipado como tempo`() {
        val work = WorkoutSegment("Intervalo", "3 min", durationMin = 3, distanceKm = 0.4, repeatCount = 3, targetMode = "TIME")
        val recovery = WorkoutSegment("Recuperação", "2 min", durationMin = 2, distanceKm = 0.25, repeatCount = 3, targetMode = "TIME")
        val finalWork = work.copy(repeatCount = 1)
        assertTrue(TrainingProtocolCatalog.validateNamedProtocol("I04", listOf(work, recovery, finalWork)).isEmpty())
    }
    @Test fun `I07 aceita pausa passiva sem distancia ou ritmo e caminhada como recuperacao`() {
        val work = WorkoutSegment("Intervalo", "600 m", distanceKm = 0.6, repeatCount = 4, targetMode = "DISTANCE")
        val stop = WorkoutSegment(
            name = "Pausa parada", instruction = "Pare por dois minutos.", durationMin = 2,
            repeatCount = 4, targetMode = "TIME", recoveryMode = "PASSIVE"
        )
        val finalWork = work.copy(repeatCount = 1)
        assertTrue(TrainingProtocolCatalog.validateNamedProtocol("I07", listOf(work, stop, finalWork)).isEmpty())
        val walk = WorkoutSegment(
            name = "Recuperação caminhando", instruction = "Caminhe por dois minutos.", durationMin = 2,
            repeatCount = 4, targetMode = "TIME", recoveryMode = "WALK"
        )
        assertTrue(TrainingProtocolCatalog.validateNamedProtocol("I07", listOf(work, walk, finalWork)).isEmpty())
    }

    @Test fun `pausa passiva rejeita distancia ou ritmo ficticio`() {
        val result = runCatching {
            WorkoutSegment(
                name = "Pausa parada", instruction = "Pare.", durationMin = 2, distanceKm = 0.1,
                targetMode = "TIME", targetPaceMinValue = 400, targetPaceMaxValue = 450,
                recoveryMode = "PASSIVE"
            )
        }
        assertTrue(result.isFailure)
    }

}
