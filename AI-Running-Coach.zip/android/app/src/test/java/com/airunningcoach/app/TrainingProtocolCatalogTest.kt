package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TrainingProtocolCatalogTest {
    private fun expandedProtocol(
        protocol: TrainingProtocolDefinition,
        repetitions: Int = protocol.repetitions,
        repeatCount: Int = 1
    ): List<WorkoutSegment> {
        val result = mutableListOf(
            WorkoutSegment("Aquecimento leve", "Aqueça", distanceKm = 0.6),
            WorkoutSegment("Preparação em Z2", "Prepare o ritmo", distanceKm = 0.4, paceZone = "Z2")
        )
        repeat(repetitions) { index ->
            result += WorkoutSegment(
                name = "Intervalo",
                instruction = protocol.displayTitle,
                durationMin = protocol.workDurationMinutes,
                distanceKm = protocol.workDistanceMeters?.div(1000.0) ?: 0.4,
                repeatCount = repeatCount,
                targetMode = protocol.targetMode
            )
            if (index < repetitions - 1) result += WorkoutSegment(
                name = "Recuperação caminhando",
                instruction = "Caminhe durante a recuperação.",
                durationMin = protocol.recoveryDurationMinutes,
                targetMode = "TIME",
                recoveryMode = "WALK"
            )
        }
        result += WorkoutSegment("Desaquecimento", "Finalize", distanceKm = 0.5)
        return result
    }

    @Test
    fun `I07 exige cinco repeticoes de 600 metros em blocos individuais e quatro recuperacoes`() {
        val segments = expandedProtocol(requireNotNull(TrainingProtocolCatalog.find("I07")))
        assertTrue(TrainingProtocolCatalog.validateNamedProtocol("I07", segments).toString(),
            TrainingProtocolCatalog.validateNamedProtocol("I07", segments).isEmpty())
        assertEquals(12, segments.size)
        assertEquals(5, segments.count { it.name == "Intervalo" })
        assertEquals(4, segments.count { it.recoveryMode == "WALK" })
        assertTrue(segments.all { it.repeatCount == 1 })
    }

    @Test
    fun `I07 rejeita bloco por tempo com dose diferente do protocolo`() {
        val segments = expandedProtocol(requireNotNull(TrainingProtocolCatalog.find("I07"))).toMutableList()
        val workIndex = segments.indexOfFirst { it.name == "Intervalo" }
        segments[workIndex] = segments[workIndex].copy(targetMode = "TIME", durationMin = 3)
        assertTrue(TrainingProtocolCatalog.validateNamedProtocol("I07", segments).isNotEmpty())
    }

    @Test
    fun `I07 rejeita quantidade incorreta de recuperacoes`() {
        val segments = expandedProtocol(requireNotNull(TrainingProtocolCatalog.find("I07"))).toMutableList()
        val recoveryIndex = segments.indexOfFirst { it.recoveryMode == "WALK" }
        segments.removeAt(recoveryIndex)
        assertTrue(TrainingProtocolCatalog.validateNamedProtocol("I07", segments).isNotEmpty())
    }

    @Test
    fun `todos os protocolos tipados respeitam dose modalidade sequencia e repeticoes individuais`() {
        TrainingProtocolCatalog.all.forEach { protocol ->
            val segments = expandedProtocol(protocol)
            assertTrue("${protocol.code}: ${TrainingProtocolCatalog.validateNamedProtocol(protocol.code, segments)}",
                TrainingProtocolCatalog.validateNamedProtocol(protocol.code, segments).isEmpty())
        }
    }

    @Test
    fun `dose reduzida valida estrutura sem depender de pontuacao ou texto do titulo`() {
        val protocol = requireNotNull(TrainingProtocolCatalog.find("I05"))
        val segments = expandedProtocol(protocol, repetitions = 4)
        assertTrue(TrainingProtocolCatalog.validateNamedProtocol("I05", segments, "Intervalado 4 × 400 m").isEmpty())
        assertTrue(TrainingProtocolCatalog.validateNamedProtocol("I05", segments, "Intervalado 4x400m").isEmpty())
        assertTrue(TrainingProtocolCatalog.validateNamedProtocol("I05", segments, "Treino de velocidade controlada").isEmpty())
    }

    @Test
    fun `I05 seis vezes quatrocentos metros resulta em quatorze blocos`() {
        val protocol = requireNotNull(TrainingProtocolCatalog.find("I05"))
        val segments = expandedProtocol(protocol)
        assertEquals(14, segments.size)
        assertEquals(6, segments.count { it.name == "Intervalo" })
        assertEquals(5, segments.count { it.recoveryMode == "WALK" })
        assertFalse(segments.any { it.repeatCount > 1 })
    }

    @Test
    fun `pausa passiva rejeita distancia ou ritmo ficticio`() {
        val result = runCatching {
            WorkoutSegment(
                name = "Pausa parada", instruction = "Pare.", durationMin = 2, distanceKm = 0.1,
                targetMode = "TIME", targetPaceMinValue = 400, targetPaceMaxValue = 450,
                recoveryMode = "PASSIVE"
            )
        }
        assertTrue(result.isFailure)
    }
}
