package com.airunningcoach.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class RaceStrategyWorkoutExporterTest {
    @Test fun `exporta somente as etapas competitivas com a distância total da prova`() {
        val today = LocalDate.of(2026, 11, 20)
        val event = RaceEvent("race-5k", "Corrida Madruga", 5.0, "2026-11-28", "B")
        val zones = PaceCalculator.calculateCooper(2.6)
        val evidence = listOf(
            RacePaceEvidence(today.minusDays(4), 5.0, 360, "Ok", "Bem", false, "ACTIVITY", "RODAGEM", sessionId = "s1"),
            RacePaceEvidence(today.minusDays(8), 5.0, 358, "Ok", "Bem", false, "ACTIVITY", "RODAGEM", sessionId = "s2")
        )
        val strategy = RaceStrategyEngine.build(event, TrainingGoalIntent.COMPLETE, zones, evidence, today)
        val workout = RaceStrategyWorkoutExporter.build(event, strategy, zones)
        assertEquals(3, workout.segments.size)
        assertEquals(listOf("Início", "Meio", "Final"), workout.segments.map { it.name })
        assertEquals(5.0, workout.segments.sumOf { it.distanceKm ?: 0.0 }, 0.0001)

        val exportName = RaceStrategyWorkoutExporter.exportName(event)
        assertEquals("Prova_Corrida Madruga_Estrategia", exportName)
        val json = JSONObject(PaceCoachExporter.workoutToJson(workout, "5 km", 5.0, exportName))
        val payload = json.getJSONObject(PaceCoachExporter.USER_WORKOUT_JSON_KEY)
        assertEquals(exportName, payload.getString("workoutName"))
        val steps = payload.getJSONArray("workoutSteps")
        assertEquals(3, steps.length())
        assertTrue((0 until steps.length()).all { steps.getJSONObject(it).getString("stepTypeKey") != "warmup" && steps.getJSONObject(it).getString("stepTypeKey") != "cooldown" })
        assertTrue(steps.getJSONObject(1).has("targetTypeKey"))
    }

    @Test fun `na ausencia de ritmo de fase exportacao nao inventa alvo de pace`() {
        val event = RaceEvent("no-pace", "Prova sem ritmo", 5.0, "2026-12-01", "C")
        val phase = RaceStrategyPhase("Início", 0.0, 5.0, "Z2", null, null, "Corra controlado.")
        val strategy = RaceStrategy(
            eventId = event.id, title = "Estratégia", priorityLabel = event.priorityLabel(), phases = listOf(phase),
            estimatedTimeMinSeconds = null, estimatedTimeMaxSeconds = null, evidenceCount = 0,
            evidenceSessionCount = 0, confidence = "Insuficiente", targetAssessment = "Sem evidências.",
            readinessNote = "Registre um teste.", pacingNotes = emptyList()
        )
        val workout = RaceStrategyWorkoutExporter.build(event, strategy, null)
        assertEquals(5.0, workout.segments[0].distanceKm!!, 0.0)
        assertEquals("Z2", workout.segments[0].paceZone)
        assertEquals(null, workout.segments[0].targetPaceMinValue)
        val json = JSONObject(PaceCoachExporter.workoutToJson(workout, "5 km", 5.0, "Prova_sem_ritmo"))
            .getJSONObject(PaceCoachExporter.USER_WORKOUT_JSON_KEY).getJSONArray("workoutSteps")
        assertEquals("no.target", json.getJSONObject(0).getString("targetTypeKey"))
        assertFalse(json.getJSONObject(0).has("targetValueOne"))
    }
    @Test fun `tempo alvo de prova B e C e exportado como alvo de pace nos tres trechos`() {
        val today = LocalDate.of(2026, 11, 20)
        val zones = PaceCalculator.calculateCooper(2.6)
        val evidence = listOf(450, 448, 452).mapIndexed { index, pace ->
            RacePaceEvidence(
                today.minusDays((index + 1).toLong()), 5.0, pace, "Ok", "Bem", false,
                "ACTIVITY", "RODAGEM", sessionId = "evidence-$index"
            )
        }
        listOf("B", "C").forEach { priority ->
            val event = RaceEvent("target-$priority", "Prova $priority", 5.0, "2026-12-20", priority, "37:00")
            val strategy = RaceStrategyEngine.build(event, TrainingGoalIntent.PERSONAL_BEST, zones, evidence, today)
            assertTrue(strategy.targetPaceDriven)
            assertEquals(444, strategy.targetPaceSecondsPerKm)
            val workout = RaceStrategyWorkoutExporter.build(event, strategy, zones)
            val raceSteps = workout.segments
            assertEquals(3, raceSteps.size)
            assertTrue(raceSteps.all { it.targetPaceMinValue != null && it.targetPaceMaxValue != null })
            val weightedPace = raceSteps.sumOf { segment ->
                (segment.distanceKm ?: 0.0) * ((segment.targetPaceMinValue!! + segment.targetPaceMaxValue!!) / 2.0)
            } / 5.0
            assertTrue(kotlin.math.abs(weightedPace - 444.0) <= 1.0)
        }
    }

}
