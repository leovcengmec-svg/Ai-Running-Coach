package com.airunningcoach.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class RaceStrategyWorkoutExporterTest {
    @Test fun `exporta estratégia como UserWorkoutJson com aquecimento fases e desaquecimento`() {
        val today = LocalDate.of(2026, 11, 20)
        val event = RaceEvent("race-5k", "Corrida Madruga", 5.0, "2026-11-28", "B")
        val zones = PaceCalculator.calculateCooper(2.6)
        val evidence = listOf(
            RacePaceEvidence(today.minusDays(4), 5.0, 360, "Ok", "Bem", false, "ACTIVITY", "RODAGEM", sessionId = "s1"),
            RacePaceEvidence(today.minusDays(8), 5.0, 358, "Ok", "Bem", false, "ACTIVITY", "RODAGEM", sessionId = "s2")
        )
        val strategy = RaceStrategyEngine.build(event, TrainingGoalIntent.COMPLETE, zones, evidence, today)
        val workout = RaceStrategyWorkoutExporter.build(event, strategy, zones)
        assertEquals(5, workout.segments.size)
        assertEquals("Aquecimento pré-prova", workout.segments.first().name)
        assertEquals(listOf("Início", "Meio", "Final"), workout.segments.slice(1..3).map { it.name })
        assertEquals("Desaquecimento pós-prova", workout.segments.last().name)
        assertEquals(5.0, workout.segments.slice(1..3).sumOf { it.distanceKm ?: 0.0 }, 0.0001)

        val exportName = RaceStrategyWorkoutExporter.exportName(event)
        assertEquals("Prova_Corrida Madruga_Estrategia", exportName)
        val json = JSONObject(PaceCoachExporter.workoutToJson(workout, "5 km", 5.0, exportName))
        val payload = json.getJSONObject(PaceCoachExporter.USER_WORKOUT_JSON_KEY)
        assertEquals(exportName, payload.getString("workoutName"))
        val steps = payload.getJSONArray("workoutSteps")
        assertEquals(5, steps.length())
        assertEquals("warmup", steps.getJSONObject(0).getString("stepTypeKey"))
        assertEquals("cooldown", steps.getJSONObject(4).getString("stepTypeKey"))
        assertTrue(steps.getJSONObject(2).has("targetTypeKey"))
    }

    @Test fun `na ausencia de ritmo de fase exportacao nao inventa alvo de pace`() {
        val event = RaceEvent("no-pace", "Prova sem ritmo", 5.0, "2026-12-01", "C")
        val phase = RaceStrategyPhase("Início", 0.0, 5.0, "Z2", null, null, "Corra controlado.")
        val strategy = RaceStrategy(
            eventId = event.id, title = "Estratégia", priorityLabel = event.priorityLabel(), phases = listOf(phase),
            estimatedTimeMinSeconds = null, estimatedTimeMaxSeconds = null, evidenceCount = 0,
            evidenceSessionCount = 0, confidence = "Insuficiente", targetAssessment = "Sem evidências.",
            readinessNote = "Registre um teste.", pacingNotes = emptyList()
        )
        val workout = RaceStrategyWorkoutExporter.build(event, strategy, null)
        assertEquals(5.0, workout.segments[1].distanceKm!!, 0.0)
        assertEquals("Z2", workout.segments[1].paceZone)
        assertEquals(null, workout.segments[1].targetPaceMinValue)
        val json = JSONObject(PaceCoachExporter.workoutToJson(workout, "5 km", 5.0, "Prova_sem_ritmo"))
            .getJSONObject(PaceCoachExporter.USER_WORKOUT_JSON_KEY).getJSONArray("workoutSteps")
        assertEquals("no.target", json.getJSONObject(1).getString("targetTypeKey"))
        assertFalse(json.getJSONObject(1).has("targetValueOne"))
    }
}
