package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.time.LocalDate

class AthleteDemographicsEngineTest {
    @Test fun `calcula idade atual e idade na data historica a partir do nascimento`() {
        val today = LocalDate.parse("2026-11-18")
        assertEquals(36, AthleteDemographicsEngine.ageAtDate("14/06/1990", "", today, today))
        assertEquals(34, AthleteDemographicsEngine.ageAtDate("14/06/1990", "", LocalDate.parse("2025-05-01"), today))
    }

    @Test fun `perfil legado sem nascimento reaproveita idade cadastrada`() {
        assertEquals(36, AthleteDemographicsEngine.ageAtDate("", "36", LocalDate.parse("2020-01-01"), LocalDate.parse("2026-11-18")))
    }

    @Test fun `nascimento invalido ou posterior ao dia atual nao e aceito`() {
        val today = LocalDate.parse("2026-11-18")
        assertNull(AthleteDemographicsEngine.parseBirthDate("31/02/1990", today))
        assertNull(AthleteDemographicsEngine.parseBirthDate("19/11/2026", today))
        assertNull(AthleteDemographicsEngine.ageAtDate("31/02/1990", "36", today, today))
        assertNull(AthleteDemographicsEngine.ageAtDate("14/06/1990", "36", LocalDate.parse("1989-01-01"), today))
    }
}
