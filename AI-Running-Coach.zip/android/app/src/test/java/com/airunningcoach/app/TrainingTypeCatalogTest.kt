package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TrainingTypeCatalogTest {
    @Test
    fun `biblioteca contempla tipos de sessao classicos e intervalados mistos com zonas operacionais`() {
        assertEquals(23, TrainingTypeCatalog.all.size)
        val ids = TrainingTypeCatalog.all.map { it.id }.toSet()
        assertEquals(23, ids.size)
        listOf(
            "RUN_WALK", "RECOVERY", "EASY_AEROBIC", "LONG_RUN", "STEADY_RUN", "TEMPO_RUN",
            "AEROBIC_INTERVAL_Z2", "AEROBIC_INTERVAL_Z2_Z3", "MIXED_INTERVAL_Z3_Z4", "MIXED_INTERVAL_Z4_Z5",
            "PYRAMID_INTERVAL_Z3_Z5", "THRESHOLD_INTERVAL", "VO2_MAX_INTERVAL", "MARATHON_SPECIFIC", "ULTRA_SPECIFIC", "FARTLEK",
            "HILL_REPEATS", "STRIDES", "PROGRESSION_RUN", "FARTLEK_PYRAMID"
        ).forEach { assertNotNull("Tipo ausente: $it", TrainingTypeCatalog.find(it)) }
    }

    @Test
    fun `catalogo oferece fortalecimento opcional sem inserir sessao automaticamente`() {
        assertEquals(2, StrengthTrainingCatalog.all.size)
        assertTrue(StrengthTrainingCatalog.all.all { it.duration.contains("min") && it.exercises.isNotBlank() })
        assertTrue(StrengthTrainingCatalog.all.any { it.title.contains("panturrilhas") })
        assertTrue(StrengthTrainingCatalog.all.any { it.title.contains("posterior") })
    }

    @Test
    fun `catalogo identifica o objetivo e a zona principal de cada sessao`() {
        assertEquals("Z1–Z2", TrainingTypeCatalog.find("RUN_WALK")!!.zone)
        assertEquals("Z1", TrainingTypeCatalog.find("RECOVERY")!!.zone)
        assertEquals("Z2", TrainingTypeCatalog.find("LONG_RUN")!!.zone)
        assertEquals("Z3", TrainingTypeCatalog.find("STEADY_RUN")!!.zone)
        assertEquals("Z4", TrainingTypeCatalog.find("TEMPO_RUN")!!.zone)
        assertEquals("Z4–Z5", TrainingTypeCatalog.find("VO2_MAX_INTERVAL")!!.zone)
        assertEquals("Técnica", TrainingTypeCatalog.find("STRIDES")!!.zone)
        assertTrue(TrainingTypeCatalog.find("HILL_REPEATS")!!.use.contains("percurso"))
        assertEquals("Condicional — percurso", TrainingTypeCatalog.prescriptionStatus("HILL_REPEATS"))
        assertEquals("Condicional", TrainingTypeCatalog.prescriptionStatus("MARATHON_SPECIFIC"))
        assertEquals("Condicional", TrainingTypeCatalog.prescriptionStatus("ULTRA_SPECIFIC"))
        assertEquals("Condicional", TrainingTypeCatalog.prescriptionStatus("MIXED_INTERVAL_Z3_Z4"))
        assertTrue(TrainingTypeCatalog.prescriptionDetail("MIXED_INTERVAL_Z4_Z5").contains("Z5"))
        assertTrue(TrainingTypeCatalog.prescriptionDetail("FARTLEK_PYRAMID").contains("Z5"))
        assertTrue(TrainingTypeCatalog.prescriptionStatus("FARTLEK_PYRAMID").startsWith("Condicional"))
        assertTrue(TrainingTypeCatalog.prescriptionDetail("LEGACY_UNKNOWN").contains("não possui seleção automática"))
        TrainingTypeCatalog.all.forEach { type ->
            assertTrue("Status ausente: ${type.id}", TrainingTypeCatalog.prescriptionStatus(type.id) != "Não classificado")
            assertTrue("Detalhe ausente: ${type.id}", TrainingTypeCatalog.prescriptionDetail(type.id).isNotBlank() && !TrainingTypeCatalog.prescriptionDetail(type.id).contains("Uso pelo motor ainda não classificado"))
        }
    }
}
