package com.airunningcoach.app

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class TrainingLoadEngineV63Test {
    @Test
    fun `carga apresenta janelas de sete vinte e oito e quarenta e dois dias`() {
        val today = LocalDate.of(2026, 11, 17)
        val runs = (0 until 12).map { index ->
            LoggedRunActivity(
                date = today.minusDays(index * 3L),
                distanceKm = 6.0,
                durationSeconds = 2100,
                rpe = 4,
                averageCadenceSpm = 170,
                elevationGainMeters = 20.0,
                estimatedZoneTimeSeconds = mapOf("Z2" to 1800)
            )
        }
        val snapshot = TrainingLoadEngine.summarize(runs, today)
        assertEquals(18.0, snapshot.totalKmLast7Days, 0.01)
        assertEquals(60.0, snapshot.totalKmLast28Days, 0.01)
        assertEquals(72.0, snapshot.totalKmLast42Days, 0.01)
        assertNotNull(snapshot.averageCadenceLast28DaysSpm)
        assertEquals(10, snapshot.estimatedZoneTimeSecondsLast28Days["Z2"]?.div(1800))
    }
}
