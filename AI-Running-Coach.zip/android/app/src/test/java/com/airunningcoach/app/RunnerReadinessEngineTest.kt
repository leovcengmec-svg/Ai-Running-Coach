package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RunnerReadinessEngineTest {
    private fun evaluate(
        goal: Double = 10.0,
        level: String = "Intermediário",
        months: Int = 24,
        frequency: Int = 3,
        weekly: Double = 16.0,
        longest: Double = 7.0,
        activeWeeks: Int = 4,
        category: String = "PERFORMANCE"
    ) = RunnerReadinessEngine.evaluate(
        RunnerReadinessInput(
            goalKm = goal,
            goalCategory = category,
            declaredLevel = level,
            experienceMonths = months,
            selectedFrequency = frequency,
            weeklyVolumeKm = weekly,
            longestRecentKm = longest,
            activeWeeksLast4 = activeWeeks
        )
    )

    @Test fun `matriz entrega faixa de volume para cada objetivo e nivel`() {
        val goals = listOf(1.609, 3.0, 5.0, 10.0, 15.0, 21.1, 42.195, 50.0)
        val levels = listOf("Iniciante", "Intermediário", "Avançado", "Elite")
        goals.forEach { goal -> levels.forEach { level ->
            val result = evaluate(goal = goal, level = level, months = 72, weekly = 70.0, longest = 30.0)
            assertTrue("$goal / $level", result.recommendedFrequencyMin in 2..6)
            assertTrue("$goal / $level", result.recommendedFrequencyMax in result.recommendedFrequencyMin..6)
            if (goal <= 50.0 && !(goal > 42.2 && level == "Iniciante")) {
                assertTrue("$goal / $level", result.weeklyVolumeReference.minKm != null)
            }
        } }
    }

    @Test fun `milha e tres quilometros usam referencia propria distinta de cinco quilometros`() {
        val threeKm = evaluate(goal = 3.0, level = "Intermediário", weekly = 15.0, longest = 5.0)
        val fiveKm = evaluate(goal = 5.0, level = "Intermediário", weekly = 18.0, longest = 6.0)
        assertEquals("Milha / 3 km", threeKm.goalBand)
        assertEquals(12.0, threeKm.weeklyVolumeReference.minKm!!, 0.001)
        assertEquals(20.0, threeKm.weeklyVolumeReference.maxKm!!, 0.001)
        assertEquals("5 km", fiveKm.goalBand)
        assertEquals(15.0, fiveKm.weeklyVolumeReference.minKm!!, 0.001)
        assertEquals(25.0, fiveKm.weeklyVolumeReference.maxKm!!, 0.001)
    }

    @Test fun `volume atual e mantido como ponto de partida sem forcar minimo da tabela`() {
        val result = evaluate(goal = 10.0, level = "Intermediário", weekly = 8.0, longest = 4.0, activeWeeks = 3)
        assertEquals(8.0, result.initialRecommendedWeeklyKm, 0.001)
        assertEquals("BELOW_REFERENCE", result.currentCondition)
        assertTrue(result.recommendation.contains("começa no histórico real"))
    }

    @Test fun `semanas ativas identificam reintroducao e inconsistência`() {
        assertEquals("REINTRODUCTION", evaluate(weekly = 0.0, longest = 0.0, activeWeeks = 0).currentCondition)
        assertEquals("INCONSISTENT", evaluate(weekly = 6.0, longest = 3.0, activeWeeks = 1).currentCondition)
        val unknown = evaluate(weekly = 16.0, longest = 7.0, activeWeeks = -1)
        assertEquals("CONSISTENCY_UNKNOWN", unknown.currentCondition)
        assertTrue(unknown.flags.contains("VOLUME_BELOW_GOAL_REFERENCE"))
    }

    @Test fun `compatibilidade diferencia objetivos longos por nível`() {
        assertEquals("PREPARATION_REQUIRED", evaluate(goal = 21.1, level = "Iniciante").compatibility)
        assertEquals("CONDITIONAL", evaluate(goal = 21.1, level = "Intermediário").compatibility)
        assertEquals("RECOMMENDED", evaluate(goal = 21.1, level = "Avançado", months = 48).compatibility)
        assertEquals("CONDITIONAL", evaluate(goal = 50.0, level = "Avançado", months = 48).compatibility)
    }

    @Test fun `frequencia escolhida continua sendo do corredor e nao e alterada pela matriz`() {
        val result = evaluate(goal = 42.195, level = "Intermediário", frequency = 2, weekly = 20.0, longest = 10.0)
        assertEquals(2, result.selectedFrequency)
        assertTrue(result.flags.contains("SELECTED_FREQUENCY_BELOW_REFERENCE"))
        assertTrue(result.recommendation.contains("Você escolheu 2 dias"))
    }

    @Test fun `elite sem evidência de carga recebe guardrails avançados`() {
        val result = evaluate(goal = 10.0, level = "Elite", months = 24, frequency = 4, weekly = 20.0, longest = 8.0, activeWeeks = 2)
        assertEquals("Intermediário", result.prescriptionLevel)
        assertFalse(result.eliteLoadEvidenceCompatible)
        assertTrue(result.flags.contains("ELITE_LEVEL_NOT_SUPPORTED_BY_CURRENT_LOAD_EVIDENCE"))
    }

    @Test fun `elite com experiência consistência volume e sessão longa compatíveis mantém faixa elite`() {
        val result = evaluate(goal = 10.0, level = "Elite", months = 72, frequency = 5, weekly = 60.0, longest = 16.0, activeWeeks = 4)
        assertEquals("Elite", result.prescriptionLevel)
        assertTrue(result.eliteLoadEvidenceCompatible)
    }

    @Test fun `saúde usa matriz própria e não depende de distância competitiva`() {
        val result = evaluate(goal = 5.0, level = "Iniciante", category = "HEALTH", weekly = 8.0, longest = 3.0)
        assertEquals("RECOMMENDED", result.compatibility)
        assertEquals("Saúde e qualidade de vida", result.goalBand)
        assertEquals(2, result.recommendedFrequencyMin)
        assertEquals(3, result.recommendedFrequencyMax)
    }
    @Test fun `tempo curto de pratica reduz temporariamente o nivel operacional avancado`() {
        val result = evaluate(goal = 10.0, level = "Avançado", months = 12, weekly = 30.0, longest = 12.0, activeWeeks = 4)
        assertEquals("Intermediário", result.prescriptionLevel)
        assertTrue(result.flags.contains("LEVEL_ADJUSTED_BY_RUNNING_EXPERIENCE_DURATION"))
    }

    @Test fun `intermediario exige pelo menos doze meses de pratica regular`() {
        val result = evaluate(goal = 5.0, level = "Intermediário", months = 9, weekly = 16.0, longest = 6.0, activeWeeks = 4)
        assertEquals("Iniciante", result.prescriptionLevel)
        assertTrue(result.flags.contains("LEVEL_ADJUSTED_BY_RUNNING_EXPERIENCE_DURATION"))
    }

    @Test fun `avancado exige pelo menos trinta e seis meses de pratica regular`() {
        val result = evaluate(goal = 10.0, level = "Avançado", months = 24, weekly = 35.0, longest = 12.0, activeWeeks = 4)
        assertEquals("Intermediário", result.prescriptionLevel)
        assertTrue(result.flags.contains("LEVEL_ADJUSTED_BY_RUNNING_EXPERIENCE_DURATION"))
    }

    @Test fun `semanas medidas prevalecem somente quando historico e confiavel`() {
        assertEquals(4, RunnerReadinessEngine.resolveActiveWeeks(reportedWeeks = 1, measuredWeeks = 4, measuredHistoryReliable = true))
        assertEquals(1, RunnerReadinessEngine.resolveActiveWeeks(reportedWeeks = 1, measuredWeeks = 4, measuredHistoryReliable = false))
        assertEquals(-1, RunnerReadinessEngine.resolveActiveWeeks(reportedWeeks = -1, measuredWeeks = 2, measuredHistoryReliable = false))
    }

    @Test fun `experiencia desconhecida em backup antigo nao inventa duracao e usa guardrail conservador`() {
        val result = evaluate(goal = 10.0, level = "Intermediário", months = -1, weekly = 20.0, longest = 8.0, activeWeeks = -1)
        assertEquals("Iniciante", result.prescriptionLevel)
        assertEquals("LIMITED", result.confidence)
        assertEquals("CONSISTENCY_UNKNOWN", result.currentCondition)
        assertTrue(result.flags.contains("EXPERIENCE_DURATION_UNKNOWN_CONSERVATIVE_LEVEL"))
    }


    @Test fun `perfil legado sem duracao de experiencia recebe guardrail conservador sem inventar dado`() {
        val intermediate = evaluate(level = "Intermediário", months = -1, weekly = 20.0, longest = 8.0, activeWeeks = 4)
        assertEquals("Iniciante", intermediate.prescriptionLevel)
        assertTrue(intermediate.flags.contains("EXPERIENCE_DURATION_UNKNOWN_CONSERVATIVE_LEVEL"))
        assertTrue(intermediate.recommendation.contains("não está registrada"))

        val advanced = evaluate(level = "Avançado", months = -1, weekly = 35.0, longest = 12.0, activeWeeks = 4)
        assertEquals("Intermediário", advanced.prescriptionLevel)
        assertEquals("LIMITED", advanced.confidence)

        val eliteWithShortHistory = evaluate(level = "Elite", months = 24, weekly = 50.0, longest = 18.0, activeWeeks = 4)
        assertEquals("Intermediário", eliteWithShortHistory.prescriptionLevel)
    }

    @Test fun `consistencia baixa reduz confianca da recomendacao`() {
        val result = evaluate(level = "Intermediário", months = 24, weekly = 12.0, longest = 6.0, activeWeeks = 2)
        assertEquals("INCONSISTENT", result.currentCondition)
        assertEquals("LOW", result.confidence)
    }

    @Test fun `volume zero descreve reintroducao sem afirmar meta inicial zero quilometros`() {
        val result = evaluate(level = "Iniciante", months = 3, weekly = 0.0, longest = 0.0, activeWeeks = 0)
        assertTrue(result.recommendation.contains("reintrodução por tempo/dose baixa"))
        assertFalse(result.recommendation.contains("primeiro volume recomendado permanece 0"))
    }
}
