package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RunnerReadinessEngineTest {
    private fun evaluate(
        goal: Double = 10.0,
        level: String = "Intermediário",
        months: Int = 24,
        frequency: Int = 3,
        weekly: Double = 16.0,
        longest: Double = 7.0,
        activeWeeks: Int = 4,
        category: String = "PERFORMANCE"
    ) = RunnerReadinessEngine.evaluate(
        RunnerReadinessInput(
            goalKm = goal, goalCategory = category, declaredLevel = level,
            experienceMonths = months, selectedFrequency = frequency,
            weeklyVolumeKm = weekly, longestRecentKm = longest,
            activeWeeksLast4 = activeWeeks
        )
    )

    @Test fun `matriz entrega faixa de volume para os quatro niveis`() {
        val goals = listOf(1.609, 3.0, 5.0, 10.0, 15.0, 21.1, 42.195, 50.0)
        val levels = listOf("Iniciante", "Intermediário", "Performance", "Elite")
        goals.forEach { goal -> levels.forEach { level ->
            val result = evaluate(goal = goal, level = level, months = 1, weekly = 70.0, longest = 30.0)
            assertTrue("$goal / $level", result.recommendedFrequencyMin in 2..6)
            assertTrue("$goal / $level", result.recommendedFrequencyMax in result.recommendedFrequencyMin..6)
        } }
    }

    @Test fun `milha e tres quilometros usam referencia propria distinta de cinco quilometros`() {
        val threeKm = evaluate(goal = 3.0, level = "Intermediário", weekly = 15.0, longest = 5.0)
        val fiveKm = evaluate(goal = 5.0, level = "Intermediário", weekly = 18.0, longest = 6.0)
        assertEquals("3 km", threeKm.goalBand)
        assertEquals(12.0, threeKm.weeklyVolumeReference.minKm!!, 0.001)
        assertEquals(20.0, threeKm.weeklyVolumeReference.maxKm!!, 0.001)
        assertEquals("5 km", fiveKm.goalBand)
        assertEquals(15.0, fiveKm.weeklyVolumeReference.minKm!!, 0.001)
        assertEquals(25.0, fiveKm.weeklyVolumeReference.maxKm!!, 0.001)
    }

    @Test fun `volume real e preservado como ponto de partida`() {
        val result = evaluate(goal = 10.0, level = "Intermediário", weekly = 8.0, longest = 4.0, activeWeeks = 3)
        assertEquals(8.0, result.initialRecommendedWeeklyKm, 0.001)
        assertEquals("BELOW_REFERENCE", result.currentCondition)
        assertTrue(result.recommendation.contains("Volume inicial: 8 km/semana"))
    }

    @Test fun `frequencia escolhida continua sendo do corredor`() {
        val result = evaluate(goal = 10.0, level = "Intermediário", frequency = 2, weekly = 20.0, longest = 10.0)
        assertEquals(2, result.selectedFrequency)
        assertTrue(result.flags.contains("SELECTED_FREQUENCY_BELOW_REFERENCE"))
        assertTrue(result.recommendation.contains("Frequência: 2 dias/semana"))
    }

    @Test fun `experiencia de corrida nao altera classificacao fisiologica`() {
        val shortExperience = evaluate(level = "Intermediário", months = 1, weekly = 16.0, longest = 7.0)
        val longExperience = evaluate(level = "Intermediário", months = 120, weekly = 16.0, longest = 7.0)
        assertEquals("Intermediário", shortExperience.prescriptionLevel)
        assertEquals(shortExperience.prescriptionLevel, longExperience.prescriptionLevel)
        assertFalse(shortExperience.flags.any { it.contains("LEVEL_ADJUSTED") })
        assertFalse(longExperience.flags.any { it.contains("LEVEL_ADJUSTED") })
    }

    @Test fun `alias avancado migra para performance sem alterar nivel pela experiencia`() {
        val result = evaluate(level = "Avançado", months = 1, weekly = 30.0, longest = 12.0)
        assertEquals("Performance", result.prescriptionLevel)
    }

    @Test fun `elite mantem classificacao mas recebe indicador independente de tolerancia de carga`() {
        val result = evaluate(goal = 10.0, level = "Elite", months = 1, weekly = 20.0, longest = 8.0, activeWeeks = 2)
        assertEquals("Elite", result.prescriptionLevel)
        assertFalse(result.eliteLoadEvidenceCompatible)
    }

    @Test fun `semanas ativas sao calculadas do historico e nao solicitadas no cadastro`() {
        assertEquals(4, RunnerReadinessEngine.resolveActiveWeeks(1, 4, true))
        assertEquals(1, RunnerReadinessEngine.resolveActiveWeeks(1, 4, false))
        assertEquals(-1, RunnerReadinessEngine.resolveActiveWeeks(-1, 2, false))
    }

    @Test fun `sem volume real usa dose inicial conservadora`() {
        val result = evaluate(level = "Iniciante", weekly = 0.0, longest = 0.0, activeWeeks = 0)
        assertTrue(result.recommendation.contains("dose inicial conservadora"))
        assertEquals(0.0, result.initialRecommendedWeeklyKm, 0.001)
        assertEquals("LOW", result.confidence)
    }

    @Test fun `objetivo de saude usa matriz propria`() {
        val result = evaluate(goal = 5.0, level = "Iniciante", category = "HEALTH", weekly = 8.0, longest = 3.0)
        assertEquals("RECOMMENDED", result.compatibility)
        assertEquals("Saúde e qualidade de vida", result.goalBand)
        assertEquals(2, result.recommendedFrequencyMin)
        assertEquals(3, result.recommendedFrequencyMax)
    }
}
