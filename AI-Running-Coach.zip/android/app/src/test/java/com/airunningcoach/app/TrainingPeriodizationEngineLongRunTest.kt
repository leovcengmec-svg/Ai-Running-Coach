package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TrainingPeriodizationEngineLongRunTest {
    @Test fun `limite do longao progride ao longo das semanas e respeita teto da prova`() {
        val week1 = TrainingPeriodizationEngine.plannedLongRunCap(21.1, 10.0, 1, true)
        val week3 = TrainingPeriodizationEngine.plannedLongRunCap(21.1, 10.0, 3, true)
        val week4 = TrainingPeriodizationEngine.plannedLongRunCap(21.1, 10.0, 4, true)
        val week5 = TrainingPeriodizationEngine.plannedLongRunCap(21.1, 10.0, 5, true)
        val week6 = TrainingPeriodizationEngine.plannedLongRunCap(21.1, 10.0, 6, true)
        assertEquals(10.0, week1, 0.01)
        assertTrue(week3 > week1)
        assertTrue(week4 < week3) // deload temporarily reduces the long run
        assertTrue(week5 > week4) // next build week resumes from the prior build reference
        assertTrue(week6 > week5)
        assertTrue(week6 <= TrainingPeriodizationEngine.longRunCapForGoal(21.1))
    }

    @Test fun `baixa prontidao impede liberar novo limite de longao`() {
        assertEquals(10.0, TrainingPeriodizationEngine.plannedLongRunCap(21.1, 10.0, 8, false), 0.01)
    }

    @Test fun `objetivos de prova possuem teto de longao proprio`() {
        assertTrue(TrainingPeriodizationEngine.longRunCapForGoal(5.0) < TrainingPeriodizationEngine.longRunCapForGoal(10.0))
        assertTrue(TrainingPeriodizationEngine.longRunCapForGoal(10.0) < TrainingPeriodizationEngine.longRunCapForGoal(21.1))
        assertTrue(TrainingPeriodizationEngine.longRunCapForGoal(21.1) < TrainingPeriodizationEngine.longRunCapForGoal(42.2))
    }
}
