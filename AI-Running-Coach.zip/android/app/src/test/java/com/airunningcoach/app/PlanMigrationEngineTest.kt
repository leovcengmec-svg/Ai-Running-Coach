package com.airunningcoach.app

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PlanMigrationEngineTest {
    private fun workout(id: String, date: String, done: Boolean = false, optional: Boolean = false, week: Int = 1) = Workout(
        date = date,
        scheduledDateIso = date,
        title = id,
        detail = "test",
        type = "Aeróbio",
        objective = "base",
        stimulus = "EASY",
        distanceKm = 5.0,
        done = done,
        sessionId = id,
        durationMin = 35,
        week = week,
        isOptionalExtra = optional
    )

    @Test fun `old plan backup requests migration only when it contains a plan`() {
        assertTrue(PlanMigrationEngine.requiresMigration(36, 37, true))
        assertFalse(PlanMigrationEngine.requiresMigration(37, 37, true))
        assertFalse(PlanMigrationEngine.requiresMigration(36, 37, false))
        assertTrue(PlanMigrationEngine.requiresMigration(37, 38, true))
        assertFalse(PlanMigrationEngine.requiresMigration(38, 38, true))
    }

    @Test fun `two completed workouts and their feedback state survive regeneration`() {
        val completed = listOf(
            workout("w1", "2026-11-11", done = true),
            workout("w2", "2026-11-13", done = false)
        )
        val preserved = PlanMigrationEngine.preserveCompleted(completed, setOf("w1", "w2"))
        val regenerated = listOf(workout("w3", "2026-11-16"), workout("w4", "2026-11-18"))
        val merged = PlanMigrationEngine.merge(preserved, emptyList(), regenerated)
        assertEquals(4, merged.size)
        assertTrue(merged.first { it.sessionId == "w1" }.done)
        assertTrue(merged.first { it.sessionId == "w2" }.done)
        assertEquals(setOf("w1", "w2"), merged.filter { it.done }.map { it.sessionId }.toSet())
    }

    @Test fun `pending optional extra is preserved but not duplicated`() {
        val old = listOf(workout("extra", "2026-11-15", optional = true))
        val pending = PlanMigrationEngine.pendingOptionalExtras(old, LocalDate.of(2026, 11, 14), emptySet())
        val merged = PlanMigrationEngine.merge(emptyList(), pending, listOf(workout("extra", "2026-11-16")))
        assertEquals(1, merged.size)
        assertEquals("2026-11-15", merged.single().scheduledDateIso)
        assertTrue(merged.single().isOptionalExtra)
    }

    @Test fun `past Friday workout remains visible after plan regeneration even if legacy done flag is missing`() {
        val old = listOf(
            workout("wed", "2026-11-11", done = true),
            workout("fri", "2026-11-13", done = false)
        )
        val preserved = PlanMigrationEngine.preserveHistoryAndCompleted(
            old, feedbackSessionIds = setOf("wed"), today = LocalDate.of(2026, 11, 15)
        )
        val merged = PlanMigrationEngine.merge(
            preserved, emptyList(), listOf(workout("mon-next", "2026-11-16"))
        )
        assertEquals(setOf("wed", "fri", "mon-next"), merged.map { it.sessionId }.toSet())
        assertTrue(merged.first { it.sessionId == "wed" }.done)
        assertFalse(merged.first { it.sessionId == "fri" }.done)
    }
    @Test fun `restored plan keeps previous monday as week one instead of restarting on import date`() {
        val window = PlanMigrationEngine.restoredPlanWindow(
            savedStartDateIso = "2026-11-09",
            savedWeeks = 8,
            events = emptyList(),
            today = LocalDate.of(2026, 11, 16)
        )
        assertEquals(LocalDate.of(2026, 11, 9), window?.startDate)
        assertEquals(8, window?.weeks)
    }

    @Test fun `restored cycle rebuilds missing sessions and normalizes weeks by original anchor`() {
        val old = listOf(
            workout("wed", "2026-11-11"),
            workout("fri", "2026-11-13")
        )
        val regenerated = listOf(
            workout("mon-next", "2026-11-16"),
            workout("wed-next", "2026-11-18")
        )
        val merged = PlanMigrationEngine.merge(old, emptyList(), regenerated)
        val normalized = PlanMigrationEngine.normalizeCycleWeekNumbers(merged, LocalDate.of(2026, 11, 9))
        assertEquals(1, normalized.first { it.sessionId == "wed" }.week)
        assertEquals(1, normalized.first { it.sessionId == "fri" }.week)
        assertEquals(2, normalized.first { it.sessionId == "mon-next" }.week)
        assertEquals(2, normalized.first { it.sessionId == "wed-next" }.week)
    }

    @Test fun `completed plan outside its original active cycle does not re-anchor stale history`() {
        val window = PlanMigrationEngine.restoredPlanWindow(
            savedStartDateIso = "2026-08-01",
            savedWeeks = 8,
            events = emptyList(),
            today = LocalDate.of(2026, 11, 16)
        )
        assertTrue(window == null)
    }

    @Test fun `stale saved start date is corrected using original session week evidence`() {
        val saved = listOf(
            workout("wed-week1", "2026-11-11", week = 1),
            workout("fri-week1", "2026-11-13", week = 1),
            workout("mon-week2", "2026-11-16", week = 2)
        )
        assertEquals(
            LocalDate.of(2026, 11, 9),
            PlanMigrationEngine.inferRestoredCycleAnchor("2026-11-16", saved)
        )
    }

    @Test fun `screenshot scenario with two prior sessions and a rebased current session restores prior week`() {
        val saved = listOf(
            workout("wed-week1", "2026-11-11", week = 1),
            workout("fri-week1", "2026-11-13", week = 1),
            workout("mon-rebased", "2026-11-16", week = 1)
        )
        assertEquals(
            LocalDate.of(2026, 11, 9),
            PlanMigrationEngine.inferRestoredCycleAnchor("2026-11-16", saved)
        )
    }

    @Test fun `backup without cycle anchor derives it from consistent week dates`() {
        val saved = listOf(
            workout("wed", "2026-11-11", week = 1),
            workout("fri", "2026-11-13", week = 1),
            workout("mon-next", "2026-11-16", week = 2)
        )
        assertEquals(
            LocalDate.of(2026, 11, 9),
            PlanMigrationEngine.inferRestoredCycleAnchor("", saved)
        )
    }

    @Test fun `two sessions in prior week repair an anchor even when legacy week fields are invalid`() {
        val saved = listOf(
            workout("wed", "2026-11-11", week = 0),
            workout("fri", "2026-11-13", week = 0),
            workout("mon", "2026-11-16", week = 0)
        )
        assertEquals(
            LocalDate.of(2026, 11, 9),
            PlanMigrationEngine.inferRestoredCycleAnchor("2026-11-16", saved)
        )
    }

    @Test fun `ambiguous single old session does not overwrite a valid saved anchor`() {
        val saved = listOf(workout("old", "2026-11-11", week = 1))
        assertEquals(
            LocalDate.of(2026, 11, 16),
            PlanMigrationEngine.inferRestoredCycleAnchor("2026-11-16", saved)
        )
    }

}
