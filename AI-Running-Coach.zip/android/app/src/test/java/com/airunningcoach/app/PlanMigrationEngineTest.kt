package com.airunningcoach.app

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PlanMigrationEngineTest {
    private fun workout(id: String, date: String, done: Boolean = false, optional: Boolean = false) = Workout(
        date = date,
        scheduledDateIso = date,
        title = id,
        detail = "test",
        type = "Aeróbio",
        objective = "base",
        stimulus = "EASY",
        distanceKm = 5.0,
        done = done,
        sessionId = id,
        durationMin = 35,
        isOptionalExtra = optional
    )

    @Test fun `old plan backup requests migration only when it contains a plan`() {
        assertTrue(PlanMigrationEngine.requiresMigration(36, 37, true))
        assertFalse(PlanMigrationEngine.requiresMigration(37, 37, true))
        assertFalse(PlanMigrationEngine.requiresMigration(36, 37, false))
    }

    @Test fun `two completed workouts and their feedback state survive regeneration`() {
        val completed = listOf(
            workout("w1", "2026-11-11", done = true),
            workout("w2", "2026-11-13", done = false)
        )
        val preserved = PlanMigrationEngine.preserveCompleted(completed, setOf("w1", "w2"))
        val regenerated = listOf(workout("w3", "2026-11-16"), workout("w4", "2026-11-18"))
        val merged = PlanMigrationEngine.merge(preserved, emptyList(), regenerated)
        assertEquals(4, merged.size)
        assertTrue(merged.first { it.sessionId == "w1" }.done)
        assertTrue(merged.first { it.sessionId == "w2" }.done)
        assertEquals(setOf("w1", "w2"), merged.filter { it.done }.map { it.sessionId }.toSet())
    }

    @Test fun `pending optional extra is preserved but not duplicated`() {
        val old = listOf(workout("extra", "2026-11-15", optional = true))
        val pending = PlanMigrationEngine.pendingOptionalExtras(old, LocalDate.of(2026, 11, 14), emptySet())
        val merged = PlanMigrationEngine.merge(emptyList(), pending, listOf(workout("extra", "2026-11-16")))
        assertEquals(1, merged.size)
        assertEquals("2026-11-15", merged.single().scheduledDateIso)
        assertTrue(merged.single().isOptionalExtra)
    }
}
