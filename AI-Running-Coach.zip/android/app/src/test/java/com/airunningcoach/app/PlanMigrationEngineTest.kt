package com.airunningcoach.app

import java.time.LocalDate
import java.time.DayOfWeek
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PlanMigrationEngineTest {
    private fun workout(id: String, date: String, done: Boolean = false, optional: Boolean = false, week: Int = 1) = Workout(
        date = date,
        scheduledDateIso = date,
        title = id,
        detail = "test",
        type = "Aeróbio",
        objective = "base",
        stimulus = "EASY",
        distanceKm = 5.0,
        done = done,
        sessionId = id,
        durationMin = 35,
        week = week,
        isOptionalExtra = optional
    )

    private fun prescribed(id: String, date: String, week: Int) = PrescribedWorkout(
        day = "Dia", date = "Data", scheduledDateIso = date, title = id, type = "Aeróbio",
        objective = "base", stimulus = "EASY", sessionId = id, distanceKm = 5.0,
        durationMin = 35, intensity = "LOW", paceMode = "PACE_RANGE", rpeRange = "3-4",
        detail = "Rodagem", rationale = "Teste", week = week, phase = "BASE", segments = emptyList()
    )


    @Test fun `corrige semana inicial vazia de sabado para a proxima segunda sem perder horizonte semanal`() {
        val saved = listOf(
            workout("mon-23", "2026-11-23", week = 2),
            workout("wed-25", "2026-11-25", week = 2),
            workout("mon-30", "2026-11-30", week = 3)
        )
        val migrated = PlanMigrationEngine.rebaseEmptyFirstWeek(
            savedStartDateIso = "2026-11-16",
            today = LocalDate.of(2026, 11, 21),
            availableDays = listOf(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY),
            workouts = saved
        )
        assertTrue(migrated.migrated)
        assertEquals(LocalDate.of(2026, 11, 23), migrated.startDate)
        assertEquals(listOf(1, 1, 2), migrated.workouts.map { it.week })
        val secondPass = PlanMigrationEngine.rebaseEmptyFirstWeek(
            migrated.startDate.toString(), LocalDate.of(2026, 11, 21),
            listOf(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY), migrated.workouts
        )
        assertFalse(secondPass.migrated)
    }

    @Test fun `nao rebasa semana inicial quando existe sessao do proprio ciclo nela`() {
        val saved = listOf(
            workout("wed-18", "2026-11-18", week = 1, done = true),
            workout("mon-23", "2026-11-23", week = 2)
        )
        val migrated = PlanMigrationEngine.rebaseEmptyFirstWeek(
            "2026-11-16", LocalDate.of(2026, 11, 21),
            listOf(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY), saved
        )
        assertFalse(migrated.migrated)
        assertEquals(LocalDate.of(2026, 11, 16), migrated.startDate)
    }

    @Test fun `historico de ciclo anterior na mesma semana nao consome semana um do plano novo`() {
        val saved = listOf(
            workout("old-wed", "2026-11-18", week = 2, done = true),
            workout("new-mon", "2026-11-23", week = 2)
        )
        val migrated = PlanMigrationEngine.rebaseEmptyFirstWeek(
            "2026-11-16", LocalDate.of(2026, 11, 21),
            listOf(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY), saved
        )
        assertTrue(migrated.migrated)
        assertEquals(2, migrated.workouts.first { it.sessionId == "old-wed" }.week)
        assertEquals(1, migrated.workouts.first { it.sessionId == "new-mon" }.week)
    }

    @Test fun `nao rebase quando domingo ainda pode receber treino`() {
        val saved = listOf(workout("sun", "2026-11-22", week = 1))
        val migrated = PlanMigrationEngine.rebaseEmptyFirstWeek(
            "2026-11-16", LocalDate.of(2026, 11, 21), listOf(DayOfWeek.SUNDAY), saved
        )
        assertFalse(migrated.migrated)
    }

    @Test fun `old plan backup requests migration only when it contains a plan`() {
        assertTrue(PlanMigrationEngine.requiresMigration(36, 37, true))
        assertFalse(PlanMigrationEngine.requiresMigration(37, 37, true))
        assertFalse(PlanMigrationEngine.requiresMigration(36, 37, false))
        assertTrue(PlanMigrationEngine.requiresMigration(37, 38, true))
        assertFalse(PlanMigrationEngine.requiresMigration(38, 38, true))
        // V66 increments the engine from 52 to 53 for the goal/phase session matrix and Fartlek dose.
        assertTrue(PlanMigrationEngine.requiresMigration(52, 53, true))
        assertFalse(PlanMigrationEngine.requiresMigration(53, 53, true))
        assertFalse(PlanMigrationEngine.requiresMigration(52, 53, false))
    }

    @Test fun `two completed workouts and their feedback state survive regeneration`() {
        val completed = listOf(
            workout("w1", "2026-11-11", done = true),
            workout("w2", "2026-11-13", done = false)
        )
        val preserved = PlanMigrationEngine.preserveCompleted(completed, setOf("w1", "w2"))
        val regenerated = listOf(workout("w3", "2026-11-16"), workout("w4", "2026-11-18"))
        val merged = PlanMigrationEngine.merge(preserved, emptyList(), regenerated)
        assertEquals(4, merged.size)
        assertTrue(merged.first { it.sessionId == "w1" }.done)
        assertTrue(merged.first { it.sessionId == "w2" }.done)
        assertEquals(setOf("w1", "w2"), merged.filter { it.done }.map { it.sessionId }.toSet())
    }

    @Test fun `pending optional extra is preserved but not duplicated`() {
        val old = listOf(workout("extra", "2026-11-15", optional = true))
        val pending = PlanMigrationEngine.pendingOptionalExtras(old, LocalDate.of(2026, 11, 14), emptySet())
        val merged = PlanMigrationEngine.merge(emptyList(), pending, listOf(workout("extra", "2026-11-15")))
        assertEquals(1, merged.size)
        assertEquals("2026-11-15", merged.single().scheduledDateIso)
        assertTrue(merged.single().isOptionalExtra)
    }

    @Test fun `past Friday workout remains visible after plan regeneration even if legacy done flag is missing`() {
        val old = listOf(
            workout("wed", "2026-11-11", done = true),
            workout("fri", "2026-11-13", done = false)
        )
        val preserved = PlanMigrationEngine.preserveHistoryAndCompleted(
            old, feedbackSessionIds = setOf("wed"), today = LocalDate.of(2026, 11, 15)
        )
        val merged = PlanMigrationEngine.merge(
            preserved, emptyList(), listOf(workout("mon-next", "2026-11-16"))
        )
        assertEquals(setOf("wed", "fri", "mon-next"), merged.map { it.sessionId }.toSet())
        assertTrue(merged.first { it.sessionId == "wed" }.done)
        assertFalse(merged.first { it.sessionId == "fri" }.done)
    }
    @Test fun `restored plan keeps previous monday as week one instead of restarting on import date`() {
        val window = PlanMigrationEngine.restoredPlanWindow(
            savedStartDateIso = "2026-11-09",
            savedWeeks = 8,
            events = emptyList(),
            today = LocalDate.of(2026, 11, 16)
        )
        assertEquals(LocalDate.of(2026, 11, 9), window?.startDate)
        assertEquals(8, window?.weeks)
    }

    @Test fun `restauracao nao inventa sessao passada ausente do backup e regenera so hoje em diante`() {
        val backupHistory = listOf(
            workout("wed", "2026-11-11"),
            workout("fri", "2026-11-13")
        )
        val regeneratedPlan = listOf(
            prescribed("mon-missing", "2026-11-09", 1),
            prescribed("wed-backup", "2026-11-11", 1),
            prescribed("fri-backup", "2026-11-13", 1),
            prescribed("mon-next", "2026-11-16", 2),
            prescribed("wed-next", "2026-11-18", 2)
        )
        val candidates = PlanMigrationEngine.currentAndFutureCycleSessions(
            regeneratedPlan, LocalDate.of(2026, 11, 16), LocalDate.of(2026, 11, 9), 8
        )
        assertEquals(setOf("mon-next", "wed-next"), candidates.map { it.sessionId }.toSet())
        val future = candidates.map { workout(it.sessionId, it.scheduledDateIso, week = it.week) }
        val merged = PlanMigrationEngine.merge(backupHistory, emptyList(), future)
        val normalized = PlanMigrationEngine.normalizeCycleWeekNumbers(merged, LocalDate.of(2026, 11, 9))
        assertEquals(setOf("wed", "fri", "mon-next", "wed-next"), normalized.map { it.sessionId }.toSet())
        assertFalse(normalized.any { it.sessionId == "mon-missing" })
        assertEquals(1, normalized.first { it.sessionId == "wed" }.week)
        assertEquals(1, normalized.first { it.sessionId == "fri" }.week)
        assertEquals(2, normalized.first { it.sessionId == "mon-next" }.week)
        assertEquals(2, normalized.first { it.sessionId == "wed-next" }.week)
    }

    @Test fun `completed plan outside its original active cycle does not re-anchor stale history`() {
        val window = PlanMigrationEngine.restoredPlanWindow(
            savedStartDateIso = "2026-08-01",
            savedWeeks = 8,
            events = emptyList(),
            today = LocalDate.of(2026, 11, 16)
        )
        assertTrue(window == null)
    }

    @Test fun `stale saved start date is corrected using original session week evidence`() {
        val saved = listOf(
            workout("wed-week1", "2026-11-11", week = 1),
            workout("fri-week1", "2026-11-13", week = 1),
            workout("mon-week2", "2026-11-16", week = 2)
        )
        assertEquals(
            LocalDate.of(2026, 11, 9),
            PlanMigrationEngine.inferRestoredCycleAnchor("2026-11-16", saved)
        )
    }

    @Test fun `screenshot scenario with two prior sessions and a rebased current session restores prior week`() {
        val saved = listOf(
            workout("wed-week1", "2026-11-11", week = 1),
            workout("fri-week1", "2026-11-13", week = 1),
            workout("mon-rebased", "2026-11-16", week = 1)
        )
        assertEquals(
            LocalDate.of(2026, 11, 9),
            PlanMigrationEngine.inferRestoredCycleAnchor("2026-11-16", saved)
        )
    }

    @Test fun `backup without cycle anchor derives it from consistent week dates`() {
        val saved = listOf(
            workout("wed", "2026-11-11", week = 1),
            workout("fri", "2026-11-13", week = 1),
            workout("mon-next", "2026-11-16", week = 2)
        )
        assertEquals(
            LocalDate.of(2026, 11, 9),
            PlanMigrationEngine.inferRestoredCycleAnchor("", saved)
        )
    }

    @Test fun `two sessions in prior week repair an anchor even when legacy week fields are invalid`() {
        val saved = listOf(
            workout("wed", "2026-11-11", week = 0),
            workout("fri", "2026-11-13", week = 0),
            workout("mon", "2026-11-16", week = 0)
        )
        assertEquals(
            LocalDate.of(2026, 11, 9),
            PlanMigrationEngine.inferRestoredCycleAnchor("2026-11-16", saved)
        )
    }

    @Test fun `ambiguous single old session does not overwrite a valid saved anchor`() {
        val saved = listOf(workout("old", "2026-11-11", week = 1))
        assertEquals(
            LocalDate.of(2026, 11, 16),
            PlanMigrationEngine.inferRestoredCycleAnchor("2026-11-16", saved)
        )
    }


    @Test fun `prova B em backup restaurado nao assume janela nem altera prova principal`() {
        val tuneUp = RaceEvent("B", "Preparatória", 5.0, "2026-11-28", priority = "B")
        val window = PlanMigrationEngine.restoredPlanWindow(
            savedStartDateIso = "2026-11-09",
            savedWeeks = 8,
            events = listOf(tuneUp),
            today = LocalDate.of(2026, 11, 16)
        )
        assertEquals(LocalDate.of(2026, 11, 9), window?.startDate)
        assertEquals(null, window?.primaryRaceId)
        assertFalse(window?.raceInsideWindow ?: true)
    }


    @Test fun `merge preserva IDs legados repetidos em datas diferentes`() {
        val history = workout("W2-MONDAY-AEROBIO", "2026-11-16", done = true, week = 2)
        val current = workout("W2-MONDAY-AEROBIO", "2026-11-23", done = false, week = 2)
        val merged = PlanMigrationEngine.merge(listOf(history), emptyList(), listOf(current))
        assertEquals(2, merged.size)
        assertTrue(merged.any { it.scheduledDateIso == "2026-11-16" && it.done })
        assertTrue(merged.any { it.scheduledDateIso == "2026-11-23" && !it.done })
    }

    @Test fun `feedback por data original preserva sessao reagendada`() {
        val moved = workout("legacy-monday", "2026-11-25", done = false).copy(
            manuallyRescheduled = true,
            originalScheduledDateIso = "2026-11-23"
        )
        val preserved = PlanMigrationEngine.preserveHistoryAndCompletedInstances(
            listOf(moved), setOf(PlanMigrationEngine.sessionInstanceKey("legacy-monday", "2026-11-23")),
            LocalDate.of(2026, 11, 22)
        )
        assertEquals(1, preserved.size)
        assertTrue(preserved.single().done)
        assertEquals("2026-11-25", preserved.single().scheduledDateIso)
    }

    @Test fun `feedback com ID e data iguais mas tipos diferentes nao conclui sessao futura errada`() {
        val aerobic = workout("legacy-shared", "2026-11-23", done = false).copy(type = "Aeróbio")
        val quality = workout("legacy-shared", "2026-11-23", done = false).copy(type = "Qualidade")
        val typedFeedback = setOf(PlanMigrationEngine.sessionInstanceKey("legacy-shared", "2026-11-23", "Aeróbio"))
        val preserved = PlanMigrationEngine.preserveHistoryAndCompletedInstances(
            listOf(aerobic, quality), typedFeedback, LocalDate.of(2026, 11, 22)
        )
        assertEquals(1, preserved.size)
        assertEquals("Aeróbio", preserved.single().type)
        assertTrue(preserved.single().done)
    }

    @Test fun `feedback legado sem tipo nao associa quando ID e data sao ambiguos`() {
        val aerobic = workout("legacy-shared", "2026-11-23", done = false).copy(type = "Aeróbio")
        val quality = workout("legacy-shared", "2026-11-23", done = false).copy(type = "Qualidade")
        val untypedFeedback = setOf(PlanMigrationEngine.sessionInstanceKey("legacy-shared", "2026-11-23"))
        val preserved = PlanMigrationEngine.preserveHistoryAndCompletedInstances(
            listOf(aerobic, quality), untypedFeedback, LocalDate.of(2026, 11, 22)
        )
        assertTrue(preserved.isEmpty())
    }

    @Test fun `semana vazia corrigida inicia novo ciclo e nao infere ancora historica antiga`() {
        assertFalse(PlanMigrationEngine.shouldPreserveRestoredCycle(
            shouldPreserveCycleAnchor = true,
            emptyFirstWeekRebased = true
        ))
        assertTrue(PlanMigrationEngine.shouldPreserveRestoredCycle(
            shouldPreserveCycleAnchor = true,
            emptyFirstWeekRebased = false
        ))
        assertFalse(PlanMigrationEngine.shouldPreserveRestoredCycle(
            shouldPreserveCycleAnchor = false,
            emptyFirstWeekRebased = false
        ))
    }

}
