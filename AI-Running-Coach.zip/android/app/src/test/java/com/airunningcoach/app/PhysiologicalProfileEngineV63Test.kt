package com.airunningcoach.app

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PhysiologicalProfileEngineV63Test {
    private val today = LocalDate.of(2026, 11, 17)

    @Test
    fun `velocidade critica exige tres esforços ou provas validas e recentes`() {
        val results = listOf(
            PerformanceTestObservation(today.minusDays(16), 1.5, 300, 9, isRaceOrTest = true),
            PerformanceTestObservation(today.minusDays(10), 5.0, 1100, 9, isRaceOrTest = true),
            PerformanceTestObservation(today.minusDays(4), 10.0, 2300, 9, isRaceOrTest = true)
        )
        val snapshot = PhysiologicalProfileEngine.estimateCriticalSpeed(results, today)
        assertEquals("FIELD_ESTIMATE", snapshot.status)
        assertNotNull(snapshot.criticalSpeedPaceSecondsPerKm)
        assertTrue(snapshot.evidenceCount >= 3)
    }

    @Test
    fun `projecao nao extrapola mais de quatro vezes a distancia de origem`() {
        val projection = PhysiologicalProfileEngine.projectGoalTime(5.0, 1500, 42.195)
        assertEquals("INSUFFICIENT_EVIDENCE", projection.status)
        assertNull(projection.projectedTimeSeconds)
    }

    @Test
    fun `projecao para distancia proxima continua disponivel`() {
        val projection = PhysiologicalProfileEngine.projectGoalTime(10.0, 3000, 21.0975)
        assertEquals("ESTIMATE", projection.status)
        assertNotNull(projection.targetPaceSecondsPerKm)
    }
}
