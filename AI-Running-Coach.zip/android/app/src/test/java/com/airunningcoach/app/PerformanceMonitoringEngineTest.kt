package com.airunningcoach.app

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PerformanceMonitoringEngineTest {
    @Test
    fun `monitora tendencia de melhora sem recalibrar pace automaticamente`() {
        val start = LocalDate.of(2026, 11, 1)
        val rows = listOf("7:00", "6:58", "6:48", "6:45").mapIndexed { index, pace ->
            PaceObservation(start.plusDays((index * 4).toLong()).toString(), 5.0, pace, "Aeróbio", "Leve", "Bem", false)
        }
        val result = PerformanceMonitoringEngine.evaluate(rows, start.plusDays(15))
        assertEquals("FASTER", result.status)
        assertTrue(result.comparableSessions >= 4)
        assertTrue(result.explanation.contains("novo Cooper"))
    }

    @Test
    fun `exclui treinos com dor ou fadiga e nao usa treino de qualidade para comparar`() {
        val start = LocalDate.of(2026, 11, 1)
        val rows = listOf(
            PaceObservation(start.toString(), 5.0, "7:00", "Aeróbio", "Leve", "Bem", false),
            PaceObservation(start.plusDays(3).toString(), 5.0, "6:58", "Aeróbio", "Leve", "Bem", false),
            PaceObservation(start.plusDays(6).toString(), 5.0, "6:50", "Aeróbio", "Bem cansado", "Muito cansado", true),
            PaceObservation(start.plusDays(9).toString(), 5.0, "5:00", "Qualidade", "Pesado", "Cansado", false)
        )
        val result = PerformanceMonitoringEngine.evaluate(rows, start.plusDays(12))
        assertEquals("INSUFFICIENT", result.status)
        assertEquals(2, result.comparableSessions)
    }

    @Test
    fun `calcula pace ausente por tempo e distancia e explica exclusoes`() {
        val start = LocalDate.of(2026, 11, 1)
        val rows = (0..3).map { index ->
            PaceObservation(
                dateIso = start.plusDays((index * 4).toLong()).toString(),
                distanceKm = 5.0,
                paceMmSs = "",
                sessionType = "Aeróbio",
                effort = "Leve",
                feeling = "Bem",
                painPresent = false,
                durationSeconds = 2 * 60 * 60 + index * 30
            )
        } + PaceObservation(
            dateIso = start.plusDays(16).toString(), distanceKm = 5.0, paceMmSs = "",
            sessionType = "Aeróbio", effort = "Leve", feeling = "Bem", painPresent = false
        )
        val result = PerformanceMonitoringEngine.evaluate(rows, start.plusDays(20))
        assertEquals(4, result.comparableSessions)
        assertEquals(5, result.evaluatedRecords)
        assertEquals(1, result.exclusionCounts["MISSING_PACE"])
        assertTrue(result.exclusionSummary().contains("sem pace/tempo calculável: 1"))
    }

    @Test
    fun `limite de 28 dias exclui registro com vinte e nove dias`() {
        val today = LocalDate.of(2026, 11, 23)
        val old = PaceObservation(today.minusDays(28).toString(), 5.0, "7:00", "Aeróbio", "Leve", "Bem", false)
        val recent = (0..3).map { index ->
            PaceObservation(today.minusDays((index * 3).toLong()).toString(), 5.0, "7:00", "Aeróbio", "Leve", "Bem", false)
        }
        val result = PerformanceMonitoringEngine.evaluate(recent + old, today)
        assertEquals(4, result.comparableSessions)
        assertEquals(1, result.exclusionCounts["OUTSIDE_WINDOW"])
    }

    @Test
    fun `nao utiliza dados fora da janela de vinte e oito dias`() {
        val start = LocalDate.of(2026, 10, 1)
        val rows = (0..3).map { index ->
            PaceObservation(start.plusDays((index * 3).toLong()).toString(), 5.0, "7:00", "Aeróbio", "Leve", "Bem", false)
        }
        val result = PerformanceMonitoringEngine.evaluate(rows, LocalDate.of(2026, 11, 6))
        assertEquals("INSUFFICIENT", result.status)
    }
}
