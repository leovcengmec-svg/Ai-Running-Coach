package com.airunningcoach.app

import java.time.LocalDate
import java.time.DayOfWeek
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CoachEngineTest {
    private fun input(frequency: Int = 4) = RunnerInput(
        goalKm = 10.0,
        level = "Intermediário",
        frequency = frequency,
        weeklyVolumeKm = 30.0,
        longestRecentKm = 10.0,
        experienceMonths = 48,
        activeWeeksLast4 = 4,
        startDate = LocalDate.of(2026, 11, 9)
    )

    @Test
    fun `gera oito semanas completas sem duplicar dia na mesma semana`() {
        for (frequency in 2..6) {
            val plan = RunningCoachEngine.generate(input(frequency))
            val prescribedFrequency = frequency
            assertEquals(prescribedFrequency * 8, plan.workouts.size)
            assertEquals(8, plan.weeklySummaries.size)
            assertTrue(plan.workouts.all { it.scheduledDateIso.matches(Regex("\\d{4}-\\d{2}-\\d{2}")) })
            plan.workouts.groupBy { it.week }.values.forEach { week ->
                assertEquals(prescribedFrequency, week.size)
                assertEquals(prescribedFrequency, week.map { it.date }.distinct().size)
            }
        }
    }

    @Test
    fun `volume semanal real nao e reduzido ao limite inferior de uma faixa`() {
        val plan = RunningCoachEngine.generate(input(3).copy(weeklyVolumeKm = 20.0, longestRecentKm = 10.0))
        assertEquals(20.0, plan.weeklySummaries.first().totalKm, 0.01)
        assertEquals(20.0, plan.state.recentVolumeKm, 0.01)
    }

    @Test
    fun `nivel intermediario nao substitui volume semanal real`() {
        val plan = RunningCoachEngine.generate(input(3).copy(level = "Intermediário", weeklyVolumeKm = 10.0, longestRecentKm = 10.0))
        assertEquals(10.0, plan.weeklySummaries.first().totalKm, 0.01)
        assertFalse(plan.workouts.any { it.type == "Qualidade" })
    }

    @Test
    fun `historico curto limita sessoes e explica reducao do volume`() {
        val plan = RunningCoachEngine.generate(input(3).copy(weeklyVolumeKm = 20.0, longestRecentKm = 3.0))
        assertTrue(plan.weeklySummaries.first().totalKm < 20.0)
        assertTrue(plan.state.flags.contains("WEEKLY_VOLUME_CAPPED_BY_RECENT_TOLERANCE"))
        assertTrue(plan.workouts.filter { it.week == 1 }.all { it.distanceKm <= 3.3 })
        assertTrue(plan.weeklySummaries.zipWithNext().all { (a, b) -> b.totalKm <= a.totalKm * 1.11 })
    }

    @Test
    fun `sem feedback recuperacao e seguranca nao sao exibidas como avaliadas`() {
        val plan = RunningCoachEngine.generate(input().copy(recoveryScore = null, fatigueScore = null))
        assertEquals("UNKNOWN", plan.state.recoveryStatus)
        assertEquals("UNASSESSED", plan.state.safetyStatus)
    }

    @Test
    fun `semanas quatro e oito sao regenerativas e reduzem a carga`() {
        val plan = RunningCoachEngine.generate(input())
        assertTrue(plan.weeklySummaries[3].isRecoveryWeek)
        assertTrue(plan.weeklySummaries[3].totalKm < plan.weeklySummaries[2].totalKm)
        assertTrue(plan.weeklySummaries[7].isRecoveryWeek)
        assertTrue(plan.weeklySummaries[7].totalKm < plan.weeklySummaries[6].totalKm)
    }

    @Test
    fun `progressao semanal nao salta mais de onze por cento`() {
        val plan = RunningCoachEngine.generate(input())
        assertTrue(plan.weeklySummaries.zipWithNext().all { (previous, next) -> next.totalKm <= previous.totalKm * 1.11 })
    }

    @Test
    fun `matriz de sessenta perfis preserva frequencia escolhida e nao gera dias duplicados`() {
        val levels = listOf("Iniciante", "Intermediário", "Avançado", "Elite")
        val volumes = listOf(5.0, 10.0, 20.0)
        var cases = 0
        levels.forEach { level ->
            for (frequency in 2..6) {
                volumes.forEach { volume ->
                    val plan = RunningCoachEngine.generate(input(frequency).copy(level = level, weeklyVolumeKm = volume, longestRecentKm = 10.0))
                    val prescribedFrequency = frequency
                    assertEquals(prescribedFrequency * 8, plan.workouts.size)
                    assertTrue(plan.workouts.all { it.distanceKm > 0.0 })
                    plan.workouts.groupBy { it.week }.values.forEach { sessions ->
                        assertEquals(prescribedFrequency, sessions.map { it.date }.distinct().size)
                    }
                    assertTrue(plan.weeklySummaries.zipWithNext().all { (a, b) -> b.totalKm <= a.totalKm * 1.11 })
                    cases++
                }
            }
        }
        assertEquals(60, cases)
    }


    @Test
    fun `tempo de sessao combina blocos por distancia e por tempo`() {
        val plan = RunningCoachEngine.generate(
            input(3).copy(weeklyVolumeKm = 18.0, longestRecentKm = 10.0, cooperDistanceKm = 2.1)
        )
        val mixedModeWorkout = plan.workouts.first { workout ->
            workout.segments.any { it.targetMode == "TIME" } && workout.segments.any { it.targetMode == "DISTANCE" }
        }
        val recomputed = WorkoutDurationEstimator.estimateMinutes(mixedModeWorkout.segments, mixedModeWorkout.distanceKm).coerceAtLeast(15)
        assertEquals(recomputed, mixedModeWorkout.durationMin)
        assertTrue("A sessão mista não pode mostrar apenas os minutos do desaquecimento", mixedModeWorkout.durationMin > 15)
    }

    @Test
    fun `sessao leve fica primeiro qualidade no meio e longao por ultimo`() {
        val days = listOf(java.time.DayOfWeek.MONDAY, java.time.DayOfWeek.WEDNESDAY, java.time.DayOfWeek.FRIDAY)
        val plan = RunningCoachEngine.generate(input(3).copy(
            availableDays = days,
            preferredLongRunDay = java.time.DayOfWeek.FRIDAY,
            weeklyVolumeKm = 18.0,
            longestRecentKm = 10.0,
            cooperDistanceKm = 2.1
        ))
        val week = plan.workouts.filter { it.week == 1 }.sortedBy { it.scheduledDateIso }
        assertEquals(listOf("Aeróbio", "Qualidade", "Longo"), week.map { it.type })
        assertEquals(listOf("2026-11-09", "2026-11-11", "2026-11-13"), week.map { it.scheduledDateIso })
    }

    @Test
    fun `rodagem e longao usam Z2 e Z3 sem blocos Z1 na parte principal`() {
        val days = listOf(java.time.DayOfWeek.MONDAY, java.time.DayOfWeek.WEDNESDAY, java.time.DayOfWeek.FRIDAY)
        val plan = RunningCoachEngine.generate(input(3).copy(
            availableDays = days,
            preferredLongRunDay = java.time.DayOfWeek.FRIDAY,
            weeklyVolumeKm = 18.0,
            longestRecentKm = 10.0,
            cooperDistanceKm = 2.1
        ))
        val week2Easy = plan.workouts.single { it.week == 2 && it.type == "Aeróbio" }
        val week2Long = plan.workouts.single { it.week == 2 && it.type == "Longo" }
        val week3Easy = plan.workouts.single { it.week == 3 && it.type == "Aeróbio" }
        val week3Long = plan.workouts.single { it.week == 3 && it.type == "Longo" }
        assertTrue(week2Easy.title.contains("progressiva"))
        assertTrue(week2Easy.segments.filter { it.name.contains("Bloco") }.all { it.paceZone == "Z2" || it.paceZone == "Z3" })
        assertTrue(week2Easy.segments.filter { it.name.contains("Bloco") }.none { it.paceZone == "Z1" })
        assertTrue(week2Long.title.contains("progressivo"))
        assertTrue(week2Long.segments.filter { it.name.contains("Bloco") || it.name.contains("Final progressivo") }.none { it.paceZone == "Z1" })
        assertTrue(week3Easy.title.contains("regressiva"))
        assertTrue(week3Easy.segments.filter { it.name.contains("Bloco") }.all { it.paceZone == "Z2" || it.paceZone == "Z3" })
        assertTrue(week3Easy.segments.filter { it.name.contains("Bloco") }.none { it.paceZone == "Z1" })
        assertTrue(week3Long.title.contains("regressivo"))
        assertTrue(week3Long.segments.filter { it.name.contains("Bloco") || it.name.contains("Início moderado") }.none { it.paceZone == "Z1" })
        listOf(week2Easy, week2Long, week3Easy, week3Long).forEach { workout ->
            assertEquals(workout.distanceKm, workout.segments.sumOf { (it.distanceKm ?: 0.0) * it.repeatCount }, 0.11)
            val main = workout.segments.filter { it.name.contains("Bloco") || it.name.contains("Final progressivo") || it.name.contains("Início moderado") || it.name.contains("Final confortável") }
            main.zipWithNext().forEach { (left, right) ->
                if (workout.title.contains("progressiva") || workout.title.contains("progressivo")) {
                    if (left.targetPaceMinValue != null && right.targetPaceMaxValue != null) {
                        assertEquals("Progressão deve encostar as faixas sem salto: ${workout.title}", left.targetPaceMinValue, right.targetPaceMaxValue)
                    }
                } else if (workout.title.contains("regressiva") || workout.title.contains("regressivo")) {
                    if (left.targetPaceMaxValue != null && right.targetPaceMinValue != null) {
                        assertEquals("Regressão deve encostar as faixas sem salto: ${workout.title}", left.targetPaceMaxValue, right.targetPaceMinValue)
                    }
                }
            }
            val warm = workout.segments.first { it.name == "Aquecimento" }
            val cool = workout.segments.last { it.name == "Desaquecimento" }
            assertEquals(80, warm.zoneIntensityMinPercent)
            assertEquals(100, warm.zoneIntensityMaxPercent)
            assertEquals(80, cool.zoneIntensityMinPercent)
            assertEquals(100, cool.zoneIntensityMaxPercent)
        }
    }

    @Test
    fun `progressivo Z2 Z3 so libera Z3 com base intermediaria e recuperacao sem alerta`() {
        val days = listOf(java.time.DayOfWeek.MONDAY, java.time.DayOfWeek.WEDNESDAY, java.time.DayOfWeek.FRIDAY)
        val eligible = RunningCoachEngine.generate(input(3).copy(
            availableDays = days, preferredLongRunDay = DayOfWeek.FRIDAY,
            weeklyVolumeKm = 18.0, longestRecentKm = 10.0, cooperDistanceKm = 2.1,
            recoveryScore = 82.0, fatigueScore = 25.0
        ))
        val easy = eligible.workouts.single { it.week == 2 && it.type == "Aeróbio" }
        assertTrue(easy.segments.any { it.paceZone == "Z3" })
        val eligibleMain = easy.segments.filter { it.name.startsWith("Bloco") }
        assertEquals(listOf("Z2", "Z2", "Z3"), eligibleMain.map { it.paceZone })
        assertEquals(listOf(0, 20, 0), eligibleMain.map { it.zoneIntensityMinPercent })
        assertEquals(listOf(20, 100, 40), eligibleMain.map { it.zoneIntensityMaxPercent })
        val notEligible = RunningCoachEngine.generate(input(3).copy(
            availableDays = days, preferredLongRunDay = DayOfWeek.FRIDAY,
            weeklyVolumeKm = 12.0, longestRecentKm = 7.0, cooperDistanceKm = 2.1
        ))
        val easyWithoutZ3 = notEligible.workouts.first { it.week == 2 && it.type == "Aeróbio" }
        assertTrue(easyWithoutZ3.segments.none { it.paceZone == "Z3" })
        val z2OnlyMain = easyWithoutZ3.segments.filter { it.name.startsWith("Bloco") }
        assertTrue(z2OnlyMain.all { it.paceZone == "Z2" })
        assertEquals(listOf(0, 20), z2OnlyMain.map { it.zoneIntensityMinPercent })
        assertEquals(listOf(20, 65), z2OnlyMain.map { it.zoneIntensityMaxPercent })
    }

    @Test
    fun `qualidade progressiva usa Z2 e Z3 na parte principal e Z1 apenas nas pontas`() {
        val days = listOf(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY)
        val plan = RunningCoachEngine.generate(input(3).copy(
            availableDays = days, preferredLongRunDay = DayOfWeek.FRIDAY,
            weeklyVolumeKm = 18.0, longestRecentKm = 10.0, cooperDistanceKm = 2.1,
            recoveryScore = 82.0, fatigueScore = 25.0
        ))
        val quality = plan.workouts.single { it.week == 1 && it.type == "Qualidade" }
        val warm = quality.segments.first { it.name == "Aquecimento" }
        val cool = quality.segments.last { it.name == "Desaquecimento" }
        val main = quality.segments.filter { it.name.startsWith("Bloco") }
        assertTrue(quality.title.contains("Z2–Z3"))
        assertEquals(listOf("Z2", "Z2", "Z3"), main.map { it.paceZone })
        assertTrue(main.none { it.paceZone == "Z1" })
        assertEquals(80, warm.zoneIntensityMinPercent)
        assertEquals(100, warm.zoneIntensityMaxPercent)
        assertEquals(80, cool.zoneIntensityMinPercent)
        assertEquals(100, cool.zoneIntensityMaxPercent)
        assertEquals(quality.distanceKm, quality.segments.sumOf { (it.distanceKm ?: 0.0) * it.repeatCount }, 0.11)
    }

    @Test
    fun `regressivo sem elegibilidade Z3 permanece nas duas faixas de Z2`() {
        val days = listOf(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY)
        val plan = RunningCoachEngine.generate(input(3).copy(
            availableDays = days, preferredLongRunDay = DayOfWeek.FRIDAY,
            weeklyVolumeKm = 12.0, longestRecentKm = 7.0, cooperDistanceKm = 2.1
        ))
        val session = plan.workouts.first { it.week == 3 && it.type == "Aeróbio" }
        val main = session.segments.filter { it.name.startsWith("Bloco") }
        assertEquals(listOf("Z2", "Z2"), main.map { it.paceZone })
        assertEquals(listOf(20, 0), main.map { it.zoneIntensityMinPercent })
        assertEquals(listOf(65, 20), main.map { it.zoneIntensityMaxPercent })
        assertTrue(main[0].targetPaceMaxValue!! < main[1].targetPaceMaxValue!!)
    }

    @Test
    fun `longao Z3 fica limitado a doze por cento da parte principal`() {
        val days = listOf(java.time.DayOfWeek.MONDAY, java.time.DayOfWeek.WEDNESDAY, java.time.DayOfWeek.FRIDAY)
        val plan = RunningCoachEngine.generate(input(3).copy(
            level = "Avançado", availableDays = days, preferredLongRunDay = DayOfWeek.FRIDAY,
            weeklyVolumeKm = 30.0, longestRecentKm = 12.0, cooperDistanceKm = 2.4
        ))
        val longRun = plan.workouts.single { it.week == 2 && it.type == "Longo" }
        val z3Km = longRun.segments.filter { it.paceZone == "Z3" }.sumOf { (it.distanceKm ?: 0.0) * it.repeatCount }
        assertTrue(z3Km > 0.0)
        assertTrue(z3Km <= longRun.distanceKm * 0.10 + 0.11)
    }

    @Test
    fun `Z3 no longao progressivo fica restrita a perfil avancado com carga suficiente`() {
        val plan = RunningCoachEngine.generate(input(3).copy(
            level = "Avançado",
            availableDays = listOf(java.time.DayOfWeek.MONDAY, java.time.DayOfWeek.WEDNESDAY, java.time.DayOfWeek.FRIDAY),
            preferredLongRunDay = java.time.DayOfWeek.FRIDAY,
            weeklyVolumeKm = 30.0,
            longestRecentKm = 12.0,
            cooperDistanceKm = 2.4
        ))
        val longRun = plan.workouts.single { it.week == 2 && it.type == "Longo" }
        assertEquals("Longão progressivo Z2–Z3", longRun.title)
        assertTrue(longRun.segments.any { it.paceZone == "Z3" && it.name == "Final progressivo Z3" })
        assertTrue(longRun.segments.filter { it.paceZone == "Z3" }.sumOf { it.distanceKm ?: 0.0 } <= longRun.distanceKm * 0.13)
    }

    @Test
    fun `longao permanece limitado pela parcela do volume e pela tolerancia recente`() {
        val plan = RunningCoachEngine.generate(input(5))
        plan.workouts.groupBy { it.week }.forEach { (_, sessions) ->
            val weeklyKm = sessions.sumOf { it.distanceKm }
            val longRunKm = sessions.single { it.type == "Longo" }.distanceKm
            val allowedShare = when {
                sessions.first().week == 4 -> 0.52
                sessions.size == 2 -> 0.52
                sessions.size >= 3 -> 0.42
                else -> 0.52
            }
            assertTrue(longRunKm <= weeklyKm * allowedShare)
            assertTrue(longRunKm <= 11.0)
            assertTrue(sessions.all { it.distanceKm <= 11.0 })
        }
    }


    @Test
    fun `longao e a maior sessao e rodagem facil fica proxima quando ha tres treinos`() {
        val plan = RunningCoachEngine.generate(input(3).copy(weeklyVolumeKm = 18.0, longestRecentKm = 10.0))
        val sessions = plan.workouts.filter { it.week == 1 }
        val longRun = sessions.single { it.type == "Longo" }
        val others = sessions.filter { it.type != "Longo" }
        assertTrue(longRun.distanceKm > others.maxOf { it.distanceKm })
        assertEquals(18.0, sessions.sumOf { it.distanceKm }, 0.01)
        assertEquals(7.0, longRun.distanceKm, 0.01)
        assertEquals(6.0, others.single { it.type == "Aeróbio" }.distanceKm, 0.01)
        assertEquals(5.0, others.single { it.type == "Qualidade" }.distanceKm, 0.01)
    }

    @Test
    fun `longao permanece a maior sessao em todas as frequencias`() {
        for (frequency in 2..6) {
            val plan = RunningCoachEngine.generate(input(frequency).copy(weeklyVolumeKm = 30.0, longestRecentKm = 10.0))
            plan.workouts.groupBy { it.week }.values.forEach { sessions ->
                val longRun = sessions.single { it.type == "Longo" }
                assertTrue("Frequência $frequency, semana ${longRun.week}: longão não é o maior", longRun.distanceKm >= sessions.filter { it.type != "Longo" }.maxOf { it.distanceKm })
            }
        }
    }

    @Test
    fun `volume semanal e reduzido quando a frequencia nao permite distribuir sem exceder a tolerancia`() {
        val plan = RunningCoachEngine.generate(input(2).copy(weeklyVolumeKm = 30.0, longestRecentKm = 6.0))
        assertTrue(plan.weeklySummaries.first().totalKm < 30.0)
        val sessions = plan.workouts.filter { it.week == 1 }
        assertTrue(sessions.single { it.type == "Longo" }.distanceKm > sessions.single { it.type != "Longo" }.distanceKm)
    }

    @Test
    fun `dor bloqueia a prescricao normal`() {
        val plan = RunningCoachEngine.generate(input().copy(painPresent = true))
        assertEquals("RED", plan.state.safetyStatus)
        assertTrue(plan.workouts.isEmpty())
        assertEquals("BLOCK", plan.decision.action)
    }

    @Test
    fun `fadiga alta suspende qualidade e reduz volume`() {
        val normal = RunningCoachEngine.generate(input())
        val fatigued = RunningCoachEngine.generate(input().copy(fatigueScore = 80.0))
        assertEquals("YELLOW", fatigued.state.safetyStatus)
        assertFalse(fatigued.workouts.any { it.type == "Qualidade" })
        assertTrue(fatigued.weeklyKm < normal.weeklyKm)
    }

    @Test
    fun `sem resultado recente nao inventa pace e mantem distancia como alvo`() {
        val plan = RunningCoachEngine.generate(input())
        assertTrue(plan.workouts.all { it.paceMode == "PACE_NOT_CALIBRATED" })
        val segments = plan.workouts.flatMap { it.segments }
        assertTrue(segments.all { it.targetMode == "DISTANCE" })
        assertTrue(segments.all { it.targetPaceMinValue == null && it.targetPaceMaxValue == null })
    }

    @Test
    fun `resultado recente gera faixas de pace e preserva RPE como apoio`() {
        val plan = RunningCoachEngine.generate(input().copy(cooperDistanceKm = 2.4))
        assertTrue(plan.workouts.all { it.paceMode == "PACE_RANGE" })
        val segments = plan.workouts.flatMap { it.segments }
        assertTrue(segments.any { it.targetMode == "TIME" })
        assertTrue(segments.any { it.targetMode == "DISTANCE" })
        assertTrue(segments.filter { it.targetMode == "TIME" }.all { it.durationMin != null })
        assertTrue(segments.filter { it.paceZone != null }.all { it.targetPaceMinValue != null && it.targetPaceMaxValue != null })
        assertTrue(segments.all { (it.targetPaceMinValue == null) == (it.targetPaceMaxValue == null) })
        val interval = plan.workouts.first { it.title == "Intervalos controlados (Z4 estimada)" }
        assertEquals("TIME", interval.segments.first { it.name == "Aquecimento" }.targetMode)
        assertTrue(interval.segments.any { it.targetMode == "DISTANCE" })
        assertEquals("TIME", interval.segments.first { it.name.contains("Recuperação") }.targetMode)
        assertTrue(segments.all { it.targetPaceMinValue!! <= it.targetPaceMaxValue!! })
        assertTrue(segments.all { it.rpeRange.isNotBlank() })
    }

    @Test
    fun `strides ficam como complemento tecnico e nao sao somados a semana de qualidade`() {
        val plan = RunningCoachEngine.generate(input(5).copy(cooperDistanceKm = 2.4))
        assertTrue(TrainingTypeCatalog.find("STRIDES")!!.zone == "Técnica")
        // A semana já contém uma sessão-chave; o motor não soma outra carga intensa em forma de strides.
        assertTrue(plan.workouts.filter { it.week == 1 }.flatMap { it.segments }
            .none { it.name.contains("strides", ignoreCase = true) })
    }

    @Test
    fun `todas as sessoes possuem estrutura de blocos exportaveis`() {
        val plan = RunningCoachEngine.generate(input())
        assertTrue(plan.workouts.all { it.segments.size >= 3 })
        assertTrue(plan.workouts.all { it.sessionId.isNotBlank() })
    }

    @Test
    fun `distancia dos blocos corresponde ao total da sessao exportada`() {
        val plan = RunningCoachEngine.generate(input(3).copy(weeklyVolumeKm = 20.0, longestRecentKm = 10.0))
        plan.workouts.forEach { workout ->
            val segmentDistance = workout.segments.sumOf { (it.distanceKm ?: 0.0) * it.repeatCount }
            assertEquals(workout.distanceKm, segmentDistance, 0.11)
        }
    }
    @Test
    fun `iniciante com muitos dias disponiveis preserva frequencia escolhida em corrida caminhada`() {
        val allDays = listOf(java.time.DayOfWeek.MONDAY, java.time.DayOfWeek.TUESDAY, java.time.DayOfWeek.WEDNESDAY,
            java.time.DayOfWeek.THURSDAY, java.time.DayOfWeek.FRIDAY, java.time.DayOfWeek.SATURDAY)
        val plan = RunningCoachEngine.generate(input(6).copy(level = "Iniciante", availableDays = allDays,
            preferredLongRunDay = java.time.DayOfWeek.SATURDAY, weeklyVolumeKm = 4.0, longestRecentKm = 3.0))
        assertEquals(6 * 8, plan.workouts.size)
        plan.workouts.groupBy { it.week }.values.forEach { week -> assertEquals(6, week.size) }
        assertTrue(plan.workouts.all { it.title.contains("corrida/caminhada", ignoreCase = true) || it.title.contains("longão leve", ignoreCase = true) })
        assertTrue(plan.workouts.all { workout -> workout.segments.any { it.name == "Corrida leve" } && workout.segments.any { it.name == "Caminhada de recuperação" } })
    }

    @Test
    fun `iniciante com teste de campo recebe corrida ativa em Z2 mesmo no formato corrida caminhada`() {
        val plan = RunningCoachEngine.generate(
            input(3).copy(
                level = "Iniciante",
                weeklyVolumeKm = 4.0,
                longestRecentKm = 2.0,
                cooperDistanceKm = 2.1
            )
        )
        val runSegments = plan.workouts.flatMap { it.segments }
        assertTrue(runSegments.any { it.name == "Corrida ativa Z2" && it.paceZone == "Z2" })
        assertTrue(runSegments.any { it.name == "Caminhada de recuperação" })
        assertTrue(runSegments.any { it.name == "Corrida ativa Z2" && it.targetPaceMinValue != null && it.targetPaceMaxValue != null })
    }

    @Test
    fun `iniciante com baixa tolerancia sem teste recebe orientacao por esforco sem inventar pace`() {
        val plan = RunningCoachEngine.generate(
            input(3).copy(level = "Iniciante", weeklyVolumeKm = 4.0, longestRecentKm = 2.0, cooperDistanceKm = null)
        )
        assertTrue(plan.workouts.flatMap { it.segments }.any { it.name == "Corrida leve" })
        assertTrue(plan.workouts.flatMap { it.segments }.none { it.targetPaceMinValue != null })
    }

    @Test
    fun `motor suprime qualidade quando disponibilidade nao permite dia completo de recuperacao`() {
        val closeDays = listOf(java.time.DayOfWeek.MONDAY, java.time.DayOfWeek.TUESDAY, java.time.DayOfWeek.WEDNESDAY)
        val plan = RunningCoachEngine.generate(input(3).copy(availableDays = closeDays,
            preferredLongRunDay = java.time.DayOfWeek.TUESDAY, weeklyVolumeKm = 24.0, longestRecentKm = 10.0))
        assertFalse(plan.workouts.any { it.type == "Qualidade" })
        assertTrue(plan.state.flags.contains("QUALITY_SUPPRESSED_BY_RECOVERY_SPACING"))
    }

    @Test
    fun `estimulo de qualidade diferencia 5k 10k meia maratona e maratona`() {
        fun qualityTitle(goalKm: Double, week: Int): String = RunningCoachEngine.generate(
            input(4).copy(goalKm = goalKm, planWeeks = week)
        ).workouts.first { it.week == week && it.type == "Qualidade" }.title

        assertEquals("Corrida progressiva Z2", qualityTitle(5.0, 1))
        assertEquals("Corrida progressiva Z2", qualityTitle(10.0, 1))
        assertEquals("Corrida aeróbia sustentada Z2", qualityTitle(21.1, 1))
        assertEquals("Corrida aeróbia sustentada Z2", qualityTitle(42.2, 1))
        assertEquals("Resistência específica (maratona)", qualityTitle(42.2, 3))
        assertEquals("Intervalos controlados (Z4 estimada)", qualityTitle(21.1, 3))
    }

    @Test
    fun `estimulo metadata acompanha Z3 realmente liberada em sustentada e maratona`() {
        val days = listOf(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY)
        val noCooperZones = input(3).copy(
            level = "Intermediário", weeklyVolumeKm = 18.0, longestRecentKm = 10.0,
            cooperDistanceKm = null, calibratedPaceZones = null,
            availableDays = days, preferredLongRunDay = DayOfWeek.FRIDAY
        )

        val halfPlan = RunningCoachEngine.generate(noCooperZones.copy(goalKm = 21.1, planWeeks = 4))
        val sustained = halfPlan.workouts.first { it.week == 1 && it.type == "Qualidade" }
        assertEquals("STEADY_RUN_Z2", sustained.stimulus)
        assertTrue(sustained.segments.none { it.paceZone == "Z3" })

        val marathonPlan = RunningCoachEngine.generate(noCooperZones.copy(goalKm = 42.2, planWeeks = 4))
        val specific = marathonPlan.workouts.first { it.week == 3 && it.type == "Qualidade" }
        assertEquals("MARATHON_ENDURANCE_Z2", specific.stimulus)
        assertTrue(specific.segments.none { it.paceZone == "Z3" })
    }

    @Test
    fun `semana regenerativa reduz entre dez e vinte por cento da semana anterior`() {
        val plan = RunningCoachEngine.generate(input(4))
        val before = plan.weeklySummaries[2].totalKm
        val recovery = plan.weeklySummaries[3].totalKm
        val reduction = (before - recovery) / before
        assertTrue("Redução regenerativa foi ${(reduction * 100).toInt()}%", reduction in 0.10..0.20)
    }

    @Test
    fun `rodagem regenerativa usa pace Z1 tambem no alvo numerico`() {
        val plan = RunningCoachEngine.generate(input().copy(cooperDistanceKm = 2.4, planWeeks = 4))
        val recoverySessions = plan.workouts.filter { it.week == 4 && it.type == "Recuperação" }
        assertTrue(recoverySessions.isNotEmpty())
        val fullZone = PaceCalculator.calculateCooper(2.4)!!.z1.range
        val expected = ZoneIntensityBandEngine.activeRange(fullZone, ActiveZoneBand(0, 40))
        recoverySessions.forEach { session ->
            val main = session.segments.first { it.paceZone == "Z1" && it.name.contains("regenerativo", ignoreCase = true) }
            assertEquals("Z1", main.paceZone)
            assertEquals(expected.fastestPaceValue, main.targetPaceMinValue)
            assertEquals(expected.slowestPaceValue, main.targetPaceMaxValue)
            assertEquals(0, main.zoneIntensityMinPercent)
            assertEquals(40, main.zoneIntensityMaxPercent)
        }
    }

    @Test
    fun `all workout segment distances reconcile with prescribed session total`() {
        val days = listOf(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY)
        val goals = listOf(5.0, 10.0, 21.1, 42.2)
        val levels = listOf("Iniciante", "Intermediário", "Avançado", "Elite")
        goals.forEach { goal ->
            levels.forEach { level ->
                val plan = RunningCoachEngine.generate(input(3).copy(
                    goalKm = goal, level = level, availableDays = days,
                    preferredLongRunDay = DayOfWeek.FRIDAY,
                    weeklyVolumeKm = if (level == "Iniciante") 10.0 else 22.0,
                    longestRecentKm = if (level == "Iniciante") 6.0 else 12.0,
                    cooperDistanceKm = 2.2
                ))
                plan.workouts.forEach { workout ->
                    val sum = workout.segments.sumOf { (it.distanceKm ?: 0.0) * it.repeatCount }
                    assertEquals("${workout.title} week ${workout.week}", workout.distanceKm, sum, 0.11)
                }
            }
        }
    }


    @Test
    fun `intervalado prescrito pelo treinador vira par repetitivo e titulo nao expoe codigo`() {
        val plan = RunningCoachEngine.generate(input(3).copy(
            goalKm = 5.0, level = "Iniciante", availableDays = listOf(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY),
            preferredLongRunDay = DayOfWeek.FRIDAY, weeklyVolumeKm = 16.0,
            longestRecentKm = 10.0, cooperDistanceKm = 2.1,
            activeWeeksLast4 = 3, recentActivityHistoryReliable = true, planWeeks = 10,
            profileBaselineConfirmed = true, goalIntent = TrainingGoalIntent.PERSONAL_BEST,
            recoveryScore = 82.0, fatigueScore = 25.0
        ))
        val workout = plan.workouts.firstOrNull { it.stimulus.contains(":I04") }
        assertTrue("O bloco I04 deve existir no ciclo de 5 km", workout != null)
        val work = workout!!.segments.single { it.name == "Intervalo" }
        val recovery = workout.segments.single { it.name == "Recuperação" }
        assertEquals(4, work.repeatCount)
        assertEquals(4, recovery.repeatCount)
        assertFalse(workout.title.contains("I04"))
        assertFalse(workout.title.contains("INT"))
    }

    @Test
    fun `F01 alterna trabalho ativo em Z2 e Z3 com recuperacao em Z1 sem Z4 ou Z5`() {
        val days = listOf(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY)
        val plan = RunningCoachEngine.generate(input(3).copy(
            goalKm = 5.0, level = "Iniciante", availableDays = days,
            preferredLongRunDay = DayOfWeek.FRIDAY, weeklyVolumeKm = 16.0,
            longestRecentKm = 10.0, cooperDistanceKm = 2.1,
            activeWeeksLast4 = 3, recentActivityHistoryReliable = true,
            profileBaselineConfirmed = true, goalIntent = TrainingGoalIntent.PERSONAL_BEST
        ))
        val fartlek = plan.workouts.firstOrNull { it.type == "Qualidade" && it.stimulus.contains(":F01") }
        assertTrue("O plano deve conter F01 quando a base informada e a recuperação permitem", fartlek != null)
        val workZones = fartlek!!.segments.filter { it.name.contains("Fartlek") || it.name.contains("Variação") }
            .mapNotNull { it.paceZone }.toSet()
        val recoveries = fartlek.segments.filter { it.name.startsWith("Recuperação entre blocos") }
        assertTrue(workZones.contains("Z2"))
        assertTrue(workZones.contains("Z3"))
        assertTrue(recoveries.isNotEmpty())
        assertTrue(recoveries.all { it.paceZone == "Z1" })
        assertTrue(fartlek.segments.none { it.paceZone == "Z4" || it.paceZone == "Z5" })
        assertTrue(fartlek.stimulus.contains("FARTLEK_Z2_Z3"))
        assertTrue("O identificador de biblioteca não deve aparecer no título", fartlek.title.none { it.isDigit() })
    }

    @Test
    fun `F04 varia de Z2 a Z3 e inclui Z4 somente quando limiar e elegivel`() {
        val days = listOf(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY)
        val runner = input(3).copy(
            goalKm = 5.0, level = "Iniciante", availableDays = days,
            preferredLongRunDay = DayOfWeek.FRIDAY, weeklyVolumeKm = 16.0,
            longestRecentKm = 10.0, cooperDistanceKm = 2.1,
            activeWeeksLast4 = 3, recentActivityHistoryReliable = true,
            profileBaselineConfirmed = true, goalIntent = TrainingGoalIntent.PERSONAL_BEST,
            recoveryScore = 82.0, fatigueScore = 25.0
        )
        val plan = RunningCoachEngine.generate(runner)
        val fartlek = plan.workouts.firstOrNull { it.stimulus.contains(":F04") }
        assertTrue("F04 deve entrar na segunda semana de base quando elegível", fartlek != null)
        assertTrue(fartlek!!.segments.any { it.paceZone == "Z2" })
        assertTrue(fartlek.segments.any { it.paceZone == "Z3" })
        assertTrue(fartlek.segments.any { it.paceZone == "Z4" })

        val restricted = RunningCoachEngine.generate(runner.copy(recoveryScore = 70.0, fatigueScore = 70.0))
        val restrictedFartlek = restricted.workouts.firstOrNull { it.stimulus.contains(":F04") }
        assertTrue(restrictedFartlek != null)
        assertTrue(restrictedFartlek!!.segments.none { it.paceZone == "Z4" || it.paceZone == "Z5" })
    }

    @Test
    fun `recuperacoes entre intervalos ficam em Z2 e Z1 permanece nas extremidades da sessao`() {
        val days = listOf(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY)
        val plan = RunningCoachEngine.generate(input(3).copy(
            goalKm = 10.0, level = "Avançado", availableDays = days,
            preferredLongRunDay = DayOfWeek.FRIDAY, weeklyVolumeKm = 24.0,
            longestRecentKm = 12.0, cooperDistanceKm = 2.4
        ))
        plan.workouts.filter { it.type == "Qualidade" }.forEach { workout ->
            workout.segments.filter { it.name.startsWith("Recuperação entre blocos") }.forEach { segment ->
                if (segment.name.endsWith("Z1")) {
                    assertEquals("Z1", segment.paceZone)
                } else {
                    assertEquals("Z2", segment.paceZone)
                    assertEquals(0, segment.zoneIntensityMinPercent)
                    assertEquals(20, segment.zoneIntensityMaxPercent)
                }
            }
        }
    }

}

class TrainingAdaptationEngineTest {
    @Test
    fun `treino perdido nao e transferido para antes de longao proximo`() {
        val resolution = TrainingAdaptationEngine.reasonMissedWorkout(
            missedTitle = "Threshold",
            missedDistanceKm = 8.0,
            nextTitle = "Longão aeróbio",
            nextDistanceKm = 18.0,
            hoursUntilNext = 24
        )
        assertTrue(resolution.options.first().recommended)
        assertEquals("DROP", resolution.options.first().action)
    }


    @Test
    fun `muito leve nao e classificado como esforco excessivo`() {
        val analysis = TrainingAdaptationEngine.analyzeRun(
            TrainingAdaptationEngine.RunResult(
                distanceKm = 5.0,
                plannedDistanceKm = 5.0,
                perceivedEffort = "Muito leve",
                feeling = "Ótimo"
            )
        )
        assertEquals("Treino aeróbio registrado", analysis.headline)
        assertEquals(100, analysis.adherencePercent)
    }

    @Test
    fun `sem distancia real nao inventa aderencia`() {
        val analysis = TrainingAdaptationEngine.analyzeRun(
            TrainingAdaptationEngine.RunResult(
                distanceKm = null,
                plannedDistanceKm = 6.0,
                perceivedEffort = "Leve",
                feeling = "Bem"
            )
        )
        assertEquals(null, analysis.adherencePercent)
        assertTrue(analysis.insights.any { it.contains("não informada") })
    }

    @Test
    fun `relato de dor gera alerta de revisao`() {
        val analysis = TrainingAdaptationEngine.analyzeRun(
            TrainingAdaptationEngine.RunResult(
                distanceKm = 5.0,
                plannedDistanceKm = 5.0,
                painReported = true
            )
        )
        assertTrue(analysis.headline.contains("Dor reportada"))
    }



    @Test
    fun `consistencia desconhecida sem historico medido impede qualidade sem reduzir frequencia`() {
        val selectedDays = listOf(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY)
        val plan = RunningCoachEngine.generate(input(3).copy(
            level = "Avançado", experienceMonths = -1, activeWeeksLast4 = -1,
            recentActivityHistoryReliable = false, availableDays = selectedDays,
            preferredLongRunDay = DayOfWeek.FRIDAY, weeklyVolumeKm = 30.0,
            longestRecentKm = 12.0, cooperDistanceKm = 2.4,
            recoveryScore = 85.0, fatigueScore = 20.0
        ))
        assertEquals(3, plan.workouts.count { it.week == 1 })
        assertTrue(plan.workouts.none { it.week == 1 && it.type == "Qualidade" })
        assertTrue(plan.state.flags.contains("QUALITY_SUPPRESSED_BY_INSUFFICIENT_CONSISTENCY"))
        assertTrue(plan.workouts.flatMap { it.segments }.none { it.paceZone in setOf("Z4", "Z5") })
    }
}
