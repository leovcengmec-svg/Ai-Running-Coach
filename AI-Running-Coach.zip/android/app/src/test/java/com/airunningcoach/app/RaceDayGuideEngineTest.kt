package com.airunningcoach.app

import org.junit.Assert.assertTrue
import org.junit.Test

class RaceDayGuideEngineTest {
    @Test fun `prova de maratona orienta abastecimento e recuperacao`() {
        val event = RaceEvent("a", "Maratona", 42.195, "2026-12-20", "A", "04:00:00")
        val guide = RaceDayGuideEngine.build(event, TrainingGoalIntent.TARGET_TIME)
        assertTrue(guide.preRace.isNotBlank())
        assertTrue(guide.warmUp.isNotBlank())
        assertTrue(guide.start.contains("04:00:00"))
        assertTrue(guide.fueling.contains("carboidratos"))
        assertTrue(guide.recovery.isNotBlank())
        assertTrue(guide.targetStrategy.contains("principal"))
    }

    @Test fun `prova preparatoria nao e tratada como tentativa maxima`() {
        val event = RaceEvent("b", "Prova treino", 10.0, "2026-12-20", "C")
        val guide = RaceDayGuideEngine.build(event, TrainingGoalIntent.COMPLETE)
        assertTrue(guide.targetStrategy.contains("treinamento"))
    }
}
