package com.airunningcoach.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RunWalkEligibilityEngineTest {
    @Test fun `campos em branco usam referencia do objetivo e nao ativam corrida caminhada`() {
        assertFalse(RunWalkEligibilityEngine.isEligible(5.0, "Iniciante", 3, null, null, false))
    }

    @Test fun `corredor com cinco km concluidos nunca recebe caminho iniciante`() {
        assertFalse(RunWalkEligibilityEngine.isEligible(5.0, "Iniciante", 3, 0.0, 0.0, true))
        assertFalse(RunWalkEligibilityEngine.isEligible(5.0, "Intermediário", 24, 0.0, 0.0, false))
    }

    @Test fun `iniciante verdadeiro com declaracao zero explicita pode usar corrida caminhada`() {
        assertTrue(RunWalkEligibilityEngine.isEligible(5.0, "Iniciante", 3, 0.0, 0.0, false))
    }

    @Test fun `objetivos acima de cinco km nao usam caminho comum de iniciante`() {
        assertFalse(RunWalkEligibilityEngine.isEligible(10.0, "Iniciante", 3, 0.0, 0.0, false))
        assertFalse(RunWalkEligibilityEngine.isEligible(42.2, "Iniciante", 3, 0.0, 0.0, false))
    }
}
