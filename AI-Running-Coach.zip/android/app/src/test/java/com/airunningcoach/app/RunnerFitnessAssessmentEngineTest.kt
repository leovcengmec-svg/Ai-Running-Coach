package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RunnerFitnessAssessmentEngineTest {
    @Test fun `limiares usam idade e referencia fisiologica`() {
        val male20s = RunnerFitnessAssessmentEngine.thresholds(25, RunnerFitnessAssessmentEngine.MALE)!!
        assertEquals(42.0, male20s.intermediate, 0.001)
        assertEquals(47.95, male20s.performance, 0.001)
        assertEquals(54.95, male20s.elite, 0.001)

        val female30s = RunnerFitnessAssessmentEngine.thresholds(35, RunnerFitnessAssessmentEngine.FEMALE)!!
        assertEquals(32.9, female30s.intermediate, 0.001)
        assertEquals(38.15, female30s.performance, 0.001)
        assertEquals(47.95, female30s.elite, 0.001)
    }

    @Test fun `classifica nas quatro faixas sem usar tempo de pratica`() {
        val thresholds = RunnerFitnessAssessmentEngine.thresholds(25, RunnerFitnessAssessmentEngine.MALE)!!
        assertEquals("Iniciante", thresholds.label(thresholds.intermediate - 0.1))
        assertEquals("Intermediário", thresholds.label(thresholds.intermediate))
        assertEquals("Performance", thresholds.label(thresholds.performance))
        assertEquals("Elite", thresholds.label(thresholds.elite))
    }

    @Test fun `nao aplica tabela adulta sem idade ou referencia fisiologica valida`() {
        assertNull(RunnerFitnessAssessmentEngine.thresholds(17, RunnerFitnessAssessmentEngine.MALE))
        assertNull(RunnerFitnessAssessmentEngine.thresholds(25, ""))
        assertNull(RunnerFitnessAssessmentEngine.assess(42.0, 25, "X", "FIELD_ESTIMATE"))
    }

    @Test fun `duracao de teste de 3 km usa formato mm ss`() {
        assertEquals(930, RunnerFitnessAssessmentEngine.parseDurationSeconds("15:30"))
        assertNull(RunnerFitnessAssessmentEngine.parseDurationSeconds("15:75"))
        assertNull(RunnerFitnessAssessmentEngine.parseDurationSeconds("930"))
    }

    @Test fun `nivel legado avancado e convertido para performance`() {
        assertEquals("Performance", RunnerFitnessAssessmentEngine.normalizeLevel("Avançado"))
    }
    @Test fun `o mesmo VO2 pode mudar de faixa conforme idade e referencia`() {
        val vo2 = 35.65
        assertEquals("Iniciante", RunnerFitnessAssessmentEngine.assess(vo2, 45, RunnerFitnessAssessmentEngine.MALE, "FIELD_ESTIMATE")!!.level)
        assertEquals("Intermediário", RunnerFitnessAssessmentEngine.assess(vo2, 55, RunnerFitnessAssessmentEngine.MALE, "FIELD_ESTIMATE")!!.level)
        assertEquals("Intermediário", RunnerFitnessAssessmentEngine.assess(vo2, 25, RunnerFitnessAssessmentEngine.FEMALE, "FIELD_ESTIMATE")!!.level)
    }

}
