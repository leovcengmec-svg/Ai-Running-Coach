package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class AppBackupCodecTest {
    @Test fun roundTripPreservesAllSupportedPreferenceTypesAndSavedRecords() {
        val source = mapOf<String, Any>(
            "name" to "Atleta",
            "weeklyVolumeText" to "16",
            "longestRecent" to "10",
            "frequency" to 3,
            "runningExperienceDuration" to "1–3 anos",
            "ageYearsText" to "32",
            "birthDateText" to "10/04/1994",
            "referenceSex" to "MASCULINO",
            "fitnessTestMethod" to "THREE_KM",
            "threeKmTimeText" to "15:30",
            "activeWeeksLast4" to 3,
            "createdAt" to 1762862400000L,
            "cooperEnabled" to true,
            "volumeFactor" to 1.25f,
            "availableTrainingDaysSet" to setOf("MONDAY", "WEDNESDAY", "FRIDAY"),
            "workouts" to "[]",
            "raceEvents" to "[]",
            "feedbackRecords" to "[]",
            "cooperAssessments" to "[]",
            "racePlanWarnings" to "[]",
            "motorState" to "{}",
            "adaptiveCalibrationState" to "{\"referenceTestDateIso\":\"2026-11-01\",\"lastReviewDateIso\":\"2026-11-29\",\"cumulativePercentByZone\":{\"Z1\":3.0,\"Z2\":2.0,\"Z3\":5.0},\"history\":[]}"
        )

        val decoded = AppBackupCodec.decode(AppBackupCodec.encode(source, "2026-11-11T12:00:00Z"))
        source.filterKeys { it !in setOf("selectedScreen", "selectedWorkoutIndex", "selectedRaceId", "fieldTestEntryPending") }.forEach { (key, value) ->
            assertEquals("Mismatch in $key", value, decoded[key])
        }
    }

    @Test fun `backup preserva os valores declarados de carga do atleta sem substituicao por historico medido`() {
        val source = mapOf<String, Any>("weeklyVolumeText" to "16", "longestRecent" to "10")
        val decoded = AppBackupCodec.decode(AppBackupCodec.encode(source))
        assertEquals("16", decoded["weeklyVolumeText"])
        assertEquals("10", decoded["longestRecent"])
    }

    @Test fun backupDoesNotRestoreTransientNavigationState() {
        val encoded = AppBackupCodec.encode(mapOf("name" to "Atleta", "selectedScreen" to 9, "selectedWorkoutIndex" to 4, "selectedRaceId" to "race-1", "fieldTestEntryPending" to true))
        val decoded = AppBackupCodec.decode(encoded)
        assertTrue(decoded.containsKey("name"))
        assertFalse(decoded.containsKey("selectedScreen"))
        assertFalse(decoded.containsKey("selectedWorkoutIndex"))
        assertFalse(decoded.containsKey("selectedRaceId"))
        assertFalse(decoded.containsKey("fieldTestEntryPending"))
    }

    @Test fun rejectsWrongApplicationAndUnsupportedFormat() {
        val wrongApp = AppBackupCodec.encode(mapOf("name" to "Atleta")).replace("com.airunningcoach.app", "other.app")
        assertThrows(IllegalArgumentException::class.java) { AppBackupCodec.decode(wrongApp) }
        assertThrows(IllegalArgumentException::class.java) { AppBackupCodec.decode("{\"format\":\"unknown\"}") }
    }

    @Test fun rejectsMalformedSavedWorkoutJsonBeforeRestore() {
        val broken = AppBackupCodec.encode(mapOf("name" to "Atleta", "workouts" to "not-json"))
        assertThrows(Exception::class.java) { AppBackupCodec.decode(broken) }
    }

    @Test fun acceptsAnEmptyBackupForAProfileNotYetConfigured() {
        assertTrue(AppBackupCodec.decode(AppBackupCodec.encode(emptyMap<String, Any>())).isEmpty())
    }

    @Test fun rejectsWrongPreferenceTypesBeforeRestore() {
        val wrongType = AppBackupCodec.encode(mapOf("frequency" to "three"))
        assertThrows(IllegalArgumentException::class.java) { AppBackupCodec.decode(wrongType) }
    }
    @Test fun `schema onze backup inclui manifesto completo e preferencias de adiamento`() {
        val encoded = AppBackupCodec.encode(mapOf(
            "planStartDateIso" to "2026-11-09",
            "planWeeks" to 8,
            "workouts" to "[{},{}]",
            "feedbackRecords" to "[{}]",
            "cooperAssessments" to "[]",
            "raceEvents" to "[]",
            "engineRefreshDeferredForPlan" to true,
            "adaptivePlanRefreshPending" to true
        ))
        val root = org.json.JSONObject(encoded)
        assertEquals(11, root.getInt("schemaVersion"))
        assertEquals("V96", root.getString("appVersion"))
        assertEquals(2, root.getJSONObject("manifest").getInt("workoutCount"))
        assertEquals(8, AppBackupCodec.decode(encoded)["planWeeks"])
        assertEquals(true, AppBackupCodec.decode(encoded)["engineRefreshDeferredForPlan"])
        assertEquals(true, AppBackupCodec.decode(encoded)["adaptivePlanRefreshPending"])
    }

    @Test fun `backup schema dez da V95 continua legivel na V96`() {
        val oldBackup = AppBackupCodec.encode(mapOf("name" to "Atleta", "workouts" to "[]"))
            .replace("\"schemaVersion\": 11", "\"schemaVersion\": 10")
            .replace("\"appVersion\": \"V96\"", "\"appVersion\": \"V95\"")
        assertEquals(10, org.json.JSONObject(oldBackup).getInt("schemaVersion"))
        assertEquals("Atleta", AppBackupCodec.decode(oldBackup)["name"])
    }

    @Test fun `backup accepts every supported macrocycle length up to 52 weeks`() {
        listOf(4, 8, 16, 20, 36, 52).forEach { weeks ->
            val encoded = AppBackupCodec.encode(mapOf(
                "planStartDateIso" to "2026-11-09",
                "planWeeks" to weeks,
                "workouts" to "[{}]",
                "feedbackRecords" to "[]",
                "cooperAssessments" to "[]",
                "raceEvents" to "[]"
            ))
            assertEquals(weeks, AppBackupCodec.decode(encoded)["planWeeks"])
        }
    }

    @Test fun `backup rejects a macrocycle beyond the supported 52 weeks`() {
        val encoded = AppBackupCodec.encode(mapOf(
            "planStartDateIso" to "2026-11-09",
            "planWeeks" to 53,
            "workouts" to "[{}]",
            "feedbackRecords" to "[]",
            "cooperAssessments" to "[]",
            "raceEvents" to "[]"
        ))
        assertThrows(IllegalArgumentException::class.java) { AppBackupCodec.decode(encoded) }
    }

    @Test fun `backup manifest detects missing or modified plan data`() {
        val encoded = AppBackupCodec.encode(mapOf(
            "planStartDateIso" to "2026-11-09",
            "planWeeks" to 8,
            "workouts" to "[{},{}]",
            "feedbackRecords" to "[]",
            "cooperAssessments" to "[]",
            "raceEvents" to "[]"
        ))
        val tampered = encoded.replace("[{},{}]", "[{}]")
        assertThrows(IllegalArgumentException::class.java) { AppBackupCodec.decode(tampered) }
    }

    @Test fun `historico seletivo aceita backup sem ancora do plano mas backup completo rejeita`() {
        val encoded = AppBackupCodec.encode(mapOf(
            "workouts" to "[{\"sessionId\":\"old-1\",\"done\":true}]",
            "feedbackRecords" to "[]"
        ))
        assertTrue(AppBackupCodec.decode(encoded, requireCompletePlan = false).containsKey("workouts"))
        assertThrows(IllegalArgumentException::class.java) { AppBackupCodec.decode(encoded) }
    }

    @Test fun `importacao seletiva mescla somente concluidos preserva base e ignora duplicados`() {
        val merged = CompletedActivityBackupMerger.merge(
            "[{\"sessionId\":\"current-1\",\"done\":false},{\"sessionId\":\"keep-1\",\"done\":true}]",
            "[{\"sessionId\":\"keep-1\",\"activityFingerprint\":\"hash-keep\"}]",
            "[{\"sessionId\":\"current-1\",\"done\":true},{\"sessionId\":\"new-1\",\"done\":true},{\"sessionId\":\"future-1\",\"done\":false}]",
            "[{\"sessionId\":\"new-1\",\"activityFingerprint\":\"hash-new\",\"actualDistanceKm\":5.0},{\"sessionId\":\"new-1\",\"activityFingerprint\":\"hash-new\",\"actualDistanceKm\":5.0}]"
        )
        val workouts = org.json.JSONArray(merged.workoutsJson)
        assertEquals(3, workouts.length())
        assertTrue(workouts.getJSONObject(0).getBoolean("done"))
        assertEquals(1, merged.addedWorkouts)
        assertEquals(2, org.json.JSONArray(merged.feedbackJson).length())
        assertEquals(1, merged.addedFeedback)
    }

    @Test fun `importacao seletiva preserva sessoes locais legadas sem sessionId`() {
        val merged = CompletedActivityBackupMerger.merge(
            "[{\"title\":\"Treino legado\",\"done\":true},{\"sessionId\":\"keep-1\",\"done\":false}]",
            "[]", "[{\"sessionId\":\"new-1\",\"done\":true}]", "[]"
        )
        val workouts = org.json.JSONArray(merged.workoutsJson)
        assertEquals(3, workouts.length())
        assertEquals("Treino legado", workouts.getJSONObject(0).getString("title"))
        assertTrue(workouts.getJSONObject(2).getBoolean("done"))
    }


    @Test fun `importacao de historico com mesmo id legado e datas diferentes nao conclui treino futuro`() {
        val merged = CompletedActivityBackupMerger.merge(
            localWorkoutsJson = """[{"sessionId":"W2-MONDAY-AEROBIO","scheduledDateIso":"2026-11-23","originalScheduledDateIso":"","done":false,"title":"Rodagem atual"}]""",
            localFeedbackJson = "[]",
            importedWorkoutsJson = """[{"sessionId":"W2-MONDAY-AEROBIO","scheduledDateIso":"2026-11-16","originalScheduledDateIso":"","done":true,"title":"Rodagem historica"}]""",
            importedFeedbackJson = """[{"sessionId":"W2-MONDAY-AEROBIO","workoutDateIso":"2026-11-16","realizedDateIso":"2026-11-18","activityFingerprint":"activity-old","actualDistanceKm":5.0}]"""
        )
        val workouts = org.json.JSONArray(merged.workoutsJson)
        assertEquals(2, workouts.length())
        val current = (0 until workouts.length()).map { workouts.getJSONObject(it) }
            .single { it.getString("scheduledDateIso") == "2026-11-23" }
        val history = (0 until workouts.length()).map { workouts.getJSONObject(it) }
            .single { it.getString("scheduledDateIso") == "2026-11-16" }
        assertFalse(current.getBoolean("done"))
        assertTrue(history.getBoolean("done"))
        assertNotEquals(current.getString("sessionId"), history.getString("sessionId"))
        val feedback = org.json.JSONArray(merged.feedbackJson).getJSONObject(0)
        assertEquals(history.getString("sessionId"), feedback.getString("sessionId"))
        assertEquals("2026-11-16", feedback.getString("workoutOriginalDateIso"))
        assertEquals(1, merged.addedWorkouts)
        assertEquals(1, merged.addedFeedback)
    }

    @Test fun `duas atividades historicas com mesmo ID relativo preservam datas e feedbacks separados`() {
        val merged = CompletedActivityBackupMerger.merge(
            localWorkoutsJson = """[{"sessionId":"W2-MONDAY-AEROBIO","scheduledDateIso":"2026-11-23","done":false}]""",
            localFeedbackJson = "[]",
            importedWorkoutsJson = """[
                {"sessionId":"W2-MONDAY-AEROBIO","scheduledDateIso":"2026-10-05","done":true,"title":"Antiga 1"},
                {"sessionId":"W2-MONDAY-AEROBIO","scheduledDateIso":"2026-11-16","done":true,"title":"Antiga 2"}
            ]""",
            importedFeedbackJson = """[
                {"sessionId":"W2-MONDAY-AEROBIO","workoutDateIso":"2026-10-05","actualDistanceKm":4.0},
                {"sessionId":"W2-MONDAY-AEROBIO","workoutDateIso":"2026-11-16","actualDistanceKm":5.0}
            ]"""
        )
        val workouts = org.json.JSONArray(merged.workoutsJson)
        assertEquals(3, workouts.length())
        val current = (0 until workouts.length()).map { workouts.getJSONObject(it) }
            .single { it.getString("scheduledDateIso") == "2026-11-23" }
        assertFalse(current.getBoolean("done"))
        val history = (0 until workouts.length()).map { workouts.getJSONObject(it) }
            .filter { it.getString("scheduledDateIso") != "2026-11-23" }
        assertEquals(2, history.size)
        assertTrue(history.all { it.getBoolean("done") })
        assertEquals(2, history.map { it.getString("sessionId") }.distinct().size)
        val feedback = org.json.JSONArray(merged.feedbackJson)
        assertEquals(2, feedback.length())
        assertEquals(
            history.map { it.getString("sessionId") }.toSet(),
            (0 until feedback.length()).map { feedback.getJSONObject(it).getString("sessionId") }.toSet()
        )
    }

    @Test fun `data reagendada nao e confundida com a data original de outra sessao`() {
        val merged = CompletedActivityBackupMerger.merge(
            localWorkoutsJson = """[{"sessionId":"legacy-slot","scheduledDateIso":"2026-11-25","originalScheduledDateIso":"2026-11-23","manuallyRescheduled":true,"done":false}]""",
            localFeedbackJson = "[]",
            importedWorkoutsJson = """[{"sessionId":"legacy-slot","scheduledDateIso":"2026-11-25","originalScheduledDateIso":"2026-11-25","done":true,"title":"Outra sessão histórica"}]""",
            importedFeedbackJson = """[{"sessionId":"legacy-slot","workoutDateIso":"2026-11-25","actualDistanceKm":5.0}]"""
        )
        val workouts = org.json.JSONArray(merged.workoutsJson)
        assertEquals(2, workouts.length())
        val local = (0 until workouts.length()).map { workouts.getJSONObject(it) }
            .single { it.optString("originalScheduledDateIso") == "2026-11-23" }
        val imported = (0 until workouts.length()).map { workouts.getJSONObject(it) }
            .single { it.optString("title") == "Outra sessão histórica" }
        assertFalse(local.getBoolean("done"))
        assertTrue(imported.getBoolean("done"))
        assertNotEquals(local.getString("sessionId"), imported.getString("sessionId"))
        assertEquals(imported.getString("sessionId"), org.json.JSONArray(merged.feedbackJson).getJSONObject(0).getString("sessionId"))
    }

    @Test fun `importacao marca concluida apenas a mesma instancia e mesma data original`() {
        val merged = CompletedActivityBackupMerger.merge(
            """[{"sessionId":"same","scheduledDateIso":"2026-11-23","done":false}]""",
            "[]",
            """[{"sessionId":"same","scheduledDateIso":"2026-11-23","done":true}]""",
            """[{"sessionId":"same","workoutDateIso":"2026-11-23","realizedDateIso":"2026-11-23","actualDistanceKm":5.0}]"""
        )
        val workouts = org.json.JSONArray(merged.workoutsJson)
        assertEquals(1, workouts.length())
        assertTrue(workouts.getJSONObject(0).getBoolean("done"))
        assertEquals("same", org.json.JSONArray(merged.feedbackJson).getJSONObject(0).getString("sessionId"))
    }

    @Test fun `feedback sem data com id legado em colisao nao conclui sessao local`() {
        val merged = CompletedActivityBackupMerger.merge(
            """[{"sessionId":"legacy","scheduledDateIso":"2026-11-23","done":false}]""",
            "[]", "[]",
            """[{"sessionId":"legacy","realizedDateIso":"2026-11-18","actualDistanceKm":5.0}]"""
        )
        val workout = org.json.JSONArray(merged.workoutsJson).getJSONObject(0)
        val feedback = org.json.JSONArray(merged.feedbackJson).getJSONObject(0)
        assertFalse(workout.getBoolean("done"))
        assertNotEquals("legacy", feedback.getString("sessionId"))
    }

    @Test fun `fingerprint repetida continua deduplicando atividade importada`() {
        val merged = CompletedActivityBackupMerger.merge(
            "[]",
            """[{"sessionId":"old","workoutDateIso":"2026-11-16","activityFingerprint":"same-hash","actualDistanceKm":5.0}]""",
            """[{"sessionId":"old","scheduledDateIso":"2026-11-16","done":true}]""",
            """[{"sessionId":"old","workoutDateIso":"2026-11-16","activityFingerprint":"same-hash","actualDistanceKm":5.0}]"""
        )
        assertEquals(1, org.json.JSONArray(merged.workoutsJson).length())
        assertEquals(1, org.json.JSONArray(merged.feedbackJson).length())
        assertEquals(0, merged.addedFeedback)
    }

    @Test fun `mesmo id e data mas tipo diferente nao marca a sessao local como concluida`() {
        val merged = CompletedActivityBackupMerger.merge(
            localWorkoutsJson = """[{"sessionId":"legacy-same-day","scheduledDateIso":"2026-11-23","type":"Aeróbio","done":false}]""",
            localFeedbackJson = "[]",
            importedWorkoutsJson = """[{"sessionId":"legacy-same-day","scheduledDateIso":"2026-11-23","type":"Fartlek","done":true}]""",
            importedFeedbackJson = """[{"sessionId":"legacy-same-day","workoutDateIso":"2026-11-23","workoutType":"Fartlek","actualDistanceKm":5.0}]"""
        )
        val workouts = org.json.JSONArray(merged.workoutsJson)
        assertEquals(2, workouts.length())
        val local = (0 until workouts.length()).map { workouts.getJSONObject(it) }
            .single { it.getString("type") == "Aeróbio" }
        val imported = (0 until workouts.length()).map { workouts.getJSONObject(it) }
            .single { it.getString("type") == "Fartlek" }
        assertFalse(local.getBoolean("done"))
        assertTrue(imported.getBoolean("done"))
        assertNotEquals(local.getString("sessionId"), imported.getString("sessionId"))
        assertEquals(imported.getString("sessionId"), org.json.JSONArray(merged.feedbackJson).getJSONObject(0).getString("sessionId"))
    }

    @Test fun `schemas um e dois continuam legiveis`() {
        val schemaOneRoot = org.json.JSONObject(AppBackupCodec.encode(mapOf("name" to "Atleta", "workouts" to "[]")))
            .put("schemaVersion", 1)
            .put("appVersion", "V72")
            .also { it.remove("manifest") }
        assertEquals("Atleta", AppBackupCodec.decode(schemaOneRoot.toString())["name"])

        val schemaTwoRoot = org.json.JSONObject(AppBackupCodec.encode(mapOf("name" to "Atleta", "workouts" to "[]")))
            .put("schemaVersion", 2)
            .put("appVersion", "V73")
        assertEquals("Atleta", AppBackupCodec.decode(schemaTwoRoot.toString())["name"])
    }

    @Test fun `backup schema tres da V78 continua legível pela V93`() {
        val oldBackup = AppBackupCodec.encode(mapOf("name" to "Atleta", "workouts" to "[]"))
            .replace("\"schemaVersion\": 11", "\"schemaVersion\": 3")
            .replace("\"appVersion\": \"V96\"", "\"appVersion\": \"V78\"")
        val legacyRoot = org.json.JSONObject(oldBackup)
        assertEquals(3, legacyRoot.getInt("schemaVersion"))
        assertEquals("V78", legacyRoot.getString("appVersion"))
        assertEquals("Atleta", AppBackupCodec.decode(oldBackup)["name"])
    }

    @Test fun `backup schema quatro da V89 continua legível pela V93`() {
        val oldBackup = AppBackupCodec.encode(mapOf("name" to "Atleta", "workouts" to "[]"))
            .replace("\"schemaVersion\": 11", "\"schemaVersion\": 4")
            .replace("\"appVersion\": \"V96\"", "\"appVersion\": \"V89\"")
        val legacyRoot = org.json.JSONObject(oldBackup)
        assertEquals(4, legacyRoot.getInt("schemaVersion"))
        assertEquals("V89", legacyRoot.getString("appVersion"))
        assertEquals("Atleta", AppBackupCodec.decode(oldBackup)["name"])
    }

    @Test fun `backup schema sete da V92 continua legível pela V93`() {
        val oldBackup = AppBackupCodec.encode(mapOf("name" to "Atleta", "workouts" to "[]"))
            .replace("\"schemaVersion\": 11", "\"schemaVersion\": 7")
            .replace("\"appVersion\": \"V96\"", "\"appVersion\": \"V92\"")
        assertEquals(7, org.json.JSONObject(oldBackup).getInt("schemaVersion"))
        assertEquals("Atleta", AppBackupCodec.decode(oldBackup)["name"])
    }

    @Test fun `backup schema seis da V91 continua legível pela V93`() {
        val oldBackup = AppBackupCodec.encode(mapOf("name" to "Atleta", "workouts" to "[]"))
            .replace("\"schemaVersion\": 11", "\"schemaVersion\": 6")
            .replace("\"appVersion\": \"V96\"", "\"appVersion\": \"V91\"")
        val legacyRoot = org.json.JSONObject(oldBackup)
        assertEquals(6, legacyRoot.getInt("schemaVersion"))
        assertEquals("V91", legacyRoot.getString("appVersion"))
        assertEquals("Atleta", AppBackupCodec.decode(oldBackup)["name"])
    }

    @Test fun `backup schema cinco continua legível pela V93`() {
        val oldBackup = AppBackupCodec.encode(mapOf("name" to "Atleta", "workouts" to "[]"))
            .replace("\"schemaVersion\": 11", "\"schemaVersion\": 5")
            .replace("\"appVersion\": \"V96\"", "\"appVersion\": \"V90\"")
        assertEquals(5, org.json.JSONObject(oldBackup).getInt("schemaVersion"))
        assertEquals("Atleta", AppBackupCodec.decode(oldBackup)["name"])
    }

}
