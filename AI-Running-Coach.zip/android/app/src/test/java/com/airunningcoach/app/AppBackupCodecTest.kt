package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class AppBackupCodecTest {
    @Test fun roundTripPreservesAllSupportedPreferenceTypesAndSavedRecords() {
        val source = mapOf<String, Any>(
            "name" to "Atleta",
            "frequency" to 3,
            "runningExperienceDuration" to "1–3 anos",
            "activeWeeksLast4" to 3,
            "createdAt" to 1762862400000L,
            "cooperEnabled" to true,
            "volumeFactor" to 1.25f,
            "availableTrainingDaysSet" to setOf("MONDAY", "WEDNESDAY", "FRIDAY"),
            "workouts" to "[]",
            "raceEvents" to "[]",
            "feedbackRecords" to "[]",
            "cooperAssessments" to "[]",
            "racePlanWarnings" to "[]",
            "motorState" to "{}"
        )

        val decoded = AppBackupCodec.decode(AppBackupCodec.encode(source, "2026-11-11T12:00:00Z"))
        source.filterKeys { it !in setOf("selectedScreen", "selectedWorkoutIndex") }.forEach { (key, value) ->
            assertEquals("Mismatch in $key", value, decoded[key])
        }
    }

    @Test fun backupDoesNotRestoreTransientNavigationState() {
        val encoded = AppBackupCodec.encode(mapOf("name" to "Atleta", "selectedScreen" to 9, "selectedWorkoutIndex" to 4))
        val decoded = AppBackupCodec.decode(encoded)
        assertTrue(decoded.containsKey("name"))
        assertFalse(decoded.containsKey("selectedScreen"))
        assertFalse(decoded.containsKey("selectedWorkoutIndex"))
    }

    @Test fun rejectsWrongApplicationAndUnsupportedFormat() {
        val wrongApp = AppBackupCodec.encode(mapOf("name" to "Atleta")).replace("com.airunningcoach.app", "other.app")
        assertThrows(IllegalArgumentException::class.java) { AppBackupCodec.decode(wrongApp) }
        assertThrows(IllegalArgumentException::class.java) { AppBackupCodec.decode("{\"format\":\"unknown\"}") }
    }

    @Test fun rejectsMalformedSavedWorkoutJsonBeforeRestore() {
        val broken = AppBackupCodec.encode(mapOf("name" to "Atleta", "workouts" to "not-json"))
        assertThrows(Exception::class.java) { AppBackupCodec.decode(broken) }
    }

    @Test fun acceptsAnEmptyBackupForAProfileNotYetConfigured() {
        assertTrue(AppBackupCodec.decode(AppBackupCodec.encode(emptyMap<String, Any>())).isEmpty())
    }

    @Test fun rejectsWrongPreferenceTypesBeforeRestore() {
        val wrongType = AppBackupCodec.encode(mapOf("frequency" to "three"))
        assertThrows(IllegalArgumentException::class.java) { AppBackupCodec.decode(wrongType) }
    }
    @Test fun `schema two backup includes a complete record manifest`() {
        val encoded = AppBackupCodec.encode(mapOf(
            "planStartDateIso" to "2026-11-09",
            "planWeeks" to 8,
            "workouts" to "[{},{}]",
            "feedbackRecords" to "[{}]",
            "cooperAssessments" to "[]",
            "raceEvents" to "[]"
        ))
        val root = org.json.JSONObject(encoded)
        assertEquals(2, root.getInt("schemaVersion"))
        assertEquals("V64", root.getString("appVersion"))
        assertEquals(2, root.getJSONObject("manifest").getInt("workoutCount"))
        assertEquals(8, AppBackupCodec.decode(encoded)["planWeeks"])
    }

    @Test fun `backup accepts every supported macrocycle length up to 52 weeks`() {
        listOf(4, 8, 16, 20, 36, 52).forEach { weeks ->
            val encoded = AppBackupCodec.encode(mapOf(
                "planStartDateIso" to "2026-11-09",
                "planWeeks" to weeks,
                "workouts" to "[{}]",
                "feedbackRecords" to "[]",
                "cooperAssessments" to "[]",
                "raceEvents" to "[]"
            ))
            assertEquals(weeks, AppBackupCodec.decode(encoded)["planWeeks"])
        }
    }

    @Test fun `backup rejects a macrocycle beyond the supported 52 weeks`() {
        val encoded = AppBackupCodec.encode(mapOf(
            "planStartDateIso" to "2026-11-09",
            "planWeeks" to 53,
            "workouts" to "[{}]",
            "feedbackRecords" to "[]",
            "cooperAssessments" to "[]",
            "raceEvents" to "[]"
        ))
        assertThrows(IllegalArgumentException::class.java) { AppBackupCodec.decode(encoded) }
    }

    @Test fun `backup manifest detects missing or modified plan data`() {
        val encoded = AppBackupCodec.encode(mapOf(
            "planStartDateIso" to "2026-11-09",
            "planWeeks" to 8,
            "workouts" to "[{},{}]",
            "feedbackRecords" to "[]",
            "cooperAssessments" to "[]",
            "raceEvents" to "[]"
        ))
        val tampered = encoded.replace("[{},{}]", "[{}]")
        assertThrows(IllegalArgumentException::class.java) { AppBackupCodec.decode(tampered) }
    }

}
