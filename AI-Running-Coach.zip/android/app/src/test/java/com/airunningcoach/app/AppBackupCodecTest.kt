package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class AppBackupCodecTest {
    @Test fun roundTripPreservesAllSupportedPreferenceTypesAndSavedRecords() {
        val source = mapOf<String, Any>(
            "name" to "Atleta",
            "frequency" to 3,
            "runningExperienceDuration" to "1–3 anos",
            "ageYearsText" to "32",
            "birthDateText" to "10/04/1994",
            "referenceSex" to "MASCULINO",
            "fitnessTestMethod" to "THREE_KM",
            "threeKmTimeText" to "15:30",
            "activeWeeksLast4" to 3,
            "createdAt" to 1762862400000L,
            "cooperEnabled" to true,
            "volumeFactor" to 1.25f,
            "availableTrainingDaysSet" to setOf("MONDAY", "WEDNESDAY", "FRIDAY"),
            "workouts" to "[]",
            "raceEvents" to "[]",
            "feedbackRecords" to "[]",
            "cooperAssessments" to "[]",
            "racePlanWarnings" to "[]",
            "motorState" to "{}"
        )

        val decoded = AppBackupCodec.decode(AppBackupCodec.encode(source, "2026-11-11T12:00:00Z"))
        source.filterKeys { it !in setOf("selectedScreen", "selectedWorkoutIndex") }.forEach { (key, value) ->
            assertEquals("Mismatch in $key", value, decoded[key])
        }
    }

    @Test fun backupDoesNotRestoreTransientNavigationState() {
        val encoded = AppBackupCodec.encode(mapOf("name" to "Atleta", "selectedScreen" to 9, "selectedWorkoutIndex" to 4))
        val decoded = AppBackupCodec.decode(encoded)
        assertTrue(decoded.containsKey("name"))
        assertFalse(decoded.containsKey("selectedScreen"))
        assertFalse(decoded.containsKey("selectedWorkoutIndex"))
    }

    @Test fun rejectsWrongApplicationAndUnsupportedFormat() {
        val wrongApp = AppBackupCodec.encode(mapOf("name" to "Atleta")).replace("com.airunningcoach.app", "other.app")
        assertThrows(IllegalArgumentException::class.java) { AppBackupCodec.decode(wrongApp) }
        assertThrows(IllegalArgumentException::class.java) { AppBackupCodec.decode("{\"format\":\"unknown\"}") }
    }

    @Test fun rejectsMalformedSavedWorkoutJsonBeforeRestore() {
        val broken = AppBackupCodec.encode(mapOf("name" to "Atleta", "workouts" to "not-json"))
        assertThrows(Exception::class.java) { AppBackupCodec.decode(broken) }
    }

    @Test fun acceptsAnEmptyBackupForAProfileNotYetConfigured() {
        assertTrue(AppBackupCodec.decode(AppBackupCodec.encode(emptyMap<String, Any>())).isEmpty())
    }

    @Test fun rejectsWrongPreferenceTypesBeforeRestore() {
        val wrongType = AppBackupCodec.encode(mapOf("frequency" to "three"))
        assertThrows(IllegalArgumentException::class.java) { AppBackupCodec.decode(wrongType) }
    }
    @Test fun `schema three backup includes a complete record manifest`() {
        val encoded = AppBackupCodec.encode(mapOf(
            "planStartDateIso" to "2026-11-09",
            "planWeeks" to 8,
            "workouts" to "[{},{}]",
            "feedbackRecords" to "[{}]",
            "cooperAssessments" to "[]",
            "raceEvents" to "[]"
        ))
        val root = org.json.JSONObject(encoded)
        assertEquals(3, root.getInt("schemaVersion"))
        assertEquals("V78", root.getString("appVersion"))
        assertEquals(2, root.getJSONObject("manifest").getInt("workoutCount"))
        assertEquals(8, AppBackupCodec.decode(encoded)["planWeeks"])
    }

    @Test fun `backup accepts every supported macrocycle length up to 52 weeks`() {
        listOf(4, 8, 16, 20, 36, 52).forEach { weeks ->
            val encoded = AppBackupCodec.encode(mapOf(
                "planStartDateIso" to "2026-11-09",
                "planWeeks" to weeks,
                "workouts" to "[{}]",
                "feedbackRecords" to "[]",
                "cooperAssessments" to "[]",
                "raceEvents" to "[]"
            ))
            assertEquals(weeks, AppBackupCodec.decode(encoded)["planWeeks"])
        }
    }

    @Test fun `backup rejects a macrocycle beyond the supported 52 weeks`() {
        val encoded = AppBackupCodec.encode(mapOf(
            "planStartDateIso" to "2026-11-09",
            "planWeeks" to 53,
            "workouts" to "[{}]",
            "feedbackRecords" to "[]",
            "cooperAssessments" to "[]",
            "raceEvents" to "[]"
        ))
        assertThrows(IllegalArgumentException::class.java) { AppBackupCodec.decode(encoded) }
    }

    @Test fun `backup manifest detects missing or modified plan data`() {
        val encoded = AppBackupCodec.encode(mapOf(
            "planStartDateIso" to "2026-11-09",
            "planWeeks" to 8,
            "workouts" to "[{},{}]",
            "feedbackRecords" to "[]",
            "cooperAssessments" to "[]",
            "raceEvents" to "[]"
        ))
        val tampered = encoded.replace("[{},{}]", "[{}]")
        assertThrows(IllegalArgumentException::class.java) { AppBackupCodec.decode(tampered) }
    }

    @Test fun `historico seletivo aceita backup sem ancora do plano mas backup completo rejeita`() {
        val encoded = AppBackupCodec.encode(mapOf(
            "workouts" to "[{\"sessionId\":\"old-1\",\"done\":true}]",
            "feedbackRecords" to "[]"
        ))
        assertTrue(AppBackupCodec.decode(encoded, requireCompletePlan = false).containsKey("workouts"))
        assertThrows(IllegalArgumentException::class.java) { AppBackupCodec.decode(encoded) }
    }

    @Test fun `importacao seletiva mescla somente concluidos preserva base e ignora duplicados`() {
        val merged = CompletedActivityBackupMerger.merge(
            "[{\"sessionId\":\"current-1\",\"done\":false},{\"sessionId\":\"keep-1\",\"done\":true}]",
            "[{\"sessionId\":\"keep-1\",\"activityFingerprint\":\"hash-keep\"}]",
            "[{\"sessionId\":\"current-1\",\"done\":true},{\"sessionId\":\"new-1\",\"done\":true},{\"sessionId\":\"future-1\",\"done\":false}]",
            "[{\"sessionId\":\"new-1\",\"activityFingerprint\":\"hash-new\",\"actualDistanceKm\":5.0},{\"sessionId\":\"new-1\",\"activityFingerprint\":\"hash-new\",\"actualDistanceKm\":5.0}]"
        )
        val workouts = org.json.JSONArray(merged.workoutsJson)
        assertEquals(3, workouts.length())
        assertTrue(workouts.getJSONObject(0).getBoolean("done"))
        assertEquals(1, merged.addedWorkouts)
        assertEquals(2, org.json.JSONArray(merged.feedbackJson).length())
        assertEquals(1, merged.addedFeedback)
    }

    @Test fun `importacao seletiva preserva sessoes locais legadas sem sessionId`() {
        val merged = CompletedActivityBackupMerger.merge(
            "[{\"title\":\"Treino legado\",\"done\":true},{\"sessionId\":\"keep-1\",\"done\":false}]",
            "[]", "[{\"sessionId\":\"new-1\",\"done\":true}]", "[]"
        )
        val workouts = org.json.JSONArray(merged.workoutsJson)
        assertEquals(3, workouts.length())
        assertEquals("Treino legado", workouts.getJSONObject(0).getString("title"))
        assertTrue(workouts.getJSONObject(2).getBoolean("done"))
    }

    @Test fun `backup anterior da V71 continua legivel pela V78`() {
        // V71 already used schema 3; compatibility is identified by appVersion, not by
        // downgrading the schema. V70/schema 2 remains covered by the legacy schema tests.
        val oldBackup = AppBackupCodec.encode(mapOf("name" to "Atleta", "workouts" to "[]"))
            .replace("\"appVersion\": \"V78\"", "\"appVersion\": \"V71\"")
        assertEquals(3, org.json.JSONObject(oldBackup).getInt("schemaVersion"))
        assertEquals("Atleta", AppBackupCodec.decode(oldBackup)["name"])
    }

}
