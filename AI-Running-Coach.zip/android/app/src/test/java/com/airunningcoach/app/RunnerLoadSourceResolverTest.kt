package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class RunnerLoadSourceResolverTest {
    @Test fun `historico confiavel pode orientar a prescricao sem alterar cadastro declarado`() {
        val sources = RunnerLoadSourceResolver.resolve(
            declaredWeeklyKm = 16.0,
            declaredLongestKm = 10.0,
            fallbackWeeklyKm = 12.0,
            fallbackLongestKm = 8.0,
            measuredWeeklyKm = 8.5,
            measuredLongestKm = 6.6,
            measuredHistoryReliable = true
        )
        assertEquals(16.0, sources.declaredWeeklyKm!!, 0.001)
        assertEquals(10.0, sources.declaredLongestKm!!, 0.001)
        assertEquals(8.5, sources.planningWeeklyKm, 0.001)
        assertEquals(6.6, sources.planningLongestKm, 0.001)
    }

    @Test fun `historico parcial nao substitui base declarada`() {
        val sources = RunnerLoadSourceResolver.resolve(
            declaredWeeklyKm = 16.0,
            declaredLongestKm = 10.0,
            fallbackWeeklyKm = 12.0,
            fallbackLongestKm = 8.0,
            measuredWeeklyKm = 8.5,
            measuredLongestKm = 6.6,
            measuredHistoryReliable = false
        )
        assertEquals(16.0, sources.planningWeeklyKm, 0.001)
        assertEquals(10.0, sources.planningLongestKm, 0.001)
    }

    @Test fun `cadastro vazio utiliza base do objetivo e ainda pode considerar corrida medida maior`() {
        val sources = RunnerLoadSourceResolver.resolve(
            declaredWeeklyKm = null,
            declaredLongestKm = null,
            fallbackWeeklyKm = 12.0,
            fallbackLongestKm = 8.0,
            measuredWeeklyKm = 6.0,
            measuredLongestKm = 9.0,
            measuredHistoryReliable = false
        )
        assertNull(sources.declaredWeeklyKm)
        assertNull(sources.declaredLongestKm)
        assertEquals(12.0, sources.planningWeeklyKm, 0.001)
        assertEquals(9.0, sources.planningLongestKm, 0.001)
    }
}
