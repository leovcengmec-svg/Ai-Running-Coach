package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class HistorySnapshotEngineTest {
    private fun workout(
        sessionId: String,
        date: String,
        type: String = "Rodagem",
        done: Boolean = false,
        originalDate: String = ""
    ) = Workout(
        date = date,
        scheduledDateIso = date,
        title = "$type de teste",
        detail = "",
        type = type,
        objective = "",
        stimulus = "",
        distanceKm = 5.0,
        done = done,
        sessionId = sessionId,
        originalScheduledDateIso = originalDate
    )

    private fun feedback(
        id: String,
        sessionId: String,
        date: String,
        type: String = "Rodagem",
        originalDate: String = date,
        distanceKm: Double? = 5.0,
        duration: String? = "40:00",
        deleted: Boolean = false,
        realizedDate: String = date,
        canonicalKey: String = SessionIdentityEngine.canonicalSlotKey(originalDate, type)
    ) = FeedbackRecord(
        sessionId = sessionId,
        effort = "Leve",
        feeling = "Bem",
        notes = "",
        actualDistanceKm = distanceKm,
        actualDuration = duration,
        actualPaceMinKm = "8:00",
        workoutDateIso = date,
        workoutOriginalDateIso = originalDate,
        workoutType = type,
        workoutTitle = "$type de teste",
        realizedDateIso = realizedDate,
        canonicalWorkoutKey = canonicalKey,
        recordId = id,
        deleted = deleted
    )

    @Test fun exactSessionMatchIsIndexedOnceAndMeasuredTotalsUseOnlyRealData() {
        val workouts = listOf(
            workout("session-1", "2026-11-24"),
            workout("session-2", "2026-11-22", done = true)
        )
        val records = listOf(
            feedback("record-1", "session-1", "2026-11-24", distanceKm = 5.8, duration = "43:25"),
            feedback("record-2", "session-2", "2026-11-22", distanceKm = null, duration = null)
        )

        val snapshot = HistorySnapshotEngine.build(workouts, records)
        val filtered = HistorySnapshotEngine.filter(snapshot, "TODOS", LocalDate.parse("2026-11-26"))

        assertEquals(2, snapshot.completed.size)
        assertTrue(snapshot.orphaned.isEmpty())
        assertEquals(setOf("record-1", "record-2"), snapshot.completed.mapNotNull { it.feedback?.recordId }.toSet())
        assertEquals(2, filtered.summary.sessionCount)
        assertEquals(5.8, filtered.summary.measuredDistanceKm, 0.0001)
        assertEquals(43 * 60 + 25, filtered.summary.measuredDurationSeconds)
    }

    @Test fun remappedLegacySessionIdLinksOnlyThroughUniqueCanonicalPlannedSlot() {
        val workout = workout("new-cycle-session", "2026-11-24", originalDate = "2026-11-24")
        val oldRecord = feedback(
            id = "legacy-record",
            sessionId = "old-cycle-session",
            date = "2026-11-24",
            originalDate = "2026-11-24"
        )

        val snapshot = HistorySnapshotEngine.build(listOf(workout), listOf(oldRecord))

        assertEquals(1, snapshot.completed.size)
        assertEquals("legacy-record", snapshot.completed.single().feedback?.recordId)
        assertTrue(snapshot.orphaned.isEmpty())
    }

    @Test fun ambiguousCanonicalSlotRemainsOrphanedInsteadOfDuplicatingAcrossSessions() {
        val workouts = listOf(
            workout("session-a", "2026-11-24", originalDate = "2026-11-24"),
            workout("session-b", "2026-11-24", originalDate = "2026-11-24")
        )
        val record = feedback("ambiguous-record", "legacy-id", "2026-11-24", originalDate = "2026-11-24")

        val snapshot = HistorySnapshotEngine.build(workouts, listOf(record))

        assertTrue(snapshot.completed.isEmpty())
        assertEquals(1, snapshot.orphaned.size)
        assertEquals("ambiguous-record", snapshot.orphaned.single().record.recordId)
    }

    @Test fun realizedDateAloneNeverLinksAFeedbackToAWorkout() {
        val workout = workout("new-session", "2026-11-24")
        val record = feedback(
            id = "unlinked-record",
            sessionId = "old-session",
            date = "",
            originalDate = "",
            canonicalKey = "",
            realizedDate = "2026-11-24"
        )

        val snapshot = HistorySnapshotEngine.build(listOf(workout), listOf(record))

        assertTrue(snapshot.completed.isEmpty())
        assertEquals(1, snapshot.orphaned.size)
    }

    @Test fun deletedRecordsAreSeparatedAndExcludedFromActiveSummary() {
        val workout = workout("session-1", "2026-11-24")
        val active = feedback("active", "session-1", "2026-11-24", distanceKm = 5.0)
        val deleted = feedback("deleted", "old-session", "2026-11-20", distanceKm = 20.0, deleted = true)

        val snapshot = HistorySnapshotEngine.build(listOf(workout), listOf(active, deleted))
        val filtered = HistorySnapshotEngine.filter(snapshot, "TODOS", LocalDate.parse("2026-11-26"))

        assertEquals(1, filtered.completed.size)
        assertEquals(1, filtered.deleted.size)
        assertEquals(1, filtered.summary.sessionCount)
        assertEquals(5.0, filtered.summary.measuredDistanceKm, 0.0001)
    }

    @Test fun weekMonthAndYearFiltersUseTheSameDateWindowForListAndSummary() {
        val dates = listOf("2026-11-24", "2026-11-22", "2026-10-31", "2025-12-31")
        val workouts = dates.mapIndexed { index, date -> workout("session-$index", date) }
        val records = dates.mapIndexed { index, date -> feedback("record-$index", "session-$index", date) }
        val snapshot = HistorySnapshotEngine.build(workouts, records)
        val today = LocalDate.parse("2026-11-26")

        val week = HistorySnapshotEngine.filter(snapshot, "SEMANA", today)
        val month = HistorySnapshotEngine.filter(snapshot, "MÊS", today)
        val year = HistorySnapshotEngine.filter(snapshot, "ANO", today)

        assertEquals(1, week.completed.size)
        assertEquals(1, week.summary.sessionCount)
        assertEquals(2, month.completed.size)
        assertEquals(2, month.summary.sessionCount)
        assertEquals(3, year.completed.size)
        assertEquals(3, year.summary.sessionCount)
    }

    @Test fun thousandSessionsRemainUniqueAndFilterWithoutRebuildingSourceLinks() {
        val workouts = (0 until 1_000).map { index ->
            workout("session-$index", "2026-11-24", originalDate = "2026-11-24")
        }
        val records = (0 until 1_000).map { index ->
            feedback("record-$index", "session-$index", "2026-11-24", originalDate = "2026-11-24")
        }

        val snapshot = HistorySnapshotEngine.build(workouts, records)
        val week = HistorySnapshotEngine.filter(snapshot, "SEMANA", LocalDate.parse("2026-11-26"))
        val month = HistorySnapshotEngine.filter(snapshot, "MÊS", LocalDate.parse("2026-11-26"))

        assertEquals(1_000, snapshot.completed.size)
        assertEquals(1_000, week.summary.sessionCount)
        assertEquals(1_000, month.summary.sessionCount)
        assertEquals(1_000, snapshot.completed.map { it.stableKey }.toSet().size)
        assertEquals(1_000, snapshot.completed.mapNotNull { it.feedback?.recordId }.toSet().size)
        assertFalse(snapshot.completed.any { it.feedback == null })
    }
}
