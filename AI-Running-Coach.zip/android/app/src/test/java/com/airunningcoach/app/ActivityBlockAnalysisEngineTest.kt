package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ActivityBlockAnalysisEngineTest {
    private val z2 = PaceZone("Z2", "Aeróbio", "", PaceRange(450, 540), "LOW")
    private val z4 = PaceZone("Z4", "Limiar", "", PaceRange(300, 360), "HIGH")

    @Test fun `alinha blocos temporais e separa repeticoes de intervalo e recuperacao`() {
        val plan = listOf(
            WorkoutSegment("Aquecimento", "", durationMin = 1, targetMode = "TIME", paceZone = "Z2", targetPaceMinValue = 450, targetPaceMaxValue = 540),
            WorkoutSegment("Intervalo", "", durationMin = 1, repeatCount = 2, targetMode = "TIME", paceZone = "Z4", targetPaceMinValue = 300, targetPaceMaxValue = 360),
            WorkoutSegment("Recuperação", "", durationMin = 1, repeatCount = 2, targetMode = "TIME", paceZone = "Z2", targetPaceMinValue = 450, targetPaceMaxValue = 540),
            WorkoutSegment("Desaquecimento", "", durationMin = 1, targetMode = "TIME", paceZone = "Z2", targetPaceMinValue = 450, targetPaceMaxValue = 540)
        )
        // 10-second samples: one minute per planned block, pace and provenance are measured.
        val samples = buildList {
            var distance = 0.0
            repeat(36) { index ->
                val pace = when (index / 6) {
                    0, 2, 4 -> 500
                    else -> 330
                }
                val stepDistance = 10_000.0 / pace
                add(ActivityPaceSegment(
                    paceSecondsPerKm = pace,
                    durationSeconds = 10,
                    startElapsedSeconds = index * 10,
                    startDistanceMeters = distance,
                    distanceMeters = stepDistance,
                    averageHeartRateBpm = 150,
                    averageCadenceSpm = 170
                ))
                distance += stepDistance
            }
        }
        val results = ActivityBlockAnalysisEngine.analyze(samples, plan, listOf(z2, z4))
        assertEquals(6, results.size)
        assertEquals("Aquecimento", results.first().name)
        assertEquals("Intervalo", results[1].name)
        assertEquals("Recuperação", results[2].name)
        assertEquals(2, results[3].repetition)
        assertEquals("Intervalo", results[3].name)
        assertEquals("DENTRO_DA_META", results[1].status)
        assertEquals("Boa", results[1].confidence)
    }

    @Test fun `bloco sem amostras e marcado sem dados sem inventar resultado`() {
        val plan = listOf(WorkoutSegment("Intervalo", "", durationMin = 2, targetMode = "TIME", paceZone = "Z4"))
        val results = ActivityBlockAnalysisEngine.analyze(emptyList(), plan, listOf(z4))
        assertTrue(results.isEmpty())
    }
}
