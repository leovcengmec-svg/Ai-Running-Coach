package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ActivityBlockAnalysisEngineTest {
    private val z2 = PaceZone("Z2", "Aeróbio", "", PaceRange(450, 540), "LOW")
    private val z4 = PaceZone("Z4", "Limiar", "", PaceRange(300, 360), "HIGH")

    @Test fun `alinha blocos temporais e separa repeticoes de intervalo e recuperacao`() {
        val plan = listOf(
            WorkoutSegment("Aquecimento", "", durationMin = 1, targetMode = "TIME", paceZone = "Z2", targetPaceMinValue = 450, targetPaceMaxValue = 540),
            WorkoutSegment("Intervalo", "", durationMin = 1, repeatCount = 2, targetMode = "TIME", paceZone = "Z4", targetPaceMinValue = 300, targetPaceMaxValue = 360),
            WorkoutSegment("Recuperação", "", durationMin = 1, repeatCount = 2, targetMode = "TIME", paceZone = "Z2", targetPaceMinValue = 450, targetPaceMaxValue = 540),
            WorkoutSegment("Desaquecimento", "", durationMin = 1, targetMode = "TIME", paceZone = "Z2", targetPaceMinValue = 450, targetPaceMaxValue = 540)
        )
        // 10-second samples: one minute per planned block, pace and provenance are measured.
        val samples = buildList {
            var distance = 0.0
            repeat(36) { index ->
                val pace = when (index / 6) {
                    0, 2, 4 -> 500
                    else -> 330
                }
                val stepDistance = 10_000.0 / pace
                add(ActivityPaceSegment(
                    paceSecondsPerKm = pace,
                    durationSeconds = 10,
                    startElapsedSeconds = index * 10,
                    startDistanceMeters = distance,
                    distanceMeters = stepDistance,
                    averageHeartRateBpm = 150,
                    averageCadenceSpm = 170
                ))
                distance += stepDistance
            }
        }
        val results = ActivityBlockAnalysisEngine.analyze(samples, plan, listOf(z2, z4))
        assertEquals(6, results.size)
        assertEquals("Aquecimento", results.first().name)
        assertEquals("Intervalo", results[1].name)
        assertEquals("Recuperação", results[2].name)
        assertEquals(2, results[3].repetition)
        assertEquals("Intervalo", results[3].name)
        assertEquals("DENTRO_DA_META", results[1].status)
        assertEquals("Boa", results[1].confidence)
    }

    @Test fun `bloco sem amostras e marcado sem dados sem inventar resultado`() {
        val plan = listOf(WorkoutSegment("Intervalo", "", durationMin = 2, targetMode = "TIME", paceZone = "Z4"))
        val results = ActivityBlockAnalysisEngine.analyze(emptyList(), plan, listOf(z4))
        assertTrue(results.isEmpty())
    }
    @Test fun `ritmo mais rapido em intervalo nao e classificado como fora da meta`() {
        val planned = listOf(WorkoutSegment(
            "Intervalo", "", durationMin = 1, targetMode = "TIME", paceZone = "Z4",
            targetPaceMinValue = 300, targetPaceMaxValue = 360
        ))
        val samples = (0..5).map { index ->
            ActivityPaceSegment(
                paceSecondsPerKm = 280, durationSeconds = 10,
                startElapsedSeconds = index * 10, startDistanceMeters = index * 35.7,
                distanceMeters = 35.7
            )
        }
        val result = ActivityBlockAnalysisEngine.analyze(samples, planned, listOf(z4)).single()
        assertEquals("MAIS_RAPIDO_QUE_META", result.status)
    }

    @Test fun `GPX esparso sem voltas explicitas nao recebe alinhamento falso por bloco`() {
        val planned = listOf(
            WorkoutSegment("Aquecimento", "", durationMin = 5, targetMode = "TIME", paceZone = "Z2"),
            WorkoutSegment("Intervalo", "", durationMin = 3, targetMode = "TIME", paceZone = "Z4"),
            WorkoutSegment("Desaquecimento", "", durationMin = 5, targetMode = "TIME", paceZone = "Z2")
        )
        val sparse = listOf(ActivityPaceSegment(639, 7, startElapsedSeconds = 0, startDistanceMeters = 0.0, distanceMeters = 10.95))
        assertTrue(ActivityBlockAnalysisEngine.analyze(sparse, planned, listOf(z2, z4)).isEmpty())
    }

    @Test fun `voltas explicitas em quantidade diferente do plano viram resumo sem atribuicao arbitraria`() {
        val planned = listOf(
            WorkoutSegment("Aquecimento", "", durationMin = 5, targetMode = "TIME", paceZone = "Z2"),
            WorkoutSegment("Intervalo", "", durationMin = 3, repeatCount = 4, targetMode = "TIME", paceZone = "Z4"),
            WorkoutSegment("Recuperação", "", durationMin = 2, repeatCount = 3, targetMode = "TIME", recoveryMode = "WALK"),
            WorkoutSegment("Desaquecimento", "", durationMin = 5, targetMode = "TIME", paceZone = "Z2")
        )
        val laps = (0..4).mapIndexed { index, _ ->
            ActivityPaceSegment(400 + index, 300, startElapsedSeconds = index * 300, startDistanceMeters = index * 750.0,
                distanceMeters = 750.0, sourceType = "EXPLICIT_LAP", sourceBlockIndex = index)
        }
        val result = ActivityBlockAnalysisEngine.analyze(laps, planned, listOf(z2, z4)).single()
        assertTrue(result.name.contains("sem alinhamento 1:1"))
        assertEquals("SEM_ALVO", result.status)
        assertEquals(1500, result.actualDurationSeconds)
        assertEquals("Voltas registradas • sem correspondência 1:1", result.confidence)
    }


    @Test fun `voltas com mesma quantidade mas dose diferente nao sao alinhadas como blocos`() {
        val planned = listOf(
            WorkoutSegment("Aquecimento", "", distanceKm = 1.0, targetMode = "DISTANCE", paceZone = "Z2"),
            WorkoutSegment("Intervalo", "", distanceKm = 0.6, targetMode = "DISTANCE", paceZone = "Z4"),
            WorkoutSegment("Recuperação", "", durationMin = 2, targetMode = "TIME", recoveryMode = "WALK"),
            WorkoutSegment("Intervalo", "", distanceKm = 0.6, targetMode = "DISTANCE", paceZone = "Z4"),
            WorkoutSegment("Desaquecimento", "", distanceKm = 0.8, targetMode = "DISTANCE", paceZone = "Z2")
        )
        val laps = listOf(1.0, 1.0, 1.0, 1.0, 1.0).mapIndexed { index, km ->
            ActivityPaceSegment(360, 360, startElapsedSeconds = index * 360,
                startDistanceMeters = index * km * 1000.0, distanceMeters = km * 1000.0,
                sourceType = "EXPLICIT_LAP", sourceBlockIndex = index)
        }
        val result = ActivityBlockAnalysisEngine.analyze(laps, planned, listOf(z2, z4)).single()
        assertTrue(result.name.contains("sem alinhamento 1:1"))
        assertEquals("SEM_ALVO", result.status)
    }

    @Test fun `voltas explicitas so alinhadas quando dose e ordem correspondem aos blocos`() {
        val planned = listOf(
            WorkoutSegment("Aquecimento", "", distanceKm = 1.0, targetMode = "DISTANCE", paceZone = "Z2"),
            WorkoutSegment("Intervalo", "", distanceKm = 0.6, targetMode = "DISTANCE", paceZone = "Z4"),
            WorkoutSegment("Recuperação caminhando", "", durationMin = 2, targetMode = "TIME", recoveryMode = "WALK"),
            WorkoutSegment("Desaquecimento", "", distanceKm = 0.8, targetMode = "DISTANCE", paceZone = "Z2")
        )
        val laps = listOf(
            ActivityPaceSegment(500, 360, startElapsedSeconds = 0, startDistanceMeters = 0.0, distanceMeters = 1_000.0, sourceType = "EXPLICIT_LAP"),
            ActivityPaceSegment(330, 200, startElapsedSeconds = 360, startDistanceMeters = 1_000.0, distanceMeters = 606.0, sourceType = "EXPLICIT_LAP"),
            ActivityPaceSegment(800, 120, startElapsedSeconds = 560, startDistanceMeters = 1_606.0, distanceMeters = 150.0, sourceType = "EXPLICIT_LAP"),
            ActivityPaceSegment(520, 416, startElapsedSeconds = 680, startDistanceMeters = 1_756.0, distanceMeters = 800.0, sourceType = "EXPLICIT_LAP")
        )
        val result = ActivityBlockAnalysisEngine.analyze(laps, planned, listOf(z2, z4))
        assertEquals(4, result.size)
        assertEquals("Volta registrada", result[0].confidence)
        assertEquals("Intervalo", result[1].name)
        assertEquals("DENTRO_DA_META", result[1].status)
    }


}
