package com.airunningcoach.app

import java.time.DayOfWeek
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TrainingPrescriptionAuditTest {
    @Test
    fun `prescricoes de diferentes objetivos fecham distancia e respeitam zonas`() {
        val zones = PaceCalculator.calculateCooper(2.5)!!
        val goals = listOf(1.609, 3.0, 5.0, 10.0, 15.0, 21.1, 42.195, 50.0)
        goals.forEach { goal ->
            val plan = RunningCoachEngine.generate(
                RunnerInput(
                    goalKm = goal,
                    level = "Avançado",
                    frequency = 4,
                    availableDays = listOf(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.THURSDAY, DayOfWeek.SATURDAY),
                    preferredLongRunDay = DayOfWeek.SATURDAY,
                    weeklyVolumeKm = 30.0,
                    longestRecentKm = 12.0,
                    experienceMonths = 48,
                    activeWeeksLast4 = 4,
                    recoveryScore = 85.0,
                    fatigueScore = 25.0,
                    planWeeks = 8,
                    cooperDistanceKm = 2.5,
                    calibratedPaceZones = zones,
                    startDate = LocalDate.of(2026, 11, 16)
                )
            )
            assertEquals("Oito semanas para objetivo $goal", 8, plan.weeklySummaries.size)
            plan.workouts.forEach { workout ->
                assertTrue("${workout.title} ($goal): ${TrainingPrescriptionAudit.validate(workout)}", TrainingPrescriptionAudit.validate(workout).isEmpty())
                val sum = TrainingPrescriptionAudit.estimatedSegmentDistanceKm(workout.segments)
                assertEquals(workout.distanceKm, sum, 0.11)
            }
        }
    }

    @Test
    fun `nome da etapa e zona pace devem corresponder`() {
        val zones = PaceCalculator.calculateCooper(2.5)!!
        val z1 = zones.z1.range
        val active = ZoneIntensityBandEngine.activeRange(z1, ZoneIntensityBandEngine.z1WarmupCoolDownBand)
        val wrong = WorkoutSegment(
            name = "Bloco principal Z3",
            instruction = "Teste inconsistente",
            distanceKm = 1.0,
            paceZone = "Z1",
            targetPaceMinValue = active.fastestPaceValue,
            targetPaceMaxValue = active.slowestPaceValue,
            zoneBasePaceFastValue = z1.fastestPaceValue,
            zoneBasePaceSlowValue = z1.slowestPaceValue,
            zoneIntensityMinPercent = 80,
            zoneIntensityMaxPercent = 100
        )
        val workout = PrescribedWorkout(
            day = "Dia", date = "Data", scheduledDateIso = "2026-11-16", title = "Teste", type = "Aeróbio",
            objective = "Teste", stimulus = "TEST", sessionId = "bad-zone-name", distanceKm = 1.0, durationMin = 10,
            intensity = "LOW", paceMode = "PACE_RANGE", rpeRange = "2-3", detail = "", rationale = "",
            segments = listOf(wrong)
        )
        assertTrue(TrainingPrescriptionAudit.validate(workout).any { it.contains("nome e zona prescrita") })
    }

    @Test
    fun `objetivo de saude preserva frequencia mas nao injeta qualidade`() {
        val zones = PaceCalculator.calculateCooper(2.5)!!
        val plan = RunningCoachEngine.generate(
            RunnerInput(
                goalKm = 5.0,
                level = "Avançado",
                frequency = 4,
                availableDays = listOf(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.THURSDAY, DayOfWeek.SATURDAY),
                weeklyVolumeKm = 20.0,
                longestRecentKm = 10.0,
                experienceMonths = 48,
                activeWeeksLast4 = 4,
                recoveryScore = 85.0,
                fatigueScore = 25.0,
                calibratedPaceZones = zones,
                goalCategory = "HEALTH"
            )
        )
        assertEquals(4, plan.workouts.count { it.week == 1 })
        assertTrue(plan.workouts.none { it.type == "Qualidade" })
        assertTrue(plan.workouts.flatMap { it.segments }.none { it.paceZone in setOf("Z3", "Z4", "Z5") })
    }
    @Test
    fun `regenerativo para corredor experiente usa Z2 e iniciante usa caminhada corrida Z1`() {
        val zones = PaceCalculator.calculateCooper(2.5)!!
        val experienced = RunningCoachEngine.generate(
            RunnerInput(
                goalKm = 5.0,
                level = "Intermediário",
                frequency = 3,
                availableDays = listOf(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY),
                preferredLongRunDay = DayOfWeek.FRIDAY,
                weeklyVolumeKm = 16.0,
                longestRecentKm = 8.0,
                experienceMonths = 36,
                activeWeeksLast4 = 4,
                recoveryScore = 85.0,
                fatigueScore = 25.0,
                planWeeks = 4,
                calibratedPaceZones = zones,
                startDate = LocalDate.of(2026, 11, 16)
            )
        )
        val experiencedRecovery = experienced.workouts.first { it.stimulus == "RECOVERY_Z2_EXPERIENCED" }
        assertTrue(TrainingPrescriptionAudit.validate(experiencedRecovery).toString(), TrainingPrescriptionAudit.validate(experiencedRecovery).isEmpty())
        assertEquals("Z2", experiencedRecovery.segments.first { it.name == "Aquecimento" }.paceZone)
        assertEquals(0, experiencedRecovery.segments.first { it.name == "Aquecimento" }.zoneIntensityMinPercent)
        assertEquals(20, experiencedRecovery.segments.first { it.name == "Aquecimento" }.zoneIntensityMaxPercent)
        assertEquals(20, experiencedRecovery.segments.first { it.name.contains("regenerativo", true) }.zoneIntensityMinPercent)
        assertEquals(50, experiencedRecovery.segments.first { it.name.contains("regenerativo", true) }.zoneIntensityMaxPercent)
        assertEquals(0, experiencedRecovery.segments.last().zoneIntensityMinPercent)
        assertEquals(20, experiencedRecovery.segments.last().zoneIntensityMaxPercent)

        val novice = RunningCoachEngine.generate(
            RunnerInput(
                goalKm = 5.0,
                level = "Iniciante",
                frequency = 3,
                availableDays = listOf(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY),
                weeklyVolumeKm = 3.0,
                longestRecentKm = 1.5,
                runWalkEligible = true,
                experienceMonths = 2,
                activeWeeksLast4 = 2,
                planWeeks = 4,
                calibratedPaceZones = zones,
                startDate = LocalDate.of(2026, 11, 16)
            )
        )
        val noviceRecovery = novice.workouts.first { it.week == 4 && it.stimulus.startsWith("BEGINNER_RUN_WALK") }
        assertTrue(noviceRecovery.segments.any { it.name.contains("caminhada", true) })
        val noviceRunningBlocks = noviceRecovery.segments.filter { it.name.contains("corrida", true) && it.paceZone != null }
        assertTrue("O regenerativo iniciante deve manter blocos de corrida Z1", noviceRunningBlocks.isNotEmpty())
        assertTrue(noviceRunningBlocks.all { it.paceZone == "Z1" })
        assertTrue(noviceRunningBlocks.all { it.zoneIntensityMinPercent == 20 && it.zoneIntensityMaxPercent == 65 })
    }


    @Test
    fun `biblioteca inteira passa pela auditoria em perfis iniciante intermediario e avancado`() {
        val zones = PaceCalculator.calculateCooper(2.5)!!
        val start = LocalDate.of(2026, 11, 23)
        val profiles = listOf(
            RunnerInput(
                goalKm = 5.0, level = "Iniciante", frequency = 3,
                availableDays = listOf(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY),
                preferredLongRunDay = DayOfWeek.FRIDAY, weeklyVolumeKm = 3.0, longestRecentKm = 1.5,
                runWalkEligible = true, experienceMonths = 2, activeWeeksLast4 = 2, planWeeks = 4,
                cooperDistanceKm = 2.0, calibratedPaceZones = zones, startDate = start
            ),
            RunnerInput(
                goalKm = 5.0, level = "Intermediário", frequency = 3,
                availableDays = listOf(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY),
                preferredLongRunDay = DayOfWeek.FRIDAY, weeklyVolumeKm = 16.0, longestRecentKm = 8.0,
                experienceMonths = 36, activeWeeksLast4 = 4, recoveryScore = 85.0, fatigueScore = 25.0,
                planWeeks = 8, cooperDistanceKm = 2.5, calibratedPaceZones = zones, startDate = start
            ),
            RunnerInput(
                goalKm = 10.0, level = "Avançado", frequency = 4,
                availableDays = listOf(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.THURSDAY, DayOfWeek.SATURDAY),
                preferredLongRunDay = DayOfWeek.SATURDAY, weeklyVolumeKm = 30.0, longestRecentKm = 12.0,
                experienceMonths = 48, activeWeeksLast4 = 4, recoveryScore = 85.0, fatigueScore = 25.0,
                planWeeks = 8, cooperDistanceKm = 2.8, calibratedPaceZones = zones,
                goalIntent = TrainingGoalIntent.PERSONAL_BEST, startDate = start
            )
        )
        profiles.forEachIndexed { profileIndex, input ->
            val plan = RunningCoachEngine.generate(input)
            assertTrue("Perfil $profileIndex não gerou sessões", plan.workouts.isNotEmpty())
            plan.workouts.forEach { workout ->
                val errors = TrainingPrescriptionAudit.validate(workout)
                assertTrue("Perfil $profileIndex · ${workout.title} · S${workout.week}: $errors", errors.isEmpty())
                val exportErrors = TrainingPrescriptionAudit.validateExportStructure(workout.segments, workout.stimulus)
                assertTrue("Exportação perfil $profileIndex · ${workout.title}: $exportErrors", exportErrors.isEmpty())
                assertEquals(workout.distanceKm, TrainingPrescriptionAudit.estimatedSegmentDistanceKm(workout.segments), 0.11)
            }
        }
    }

    @Test
    fun `rodagem com aceleracoes possui oito blocos individuais com tempos exatos`() {
        val segments = listOf(
            WorkoutSegment("Aquecimento", "Aqueça", distanceKm = 1.0),
            WorkoutSegment("Bloco aeróbio Z2", "Corra confortavelmente", distanceKm = 2.0, paceZone = "Z2"),
            WorkoutSegment("Aceleração 1", "Acelere tecnicamente", durationSeconds = 12, distanceKm = 0.05, targetMode = "TIME"),
            WorkoutSegment("Recuperação 1", "Caminhe", durationSeconds = 75, distanceKm = 0.1, targetMode = "TIME", recoveryMode = "WALK"),
            WorkoutSegment("Aceleração 2", "Acelere tecnicamente", durationSeconds = 12, distanceKm = 0.05, targetMode = "TIME"),
            WorkoutSegment("Recuperação 2", "Caminhe", durationSeconds = 75, distanceKm = 0.1, targetMode = "TIME", recoveryMode = "WALK"),
            WorkoutSegment("Aceleração 3", "Acelere tecnicamente", durationSeconds = 12, distanceKm = 0.05, targetMode = "TIME"),
            WorkoutSegment("Desaquecimento", "Reduza gradualmente", distanceKm = 0.65)
        )
        assertTrue(TrainingPrescriptionAudit.validateExportStructure(segments, "EASY_WITH_STRIDES_Z2_Z5").toString(),
            TrainingPrescriptionAudit.validateExportStructure(segments, "EASY_WITH_STRIDES_Z2_Z5").isEmpty())
    }

}
