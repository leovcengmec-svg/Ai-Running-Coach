package com.airunningcoach.app

import java.time.DayOfWeek
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TrainingPrescriptionAuditTest {
    @Test
    fun `prescricoes de diferentes objetivos fecham distancia e respeitam zonas`() {
        val zones = PaceCalculator.calculateCooper(2.5)!!
        val goals = listOf(1.609, 3.0, 5.0, 10.0, 15.0, 21.1, 42.195, 50.0)
        goals.forEach { goal ->
            val plan = RunningCoachEngine.generate(
                RunnerInput(
                    goalKm = goal,
                    level = "Avançado",
                    frequency = 4,
                    availableDays = listOf(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.THURSDAY, DayOfWeek.SATURDAY),
                    preferredLongRunDay = DayOfWeek.SATURDAY,
                    weeklyVolumeKm = 30.0,
                    longestRecentKm = 12.0,
                    experienceMonths = 48,
                    activeWeeksLast4 = 4,
                    recoveryScore = 85.0,
                    fatigueScore = 25.0,
                    planWeeks = 8,
                    cooperDistanceKm = 2.5,
                    calibratedPaceZones = zones,
                    startDate = LocalDate.of(2026, 11, 16)
                )
            )
            assertEquals("Oito semanas para objetivo $goal", 8, plan.weeklySummaries.size)
            plan.workouts.forEach { workout ->
                assertTrue("${workout.title} ($goal): ${TrainingPrescriptionAudit.validate(workout)}", TrainingPrescriptionAudit.validate(workout).isEmpty())
                val sum = TrainingPrescriptionAudit.estimatedSegmentDistanceKm(workout.segments)
                assertEquals(workout.distanceKm, sum, 0.11)
            }
        }
    }

    @Test
    fun `nome da etapa e zona pace devem corresponder`() {
        val zones = PaceCalculator.calculateCooper(2.5)!!
        val z1 = zones.z1.range
        val active = ZoneIntensityBandEngine.activeRange(z1, ZoneIntensityBandEngine.z1WarmupCoolDownBand)
        val wrong = WorkoutSegment(
            name = "Bloco principal Z3",
            instruction = "Teste inconsistente",
            distanceKm = 1.0,
            paceZone = "Z1",
            targetPaceMinValue = active.fastestPaceValue,
            targetPaceMaxValue = active.slowestPaceValue,
            zoneBasePaceFastValue = z1.fastestPaceValue,
            zoneBasePaceSlowValue = z1.slowestPaceValue,
            zoneIntensityMinPercent = 80,
            zoneIntensityMaxPercent = 100
        )
        val workout = PrescribedWorkout(
            day = "Dia", date = "Data", scheduledDateIso = "2026-11-16", title = "Teste", type = "Aeróbio",
            objective = "Teste", stimulus = "TEST", sessionId = "bad-zone-name", distanceKm = 1.0, durationMin = 10,
            intensity = "LOW", paceMode = "PACE_RANGE", rpeRange = "2-3", detail = "", rationale = "",
            segments = listOf(wrong)
        )
        assertTrue(TrainingPrescriptionAudit.validate(workout).any { it.contains("nome e zona prescrita") })
    }

    @Test
    fun `objetivo de saude preserva frequencia mas nao injeta qualidade`() {
        val zones = PaceCalculator.calculateCooper(2.5)!!
        val plan = RunningCoachEngine.generate(
            RunnerInput(
                goalKm = 5.0,
                level = "Avançado",
                frequency = 4,
                availableDays = listOf(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.THURSDAY, DayOfWeek.SATURDAY),
                weeklyVolumeKm = 20.0,
                longestRecentKm = 10.0,
                experienceMonths = 48,
                activeWeeksLast4 = 4,
                recoveryScore = 85.0,
                fatigueScore = 25.0,
                calibratedPaceZones = zones,
                goalCategory = "HEALTH"
            )
        )
        assertEquals(4, plan.workouts.count { it.week == 1 })
        assertTrue(plan.workouts.none { it.type == "Qualidade" })
        assertTrue(plan.workouts.flatMap { it.segments }.none { it.paceZone in setOf("Z3", "Z4", "Z5") })
    }
}
