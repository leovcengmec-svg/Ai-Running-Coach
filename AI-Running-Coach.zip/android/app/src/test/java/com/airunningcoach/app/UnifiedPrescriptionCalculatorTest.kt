package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class UnifiedPrescriptionCalculatorTest {
    @Test fun `prescricao por distancia calcula tempo e ritmo a partir do mesmo bloco`() {
        val segment = WorkoutSegment(
            name = "Rodagem", instruction = "", distanceKm = 5.0, targetMode = "DISTANCE",
            targetPaceMinValue = 447, targetPaceMaxValue = 447
        )
        val result = UnifiedPrescriptionCalculator.planned(listOf(segment))
        assertEquals(5.0, result.distanceKm!!, 0.0001)
        assertEquals(2_235, result.durationSeconds)
        assertEquals(447, result.paceSecondsPerKm)
    }

    @Test fun `prescricao por tempo estima distancia usando faixa de ritmo`() {
        val segment = WorkoutSegment(
            name = "Rodagem", instruction = "", durationMin = 40, targetMode = "TIME",
            targetPaceMinValue = 480, targetPaceMaxValue = 480
        )
        val result = UnifiedPrescriptionCalculator.planned(listOf(segment))
        assertEquals(5.0, result.distanceKm!!, 0.0001)
        assertEquals(2_400, result.durationSeconds)
        assertEquals(480, result.paceSecondsPerKm)
        assertTrue(result.distanceEstimated)
    }

    @Test fun `blocos mistos somam distancias e tempos sem misturar unidades`() {
        val segments = listOf(
            WorkoutSegment("Aquecimento", "", distanceKm = 2.0, targetMode = "DISTANCE", targetPaceMinValue = 480, targetPaceMaxValue = 480),
            WorkoutSegment("Tempo", "", durationMin = 20, targetMode = "TIME", targetPaceMinValue = 360, targetPaceMaxValue = 360),
            WorkoutSegment("Pausa", "", durationMin = 5, targetMode = "TIME", recoveryMode = "PASSIVE")
        )
        val result = UnifiedPrescriptionCalculator.planned(segments)
        assertEquals(5.3333, result.distanceKm!!, 0.001)
        assertEquals(2_460, result.durationSeconds)
        assertEquals(405, result.paceSecondsPerKm)
    }

    @Test fun `metricas realizadas calculam o pace a partir de distancia e tempo reais`() {
        val result = UnifiedPrescriptionCalculator.realized(5.0, "37:15")
        assertEquals(5.0, result.distanceKm!!, 0.0001)
        assertEquals(2_235, result.durationSeconds)
        assertEquals(447, result.paceSecondsPerKm)
    }

    @Test fun `prescricao por tempo sem ritmo e sem distancia nao inventa quilometragem`() {
        val segment = WorkoutSegment(
            name = "Bloco por tempo", instruction = "", durationMin = 30, targetMode = "TIME"
        )
        val result = UnifiedPrescriptionCalculator.planned(listOf(segment))
        assertNull(result.distanceKm)
        assertEquals(1_800, result.durationSeconds)
        assertNull(result.paceSecondsPerKm)
        assertTrue(result.distanceEstimated)
    }

    @Test fun `metrica realizada permanece indisponivel quando faltar dado essencial`() {
        val result = UnifiedPrescriptionCalculator.realized(null, "37:15")
        assertNull(result.paceSecondsPerKm)
    }
}
