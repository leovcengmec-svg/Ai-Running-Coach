package com.airunningcoach.app

import org.junit.Assert.*
import org.junit.Test

class ZoneCalibrationEngineTest {
    private val base = PaceCalculator.calculateCooper(2.5)!!

    @Test fun `Z1 reconhece tipos recuperacao regenerativa e recovery`() {
        assertTrue(ZoneCalibrationEngine.isRecoveryWorkoutType("Recuperação"))
        assertTrue(ZoneCalibrationEngine.isRecoveryWorkoutType("Rodagem regenerativa"))
        assertTrue(ZoneCalibrationEngine.isRecoveryWorkoutType("RECOVERY"))
        assertFalse(ZoneCalibrationEngine.isRecoveryWorkoutType("Rodagem aeróbia"))
        assertFalse(ZoneCalibrationEngine.isRecoveryWorkoutType("Intervalos"))
    }

    @Test fun `Z1 pode ser calibrada com tres sessoes regenerativas sem calibrar Z2 ou Z3`() {
        val evidence = ZoneCalibrationEvidence(z1Recovery = listOf(
            ZoneObservation("2026-10-01", 500),
            ZoneObservation("2026-10-04", 510),
            ZoneObservation("2026-10-08", 505)
        ))
        val firstUpdate = ZoneCalibrationEngine.apply(base, evidence, ZoneCalibrationEngine.boundaryValues(base))
        assertEquals(ZoneCalibrationEngine.REVIEW, firstUpdate.z1CalibrationStatus)
        assertTrue(kotlin.math.abs(firstUpdate.z1.range.fastestPaceValue - base.z1.range.fastestPaceValue) <= 15)
        val result = ZoneCalibrationEngine.apply(base, evidence, ZoneCalibrationEngine.boundaryValues(firstUpdate))
        assertEquals(ZoneCalibrationEngine.CALIBRATED, result.z1CalibrationStatus)
        assertEquals(ZoneCalibrationEngine.INITIAL, result.z2CalibrationStatus)
        assertEquals(ZoneCalibrationEngine.INITIAL, result.z3CalibrationStatus)
        assertEquals(505, result.z1CalibrationReferencePaceValue)
        assertContinuous(result)
    }

    @Test fun `Z2 ignora observacoes antigas do teste da fala`() {
        val evidence = ZoneCalibrationEvidence(z2TalkTest = listOf(
            ZoneObservation("2026-10-01", 440),
            ZoneObservation("2026-10-04", 442),
            ZoneObservation("2026-10-08", 445)
        ))
        val result = ZoneCalibrationEngine.apply(base, evidence)
        assertEquals(ZoneCalibrationEngine.INITIAL, result.z2CalibrationStatus)
        assertEquals(0, result.z2CalibrationEvidenceCount)
        assertNull(result.z2CalibrationReferencePaceValue)
        assertEquals(base.z2.range, result.z2.range)
        assertContinuous(result)
    }

    @Test fun `Z1 pode evoluir sem reativar calibracao Z2 pelo teste da fala`() {
        val evidence = ZoneCalibrationEvidence(
            z1Recovery = listOf(
                ZoneObservation("2026-10-01", 520),
                ZoneObservation("2026-10-04", 525),
                ZoneObservation("2026-10-08", 530)
            ),
            z2TalkTest = listOf(
                ZoneObservation("2026-10-02", 440),
                ZoneObservation("2026-10-05", 442),
                ZoneObservation("2026-10-09", 445)
            )
        )
        var result = base
        repeat(5) { result = ZoneCalibrationEngine.apply(base, evidence, ZoneCalibrationEngine.boundaryValues(result)) }
        assertEquals(ZoneCalibrationEngine.CALIBRATED, result.z1CalibrationStatus)
        assertEquals(ZoneCalibrationEngine.INITIAL, result.z2CalibrationStatus)
        assertNotNull(result.z1CalibrationReferencePaceValue)
        assertNull(result.z2CalibrationReferencePaceValue)
        assertContinuous(result)
    }

    @Test fun `Z3 exige dois Cooper independentes e nao usa rodagem comum`() {
        val evidence = ZoneCalibrationEvidence(z3Performance = listOf(
            CooperPerformanceEvidence("2026-09-01", 2.50),
            CooperPerformanceEvidence("2026-10-01", 2.55)
        ))
        val result = ZoneCalibrationEngine.apply(base, evidence)
        assertEquals(ZoneCalibrationEngine.CALIBRATED, result.z3CalibrationStatus)
        assertEquals(2, result.z3CalibrationEvidenceCount)
        assertEquals(result.z3.range.fastestPaceValue, result.z4.range.slowestPaceValue)
        assertContinuous(result)
    }

    @Test fun `cada atualizacao move uma fronteira no maximo quinze segundos`() {
        val evidence = ZoneCalibrationEvidence(z1Recovery = listOf(
            ZoneObservation("2026-10-01", 500),
            ZoneObservation("2026-10-04", 510),
            ZoneObservation("2026-10-08", 505)
        ))
        val first = ZoneCalibrationEngine.apply(base, evidence, ZoneCalibrationEngine.boundaryValues(base))
        val before = ZoneCalibrationEngine.boundaryValues(first)
        val second = ZoneCalibrationEngine.apply(base, evidence, before)
        val after = ZoneCalibrationEngine.boundaryValues(second)
        before.zip(after).forEach { (old, updated) -> assertTrue(kotlin.math.abs(updated - old) <= 15) }
        assertContinuous(second)
    }

    @Test fun `evidencia divergente bloqueia calibracao automatica`() {
        val result = ZoneCalibrationEngine.apply(base, ZoneCalibrationEvidence(
            z1Recovery = listOf(
                ZoneObservation("2026-10-01", 400),
                ZoneObservation("2026-10-04", 520),
                ZoneObservation("2026-10-08", 600)
            ),
            z2TalkTest = listOf(
                ZoneObservation("2026-10-01", 350),
                ZoneObservation("2026-10-04", 450),
                ZoneObservation("2026-10-08", 520)
            ),
            z3Performance = listOf(
                CooperPerformanceEvidence("2026-09-01", 2.2),
                CooperPerformanceEvidence("2026-10-01", 2.8)
            )
        ))
        assertEquals(ZoneCalibrationEngine.UNSTABLE, result.z1CalibrationStatus)
        assertEquals(ZoneCalibrationEngine.INITIAL, result.z2CalibrationStatus)
        assertEquals(ZoneCalibrationEngine.UNSTABLE, result.z3CalibrationStatus)
        assertEquals(base.z1.range, result.z1.range)
        assertEquals(base.z2.range, result.z2.range)
        assertEquals(base.z3.range, result.z3.range)
    }

    @Test fun `um unico resultado de desempenho permanece em observacao`() {
        val result = ZoneCalibrationEngine.apply(base, ZoneCalibrationEvidence(
            z3Performance = listOf(CooperPerformanceEvidence("2026-10-01", 2.6))
        ))
        assertEquals(ZoneCalibrationEngine.OBSERVATION, result.z3CalibrationStatus)
        assertEquals(base.z3.range, result.z3.range)
    }

    private fun assertContinuous(zones: TrainingPaceZones) {
        assertTrue(zones.z5.range.fastestPaceValue < zones.z5.range.slowestPaceValue)
        assertEquals(zones.z5.range.slowestPaceValue, zones.z4.range.fastestPaceValue)
        assertEquals(zones.z4.range.slowestPaceValue, zones.z3.range.fastestPaceValue)
        assertEquals(zones.z3.range.slowestPaceValue, zones.z2.range.fastestPaceValue)
        assertEquals(zones.z2.range.slowestPaceValue, zones.z1.range.fastestPaceValue)
        assertTrue(zones.z1.range.fastestPaceValue < zones.z1.range.slowestPaceValue)
    }
}
