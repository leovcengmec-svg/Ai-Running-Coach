package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CooperAssessmentManagementEngineTest {
    private fun assessment(
        date: String,
        id: String,
        deletedAt: String = "",
        updatedAt: String = ""
    ) = CooperAssessmentRecord(
        dateIso = date,
        distanceKm = 2.1,
        estimatedVo2Max = 35.6,
        averagePace = "5:42",
        testMethod = "COOPER_12_MIN",
        referenceSex = RunnerFitnessAssessmentEngine.MALE,
        ageAtTest = 36,
        recordId = id,
        deletedAtIso = deletedAt,
        updatedAtIso = updatedAt
    )

    @Test fun `ids legados sao migrados e permanecem estaveis`() {
        val legacy = listOf(assessment("2026-10-11", ""), assessment("2026-11-10", ""))
        val migrated = CooperAssessmentManagementEngine.ensureStableIds(legacy)
        val migratedAgain = CooperAssessmentManagementEngine.ensureStableIds(migrated)
        assertTrue(migrated.all { it.recordId.isNotBlank() })
        assertNotEquals(migrated[0].recordId, migrated[1].recordId)
        assertEquals(migrated.map { it.recordId }, migratedAgain.map { it.recordId })
    }

    @Test fun `ultimo teste ativo ignora registros removidos`() {
        val old = assessment("2026-10-11", "old")
        val newestRemoved = assessment("2026-11-20", "removed", "2026-11-21T10:00:00Z")
        val active = assessment("2026-11-10", "active")
        assertEquals(active, CooperAssessmentManagementEngine.latestActive(listOf(old, newestRemoved, active)))
        assertEquals(listOf(newestRemoved), CooperAssessmentManagementEngine.removed(listOf(old, newestRemoved, active)))
    }

    @Test fun `remocao e restauracao preservam a identidade e o resultado`() {
        val source = listOf(assessment("2026-10-11", "test-001"))
        val deleted = CooperAssessmentManagementEngine.softDelete(source, "test-001", "2026-11-26T12:00:00Z")
        assertNull(CooperAssessmentManagementEngine.latestActive(deleted))
        assertEquals("test-001", CooperAssessmentManagementEngine.removed(deleted).single().recordId)
        val restored = CooperAssessmentManagementEngine.restore(deleted, "test-001", "2026-11-26T12:30:00Z")
        assertEquals("test-001", CooperAssessmentManagementEngine.latestActive(restored)?.recordId)
        assertTrue(restored.single().deletedAtIso.isBlank())
        assertEquals("2.1", restored.single().distanceKm.toString())
    }

    @Test fun `edicao substitui somente o mesmo id`() {
        val first = assessment("2026-10-11", "test-001")
        val second = assessment("2026-11-10", "test-002")
        val changed = first.copy(distanceKm = 2.2, updatedAtIso = "2026-11-26T13:00:00Z")
        val result = CooperAssessmentManagementEngine.replace(listOf(first, second), changed)
        assertEquals(2, result.size)
        assertEquals(2.2, result.first { it.recordId == "test-001" }.distanceKm, 0.0001)
        assertEquals(second, result.first { it.recordId == "test-002" })
    }

    @Test fun `restauracao nao afeta registros nao relacionados`() {
        val first = assessment("2026-10-11", "test-001", "2026-10-12T10:00:00Z")
        val second = assessment("2026-11-10", "test-002")
        val restored = CooperAssessmentManagementEngine.restore(listOf(first, second), "test-001", "2026-11-26T13:00:00Z")
        assertEquals(second, restored.first { it.recordId == "test-002" })
        assertTrue(restored.first { it.recordId == "test-001" }.deletedAtIso.isBlank())
        assertFalse(CooperAssessmentManagementEngine.active(restored).isEmpty())
    }
}
