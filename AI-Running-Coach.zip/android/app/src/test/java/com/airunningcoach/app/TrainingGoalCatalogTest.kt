package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TrainingGoalCatalogTest {
    @Test fun `objetivos cobrem distancias historicas e customizado permanece apenas para restauracao`() {
        assertEquals(1.609, TrainingGoalCatalog.distanceForLabel("Milha (1,61 km)")!!, 0.001)
        assertEquals(3.0, TrainingGoalCatalog.distanceForLabel("3 km")!!, 0.001)
        assertEquals(5.0, TrainingGoalCatalog.distanceForLabel("5 km")!!, 0.001)
        assertEquals(10.0, TrainingGoalCatalog.distanceForLabel("10 km")!!, 0.001)
        assertEquals(15.0, TrainingGoalCatalog.distanceForLabel("15 km")!!, 0.001)
        assertEquals(21.1, TrainingGoalCatalog.distanceForLabel("Meia maratona (21,1 km)")!!, 0.001)
        assertEquals(42.195, TrainingGoalCatalog.distanceForLabel("Maratona (42,2 km)")!!, 0.001)
        assertEquals(50.0, TrainingGoalCatalog.distanceForLabel("Ultramaratona (50 km)")!!, 0.001)
        assertEquals(12.5, TrainingGoalCatalog.distanceForLabel("Outro objetivo", 12.5)!!, 0.001)
        assertNull(TrainingGoalCatalog.distanceForLabel("Outro objetivo", 0.5))
        assertFalse(TrainingGoalCatalog.labels.contains("Outro objetivo"))
    }

    @Test fun `iniciante pode selecionar maratona por capacidade de corrida presumida independente do VO2`() {
        val labels = TrainingGoalCatalog.labelsForLevel("Iniciante")
        assertTrue(labels.containsAll(listOf("3 km", "5 km", "10 km", "15 km", "20 km", "Meia maratona (21,1 km)", "Saúde e qualidade de vida")))
        assertTrue(labels.contains("Maratona (42,2 km)"))
        assertFalse(labels.contains("Outro objetivo"))
    }

    @Test fun `iniciante e intermediario podem selecionar metas ate maratona`() {
        listOf("Iniciante", "Intermediário").forEach { level ->
            val labels = TrainingGoalCatalog.labelsForLevel(level)
            assertTrue(labels.contains("Meia maratona (21,1 km)"))
            assertTrue(labels.contains("Maratona (42,2 km)"))
            assertFalse(labels.contains("Ultramaratona (50 km)"))
            assertFalse(labels.contains("Outro objetivo"))
        }
    }

    @Test fun `intermediario tambem pode selecionar maratona`() {
        val labels = TrainingGoalCatalog.labelsForLevel("Intermediário")
        assertTrue(labels.containsAll(listOf("3 km", "5 km", "10 km", "Meia maratona (21,1 km)")))
        assertTrue(labels.contains("Maratona (42,2 km)"))
        assertFalse(labels.contains("Ultramaratona (50 km)"))
    }

    @Test fun `performance libera maratona mas nao ultradistancia`() {
        val labels = TrainingGoalCatalog.labelsForLevel("Performance")
        assertTrue(labels.contains("Maratona (42,2 km)"))
        assertFalse(labels.contains("Ultramaratona (50 km)"))
        assertFalse(labels.contains("Outro objetivo"))
    }

    @Test fun `elite libera ultradistancias`() {
        val labels = TrainingGoalCatalog.labelsForLevel("Elite")
        assertTrue(labels.containsAll(listOf("Ultramaratona (50 km)", "Ultramaratona (100 km)", "Ultramaratona (100 milhas / 160,9 km)")))
        assertFalse(labels.contains("Outro objetivo"))
    }

    @Test fun `objetivo de saude e separado de objetivos de desempenho`() {
        assertEquals("HEALTH", TrainingGoalCatalog.categoryForLabel("Saúde e qualidade de vida"))
        assertEquals("PERFORMANCE", TrainingGoalCatalog.categoryForLabel("5 km"))
        assertEquals("CUSTOM", TrainingGoalCatalog.categoryForLabel("Outro objetivo"))
    }

    @Test fun `rotulos antigos continuam compativeis com backups anteriores`() {
        assertEquals(21.1, TrainingGoalCatalog.distanceForLabel("Meia Maratona (21 km)")!!, 0.001)
        assertEquals(42.195, TrainingGoalCatalog.distanceForLabel("Maratona (42 km)")!!, 0.001)
    }
}
