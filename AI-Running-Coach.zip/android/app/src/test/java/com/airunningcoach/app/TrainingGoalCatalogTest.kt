package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TrainingGoalCatalogTest {
    @Test fun `objetivos cobrem milha 3 5 10 15 meia maratona maratona ultra e customizado`() {
        assertEquals(1.609, TrainingGoalCatalog.distanceForLabel("Milha (1,61 km)")!!, 0.001)
        assertEquals(3.0, TrainingGoalCatalog.distanceForLabel("3 km")!!, 0.001)
        assertEquals(5.0, TrainingGoalCatalog.distanceForLabel("5 km")!!, 0.001)
        assertEquals(10.0, TrainingGoalCatalog.distanceForLabel("10 km")!!, 0.001)
        assertEquals(15.0, TrainingGoalCatalog.distanceForLabel("15 km")!!, 0.001)
        assertEquals(21.1, TrainingGoalCatalog.distanceForLabel("Meia maratona (21,1 km)")!!, 0.001)
        assertEquals(42.195, TrainingGoalCatalog.distanceForLabel("Maratona (42,2 km)")!!, 0.001)
        assertEquals(50.0, TrainingGoalCatalog.distanceForLabel("Ultramaratona (50 km)")!!, 0.001)
        assertEquals(12.5, TrainingGoalCatalog.distanceForLabel("Outro objetivo", 12.5)!!, 0.001)
        assertNull(TrainingGoalCatalog.distanceForLabel("Outro objetivo", 0.5))
    }

    @Test fun `objetivo de saude e separado de objetivos de desempenho`() {
        assertEquals("HEALTH", TrainingGoalCatalog.categoryForLabel("Saúde e qualidade de vida"))
        assertEquals("PERFORMANCE", TrainingGoalCatalog.categoryForLabel("5 km"))
        assertEquals("CUSTOM", TrainingGoalCatalog.categoryForLabel("Outro objetivo"))
    }

    @Test fun `rotulos antigos continuam compativeis com backups anteriores`() {
        assertEquals(21.1, TrainingGoalCatalog.distanceForLabel("Meia Maratona (21 km)")!!, 0.001)
        assertEquals(42.195, TrainingGoalCatalog.distanceForLabel("Maratona (42 km)")!!, 0.001)
    }
}
