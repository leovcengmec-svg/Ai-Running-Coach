package com.airunningcoach.app

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Test

class WorkoutCalendarPresentationTest {
    @Test fun `classifica oito familias gerais a partir do tipo e estimulo estruturado`() {
        assertEquals(WorkoutCalendarCategory.REGENERATIVO, WorkoutCalendarCategory.resolve("Recuperação", "RECOVERY_Z1", "Rodagem leve"))
        assertEquals(WorkoutCalendarCategory.RODAGEM, WorkoutCalendarCategory.resolve("Aeróbio", "PROGRESSION_RUN_Z2_Z3", "Rodagem progressiva Z2–Z3"))
        assertEquals(WorkoutCalendarCategory.INTERVALADO, WorkoutCalendarCategory.resolve("Qualidade", "INTERVAL_DISTANCE_800M:I08", "Repetições"))
        assertEquals(WorkoutCalendarCategory.FARTLEK, WorkoutCalendarCategory.resolve("Qualidade", "FARTLEK_Z2_Z3:F01", "Fartlek leve"))
        assertEquals(WorkoutCalendarCategory.LIMIAR_QUALIDADE, WorkoutCalendarCategory.resolve("Qualidade", "TEMPO_RUN_ESTIMATED", "Tempo Run"))
        assertEquals(WorkoutCalendarCategory.LIMIAR_QUALIDADE, WorkoutCalendarCategory.resolve("Qualidade", "THRESHOLD_INTERVAL_Z3_Z4", "Intervalo de limiar"))
        assertEquals(WorkoutCalendarCategory.LONGAO, WorkoutCalendarCategory.resolve("Longo", "AEROBIC_ENDURANCE", "Longão contínuo"))
        assertEquals(WorkoutCalendarCategory.PROVA, WorkoutCalendarCategory.resolve("Prova", "RACE_EVENT", "Corrida de 5 km"))
        assertEquals(WorkoutCalendarCategory.TESTE, WorkoutCalendarCategory.resolve("Teste", "COOPER_TEST", "Teste Cooper"))
    }

    @Test fun `status distingue concluido perdido e pendente incluindo hoje`() {
        val today = LocalDate.parse("2026-11-23")
        assertEquals(CalendarWorkoutStatus.COMPLETED, WorkoutCalendarStatusResolver.resolve("2026-11-20", today, true))
        assertEquals(CalendarWorkoutStatus.MISSED, WorkoutCalendarStatusResolver.resolve("2026-11-22", today, false))
        assertEquals(CalendarWorkoutStatus.PENDING, WorkoutCalendarStatusResolver.resolve("2026-11-23", today, false))
        assertEquals(CalendarWorkoutStatus.PENDING, WorkoutCalendarStatusResolver.resolve("2026-11-24", today, false))
    }
}
