package com.airunningcoach.app

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class WorkoutCalendarPresentationTest {
    @Test fun `classifica as nove familias curtas da grade por protocolo e estimulo`() {
        assertEquals(WorkoutCalendarCategory.REGENERATIVO, WorkoutCalendarCategory.resolve("Recuperação", "RECOVERY_Z1", "Rodagem leve"))
        assertEquals(WorkoutCalendarCategory.REGENERATIVO, WorkoutCalendarCategory.resolve("Aeróbio", "RECOVERY_Z1", "Rodagem regenerativa"))
        assertEquals(WorkoutCalendarCategory.RODAGEM, WorkoutCalendarCategory.resolve("Aeróbio", "PROGRESSION_RUN_Z2_Z3", "Rodagem progressiva aeróbia"))
        assertEquals(WorkoutCalendarCategory.INTERVALADO_QUALIDADE, WorkoutCalendarCategory.resolve("Qualidade", "INTERVAL_DISTANCE_800M:I08", "Repetições"))
        assertEquals(WorkoutCalendarCategory.FARTLEK, WorkoutCalendarCategory.resolve("Qualidade", "FARTLEK_Z2_Z3:F01", "Fartlek leve"))
        assertEquals(WorkoutCalendarCategory.TEMPO_RUN, WorkoutCalendarCategory.resolve("Qualidade", "TEMPO_RUN_ESTIMATED", "Tempo Run"))
        assertEquals(WorkoutCalendarCategory.INTERVALADO_QUALIDADE, WorkoutCalendarCategory.resolve("Qualidade", "TEMPO_INTERVAL_10MIN:T04", "Tempo intervalado 2 × 10 min"))
        assertEquals(WorkoutCalendarCategory.INTERVALADO_QUALIDADE, WorkoutCalendarCategory.resolve("Qualidade", "RACE_PACE_5KM:RP05", "Ritmo específico 5 km"))
        assertEquals(WorkoutCalendarCategory.INTERVALADO_QUALIDADE, WorkoutCalendarCategory.resolve("Qualidade", "THRESHOLD_INTERVAL_Z3_Z4", "Intervalo de limiar"))
        assertEquals(WorkoutCalendarCategory.RODAGEM, WorkoutCalendarCategory.resolve("Qualidade", "EASY_AEROBIC_Z2", "Rodagem leve"))
        assertEquals(WorkoutCalendarCategory.RODAGEM, WorkoutCalendarCategory.resolve("Aeróbio", "PROGRESSIVE_RUN_Z2_Z3:CC01", "Rodagem progressiva"))
        assertEquals(WorkoutCalendarCategory.LONGAO, WorkoutCalendarCategory.resolve("Longo", "AEROBIC_ENDURANCE", "Longão contínuo"))
        assertEquals(WorkoutCalendarCategory.PROVA, WorkoutCalendarCategory.resolve("Prova", "RACE_EVENT", "Corrida de 5 km"))
        assertEquals(WorkoutCalendarCategory.TESTE, WorkoutCalendarCategory.resolve("Teste", "COOPER_TEST", "Teste Cooper"))
        assertEquals(WorkoutCalendarCategory.INICIACAO, WorkoutCalendarCategory.resolve("Caminhada e corrida", "RUN_WALK_PROTOCOL", "Protocolo inicial"))
        // A generic beginner label does not force the initiation category.
        assertEquals(WorkoutCalendarCategory.RODAGEM, WorkoutCalendarCategory.resolve("Aeróbio", "EASY", "Rodagem leve"))
    }

    @Test fun `siglas sao curtas unicas e nao usam rotulos aerobios`() {
        val categories = listOf(
            WorkoutCalendarCategory.INICIACAO, WorkoutCalendarCategory.REGENERATIVO,
            WorkoutCalendarCategory.RODAGEM, WorkoutCalendarCategory.FARTLEK, WorkoutCalendarCategory.TEMPO_RUN,
            WorkoutCalendarCategory.INTERVALADO_QUALIDADE, WorkoutCalendarCategory.LONGAO,
            WorkoutCalendarCategory.PROVA, WorkoutCalendarCategory.TESTE
        )
        val codes = categories.map(WorkoutCalendarCategory::shortCode)
        assertEquals(listOf("INI", "REG", "ROD", "FAR", "TMP", "INT", "LNG", "PRV", "TES"), codes)
        assertEquals(9, codes.distinct().size)
        assertTrue(categories.none { WorkoutCalendarCategory.label(it).contains("aeróbio", ignoreCase = true) })
    }

    @Test fun `status distingue concluido perdido e pendente incluindo hoje`() {
        val today = LocalDate.parse("2026-11-23")
        assertEquals(CalendarWorkoutStatus.COMPLETED, WorkoutCalendarStatusResolver.resolve("2026-11-20", today, true))
        assertEquals(CalendarWorkoutStatus.MISSED, WorkoutCalendarStatusResolver.resolve("2026-11-22", today, false))
        assertEquals(CalendarWorkoutStatus.PENDING, WorkoutCalendarStatusResolver.resolve("2026-11-23", today, false))
        assertEquals(CalendarWorkoutStatus.PENDING, WorkoutCalendarStatusResolver.resolve("2026-11-24", today, false))
    }
}
