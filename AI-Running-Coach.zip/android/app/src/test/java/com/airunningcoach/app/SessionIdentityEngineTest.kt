package com.airunningcoach.app

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SessionIdentityEngineTest {
    @Test fun `session identity is stable within a cycle but distinct across cycles`() {
        val date = LocalDate.parse("2026-11-23")
        val firstCycle = SessionIdentityEngine.create(date, 1, "Aeróbio")
        val sameSession = SessionIdentityEngine.create(date, 1, "Aeróbio")
        val priorCycle = SessionIdentityEngine.create(date.minusWeeks(8), 1, "Aeróbio")
        assertEquals(firstCycle, sameSession)
        assertNotEquals(firstCycle, priorCycle)
        assertTrue(firstCycle.startsWith("C20261123-20261123-"))
    }

    @Test fun `feedback legacy id so associa quando a data original da instancia coincide`() {
        assertTrue(SessionIdentityEngine.feedbackMatchesWorkout(
            "W2-MONDAY-AEROBIO", "2026-11-23", "W2-MONDAY-AEROBIO", "2026-11-23"
        ))
        assertFalse(SessionIdentityEngine.feedbackMatchesWorkout(
            "W2-MONDAY-AEROBIO", "2026-11-16", "W2-MONDAY-AEROBIO", "2026-11-23"
        ))
    }

    @Test fun `feedback de treino movido exige data original persistida`() {
        assertFalse(SessionIdentityEngine.feedbackMatchesWorkout(
            "legacy", "2026-11-23", "legacy", "2026-11-23", "2026-11-16"
        ))
        assertTrue(SessionIdentityEngine.feedbackMatchesWorkout(
            "legacy", "2026-11-23", "legacy", "2026-11-23", "2026-11-16", "2026-11-16"
        ))
    }
    @Test
    fun `feedback com mesmo id e data mas tipo diferente nao conclui outra sessao`() {
        assertFalse(
            SessionIdentityEngine.feedbackMatchesWorkout(
                feedbackSessionId = "legacy-slot",
                feedbackWorkoutDateIso = "2026-11-23",
                workoutSessionId = "legacy-slot",
                scheduledDateIso = "2026-11-23",
                feedbackWorkoutType = "Fartlek",
                workoutType = "Aeróbio"
            )
        )
    }

    @Test fun `feedback de backup com id remapeado associa pelo slot canonico unico`() {
        assertTrue(SessionIdentityEngine.feedbackMatchesCanonicalSlot(
            feedbackOriginalDateIso = "2026-11-18",
            feedbackDateIso = "2026-11-18",
            feedbackType = "Aeróbio",
            workoutOriginalDateIso = "2026-11-18",
            workoutDateIso = "2026-11-18",
            workoutType = "Aeróbio"
        ))
        assertFalse(SessionIdentityEngine.feedbackMatchesCanonicalSlot(
            feedbackOriginalDateIso = "2026-11-18",
            feedbackDateIso = "2026-11-18",
            feedbackType = "Aeróbio",
            workoutOriginalDateIso = "2026-11-18",
            workoutDateIso = "2026-11-18",
            workoutType = "Longo"
        ))
    }

    @Test fun `chave canonica nao aceita data invalida ou tipo vazio`() {
        assertEquals("", SessionIdentityEngine.canonicalSlotKey("18/11/2026", "Aeróbio"))
        assertEquals("", SessionIdentityEngine.canonicalSlotKey("2026-11-18", ""))
        assertEquals("2026-11-18|RODAGEM", SessionIdentityEngine.canonicalSlotKey("2026-11-18", "Aeróbio"))
    }

    @Test fun `tipos legados de atividade aerobica sao normalizados para rodagem`() {
        assertTrue(SessionIdentityEngine.typesCompatible("EASY_AEROBIC_Z2_Z3_PROGRESSIVE", "Rodagem"))
        assertTrue(SessionIdentityEngine.typesCompatible("Aeróbio", "Rodagem aeróbia progressiva Z2 Z3"))
        assertTrue(SessionIdentityEngine.typesCompatible("LONG_RUN_PROGRESSIVE", "Longão"))
    }

    @Test fun `registro remapeado encontra um unico slot pelo tipo canonico`() {
        val oldKey = SessionIdentityEngine.canonicalSlotKey("2026-11-18", "EASY_AEROBIC_Z2_Z3_PROGRESSIVE")
        assertEquals("2026-11-18|RODAGEM", oldKey)
        assertTrue(SessionIdentityEngine.feedbackMatchesCanonicalSlot(
            feedbackOriginalDateIso = "2026-11-18",
            feedbackDateIso = "2026-11-18",
            feedbackType = "EASY_AEROBIC_Z2_Z3_PROGRESSIVE",
            workoutOriginalDateIso = "2026-11-18",
            workoutDateIso = "2026-11-18",
            workoutType = "Rodagem",
            persistedCanonicalKey = oldKey
        ))
    }

}
