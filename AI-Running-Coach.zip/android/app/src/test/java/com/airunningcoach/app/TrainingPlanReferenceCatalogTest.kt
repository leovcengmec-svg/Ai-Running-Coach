package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TrainingPlanReferenceCatalogTest {
    @Test fun `duracoes de referencia correspondem aos planos anexados`() {
        assertEquals(12, TrainingPlanReferenceCatalog.reference(5.0, "Iniciante")!!.defaultWeeks)
        assertEquals(8, TrainingPlanReferenceCatalog.reference(5.0, "Intermediário")!!.defaultWeeks)
        assertEquals(12, TrainingPlanReferenceCatalog.reference(10.0, "Iniciante")!!.defaultWeeks)
        assertEquals(8, TrainingPlanReferenceCatalog.reference(10.0, "Performance")!!.defaultWeeks)
        assertEquals(14, TrainingPlanReferenceCatalog.reference(21.1, "Intermediário")!!.defaultWeeks)
        assertEquals(18, TrainingPlanReferenceCatalog.reference(42.2, "Performance")!!.defaultWeeks)
    }

    @Test fun `15km e ponte adaptativa explicitamente definida pelo aplicativo`() {
        val reference = TrainingPlanReferenceCatalog.reference(15.0, "Intermediário")!!
        assertTrue(reference.emphasis.contains("Transição") || reference.emphasis.contains("Resistência"))
        assertEquals(14, reference.defaultWeeks)
    }

    @Test fun `5km iniciante que ja corre continuamente pode usar referencia de oito semanas`() {
        assertEquals(8, TrainingPlanReferenceCatalog.recommendedWeeks(5.0, "Iniciante", 20.0, 4.0))
        assertEquals(14, TrainingPlanReferenceCatalog.recommendedWeeks(5.0, "Iniciante", 3.0, 1.0))
    }

    @Test fun `progressao caminhada trote comeca pela alternancia da planilha e cresce ate continuo`() {
        val first = TrainingPlanReferenceCatalog.runWalkDose(1, 12, false, false)
        val final = TrainingPlanReferenceCatalog.runWalkDose(12, 12, false, false)
        assertEquals(1, first.runMinutes)
        assertEquals(2, first.walkMinutes)
        assertEquals(7, first.repetitions)
        assertTrue(final.runMinutes >= first.runMinutes)
        assertTrue(final.continuousRunMinutes != null)
    }

    @Test fun `semana regenerativa reduz repeticoes e aumenta caminhada`() {
        val build = TrainingPlanReferenceCatalog.runWalkDose(6, 12, false, false)
        val recovery = TrainingPlanReferenceCatalog.runWalkDose(6, 12, false, true)
        assertTrue(recovery.repetitions < build.repetitions)
        assertTrue(recovery.walkMinutes > build.walkMinutes)
        assertEquals(null, recovery.continuousRunMinutes)
    }
}
