package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TrainingPlanReferenceCatalogTest {
    @Test fun `base e teto semanal sao fixos por objetivo independentemente do nivel`() {
        val expected = listOf(
            Triple(3.0, 8.0, 16.0),
            Triple(5.0, 12.0, 22.5),
            Triple(10.0, 15.0, 27.5),
            Triple(15.0, 25.0, 43.0),
            Triple(16.1, 25.0, 43.0),
            Triple(20.0, 28.0, 48.0),
            Triple(21.1, 30.0, 51.0),
            Triple(25.0, 35.0, 60.0),
            Triple(30.0, 40.0, 70.0),
            Triple(42.2, 45.0, 80.0),
            Triple(50.0, 55.0, 100.0),
            Triple(100.0, 75.0, 140.0),
            Triple(160.9, 90.0, 160.0)
        )
        expected.forEach { (goal, base, ceiling) ->
            val reference = TrainingPlanReferenceCatalog.loadReference(goal)
            assertEquals("base $goal", base, reference.baseWeeklyKm, 0.001)
            assertEquals("teto $goal", ceiling, reference.maximumBuildWeeklyKm, 0.001)
        }
    }

    @Test fun `maratona presume meia maratona como distancia continua anterior`() {
        val reference = TrainingPlanReferenceCatalog.loadReference(42.195)
        assertEquals(45.0, reference.baseWeeklyKm, 0.001)
        assertEquals(80.0, reference.maximumBuildWeeklyKm, 0.001)
        assertEquals(21.1, reference.assumedPreviousContinuousDistanceKm, 0.001)
        assertEquals(4, reference.recommendedFrequency)
    }

    @Test fun `objetivo de meia maratona presume dez milhas como capacidade anterior`() {
        val reference = TrainingPlanReferenceCatalog.loadReference(21.0975)
        assertEquals(30.0, reference.baseWeeklyKm, 0.001)
        assertEquals(51.0, reference.maximumBuildWeeklyKm, 0.001)
        assertEquals(16.1, reference.assumedPreviousContinuousDistanceKm, 0.001)
        assertEquals(4, reference.recommendedFrequency)
    }

    @Test fun `duracoes de referencia correspondem aos planos anexados`() {
        assertEquals(12, TrainingPlanReferenceCatalog.reference(5.0, "Iniciante")!!.defaultWeeks)
        assertEquals(8, TrainingPlanReferenceCatalog.reference(5.0, "Intermediário")!!.defaultWeeks)
        assertEquals(12, TrainingPlanReferenceCatalog.reference(10.0, "Iniciante")!!.defaultWeeks)
        assertEquals(8, TrainingPlanReferenceCatalog.reference(10.0, "Performance")!!.defaultWeeks)
        assertEquals(14, TrainingPlanReferenceCatalog.reference(21.1, "Intermediário")!!.defaultWeeks)
        assertEquals(18, TrainingPlanReferenceCatalog.reference(42.2, "Performance")!!.defaultWeeks)
    }

    @Test fun `15km e ponte adaptativa explicitamente definida pelo aplicativo`() {
        val reference = TrainingPlanReferenceCatalog.reference(15.0, "Intermediário")!!
        assertTrue(reference.emphasis.contains("Transição") || reference.emphasis.contains("Resistência"))
        assertEquals(14, reference.defaultWeeks)
    }

    @Test fun `5km iniciante que ja corre continuamente pode usar referencia de oito semanas`() {
        assertEquals(8, TrainingPlanReferenceCatalog.recommendedWeeks(5.0, "Iniciante", 20.0, 4.0))
        assertEquals(14, TrainingPlanReferenceCatalog.recommendedWeeks(5.0, "Iniciante", 3.0, 1.0))
    }

    @Test fun `progressao caminhada trote comeca pela alternancia da planilha e cresce ate continuo`() {
        val first = TrainingPlanReferenceCatalog.runWalkDose(1, 12, false, false)
        val final = TrainingPlanReferenceCatalog.runWalkDose(12, 12, false, false)
        assertEquals(1, first.runMinutes)
        assertEquals(2, first.walkMinutes)
        assertEquals(7, first.repetitions)
        assertTrue(final.runMinutes >= first.runMinutes)
        assertTrue(final.continuousRunMinutes != null)
    }

    @Test fun `semana regenerativa reduz repeticoes e aumenta caminhada`() {
        val build = TrainingPlanReferenceCatalog.runWalkDose(6, 12, false, false)
        val recovery = TrainingPlanReferenceCatalog.runWalkDose(6, 12, false, true)
        assertTrue(recovery.repetitions < build.repetitions)
        assertTrue(recovery.walkMinutes > build.walkMinutes)
        assertEquals(null, recovery.continuousRunMinutes)
    }
}
