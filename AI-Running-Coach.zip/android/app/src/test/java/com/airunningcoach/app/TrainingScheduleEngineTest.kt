package com.airunningcoach.app

import java.time.DayOfWeek
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TrainingScheduleEngineTest {
    private val monday = LocalDate.of(2026, 11, 9)

    @Test fun `aceita dois a seis dias e rejeita disponibilidade fora da faixa`() {
        assertEquals(null, TrainingScheduleEngine.validateAvailability(listOf(DayOfWeek.TUESDAY, DayOfWeek.SUNDAY), DayOfWeek.SUNDAY))
        assertTrue(TrainingScheduleEngine.validateAvailability(listOf(DayOfWeek.TUESDAY), DayOfWeek.TUESDAY) != null)
        assertTrue(TrainingScheduleEngine.validateAvailability(DayOfWeek.values().toList(), DayOfWeek.SUNDAY) != null)
    }

    @Test fun `normaliza dias em ordem semanal e remove duplicados`() {
        assertEquals(listOf(DayOfWeek.TUESDAY, DayOfWeek.THURSDAY, DayOfWeek.SUNDAY),
            TrainingScheduleEngine.normalizeDays(listOf(DayOfWeek.SUNDAY, DayOfWeek.TUESDAY, DayOfWeek.THURSDAY, DayOfWeek.TUESDAY), 3))
    }

    @Test fun `reagendamento permanece dentro da mesma semana`() {
        val source = TrainingScheduleEngine.SessionSlot("s1", monday.plusDays(1), "Aeróbio")
        val result = TrainingScheduleEngine.validateMove(source, monday.plusDays(2), listOf(source), emptySet(), monday)
        assertTrue(result.allowed)
        val outside = TrainingScheduleEngine.validateMove(source, monday.plusWeeks(1), listOf(source), emptySet(), monday)
        assertFalse(outside.allowed)
    }

    @Test fun `reagendamento bloqueia dia ocupado e dia de prova`() {
        val source = TrainingScheduleEngine.SessionSlot("s1", monday.plusDays(1), "Aeróbio")
        val occupied = TrainingScheduleEngine.SessionSlot("s2", monday.plusDays(2), "Longo")
        assertFalse(TrainingScheduleEngine.validateMove(source, occupied.date, listOf(source, occupied), emptySet(), monday).allowed)
        assertFalse(TrainingScheduleEngine.validateMove(source, monday.plusDays(3), listOf(source), setOf(monday.plusDays(3)), monday).allowed)
    }

    @Test fun `treino concluido nao pode ser movido`() {
        val source = TrainingScheduleEngine.SessionSlot("s1", monday.plusDays(1), "Aeróbio", done = true)
        assertFalse(TrainingScheduleEngine.validateMove(source, monday.plusDays(2), listOf(source), emptySet(), monday).allowed)
    }

    @Test fun `IDs relativos repetidos nao ocultam outra instancia no dia de destino`() {
        val source = TrainingScheduleEngine.SessionSlot(
            "W2-MONDAY-AEROBIO", monday, "Aeróbio", false, "W2-MONDAY-AEROBIO|2026-11-09"
        )
        val otherCycle = TrainingScheduleEngine.SessionSlot(
            "W2-MONDAY-AEROBIO", monday.plusDays(2), "Qualidade", false, "W2-MONDAY-AEROBIO|2026-11-02"
        )
        val result = TrainingScheduleEngine.validateMove(
            source, otherCycle.date, listOf(source, otherCycle), emptySet(), monday
        )
        assertFalse(result.allowed)
    }

    @Test fun `qualidade ou longao respeita intervalo minimo de recuperacao`() {
        val quality = TrainingScheduleEngine.SessionSlot("s1", monday.plusDays(1), "Qualidade")
        val longRun = TrainingScheduleEngine.SessionSlot("s2", monday.plusDays(5), "Longo")
        assertFalse(TrainingScheduleEngine.validateMove(quality, monday.plusDays(4), listOf(quality, longRun), emptySet(), monday).allowed)
        assertTrue(TrainingScheduleEngine.validateMove(quality, monday.plusDays(2), listOf(quality, longRun), emptySet(), monday).allowed)
    }

    @Test fun `motor respeita dias escolhidos e dia preferido do longao`() {
        val chosen = listOf(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.SATURDAY)
        val plan = RunningCoachEngine.generate(RunnerInput(
            goalKm = 10.0, level = "Intermediário", frequency = 3, availableDays = chosen,
            preferredLongRunDay = DayOfWeek.SATURDAY, weeklyVolumeKm = 24.0, longestRecentKm = 10.0,
            experienceMonths = 24, activeWeeksLast4 = 4,
            startDate = monday, planWeeks = 4
        ))
        val firstWeek = plan.workouts.filter { it.week == 1 }
        assertEquals(chosen.map { it.value }.sorted(), firstWeek.map { LocalDate.parse(it.scheduledDateIso).dayOfWeek.value }.sorted())
        assertTrue(firstWeek.any { it.type == "Longo" && LocalDate.parse(it.scheduledDateIso).dayOfWeek == DayOfWeek.SATURDAY })
    }
    @Test fun `iniciante mantem a frequencia semanal escolhida entre dois e seis dias`() {
        for (frequency in 2..6) {
            val available = TrainingScheduleEngine.defaultDays(frequency)
            val selected = TrainingScheduleEngine.prescribedRunningDays(
                available, frequency, novice = true, preferredLongRunDay = available.last()
            )
            assertEquals(frequency, selected.size)
            assertEquals(available.sortedBy { it.value }, selected)
        }
    }

    @Test fun `semana atual e calculada a partir da ancora original do ciclo`() {
        val anchor = LocalDate.of(2026, 11, 9)
        assertEquals(1, TrainingScheduleEngine.weekNumberForDate(anchor, LocalDate.of(2026, 11, 15)))
        assertEquals(2, TrainingScheduleEngine.weekNumberForDate(anchor, LocalDate.of(2026, 11, 16)))
        assertEquals(3, TrainingScheduleEngine.weekNumberForDate(anchor, LocalDate.of(2026, 11, 23)))
    }

    @Test fun `qualidade fica no meio da semana e nao na segunda quando ha tres dias`() {
        val selected = listOf(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY)
        assertEquals(DayOfWeek.WEDNESDAY, TrainingScheduleEngine.qualityDayWithRecoveryGap(selected, DayOfWeek.FRIDAY))
    }

    @Test fun `nao escolhe qualidade quando todos os dias estao colados ao longao`() {
        val selected = listOf(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY)
        assertEquals(null, TrainingScheduleEngine.qualityDayWithRecoveryGap(selected, DayOfWeek.TUESDAY))
    }

    @Test fun `preferencia do longao e preservada ou ajustada sem falhar com lista vazia`() {
        assertEquals(DayOfWeek.SATURDAY, TrainingScheduleEngine.resolvePreferredLongRunDay(DayOfWeek.SATURDAY, listOf(DayOfWeek.TUESDAY, DayOfWeek.SATURDAY)))
        assertEquals(DayOfWeek.SUNDAY, TrainingScheduleEngine.resolvePreferredLongRunDay(DayOfWeek.SATURDAY, listOf(DayOfWeek.TUESDAY, DayOfWeek.SUNDAY)))
        assertEquals(null, TrainingScheduleEngine.resolvePreferredLongRunDay(DayOfWeek.SATURDAY, emptyList()))
    }

    @Test fun `migra semana parcial zero para semana um e desloca semanas antigas`() {
        assertEquals(1, TrainingScheduleEngine.migrateV40WeekIndex(0))
        assertEquals(2, TrainingScheduleEngine.migrateV40WeekIndex(1))
        assertEquals(3, TrainingScheduleEngine.migrateV40WeekIndex(2))
        assertEquals(4, TrainingScheduleEngine.migrateV40WeekIndex(3))
    }

    @Test fun `plano iniciado na terca preserva apenas sessoes futuras da semana atual`() {
        val tuesday = monday.plusDays(1)
        val sessions = listOf(
            plannedWorkout(monday, week = 1, id = "mon"),
            plannedWorkout(monday.plusDays(2), week = 1, id = "wed"),
            plannedWorkout(monday.plusDays(4), week = 1, id = "fri"),
            plannedWorkout(monday.plusDays(7), week = 2, id = "next-mon"),
            plannedWorkout(monday.plusDays(9), week = 2, id = "next-wed")
        )
        val result = TrainingScheduleEngine.keepUpcomingSessionsForCurrentWeek(sessions, tuesday, monday)
        assertEquals(listOf("wed", "fri", "next-mon", "next-wed"), result.map { it.sessionId })
        assertEquals(listOf(1, 1, 2, 2), result.map { it.week })
    }

    @Test fun `semana parcial iniciada na terca e sempre semana 1`() {
        val tuesday = monday.plusDays(1)
        val sessions = listOf(
            plannedWorkout(monday.plusDays(2), week = 1, id = "wed"),
            plannedWorkout(monday.plusDays(4), week = 1, id = "fri"),
            plannedWorkout(monday.plusDays(7), week = 2, id = "next-mon")
        )
        val result = TrainingScheduleEngine.keepUpcomingSessionsForCurrentWeek(sessions, tuesday, monday)
        assertTrue(result.all { it.week >= 1 })
        assertEquals(1, result.first().week)
        assertEquals(2, result.last().week)
    }

    @Test fun `plano criado na segunda inclui treino de hoje e nao desloca os proximos dias`() {
        val sessions = listOf(
            plannedWorkout(monday, week = 1, id = "today"),
            plannedWorkout(monday.plusDays(2), week = 1, id = "wed"),
            plannedWorkout(monday.plusDays(7), week = 2, id = "next-mon")
        )
        val result = TrainingScheduleEngine.keepUpcomingSessionsForCurrentWeek(sessions, monday, monday)
        assertEquals(listOf("today", "wed", "next-mon"), result.map { it.sessionId })
        assertEquals(listOf(1, 1, 2), result.map { it.week })
    }


    @Test fun `primeira semana treinavel avanca quando todos os dias escolhidos ja passaram`() {
        val saturday = LocalDate.of(2026, 11, 21)
        val selected = listOf(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY)
        assertEquals(LocalDate.of(2026, 11, 23), TrainingScheduleEngine.firstTrainableWeekStart(saturday, selected))
    }

    @Test fun `primeira semana permanece quando domingo ou o proprio sabado ainda esta disponivel`() {
        val saturday = LocalDate.of(2026, 11, 21)
        val monday = LocalDate.of(2026, 11, 16)
        assertEquals(monday, TrainingScheduleEngine.firstTrainableWeekStart(saturday, listOf(DayOfWeek.SUNDAY)))
        assertEquals(monday, TrainingScheduleEngine.firstTrainableWeekStart(saturday, listOf(DayOfWeek.SATURDAY, DayOfWeek.TUESDAY)))
        assertEquals(monday, TrainingScheduleEngine.firstTrainableWeekStart(LocalDate.of(2026, 11, 22), listOf(DayOfWeek.SUNDAY)))
    }

    private fun plannedWorkout(date: LocalDate, week: Int, id: String) = PrescribedWorkout(
        day = "Dia", date = "Data", scheduledDateIso = date.toString(), title = "Rodagem",
        type = "Aeróbio", objective = "Base", stimulus = "EASY_AEROBIC_Z2", sessionId = id,
        distanceKm = 5.0, durationMin = 40, intensity = "LOW", paceMode = "PACE_RANGE",
        rpeRange = "3-4", detail = "Rodagem confortável", rationale = "Base aeróbia",
        week = week, phase = "ADAPTATION", segments = listOf(
            WorkoutSegment("Corrida", "Confortável", durationMin = 30, targetMode = "TIME")
        )
    )

}
