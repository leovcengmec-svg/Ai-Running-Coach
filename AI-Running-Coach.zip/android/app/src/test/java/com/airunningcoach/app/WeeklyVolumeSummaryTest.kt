package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class WeeklyVolumeSummaryTest {
    @Test
    fun `includes race distance in weekly deficit`() {
        val summary = WeeklyVolumeSummary.calculate(
            trainingKm = 10.9,
            raceKm = 5.0,
            targetKm = 17.0
        )

        assertEquals(15.9, summary.totalKm, 0.0001)
        assertEquals(1.1, summary.shortfallKm, 0.0001)
        assertEquals(WeeklyVolumeStatus.BELOW_TARGET, summary.status)
    }

    @Test
    fun `without race preserves training-only deficit`() {
        val summary = WeeklyVolumeSummary.calculate(
            trainingKm = 10.9,
            raceKm = 0.0,
            targetKm = 17.0
        )

        assertEquals(6.1, summary.shortfallKm, 0.0001)
        assertEquals(WeeklyVolumeStatus.BELOW_TARGET, summary.status)
    }

    @Test
    fun `race can bring total volume into weekly target`() {
        val summary = WeeklyVolumeSummary.calculate(
            trainingKm = 12.0,
            raceKm = 5.0,
            targetKm = 17.0
        )

        assertEquals(17.0, summary.totalKm, 0.0001)
        assertEquals(0.0, summary.shortfallKm, 0.0001)
        assertEquals(WeeklyVolumeStatus.ALIGNED, summary.status)
    }

    @Test
    fun `reports excess using total including races`() {
        val summary = WeeklyVolumeSummary.calculate(
            trainingKm = 14.0,
            raceKm = 5.0,
            targetKm = 17.0
        )

        assertEquals(2.0, summary.excessKm, 0.0001)
        assertEquals(WeeklyVolumeStatus.ABOVE_TARGET, summary.status)
    }

    @Test
    fun `missing target does not report artificial deficit`() {
        val summary = WeeklyVolumeSummary.calculate(10.0, 5.0, null)

        assertNull(summary.targetKm)
        assertEquals(WeeklyVolumeStatus.NO_TARGET, summary.status)
        assertTrue(summary.shortfallKm == 0.0)
    }
}
