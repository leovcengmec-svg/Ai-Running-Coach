package com.airunningcoach.app

import androidx.compose.ui.text.TextRange

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SmartInputMaskTest {
    @Test fun `data insere barras sem alterar valor digitado`() {
        assertEquals("14/07/1990", SmartInputMask.date("14071990"))
        assertEquals("14/07", SmartInputMask.date("14/07"))
        assertEquals("31/02/2026", SmartInputMask.date("31022026")) // máscara não substitui validação calendárica
    }

    @Test fun `ritmo insere dois pontos e remove zero inicial desnecessario`() {
        assertEquals("7:35", SmartInputMask.pace("735"))
        assertEquals("6:30", SmartInputMask.pace("0630"))
        assertEquals("12:30", SmartInputMask.pace("1230"))
        assertEquals("6:15", SmartInputMask.pace("6:15"))
    }

    @Test fun `tempo aceita mmss e hhmmss`() {
        assertEquals("42:30", SmartInputMask.duration("4230"))
        assertEquals("01:12:30", SmartInputMask.duration("011230"))
        assertEquals("42:30", SmartInputMask.duration("42:30"))
    }

    @Test fun `distancia aceita ponto e virgula sem duplicar separador`() {
        assertEquals("6,62", SmartInputMask.distance("6.62"))
        assertEquals("5,1", SmartInputMask.distance("5,1"))
        assertEquals("6,62", SmartInputMask.distance("6,62"))
        assertEquals(6.62, SmartInputMask.normalizedDecimal("6.62")!!, 0.0001)
        assertNull(SmartInputMask.normalizedDecimal("km"))
    }
    @Test fun `campo de data coloca cursor sempre apos a mascara`() {
        val partial = dateTextFieldValue("1407")
        assertEquals("14/07", partial.text)
        assertEquals(TextRange(partial.text.length), partial.selection)

        val full = dateTextFieldValue("14071990")
        assertEquals("14/07/1990", full.text)
        assertEquals(TextRange(full.text.length), full.selection)
    }

}
