package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class PlanMigrationRescheduleTest {
    private fun prescribed(id: String, date: String) = PrescribedWorkout(
        day = "", date = date, scheduledDateIso = date, title = id, type = "Rodagem",
        objective = "Base", stimulus = "Aeróbio", sessionId = id, distanceKm = 5.0,
        durationMin = 35, intensity = "LOW", paceMode = "PACE", rpeRange = "2-3",
        detail = "", rationale = "", week = 2
    )

    private fun moved(id: String, original: String, moved: String) = Workout(
        date = moved, scheduledDateIso = moved, title = id, detail = "", type = "Rodagem",
        objective = "Base", stimulus = "Aeróbio", distanceKm = 5.0, sessionId = id,
        manuallyRescheduled = true, originalScheduledDateIso = original
    )

    @Test fun `recalibracao preserva as tres sessoes reagendadas quarta sexta domingo`() {
        val monday = LocalDate.parse("2026-11-16")
        val sessions = listOf(
            prescribed("s1", monday.toString()),
            prescribed("s2", monday.plusDays(2).toString()),
            prescribed("s3", monday.plusDays(4).toString())
        )
        val saved = mapOf(
            "s1" to moved("s1", monday.toString(), monday.plusDays(2).toString()),
            "s2" to moved("s2", monday.plusDays(2).toString(), monday.plusDays(4).toString()),
            "s3" to moved("s3", monday.plusDays(4).toString(), monday.plusDays(6).toString())
        )
        val result = PlanMigrationEngine.reapplyManualRescheduleDates(sessions, saved, monday)
        assertEquals(3, result.size)
        assertEquals(listOf("2026-11-18", "2026-11-20", "2026-11-22"), result.map { it.scheduledDateIso })
        assertEquals(setOf("s1", "s2", "s3"), result.map { it.sessionId }.toSet())
    }

    @Test fun `reagendamento manual nao atravessa semana durante recalibracao`() {
        val monday = LocalDate.parse("2026-11-16")
        val session = prescribed("s1", monday.toString())
        val movedToNextWeek = moved("s1", monday.toString(), monday.plusDays(7).toString())
        val result = PlanMigrationEngine.reapplyManualRescheduleDates(listOf(session), mapOf("s1" to movedToNextWeek), monday)
        assertEquals(monday.toString(), result.single().scheduledDateIso)
    }

    @Test fun `conclusao em quarta nao remove outro treino reagendado para sexta`() {
        val monday = LocalDate.parse("2026-11-16")
        val completedWednesday = moved("completed-wed", monday.toString(), monday.plusDays(2).toString()).copy(done = true)
        val movedFriday = prescribed("moved-from-monday", monday.toString()).copy(scheduledDateIso = monday.plusDays(4).toString())
        val filtered = PlanMigrationEngine.excludeCompletedSessionIdentities(listOf(movedFriday), listOf(completedWednesday))
        assertEquals(1, filtered.size)
        assertEquals("moved-from-monday", filtered.single().sessionId)
        assertEquals("2026-11-20", filtered.single().scheduledDateIso)
    }

    @Test fun `sessao movida de segunda para domingo sobrevive recalibracao na quarta`() {
        val monday = LocalDate.parse("2026-11-16")
        val wednesday = monday.plusDays(2)
        val sunday = monday.plusDays(6)
        val generatedMonday = prescribed("moved-monday", monday.toString())
        val savedMove = moved("moved-monday", monday.toString(), sunday.toString())
        val reapplied = PlanMigrationEngine.reapplyManualRescheduleDates(
            listOf(generatedMonday), mapOf(savedMove.sessionId to savedMove), wednesday
        )
        val future = PlanMigrationEngine.currentAndFutureCycleSessions(
            sessions = reapplied, today = wednesday, cycleStart = monday, cycleWeeks = 8
        )
        assertEquals(1, future.size)
        assertEquals(sunday.toString(), future.single().scheduledDateIso)
    }
}
