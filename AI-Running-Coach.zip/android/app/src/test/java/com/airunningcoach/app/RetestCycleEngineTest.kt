package com.airunningcoach.app

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RetestCycleEngineTest {
    private val start = LocalDate.of(2026, 11, 1)

    private fun sessions(completed: Int, total: Int = 12, painAt: Int? = null): List<RetestSessionProgress> =
        (0 until total).map { index ->
            val week = index / 3
            val day = index % 3
            RetestSessionProgress(
                scheduledDateIso = start.plusDays(1 + week * 7L + day * 2L).toString(),
                completed = index < completed,
                painPresent = index == painAt
            )
        }

    @Test
    fun `mais treinos concluidos que faltas libera reteste`() {
        val result = RetestCycleEngine.evaluateAdherence(sessions(completed = 8))
        assertTrue(result.eligible)
        assertEquals(12, result.plannedSessions)
        assertEquals(8, result.completedSessions)
        assertEquals(4, result.missedSessions)
        assertEquals(4, result.activeWeeks)
    }

    @Test
    fun `empate ou mais faltas adia reteste`() {
        assertFalse(RetestCycleEngine.evaluateAdherence(sessions(completed = 6)).eligible)
        assertFalse(RetestCycleEngine.evaluateAdherence(sessions(completed = 5)).eligible)
    }

    @Test
    fun `dor impede reteste mesmo com boa adesao`() {
        val result = RetestCycleEngine.evaluateAdherence(sessions(completed = 11, painAt = 2))
        assertFalse(result.eligible)
        assertTrue(result.reason.contains("dor", ignoreCase = true))
    }

    @Test
    fun `historico insuficiente nao libera reteste`() {
        val result = RetestCycleEngine.evaluateAdherence(sessions(completed = 3, total = 3))
        assertFalse(result.eligible)
        assertTrue(result.reason.contains("insuficiente", ignoreCase = true))
    }

    @Test
    fun `proximo bloco comeca apos vinte e oito dias completos`() {
        assertEquals(start.plusDays(29), RetestCycleEngine.candidateWeekStart(start, 1))
        assertEquals(start.plusDays(57), RetestCycleEngine.candidateWeekStart(start, 2))
        assertEquals(start.plusDays(28), RetestCycleEngine.blockEnd(start, 1))
    }


    @Test
    fun `snapshot do reteste preserva etapas com duracao em segundos`() {
        val original = Workout(
            date = "Segunda-feira, 30/11", scheduledDateIso = "2026-11-30",
            title = "Rodagem com acelerações", detail = "Três acelerações técnicas",
            type = "Aeróbio", objective = "Consistência aeróbia", stimulus = "EASY_WITH_STRIDES_Z2_Z5",
            distanceKm = 4.8, durationMin = 36, intensity = "LOW", rpeRange = "3-4",
            sessionId = "strides-session", segments = listOf(
                WorkoutSegment("Aquecimento", "Leve", distanceKm = 1.0),
                WorkoutSegment("Bloco aeróbio Z2", "Confortável", distanceKm = 2.0, paceZone = "Z2"),
                WorkoutSegment("Aceleração 1", "Rápida e relaxada", durationSeconds = 12, distanceKm = 0.05, targetMode = "TIME"),
                WorkoutSegment("Recuperação 1", "Caminhe", durationSeconds = 75, distanceKm = 0.1, targetMode = "TIME", recoveryMode = "WALK"),
                WorkoutSegment("Aceleração 2", "Rápida e relaxada", durationSeconds = 12, distanceKm = 0.05, targetMode = "TIME"),
                WorkoutSegment("Recuperação 2", "Caminhe", durationSeconds = 75, distanceKm = 0.1, targetMode = "TIME", recoveryMode = "WALK"),
                WorkoutSegment("Aceleração 3", "Rápida e relaxada", durationSeconds = 12, distanceKm = 0.05, targetMode = "TIME"),
                WorkoutSegment("Desaquecimento", "Leve", distanceKm = 1.45)
            )
        )
        val restored = RetestOriginalSessionSnapshot.fromJson(RetestOriginalSessionSnapshot.from(original).toJson())!!
            .restore(original.copy(title = "Reteste fisiológico", stimulus = "PHYSIOLOGICAL_RETEST_4W"))
        assertEquals(original.segments, restored.segments)
        assertEquals(listOf(12, 75, 12, 75, 12), restored.segments.mapNotNull { it.durationSeconds })
    }

    @Test
    fun `snapshot preserva a sessao original deslocada pelo reteste`() {
        val original = Workout(
            date = "Quarta-feira, 02/12", scheduledDateIso = "2026-12-02",
            title = "Tempo intervalado 2 x 10 min", detail = "Treino de limiar",
            type = "Qualidade", objective = "Limiar", stimulus = "THRESHOLD_INTERVAL_Z4",
            distanceKm = 5.4, durationMin = 42, intensity = "HIGH", rpeRange = "6-7",
            sessionId = "source-session", segments = listOf(
                WorkoutSegment("Aquecimento", "Leve", durationMin = 10, distanceKm = 1.2, targetMode = "TIME", paceZone = "Z2"),
                WorkoutSegment("Limiar", "Sustentado", durationMin = 20, distanceKm = 3.0, targetMode = "TIME", paceZone = "Z4"),
                WorkoutSegment("Desaquecimento", "Leve", durationMin = 10, distanceKm = 1.2, targetMode = "TIME", paceZone = "Z1")
            )
        )
        val snapshot = RetestOriginalSessionSnapshot.from(original)
        val roundTrip = RetestOriginalSessionSnapshot.fromJson(snapshot.toJson())!!
        val retest = original.copy(
            title = "Reteste fisiológico de campo", type = "Teste fisiológico",
            stimulus = "PHYSIOLOGICAL_RETEST_4W", retestOriginalSession = roundTrip
        )
        val restored = retest.retestOriginalSession!!.restore(retest)
        assertEquals(original.title, restored.title)
        assertEquals(original.type, restored.type)
        assertEquals(original.stimulus, restored.stimulus)
        assertEquals(original.distanceKm, restored.distanceKm, 0.001)
        assertEquals(original.segments, restored.segments)
        assertEquals("ALTERNATIVE", restored.selectedOption)
        assertEquals(null, restored.retestOriginalSession)
    }
}
