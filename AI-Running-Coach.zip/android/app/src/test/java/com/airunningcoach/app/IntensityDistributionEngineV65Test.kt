package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class IntensityDistributionEngineV66Test {
    @Test fun `distribuicao de base e definida pela fase e nao bloqueada pelo rotulo iniciante`() {
        val beginner = IntensityDistributionEngine.target("PERFORMANCE", "Iniciante", TrainingPeriodizationEngine.BASE)
        val performance = IntensityDistributionEngine.target("PERFORMANCE", "Performance", TrainingPeriodizationEngine.BASE)
        assertEquals(beginner, performance)
        assertEquals(80, beginner.lowMinPercent)
        assertEquals(92, beginner.lowMaxPercent)
        assertEquals(8, beginner.moderateMinPercent)
        assertEquals(20, beginner.moderateMaxPercent)
    }

    @Test fun `desenvolvimento admite pequena parcela de alta intensidade se elegibilidade liberar`() {
        val target = IntensityDistributionEngine.target("PERFORMANCE", "Iniciante", TrainingPeriodizationEngine.DEVELOPMENT)
        assertEquals(75, target.lowMinPercent)
        assertEquals(10, target.highMaxPercent)
        assertTrue(target.note.contains("não do rótulo fisiológico"))
    }

    @Test fun `sem tempo segmentado nao apresenta percentuais falsos como se fossem dados`() {
        val report = IntensityDistributionEngine.summarize(emptyList())
        assertEquals(0, report.totalEstimatedMinutes)
        assertTrue(report.explanation.contains("Percentuais não são exibidos"))
    }
}
