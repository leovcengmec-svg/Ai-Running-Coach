package com.airunningcoach.app

import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.assertEquals
import org.junit.Test

class IntensityDistributionEngineV72Test {
    @Test fun `distribuicao por pace muda conforme nivel do corredor`() {
        val beginner = IntensityDistributionEngine.target("PERFORMANCE", "Iniciante", TrainingPeriodizationEngine.BASE)
        val performance = IntensityDistributionEngine.target("PERFORMANCE", "Performance", TrainingPeriodizationEngine.BASE)
        assertNotEquals(beginner, performance)
        assertTrue(beginner.lowMinPercent > performance.lowMinPercent)
        assertEquals(0, beginner.highMinPercent)
    }

    @Test fun `desenvolvimento libera dose maior apenas para nivel com base compativel`() {
        val beginner = IntensityDistributionEngine.target("PERFORMANCE", "Iniciante", TrainingPeriodizationEngine.DEVELOPMENT)
        val advanced = IntensityDistributionEngine.target("PERFORMANCE", "Performance", TrainingPeriodizationEngine.DEVELOPMENT)
        assertTrue(advanced.highMaxPercent > beginner.highMaxPercent)
        assertTrue(beginner.note.contains("Z3"))
    }

    @Test fun `recuperacao retira os estimulos de alta intensidade`() {
        val target = IntensityDistributionEngine.target("PERFORMANCE", "Performance", TrainingPeriodizationEngine.RECOVERY)
        assertEquals(0, target.highMaxPercent)
        assertEquals(92, target.lowMinPercent)
    }

    @Test fun `sem tempo segmentado nao apresenta percentuais falsos como se fossem dados`() {
        val report = IntensityDistributionEngine.summarize(emptyList())
        assertEquals(0, report.totalEstimatedMinutes)
        assertTrue(report.explanation.contains("Percentuais não são exibidos"))
    }
}
