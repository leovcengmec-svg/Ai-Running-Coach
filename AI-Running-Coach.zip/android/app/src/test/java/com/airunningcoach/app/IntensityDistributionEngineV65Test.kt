package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Test

class IntensityDistributionEngineV65Test {
    @Test fun `performance usa faixa de distribuicao avancada`() {
        val target = IntensityDistributionEngine.target("PERFORMANCE", "Performance", "BASE")
        assertEquals(75, target.lowMinPercent)
        assertEquals(90, target.lowMaxPercent)
        assertEquals(5, target.moderateMinPercent)
        assertEquals(15, target.moderateMaxPercent)
        assertEquals(0, target.highMinPercent)
        assertEquals(10, target.highMaxPercent)
    }
}
