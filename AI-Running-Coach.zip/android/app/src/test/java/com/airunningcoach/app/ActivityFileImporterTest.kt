package com.airunningcoach.app

import org.junit.Assert.*
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

class ActivityFileImporterTest {
    @Test fun `GPX extrai percurso tempo distancia elevacao FC cadencia e parciais`() {
        val gpx = """
            <?xml version="1.0"?>
            <gpx version="1.1" creator="test" xmlns="http://www.topografix.com/GPX/1/1" xmlns:gpxtpx="http://www.garmin.com/xmlschemas/TrackPointExtension/v1">
              <trk><trkseg>
                <trkpt lat="0.0000" lon="0.0000"><ele>10</ele><time>2026-11-01T10:00:00Z</time><extensions><gpxtpx:TrackPointExtension><gpxtpx:hr>140</gpxtpx:hr><gpxtpx:cad>84</gpxtpx:cad></gpxtpx:TrackPointExtension></extensions></trkpt>
                <trkpt lat="0.0045" lon="0.0000"><ele>18</ele><time>2026-11-01T10:05:00Z</time><extensions><gpxtpx:TrackPointExtension><gpxtpx:hr>150</gpxtpx:hr><gpxtpx:cad>88</gpxtpx:cad></gpxtpx:TrackPointExtension></extensions></trkpt>
                <trkpt lat="0.0090" lon="0.0000"><ele>25</ele><time>2026-11-01T10:10:00Z</time><extensions><gpxtpx:TrackPointExtension><gpxtpx:hr>160</gpxtpx:hr><gpxtpx:cad>90</gpxtpx:cad></gpxtpx:TrackPointExtension></extensions></trkpt>
              </trkseg></trk>
            </gpx>
        """.trimIndent()
        val parsed = ActivityFileImporter.import(gpx.byteInputStream(), "run.gpx")
        assertEquals("GPX", parsed.sourceFormat)
        assertTrue(parsed.distanceKm!! > 0.95 && parsed.distanceKm < 1.05)
        assertEquals(600, parsed.elapsedSeconds)
        assertEquals("10:00", parsed.averagePaceMmSs)
        assertEquals(15.0, parsed.elevationGainMeters!!, 0.1)
        assertEquals(150, parsed.averageHeartRateBpm)
        assertEquals(160, parsed.maxHeartRateBpm)
        assertEquals(87, parsed.averageCadenceSpm)
        assertEquals(90, parsed.maxCadenceSpm)
        assertEquals(3, parsed.routePointCount)
        assertTrue(parsed.encodedRoute.isNotBlank())
        assertEquals(1, parsed.splitPacesMmSs.size)
    }

    @Test fun `GPX gera segmentos de pace medido apenas com pontos temporizados validos`() {
        val gpx = """
            <gpx version="1.1" creator="test">
              <trk><trkseg>
                <trkpt lat="0.0000" lon="0.0000"><time>2026-11-11T10:00:00Z</time></trkpt>
                <trkpt lat="0.0009" lon="0.0000"><time>2026-11-11T10:00:30Z</time></trkpt>
                <trkpt lat="0.0018" lon="0.0000"><time>2026-11-11T10:01:00Z</time></trkpt>
              </trkseg></trk>
            </gpx>
        """.trimIndent()
        val parsed = ActivityFileImporter.import(gpx.byteInputStream(), "timed.gpx")
        assertEquals(2, parsed.paceSegments.size)
        assertTrue(parsed.paceSegments.all { it.paceSecondsPerKm in 270..330 })
        assertEquals(60, parsed.paceSegments.sumOf { it.durationSeconds })
    }

    @Test fun `GPX aceita atividade de ultradistancia com duracao de ate 48 horas`() {
        val gpx = """
            <gpx version="1.1" creator="test" xmlns:pacecoach="https://pacecoach.app/gpx/1">
              <metadata>
                <time>2026-11-11T06:00:00Z</time>
                <pacecoach:activity distance="20000" time="172800" />
              </metadata>
            </gpx>
        """.trimIndent()
        val parsed = ActivityFileImporter.import(gpx.byteInputStream(), "ultra.gpx")
        assertEquals(20.0, parsed.distanceKm!!, 0.001)
        assertEquals(172_800, parsed.elapsedSeconds)
        assertEquals("48:00:00", PaceRange.formatDuration(parsed.elapsedSeconds!!))
    }

    @Test fun `GPX RunnerUp le metadados oficiais pacecoach e parciais por km`() {
        val gpx = """
            <?xml version="1.0" encoding="UTF-8"?>
            <gpx version="1.1" xmlns="http://www.topografix.com/GPX/1/1"
                 xmlns:pacecoach="https://pacecoach.app/gpx/1"
                 xmlns:gpxtpx="http://www.garmin.com/xmlschemas/TrackPointExtension/v2">
              <metadata>
                <time>2026-11-11T22:45:39Z</time>
                <pacecoach:activity version="2" distance="4970.0" time="2223" workoutType="2" />
              </metadata>
              <trk><name>Rodagem aeróbia</name><trkseg>
                <pacecoach:lap number="0" distance="991.477" time="474" intensity="2" />
                <pacecoach:lap number="1" distance="993.588" time="439" intensity="0" />
                <pacecoach:lap number="2" distance="995.089" time="434" intensity="0" />
                <pacecoach:lap number="3" distance="994.504" time="422" intensity="0" />
                <pacecoach:lap number="4" distance="993.083" time="453" intensity="3" />
                <pacecoach:lap number="5" distance="2.387" time="1" intensity="3" />
                <trkpt lat="0.0000" lon="0.0000"><ele>91.35</ele><time>2026-11-11T22:45:39Z</time></trkpt>
                <trkpt lat="0.0090" lon="0.0000"><ele>92.35</ele><time>2026-11-11T23:22:41Z</time></trkpt>
              </trkseg></trk>
            </gpx>
        """.trimIndent()
        val parsed = ActivityFileImporter.import(gpx.byteInputStream(), "runnerup.gpx")
        assertEquals(4.97, parsed.distanceKm!!, 0.001)
        assertEquals(2223, parsed.elapsedSeconds)
        assertEquals("7:27", parsed.averagePaceMmSs)
        assertEquals("2026-11-11T22:45:39Z", parsed.startedAtIso)
        assertEquals(2, parsed.routePointCount)
        assertEquals(5, parsed.splitPacesMmSs.size)
    }

    @Test fun `GPX com DOCTYPE e recusado sem depender de feature especifica do parser`() {
        val gpx = """
            <?xml version="1.0"?>
            <!DOCTYPE gpx [<!ENTITY xxe SYSTEM "file:///etc/passwd">]>
            <gpx version="1.1"><trk><trkseg><trkpt lat="0" lon="0"/><trkpt lat="0.009" lon="0"/></trkseg></trk>
        """.trimIndent()
        val error = try {
            ActivityFileImporter.import(gpx.byteInputStream(), "unsafe.gpx")
            fail("O GPX com DOCTYPE deveria ser rejeitado")
            null
        } catch (expected: ActivityImportException) {
            expected
        }
        assertTrue(error!!.message!!.contains("DOCTYPE"))
    }

    @Test fun `GPX sem horario calcula percurso mas nao inventa tempo ou pace`() {
        val gpx = """
            <gpx version="1.1"><trk><trkseg>
              <trkpt lat="0" lon="0"/><trkpt lat="0.009" lon="0"/>
            </trkseg></trk></gpx>
        """.trimIndent()
        val parsed = ActivityFileImporter.import(gpx.byteInputStream(), "no-time.gpx")
        assertTrue(parsed.distanceKm!! > 0.9)
        assertNull(parsed.elapsedSeconds)
        assertNull(parsed.averagePaceMmSs)
    }

    @Test fun `TCX usa totais de volta e medias de FC`() {
        val tcx = """
            <TrainingCenterDatabase xmlns="http://www.garmin.com/xmlschemas/TrainingCenterDatabase/v2">
              <Activities><Activity Sport="Running"><Id>2026-11-01T10:00:00Z</Id>
                <Lap StartTime="2026-11-01T10:00:00Z"><TotalTimeSeconds>600</TotalTimeSeconds><DistanceMeters>1000</DistanceMeters>
                  <AverageHeartRateBpm><Value>145</Value></AverageHeartRateBpm><MaximumHeartRateBpm><Value>168</Value></MaximumHeartRateBpm>
                  <Track>
                    <Trackpoint><Time>2026-11-01T10:00:00Z</Time><Position><LatitudeDegrees>0</LatitudeDegrees><LongitudeDegrees>0</LongitudeDegrees></Position><AltitudeMeters>20</AltitudeMeters><HeartRateBpm><Value>140</Value></HeartRateBpm><Cadence>84</Cadence><DistanceMeters>0</DistanceMeters></Trackpoint>
                    <Trackpoint><Time>2026-11-01T10:10:00Z</Time><Position><LatitudeDegrees>0.009</LatitudeDegrees><LongitudeDegrees>0</LongitudeDegrees></Position><AltitudeMeters>24</AltitudeMeters><HeartRateBpm><Value>160</Value></HeartRateBpm><Cadence>88</Cadence><DistanceMeters>1000</DistanceMeters></Trackpoint>
                  </Track></Lap>
              </Activity></Activities>
            </TrainingCenterDatabase>
        """.trimIndent()
        val parsed = ActivityFileImporter.import(tcx.byteInputStream(), "run.tcx")
        assertEquals(1.0, parsed.distanceKm!!, 0.001)
        assertEquals(600, parsed.elapsedSeconds)
        assertEquals(145, parsed.averageHeartRateBpm)
        assertEquals(168, parsed.maxHeartRateBpm)
        assertEquals(86, parsed.averageCadenceSpm)
    }

    @Test fun `FIT extrai totais da sessao e registros`() {
        val bytes = makeFitFile()
        val parsed = ActivityFileImporter.import(bytes.inputStream(), "run.fit")
        assertEquals(1.0, parsed.distanceKm!!, 0.001)
        assertEquals(600, parsed.elapsedSeconds)
        assertEquals(147, parsed.averageHeartRateBpm)
        assertEquals(165, parsed.maxHeartRateBpm)
        assertEquals(88, parsed.averageCadenceSpm)
        assertEquals(94, parsed.maxCadenceSpm)
        assertEquals("10:00", parsed.averagePaceMmSs)
        assertEquals(2, parsed.routePointCount)
    }

    @Test fun `FIT com assinatura invalida e rejeitado`() {
        val bytes = makeFitFile()
        bytes[8] = 'X'.code.toByte()
        val error = runCatching { ActivityFileImporter.import(bytes.inputStream(), "invalid.fit") }.exceptionOrNull()
        assertTrue(error is ActivityImportException)
        assertTrue(error?.message.orEmpty().contains("Assinatura"))
    }

    @Test fun `FIT truncado e rejeitado em vez de interpretar dados parciais`() {
        val bytes = makeFitFile().copyOf().also { it[4] = (it[4].toInt() + 20).toByte() }
        val error = runCatching { ActivityFileImporter.import(bytes.inputStream(), "truncated.fit") }.exceptionOrNull()
        assertTrue(error is ActivityImportException)
        assertTrue(error?.message.orEmpty().contains("truncado"))
    }

    @Test fun `identificador de conteudo e deterministico`() {
        val gpx = "<gpx version=\"1.1\"><trk><trkseg><trkpt lat=\"0\" lon=\"0\"/><trkpt lat=\"0.009\" lon=\"0\"/></trkseg></trk></gpx>"
        val first = ActivityFileImporter.import(gpx.byteInputStream(), "a.gpx")
        val second = ActivityFileImporter.import(gpx.byteInputStream(), "copy.gpx")
        assertEquals(first.fingerprint, second.fingerprint)
    }

    private fun makeFitFile(): ByteArray {
        val data = ByteArrayOutputStream()
        // Local message 0: Record (global message 20).
        data.write(byteArrayOf(0x60, 0, 0, 20, 0, 6)) // developer data section present
        writeField(data, 0, 4, 0x85); writeField(data, 1, 4, 0x85)
        writeField(data, 3, 1, 0x02); writeField(data, 4, 1, 0x02)
        writeField(data, 5, 4, 0x86); writeField(data, 253, 4, 0x86)
        data.write(1) // one developer field
        data.write(byteArrayOf(0, 2, 0)) // field number, size, developer data index
        data.write(0x00)
        writeInt(data, 0); writeInt(data, 0); data.write(140); data.write(84); writeInt(data, 0); writeInt(data, 1000)
        data.write(byteArrayOf(11, 12)) // uninterpreted developer field bytes
        data.write(0x00)
        writeInt(data, 10000); writeInt(data, 0); data.write(155); data.write(90); writeInt(data, 100000); writeInt(data, 1600)
        data.write(byteArrayOf(13, 14))

        // Local message 1: Session (global message 18).
        data.write(byteArrayOf(0x41, 0, 0, 18, 0, 7))
        writeField(data, 7, 4, 0x86); writeField(data, 9, 4, 0x86)
        writeField(data, 15, 1, 0x02); writeField(data, 16, 1, 0x02)
        writeField(data, 17, 1, 0x02); writeField(data, 18, 1, 0x02)
        writeField(data, 2, 4, 0x86)
        data.write(0x01)
        writeInt(data, 600000); writeInt(data, 100000); data.write(147); data.write(165); data.write(88); data.write(94); writeInt(data, 1000)

        val payload = data.toByteArray()
        val header = ByteArray(14)
        header[0] = 14
        header[1] = 0x20
        ByteBuffer.wrap(header, 4, 4).order(ByteOrder.LITTLE_ENDIAN).putInt(payload.size)
        header[8] = '.'.code.toByte(); header[9] = 'F'.code.toByte(); header[10] = 'I'.code.toByte(); header[11] = 'T'.code.toByte()
        return header + payload + byteArrayOf(0, 0)
    }

    private fun writeField(output: ByteArrayOutputStream, number: Int, size: Int, baseType: Int) {
        output.write(number); output.write(size); output.write(baseType)
    }

    private fun writeInt(output: ByteArrayOutputStream, value: Int) {
        val bytes = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(value).array()
        output.write(bytes)
    }
}
