package com.airunningcoach.app

import org.junit.Assert.*
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

class ActivityFileImporterTest {
    @Test fun `GPX extrai percurso tempo distancia elevacao cadencia e parciais sem usar FC`() {
        val gpx = """
            <?xml version="1.0"?>
            <gpx version="1.1" creator="test" xmlns="http://www.topografix.com/GPX/1/1" xmlns:gpxtpx="http://www.garmin.com/xmlschemas/TrackPointExtension/v1">
              <trk><trkseg>
                <trkpt lat="0.0000" lon="0.0000"><ele>10</ele><time>2026-11-01T10:00:00Z</time><extensions><gpxtpx:TrackPointExtension><gpxtpx:hr>140</gpxtpx:hr><gpxtpx:cad>84</gpxtpx:cad></gpxtpx:TrackPointExtension></extensions></trkpt>
                <trkpt lat="0.0045" lon="0.0000"><ele>18</ele><time>2026-11-01T10:05:00Z</time><extensions><gpxtpx:TrackPointExtension><gpxtpx:hr>150</gpxtpx:hr><gpxtpx:cad>88</gpxtpx:cad></gpxtpx:TrackPointExtension></extensions></trkpt>
                <trkpt lat="0.0090" lon="0.0000"><ele>25</ele><time>2026-11-01T10:10:00Z</time><extensions><gpxtpx:TrackPointExtension><gpxtpx:hr>160</gpxtpx:hr><gpxtpx:cad>90</gpxtpx:cad></gpxtpx:TrackPointExtension></extensions></trkpt>
              </trkseg></trk>
            </gpx>
        """.trimIndent()
        val parsed = ActivityFileImporter.import(gpx.byteInputStream(), "run.gpx")
        assertEquals("GPX", parsed.sourceFormat)
        assertTrue(parsed.distanceKm!! > 0.95 && parsed.distanceKm < 1.05)
        assertEquals(600, parsed.elapsedSeconds)
        assertEquals("10:00", parsed.averagePaceMmSs)
        assertEquals(15.0, parsed.elevationGainMeters!!, 0.1)
        assertNull(parsed.averageHeartRateBpm)
        assertNull(parsed.maxHeartRateBpm)
        assertEquals(87, parsed.averageCadenceSpm)
        assertEquals(90, parsed.maxCadenceSpm)
        assertEquals(3, parsed.routePointCount)
        assertTrue(parsed.encodedRoute.isNotBlank())
        assertEquals(1, parsed.splitPacesMmSs.size)
    }

    @Test fun `GPX gera segmentos de pace medido apenas com pontos temporizados validos`() {
        val gpx = """
            <gpx version="1.1" creator="test">
              <trk><trkseg>
                <trkpt lat="0.0000" lon="0.0000"><time>2026-11-11T10:00:00Z</time></trkpt>
                <trkpt lat="0.0009" lon="0.0000"><time>2026-11-11T10:00:30Z</time></trkpt>
                <trkpt lat="0.0018" lon="0.0000"><time>2026-11-11T10:01:00Z</time></trkpt>
              </trkseg></trk>
            </gpx>
        """.trimIndent()
        val parsed = ActivityFileImporter.import(gpx.byteInputStream(), "timed.gpx")
        assertEquals(2, parsed.paceSegments.size)
        assertTrue(parsed.paceSegments.all { it.paceSecondsPerKm in 270..330 })
        assertEquals(60, parsed.paceSegments.sumOf { it.durationSeconds })
    }

    @Test fun `GPX aceita atividade de ultradistancia com duracao de ate 48 horas`() {
        val gpx = """
            <gpx version="1.1" creator="test" xmlns:pacecoach="https://pacecoach.app/gpx/1">
              <metadata>
                <time>2026-11-11T06:00:00Z</time>
                <pacecoach:activity distance="20000" time="172800" />
              </metadata>
            </gpx>
        """.trimIndent()
        val parsed = ActivityFileImporter.import(gpx.byteInputStream(), "ultra.gpx")
        assertEquals(20.0, parsed.distanceKm!!, 0.001)
        assertEquals(172_800, parsed.elapsedSeconds)
        assertEquals("2026-11-11T06:00:00Z", parsed.startedAtIso)
        assertEquals("METADATA", parsed.startedAtSource)
        assertEquals("48:00:00", PaceRange.formatDuration(parsed.elapsedSeconds!!))
    }

    @Test fun `GPX RunnerUp le metadados oficiais pacecoach e parciais por km`() {
        val gpx = """
            <?xml version="1.0" encoding="UTF-8"?>
            <gpx version="1.1" xmlns="http://www.topografix.com/GPX/1/1"
                 xmlns:pacecoach="https://pacecoach.app/gpx/1"
                 xmlns:gpxtpx="http://www.garmin.com/xmlschemas/TrackPointExtension/v2">
              <metadata>
                <time>2026-11-11T22:45:39Z</time>
                <pacecoach:activity version="2" distance="4970.0" time="2223" workoutType="2" />
              </metadata>
              <trk><name>Rodagem aeróbia</name><trkseg>
                <pacecoach:lap number="0" distance="991.477" time="474" intensity="2" />
                <pacecoach:lap number="1" distance="993.588" time="439" intensity="0" />
                <pacecoach:lap number="2" distance="995.089" time="434" intensity="0" />
                <pacecoach:lap number="3" distance="994.504" time="422" intensity="0" />
                <pacecoach:lap number="4" distance="993.083" time="453" intensity="3" />
                <pacecoach:lap number="5" distance="2.387" time="1" intensity="3" />
                <trkpt lat="0.0000" lon="0.0000"><ele>91.35</ele><time>2026-11-11T22:45:39Z</time></trkpt>
                <trkpt lat="0.0090" lon="0.0000"><ele>92.35</ele><time>2026-11-11T23:22:41Z</time></trkpt>
              </trkseg></trk>
            </gpx>
        """.trimIndent()
        val parsed = ActivityFileImporter.import(gpx.byteInputStream(), "runnerup.gpx")
        assertEquals(4.97, parsed.distanceKm!!, 0.001)
        assertEquals(2223, parsed.elapsedSeconds)
        assertEquals("7:27", parsed.averagePaceMmSs)
        assertEquals("2026-11-11T22:45:39Z", parsed.startedAtIso)
        assertEquals(2, parsed.routePointCount)
        assertEquals(5, parsed.splitPacesMmSs.size)
    }


    @Test fun `GPX organiza cinco voltas e cobertura restante em quilômetros acumulados`() {
        val gpx = """
            <gpx version="1.1" xmlns:pacecoach="https://pacecoach.app/gpx/1">
              <metadata>
                <time>2026-11-18T19:00:00Z</time>
                <pacecoach:activity distance="6620" time="3000" />
              </metadata>
              <trk><trkseg>
                <pacecoach:lap number="0" distance="1000" time="400" />
                <pacecoach:lap number="1" distance="1000" time="400" />
                <pacecoach:lap number="2" distance="1000" time="400" />
                <pacecoach:lap number="3" distance="1000" time="400" />
                <pacecoach:lap number="4" distance="1000" time="400" />
                <trkpt lat="0.00000" lon="0.00000"><time>2026-11-18T19:00:00Z</time></trkpt>
                <trkpt lat="0.05953" lon="0.00000"><time>2026-11-18T19:50:00Z</time></trkpt>
              </trkseg></trk>
            </gpx>
        """.trimIndent()
        val parsed = ActivityFileImporter.import(gpx.byteInputStream(), "activity-6620.gpx")
        assertEquals(6.62, parsed.distanceKm!!, 0.001)
        assertEquals(7, parsed.splitDetails.size)
        assertEquals(6.62, parsed.splitDetails.sumOf { it.distanceMeters } / 1000.0, 0.001)
        assertEquals((1..6).map { "${it}º km" }, parsed.splitDetails.take(6).map { it.label })
        assertTrue(parsed.splitDetails.last().label.startsWith("Parcial final"))
        assertEquals("EXPLICIT_LAP", parsed.splitDetails.first().sourceType)
        assertTrue(parsed.splitDetails.drop(5).all { it.paceSecondsPerKm == null })
    }

    @Test fun `GPX preserva distancia total declarada quando trilha GPS termina antes`() {
        val track = buildString {
            append("<trk><trkseg>")
            (0..5).forEach { km ->
                val latitude = km * 1000.0 / 111_194.9
                val time = java.time.Instant.parse("2026-11-18T19:00:00Z").plusSeconds(km * 500L)
                append("<trkpt lat=\"$latitude\" lon=\"0\"><time>$time</time></trkpt>")
            }
            append("</trkseg></trk>")
        }
        val gpx = """
            <gpx version="1.1" xmlns:pacecoach="https://pacecoach.app/gpx/1">
              <metadata><time>2026-11-18T19:00:00Z</time><pacecoach:activity distance="6620" time="3000" /></metadata>
              $track
            </gpx>
        """.trimIndent()
        val parsed = ActivityFileImporter.import(gpx.byteInputStream(), "sparse-6-62.gpx")
        assertEquals(6.62, parsed.distanceKm!!, 0.001)
        assertEquals(6.62, parsed.splitDetails.sumOf { it.distanceMeters } / 1000.0, 0.01)
        assertEquals((1..6).map { "${it}º km" }, parsed.splitDetails.take(6).map { it.label })
        assertTrue(parsed.splitDetails.last().label.startsWith("Parcial final"))
        assertNull(parsed.splitDetails.last().paceSecondsPerKm)
        assertEquals("TRACK_DISTANCE_ONLY", parsed.splitDetails.last().sourceType)
    }

    @Test fun `GPX combina voltas explicitas com parciais GPS e trecho final fracionado`() {
        val lapXml = (0..4).joinToString("") { index ->
            "<pacecoach:lap number=\"$index\" distance=\"1000\" time=\"400\"/>"
        }
        val trackPoints = buildString {
            val distances = (0..16).map { it * 400.0 }.filter { it < 6620.0 } + 6620.0
            append("<trk><trkseg>")
            distances.forEach { distance ->
                val latitude = distance / 111_194.9
                val elapsed = (distance / 6620.0 * 3000.0).toLong()
                val time = java.time.Instant.parse("2026-11-18T19:00:00Z").plusSeconds(elapsed)
                append("<trkpt lat=\"$latitude\" lon=\"0\"><time>$time</time></trkpt>")
            }
            append("</trkseg></trk>")
        }
        val gpx = """
            <gpx version="1.1" xmlns:pacecoach="https://pacecoach.app/gpx/1">
              <metadata><time>2026-11-18T19:00:00Z</time><pacecoach:activity distance="6620" time="3000" /></metadata>
              $lapXml
              $trackPoints
            </gpx>
        """.trimIndent()
        val parsed = ActivityFileImporter.import(gpx.byteInputStream(), "full-splits.gpx")
        assertEquals(6.62, parsed.distanceKm!!, 0.001)
        assertEquals(7, parsed.splitDetails.size)
        assertEquals(6.62, parsed.splitDetails.sumOf { it.distanceMeters } / 1000.0, 0.01)
        assertTrue(parsed.splitDetails.takeLast(2).all { it.sourceType == "TRACK_POINT" })
        assertEquals((1..6).map { "${it}º km" }, parsed.splitDetails.take(6).map { it.label })
        assertTrue(parsed.splitDetails.last().label.startsWith("Parcial final"))
    }

    @Test fun `GPX usa primeiro ponto como inicio e nao horario de exportacao em metadata`() {
        val gpx = """
            <gpx version="1.1">
              <metadata><time>2026-11-19T19:00:00Z</time></metadata>
              <trk><trkseg>
                <trkpt lat="0" lon="0"><time>2026-11-18T20:00:00Z</time></trkpt>
                <trkpt lat="0.0005" lon="0"><time>2026-11-18T20:00:10Z</time></trkpt>
                <trkpt lat="0.0010" lon="0"><time>2026-11-18T20:00:20Z</time></trkpt>
              </trkseg></trk>
            </gpx>
        """.trimIndent()
        val parsed = ActivityFileImporter.import(gpx.byteInputStream(), "metadata-time.gpx")
        assertEquals("2026-11-18T20:00:00Z", parsed.startedAtIso)
        assertEquals("TRACK_POINT", parsed.startedAtSource)
        assertTrue(parsed.paceSegments.isNotEmpty())
        assertEquals(0, parsed.paceSegments.first().startElapsedSeconds)
        assertTrue(parsed.paceSegments.first().distanceMeters!! > 5.0)
    }


    @Test fun `GPX nao cria distancia ou segmento entre faixas de GPS separadas`() {
        val gpx = """
            <gpx version="1.1">
              <trk>
                <trkseg>
                  <trkpt lat="0.0000" lon="0.0000"><time>2026-11-18T08:00:00Z</time></trkpt>
                  <trkpt lat="0.0005" lon="0.0000"><time>2026-11-18T08:00:10Z</time></trkpt>
                </trkseg>
                <trkseg>
                  <trkpt lat="0.1000" lon="0.1000"><time>2026-11-18T08:30:00Z</time></trkpt>
                  <trkpt lat="0.1005" lon="0.1000"><time>2026-11-18T08:30:10Z</time></trkpt>
                </trkseg>
              </trk>
            </gpx>
        """.trimIndent()
        val parsed = ActivityFileImporter.import(gpx.byteInputStream(), "segments.gpx")
        assertTrue(parsed.distanceKm!! < 0.2)
        assertEquals(2, parsed.paceSegments.size)
        assertTrue(parsed.paceSegments.all { it.startElapsedSeconds in setOf(0, 1800) })
    }

    @Test fun `GPX nao cria parcial por km atravessando segmentos separados`() {
        val gpx = """
            <gpx version="1.1"><trk>
              <trkseg>
                <trkpt lat="0.0000" lon="0.0000"><time>2026-11-18T08:00:00Z</time></trkpt>
                <trkpt lat="0.0054" lon="0.0000"><time>2026-11-18T08:02:00Z</time></trkpt>
              </trkseg>
              <trkseg>
                <trkpt lat="0.1000" lon="0.1000"><time>2026-11-18T08:30:00Z</time></trkpt>
                <trkpt lat="0.1054" lon="0.1000"><time>2026-11-18T08:32:00Z</time></trkpt>
              </trkseg>
            </trk></gpx>
        """.trimIndent()
        val parsed = ActivityFileImporter.import(gpx.byteInputStream(), "disconnected-splits.gpx")
        assertTrue(parsed.distanceKm!! in 1.15..1.25)
        assertTrue(parsed.splitPacesMmSs.isEmpty())
        assertEquals(2, parsed.paceSegments.size)
    }

    @Test fun `GPX com DOCTYPE e recusado sem depender de feature especifica do parser`() {
        val gpx = """
            <?xml version="1.0"?>
            <!DOCTYPE gpx [<!ENTITY xxe SYSTEM "file:///etc/passwd">]>
            <gpx version="1.1"><trk><trkseg><trkpt lat="0" lon="0"/><trkpt lat="0.009" lon="0"/></trkseg></trk>
        """.trimIndent()
        val error = try {
            ActivityFileImporter.import(gpx.byteInputStream(), "unsafe.gpx")
            fail("O GPX com DOCTYPE deveria ser rejeitado")
            null
        } catch (expected: ActivityImportException) {
            expected
        }
        assertTrue(error!!.message!!.contains("DOCTYPE"))
    }

    @Test fun `GPX sem horario calcula percurso mas nao inventa tempo ou pace`() {
        val gpx = """
            <gpx version="1.1"><trk><trkseg>
              <trkpt lat="0" lon="0"/><trkpt lat="0.009" lon="0"/>
            </trkseg></trk></gpx>
        """.trimIndent()
        val parsed = ActivityFileImporter.import(gpx.byteInputStream(), "no-time.gpx")
        assertTrue(parsed.distanceKm!! > 0.9)
        assertNull(parsed.elapsedSeconds)
        assertNull(parsed.averagePaceMmSs)
    }

    @Test fun `TCX usa totais de volta e ignora dados cardiacos`() {
        val tcx = """
            <TrainingCenterDatabase xmlns="http://www.garmin.com/xmlschemas/TrainingCenterDatabase/v2">
              <Activities><Activity Sport="Running"><Id>2026-11-01T10:00:00Z</Id>
                <Lap StartTime="2026-11-01T10:00:00Z"><TotalTimeSeconds>600</TotalTimeSeconds><DistanceMeters>1000</DistanceMeters>
                  <AverageHeartRateBpm><Value>145</Value></AverageHeartRateBpm><MaximumHeartRateBpm><Value>168</Value></MaximumHeartRateBpm>
                  <Track>
                    <Trackpoint><Time>2026-11-01T10:00:00Z</Time><Position><LatitudeDegrees>0</LatitudeDegrees><LongitudeDegrees>0</LongitudeDegrees></Position><AltitudeMeters>20</AltitudeMeters><HeartRateBpm><Value>140</Value></HeartRateBpm><Cadence>84</Cadence><DistanceMeters>0</DistanceMeters></Trackpoint>
                    <Trackpoint><Time>2026-11-01T10:10:00Z</Time><Position><LatitudeDegrees>0.009</LatitudeDegrees><LongitudeDegrees>0</LongitudeDegrees></Position><AltitudeMeters>24</AltitudeMeters><HeartRateBpm><Value>160</Value></HeartRateBpm><Cadence>88</Cadence><DistanceMeters>1000</DistanceMeters></Trackpoint>
                  </Track></Lap>
              </Activity></Activities>
            </TrainingCenterDatabase>
        """.trimIndent()
        val parsed = ActivityFileImporter.import(tcx.byteInputStream(), "run.tcx")
        assertEquals(1.0, parsed.distanceKm!!, 0.001)
        assertEquals(600, parsed.elapsedSeconds)
        assertNull(parsed.averageHeartRateBpm)
        assertNull(parsed.maxHeartRateBpm)
        assertEquals(86, parsed.averageCadenceSpm)
    }

    @Test fun `FIT extrai totais da sessao e registros`() {
        val bytes = makeFitFile()
        val parsed = ActivityFileImporter.import(bytes.inputStream(), "run.fit")
        assertEquals(1.0, parsed.distanceKm!!, 0.001)
        assertEquals(600, parsed.elapsedSeconds)
        assertNull(parsed.averageHeartRateBpm)
        assertNull(parsed.maxHeartRateBpm)
        assertEquals(88, parsed.averageCadenceSpm)
        assertEquals(94, parsed.maxCadenceSpm)
        assertEquals("10:00", parsed.averagePaceMmSs)
        assertEquals(2, parsed.routePointCount)
    }

    @Test fun `FIT preserva voltas explicitas para analise de blocos`() {
        val parsed = ActivityFileImporter.import(makeFitFile(includeLap = true).inputStream(), "laps.fit")
        assertEquals(1, parsed.paceSegments.size)
        val lap = parsed.paceSegments.single()
        assertEquals("EXPLICIT_LAP", lap.sourceType)
        assertEquals(600, lap.durationSeconds)
        assertEquals(1000.0, lap.distanceMeters!!, 0.01)
        assertEquals(600, lap.paceSecondsPerKm)
    }

    @Test fun `FIT com assinatura invalida e rejeitado`() {
        val bytes = makeFitFile()
        bytes[8] = 'X'.code.toByte()
        val error = runCatching { ActivityFileImporter.import(bytes.inputStream(), "invalid.fit") }.exceptionOrNull()
        assertTrue(error is ActivityImportException)
        assertTrue(error?.message.orEmpty().contains("Assinatura"))
    }

    @Test fun `FIT truncado e rejeitado em vez de interpretar dados parciais`() {
        val bytes = makeFitFile().copyOf().also { it[4] = (it[4].toInt() + 20).toByte() }
        val error = runCatching { ActivityFileImporter.import(bytes.inputStream(), "truncated.fit") }.exceptionOrNull()
        assertTrue(error is ActivityImportException)
        assertTrue(error?.message.orEmpty().contains("truncado"))
    }

    @Test fun `identificador de conteudo e deterministico`() {
        val gpx = "<gpx version=\"1.1\"><trk><trkseg><trkpt lat=\"0\" lon=\"0\"/><trkpt lat=\"0.009\" lon=\"0\"/></trkseg></trk></gpx>"
        val first = ActivityFileImporter.import(gpx.byteInputStream(), "a.gpx")
        val second = ActivityFileImporter.import(gpx.byteInputStream(), "copy.gpx")
        assertEquals(first.fingerprint, second.fingerprint)
    }

    private fun makeFitFile(includeLap: Boolean = false): ByteArray {
        val data = ByteArrayOutputStream()
        // Local message 0: Record (global message 20).
        data.write(byteArrayOf(0x60, 0, 0, 20, 0, 6)) // developer data section present
        writeField(data, 0, 4, 0x85); writeField(data, 1, 4, 0x85)
        writeField(data, 3, 1, 0x02); writeField(data, 4, 1, 0x02)
        writeField(data, 5, 4, 0x86); writeField(data, 253, 4, 0x86)
        data.write(1) // one developer field
        data.write(byteArrayOf(0, 2, 0)) // field number, size, developer data index
        data.write(0x00)
        writeInt(data, 0); writeInt(data, 0); data.write(140); data.write(84); writeInt(data, 0); writeInt(data, 1000)
        data.write(byteArrayOf(11, 12)) // uninterpreted developer field bytes
        data.write(0x00)
        writeInt(data, 10000); writeInt(data, 0); data.write(155); data.write(90); writeInt(data, 100000); writeInt(data, 1600)
        data.write(byteArrayOf(13, 14))

        if (includeLap) {
            // Local message 2: Lap (global message 19): start_time, total_elapsed_time, total_distance.
            data.write(byteArrayOf(0x42, 0, 0, 19, 0, 3))
            writeField(data, 2, 4, 0x86); writeField(data, 7, 4, 0x86); writeField(data, 9, 4, 0x86)
            data.write(0x02)
            writeInt(data, 1000); writeInt(data, 600000); writeInt(data, 100000)
        }

        // Local message 1: Session (global message 18).
        data.write(byteArrayOf(0x41, 0, 0, 18, 0, 7))
        writeField(data, 7, 4, 0x86); writeField(data, 9, 4, 0x86)
        writeField(data, 15, 1, 0x02); writeField(data, 16, 1, 0x02)
        writeField(data, 17, 1, 0x02); writeField(data, 18, 1, 0x02)
        writeField(data, 2, 4, 0x86)
        data.write(0x01)
        writeInt(data, 600000); writeInt(data, 100000); data.write(147); data.write(165); data.write(88); data.write(94); writeInt(data, 1000)

        val payload = data.toByteArray()
        val header = ByteArray(14)
        header[0] = 14
        header[1] = 0x20
        ByteBuffer.wrap(header, 4, 4).order(ByteOrder.LITTLE_ENDIAN).putInt(payload.size)
        header[8] = '.'.code.toByte(); header[9] = 'F'.code.toByte(); header[10] = 'I'.code.toByte(); header[11] = 'T'.code.toByte()
        return header + payload + byteArrayOf(0, 0)
    }

    private fun writeField(output: ByteArrayOutputStream, number: Int, size: Int, baseType: Int) {
        output.write(number); output.write(size); output.write(baseType)
    }

    private fun writeInt(output: ByteArrayOutputStream, value: Int) {
        val bytes = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(value).array()
        output.write(bytes)
    }

    @Test fun `GPX de 6,62 km com voltas irregulares vira seis quilômetros e parcial final`() {
        val laps = listOf(660.0 to 299.0, 1_120.0 to 510.0, 850.0 to 390.0,
            1_040.0 to 470.0, 930.0 to 420.0, 1_020.0 to 460.0, 1_000.0 to 450.0)
        val lapXml = laps.mapIndexed { index, (distance, seconds) ->
            "<pacecoach:lap number=\"$index\" distance=\"$distance\" time=\"$seconds\"/>"
        }.joinToString("")
        val gpx = """
            <gpx version="1.1" xmlns:pacecoach="https://pacecoach.app/gpx/1">
              <metadata><time>2026-11-18T19:00:00Z</time><pacecoach:activity distance="6620" time="2999"/></metadata>
              $lapXml
            </gpx>
        """.trimIndent()
        val parsed = ActivityFileImporter.import(gpx.byteInputStream(), "irregular-6620.gpx")
        assertEquals(7, parsed.splitDetails.size)
        assertEquals((1..6).map { "${it}º km" }, parsed.splitDetails.take(6).map { it.label })
        assertEquals("Parcial final (0,62 km)", parsed.splitDetails.last().label)
        assertEquals(6.62, parsed.splitDetails.sumOf { it.distanceMeters } / 1000.0, 0.001)
        assertTrue(parsed.splitDetails.all { it.paceSecondsPerKm != null })
        assertTrue(parsed.splitDetails.any { it.sourceType == "EXPLICIT_LAP_AGGREGATED" })
    }

    @Test fun `GPX sem timestamps preserva quilômetros e parcial sem inventar pace`() {
        val points = buildString {
            append("<trk><trkseg>")
            (0..6).forEach { km ->
                val latitude = km * 1000.0 / 111_194.9
                append("<trkpt lat=\"$latitude\" lon=\"0\"/>")
            }
            val finalLatitude = 6_620.0 / 111_194.9
            append("<trkpt lat=\"$finalLatitude\" lon=\"0\"/>")
            append("</trkseg></trk>")
        }
        val gpx = """
            <gpx version="1.1" xmlns:pacecoach="https://pacecoach.app/gpx/1">
              <metadata><pacecoach:activity distance="6620" /></metadata>
              $points
            </gpx>
        """.trimIndent()
        val parsed = ActivityFileImporter.import(gpx.byteInputStream(), "no-timestamps-6620.gpx")
        assertEquals(7, parsed.splitDetails.size)
        assertEquals(6.62, parsed.splitDetails.sumOf { it.distanceMeters } / 1000.0, 0.001)
        assertEquals((1..6).map { "${it}º km" }, parsed.splitDetails.take(6).map { it.label })
        assertEquals("Parcial final (0,62 km)", parsed.splitDetails.last().label)
        assertTrue(parsed.splitDetails.all { it.paceSecondsPerKm == null && it.durationSeconds == null })
        assertTrue(parsed.splitDetails.all { it.sourceType == "TRACK_DISTANCE_ONLY" })
    }

}
