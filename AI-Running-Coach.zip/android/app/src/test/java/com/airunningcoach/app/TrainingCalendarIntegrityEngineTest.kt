package com.airunningcoach.app

import java.time.LocalDate
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TrainingCalendarIntegrityEngineTest {
    private val monday = LocalDate.of(2026, 11, 23)

    private fun workout(
        date: LocalDate,
        id: String,
        optional: Boolean = false,
        type: String = "Aeróbio",
        distanceKm: Double = 5.0
    ) = Workout(
        date = date.toString(), scheduledDateIso = date.toString(), title = type, detail = "",
        type = type, objective = "", stimulus = "EASY", distanceKm = distanceKm,
        sessionId = id, isOptionalExtra = optional
    )

    private fun race(date: LocalDate, distanceKm: Double = 5.0) = RaceEvent("race", "Prova", distanceKm, date.toString(), "B")

    @Test fun `rejeita dois treinos no mesmo dia`() {
        val issues = TrainingCalendarIntegrityEngine.validate(
            listOf(workout(monday.plusDays(1), "a"), workout(monday.plusDays(1), "b")),
            emptyList(), 3, monday
        )
        assertTrue(issues.any { it.contains("mesmo dia") })
    }

    @Test fun `rejeita treino no mesmo dia de prova`() {
        val issues = TrainingCalendarIntegrityEngine.validate(
            listOf(workout(monday.plusDays(5), "a")), listOf(race(monday.plusDays(5))), 3, monday
        )
        assertTrue(issues.any { it.contains("conflita") })
    }

    @Test fun `rejeita mais compromissos do que dias configurados`() {
        val workouts = listOf(workout(monday.plusDays(1), "a"), workout(monday.plusDays(3), "b"), workout(monday.plusDays(6), "c"))
        val issues = TrainingCalendarIntegrityEngine.validate(workouts, listOf(race(monday.plusDays(5))), 3, monday)
        assertTrue(issues.any { it.contains("acima dos 3 dias") })
    }

    @Test fun `aceita prova no lugar de sessao e longao mantido em domingo`() {
        val workouts = listOf(
            workout(monday.plusDays(1), "easy"),
            workout(monday.plusDays(6), "long", type = "Longo", distanceKm = 6.0)
        )
        val issues = TrainingCalendarIntegrityEngine.validate(workouts, listOf(race(monday.plusDays(5))), 3, monday)
        assertTrue(issues.isEmpty())
    }

    @Test fun `teto de quarenta por cento do longao inclui distancia da prova`() {
        val workouts = listOf(
            workout(monday.plusDays(1), "long", type = "Longo", distanceKm = 6.0),
            workout(monday.plusDays(3), "easy", distanceKm = 5.0)
        )
        val issues = TrainingCalendarIntegrityEngine.validate(workouts, listOf(race(monday.plusDays(5), 1.0)), 3, monday)
        assertTrue(issues.any { it.contains("incluindo provas") && it.contains("40%") })
    }

    @Test fun `longao precisa continuar maior que as demais sessoes`() {
        val workouts = listOf(
            workout(monday.plusDays(1), "long", type = "Longo", distanceKm = 5.0),
            workout(monday.plusDays(3), "quality", type = "Qualidade", distanceKm = 6.0),
            workout(monday.plusDays(5), "easy", distanceKm = 5.0)
        )
        val issues = TrainingCalendarIntegrityEngine.validate(workouts, emptyList(), 3, monday)
        assertTrue(issues.any { it.contains("não é maior") })
    }

    @Test fun `sessao opcional nao conta para frequencia principal`() {
        val workouts = listOf(
            workout(monday.plusDays(1), "a"), workout(monday.plusDays(3), "b"),
            workout(monday.plusDays(5), "extra", optional = true)
        )
        val issues = TrainingCalendarIntegrityEngine.validate(workouts, emptyList(), 2, monday)
        assertFalse(issues.any { it.contains("acima dos 2 dias") })
    }
}
