package com.airunningcoach.app

import java.time.LocalDate
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TrainingCalendarIntegrityEngineTest {
    private val monday = LocalDate.of(2026, 11, 23)

    private fun workout(
        date: LocalDate,
        id: String,
        optional: Boolean = false,
        type: String = "Aeróbio",
        distanceKm: Double = 5.0,
        done: Boolean = false,
        weeklyTargetKm: Double? = null
    ) = Workout(
        date = date.toString(), scheduledDateIso = date.toString(), title = type, detail = "",
        type = type, objective = "", stimulus = "EASY", distanceKm = distanceKm,
        sessionId = id, isOptionalExtra = optional, done = done, weeklyTargetKm = weeklyTargetKm
    )

    private fun race(date: LocalDate, distanceKm: Double = 5.0, status: String = "PLANNED") =
        RaceEvent("race-${date}", "Prova", distanceKm, date.toString(), "B", status = status)

    @Test fun `rejeita dois treinos pendentes no mesmo dia`() {
        val issues = TrainingCalendarIntegrityEngine.validate(
            listOf(workout(monday.plusDays(1), "a"), workout(monday.plusDays(1), "b")),
            emptyList(), 3, monday
        )
        assertTrue(issues.any { it.contains("mesmo dia") })
    }

    @Test fun `rejeita treino pendente no mesmo dia de prova`() {
        val issues = TrainingCalendarIntegrityEngine.validate(
            listOf(workout(monday.plusDays(5), "a")), listOf(race(monday.plusDays(5))), 3, monday
        )
        assertTrue(issues.any { it.contains("conflita") })
    }

    @Test fun `rejeita mais dias com compromissos do que frequencia`() {
        val workouts = listOf(workout(monday.plusDays(1), "a"), workout(monday.plusDays(3), "b"), workout(monday.plusDays(6), "c"))
        val issues = TrainingCalendarIntegrityEngine.validate(workouts, listOf(race(monday.plusDays(5))), 3, monday)
        assertTrue(issues.any { it.contains("acima dos 3 dias") })
    }

    @Test fun `aceita prova no lugar de sessao e longao mantido em domingo`() {
        val workouts = listOf(
            workout(monday.plusDays(1), "easy"),
            workout(monday.plusDays(6), "long", type = "Longo", distanceKm = 6.0)
        )
        val issues = TrainingCalendarIntegrityEngine.validate(workouts, listOf(race(monday.plusDays(5))), 3, monday)
        assertTrue(issues.isEmpty())
    }

    @Test fun `teto de quarenta por cento inclui distancia da prova`() {
        val workouts = listOf(
            workout(monday.plusDays(1), "long", type = "Longo", distanceKm = 6.0),
            workout(monday.plusDays(3), "easy", distanceKm = 5.0)
        )
        val issues = TrainingCalendarIntegrityEngine.validate(workouts, listOf(race(monday.plusDays(5), 1.0)), 3, monday)
        assertTrue(issues.any { it.contains("incluindo provas") && it.contains("40%") })
    }

    @Test fun `longao precisa continuar maior que as demais sessoes`() {
        val workouts = listOf(
            workout(monday.plusDays(1), "long", type = "Longo", distanceKm = 5.0),
            workout(monday.plusDays(3), "quality", type = "Qualidade", distanceKm = 6.0),
            workout(monday.plusDays(5), "easy", distanceKm = 5.0)
        )
        val issues = TrainingCalendarIntegrityEngine.validate(workouts, emptyList(), 3, monday)
        assertTrue(issues.any { it.contains("não é maior") })
    }

    @Test fun `sessao opcional nao conta para frequencia principal`() {
        val workouts = listOf(
            workout(monday.plusDays(1), "a"), workout(monday.plusDays(3), "b"),
            workout(monday.plusDays(5), "extra", optional = true)
        )
        val issues = TrainingCalendarIntegrityEngine.validate(workouts, emptyList(), 2, monday)
        assertFalse(issues.any { it.contains("acima dos 2 dias") })
    }

    @Test fun `treinos concluidos nao contam como compromissos futuros`() {
        val today = monday.plusDays(3)
        val workouts = listOf(
            workout(monday, "done-mon", done = true),
            workout(monday.plusDays(1), "done-tue", done = true),
            workout(monday.plusDays(4), "future", done = false)
        )
        val issues = TrainingCalendarIntegrityEngine.validate(
            workouts, listOf(race(monday.plusDays(6))), weeklyFrequency = 2, today = today
        )
        assertFalse(issues.any { it.contains("acima dos 2 dias") })
    }

    @Test fun `treino concluido no dia da prova nao cria conflito futuro`() {
        val raceDate = monday.plusDays(5)
        val issues = TrainingCalendarIntegrityEngine.validate(
            listOf(workout(raceDate, "already-done", done = true)),
            listOf(race(raceDate)), weeklyFrequency = 1, today = monday.plusDays(3)
        )
        assertFalse(issues.any { it.contains("conflita") })
    }

    @Test fun `treino e prova no mesmo dia contam um dia mas geram conflito`() {
        val raceDate = monday.plusDays(5)
        val issues = TrainingCalendarIntegrityEngine.validate(
            listOf(workout(raceDate, "pending")), listOf(race(raceDate)), 1, monday
        )
        assertTrue(issues.any { it.contains("conflita") })
        assertFalse(issues.any { it.contains("acima de 1 dias") || it.contains("acima dos 1 dias") })
    }

    @Test fun `semana atual parcial nao bloqueia longao por denominador truncado`() {
        val today = monday.plusDays(3)
        val remainingLongRun = workout(monday.plusDays(6), "long", type = "Longo", distanceKm = 6.0)
        val issues = TrainingCalendarIntegrityEngine.validate(listOf(remainingLongRun), emptyList(), 3, today)
        assertFalse(issues.any { it.contains("100.0%") || it.contains("40%") })
    }


    @Test fun `prova concluida na semana atual contribui para carga mas nao frequencia futura`() {
        val today = monday.plusDays(3)
        val workouts = listOf(
            workout(monday, "done-a", type = "Rodagem", distanceKm = 3.0, done = true),
            workout(monday.plusDays(1), "done-b", type = "Qualidade", distanceKm = 3.0, done = true),
            workout(monday.plusDays(6), "long", type = "Longo", distanceKm = 6.0)
        )
        val completedRace = race(monday.plusDays(2), distanceKm = 4.0, status = "COMPLETED")
        val issues = TrainingCalendarIntegrityEngine.validate(workouts, listOf(completedRace), 1, today)
        assertFalse(issues.any { it.contains("acima dos 1 dias") })
        assertFalse(issues.any { it.contains("40%") }) // 6 / (3 + 3 + 4 + 6) = 37.5%
    }

    @Test fun `semana atual com todas as datas realizadas e futuras usa carga completa`() {
        val today = monday.plusDays(3)
        val workouts = listOf(
            workout(monday, "done-a", type = "Rodagem", distanceKm = 3.0, done = true),
            workout(monday.plusDays(1), "done-b", type = "Qualidade", distanceKm = 3.0, done = true),
            workout(monday.plusDays(6), "long", type = "Longo", distanceKm = 6.0)
        )
        val issues = TrainingCalendarIntegrityEngine.validate(workouts, emptyList(), 3, today)
        assertTrue(issues.any { it.contains("50.0%") && it.contains("40%") })
    }

    @Test fun `semana futura completa mantem bloqueio quando longao excede quarenta`() {
        val futureMonday = monday.plusWeeks(2)
        val workouts = listOf(
            workout(futureMonday.plusDays(1), "long", type = "Longo", distanceKm = 6.8, weeklyTargetKm = 16.0),
            workout(futureMonday.plusDays(3), "quality", type = "Qualidade", distanceKm = 5.1, weeklyTargetKm = 16.0)
        )
        val issues = TrainingCalendarIntegrityEngine.validate(workouts, emptyList(), 3, monday.plusDays(3))
        val longRunIssue = issues.firstOrNull { it.contains("57.1%") && it.contains("40%") }
        assertTrue(longRunIssue != null)
        assertTrue(longRunIssue!!.contains("57.1%"))
        assertTrue(longRunIssue.contains("Meta semanal registrada: 16.0 km"))
        assertTrue(longRunIssue.contains("Longo 6.8 km"))
        assertTrue(longRunIssue.contains("Qualidade 5.1 km"))
    }

    @Test fun `semana futura de dezesseis km seis mais cinco mais cinco aprovada`() {
        val futureMonday = monday.plusWeeks(1)
        val workouts = listOf(
            workout(futureMonday.plusDays(1), "long", type = "Longo", distanceKm = 6.0, weeklyTargetKm = 16.0),
            workout(futureMonday.plusDays(3), "quality", type = "Qualidade", distanceKm = 5.0, weeklyTargetKm = 16.0),
            workout(futureMonday.plusDays(5), "easy", type = "Rodagem", distanceKm = 5.0, weeklyTargetKm = 16.0)
        )
        val issues = TrainingCalendarIntegrityEngine.validate(workouts, emptyList(), 3, monday)
        assertTrue(issues.isEmpty())
    }

    @Test fun `prova cancelada ou concluida nao conta como compromisso futuro`() {
        val futureMonday = monday.plusWeeks(1)
        val workouts = listOf(
            workout(futureMonday.plusDays(1), "long", type = "Longo", distanceKm = 6.0),
            workout(futureMonday.plusDays(3), "easy", distanceKm = 5.0),
            workout(futureMonday.plusDays(5), "quality", type = "Qualidade", distanceKm = 5.0)
        )
        val races = listOf(
            race(futureMonday.plusDays(4), status = "CANCELLED"),
            race(futureMonday.plusDays(6), distanceKm = 3.0, status = "COMPLETED")
        )
        val issues = TrainingCalendarIntegrityEngine.validate(workouts, races, 3, monday)
        assertFalse(issues.any { it.contains("acima dos 3 dias") })
    }

    @Test fun `duplicata da mesma instancia nao duplica volume semanal`() {
        val futureMonday = monday.plusWeeks(1)
        val longRun = workout(futureMonday.plusDays(1), "long", type = "Longo", distanceKm = 6.0)
        val workouts = listOf(
            longRun,
            longRun,
            workout(futureMonday.plusDays(3), "quality", type = "Qualidade", distanceKm = 5.0),
            workout(futureMonday.plusDays(5), "easy", type = "Rodagem", distanceKm = 5.0)
        )
        val issues = TrainingCalendarIntegrityEngine.validate(workouts, emptyList(), 3, monday)
        assertTrue(issues.isEmpty())
    }

    @Test fun `distancias invalidas nao sao tratadas como volume zero`() {
        val futureMonday = monday.plusWeeks(1)
        val workouts = listOf(
            workout(futureMonday.plusDays(1), "long", type = "Longo", distanceKm = 6.0),
            workout(futureMonday.plusDays(3), "bad", type = "Qualidade", distanceKm = Double.NaN)
        )
        val issues = TrainingCalendarIntegrityEngine.validate(workouts, emptyList(), 3, monday)
        assertTrue(issues.any { it.contains("distância inválida") })
    }


    @Test fun `reteste fisiologico sem protocolo permanece compromisso sem distancia invalida`() {
        val futureMonday = monday.plusWeeks(2)
        val workouts = listOf(
            workout(futureMonday.plusDays(1), "long", type = "Longo", distanceKm = 6.8, weeklyTargetKm = 16.0),
            workout(futureMonday.plusDays(3), "quality", type = "Qualidade", distanceKm = 5.1, weeklyTargetKm = 16.0),
            workout(futureMonday.plusDays(5), "retest", type = "Teste fisiológico", distanceKm = 0.0, weeklyTargetKm = 16.0)
                .copy(stimulus = "PHYSIOLOGICAL_RETEST_4W", retestMethod = "")
        )
        val issues = TrainingCalendarIntegrityEngine.validate(workouts, emptyList(), 3, monday.plusDays(3))
        assertFalse(issues.any { it.contains("distância inválida") })
        assertTrue(issues.any { it.contains("pelo menos") && it.contains("40%") && it.contains("método a definir") })
    }

    @Test fun `reteste pendente nao bloqueia se distancia maxima permitida puder cumprir quarenta por cento`() {
        val futureMonday = monday.plusWeeks(2)
        val workouts = listOf(
            workout(futureMonday.plusDays(1), "long", type = "Longo", distanceKm = 6.0, weeklyTargetKm = 16.0),
            workout(futureMonday.plusDays(3), "easy", type = "Rodagem", distanceKm = 5.0, weeklyTargetKm = 16.0),
            workout(futureMonday.plusDays(5), "retest", type = "Teste fisiológico", distanceKm = 0.0, weeklyTargetKm = 16.0)
                .copy(stimulus = "PHYSIOLOGICAL_RETEST_4W", retestMethod = "")
        )
        val issues = TrainingCalendarIntegrityEngine.validate(workouts, emptyList(), 3, monday.plusDays(3))
        assertFalse(issues.any { it.contains("40%") })
        assertFalse(issues.any { it.contains("distância inválida") })
    }


    @Test fun `reteste de tres km escolhido entra no volume e recalcula participacao exata`() {
        val futureMonday = monday.plusWeeks(2)
        val workouts = listOf(
            workout(futureMonday.plusDays(1), "long", type = "Longo", distanceKm = 6.8),
            workout(futureMonday.plusDays(3), "quality", type = "Qualidade", distanceKm = 5.1),
            workout(futureMonday.plusDays(5), "retest", type = "Teste fisiológico", distanceKm = 3.0)
                .copy(stimulus = "PHYSIOLOGICAL_RETEST_4W", retestMethod = "THREE_KM")
        )
        val issues = TrainingCalendarIntegrityEngine.validate(workouts, emptyList(), 3, monday.plusDays(3))
        assertTrue(issues.any { it.contains("45.6%") && it.contains("40%") })
        assertFalse(issues.any { it.contains("distância pendente") })
    }

    @Test fun `reteste cooper com cinco km usa distancia definida e valida teto`() {
        val futureMonday = monday.plusWeeks(2)
        val workouts = listOf(
            workout(futureMonday.plusDays(1), "long", type = "Longo", distanceKm = 6.8),
            workout(futureMonday.plusDays(3), "quality", type = "Qualidade", distanceKm = 5.1),
            workout(futureMonday.plusDays(5), "retest", type = "Teste fisiológico", distanceKm = 5.0)
                .copy(stimulus = "PHYSIOLOGICAL_RETEST_4W", retestMethod = "COOPER_12_MIN")
        )
        val issues = TrainingCalendarIntegrityEngine.validate(workouts, emptyList(), 3, monday.plusDays(3))
        assertTrue(issues.any { it.contains("40.2%") && it.contains("40%") })
    }

    @Test fun `data ISO invalida e explicitada gera aviso`() {
        val invalid = workout(monday.plusDays(1), "bad").copy(scheduledDateIso = "26/11/2026")
        val issues = TrainingCalendarIntegrityEngine.validate(listOf(invalid), emptyList(), 3, monday)
        assertTrue(issues.any { it.contains("data inválida") })
    }
}
