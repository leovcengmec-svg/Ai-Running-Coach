package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WorkoutBlockFeedbackEngineTest {
    @Test fun `classifica ritmo mais rapido dentro e mais lento que faixa prescrita`() {
        val block = WorkoutBlockPaceFeedback(
            blockKey = "s0_r1", segmentIndex = 0, repetition = 1, segmentName = "Intervalo",
            targetZone = "Z4", targetFastestPaceSecondsPerKm = 350,
            targetSlowestPaceSecondsPerKm = 370, actualPaceSecondsPerKm = 340, targetMode = "TIME"
        )
        assertEquals(WorkoutBlockFeedbackEngine.FASTER, WorkoutBlockFeedbackEngine.compare(block).status)
        assertEquals(WorkoutBlockFeedbackEngine.PRECISE, WorkoutBlockFeedbackEngine.compare(block.copy(actualPaceSecondsPerKm = 360)).status)
        assertEquals(WorkoutBlockFeedbackEngine.SLOWER, WorkoutBlockFeedbackEngine.compare(block.copy(actualPaceSecondsPerKm = 380)).status)
    }

    @Test fun `repeticoes de trabalho e recuperacao sao expandidas em ordem intercalada`() {
        val segments = listOf(
            WorkoutSegment("Aquecimento", "", durationMin = 5, targetMode = "TIME", paceZone = "Z2", targetPaceMinValue = 440, targetPaceMaxValue = 480),
            WorkoutSegment("Intervalo", "", durationMin = 2, targetMode = "TIME", repeatCount = 3, paceZone = "Z4", targetPaceMinValue = 350, targetPaceMaxValue = 370),
            WorkoutSegment("Recuperação", "", durationMin = 2, targetMode = "TIME", repeatCount = 3, recoveryMode = "ACTIVE_Z2", paceZone = "Z2", targetPaceMinValue = 440, targetPaceMaxValue = 500),
            WorkoutSegment("Intervalo", "", durationMin = 2, targetMode = "TIME", paceZone = "Z4", targetPaceMinValue = 350, targetPaceMaxValue = 370),
            WorkoutSegment("Desaquecimento", "", durationMin = 5, targetMode = "TIME", paceZone = "Z1", targetPaceMinValue = 480, targetPaceMaxValue = 540)
        )
        val blocks = WorkoutBlockFeedbackEngine.expand(segments)
        assertEquals(listOf("Aquecimento", "Intervalo", "Recuperação", "Intervalo", "Recuperação", "Intervalo", "Recuperação", "Intervalo", "Desaquecimento"), blocks.map { it.segment.name })
        assertEquals(listOf(1, 2, 3), blocks.filter { it.segment.name == "Intervalo" }.take(3).map { it.repetition })
    }


    @Test fun `corrida caminhada alterna por repeticao e caminhada nao exige pace`() {
        val walk = WorkoutSegment(
            "Caminhada de recuperação", "Caminhe até recuperar", durationMin = 2,
            repeatCount = 2, targetMode = "TIME"
        )
        val run = WorkoutSegment(
            "Corrida leve", "Corra leve", durationMin = 3,
            repeatCount = 2, targetMode = "TIME", paceZone = "Z2",
            targetPaceMinValue = 430, targetPaceMaxValue = 480
        )
        val blocks = WorkoutBlockFeedbackEngine.expand(listOf(walk, run))
        assertEquals(listOf("Caminhada de recuperação", "Corrida leve", "Caminhada de recuperação", "Corrida leve"), blocks.map { it.segment.name })
        assertFalse(WorkoutBlockFeedbackEngine.requiresPaceInput(blocks[0]))
        assertTrue(WorkoutBlockFeedbackEngine.requiresPaceInput(blocks[1]))
    }

    @Test fun `zona sem faixa prescrita nao gera comparacao ficticia`() {
        val block = WorkoutBlockPaceFeedback(
            blockKey = "s0_r1", segmentIndex = 0, repetition = 1, segmentName = "Strides",
            targetZone = null, targetFastestPaceSecondsPerKm = null,
            targetSlowestPaceSecondsPerKm = null, actualPaceSecondsPerKm = 300, targetMode = "DISTANCE"
        )
        assertEquals(WorkoutBlockFeedbackEngine.NO_TARGET, WorkoutBlockFeedbackEngine.compare(block).status)
    }

    @Test fun `inteligencia por zona exige varias sessoes antes de indicar revisao`() {
        val observations = (1..5).map { index ->
            ZoneExecutionObservation(
                sessionId = "session-${(index - 1) / 2}", dateIso = "2026-11-${(index + 10).toString().padStart(2, '0')}",
                zone = "Z2", actualPaceSecondsPerKm = 420, targetFastestPaceSecondsPerKm = 450,
                targetSlowestPaceSecondsPerKm = 480, effort = "Leve", feeling = "Bem", painPresent = false
            )
        }
        val summary = WorkoutBlockFeedbackEngine.summary(observations).single()
        assertEquals(5, summary.observationCount)
        assertTrue(summary.sessionCount >= 3)
        assertEquals("Evidência acumulada", summary.confidence)
        assertTrue(summary.interpretation.contains("candidata a revisão"))
    }

    @Test fun `detecta queda de ritmo nos blocos finais de uma mesma sessao`() {
        val observations = listOf(425, 430, 472, 480, 490).mapIndexed { index, pace ->
            ZoneExecutionObservation(
                sessionId = "intervalos-1", dateIso = "2026-11-18", zone = "Z4",
                actualPaceSecondsPerKm = pace, targetFastestPaceSecondsPerKm = 440,
                targetSlowestPaceSecondsPerKm = 460, effort = "Pesado", feeling = "Cansado",
                painPresent = false, sequenceOrder = index
            )
        } + listOf("rodagem-2", "rodagem-3").map { session ->
            ZoneExecutionObservation(
                sessionId = session, dateIso = "2026-11-19", zone = "Z4",
                actualPaceSecondsPerKm = 450, targetFastestPaceSecondsPerKm = 440,
                targetSlowestPaceSecondsPerKm = 460, effort = "Leve", feeling = "Bem",
                painPresent = false, sequenceOrder = 0
            )
        }
        val summary = WorkoutBlockFeedbackEngine.summary(observations).single()
        assertEquals(1, summary.sessionsWithPaceFade)
        assertEquals(1, summary.sessionsWithFastStartFade)
        assertTrue(summary.interpretation.contains("início acima da velocidade-alvo"))
    }

    @Test fun `sessao com mesmo ID e data mas tipo diferente conta separadamente`() {
        val observations = listOf(
            ZoneExecutionObservation("legacy", "2026-11-21", "Z2", 360, 350, 370, "Leve", "Bem", false, workoutType = "Aeróbio"),
            ZoneExecutionObservation("legacy", "2026-11-21", "Z2", 365, 350, 370, "Leve", "Bem", false, workoutType = "Qualidade")
        )
        val summary = WorkoutBlockFeedbackEngine.summary(observations).single()
        assertEquals(2, summary.sessionCount)
    }

}
