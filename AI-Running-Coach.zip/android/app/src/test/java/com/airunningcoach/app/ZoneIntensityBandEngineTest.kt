package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ZoneIntensityBandEngineTest {
    @Test fun `zero percent maps to slow boundary and one hundred to fast boundary`() {
        val zone = PaceRange(429, 499)
        assertEquals(499, ZoneIntensityBandEngine.paceAtPercent(zone, 0))
        assertEquals(429, ZoneIntensityBandEngine.paceAtPercent(zone, 100))
    }

    @Test fun `aerobic session receives a narrower active band inside Z2`() {
        val segment = WorkoutSegment(
            name = "Bloco aeróbio", instruction = "Conversa confortável", distanceKm = 4.0,
            targetPaceMinValue = 429, targetPaceMaxValue = 499, paceZone = "Z2"
        )
        val active = ZoneIntensityBandEngine.apply("Aeróbio", "Rodagem aeróbia", "BASE", segment)
        assertEquals(20, active.zoneIntensityMinPercent)
        assertEquals(65, active.zoneIntensityMaxPercent)
        assertTrue(active.targetPaceMinValue!! > 429)
        assertTrue(active.targetPaceMaxValue!! < 499)
        assertEquals(429, active.zoneBasePaceFastValue)
        assertEquals(499, active.zoneBasePaceSlowValue)
    }

    @Test fun `long run stays in a slower active portion than ordinary aerobic run`() {
        val segment = WorkoutSegment(
            name = "Longão aeróbio", instruction = "Conversável", distanceKm = 8.0,
            targetPaceMinValue = 429, targetPaceMaxValue = 499, paceZone = "Z2"
        )
        val longRun = ZoneIntensityBandEngine.apply("Longo", "Longão aeróbio", "BASE", segment)
        val easy = ZoneIntensityBandEngine.apply("Aeróbio", "Rodagem aeróbia", "BASE", segment)
        assertEquals(10, longRun.zoneIntensityMinPercent)
        assertEquals(55, longRun.zoneIntensityMaxPercent)
        assertTrue(longRun.targetPaceMinValue!! > easy.targetPaceMinValue!!)
        assertTrue(longRun.targetPaceMaxValue!! > easy.targetPaceMaxValue!!)
    }

    @Test fun `recovery phase limits active intensity to forty percent of the zone`() {
        val segment = WorkoutSegment(
            name = "Bloco limiar", instruction = "Controlado", durationMin = 8,
            targetPaceMinValue = 300, targetPaceMaxValue = 360, paceZone = "Z4"
        )
        val active = ZoneIntensityBandEngine.apply("Qualidade", "Tempo controlado", "RECOVERY", segment)
        assertEquals(40, active.zoneIntensityMaxPercent)
        assertTrue(active.targetPaceMinValue!! > 300)
    }

    @Test fun `new Cooper boundaries move at most fifteen seconds from previous calibration`() {
        val previous = PaceCalculator.calculateCooper(2.10)!!
        val next = PaceCalculator.calculateCooper(2.50)!!
        val smoothed = PaceCalculator.limitCalibrationChange(next, previous, 15)!!
        val before = previous.all().flatMap { listOf(it.range.fastestPaceValue, it.range.slowestPaceValue) }
        val after = smoothed.all().flatMap { listOf(it.range.fastestPaceValue, it.range.slowestPaceValue) }
        before.zip(after).forEach { (old, updated) -> assertTrue(kotlin.math.abs(updated - old) <= 15) }
    }

    @Test fun `talk test refinement is capped to a small conservative boundary shift`() {
        val baseline = PaceCalculator.calculateCooper(2.10)!!
        val talk = PaceCalculator.calculateCooper(2.10, listOf(440, 442, 441))!!
        val shift = talk.z2.range.fastestPaceValue - baseline.z2.range.fastestPaceValue
        assertTrue(kotlin.math.abs(shift) <= 15)
        assertEquals(3, talk.talkTestEvidenceCount)
        assertEquals(ZoneCalibrationEngine.CALIBRATED, talk.z2CalibrationStatus)
    }
    @Test fun `calibration keeps shared zone boundaries ordered after conservative smoothing`() {
        val previous = PaceCalculator.calculateCooper(2.0)!!
        val fasterResult = PaceCalculator.calculateCooper(3.2)!!
        val smoothed = PaceCalculator.limitCalibrationChange(fasterResult, previous, 15)!!
        val boundaries = smoothed.all().flatMap { listOf(it.range.fastestPaceValue, it.range.slowestPaceValue) }
        assertTrue(boundaries.all { it in 120..1800 })
        assertTrue(smoothed.all().all { it.range.fastestPaceValue < it.range.slowestPaceValue })
        smoothed.all().zipWithNext().forEach { (left, right) ->
            assertEquals(left.range.fastestPaceValue, right.range.slowestPaceValue)
        }
    }

    @Test fun `unchanged Cooper preview keeps same zones as saved calibration`() {
        val stored = PaceCalculator.calculateCooper(2.35)!!
        val preview = PaceCalculator.limitCalibrationChange(
            PaceCalculator.calculateCooper(2.35)!!,
            PaceCalculator.calculateCooper(2.10)!!,
            15
        )!!
        val expected = PaceCalculator.limitCalibrationChange(
            PaceCalculator.calculateCooper(2.35)!!,
            PaceCalculator.calculateCooper(2.10)!!,
            15
        )!!
        assertEquals(expected.all().map { it.range }, preview.all().map { it.range })
        assertTrue(stored.all().isNotEmpty())
    }

    @Test fun `warmup and cooldown use the faster edge of Z1`() {
        val warm = WorkoutSegment("Aquecimento", "Prepare", distanceKm = 0.5,
            targetPaceMinValue = 500, targetPaceMaxValue = 570, paceZone = "Z1")
        val cool = warm.copy(name = "Desaquecimento")
        listOf(warm, cool).forEach { segment ->
            val active = ZoneIntensityBandEngine.apply("Aeróbio", "Rodagem aeróbia", "BASE", segment)
            assertEquals(80, active.zoneIntensityMinPercent)
            assertEquals(100, active.zoneIntensityMaxPercent)
            assertEquals(500, active.targetPaceMinValue)
            assertTrue(active.targetPaceMaxValue!! < 570)
        }
    }

    @Test fun `explicit transition band at zero to twenty percent is respected`() {
        val segment = WorkoutSegment("Bloco inicial Z2", "Mais leve", distanceKm = 1.0,
            targetPaceMinValue = 430, targetPaceMaxValue = 500, paceZone = "Z2",
            zoneIntensityMinPercent = 0, zoneIntensityMaxPercent = 20)
        val active = ZoneIntensityBandEngine.apply("Aeróbio", "Progressivo", "BASE", segment)
        assertEquals(0, active.zoneIntensityMinPercent)
        assertEquals(20, active.zoneIntensityMaxPercent)
        assertEquals(486, active.targetPaceMinValue)
        assertEquals(500, active.targetPaceMaxValue)
    }

    @Test fun `explicit segment band remains stable after applying engine twice`() {
        val segment = WorkoutSegment("Bloco final Z3", "Moderado", distanceKm = 1.0,
            targetPaceMinValue = 360, targetPaceMaxValue = 420, paceZone = "Z3",
            zoneIntensityMinPercent = 0, zoneIntensityMaxPercent = 40)
        val once = ZoneIntensityBandEngine.apply("Aeróbio", "Progressivo", "BASE", segment)
        val twice = ZoneIntensityBandEngine.apply("Aeróbio", "Progressivo", "BASE", once)
        assertEquals(once.targetPaceMinValue, twice.targetPaceMinValue)
        assertEquals(once.targetPaceMaxValue, twice.targetPaceMaxValue)
        assertEquals(0, twice.zoneIntensityMinPercent)
        assertEquals(40, twice.zoneIntensityMaxPercent)
    }

}
