package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ZoneIntensityBandEngineTest {
    @Test fun `zero percent maps to slow boundary and one hundred to fast boundary`() {
        val zone = PaceRange(429, 499)
        assertEquals(499, ZoneIntensityBandEngine.paceAtPercent(zone, 0))
        assertEquals(429, ZoneIntensityBandEngine.paceAtPercent(zone, 100))
    }

    @Test fun `aerobic session receives a narrower active band inside Z2`() {
        val segment = WorkoutSegment(
            name = "Bloco aeróbio", instruction = "Conversa confortável", distanceKm = 4.0,
            targetPaceMinValue = 429, targetPaceMaxValue = 499, paceZone = "Z2"
        )
        val active = ZoneIntensityBandEngine.apply("Aeróbio", "Rodagem aeróbia", "BASE", segment)
        assertEquals(20, active.zoneIntensityMinPercent)
        assertEquals(65, active.zoneIntensityMaxPercent)
        assertTrue(active.targetPaceMinValue!! > 429)
        assertTrue(active.targetPaceMaxValue!! < 499)
        assertEquals(429, active.zoneBasePaceFastValue)
        assertEquals(499, active.zoneBasePaceSlowValue)
    }

    @Test fun `long run stays in a slower active portion than ordinary aerobic run`() {
        val segment = WorkoutSegment(
            name = "Longão aeróbio", instruction = "Conversável", distanceKm = 8.0,
            targetPaceMinValue = 429, targetPaceMaxValue = 499, paceZone = "Z2"
        )
        val longRun = ZoneIntensityBandEngine.apply("Longo", "Longão aeróbio", "BASE", segment)
        val easy = ZoneIntensityBandEngine.apply("Aeróbio", "Rodagem aeróbia", "BASE", segment)
        assertEquals(10, longRun.zoneIntensityMinPercent)
        assertEquals(55, longRun.zoneIntensityMaxPercent)
        assertTrue(longRun.targetPaceMinValue!! > easy.targetPaceMinValue!!)
        assertTrue(longRun.targetPaceMaxValue!! > easy.targetPaceMaxValue!!)
    }

    @Test fun `recovery phase limits active intensity to forty percent of the zone`() {
        val segment = WorkoutSegment(
            name = "Bloco limiar", instruction = "Controlado", durationMin = 8,
            targetPaceMinValue = 300, targetPaceMaxValue = 360, paceZone = "Z4"
        )
        val active = ZoneIntensityBandEngine.apply("Qualidade", "Tempo controlado", "RECOVERY", segment)
        assertEquals(40, active.zoneIntensityMaxPercent)
        assertTrue(active.targetPaceMinValue!! > 300)
    }

    @Test fun `new Cooper boundaries move at most fifteen seconds from previous calibration`() {
        val previous = PaceCalculator.calculateCooper(2.10)!!
        val next = PaceCalculator.calculateCooper(2.50)!!
        val smoothed = PaceCalculator.limitCalibrationChange(next, previous, 15)!!
        val before = previous.all().flatMap { listOf(it.range.fastestPaceValue, it.range.slowestPaceValue) }
        val after = smoothed.all().flatMap { listOf(it.range.fastestPaceValue, it.range.slowestPaceValue) }
        before.zip(after).forEach { (old, updated) -> assertTrue(kotlin.math.abs(updated - old) <= 15) }
    }

    @Test fun `talk test refinement is capped to a small conservative boundary shift`() {
        val baseline = PaceCalculator.calculateCooper(2.10)!!
        val talk = PaceCalculator.calculateCooper(2.10, listOf(440, 442, 441))!!
        val shift = talk.z2.range.fastestPaceValue - baseline.z2.range.fastestPaceValue
        assertTrue(kotlin.math.abs(shift) <= 15)
        assertEquals(3, talk.talkTestEvidenceCount)
        assertEquals(ZoneCalibrationEngine.CALIBRATED, talk.z2CalibrationStatus)
    }
    @Test fun `calibration keeps shared zone boundaries ordered after conservative smoothing`() {
        val previous = PaceCalculator.calculateCooper(2.0)!!
        val fasterResult = PaceCalculator.calculateCooper(3.2)!!
        val smoothed = PaceCalculator.limitCalibrationChange(fasterResult, previous, 15)!!
        val boundaries = smoothed.all().flatMap { listOf(it.range.fastestPaceValue, it.range.slowestPaceValue) }
        assertTrue(boundaries.all { it in 120..1800 })
        assertTrue(smoothed.all().all { it.range.fastestPaceValue < it.range.slowestPaceValue })
        smoothed.all().zipWithNext().forEach { (left, right) ->
            assertEquals(left.range.fastestPaceValue, right.range.slowestPaceValue)
        }
    }

    @Test fun `unchanged Cooper preview keeps same zones as saved calibration`() {
        val stored = PaceCalculator.calculateCooper(2.35)!!
        val preview = PaceCalculator.limitCalibrationChange(
            PaceCalculator.calculateCooper(2.35)!!,
            PaceCalculator.calculateCooper(2.10)!!,
            15
        )!!
        val expected = PaceCalculator.limitCalibrationChange(
            PaceCalculator.calculateCooper(2.35)!!,
            PaceCalculator.calculateCooper(2.10)!!,
            15
        )!!
        assertEquals(expected.all().map { it.range }, preview.all().map { it.range })
        assertTrue(stored.all().isNotEmpty())
    }

    @Test fun `legacy segment keeps faster edge of Z1 without athlete context`() {
        val warm = WorkoutSegment("Aquecimento", "Prepare", distanceKm = 0.5,
            targetPaceMinValue = 500, targetPaceMaxValue = 570, paceZone = "Z1")
        val active = ZoneIntensityBandEngine.apply("Aeróbio", "Rodagem aeróbia", "BASE", warm)
        assertEquals(80, active.zoneIntensityMinPercent)
        assertEquals(100, active.zoneIntensityMaxPercent)
        assertEquals(500, active.targetPaceMinValue)
        assertTrue(active.targetPaceMaxValue!! < 570)
    }

    @Test fun `experienced runner warmup and cooldown move to Z2 zero to twenty`() {
        val snapshot = PaceCalibrationSnapshot(
            assessmentDateIso = "2026-11-19", distanceKm = 2.4, averagePaceMmSs = "5:00",
            estimatedVo2Max = 42.3, modelVersion = "TEST",
            zoneRanges = mapOf("Z1" to "8:00–9:30 min/km", "Z2" to "7:00–8:00 min/km",
                "Z3" to "6:00–7:00 min/km", "Z4" to "5:00–6:00 min/km", "Z5" to "4:30–5:00 min/km")
        )
        val warm = WorkoutSegment("Aquecimento", "Prepare", distanceKm = 1.0, targetMode = "DISTANCE",
            targetPaceMinValue = 480, targetPaceMaxValue = 570, paceZone = "Z1")
        val cool = warm.copy(name = "Desaquecimento")
        val workout = Workout(date = "Hoje", title = "Progressivo", detail = "Teste", type = "Aeróbio",
            objective = "Base", stimulus = "EASY_AEROBIC_Z2", distanceKm = 5.0,
            segments = listOf(warm, cool), paceCalibrationSnapshot = snapshot, experienceMonths = 9)
        val updated = ZoneIntensityBandEngine.apply(workout)
        updated.segments.forEach { segment ->
            assertEquals("Z2", segment.paceZone)
            assertEquals(0, segment.zoneIntensityMinPercent)
            assertEquals(20, segment.zoneIntensityMaxPercent)
            assertEquals(468, segment.targetPaceMinValue)
            assertEquals(480, segment.targetPaceMaxValue)
        }
    }

    @Test fun `free percentage bands from zero to one hundred work in every Z2 to Z5 zone`() {
        val zones = listOf(PaceRange(420, 480), PaceRange(360, 420), PaceRange(300, 360), PaceRange(270, 300))
        zones.forEach { zone ->
            assertEquals(zone, ZoneIntensityBandEngine.activeRange(zone, ActiveZoneBand(0, 100)))
            val partial = ZoneIntensityBandEngine.activeRange(zone, ActiveZoneBand(35, 85))
            assertTrue(partial.fastestPaceValue > zone.fastestPaceValue)
            assertTrue(partial.slowestPaceValue < zone.slowestPaceValue)
        }
        val narrow = ActiveZoneBand(20, 30)
        assertEquals(20, narrow.minPercent)
        assertEquals(30, narrow.maxPercent)
    }

    @Test fun `passive recovery never receives pace distance or zone targets`() {
        val rest = WorkoutSegment("Pausa parada", "Fique parado", durationMin = 2,
            distanceKm = null, targetMode = "TIME", recoveryMode = "PASSIVE")
        val applied = ZoneIntensityBandEngine.apply("Qualidade", "Intervalado", "BASE", rest)
        assertEquals("TIME", applied.targetMode)
        assertEquals(null, applied.distanceKm)
        assertEquals(null, applied.paceZone)
        assertEquals(null, applied.targetPaceMinValue)
        assertEquals(null, applied.targetPaceMaxValue)
        assertEquals("PASSIVE", applied.recoveryMode)
    }

    @Test fun `walking recovery has no running pace or zone target`() {
        val rest = WorkoutSegment("Recuperação caminhando", "Caminhe", durationMin = 2,
            targetMode = "TIME", paceZone = "Z1", targetPaceMinValue = 500,
            targetPaceMaxValue = 570, recoveryMode = "WALK")
        val applied = ZoneIntensityBandEngine.apply("Qualidade", "Intervalado", "BASE", rest)
        assertEquals("TIME", applied.targetMode)
        assertEquals(null, applied.paceZone)
        assertEquals(null, applied.targetPaceMinValue)
        assertEquals(null, applied.targetPaceMaxValue)
        assertEquals("WALK", applied.recoveryMode)
    }

    @Test fun `explicit transition band at zero to twenty percent is respected`() {
        val segment = WorkoutSegment("Bloco inicial Z2", "Mais leve", distanceKm = 1.0,
            targetPaceMinValue = 430, targetPaceMaxValue = 500, paceZone = "Z2",
            zoneIntensityMinPercent = 0, zoneIntensityMaxPercent = 20)
        val active = ZoneIntensityBandEngine.apply("Aeróbio", "Progressivo", "BASE", segment)
        assertEquals(0, active.zoneIntensityMinPercent)
        assertEquals(20, active.zoneIntensityMaxPercent)
        assertEquals(486, active.targetPaceMinValue)
        assertEquals(500, active.targetPaceMaxValue)
    }

    @Test fun `explicit segment band remains stable after applying engine twice`() {
        val segment = WorkoutSegment("Bloco final Z3", "Moderado", distanceKm = 1.0,
            targetPaceMinValue = 360, targetPaceMaxValue = 420, paceZone = "Z3",
            zoneIntensityMinPercent = 0, zoneIntensityMaxPercent = 40)
        val once = ZoneIntensityBandEngine.apply("Aeróbio", "Progressivo", "BASE", segment)
        val twice = ZoneIntensityBandEngine.apply("Aeróbio", "Progressivo", "BASE", once)
        assertEquals(once.targetPaceMinValue, twice.targetPaceMinValue)
        assertEquals(once.targetPaceMaxValue, twice.targetPaceMaxValue)
        assertEquals(0, twice.zoneIntensityMinPercent)
        assertEquals(40, twice.zoneIntensityMaxPercent)
    }

}
