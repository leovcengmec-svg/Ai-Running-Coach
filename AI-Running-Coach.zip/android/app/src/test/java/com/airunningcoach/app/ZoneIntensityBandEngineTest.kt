package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ZoneIntensityBandEngineTest {
    @Test fun `zero percent maps to slow boundary and one hundred to fast boundary`() {
        val zone = PaceRange(429, 499)
        assertEquals(499, ZoneIntensityBandEngine.paceAtPercent(zone, 0))
        assertEquals(429, ZoneIntensityBandEngine.paceAtPercent(zone, 100))
    }

    @Test fun `aerobic session receives a narrower active band inside Z2`() {
        val segment = WorkoutSegment(
            name = "Bloco aeróbio", instruction = "Conversa confortável", distanceKm = 4.0,
            targetPaceMinValue = 429, targetPaceMaxValue = 499, paceZone = "Z2"
        )
        val active = ZoneIntensityBandEngine.apply("Aeróbio", "Rodagem aeróbia", "BASE", segment)
        assertEquals(20, active.zoneIntensityMinPercent)
        assertEquals(65, active.zoneIntensityMaxPercent)
        assertTrue(active.targetPaceMinValue!! > 429)
        assertTrue(active.targetPaceMaxValue!! < 499)
        assertEquals(429, active.zoneBasePaceFastValue)
        assertEquals(499, active.zoneBasePaceSlowValue)
    }

    @Test fun `long run stays in a slower active portion than ordinary aerobic run`() {
        val segment = WorkoutSegment(
            name = "Longão aeróbio", instruction = "Conversável", distanceKm = 8.0,
            targetPaceMinValue = 429, targetPaceMaxValue = 499, paceZone = "Z2"
        )
        val longRun = ZoneIntensityBandEngine.apply("Longo", "Longão aeróbio", "BASE", segment)
        val easy = ZoneIntensityBandEngine.apply("Aeróbio", "Rodagem aeróbia", "BASE", segment)
        assertEquals(10, longRun.zoneIntensityMinPercent)
        assertEquals(55, longRun.zoneIntensityMaxPercent)
        assertTrue(longRun.targetPaceMinValue!! > easy.targetPaceMinValue!!)
        assertTrue(longRun.targetPaceMaxValue!! > easy.targetPaceMaxValue!!)
    }

    @Test fun `recovery phase limits active intensity to forty percent of the zone`() {
        val segment = WorkoutSegment(
            name = "Bloco limiar", instruction = "Controlado", durationMin = 8,
            targetPaceMinValue = 300, targetPaceMaxValue = 360, paceZone = "Z4"
        )
        val active = ZoneIntensityBandEngine.apply("Qualidade", "Tempo controlado", "RECOVERY", segment)
        assertEquals(40, active.zoneIntensityMaxPercent)
        assertTrue(active.targetPaceMinValue!! > 300)
    }

    @Test fun `new Cooper boundaries move at most fifteen seconds from previous calibration`() {
        val previous = PaceCalculator.calculateCooper(2.10)!!
        val next = PaceCalculator.calculateCooper(2.50)!!
        val smoothed = PaceCalculator.limitCalibrationChange(next, previous, 15)!!
        val before = previous.all().flatMap { listOf(it.range.fastestPaceValue, it.range.slowestPaceValue) }
        val after = smoothed.all().flatMap { listOf(it.range.fastestPaceValue, it.range.slowestPaceValue) }
        before.zip(after).forEach { (old, updated) -> assertTrue(kotlin.math.abs(updated - old) <= 15) }
    }

    @Test fun `dados legados de teste da fala nao modificam a faixa Z2`() {
        val baseline = PaceCalculator.calculateCooper(2.10)!!
        val legacyTalk = PaceCalculator.calculateCooper(2.10, listOf(440, 442, 441))!!
        assertEquals(baseline.z2.range, legacyTalk.z2.range)
        assertEquals(0, legacyTalk.talkTestEvidenceCount)
        assertEquals(ZoneCalibrationEngine.INITIAL, legacyTalk.z2CalibrationStatus)
    }
    @Test fun `calibration keeps shared zone boundaries ordered after conservative smoothing`() {
        val previous = PaceCalculator.calculateCooper(2.0)!!
        val fasterResult = PaceCalculator.calculateCooper(3.2)!!
        val smoothed = PaceCalculator.limitCalibrationChange(fasterResult, previous, 15)!!
        val boundaries = smoothed.all().flatMap { listOf(it.range.fastestPaceValue, it.range.slowestPaceValue) }
        assertTrue(boundaries.all { it in 120..1800 })
        assertTrue(smoothed.all().all { it.range.fastestPaceValue < it.range.slowestPaceValue })
        smoothed.all().zipWithNext().forEach { (left, right) ->
            assertEquals(left.range.fastestPaceValue, right.range.slowestPaceValue)
        }
    }

    @Test fun `unchanged Cooper preview keeps same zones as saved calibration`() {
        val stored = PaceCalculator.calculateCooper(2.35)!!
        val preview = PaceCalculator.limitCalibrationChange(
            PaceCalculator.calculateCooper(2.35)!!,
            PaceCalculator.calculateCooper(2.10)!!,
            15
        )!!
        val expected = PaceCalculator.limitCalibrationChange(
            PaceCalculator.calculateCooper(2.35)!!,
            PaceCalculator.calculateCooper(2.10)!!,
            15
        )!!
        assertEquals(expected.all().map { it.range }, preview.all().map { it.range })
        assertTrue(stored.all().isNotEmpty())
    }

    @Test fun `legacy segment keeps faster edge of Z1 without athlete context`() {
        val warm = WorkoutSegment("Aquecimento", "Prepare", distanceKm = 0.5,
            targetPaceMinValue = 500, targetPaceMaxValue = 570, paceZone = "Z1")
        val active = ZoneIntensityBandEngine.apply("Aeróbio", "Rodagem aeróbia", "BASE", warm)
        assertEquals(80, active.zoneIntensityMinPercent)
        assertEquals(100, active.zoneIntensityMaxPercent)
        assertEquals(500, active.targetPaceMinValue)
        assertTrue(active.targetPaceMaxValue!! < 570)
    }

    @Test fun `experienced runner warmup and cooldown move to Z2 zero to twenty`() {
        val snapshot = PaceCalibrationSnapshot(
            assessmentDateIso = "2026-11-19", distanceKm = 2.4, averagePaceMmSs = "5:00",
            estimatedVo2Max = 42.3, modelVersion = "TEST",
            zoneRanges = mapOf("Z1" to "8:00–9:30 min/km", "Z2" to "7:00–8:00 min/km",
                "Z3" to "6:00–7:00 min/km", "Z4" to "5:00–6:00 min/km", "Z5" to "4:30–5:00 min/km")
        )
        val warm = WorkoutSegment("Aquecimento", "Prepare", distanceKm = 1.0, targetMode = "DISTANCE",
            targetPaceMinValue = 480, targetPaceMaxValue = 570, paceZone = "Z1")
        val cool = warm.copy(name = "Desaquecimento")
        val workout = Workout(date = "Hoje", title = "Progressivo", detail = "Teste", type = "Aeróbio",
            objective = "Base", stimulus = "EASY_AEROBIC_Z2", distanceKm = 5.0,
            segments = listOf(warm, cool), paceCalibrationSnapshot = snapshot, experienceMonths = 9)
        val updated = ZoneIntensityBandEngine.apply(workout)
        updated.segments.forEach { segment ->
            assertEquals("Z2", segment.paceZone)
            assertEquals(0, segment.zoneIntensityMinPercent)
            assertEquals(20, segment.zoneIntensityMaxPercent)
            assertEquals(468, segment.targetPaceMinValue)
            assertEquals(480, segment.targetPaceMaxValue)
        }
    }

    @Test fun `free percentage bands from zero to one hundred work in every Z2 to Z5 zone`() {
        val zones = listOf(PaceRange(420, 480), PaceRange(360, 420), PaceRange(300, 360), PaceRange(270, 300))
        zones.forEach { zone ->
            assertEquals(zone, ZoneIntensityBandEngine.activeRange(zone, ActiveZoneBand(0, 100)))
            val partial = ZoneIntensityBandEngine.activeRange(zone, ActiveZoneBand(35, 85))
            assertTrue(partial.fastestPaceValue > zone.fastestPaceValue)
            assertTrue(partial.slowestPaceValue < zone.slowestPaceValue)
        }
        val narrow = ActiveZoneBand(20, 30)
        assertEquals(20, narrow.minPercent)
        assertEquals(30, narrow.maxPercent)
    }

    @Test fun `passive recovery never receives pace distance or zone targets`() {
        val rest = WorkoutSegment("Pausa parada", "Fique parado", durationMin = 2,
            distanceKm = null, targetMode = "TIME", recoveryMode = "PASSIVE")
        val applied = ZoneIntensityBandEngine.apply("Qualidade", "Intervalado", "BASE", rest)
        assertEquals("TIME", applied.targetMode)
        assertEquals(null, applied.distanceKm)
        assertEquals(null, applied.paceZone)
        assertEquals(null, applied.targetPaceMinValue)
        assertEquals(null, applied.targetPaceMaxValue)
        assertEquals("PASSIVE", applied.recoveryMode)
    }

    @Test fun `walking recovery has no running pace or zone target`() {
        val rest = WorkoutSegment("Recuperação caminhando", "Caminhe", durationMin = 2,
            targetMode = "TIME", paceZone = "Z1", targetPaceMinValue = 500,
            targetPaceMaxValue = 570, recoveryMode = "WALK")
        val applied = ZoneIntensityBandEngine.apply("Qualidade", "Intervalado", "BASE", rest)
        assertEquals("TIME", applied.targetMode)
        assertEquals(null, applied.paceZone)
        assertEquals(null, applied.targetPaceMinValue)
        assertEquals(null, applied.targetPaceMaxValue)
        assertEquals("WALK", applied.recoveryMode)
    }

    @Test fun `explicit transition band at zero to twenty percent is respected`() {
        val segment = WorkoutSegment("Bloco inicial Z2", "Mais leve", distanceKm = 1.0,
            targetPaceMinValue = 430, targetPaceMaxValue = 500, paceZone = "Z2",
            zoneIntensityMinPercent = 0, zoneIntensityMaxPercent = 20)
        val active = ZoneIntensityBandEngine.apply("Aeróbio", "Progressivo", "BASE", segment)
        assertEquals(0, active.zoneIntensityMinPercent)
        assertEquals(20, active.zoneIntensityMaxPercent)
        assertEquals(486, active.targetPaceMinValue)
        assertEquals(500, active.targetPaceMaxValue)
    }

    @Test fun `explicit segment band remains stable after applying engine twice`() {
        val segment = WorkoutSegment("Bloco final Z3", "Moderado", distanceKm = 1.0,
            targetPaceMinValue = 360, targetPaceMaxValue = 420, paceZone = "Z3",
            zoneIntensityMinPercent = 0, zoneIntensityMaxPercent = 40)
        val once = ZoneIntensityBandEngine.apply("Aeróbio", "Progressivo", "BASE", segment)
        val twice = ZoneIntensityBandEngine.apply("Aeróbio", "Progressivo", "BASE", once)
        assertEquals(once.targetPaceMinValue, twice.targetPaceMinValue)
        assertEquals(once.targetPaceMaxValue, twice.targetPaceMaxValue)
        assertEquals(0, twice.zoneIntensityMinPercent)
        assertEquals(40, twice.zoneIntensityMaxPercent)
    }

    @Test fun `recuperacao sem faixa explicita usa Z1 alto ou Z2 lento 0 a 20`() {
        val z1 = WorkoutSegment("Recuperação entre blocos Z1", "Recupere confortavelmente", durationMin = 2,
            targetPaceMinValue = 500, targetPaceMaxValue = 570, paceZone = "Z1")
        val z2 = z1.copy(name = "Recuperação aeróbia Z2", paceZone = "Z2",
            targetPaceMinValue = 430, targetPaceMaxValue = 500)
        val z1Applied = ZoneIntensityBandEngine.apply("Qualidade", "Fartlek aeróbio", "BASE", z1)
        val z2Applied = ZoneIntensityBandEngine.apply("Qualidade", "Intervalado aeróbio", "BASE", z2)
        assertEquals(90, z1Applied.zoneIntensityMinPercent)
        assertEquals(100, z1Applied.zoneIntensityMaxPercent)
        assertEquals(0, z2Applied.zoneIntensityMinPercent)
        assertEquals(20, z2Applied.zoneIntensityMaxPercent)
    }

    @Test fun `inter-block Z1 recovery slower than cooldown becomes walking`() {
        val warm = WorkoutSegment(
            name = "Aquecimento", instruction = "Prepare", durationMin = 8, distanceKm = 1.0,
            targetPaceMinValue = 477, targetPaceMaxValue = 490, paceZone = "Z2",
            zoneBasePaceFastValue = 477, zoneBasePaceSlowValue = 490,
            zoneIntensityMinPercent = 0, zoneIntensityMaxPercent = 20
        )
        val legacyRecovery = WorkoutSegment(
            name = "Recuperação entre blocos Z1", instruction = "Recupere", durationMin = 3, distanceKm = 0.3,
            targetPaceMinValue = 550, targetPaceMaxValue = 571, paceZone = "Z1",
            zoneBasePaceFastValue = 530, zoneBasePaceSlowValue = 571,
            zoneIntensityMinPercent = 0, zoneIntensityMaxPercent = 50
        )
        val cooldown = warm.copy(name = "Desaquecimento", durationMin = 8, distanceKm = 1.0)
        val workout = Workout(
            date = "Hoje", title = "Fartlek aeróbio", detail = "Teste", type = "Qualidade",
            objective = "Base", stimulus = "PYRAMID_INTERVAL_Z3_Z5", distanceKm = 5.0,
            segments = listOf(warm, legacyRecovery, cooldown), experienceMonths = 0
        )

        val updated = ZoneIntensityBandEngine.apply(workout)
        val recovery = updated.segments[1]
        assertEquals("WALK", recovery.recoveryMode)
        assertEquals(null, recovery.paceZone)
        assertEquals(null, recovery.targetPaceMinValue)
        assertEquals(null, recovery.targetPaceMaxValue)
        assertEquals(3, recovery.durationMin)
        assertTrue(recovery.instruction.contains("Caminhe"))
        assertEquals("WALK", ZoneIntensityBandEngine.apply(updated).segments[1].recoveryMode)
    }

    @Test fun `active Z1 recovery remains active when its pace overlaps cooldown`() {
        val warm = WorkoutSegment(
            name = "Aquecimento", instruction = "Prepare", durationMin = 6, distanceKm = 0.7,
            targetPaceMinValue = 500, targetPaceMaxValue = 540, paceZone = "Z1",
            zoneBasePaceFastValue = 500, zoneBasePaceSlowValue = 540,
            zoneIntensityMinPercent = 80, zoneIntensityMaxPercent = 100
        )
        val recovery = WorkoutSegment(
            name = "Recuperação entre blocos Z1", instruction = "Recupere", durationMin = 2, distanceKm = 0.2,
            targetPaceMinValue = 500, targetPaceMaxValue = 504, paceZone = "Z1",
            zoneBasePaceFastValue = 500, zoneBasePaceSlowValue = 540,
            zoneIntensityMinPercent = 90, zoneIntensityMaxPercent = 100
        )
        val cooldown = warm.copy(name = "Desaquecimento")
        val workout = Workout(
            date = "Hoje", title = "Fartlek leve", detail = "Teste", type = "Qualidade",
            objective = "Base", stimulus = "PYRAMID_INTERVAL_Z3_Z5", distanceKm = 4.0,
            segments = listOf(warm, recovery, cooldown), experienceMonths = 0
        )

        val updatedRecovery = ZoneIntensityBandEngine.apply(workout).segments[1]
        assertEquals("ACTIVE_Z1", updatedRecovery.recoveryMode)
        assertEquals("Z1", updatedRecovery.paceZone)
        assertTrue(updatedRecovery.targetPaceMinValue!! <= updatedRecovery.targetPaceMaxValue!!)
    }

    @Test fun `active Z2 recovery remains jogging without exact cooldown overlap`() {
        val recovery = WorkoutSegment(
            name = "Recuperação entre blocos Z2", instruction = "Trote confortável", durationMin = 2,
            distanceKm = 0.25, targetPaceMinValue = 490, targetPaceMaxValue = 498,
            paceZone = "Z2", zoneBasePaceFastValue = 450, zoneBasePaceSlowValue = 510,
            zoneIntensityMinPercent = 20, zoneIntensityMaxPercent = 65, recoveryMode = "ACTIVE_Z2"
        )
        val cooldown = WorkoutSegment(
            name = "Desaquecimento", instruction = "Reduza", durationMin = 8, distanceKm = 1.0,
            targetPaceMinValue = 477, targetPaceMaxValue = 485, paceZone = "Z2"
        )
        val result = ZoneIntensityBandEngine.enforceRecoveryCompatibility(listOf(recovery, cooldown))
        assertEquals("ACTIVE_Z2", result.first().recoveryMode)
        assertEquals("Z2", result.first().paceZone)
        assertEquals(2, result.first().durationMin)
    }

    @Test fun `recovery migration changes pending sessions and preserves completed history`() {
        val warm = WorkoutSegment("Aquecimento", "Prepare", durationMin = 8, distanceKm = 1.0,
            targetPaceMinValue = 477, targetPaceMaxValue = 490, paceZone = "Z2",
            zoneBasePaceFastValue = 477, zoneBasePaceSlowValue = 490,
            zoneIntensityMinPercent = 0, zoneIntensityMaxPercent = 20)
        val legacyRecovery = WorkoutSegment("Recuperação entre blocos Z1", "Recupere", durationMin = 3, distanceKm = 0.3,
            targetPaceMinValue = 550, targetPaceMaxValue = 571, paceZone = "Z1",
            zoneBasePaceFastValue = 530, zoneBasePaceSlowValue = 571,
            zoneIntensityMinPercent = 0, zoneIntensityMaxPercent = 50)
        val autoWalkedByV84 = WorkoutSegment(
            name = "Recuperação caminhando entre blocos",
            instruction = "Caminhe durante a recuperação. Este protocolo de maior intensidade não possui uma faixa ativa Z1 compatível com a calibração atual; retome somente quando a respiração estiver controlada.",
            durationMin = 3, distanceKm = 0.3, intensity = "LOW", rpeRange = "2-3", targetMode = "TIME", recoveryMode = "WALK"
        )
        val autoWalkedByV84ScreenshotVariant = autoWalkedByV84.copy(
            instruction = "Caminhe durante a recuperação. A faixa de corrida desta zona não é compatível com o desaquecimento desta sessão."
        )
        val intentionalWalk = WorkoutSegment(
            name = "Recuperação caminhando por segurança",
            instruction = "Caminhe por indicação de segurança.",
            durationMin = 3, distanceKm = 0.2, intensity = "LOW", rpeRange = "2-3",
            targetMode = "TIME", recoveryMode = "WALK"
        )
        val cooldown = warm.copy(name = "Desaquecimento")
        val snapshot = PaceCalibrationSnapshot(
            assessmentDateIso = "2026-11-01", distanceKm = 2.2, averagePaceMmSs = "5:27",
            estimatedVo2Max = 35.0, modelVersion = "TEST",
            zoneRanges = mapOf("Z2" to "7:30–8:30 min/km")
        )
        val base = Workout(date = "Hoje", title = "Fartlek", detail = "Teste", type = "Qualidade",
            objective = "Base", stimulus = "FARTLEK_Z2_Z3:F01", distanceKm = 5.0,
            segments = listOf(warm, legacyRecovery, autoWalkedByV84, autoWalkedByV84ScreenshotVariant, intentionalWalk, cooldown), experienceMonths = 0,
            paceCalibrationSnapshot = snapshot)
        val completed = base.copy(done = true)
        val pending = base.copy(sessionId = "PENDING")

        val migrated = ZoneIntensityBandEngine.migrateUnfinishedWorkouts(listOf(completed, pending))
        assertTrue(migrated.changed)
        assertEquals(completed.segments, migrated.workouts[0].segments)
        val migratedRecoveries = migrated.workouts[1].segments.filter { it.recoveryMode == "ACTIVE_Z2" }
        assertEquals(3, migratedRecoveries.size)
        migratedRecoveries.forEach { migratedRecovery ->
            assertEquals("Z2", migratedRecovery.paceZone)
            assertEquals(0, migratedRecovery.zoneIntensityMinPercent)
            assertEquals(20, migratedRecovery.zoneIntensityMaxPercent)
            assertEquals(2, migratedRecovery.durationMin)
            assertTrue(migratedRecovery.targetPaceMinValue != null)
            assertTrue(migratedRecovery.targetPaceMaxValue != null)
            assertEquals(498, migratedRecovery.targetPaceMinValue) // 8:18/km
            assertEquals(510, migratedRecovery.targetPaceMaxValue) // 8:30/km
        }
        assertTrue(migrated.workouts[1].segments.any {
            it.recoveryMode == "WALK" && it.instruction == "Caminhe por indicação de segurança."
        })
        val migratedAgain = ZoneIntensityBandEngine.migrateUnfinishedWorkouts(migrated.workouts)
        assertFalse(migratedAgain.changed)
        assertEquals("ACTIVE_Z2", migratedAgain.workouts[1].segments[1].recoveryMode)
        assertEquals("ACTIVE_Z2", migratedAgain.workouts[1].segments[2].recoveryMode)
        assertEquals("ACTIVE_Z2", migratedAgain.workouts[1].segments[3].recoveryMode)
    }


    @Test fun `progression migration separates first main block from warmup and preserves completed history`() {
        val snapshot = PaceCalibrationSnapshot(
            assessmentDateIso = "2026-11-01", distanceKm = 2.4, averagePaceMmSs = "5:00",
            estimatedVo2Max = 42.0, modelVersion = "TEST",
            zoneRanges = mapOf("Z2" to "7:30–8:30 min/km", "Z3" to "6:30–7:30 min/km")
        )
        val z2 = PaceRange(450, 510)
        fun segment(name: String, min: Int, max: Int) = WorkoutSegment(
            name = name, instruction = "Teste", distanceKm = 1.0, paceZone = "Z2",
            targetPaceMinValue = ZoneIntensityBandEngine.activeRange(z2, ActiveZoneBand(min, max)).fastestPaceValue,
            targetPaceMaxValue = ZoneIntensityBandEngine.activeRange(z2, ActiveZoneBand(min, max)).slowestPaceValue,
            zoneBasePaceFastValue = 450, zoneBasePaceSlowValue = 510,
            zoneIntensityMinPercent = min, zoneIntensityMaxPercent = max
        )
        val warm = segment("Aquecimento", 0, 20)
        val oldFirst = segment("Bloco inicial Z2 confortável", 0, 20)
        val oldSecond = segment("Bloco final Z2 mais rápido", 20, 65)
        val cool = segment("Desaquecimento", 0, 20)
        val base = Workout(
            date = "Hoje", title = "Longão progressivo Z2", detail = "Teste", type = "Longo",
            objective = "Progressão", stimulus = "LONG_RUN_PROGRESSIVE_Z2", distanceKm = 4.0,
            segments = listOf(warm, oldFirst, oldSecond, cool), paceCalibrationSnapshot = snapshot
        )
        val completed = base.copy(done = true, sessionId = "DONE")
        val pending = base.copy(done = false, sessionId = "PENDING")
        val migrated = ZoneIntensityBandEngine.migrateUnfinishedWorkouts(listOf(completed, pending))
        assertTrue(migrated.changed)
        assertEquals(completed.segments, migrated.workouts.first().segments)
        val updated = migrated.workouts.last().segments
        assertEquals(0, updated[0].zoneIntensityMinPercent)
        assertEquals(20, updated[0].zoneIntensityMaxPercent)
        assertEquals(20, updated[1].zoneIntensityMinPercent)
        assertEquals(40, updated[1].zoneIntensityMaxPercent)
        assertEquals(40, updated[2].zoneIntensityMinPercent)
        assertEquals(65, updated[2].zoneIntensityMaxPercent)
        assertEquals(0, updated[3].zoneIntensityMinPercent)
        assertEquals(20, updated[3].zoneIntensityMaxPercent)
        assertTrue(updated[0].targetPaceMinValue != updated[1].targetPaceMinValue)
        val secondPass = ZoneIntensityBandEngine.migrateUnfinishedWorkouts(migrated.workouts)
        assertEquals(false, secondPass.changed)
    }


    @Test fun `Fartlek V84 auto-walk migration restores active Z2 and preserves session volume`() {
        val snapshot = PaceCalibrationSnapshot(
            assessmentDateIso = "2026-11-01", distanceKm = 2.2, averagePaceMmSs = "5:27",
            estimatedVo2Max = 35.0, modelVersion = "TEST",
            zoneRanges = mapOf("Z2" to "7:30–8:30 min/km", "Z3" to "6:30–7:30 min/km")
        )
        val z2 = PaceRange(450, 510)
        fun activeSegment(name: String, band: ActiveZoneBand, distance: Double, duration: Int) = WorkoutSegment(
            name = name, instruction = "Teste", durationMin = duration, distanceKm = distance,
            targetMode = "TIME", paceZone = "Z2",
            targetPaceMinValue = ZoneIntensityBandEngine.activeRange(z2, band).fastestPaceValue,
            targetPaceMaxValue = ZoneIntensityBandEngine.activeRange(z2, band).slowestPaceValue,
            zoneBasePaceFastValue = z2.fastestPaceValue, zoneBasePaceSlowValue = z2.slowestPaceValue,
            zoneIntensityMinPercent = band.minPercent, zoneIntensityMaxPercent = band.maxPercent
        )
        val warm = activeSegment("Aquecimento", ActiveZoneBand(0, 20), 0.4, 3)
        val work = activeSegment("Fartlek aeróbio Z2", ActiveZoneBand(20, 65), 0.4, 3)
        val legacyAutoWalk = WorkoutSegment(
            name = "Recuperação caminhando entre blocos",
            instruction = "Caminhe durante a recuperação. Este protocolo não possui uma faixa ativa Z1 compatível com a calibração atual.",
            durationMin = 3, distanceKm = 0.3, targetMode = "TIME", recoveryMode = "WALK",
            rpeRange = "2-3"
        )
        val cool = activeSegment("Desaquecimento", ActiveZoneBand(0, 20), 0.4, 3)
        val base = Workout(
            date = "Hoje", title = "Fartlek aeróbio", detail = "Teste", type = "Qualidade",
            objective = "Fartlek", stimulus = "FARTLEK_Z2_Z3:F01", distanceKm = 2.0,
            segments = listOf(warm, work, legacyAutoWalk, cool), paceCalibrationSnapshot = snapshot
        )
        val completed = base.copy(done = true, sessionId = "DONE")
        val migrated = ZoneIntensityBandEngine.migrateUnfinishedWorkouts(listOf(completed, base.copy(sessionId = "PENDING")))
        val unchangedHistory = migrated.workouts.first()
        val pending = migrated.workouts.last()
        val recovery = pending.segments.single { it.recoveryMode == "ACTIVE_Z2" }
        assertEquals(completed.segments, unchangedHistory.segments)
        assertEquals("Z2", recovery.paceZone)
        assertEquals(0, recovery.zoneIntensityMinPercent)
        assertEquals(20, recovery.zoneIntensityMaxPercent)
        assertEquals(2, recovery.durationMin)
        assertEquals(2.0, TrainingPrescriptionAudit.estimatedSegmentDistanceKm(pending.segments), 0.01)
        assertFalse(ZoneIntensityBandEngine.migrateUnfinishedWorkouts(migrated.workouts).changed)
    }

    @Test fun `Fartlek active Z2 recovery is slower than Z2 work after normalization`() {
        val snapshot = PaceCalibrationSnapshot(
            assessmentDateIso = "2026-11-01", distanceKm = 2.2, averagePaceMmSs = "5:27",
            estimatedVo2Max = 35.0, modelVersion = "TEST",
            zoneRanges = mapOf("Z2" to "7:30–8:30 min/km", "Z3" to "6:30–7:30 min/km")
        )
        val z2 = PaceRange(450, 510)
        val workBand = ActiveZoneBand(20, 65)
        val oldRecoveryBand = ActiveZoneBand(20, 65)
        fun segment(name: String, band: ActiveZoneBand, recoveryMode: String? = null) = WorkoutSegment(
            name = name, instruction = "Teste", durationMin = if (recoveryMode == null) 5 else 2,
            distanceKm = 0.5, paceZone = "Z2",
            targetPaceMinValue = ZoneIntensityBandEngine.activeRange(z2, band).fastestPaceValue,
            targetPaceMaxValue = ZoneIntensityBandEngine.activeRange(z2, band).slowestPaceValue,
            zoneBasePaceFastValue = z2.fastestPaceValue, zoneBasePaceSlowValue = z2.slowestPaceValue,
            zoneIntensityMinPercent = band.minPercent, zoneIntensityMaxPercent = band.maxPercent,
            recoveryMode = recoveryMode
        )
        val workout = Workout(
            date = "Hoje", title = "Fartlek F01", detail = "Teste", type = "Qualidade",
            objective = "Fartlek", stimulus = "FARTLEK_Z2_Z3:F01", distanceKm = 2.0,
            segments = listOf(segment("Fartlek aeróbio Z2", workBand),
                segment("Recuperação entre blocos Z2", oldRecoveryBand, "ACTIVE_Z2")),
            paceCalibrationSnapshot = snapshot
        )
        val normalized = ZoneIntensityBandEngine.apply(workout)
        val work = normalized.segments[0]
        val recovery = normalized.segments[1]
        assertEquals(20, work.zoneIntensityMinPercent)
        assertEquals(65, work.zoneIntensityMaxPercent)
        assertEquals(0, recovery.zoneIntensityMinPercent)
        assertEquals(20, recovery.zoneIntensityMaxPercent)
        assertEquals(2, recovery.durationMin)
        assertTrue(recovery.targetPaceMinValue!! > work.targetPaceMinValue!!)
        assertTrue(recovery.targetPaceMaxValue!! > work.targetPaceMaxValue!!)
    }

}
