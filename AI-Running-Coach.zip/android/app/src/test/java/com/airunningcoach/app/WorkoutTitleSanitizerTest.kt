package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Test

class WorkoutTitleSanitizerTest {
    @Test fun `remove codigos internos de titulos apresentados ao corredor`() {
        assertEquals("Fartlek leve", WorkoutTitleSanitizer.clean("FOR01 · Fartlek leve"))
        assertEquals("Intervalado", WorkoutTitleSanitizer.clean("INT05 ROD", "Intervalado"))
        assertEquals("Sessão específica", WorkoutTitleSanitizer.clean("I05 - Sessão específica"))
        assertEquals("Rodagem aeróbia", WorkoutTitleSanitizer.clean("ROD · Rodagem aeróbia"))
    }
}
