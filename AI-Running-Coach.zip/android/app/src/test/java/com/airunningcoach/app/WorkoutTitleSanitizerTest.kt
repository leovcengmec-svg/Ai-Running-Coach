package com.airunningcoach.app

import org.junit.Assert.assertEquals
import org.junit.Test

class WorkoutTitleSanitizerTest {
    @Test fun `remove codigos internos de titulos apresentados ao corredor`() {
        assertEquals("Fartlek leve", WorkoutTitleSanitizer.clean("FOR01 · Fartlek leve"))
        assertEquals("Intervalado", WorkoutTitleSanitizer.clean("INT05 ROD", "Intervalado"))
        assertEquals("Sessão específica", WorkoutTitleSanitizer.clean("I05 - Sessão específica"))
        assertEquals("Rodagem aeróbia", WorkoutTitleSanitizer.clean("ROD · Rodagem aeróbia"))
    }

    @Test fun `remove indice redundante depois da zona nos nomes dos blocos`() {
        assertEquals("Fartlek aeróbio Z2", WorkoutTitleSanitizer.clean("Fartlek aeróbio Z2 1"))
        assertEquals("Variação controlada Z3", WorkoutTitleSanitizer.clean("Variação controlada Z3 2"))
        assertEquals("Série 5 × 600 m", WorkoutTitleSanitizer.clean("Série 5 × 600 m"))
    }
}
