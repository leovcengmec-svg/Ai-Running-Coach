# AI Running Coach V61

Aplicativo Android de prescrição inteligente de corrida, com objetivos por distância, periodização, biblioteca de sessões, calibração de zonas, importação GPX/FIT/TCX, feedback e histórico local.

## Identificação
- `versionCode = 61`, `versionName = V61`.
- `engineVersion = 46`; sessões futuras usam o novo motor de prescrição, preservando ciclo, semana, histórico, treinos concluídos e feedbacks.
- Backup `schemaVersion = 2`; formato e validação mantidos.
- O pacote de entrega mantém o nome original `AI-Running-Coach.zip`.

## Objetivos e periodização
- Objetivos: milha, 3 km, 5 km, 10 km, 15 km, meia maratona, maratona, ultramaratona (50 km), saúde/qualidade de vida e distância personalizada de 1–100 km.
- Macrociclo: base, desenvolvimento, específico e recuperação. A fase orienta a escolha de sessões, sem substituir a avaliação de carga real.
- Somente prova A define o ciclo principal e aciona taper/recuperação pós-prova. Provas B/C substituem uma sessão na semana do evento sem desmontar o ciclo.

## Biblioteca e prescrição
- Sessões contínuas Z2, regenerativas Z1, progressivas/regressivas Z2–Z3, longões, tempo/limiar, fartlek, intervalados aeróbios Z2/Z2–Z3, intervalados mistos Z3–Z4/Z4–Z5, piramidal Z3–Z5, maratona e ultradistância.
- Recuperações de intervalados em Z2 confortável (0–20% da zona); Z1 fica para aquecimento, desaquecimento e sessões regenerativas.
- Z4/Z5 são referências operacionais estimadas a partir dos dados de campo, não confirmações laboratoriais de LT2 ou VO₂máx.
- Elegibilidade de limiar/VO₂ combina nível, frequência, volume, maior corrida recente, zonas e resposta de recuperação. Os critérios numéricos são guardrails conservadores de engenharia, não limites fisiológicos universais.
- Objetivo Saúde e Qualidade de Vida não gera qualidade intensa automaticamente e preserva a frequência selecionada.
- Subidas permanecem condicionais a percurso/elevação conhecida; strides são complementares; força é opcional e não é inserida automaticamente no calendário.

## Consistência e validação
- `TrainingPrescriptionAudit` verifica soma de segmentos, limites de pace e zona, nomes de segmentos, faixas ativas e recuperação.
- Teste de execução dos motores Kotlin: 8 objetivos × 8 semanas (256 sessões), frequências 2–6, eventos A/B/C, fartlek, intervalados mistos, objetivo Saúde e alternativas. Aprovado.
- Testes unitários adicionais foram incluídos no projeto; a execução completa via Gradle/JUnit deve ocorrer no CI.

## Compatibilidade e compilação
- Tela inicial com **Começar Novo Plano** e **Importar Backup** preservada.
- Importação GPX/FIT/TCX, calibração Z1–Z3, feedbacks, calendário e exportação preservados.
- Execute o workflow GitHub Actions `build-apk` para confirmar a compilação Android e gerar o APK. A compilação Android completa não foi executada neste ambiente.
- Ver `TRAINING_PRESCRIPTION_V61.md`, `TRAINING_PERIODIZATION_V61.md`, `TRAINING_GOALS_AND_RACES_V61.md` e `TRAINING_SAFETY_V61.md`.
