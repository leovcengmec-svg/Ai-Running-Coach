# AI Running Coach V96

## V96 — correções da auditoria V95

- `versionCode = 96` · `versionName = V96` · `CURRENT_ENGINE_VERSION = 86` · Backup Schema 11 (leitura compatível de schemas 1–10).
- Reteste futuro sem método pré-escolhido; no dia programado, o atleta escolhe Cooper 12 min ou 3 km, e a sessão é montada e persistida conforme o protocolo.
- Perfil protegido: volume semanal e maior corrida declarados não são substituídos pelo histórico importado; dados medidos aparecem separados e podem orientar a prescrição quando confiáveis.
- Calibração adaptativa exige revisão e confirmação; a atualização dos treinos futuros é uma segunda ação explícita e persistida.
- Testes de regressão adicionados para os três problemas da auditoria V95. A compilação Android/JUnit completa depende do GitHub Actions.

## V95 — revisão integral da biblioteca e exportação por blocos

- `versionCode = 95` · `versionName = V95` · `CURRENT_ENGINE_VERSION = 85` · Backup Schema 10 (leitura schemas 1–9).
- Regenerativo: iniciantes elegíveis usam Z1 em caminhada/corrida; corredores com mais de 11 meses de prática consistente usam Z2 0–20% nas transições e Z2 20–50% no bloco principal. Perfis com recuperação/consistência insuficiente permanecem conservadores sem Z1 automática.
- Longões contínuos: bandas do aquecimento/desaquecimento separadas da parte principal. Progressivos/regressivos com três etapas quando a dose permite.
- Strides: oito blocos explícitos, três acelerações de 10–15 s e duas recuperações individuais de 60–90 s.
- Intervalado 6 × 400 m: 14 passos executáveis no Pace Coach, incluindo aquecimento, preparação, seis intervalos, cinco recuperações e desaquecimento.
- Auditoria obrigatória bloqueia sessões inválidas antes da apresentação e exportação.
- `durationSeconds` é preservado em snapshots/backups e exportado para Pace Coach em milissegundos.

Consulte `V96_CORRECAO_AUDITORIA_V95.md`, `TEST_REPORT_V96.md` e `BUILD_STATUS_V96.md` para o pacote de correção atual. O histórico V95 permanece em `V95_BIBLIOTECA_REVISADA_E_PACE_COACH.md` e nos relatórios V95.
