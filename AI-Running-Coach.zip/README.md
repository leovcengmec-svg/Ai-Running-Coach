# AI Running Coach V100

## V100 — ciclo de oito semanas protegido e calendário compacto

- `versionCode = 100` · `versionName = V100` · `CURRENT_ENGINE_VERSION = 90` · Backup Schema 14 (leitura compatível de schemas 1–13).
- Ciclo persistido por identidade, âncora, duração e perfil congelado. Mudanças do perfil durante o ciclo ficam pendentes para o próximo; troca de motor não inicia novo plano.
- Semanas anteriores mantidas como histórico do backup; semana atual preservada integralmente; somente sessões de hoje em diante nas semanas futuras do mesmo ciclo podem ser atualizadas.
- Ciclo de oito semanas só pode ser encerrado após o período transcorrer e por ação explícita; início do próximo ciclo também é explícito.
- Backups antigos recuperam a âncora por data/número da semana; evidência ambígua preserva o plano e pede confirmação.
- Distribuição usa o motor real de sessões, mantém longão até 40%, piso de sessão para objetivo contínuo de 5 km e diferença de dominância quando viável. Exemplo 17 km: 6,8 + 5,1 + 5,1 km.
- Calendário mensal: células de 68 dp, grade 4/5/6 semanas, ícones vetoriais coloridos e códigos INI/REG/ROD/FAR/INT/LNG/PRV/TES; prova e treino no mesmo dia podem aparecer juntos.
- Harness Kotlin/JVM focado de calendário/distribuição e harness de ciclo passaram. Gradle/JUnit oficial, compilação Android e APK aguardam GitHub Actions.

Relatórios: `V100_CORRECAO_AUDITORIA_V99.md`, `TEST_REPORT_V100.md`, `BUILD_STATUS_V100.md` e `V100_PLANO_CORRECAO_AUDITORIA_V99.md`.

**Fonte Android compilada:** `android/app/src/main/java/com/airunningcoach/app/` (source set padrão Gradle). Os snapshots Kotlin soltos na raiz são legados e não fazem parte do source set compilado.

---

# AI Running Coach V99

## V99 — frequência futura e integridade do longão

- `versionCode = 99` · `versionName = V99` · `CURRENT_ENGINE_VERSION = 89` · Backup Schema 13 (leitura compatível de schemas 1–13).
- Treinos concluídos não contam como compromissos futuros; frequência usa datas distintas. Conflitos pendentes no mesmo dia continuam bloqueados.
- Semana atual parcial não aplica teto de 40% sobre sessões restantes se os dias da frequência não estiverem integralmente representados.
- Reteste futuro sem protocolo conta como compromisso, não como sessão inválida de 0 km; a participação do longão usa limite conservador até escolha Cooper/3 km.
- Semanas futuras completas continuam respeitando longão até 40% e dominância. Mensagens de bloqueio agora listam sessões/provas e a meta semanal disponível.
- `RaceEventEngine` verifica frequência por datas futuras distintas.
- 23 métodos de teste do calendário executados localmente com runner Kotlin e shim JUnit leve. Gradle/JUnit oficial e APK dependem do GitHub Actions.

Relatórios: `V99_CORRECAO_AUDITORIA_V98.md`, `TEST_REPORT_V99.md`, `BUILD_STATUS_V99.md` e `V99_PLANO_CORRECAO_AUDITORIA_V98.md`.

**Fonte Android compilada:** `android/app/src/main/java/com/airunningcoach/app/` (source set padrão Gradle). Os snapshots Kotlin soltos na raiz são legados e não fazem parte do source set compilado.

## V98 — backup fisiológico e histórico em card único

- `versionCode = 98` · `versionName = V98` · `CURRENT_ENGINE_VERSION = 88` · Backup Schema 13 (leitura compatível de schemas 1–12).
- Gerar/recalcular plano não salva nem recria teste fisiológico; usa a última avaliação ativa já salva e ignora rascunho vazio.
- Avaliações Cooper/3 km possuem identidade estável, edição, remoção reversível e restauração; registros removidos não entram nas referências fisiológicas.
- Reidratação de backups reconstrói zonas de 3 km pelo tempo do teste e protocolo correto; preserva faixas congeladas quando existentes.
- Histórico de treino apresenta um card expansível por sessão concluída com feedback associado, métricas reais e ações discretas no menu.
- Cadastro distingue base/maior sessão declaradas de referências automáticas do objetivo e histórico medido.
- Harness Kotlin/JVM isolado da gestão de avaliações: cinco cenários aprovados. Gradle/JUnit, compilação Compose e APK dependem do GitHub Actions.

Relatórios: `V98_CORRECAO_AUDITORIA_V97.md`, `TEST_REPORT_V98.md`, `BUILD_STATUS_V98.md` e `V98_PLANO_CORRECAO_AUDITORIA_V97.md`.

**Fonte Android compilada:** `android/app/src/main/java/com/airunningcoach/app/` (source set padrão Gradle). Os snapshots Kotlin soltos na raiz são legados e não fazem parte do source set compilado.

## V97 — preservação da carga, longão e calendário

- `versionCode = 97` · `versionName = V97` · motor 87 · Backup Schema 12.
- Feedback normal não reconstrói a semana; fonte de carga declarada protegida e adoção medida por confirmação; longão até 40% e piso de sessão para objetivo 5 km, com exceções explicitadas.
- Harness Kotlin/JVM focado da V97: 102 testes aprovados. Build Android oficial depende do GitHub Actions.
