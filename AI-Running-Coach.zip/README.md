# AI Running Coach V95

## V95 — revisão integral da biblioteca e exportação por blocos

- `versionCode = 95` · `versionName = V95` · `CURRENT_ENGINE_VERSION = 85` · Backup Schema 10 (leitura schemas 1–9).
- Regenerativo: iniciantes elegíveis usam Z1 em caminhada/corrida; corredores com mais de 11 meses de prática consistente usam Z2 0–20% nas transições e Z2 20–50% no bloco principal. Perfis com recuperação/consistência insuficiente permanecem conservadores sem Z1 automática.
- Longões contínuos: bandas do aquecimento/desaquecimento separadas da parte principal. Progressivos/regressivos com três etapas quando a dose permite.
- Strides: oito blocos explícitos, três acelerações de 10–15 s e duas recuperações individuais de 60–90 s.
- Intervalado 6 × 400 m: 14 passos executáveis no Pace Coach, incluindo aquecimento, preparação, seis intervalos, cinco recuperações e desaquecimento.
- Auditoria obrigatória bloqueia sessões inválidas antes da apresentação e exportação.
- `durationSeconds` é preservado em snapshots/backups e exportado para Pace Coach em milissegundos.

Consulte `V95_BIBLIOTECA_REVISADA_E_PACE_COACH.md`, `PLANO_V95_AUDITORIA_E_CORRECAO_BIBLIOTECA.md`, `TEST_REPORT_V95.md` e `BUILD_STATUS_V95.md`.
