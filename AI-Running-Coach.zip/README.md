# AI Running Coach V60

Aplicativo Android de prescrição inteligente de treinos de corrida, com planejamento adaptativo, calibração individual de zonas, importação de atividades, feedback e histórico local.

## Identificação
- `versionCode = 60`, `versionName = V60`.
- `engineVersion = 45`; planos V59 atualizam somente sessões futuras, preservando o ciclo, semanas anteriores, sessões concluídas e feedbacks.
- Backup `schemaVersion = 2`; formato e validação mantidos.
- O pacote de entrega mantém o nome original `AI-Running-Coach.zip`.

## Estrutura dos treinos
- A tela de sessão apresenta todos os blocos e a soma estimada das etapas.
- Segmentos prescritos por tempo também mostram a distância estimada total e, quando repetidos, a estimativa por repetição.
- Progressivos e regressivos usam Z2 confortável, Z2 mais rápida e Z3 controlada somente quando o atleta é elegível.
- Recuperações de fartlek e de intervalados usam Z2 0–20%, com duração calculada pelo pace médio da faixa ativa.
- Z1 fica reservada ao aquecimento/desaquecimento e a sessões regenerativas específicas.
- Corrida sustentada e bloco específico de maratona só incluem Z3 quando os critérios de experiência, carga recente, maior sessão e recuperação permitem.

## Compatibilidade
- Tela inicial com **Começar Novo Plano** e **Importar Backup**.
- Importação GPX/FIT/TCX, calibração Z1–Z3, feedbacks, calendário e exportação preservados.
- `engineVersion = 45` solicita a atualização do motor V60 sem reiniciar o ciclo nem alterar sessões concluídas.
- Ver `TRAINING_STRUCTURE_AUDIT_V60.md` para a auditoria técnica e os critérios de validação.
- Validação do motor: 110 testes JVM aprovados, sem falhas.

## Compilação Android
Execute pelo GitHub Actions o workflow `build-apk`. A compilação Android completa deve ser confirmada no CI.
