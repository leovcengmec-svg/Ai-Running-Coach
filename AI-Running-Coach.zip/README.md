# AI Running Coach V71

## V71 — Athlete Experience & GPX Intelligence 2.0

`versionCode = 71` • `versionName = V71` • `CURRENT_ENGINE_VERSION = 56` • Backup Schema 3 (`appVersion = V71`).

A V71 parte do código-fonte V70 e consolida, em uma única revisão, a reformulação do Perfil do Atleta e da tela Evolução, a unificação dos dados demográficos, a correção de datas reais de atividades e a análise de execução por bloco a partir de amostras GPX/FIT/TCX.

### Perfil do atleta e dados fisiológicos

- Perfil dividido em identificação, resumo, dados pessoais, avaliação fisiológica, objetivos, rotina/carga e gerenciamento.
- Avaliação de prontidão removida do meio das ações de gerenciamento do perfil.
- Data de nascimento passa a ser a fonte preferencial; a idade é calculada para hoje e para a data histórica de cada teste.
- Perfis V70 legados que só possuem idade continuam compatíveis: a idade cadastrada é reutilizada como fallback até que o atleta informe nascimento.
- Referência fisiológica é configurada no perfil e reutilizada nas avaliações seguintes; a migração recupera a referência do último teste quando disponível.
- A tela de perfil não pede idade atual, idade da avaliação e idade histórica em campos separados.

### Evolução

- Períodos de 7, 28 e 90 dias.
- Indicadores compactos, histórico recente, aderência planejado x realizado e barras de volume por dia/semana.
- Distribuição Z1–Z5 calculada apenas a partir de amostras temporizadas efetivamente disponíveis.
- Carga, ritmo, zonas e atividade recente permanecem acessíveis sem cards excessivamente altos.
- Elevação acumulada é exibida em metros.

### GPX/FIT/TCX e histórico

- Em GPX, o primeiro horário real dos pontos de trilha prevalece sobre o horário de exportação em `metadata`; metadata é fallback quando pontos não têm timestamp.
- TCX usa primeiro os horários dos Trackpoints, com Activity/Id e início da volta como fallback; FIT preserva o timestamp da sessão quando fornecido.
- Tracks/TrackSegments separados não são ligados por uma distância reta artificial nem usados para interpolar parciais atravessando pausas. Lacunas temporais e saltos são excluídos das amostras de ritmo.
- Cada amostra de ritmo persiste deslocamento temporal, distância inicial/percorrida, FC e cadência quando medidos.
- A tela Histórico mostra a data real da execução e, quando disponível, o horário local. A data planejada permanece como referência secundária.
- A análise de blocos cruza a sequência prescrita com as amostras temporais/distância para apresentar repetição, ritmo médio, tempo na zona, FC/cadência disponíveis, confiança e aderência à meta.
- Quando não há voltas explícitas, a divisão dos blocos é identificada como reconstrução estimada; métricas inexistentes não são inventadas.

### Backup e compatibilidade

- Backup Schema 3 inclui a data de nascimento e a estrutura enriquecida das amostras de atividade.
- Schemas 1 e 2 continuam aceitos; campos adicionados são opcionais para dados antigos.
- A V70 é preservada como base de migração. Atividades antigas sem o timestamp original confiável podem exigir reimportação do GPX original para recuperar a data/hora real, pois a cópia de backup não contém necessariamente os timestamps de todos os pontos.

### Validação

Os testes locais de domínio para prioridade do timestamp, continuidade entre segmentos GPX e comparação dos blocos foram compilados e executados com sucesso. A suíte Gradle/JUnit Android e os APKs Debug/Release ainda precisam ser executados no GitHub Actions: o pacote não possui Gradle Wrapper e este ambiente não tem Gradle/Android SDK instalados. A importação real de arquivos de relógio e a execução no Pace Coach permanecem testes de aparelho.

## Estrutura do projeto

- `android/`: aplicativo Android Kotlin/Jetpack Compose e testes unitários.
- `design/`: identidade visual e recursos do aplicativo.
- `CHANGELOG.md`: histórico de versões.
- `README_GITHUB_ANDROID.md`: instruções de build no GitHub Actions.
