# AI Running Coach V72

## Adaptive Training Intelligence 4.0

`versionCode = 72` • `versionName = V72` • `CURRENT_ENGINE_VERSION = 57` • Backup Schema 3 (`appVersion = V72`).

A V72 é uma atualização integrada sobre a V71. Reorganiza a biblioteca, reforça a periodização por distância/nível/prioridade e corrige a coerência entre nome e dose dos treinos. Também corrige o calendário para atividades concluídas na data real, padroniza os cards de perfil, melhora as ações de backup e mantém a análise GPX por blocos.

## Metodologia sem sensor cardíaco

O aplicativo funciona com celular/GPS, sem cinta peitoral, relógio com sensor cardíaco ou acessório obrigatório. Todas as zonas e prescrições usam pace individualizado, distância, duração, testes de corrida, desempenho recente e percepção de esforço/teste da fala.

- Não há zonas por FC/FCM.
- FC não é requisito de cadastro, teste, calibração, prescrição, carga, análise de bloco ou evolução.
- Novas importações GPX/FIT/TCX ignoram completamente os campos cardíacos. Valores já presentes em backups antigos podem permanecer armazenados somente para compatibilidade histórica; não são exibidos nem consumidos por motores de treinamento.

## Biblioteca e protocolos

- Camada de tipos de sessão: Rodagem, Longão, qualidade, caminhada/corrida e preparação/recuperação.
- Camada de protocolos: estímulos por distância ou duração, repetições e recuperação tipados.
- Camada de periodização: seleção conforme distância, nível, prioridade, fase, volume, maior sessão, consistência, disponibilidade e recuperação percebida.
- Protocolos tipados incluem I05 (6 × 400 m), I06 (4 × 800 m), I07 (5 × 600 m), I08 (5 × 800 m), I09 (3 × 1.000 m), I10 (3 × 1.600 m), além de estímulos por tempo e blocos de ritmo específico.
- A validação confere dose e recuperação. Se um protocolo nomeado não couber no orçamento seguro da sessão, o motor substitui por sessão aeróbia e remove o nome incompatível; nunca converte silenciosamente distância em tempo.
- A nomenclatura visível usa o tipo e objetivo da sessão (por exemplo, Rodagem progressiva, Longão contínuo, Intervalado 5 × 600 m). Códigos técnicos não aparecem nos títulos.

## Referências de planejamento fornecidas

A biblioteca e os defaults de periodização foram informados pelas planilhas O2 Corre de 5 km/10 km, BR Corrida 5K/10K Sem Parar, 5K Sub 30 e programas Nike Run Club de meia maratona (14 semanas) e maratona (18 semanas). São referências para estrutura, variedade e progressão; não são cópias rígidas.

- 5 km/10 km têm percursos distintos para iniciantes, intermediários e avançados.
- 5K Sem Parar usa progressão caminhada/trote por 12 semanas.
- 5K Sub 30 utiliza ritmos de referência e retestes para recalibração.
- 10K Sem Parar combina resistência, blocos por distância e retestes durante o ciclo.
- Meia e maratona combinam velocidade, resistência, recuperação e longões; a maratona inclui maior volume específico e taper.
- Os anexos não contêm um plano exclusivo de 15 km. Essa distância é uma ponte metodológica própria do aplicativo entre 10 km e meia maratona, identificada como tal.
- Tabelas de FC/FCM dos anexos foram deliberadamente excluídas conforme requisito do produto.

## Calendário, histórico e backup

- Treino concluído com atividade vinculada aparece no calendário pela data real de execução; a data planejada é mantida como referência secundária.
- Sessões futuras continuam na data planejada.
- Backup Schema 3 mantido. A V72 grava `appVersion = V72` e lê schemas 1–3; backups V71/schema 3 continuam compatíveis.
- Importação seletiva continua mesclando atividades concluídas sem substituir perfil/plano; restauração completa continua substituindo o estado local após confirmação.

## GPX/FIT/TCX e análise de blocos

- A data real prioriza timestamps dos pontos de atividade, usando metadata como fallback.
- Segmentos GPS separados não criam distância artificial entre trilhas.
- A análise compara blocos prescritos e executados usando tempo, distância, pace, zonas de ritmo e cadência quando disponível.
- Lacunas ou dados insuficientes são identificados; a segmentação reconstruída é marcada como estimativa.

## Validação e limitações

- Motores de domínio Kotlin/JVM compilados localmente com `kotlinc`.
- Harness específico validou o I07 como cinco repetições exatas de 600 m, quatro recuperações de dois minutos e preservação do modo DISTANCE.
- Foram adicionados testes de catálogo, dose, recuperação, progressão caminhada/trote, periodização 15 km e compatibilidade de backup V71.
- Build Android, suíte Gradle/JUnit completa, APK Debug/Release, teste em aparelho e importação real no Pace Coach ainda exigem GitHub Actions/Android SDK e validação em dispositivo. Não são declarados aprovados neste pacote local.
