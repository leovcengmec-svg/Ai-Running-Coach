# V55 — importação RunnerUp, calendário equilibrado e variedade aeróbia

- `versionCode = 55`, `versionName = V55`, `engineVersion = 42`.
- Migração de backup recupera a âncora original cruzando datas e números de semana, mantém a numeração e regenera somente sessões de hoje e datas futuras; sessões passadas ausentes no arquivo nunca são inventadas. A interface calcula a semana em andamento pela data atual contra a âncora original; o Plano abre a semana corrente e mantém as semanas anteriores visíveis.
- Schema 2 do backup usa SHA-256 e manifesto de contagens; backups schema 1 permanecem compatíveis.
- Treinos extras passam a ser apresentados com riscos em vez de serem bloqueados por sessão pendente, limite semanal, treino próximo, dor ou fadiga. A inclusão é uma decisão explícita do corredor; a programação original permanece intocada.
- Datas futuras distantes permanecem disponíveis com aviso de menor precisão; somente datas passadas não podem receber sessões novas.

## Funcionalidades mantidas da V53/V52
- Importa GPX, FIT e TCX no feedback de cada sessão e não inventa métricas ausentes.
- Preserva metadados e dados da atividade, feedback subjetivo e proteção contra duplicatas.
- Calibra Z1 por sessões regenerativas, Z2 pelo teste da fala e Z3 por testes Cooper independentes, com avanço máximo de 15 s por fronteira a cada atualização.

## V51 — cartões responsivos e layout de competições padronizado

- Tela de competições: resumo de métricas com hierarquia vertical, rótulos em múltiplas linhas, campos de formulário com larguras equivalentes, prioridades A/B/C em cartões padronizados e cartões de provas com nome/dados/notas quebrando linha sem truncamento.
- Pílulas de estado centralizadas e compatíveis com duas linhas; nomes, locais e observações são exibidos integralmente.
- Atualização exclusivamente visual: regras de competição, plano, calendário, prescrição, backup e motor esportivo da V50 permanecem inalterados.
- `versionCode = 51`, `versionName = V51`, `engineVersion = 38`; backup identifica `appVersion` V51.

## Regras de unidades
- Distâncias: somente km.
- Pace: somente `mm:ss min/km`.
- Tempo decorrido: `mm:ss` ou `hh:mm:ss`.
- A UI e o contrato não exibem pace como segundos/km nem distância como metros.

## Cooper e zonas
O Teste de Cooper de 12 min fornece a velocidade média de referência e uma estimativa indireta de VO₂máx (não laboratorial). Z1–Z4 começam com faixas operacionais derivadas da velocidade média do Cooper: Z1 60–70%, Z2 70–80%, Z3 80–90% e Z4 90–100%; a Z2 pode ser refinada pelo teste da fala. Z5 usa a VAM estimada apenas como referência auxiliar para o limite rápido quando a regressão é plausível; caso contrário, mantém a banda conservadora do Cooper. Portanto, as cinco zonas não devem ser interpretadas como percentuais de VO₂máx nem como limiares medidos.

VAM e segundo limiar estimados por regressões permanecem informações auxiliares de campo; não são tratados como medidas laboratoriais nem como substitutos de avaliação fisiológica individual.

A V52 calibra Z1, Z2 e Z3 de forma independente e baseada em evidências: Z1 exige três sessões regenerativas recentes, confortáveis e sem dor; Z2 exige três observações válidas e consistentes do teste da fala; Z3 exige dois testes Cooper separados por pelo menos 14 dias, com variação máxima de 8%. O pace observado precisa caber na faixa correspondente; dados em transição ficam em `REVIEW` e as fronteiras avançam até 15 segundos por atualização. As cinco zonas continuam contíguas e o treinador não converte rodagem comum em prova/teste fisiológico.

A calibração considera até 42 dias de feedback para Z1/Z2. Dor bloqueia a progressão automática e é excluída da evidência. Consulte `PACE_ZONE_METHODOLOGY_V52.md` para os critérios completos, formatos de arquivo e limitações; `PACE_ZONE_METHODOLOGY_V26.md` permanece como histórico metodológico anterior.

## Tipos de treino
O motor estrutura rodagem regenerativa, rodagem aeróbia, longão, moderado, tempo run, intervalos controlados em Z4 estimada, intervalos de alta intensidade em Z5 estimada, fartlek, resistência específica de maratona, strides, corrida progressiva e corrida/caminhada para iniciantes ou reentrada. Repetições em subida aparecem como item informativo da biblioteca, mas ainda não são geradas automaticamente. RPE permanece como orientação complementar; os alvos são tempo/distância e pace `mm:ss min/km` quando calibrado.

## Competições e calendário (V27)
- Cadastro local de provas com nome, distância em km, data, prioridade A/B/C, tempo-alvo opcional, local e observações.
- A prioridade A (ou B quando não houver A futura) define a competição que orienta o próximo ciclo e fornece a distância específica do objetivo do motor.
- O plano é ancorado na segunda-feira da semana atual. Quando é gerado no meio da semana, sessões já passadas não são repostas nem comprimidas nos dias restantes; os treinos futuros permanecem na semana correta. Se a prova estiver no horizonte de até 16 semanas, o ciclo inclui a semana da competição e, quando couber, uma semana posterior de recuperação.
- Cada prova planejada dentro do ciclo substitui uma sessão de corrida naquela semana. Em provas de fim de semana, o longão é a sessão preferencial para substituição; em outros dias, é escolhida a sessão mais próxima.
- Provas A/B acionam redução de carga pré-prova (taper) e sessões de recuperação pós-prova. Os parâmetros são heurísticas conservadoras e precisam de validação em uso real; não substituem avaliação individual.
- Calendário mensal, semanal e detalhamento por dia mostram sessões e competições separadamente.
- Mudanças em provas após a geração do plano solicitam recálculo explícito; treinos concluídos são preservados.
- Eventos fora do horizonte atual permanecem no calendário. O ciclo atual cobre até 16 semanas; o próximo bloco deve ser gerado quando a competição entrar no horizonte. Provas distantes não alteram antecipadamente a distância-alvo do bloco-base atual.

## Pace Coach
Exportação de treinos no envelope nativo `com.garmin.connect.workout.json.UserWorkoutJson`, igual ao modelo de arquivo exportado pelo Pace Coach. Cada etapa é serializada como tempo em milissegundos ou distância em metros; alvos de pace são convertidos para `centimetersPerMillisecond`; repetições são representadas por grupos `repeat` com etapas filhas. Competições continuam gerenciadas no AI Running Coach e não são enviadas como sessões.

## Build Android
1. Envie o conteúdo desta pasta para a raiz do repositório.
2. Abra Actions → Android APK.
3. Execute `workflow_dispatch` ou envie um commit para `main`.
4. Confirme `:app:testDebugUnitTest` e `:app:assembleDebug`.
5. Baixe o artefato `ai-running-coach-debug-apk`.

## Versão
V52 (`versionCode = 52`, `versionName = V52`, `engineVersion = 39`). Adiciona importação GPX/FIT/TCX e calibração individual Z1–Z3, mantendo o layout responsivo e histórico da V51. V46 (`versionCode = 46`, `versionName = V46`, `engineVersion = 36`) consolida a persistência de feedback subjetivo sem exigir métricas físicas, a exibição completa desses registros no histórico, a calibração progressiva e explícita da Z2 pelo teste da fala e as faixas percentuais ativas por sessão. O backup identifica o aplicativo como V46. Nome fixo do ZIP: `AI-Running-Coach.zip`.


## V29 — Disponibilidade e reagendamento
- O atleta seleciona seus dias habituais de corrida (2 a 6) e o dia preferido do longão.
- A frequência semanal passa a ser derivada dos dias selecionados; o motor distribui as sessões exatamente nesses dias.
- A agenda permite reagendar uma sessão não concluída para um dia livre da mesma semana, inclusive como exceção à disponibilidade habitual.
- O reagendamento valida colisões, provas, sessões concluídas e intervalo de recuperação entre sessões exigentes.
- A sessão preserva identidade, distância, pace e blocos; a data original fica registrada.
- Calendário mensal e agenda diária/semanal diferenciam regenerativo, aeróbio, moderado, progressivo, qualidade/limiar, intervalado, fartlek, longão e competição.

### V29 — Agenda do atleta
A V29 permite selecionar de 2 a 6 dias habituais de corrida, escolher o dia preferido do longão e reagendar uma sessão não concluída para outro dia livre dentro da mesma semana. O calendário identifica visualmente modalidades de treino. A seleção de dias é persistida localmente; mudanças de disponibilidade solicitam recálculo para redistribuir as sessões futuras.


## V30 — Duas opções por sessão
- Cada sessão futura e não concluída apresenta a opção principal recomendada e uma alternativa compatível com o objetivo geral do dia.
- A alternativa substitui a principal; nunca é somada ao volume semanal como sessão extra.
- A seleção fica salva por sessão e é preservada ao reabrir o aplicativo.
- A alternativa de qualidade troca repetições intensas por um bloco contínuo moderado em Z3; longões oferecem formato contínuo confortável; sessões fáceis oferecem formato corrida-caminhada.
- Distância total e duração estimada da sessão permanecem iguais às da prescrição principal. O pace da alternativa moderada usa a faixa Z3 da calibração quando disponível.
- Sessões concluídas não podem trocar de opção. Provas não recebem opção alternativa.
- As opções são estimadas por regras locais derivadas da sessão principal; não são duas prescrições independentes otimizadas por um segundo ciclo do motor.


## V31 — Tela de sessão simplificada
- Exibe somente o treino ativo e oferece um botão compacto para consultar/trocar a alternativa.
- Remove o resumo redundante; objetivo e estrutura permanecem em áreas distintas e mais espaçadas.
- A escolha entre principal e alternativa é confirmada em uma janela compacta e persiste por sessão.
- Alternativas atualizam os paces de cada bloco conforme a zona correta do snapshot, sem inventar valores quando falta calibração.
- A seleção continua refletida no calendário e na exportação para Pace Coach.

## Identidade visual V38
Ícone minimalista com fundo azul-marinho, corredor branco e arco ciano; sem textos ou pictogramas acessórios no launcher.


## Correção de agenda V39

O plano inclui a semana corrente de segunda a domingo mesmo quando a geração ocorre depois de segunda-feira. Sessões que já passaram não são repostas nem comprimidas nos dias restantes. A semana parcial atual aparece como “Semana em andamento”; a próxima semana completa passa a ser semana 1. Competições já ocorridas não alteram a prescrição futura.


V42 (`versionCode = 42`, `versionName = V42`) corrige o cálculo de tempo estimado somando todas as etapas conforme o modo de alvo: tempo explícito para segmentos TIME e pace × distância para segmentos DISTANCE, incluindo repetições. Planos V41 salvos e sessões ajustadas para provas são corrigidos com a mesma regra de blocos. O rótulo da interface passa a ser “Tempo estimado”. O botão Voltar do Android retorna à tela anterior usando histórico de navegação e rotas de fallback para telas restauradas. ZIP canônico: `AI-Running-Coach.zip`.


V43 (`versionCode = 43`, `versionName = V43`) calcula a duração total de toda sessão somando cada etapa segundo seu modo real de execução, sem piso artificial de 15 minutos: etapas por tempo usam sua duração explícita e etapas por distância usam o pace-alvo médio (ou referência aproximada identificada quando não há calibração). A tela apresenta `Tempo estimado` com unidade `min`. O botão Voltar do Android percorre o histórico de navegação e usa rota-pai para telas restauradas. `engineVersion = 35`. ZIP canônico: `AI-Running-Coach.zip`.
