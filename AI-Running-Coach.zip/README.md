# AI Running Coach V70

## V70 — Training Intelligence 3.1

`versionCode = 70` • `versionName = V70` • `engineVersion = 55` • Backup Schema 2.

A V70 consolida as correções da auditoria da V69: restauração integral separada da importação seletiva de treinos concluídos; progressão de volume com deload que não rebaixa a referência de construção; progressão planejada do longão por semana, com limite por distância-alvo e bloqueio por prontidão; prioridade de plano com registro de recorde pessoal atual ou tempo-alvo; remoção de códigos técnicos dos títulos; correção da hierarquia de grupos e da unidade de distância no exportador Garmin/Pace Coach; idade atual centralizada no perfil, sem confundir com a idade histórica do teste.

### Regras importantes

- O backup completo continua substituindo o estado local após validação de integridade. A importação seletiva mescla apenas sessões concluídas e feedbacks/atividades correspondentes, ignora duplicados e preserva perfil e plano atuais.
- A semana regenerativa reduz temporariamente a exposição; a trajetória de construção é mantida para a semana seguinte. A faixa de referência por objetivo é uma direção gradual, não uma carga obrigatória.
- O longão tem um limite planejado progressivo, mas a evolução depende de ausência de dor e de prontidão adequada. A resposta real do atleta continua sendo um limite de segurança.
- Os códigos internos (FOR01, INT05, I05, ROD e similares) permanecem disponíveis como metadados de motor quando necessários, mas não aparecem nos títulos apresentados ao atleta nem no nome exportado do treino.
- Intervalos repetidos são mantidos em um único grupo lógico: aquecimento → repetir intervalo/recuperação → desaquecimento. Cada etapa possui seu próprio identificador e referência ao grupo pai; etapas isoladas não recebem `parentGroupId`.
- A idade atual é cadastrada na primeira tela e editada no perfil. A idade na data de um teste é mantida como fotografia histórica; ao completar um teste antigo, é solicitada separadamente.

### Estrutura do projeto

- `android/`: aplicativo Android Kotlin/Jetpack Compose e testes unitários.
- `design/`: identidade visual e recursos do aplicativo.
- `CHANGELOG.md`: histórico de versões.
- `README_GITHUB_ANDROID.md`: instruções de build no GitHub Actions.

### Validação

O pacote-fonte foi atualizado e inspecionado. Os testes Gradle/JUnit e o APK Android devem ser executados no GitHub Actions: esta revisão de origem não contém Gradle Wrapper e o ambiente local desta edição não possui Gradle/Android SDK instalados. Não considerar build ou importação em aparelho aprovados até esses testes terminarem.
