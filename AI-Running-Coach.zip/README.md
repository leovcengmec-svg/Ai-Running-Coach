# AI Running Coach V97

## V97 — preservação da carga, longão e calendário

- `versionCode = 97` · `versionName = V97` · `CURRENT_ENGINE_VERSION = 87` · Backup Schema 12 (leitura compatível de schemas 1–12).
- Feedback comum não reconstrói a semana. Uma revisão explícita preserva as sessões incompletas da semana em andamento; a migração inicial da V96 pode normalizar uma vez os conflitos antigos.
- Histórico não substitui a base cadastrada com seis atividades em três semanas. Exige quatro semanas completas confirmadas e autorização explícita; os valores confirmados ficam salvos e só valem no próximo bloco.
- Longão limitado a 40% do volume semanal incluindo provas. Diferença de 0,8 km e 15% priorizada quando possível.
- Objetivo 5 km: cada sessão completa regular em semana normal tem pelo menos 5 km. Exceções: semana Regenerativa e protocolo inicial caminhada/corrida ativo. Exemplo de 16 km em três dias: 6 + 5 + 5 km.
- Prova preparatória curta não elimina longão maior. Validação final bloqueia duplicidades, colisões, excesso de frequência e violação do teto de 40%.
- Harness Kotlin/JVM focado: 102 testes aprovados. Build Android/Compose, Gradle/JUnit oficial e APK dependem do GitHub Actions.

Relatórios: `V97_CORRECAO_AUDITORIA_V96.md`, `TEST_REPORT_V97.md`, `BUILD_STATUS_V97.md` e `V97_PLANO_CORRECAO_LONGAO_AUDITORIA_V96.md`.

**Fonte Android compilada:** `android/app/src/main/java/com/airunningcoach/app/` (source set padrão do Gradle). Os arquivos Kotlin soltos na raiz são snapshots legados e não fazem parte do source set do módulo Android.

## V95 — revisão integral da biblioteca e exportação por blocos

- `versionCode = 95` · `versionName = V95` · `CURRENT_ENGINE_VERSION = 85` · Backup Schema 10 (leitura schemas 1–9).
- Regenerativo: iniciantes elegíveis usam Z1 em caminhada/corrida; corredores com mais de 11 meses de prática consistente usam Z2 0–20% nas transições e Z2 20–50% no bloco principal. Perfis com recuperação/consistência insuficiente permanecem conservadores sem Z1 automática.
- Longões contínuos: bandas do aquecimento/desaquecimento separadas da parte principal. Progressivos/regressivos com três etapas quando a dose permite.
- Strides: oito blocos explícitos, três acelerações de 10–15 s e duas recuperações individuais de 60–90 s.
- Intervalado 6 × 400 m: 14 passos executáveis no Pace Coach, incluindo aquecimento, preparação, seis intervalos, cinco recuperações e desaquecimento.
- Auditoria obrigatória bloqueia sessões inválidas antes da apresentação e exportação.
- `durationSeconds` é preservado em snapshots/backups e exportado para Pace Coach em milissegundos.

Consulte `V96_CORRECAO_AUDITORIA_V95.md`, `TEST_REPORT_V96.md` e `BUILD_STATUS_V96.md` para o pacote de correção atual. O histórico V95 permanece em `V95_BIBLIOTECA_REVISADA_E_PACE_COACH.md` e nos relatórios V95.
