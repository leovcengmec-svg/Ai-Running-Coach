# AI Running Coach V85

## Exportação Pace Coach corrigida, variedade de biblioteca e evolução do volume planejado

`versionCode = 85` • `versionName = V85` • `CURRENT_ENGINE_VERSION = 74` • Backup Schema 4 (lê schemas 1–4; compatível com V80 e anteriores).

A V85 corrige a consistência da meta de volume semanal, comparando treinos e provas na mesma base usada pelo total e pelo gráfico. A V81 corrige a conversão de distância no JSON do Pace Coach (1 km = 1.000 m), valida os alvos e condições de término, preserva ritmo em recuperações ativas e restaura o gráfico de volume semanal previsto na tela Plano. A revisão corretiva também separa tempo total de tempo em movimento no cálculo do pace, aplica redução real de carga diante de prontidão POOR/YELLOW, usa as zonas Cooper calculadas nas flags e ajusta a seleção F01/F04 e I05. A revisão de calendário/backup atualiza a âncora da primeira semana treinável e protege a identidade das sessões históricas, com `CURRENT_ENGINE_VERSION = 73`. A V83 corrige a falha de compilação Kotlin da proteção de reagendamentos: a data original agora faz parte de `PrescribedWorkout` e é preservada pela migração e pelo ajuste de provas. A V84 valida recuperações ativas contra a faixa real do desaquecimento, converte incompatibilidades em caminhada sem pace artificial e controla o cursor dos campos de data no fim da máscara. Consulte `BUILD_STATUS_V85.md`, `BUILD_STATUS_V84.md`, `BUILD_STATUS_V83.md`, `PACE_COACH_EXPORT_CONTRACT_V81.md`, `TRAINING_LIBRARY_VARIATION_V81.md`, `CORRECTION_REPORT_V81.md` e `CORRECTION_REPORT_V82_CALENDAR_BACKUP.md`.

A V78 substitui a análise automática de blocos inferida por GPX e a calibração isolada da Z2 por feedback manual de cada bloco prescrito. O corredor informa o pace executado em cada repetição; o app preserva a meta original, compara mais rápido/dentro/mais lento e acumula evidências por zona Z1–Z5 sem alterar limites automaticamente com base em poucos dados.

A V79 introduziu máscaras automáticas para data/ritmo/tempo/distância, cálculo centralizado de métricas, parciais GPX que preservam a distância declarada, distribuição semanal em incrementos de 0,1 km, revisão assistida das zonas e uma tela exclusiva de estratégia de prova. A V80 revisa a intensidade das recuperações em toda a biblioteca, corrige a distribuição do tempo nas zonas, normaliza atividades em quilômetros acumulados + parcial final, melhora o fluxo de revisão e permite exportar a estratégia de prova para Pace Coach.

Os ritmos não são inventados quando faltam zonas ou evidências; alvos agressivos não substituem a capacidade demonstrada. A estratégia e as projeções são referências estimadas, não garantias de resultado.


## V81 — Pace Coach Export Integrity & Training Variation

- Distâncias enviadas em metros reais; 1 km = 1.000 m, sem escala ×100.
- Validação de duração, distância e faixa de ritmo; recuperação ativa preserva ritmo quando prescrito.
- Seleção determinística de F01/F04 condicionada à intenção e ao feedback de prontidão; F04 só libera Z4 com elegibilidade de limiar.
- Gráfico de evolução do volume semanal planejado na tela Plano.
- Estratégia de prova e treinos usam o mesmo exportador.


## V80 — Recovery Intelligence, Activity Splits & Race Export

- Fartlek aeróbio F01 recupera na parte superior da Z1 (90–100% da faixa operacional), com RPE leve e gatilho de retorno pela respiração controlada. Recuperações aeróbias Z2 usam 0–30% da Z2. Recuperações Z4 permanecem como caminhada nos protocolos explícitos e Z5 como pausa passiva; a duração prescrita não é reduzida automaticamente.
- Biblioteca e alternativas revisadas para que o modo de recuperação corresponda à intensidade do bloco, sem converter pausas passivas/caminhadas em corrida nem impor uma recuperação única a todos os estímulos.
- Removidos sufixos numéricos redundantes dos títulos de estágios repetidos. A ordem e a identidade das repetições continuam preservadas internamente.
- `ActivityZoneTimeEngine` inclui voltas explícitas e parciais agregadas de vários minutos na distribuição Z1–Z5; amostras GPS brutas continuam limitadas a 120 s para não preencher lacunas temporais longas.
- `ActivityFileImporter` reconstrói parciais acumuladas de 1 km e trecho final fracionado. Voltas irregulares são rateadas proporcionalmente quando cruzam limites de quilômetro e identificadas como reconstruídas. Cobertura/tempo insuficiente permanece desconhecida, sem fabricar pace.
- Revisão assistida Z1–Z5 abre o formulário de teste devidamente inicializado. “Manter e observar” registra a decisão e preserva as zonas; nenhuma faixa é alterada apenas pela sugestão.
- Estratégia de prova exportável pelo contrato nativo `UserWorkoutJson` do Pace Coach, incluindo aquecimento, fases de execução sustentadas por evidência e desaquecimento. Metas sem suporte não são inventadas.
- Nomes de exportação semanal seguem exatamente `S{semana}_T{treino}_{Título}`, sem data: por exemplo `S1_T1_Rodagem Progressiva`, `S1_T2_Longão`, `S2_T1_Rodagem Progressiva Z2 Z3`.
- Perfil mantém o gerenciamento esportivo sem atalho de exportação de sessão. Backup Schema 4, leitura de schemas 1–4, `versionCode = 80`, `versionName = V80`, `CURRENT_ENGINE_VERSION = 70`; sem dependência de FC/FCM.
- Validação Kotlin/JVM isolada: compilação dos motores de domínio e 12 verificações integradas de recuperação, títulos, distribuição de intensidade, GPX 6,62 km, nomes de exportação e estratégia. Build Android/Compose e suíte Gradle oficiais ainda precisam ser confirmados no GitHub Actions.

## V78 — Block-by-Block Feedback & Zone Execution Intelligence

- Faixas ativas de qualquer largura válida entre 0% e 100% dentro da zona; 0% é o limite mais lento e 100% o mais rápido. A escala não representa percentual de VO₂máx nem FC.
- Corredores com seis meses ou mais de experiência recebem aquecimento e desaquecimento em Z2 0–20%, calculados pela calibração individual.
- Recuperação passiva é cronometrada e não possui pace/distância; caminhada não recebe pace; recuperação ativa usa Z2 0–20%.
- Alternativas preservam o estímulo original e a dose quando a prontidão permite; progressões conservam a sequência de etapas. Redução de qualidade ocorre apenas diante de sinais de recuperação/saúde insuficientes.
- Restauração completa do backup oferece recalibração pelo motor atual ou manutenção do plano importado; a recalibração preserva sessões concluídas, feedbacks, atividades e datas reais.
- `versionCode = 78`, `versionName = V78`, `CURRENT_ENGINE_VERSION = 68`; Backup Schema 3 e leitura dos schemas 1–3 preservados.
- Reagendamentos manuais são reaplicados por identidade antes da regeneração e protegidos contra substituição silenciosa por prova.
- Provas futuras exibem orientação por distância, prioridade A/B/C e prioridade do atleta.
- Prontidão temporária altera a sessão/semana próxima, sem apagar a periodização futura.
- Ritmo médio previsto usa média ponderada de todos os segmentos com pace; ritmo real usa feedback registrado.
- Sem dependência de FC/FCM.

Documentação técnica adicional: `BUILD_STATUS_V78.md`, `TRAINING_BLOCK_FEEDBACK_V78.md`, `RACE_DAY_GUIDE_V77.md` e `SCHEDULE_INTEGRITY_V77.md`.

## Bases fixas por objetivo

| Objetivo | Base semanal | Teto de construção | Capacidade contínua presumida anterior | Frequência de referência |
|---|---:|---:|---:|---:|
| Milha (1,61 km) | 8 km | 15 km | 0,8 km | 2 dias |
| 3 km | 8 km | 16 km | 1,6 km | 3 dias |
| 5 km | 12 km | 22,5 km | 3 km | 3 dias |
| 10 km | 15 km | 27,5 km | 5 km | 4 dias |
| 15 km | 25 km | 43 km | 10 km | 4 dias |
| 10 milhas (16,1 km) | 25 km | 43 km | 10 km | 4 dias |
| 20 km | 28 km | 48 km | 16,1 km | 4 dias |
| Meia maratona (21,1 km) | 30 km | 51 km | 16,1 km | 4 dias |
| 25 km | 35 km | 60 km | 21,1 km | 4 dias |
| 30 km | 40 km | 70 km | 21,1 km | 4 dias |
| Maratona (42,2 km) | 45 km | 80 km | 21,1 km | 4 dias |
| 50 km | 55 km | 100 km | 42,2 km | 5 dias |
| 100 km | 75 km | 140 km | 50 km | 5 dias |
| 100 milhas (160,9 km) | 90 km | 160 km | 100 km | 6 dias |

Bases e tetos são parâmetros internos de planejamento. Para distâncias personalizadas, o catálogo interpola os pontos de referência adjacentes. Saúde e qualidade de vida usa uma referência separada de 8 km/semana, teto de 16 km e 2 dias.

## Como os dados do cadastro entram no motor

- Média de quatro semanas vazia: utiliza o KM-base do objetivo.
- Maior percurso recente vazio: utiliza a capacidade contínua anterior presumida do objetivo.
- Dados positivos preenchidos substituem a referência correspondente.
- Zero digitado é declaração explícita de ausência de corrida recente; não é tratado como campo vazio.
- Quando os dados reais são incompatíveis entre si, a prontidão continua sinalizando a divergência; objetivo selecionado não apaga evidência de carga real muito baixa.

Exemplos: maratona sem os dois campos preenchidos inicia com referência semanal de 45 km e capacidade contínua anterior presumida de 21,1 km; meia maratona utiliza 30 km e presume 16,1 km; 10 km utiliza 15 km e presume 5 km.

## Caminhada/corrida

- A sessão completa de caminhada/corrida fica habilitada somente para iniciante real com declaração explícita de ausência de corrida recente e objetivo de até 5,5 km. Um retorno pós-lesão não é inferido de dor, histórico ausente ou VO₂máx: exige fluxo de retorno específico e avaliação apropriada, ainda não habilitado nesta versão.
- VO₂máx/nível fisiológico iniciante, falta de GPX ou campos em branco não habilitam caminhada/corrida.
- Uma evidência de 5 km contínuos bloqueia esse formato no cadastro e também no motor de prescrição, mesmo que uma flag antiga/externa venha ligada.
- Para corredores contínuos, alternativas leves e sessões extras permanecem corrida contínua; caminhadas pontuais ainda podem compor uma recuperação de intervalo quando prescritas como tal.

## Prioridades

| Prioridade | Estrutura predominante |
|---|---|
| Completar distância | Longão contínuo em Z2; rodagens fáceis e volume consistente; qualidade só quando elegível. |
| Correr continuamente | Progressões/regressões de corrida sustentada e foco em prolongar o tempo contínuo sem pausas planejadas. |
| Melhorar recorde pessoal | Acelerações, progressões, limiar/intervalos quando elegíveis e longões com final controlado quando há prontidão. |
| Alcançar tempo definido | Blocos orientados ao ritmo-alvo, progressões/regressões específicas e validação da viabilidade temporal. |

A prioridade também altera a distribuição interna entre longão, qualidade e rodagens. Quando os requisitos para uma sessão de qualidade ainda não existem, a estratégia de base continua diferente por prioridade sem liberar intensidade alta prematuramente. Alterar prioridade, objetivo, alvo de tempo, recorde, experiência, teste, volume, maior percurso ou disponibilidade marca o plano como desatualizado. Recalcular reorganiza sessões futuras e preserva treinos concluídos.

## Carga e segurança

- KM-base e teto semanal são carregados pelo objetivo selecionado.
- O motor aplica progressão gradual e descarga temporária de 25% após três semanas de construção como parâmetro de planejamento; o valor é reduzido/segurado quando a resposta, dor, fadiga ou RPE exigem.
- O teto não força o atleta a atingir aquele volume; dados reais acima do teto não são reduzidos artificialmente.
- O longão mantém o papel de maior sessão, respeitando distância recente, distribuição semanal e recuperação.
- A prontidão específica mantém critérios de volume, maior sessão, frequência, consistência e recuperação.

## Sem dependência de frequência cardíaca

O treinador usa pace individualizado, distância, duração, Cooper de 12 minutos, teste de 3 km, desempenho recente, RPE e teste da fala. FC/FCM não participa de prescrição, prontidão, progressão, carga ou análise. Dados cardíacos históricos podem permanecer apenas em registros antigos por compatibilidade, sem uso pelo motor.

## Backup e migração

- Backup Schema 3 preservado; leitura dos schemas 1–3 mantida.
- O app identifica exportações como V78.
- `CURRENT_ENGINE_VERSION` passa a 66 para marcar a necessidade de recalcular/migrar planos antigos, preservando sessões concluídas, feedbacks e histórico.

## Validação local

- Compilação Kotlin/JVM de módulos de domínio aprovada com `kotlinc`, usando stub temporário para o modelo de UI `Workout`; warnings não bloqueantes.
- Testes direcionados de faixas, alternativas e transição de experiência: 26 aprovados, 0 falhas no runner local com stub leve de JUnit.
- 21 falhas preexistentes do conjunto amplo de `CoachEngineTest` também ocorrem na base V75, sem aumento na V77.
- Suíte oficial JUnit/Gradle e build Android/Compose não executados: não há Gradle Wrapper/CLI nem Android SDK neste ambiente. Ver `BUILD_STATUS_V78.md`.


## V80 — Recovery Intelligence, Activity Splits & Race Export

- Fartlek aeróbio F01 recupera na parte superior da Z1 (90–100% da faixa operacional), com RPE leve e gatilho de retorno pela respiração controlada. Recuperações aeróbias Z2 usam 0–30% da Z2. Recuperações Z4 permanecem como caminhada nos protocolos explícitos e Z5 como pausa passiva; a duração prescrita não é reduzida automaticamente.
- Biblioteca e alternativas revisadas para que o modo de recuperação corresponda à intensidade do bloco, sem converter pausas passivas/caminhadas em corrida nem impor uma recuperação única a todos os estímulos.
- Removidos sufixos numéricos redundantes dos títulos de estágios repetidos. A ordem e a identidade das repetições continuam preservadas internamente.
- `ActivityZoneTimeEngine` inclui voltas explícitas e parciais agregadas de vários minutos na distribuição Z1–Z5; amostras GPS brutas continuam limitadas a 120 s para não preencher lacunas temporais longas.
- `ActivityFileImporter` reconstrói parciais acumuladas de 1 km e trecho final fracionado. Voltas irregulares são rateadas proporcionalmente quando cruzam limites de quilômetro e identificadas como reconstruídas. Cobertura/tempo insuficiente permanece desconhecida, sem fabricar pace.
- Revisão assistida Z1–Z5 abre o formulário de teste devidamente inicializado. “Manter e observar” registra a decisão e preserva as zonas; nenhuma faixa é alterada apenas pela sugestão.
- Estratégia de prova exportável pelo contrato nativo `UserWorkoutJson` do Pace Coach, incluindo aquecimento, fases de execução sustentadas por evidência e desaquecimento. Metas sem suporte não são inventadas.
- Nomes de exportação semanal seguem exatamente `S{semana}_T{treino}_{Título}`, sem data: por exemplo `S1_T1_Rodagem Progressiva`, `S1_T2_Longão`, `S2_T1_Rodagem Progressiva Z2 Z3`.
- Perfil mantém o gerenciamento esportivo sem atalho de exportação de sessão. Backup Schema 4, leitura de schemas 1–4, `versionCode = 80`, `versionName = V80`, `CURRENT_ENGINE_VERSION = 70`; sem dependência de FC/FCM.
- Validação Kotlin/JVM isolada: compilação dos motores de domínio e 12 verificações integradas de recuperação, títulos, distribuição de intensidade, GPX 6,62 km, nomes de exportação e estratégia. Build Android/Compose e suíte Gradle oficiais ainda precisam ser confirmados no GitHub Actions.

## V78 — Block-by-Block Feedback & Zone Execution Intelligence
- Removida a análise automática de blocos por voltas/amostras GPX/FIT/TCX; arquivos continuam sendo fonte de métricas gerais reais, sem associação artificial à prescrição.
- Removido o formulário de calibração individual Z2 por ritmo confortável. Dados legados permanecem compatíveis, mas deixam de ser usados para calibrar zonas.
- Feedback passa a exibir todos os blocos, zonas e ritmos prescritos, com campo de pace realizado por repetição. Intervalos e recuperações repetidos são exibidos intercalados na ordem real.
- Classificação: ritmo menor que o limite rápido = mais rápido que o proposto; dentro da faixa = preciso; acima do limite lento = mais lento. Classificação de velocidade não é confundida com qualidade fisiológica do estímulo.
- Painel de comportamento por zona Z1–Z5 acumula registros, combina execução com esforço/sensação/dor e exige múltiplas sessões para sugerir revisão. Nenhum ajuste automático isolado de zonas.
- Faixa originalmente prescrita congelada em cada registro. Backup Schema 3 preservado, com novos dados incluídos no JSON de feedback.
- `versionCode = 78`, `versionName = V78`, `CURRENT_ENGINE_VERSION = 68`; sem dependência de FC/FCM.
