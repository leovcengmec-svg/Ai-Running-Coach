# AI Running Coach V64

Aplicativo Android de prescrição inteligente de corrida, com avaliação de prontidão, zonas de pace, periodização por objetivo, biblioteca de sessões, monitoramento de carga, importação GPX/FIT/TCX, feedback, histórico local e backup.

## Identificação
- `versionCode = 64`, `versionName = V64`.
- `engineVersion = 50`; planos V63 são identificados para atualização. Ao solicitar o recálculo, somente sessões de hoje em diante são regeneradas, preservando treinos concluídos, feedbacks, âncora do ciclo e histórico.
- Backup `schemaVersion = 2`; campos novos permanecem opcionais e compatíveis com versões anteriores.
- O pacote de entrega mantém o nome original `AI-Running-Coach.zip`.

## Perfil, objetivo e prontidão
- `RunnerReadinessEngine` conecta objetivo, intenção (completar, correr continuamente, recorde pessoal, tempo-alvo ou saúde), nível, duração de experiência, frequência escolhida, média real, maior corrida recente e consistência das últimas quatro semanas.
- Catálogo contempla milha, 3 km, 5 km, 10 km, 15 km, 10 milhas, 20–30 km, meia maratona, maratona, ultradistâncias até 200 km, saúde e objetivo personalizado.
- A matriz de frequência/volume é uma referência de engenharia, não um mínimo fisiológico universal. O volume inicial é ancorado na carga real e nunca salta automaticamente para o mínimo da referência.
- Experiência acumulada é separada da condição atual. Perfis legados sem dados novos continuam compatíveis e recebem guardrails conservadores.
- Frequência de 2–6 dias selecionada pelo corredor é preservada. A recomendação explica diferenças sem alterar os dias silenciosamente.

## Perfil fisiológico e desempenho
- `PhysiologicalProfileEngine` estima velocidade crítica de campo somente com pelo menos três esforços/provas recentes, diferentes e consistentes; a estimativa não é tratada como medição laboratorial de LT2 ou VO₂máx.
- Projeção de tempo-alvo utiliza uma fórmula de desempenho como referência secundária, limitada por distância de extrapolação. Não substitui as zonas nem é exibida como promessa.
- `PerformanceMonitoringEngine` compara rodagens do mesmo tipo e terreno, considerando elevação quando há dados suficientes. Tendência de pace não recalibra zonas automaticamente.
- Pace-alvo competitivo é mostrado somente quando cabe na faixa completa da zona do segmento e nunca substitui a intensidade fisiológica prescrita.

## Planejamento, carga e periodização
- Planos de 6–52 semanas conforme objetivo, nível e carga atual; fases BASE, DEVELOPMENT, SPECIFIC, RECOVERY, TAPER e POST_RACE.
- Prova A define o macrociclo e pode acionar taper; provas B/C substituem uma sessão sem comandar o ciclo principal.
- `LoadPrescriptionEngine` utiliza volume atual, consistência, recuperação, fadiga, RPE e tendência sRPE. Progressões são guardrails conservadores do produto, não leis científicas universais; semanas respeitam o teto de referência sem forçar o corredor a alcançá-lo.
- `TrainingLoadEngine` sumariza distância, duração, sRPE, RPE, FC, cadência, elevação e tempo em zonas em janelas de 7, 28 e 42 dias. Tempo em zonas estimado por parciais é identificado como estimativa, não medição contínua.
- Tela Evolução mostra planejado versus realizado em 28 dias, aderência por sessões e quilômetros efetivamente registrados. Sessão marcada como concluída sem distância real conta para aderência, mas não infla a quilometragem realizada.

## Biblioteca e prescrição
- Sessões aeróbias, regenerativas, progressivas/regressivas, longões, tempo/limiar, fartlek, intervalados mistos Z2–Z5, piramidais, maratona e ultradistância.
- Treinos estruturados compartilham segmentos com zona, faixa ativa, pace, distância/duração, repetições, recuperação e RPE.
- `TrainingPrescriptionAudit` verifica consistência entre nome, zona, faixa, pace, dose e soma de segmentos.
- Recuperações de intervalados permanecem aeróbias em Z2 confortável; Z1 é reservada a aquecimento, desaquecimento e sessões regenerativas.
- Subidas dependem de percurso/elevação conhecida; força permanece complementar e opcional, sem ser inserida automaticamente no calendário.

## Importação, backup e compatibilidade
- Importação GPX/FIT/TCX preservada; métricas ausentes permanecem vazias.
- Backup Schema 2 permanece inalterado. Campos novos são opcionais; backups anteriores são restauráveis.
- Tela inicial **Começar Novo Plano** e **Importar Backup** preservada.
- Histórico, treinos concluídos, feedbacks, calibrações, competências e ciclo não são apagados pela migração.

## Validação
- Motores Kotlin de domínio compilados em conjunto com `kotlinc`, isolando Android/Compose e usando modelo `Workout` de suporte, pois o modelo de UI está declarado em `MainActivity.kt`.
- Harness integrado gerou 12 semanas/36 sessões em perfil intermediário de 10 km e verificou segmentos, distâncias, carga de 7/28/42 dias, estimativa de velocidade crítica e teto individual de volume.
- Fontes de testes unitários para prontidão, carga, fisiologia, periodização e monitoramento foram adicionadas ao projeto. A suíte Gradle/JUnit e o APK Android completo ainda precisam ser executados pelo GitHub Actions.
- Gradle/Android SDK não estão disponíveis neste ambiente; não foi declarada compilação APK.

## Documentação dos motores introduzidos na V63
- `RUNNER_INTELLIGENCE_V63.md` — objetivos, prontidão, perfil fisiológico e decisões adaptativas.
- `TRAINING_LOAD_AND_PERFORMANCE_V63.md` — carga externa/interna, RPE, janelas móveis e monitoramento.
- `TRAINING_PERIODIZATION_V63.md` — periodização por objetivo, provas A/B/C e carga.
- `TRAINING_PRESCRIPTION_AUDIT_V63.md` — estrutura de sessões e critérios de consistência.
