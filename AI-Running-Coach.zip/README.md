# AI Running Coach — V58

V58 adiciona a escolha inicial entre **Começar Novo Plano** e **Importar Backup**. A importação utiliza o mesmo restaurador já disponível em Mais → Backup e restauração, apresenta uma confirmação antes de substituir os dados locais e preserva os dados atuais quando o arquivo falha na validação.

## Identificação
- `versionCode = 58`, `versionName = V58`.
- `engineVersion = 43`; motor de treino preservado da V57.
- Backup `schemaVersion = 2`; formato e validação mantidos.

## Fluxo de importação
1. Na tela inicial, tocar em **Importar Backup**.
2. Selecionar o arquivo JSON de backup no seletor Android.
3. Confirmar a substituição dos dados locais.
4. O aplicativo valida o arquivo e restaura perfil, plano, sessões, feedbacks, avaliações e competições.
5. Em sucesso, abre Backup e restauração com a mensagem de resultado; em falha, permanece na tela inicial sem alterar os dados.

A lógica de treinamento V57 continua preservada: recálculo mantém o ciclo ativo e a frequência semanal de 2–6 dias, opções extras ficam restritas aos dias livres e os indicadores de prontidão são calculados a partir de feedbacks recentes.
