# AI Running Coach V67

## V67 — correção do build Android sobre a base V66

`versionCode=67` • `versionName=V67` • `engineVersion=53` • Backup Schema 2. O motor escolhe protocolos por objetivo, intenção e fase; F01 usa Z2–Z3 com recuperação Z1; níveis fisiológicos não bloqueiam qualidade quando carga e recuperação permitem. Após atualizar, recalcule o plano para aplicar a nova matriz, preservando o histórico.


Aplicativo Android de prescrição inteligente de corrida. A V67 corrige a compilação do painel de calibração e mantém as funcionalidades de prescrição da V66. A V66 aprofunda a seleção de sessões por objetivo, intenção, fase, carga e tolerância; incorpora a matriz MOTOR V11 e protocolos da planilha fornecida; corrige a progressão de Fartlek, Tempo Run e intervalados; e melhora a transparência da classificação fisiológica.

## Identificação
- `versionCode = 67`, `versionName = V67`.
- `engineVersion = 53`; planos V65 (engineVersion 52) são sinalizados para revisão e recálculo. Ao confirmar, somente sessões futuras são regeneradas, preservando treinos concluídos, feedbacks, âncora do ciclo e histórico.
- Backup `schemaVersion = 2`; `appVersion = V67`; campos novos são opcionais e compatíveis com versões anteriores.
- O pacote mantém o nome original `AI-Running-Coach.zip`.

## Cadastro e nível fisiológico
- Seis etapas: teste + idade/referência fisiológica; meta liberada; experiência; dias/terreno; volume semanal; maior corrida recente.
- Cooper 12 min e teste de 3 km estimam VO₂máx. A classe (Iniciante, Intermediário, Performance ou Elite) é determinada exclusivamente pelo VO₂máx estimado e pela referência de idade/sexo. Experiência não altera o nível.
- Metas são filtradas por classe. Veja `TRAINING_PRESCRIPTION_ENGINE_V66.md` para a tabela de cortes VO₂max por idade/referência, matriz de protocolos, validação de exemplo e fontes.
- A pergunta manual de semanas ativas foi removida; consistência vem do histórico real.

## Prescrição e tolerância
- O motor relaciona a meta à intenção (completar, correr continuamente, melhorar recorde ou atingir tempo) e à fase; a seleção usa protocolos nomeados como F01/F04, T01, I04, T04, RP05 e I07.
- F01 alterna blocos ativos Z2–Z3 e recupera em Z1; F04 introduz variação aeróbia com Z4 somente quando os critérios de carga e recuperação permitem.
- Para três dias de corrida, o plano tende a uma sessão de qualidade, uma rodagem fácil e um longão; semanas regenerativas reduzem carga.
- Volume, maior sessão recente, recuperação e resposta às atividades definem a dose; não alteram a classe fisiológica.
- Iniciante sem histórico pode deixar volume e maior corrida em branco; o início usa dose conservadora e adapta conforme tolerância registrada.
- Corrida/caminhada é uma estratégia de tolerância, não uma consequência automática do rótulo Iniciante. Com teste válido, os trechos ativos usam Z2 individual; sem teste, o app não inventa pace.
- Textos de resumo foram reduzidos e códigos técnicos internos não aparecem na interface do corredor.

## Demais sistemas
- `RunnerReadinessEngine` combina classe fisiológica, meta, frequência, volume, maior sessão e consistência real; experiência é apenas contexto.
- `TrainingPeriodizationEngine` planeja ciclos até 52 semanas e preserva provas A/B/C.
- `TrainingLoadEngine` resume carga de 7/28/42 dias, com valores medidos e estimados separados.
- `PerformanceMonitoringEngine` compara sessões por tipo/terreno; estimativas não recalibram zonas automaticamente.
- Backup Schema 2, importação GPX/FIT/TCX, feedback, histórico e migração de ciclos permanecem.

## Validação
- Compilação isolada Kotlin/JVM e harness de ponta a ponta do motor confirmaram seleção de sete protocolos distintos no plano de exemplo de 10 semanas, Fartlek F01 em Z2–Z3 com recuperação Z1, faixas de VO₂max por idade/referência e metas até meia maratona para Iniciante/Intermediário.
- Testes unitários foram adicionados para a tabela fisiológica, seleção por objetivo/fase, diversidade de sessões, integração do catálogo e migração engineVersion 52→53.
- A suíte Gradle/JUnit e a compilação APK Android ainda dependem do GitHub Actions; não declarar o APK aprovado antes do workflow.
