# AI Running Coach V104

- VersionCode 104 / VersionName V104; motor interno 94; Backup Schema 16, compatibilidade de leitura 1–16 (inclui V103/15 e V102/14).
- V104 corrige a revisão complementar da calibração: Lote B fica elegível assim que reunir novas evidências válidas, mesmo antes dos 28 dias da próxima revisão periódica.
- Z1 mantém lote próprio completo (Lote A até 3% + Lote B até 2%) e continua recebendo automaticamente as contribuições confirmadas de Z2 e Z3. Z2 mantém seu lote próprio e recebe Z3; Z3 mantém seu lote próprio. Tetos efetivos preservados: Z1 15%, Z2 10%, Z3 5%.
- IDs estáveis de blocos consumidos e marco temporal por zona impedem reutilização de evidências entre lotes; estados V103 sem IDs usam a data do último crédito confirmado como limite conservador de migração.
- O histórico passa a registrar a amostra efetivamente consumida, resumo A/B e a data final das evidências aceitas. Abrir/dispensar uma revisão insuficiente não posterga a próxima verificação.
- O cartão de reteste consulta a próxima sessão futura real do plano. Se não houver sessão futura e a primeira oportunidade já passou, apresenta atraso e informa que o próximo reteste ainda não foi programado; nunca mostra a data vencida como futura.
- Backup Schema 16 persiste IDs consumidos, marcos de evidência e resumo de lotes, preservando compatibilidade de leitura com schemas anteriores.
- As correções V103 continuam preservadas: semana regenerativa adaptativa, indicadores vetoriais, próximo evento unificado e monitoramento preliminar de ritmo sem frequência cardíaca.

# AI Running Coach V101

## V101 — exportação Pace Coach resiliente, nomes curtos e modalidade Tempo Run distinta

- `versionCode = 101` · `versionName = V101` · `CURRENT_ENGINE_VERSION = 91` · Backup Schema 14 (leitura compatível de schemas 1–14).
- Exportação não compara mais títulos completos: a auditoria valida código, blocos, repetições, doses, recuperações e sequência; variações de pontuação/Unicode/localização não bloqueiam a sessão.
- O botão de compartilhamento captura erros, registra diagnóstico, remove anexos temporários incompletos e mostra mensagem sem derrubar o app.
- Nomes exportados seguem `S{semana}_T{número}_{SIGLA}_{VARIANTE}`; prévia, arquivo e JSON compartilham o mesmo identificador compacto. Rótulos descritivos antigos são normalizados.
- Taxonomia distingue `TMP` (Tempo Run contínuo), `INT` (Tempo intervalado, intervalados e ritmo específico), `FAR`, `ROD`, `LNG` e demais famílias. O rótulo genérico `Qualidade` não força `INT`.
- Periodização para prioridades de recorde/tempo limita a sequência a dois estímulos de maior demanda no bloco de construção; a terceira semana alterna para estímulo aeróbio/moderado quando elegível e a quarta não recebe protocolo intenso. A prontidão continua prevalecendo, sem quota fixa de Fartlek.
- A sessão selecionada recebe auditoria resumida de semana, fase, posição no ciclo, protocolo, modalidade e gates de limiar/VO₂.
- Ciclo de oito semanas, semana atual, histórico, teto de 40% do longão e Backup Schema 14 preservados.

Relatórios: `V101_CORRECAO_AUDITORIA_V100.md`, `TEST_REPORT_V101.md`, `BUILD_STATUS_V101.md` e `V101_PLANO_CORRECAO_AUDITORIA_V100.md`.

---

# AI Running Coach V100

## V100 — ciclo de oito semanas protegido e calendário compacto

- `versionCode = 100` · `versionName = V100` · `CURRENT_ENGINE_VERSION = 90` · Backup Schema 14 (leitura compatível de schemas 1–13).
- Ciclo persistido por identidade, âncora, duração e perfil congelado. Mudanças do perfil durante o ciclo ficam pendentes para o próximo; troca de motor não inicia novo plano.
- Semanas anteriores mantidas como histórico do backup; semana atual preservada integralmente; somente sessões de hoje em diante nas semanas futuras do mesmo ciclo podem ser atualizadas.
- Ciclo de oito semanas só pode ser encerrado após o período transcorrer e por ação explícita; início do próximo ciclo também é explícito.
- Backups antigos recuperam a âncora por data/número da semana; evidência ambígua preserva o plano e pede confirmação.
- Distribuição usa o motor real de sessões, mantém longão até 40%, piso de sessão para objetivo contínuo de 5 km e diferença de dominância quando viável. Exemplo 17 km: 6,8 + 5,1 + 5,1 km.
- Calendário mensal: células de 68 dp, grade 4/5/6 semanas, ícones vetoriais coloridos e códigos INI/REG/ROD/FAR/INT/LNG/PRV/TES; prova e treino no mesmo dia podem aparecer juntos.
- Harness Kotlin/JVM focado de calendário/distribuição e harness de ciclo passaram. Gradle/JUnit oficial, compilação Android e APK aguardam GitHub Actions.

Relatórios: `V100_CORRECAO_AUDITORIA_V99.md`, `TEST_REPORT_V100.md`, `BUILD_STATUS_V100.md` e `V100_PLANO_CORRECAO_AUDITORIA_V99.md`.

**Fonte Android compilada:** `android/app/src/main/java/com/airunningcoach/app/` (source set padrão Gradle). Os snapshots Kotlin soltos na raiz são legados e não fazem parte do source set compilado.

---

# AI Running Coach V99

## V99 — frequência futura e integridade do longão

- `versionCode = 99` · `versionName = V99` · `CURRENT_ENGINE_VERSION = 89` · Backup Schema 13 (leitura compatível de schemas 1–13).
- Treinos concluídos não contam como compromissos futuros; frequência usa datas distintas. Conflitos pendentes no mesmo dia continuam bloqueados.
- Semana atual parcial não aplica teto de 40% sobre sessões restantes se os dias da frequência não estiverem integralmente representados.
- Reteste futuro sem protocolo conta como compromisso, não como sessão inválida de 0 km; a participação do longão usa limite conservador até escolha Cooper/3 km.
- Semanas futuras completas continuam respeitando longão até 40% e dominância. Mensagens de bloqueio agora listam sessões/provas e a meta semanal disponível.
- `RaceEventEngine` verifica frequência por datas futuras distintas.
- 23 métodos de teste do calendário executados localmente com runner Kotlin e shim JUnit leve. Gradle/JUnit oficial e APK dependem do GitHub Actions.

Relatórios: `V99_CORRECAO_AUDITORIA_V98.md`, `TEST_REPORT_V99.md`, `BUILD_STATUS_V99.md` e `V99_PLANO_CORRECAO_AUDITORIA_V98.md`.

**Fonte Android compilada:** `android/app/src/main/java/com/airunningcoach/app/` (source set padrão Gradle). Os snapshots Kotlin soltos na raiz são legados e não fazem parte do source set compilado.

## V98 — backup fisiológico e histórico em card único

- `versionCode = 98` · `versionName = V98` · `CURRENT_ENGINE_VERSION = 88` · Backup Schema 13 (leitura compatível de schemas 1–12).
- Gerar/recalcular plano não salva nem recria teste fisiológico; usa a última avaliação ativa já salva e ignora rascunho vazio.
- Avaliações Cooper/3 km possuem identidade estável, edição, remoção reversível e restauração; registros removidos não entram nas referências fisiológicas.
- Reidratação de backups reconstrói zonas de 3 km pelo tempo do teste e protocolo correto; preserva faixas congeladas quando existentes.
- Histórico de treino apresenta um card expansível por sessão concluída com feedback associado, métricas reais e ações discretas no menu.
- Cadastro distingue base/maior sessão declaradas de referências automáticas do objetivo e histórico medido.
- Harness Kotlin/JVM isolado da gestão de avaliações: cinco cenários aprovados. Gradle/JUnit, compilação Compose e APK dependem do GitHub Actions.

Relatórios: `V98_CORRECAO_AUDITORIA_V97.md`, `TEST_REPORT_V98.md`, `BUILD_STATUS_V98.md` e `V98_PLANO_CORRECAO_AUDITORIA_V97.md`.

**Fonte Android compilada:** `android/app/src/main/java/com/airunningcoach/app/` (source set padrão Gradle). Os snapshots Kotlin soltos na raiz são legados e não fazem parte do source set compilado.

## V97 — preservação da carga, longão e calendário

- `versionCode = 97` · `versionName = V97` · motor 87 · Backup Schema 12.
- Feedback normal não reconstrói a semana; fonte de carga declarada protegida e adoção medida por confirmação; longão até 40% e piso de sessão para objetivo 5 km, com exceções explicitadas.
- Harness Kotlin/JVM focado da V97: 102 testes aprovados. Build Android oficial depende do GitHub Actions.
