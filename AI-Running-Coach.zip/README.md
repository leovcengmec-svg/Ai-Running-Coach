# AI Running Coach V65

Aplicativo Android de prescrição inteligente de corrida. O V65 reorganiza o cadastro fisiológico, libera metas conforme VO₂máx estimado, separa classe fisiológica de experiência e tolerância atual e reduz textos repetitivos nas telas.

## Identificação
- `versionCode = 65`, `versionName = V65`.
- `engineVersion = 51`; planos V64 (engineVersion 50) são sinalizados para revisão e recálculo. Ao confirmar, somente sessões futuras são regeneradas, preservando treinos concluídos, feedbacks, âncora do ciclo e histórico.
- Backup `schemaVersion = 2`; `appVersion = V65`; campos novos são opcionais e compatíveis com versões anteriores.
- O pacote mantém o nome original `AI-Running-Coach.zip`.

## Cadastro e nível fisiológico
- Seis etapas: teste + idade/referência fisiológica; meta liberada; experiência; dias/terreno; volume semanal; maior corrida recente.
- Cooper 12 min e teste de 3 km estimam VO₂máx. A classe (Iniciante, Intermediário, Performance ou Elite) é determinada exclusivamente pelo VO₂máx estimado e pela referência de idade/sexo. Experiência não altera o nível.
- Metas são filtradas por classe. Veja `RUNNER_FITNESS_LEVELS_V65.md` para tabela, equações, protocolos e limitações dos testes.
- A pergunta manual de semanas ativas foi removida; consistência vem do histórico real.

## Prescrição e tolerância
- Volume, maior sessão recente, recuperação e resposta às atividades definem a dose; não alteram a classe fisiológica.
- Iniciante sem histórico pode deixar volume e maior corrida em branco; o início usa dose conservadora e adapta conforme tolerância registrada.
- Corrida/caminhada é uma estratégia de tolerância, não uma consequência automática do rótulo Iniciante. Com teste válido, os trechos ativos usam Z2 individual; sem teste, o app não inventa pace.
- Textos de resumo foram reduzidos e códigos técnicos internos não aparecem na interface do corredor.

## Demais sistemas
- `RunnerReadinessEngine` combina classe fisiológica, meta, frequência, volume, maior sessão e consistência real; experiência é apenas contexto.
- `TrainingPeriodizationEngine` planeja ciclos até 52 semanas e preserva provas A/B/C.
- `TrainingLoadEngine` resume carga de 7/28/42 dias, com valores medidos e estimados separados.
- `PerformanceMonitoringEngine` compara sessões por tipo/terreno; estimativas não recalibram zonas automaticamente.
- Backup Schema 2, importação GPX/FIT/TCX, feedback, histórico e migração de ciclos permanecem.

## Validação
- Foram adicionados testes unitários para classificação por idade/referência, equações Cooper/3 km, disponibilidade de metas, independência entre experiência e nível, e corrida ativa Z2 para iniciante com teste válido.
- A suíte Gradle/JUnit e a compilação APK Android ainda dependem do GitHub Actions; não declarar o APK aprovado antes do workflow.
