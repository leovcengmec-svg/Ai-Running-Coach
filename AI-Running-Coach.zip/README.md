# AI Running Coach — V57

V57 preserva o ciclo ao recalcular, mantém a frequência semanal escolhida (2–6 dias), restringe consulta extra a dias livres, adapta opções extras à carga recente e atualiza os indicadores de recuperação/segurança pelos feedbacks recentes.

# V57 — recálculo do ciclo e prontidão do atleta

- `versionCode = 57`, `versionName = V57`, `engineVersion = 43`; backup schema 2.
- Recalcular respeita a âncora do ciclo ativo, mantém semanas concluídas e atualiza apenas sessões de hoje em diante.
- Dashboard e Plano compartilham o mesmo cálculo da semana atual.
- Preserva a frequência semanal escolhida no perfil (2–6 dias), inclusive para iniciantes; a intensidade/dose é que muda conforme a capacidade.
- Consulta de treino extra somente em dias livres. Recomendações de 3–5 km quando o volume e o maior treino recente sustentam, com redução por sinais de recuperação.
- Cards Recuperação e Segurança atualizados pelos três feedbacks mais recentes (janela de 14 dias), sem alegação de medição fisiológica.
- GPX/FIT/TCX, calibração Z1–Z3 e backups V56 anteriores preservados; schema do backup não muda.

Consulte `RECÁLCULO_E_PRONTIDÃO_V57.md` para as regras e limitações.


