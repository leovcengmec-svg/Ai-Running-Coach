# V90 — Correção da progressão de carga e do calendário

**Base:** AI Running Coach V89  
**VersionCode:** 90  
**VersionName:** V90  
**Motor interno:** 79  
**Backup:** Schema 5; leitura dos schemas 1–5

## 1. Diagnóstico da regressão semanal

A inspeção da V89 mostrou que `LoadPrescriptionEngine` zerava o crescimento de todo o ciclo diante de qualquer um destes sinais, mesmo moderados: recuperação abaixo de 75, fadiga a partir de 65, RPE médio a partir de 7,5 ou razão de carga recente acima de 1,35. Como esses dados são um retrato do momento de geração, a decisão era repetida em todas as semanas futuras, produzindo patamares como 16,0 / 16,0 / 16,0 km.

O catálogo de carga para objetivo de 5 km tem teto de construção de 22,5 km. Portanto, 16 km não era o teto do catálogo do objetivo, mas podia virar um platô por causa da regra binária de prontidão.

## 2. Nova regra de progressão

- Sinal severo: recuperação abaixo de 50 ou fadiga igual/acima de 75. Mantém o volume de construção para reavaliação. Dor continua bloqueando a prescrição.
- Dois ou mais sinais moderados: permite progressão de até 1% por semana de construção.
- Um sinal moderado: permite progressão de até 2%.
- Sem sinais moderados: mantém o limite definido pela consistência individual (5%, 4%, 3%, 2% ou 1%).
- O teto do objetivo continua valendo, sem reduzir a base atual se ela já estiver acima dele.
- Semana regenerativa reduz 25% sobre a última semana de construção e não redefine a referência.

Os valores são guardrails de produto, não limites fisiológicos universais. O plano futuro continua sendo uma projeção; resposta real deve ser reavaliada quando o atleta registrar os treinos.

## 3. Longão

A liberação progressiva do teto de longão deixou de ser congelada por alertas moderados isolados. O bloqueio continua quando há dor, recuperação abaixo de 50 ou fadiga igual/acima de 75. O longão continua sujeito à distribuição, ao teto próprio da distância-alvo e à maior sessão recente.

## 4. Transparência por semana

Cada sessão guarda uma cópia opcional da justificativa da carga semanal e do percentual planejado. Os cards de semana mostram a razão em semanas mantidas ou limitadas e, ao expandir, exibem a explicação completa. Os campos novos são opcionais e não removem histórico de backups antigos.

## 5. Coerência do gráfico e dos cards

O gráfico da progressão passa a calcular cada total com `WeeklyVolumeSummary`, a mesma consolidação usada pelos cards semanais: treinos prescritos + provas não canceladas. Isso elimina duas fórmulas independentes e reduz risco de duplicação ou divergência na tela.

## 6. Calendário

O calendário passa a ter exatamente oito famílias gerais: Regenerativo, Rodagem, Intervalado, Fartlek, Limiar/Qualidade, Longão, Prova e Teste. A classificação prioriza `type` e `stimulus`; o título serve apenas como fallback para registros antigos.

Cores mantidas ou reutilizadas: regenerativo azul-claro, rodagem verde, intervalado rosa, fartlek azul, limiar/qualidade laranja, longão ciano, prova roxo e teste violeta.

Status visual: ✓ verde translúcido quando concluído; × vermelho translúcido quando a data programada passou e a sessão não está concluída; sem símbolo enquanto hoje ainda está em andamento ou para datas futuras. O status não altera distância, treino, feedback nem backup.

## 7. Integridade e backup

Schema 5 grava `weeklyLoadRationale` e `plannedGrowthPercent` como campos opcionais dentro dos registros de treino. A leitura de schemas 1–4 continua disponível; ao restaurar um registro legado, os campos novos usam valores vazios/nulos. Não foi adicionada categoria/status persistente: ambos são derivados, evitando reclassificar o histórico.

## 8. Testes incluídos

- Um RPE alto isolado ou razão de carga alta reduz progressão a 2%, sem congelar o ciclo.
- Dois sinais moderados simultâneos reduzem a progressão a 1%.
- Recuperação abaixo de 50 ou fadiga ≥75 mantém carga.
- Perfil 5 km com base 16 km mostra progressão, limitada pelo teto de 22,5 km.
- O deload preserva a referência de construção.
- Categorias e status de calendário testados para oito famílias e datas passadas/hoje/futuras.
- Backup Schema 4/V89 testado para leitura na V90.

## 9. Limitação de validação

Este ambiente não dispõe de Gradle CLI, wrapper ou Android SDK. A validação final da suíte Android/Compose e a geração do APK precisam ser feitas no GitHub Actions.
