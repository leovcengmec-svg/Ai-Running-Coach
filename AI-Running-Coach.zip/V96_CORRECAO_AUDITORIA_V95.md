# AI Running Coach V96 — Implementação do plano de correção da auditoria V95

**Base:** V95  
**VersionCode / VersionName:** 96 / V96  
**Motor interno:** 86  
**Backup Schema:** 11 (leitura compatível de schemas 1–10)

## 1. Reteste Cooper / 3 km
- O evento futuro é salvo sem método, duração, distância ou blocos específicos.
- Na data exata do evento, a tela apresenta Cooper 12 min e 3 km, cada um condicionado à elegibilidade etária e referência fisiológica.
- A escolha monta a prescrição completa de aquecimento, bloco principal e desaquecimento. O Cooper usa alvo TIME de 12 minutos; o teste de 3 km usa alvo DISTANCE de 3 km.
- O método escolhido é persistido no registro da sessão e é atualizado caso o atleta troque de opção na tela do teste.
- A tentativa só abre no dia agendado. A adesão e ausência de dor continuam sendo verificadas. Após salvar um resultado correspondente, a sessão de reteste é marcada como concluída antes de criar o próximo ciclo.
- Quando o protocolo escolhido difere do último teste, a distância/duração preditiva é apenas estimativa, nunca um resultado medido.

## 2. Proteção do cadastro do corredor
- Removida de `createPlan()` a escrita sobre `weeklyVolumeText` e `longestRecent`.
- `RunnerLoadSourceResolver` separa valores declarados, medições e os valores efetivamente usados para prescrever.
- Histórico confiável pode orientar a carga do plano, sem substituir o cadastro original. Histórico parcial mantém a base declarada/objetivo e pode considerar uma maior corrida medida como limite adicional.
- Perfil exibe base declarada e medidas recentes separadamente.
- Backup continua carregando os campos declarados como dados independentes e há teste de round-trip para 16 km/10 km.

## 3. Calibração e atualização de sessões
- Removido o botão genérico que aparecia somente porque havia treinos cadastrados.
- `recalibratePlan()` agora exige `needsPacePlanRefresh` e sessões existentes.
- A proposta adaptativa em estado READY oferece somente “Revisar e confirmar alterações nas zonas”. Os estados aguardando revisão, evidência insuficiente, sem alteração, limite atingido ou bloqueado não recebem ação para confirmar/aplicar.
- A confirmação grava a calibração e cria um estado separado `adaptivePlanRefreshPending`; não recria o plano silenciosamente. Somente depois da confirmação aparece “Atualizar treinos futuros”.
- A atualização conserva as sessões concluídas e recalcula o planejamento por `createPlan()`.

## 4. Versões e backups
- VersionCode 96; VersionName V96; motor interno 86.
- Backup Schema 11. O decoder continua aceitando versões de schema 1 até 11; portanto, os schemas 1–10 anteriores permanecem legíveis.
- Novo campo `adaptivePlanRefreshPending` é opcional nas preferências e `retestMethod` é opcional dentro do JSON de cada sessão. Backups antigos que não o contêm são lidos com valor vazio, mantendo o reteste como “método a definir”.

## 5. Arquivos principais
- `android/app/src/main/java/com/airunningcoach/app/MainActivity.kt` — integração de agenda, seleção, persistência, perfil, calibração e controle de sessão.
- `RetestProtocolEngine.kt` — prescrição específica por protocolo.
- `RunnerLoadSourceResolver.kt` — separação entre cadastro, medições e fonte de carga da prescrição.
- `CooperAssessmentEngine.kt` — estimativa por protocolo selecionado, inclusive quando o último teste pertence ao outro método.
- `RetestCycleEngine.kt` — restauração da sessão original limpa o método escolhido no reteste.
- `AppBackupManager.kt` — schema 11.

## 6. Testes incluídos
- `RetestProtocolEngineTest.kt`: reteste sem método; Cooper; 3 km; troca entre métodos; requisitos etários/referenciais.
- `RetestDistanceEstimatorTest.kt`: conversão estimada entre o último protocolo e o protocolo escolhido.
- `RunnerLoadSourceResolverTest.kt`: cadastro de 16/10 preservado com medição confiável de 8,5/6,6 e cenário de histórico parcial.
- `AppBackupCodecTest.kt`: schema 11 e preservação dos campos declarados no backup.
- `RetestCycleEngineTest.kt`: restauração da sessão de origem limpa o método do reteste.

## 7. Limite da verificação desta entrega
O código e os testes de regressão foram adicionados ao projeto. Este ambiente de execução não contém Gradle nem Android SDK; por isso a suíte Android/JUnit, a compilação Compose e a geração do APK não puderam ser executadas aqui. O workflow `.github/workflows/android.yml` está configurado para executar `:app:testDebugUnitTest` e `:app:assembleDebug` no GitHub Actions. Não considerar o APK certificado antes de o workflow terminar verde.
