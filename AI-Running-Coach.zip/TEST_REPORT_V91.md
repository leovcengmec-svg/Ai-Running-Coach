# Relatório de testes — V91

**Base:** V90 Build Fix  
**VersionCode:** 91 • **Engine:** 80 • **Backup Schema:** 6

## Verificações executadas neste ambiente

| Área | Verificação | Resultado |
|---|---|---|
| Calendário | Oito categorias com glifos distintos | PASS |
| Calendário | Hoje/futuro pendentes; passado não concluído perdido; opacidade somente no estado perdido | PASS |
| Carga | Média descritiva de 28 dias com histórico parcial | PASS |
| Carga | Média descritiva de 42 dias com histórico parcial; confiabilidade permanece independente | PASS |
| Cooper | Cooper 12 min + aquecimento/desaquecimento estimados pela Z2 individual | PASS |
| Cooper | Teste de 3 km + estimativas individuais | PASS |
| Cooper | Ausência de zona individual gera estimativa parcial sem inventar distância | PASS |
| Backup | Testes JUnit adicionados para Schema 6 e leitura dos schemas 1–5 | ADICIONADOS; não executados localmente |
| Prescrição | Auditoria JUnit de biblioteca/preparação Z2 | ATUALIZADA; não executada localmente |

## Resultados dos harnesses Kotlin/JVM isolados

- `WorkoutCalendarPresentation.kt`: compilado e executado; categorias, datas e opacidade aprovadas.
- `TrainingLoadEngine.kt`: compilado e executado; médias de 28/42 dias disponíveis em amostra parcial, sem liberar confiabilidade automaticamente.
- `RetestDistanceEstimator`: trecho de produção compilado em harness com stubs de dependências e executado; cenários Cooper, 3 km e estimativa parcial aprovados.

## Não executado

- `:app:testDebugUnitTest` completo.
- `:app:compileDebugKotlin` via Gradle.
- `:app:assembleDebug` / APK.
- Testes instrumentados ou restauração real em aparelho.

A razão é ambiental: o ZIP não contém Gradle Wrapper e este ambiente não possui Gradle CLI nem Android SDK. Os harnesses acima são verificações direcionadas, não substituem o build Android. O APK somente deve ser considerado aprovado após o workflow `build-apk` terminar verde no GitHub Actions.
