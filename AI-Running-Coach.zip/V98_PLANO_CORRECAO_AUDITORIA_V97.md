# AI Running Coach — Plano de correção V98

**Auditoria da V97 · 26/11/2026**  
**Status:** diagnóstico concluído e plano de implementação elaborado. A atualização ainda não foi aplicada.

## 1. Identificação da próxima versão

| Item | Proposta |
|---|---:|
| VersionCode | 98 |
| VersionName | V98 |
| Motor interno | 88 |
| Base de trabalho | V97 |
| Backup Schema | 13 |
| Compatibilidade | Leitura de schemas 1–12 |

A V98 deverá consolidar três frentes: confiabilidade do teste fisiológico após backup, gestão do histórico de testes e reorganização integral do histórico de treinos em cards únicos e expansíveis.

---

## 2. Diagnóstico das cinco imagens e confirmação no código

### Imagem 1 — aviso de falha ao recalcular após restaurar backup

A mensagem exibida é: “Não foi possível recalcular: Confira a idade do perfil, a referência fisiológica, a distância do Cooper (1,00–5,00 km) e a data do teste. O plano importado foi preservado.”

**O backup foi restaurado e o plano foi preservado. O erro aparece na etapa posterior de recalibração/reconstrução do plano, não é evidência suficiente de que o arquivo JSON tenha perdido o teste.**

### Imagem 2 — teste existe no histórico, mas o formulário atual está vazio

O histórico mostra um registro Cooper de **2,1 km em 12 minutos**, em **11/10/2026**, com VO₂máx estimado de **35,6 ml/kg/min**, idade de **36 anos**, referência masculina e nível Iniciante. Portanto, o objeto histórico foi recuperado e os seus principais campos estão disponíveis na tela.

Ao mesmo tempo, a parte superior da tela mostra um formulário de novo teste Cooper com distância vazia e data **26/11/2026**. São estados diferentes: o resultado antigo existe no histórico, enquanto o rascunho de um novo teste está vazio.

**Causa encontrada no código:**

- `MainActivity.kt`, `createPlan()`, chama `saveCurrentFieldTestToHistory()` antes de gerar o plano, mesmo quando a operação é apenas uma atualização do motor ou uma recalibração de backup.
- `saveCurrentFieldTestToHistory()` chama `isCooperEntryValid()` e valida os campos atuais do formulário.
- `openFieldTestEditor()` limpa a distância/tempo para iniciar uma nova tentativa.
- `fieldTestEntryPending` é estado transitório e é excluído do backup por `AppBackupCodec`.
- Assim, a lista `cooperAssessments` pode conter o teste válido, enquanto `cooperDistanceText` está vazio. O recálculo tenta validar o rascunho vazio em vez de usar o último teste salvo.

Esse encadeamento explica a mensagem da imagem. A correção deve separar a operação “salvar novo teste” da operação “gerar/atualizar plano usando o último teste salvo”.

### Imagem 3 — cadastro aparenta mostrar uma base diferente

A tela exibe maior sessão declarada de **10 km**, mas o texto auxiliar informa capacidade presumida de **3,0 km** e base semanal de **12,0 km**.

A auditoria do código identificou que esses dois números auxiliares vêm diretamente de `TrainingPlanReferenceCatalog.loadReference()` para o objetivo selecionado. O texto não consulta os campos efetivamente digitados (`weeklyVolumeText` e `longestRecent`). Os valores declarados são usados por outras funções, como `effectiveDisplayWeeklyKm()`, `effectiveDisplayLongestKm()` e `isRunWalkEligibleForCurrentProfile()`.

**Conclusão importante:** a imagem confirma uma apresentação confusa, mas, isoladamente, não prova que os valores declarados tenham sido substituídos no armazenamento. A tela está misturando a referência padrão do objetivo com os dados particulares do corredor sem identificá-los corretamente.

Há ainda uma frase desatualizada no onboarding: “Histórico real informado substitui a base quando disponível”. Ela conflita com a regra vigente da V97, em que o histórico medido não deve substituir a base declarada sem confirmação expressa.

### Imagem 4 — dois cards para cada treino concluído

A duplicação está confirmada em `HistoryScreen()`:

1. A tela renderiza `WorkoutCard()` para a sessão concluída.
2. Logo depois, renderiza `FeedbackHistoryDetails()` em outro `CardSurface` para o feedback associado.

Os dois componentes representam a mesma sessão. Por isso, cada treino aparece como um card-resumo e outro card com detalhes/ações.

A `FeedbackHistoryDetails()` também distribui “Editar”, “Vincular”, “Remover” e outras ações em uma linha com pesos iguais, ocupando a largura e criando espaço desnecessário. A ação não deve comandar o layout do card.

### Imagem 5 — referência visual do Pace Coach

A referência apresenta uma lista mais direta:

- filtros por Todos, Semana, Mês e Ano;
- resumo do período com quantidade de treinos, distância e duração;
- sessões agrupadas por data;
- um único card por atividade;
- distância, duração e ritmo médio apresentados de forma compacta.

A V98 deverá aproveitar essa hierarquia visual, adaptando-a à identidade visual do AI Running Coach e mantendo os dados específicos de feedback, blocos, parciais e atividades importadas.

---

## 3. Plano de correção — backup e teste fisiológico

### 3.1 Separar rascunho de teste de referência fisiológica salva

Criar um fluxo explícito para decidir qual dado será usado na geração do plano:

| Situação | Comportamento obrigatório |
|---|---|
| Existe teste salvo válido e não há novo teste em edição | Usar o último teste salvo; ignorar campos vazios do formulário |
| Usuário iniciou explicitamente um novo teste | Validar método, resultado, data e dados fisiológicos antes de salvar |
| Novo teste está incompleto | Não salvar o teste e não impedir uma atualização independente do plano com o último teste válido |
| Não existe teste salvo e o perfil exige avaliação | Informar os campos ausentes com precisão; não inventar resultado |
| Perfil usa modo provisório `NONE` | Manter as regras conservadoras já existentes |

**Regra técnica:** `createPlan()` não deve chamar incondicionalmente `saveCurrentFieldTestToHistory()`. A gravação só pode ocorrer quando houver uma ação explícita de salvar um teste novo e um rascunho marcado como pendente. A atualização do plano deve resolver a referência a partir do histórico fisiológico ativo.

Ao restaurar backup:

- limpar o rascunho transitório de teste;
- selecionar o último teste fisiológico válido como referência de leitura;
- não transformar o resultado histórico em um formulário de novo teste vazio;
- permitir recalcular o plano com o teste recuperado;
- preservar a lista original de testes e as zonas históricas;
- não exigir que o atleta repita um teste apenas porque o campo de entrada do novo teste está vazio.

### 3.2 Diferenciar a tela “último teste” da tela “novo teste”

A tela fisiológica deverá ter dois estados visuais claros:

**Estado de consulta:** mostrar o último teste salvo com data, método, resultado, VO₂máx, idade na data do teste, referência fisiológica, classificação e zonas de ritmo congeladas. Ações discretas: “Editar teste” e “Registrar novo teste”.

**Estado de novo teste:** mostrar os campos vazios somente depois de o usuário escolher “Registrar novo teste”. Nesse estado, o botão “Salvar teste” depende da validade da nova entrada. O abandono ou a restauração do backup não pode converter automaticamente um teste histórico válido em um erro de formulário.

### 3.3 Validar os dois protocolos corretamente

- Cooper: validar distância total entre 1,00 e 5,00 km, data válida e os dados demográficos exigidos para classificar o resultado.
- 3 km: validar tempo `mm:ss`, idade elegível e referência fisiológica; preservar `testDurationSeconds`.
- O prazo de até 56 dias deve ser requisito de entrada do teste novo no onboarding, não uma barreira para consultar ou editar um teste histórico antigo.
- A edição de um teste histórico pode manter a data original, mesmo que tenha mais de 56 dias.

### 3.4 Reidratação específica para Cooper e 3 km

Foi encontrada uma fragilidade adicional em `load()`: o fallback de zonas calcula `PaceCalculator.calculateCooper(distanceKm)` antes de considerar o método do teste. Para um registro `THREE_KM` sem `zoneRanges` legadas, a recuperação pode tentar tratar 3,0 km como resultado Cooper.

A V98 deve selecionar o cálculo conforme `testMethod`:

- `COOPER_12_MIN` → reconstrução Cooper a partir de `distanceKm`;
- `THREE_KM` → reconstrução de 3 km a partir de `testDurationSeconds`, idade e referência fisiológica armazenadas.

Quando o backup contém faixas congeladas válidas, elas devem ser preservadas; não devem ser substituídas silenciosamente por uma estimativa de outro protocolo.

### 3.5 Melhorar a mensagem de falha

A mensagem atual agrupa idade, sexo, distância e data, mesmo quando o problema é o rascunho vazio. Substituir por mensagens que identifiquem a origem:

- “O último teste salvo foi recuperado. O formulário de novo teste está vazio; isso não impede atualizar o plano.”
- “Não existe teste fisiológico válido no histórico. Registre Cooper ou 3 km para classificar o perfil.”
- “O novo teste está incompleto: informe a distância/tempo.”
- “A referência fisiológica do teste está ausente; confira o perfil ou vincule os dados históricos.”

O plano restaurado deve permanecer intacto caso a recalibração realmente não possa ser concluída.

---

## 4. Gestão do histórico de testes fisiológicos

### 4.1 Adicionar identificação estável ao teste

Atualmente `CooperAssessmentRecord` não possui um identificador próprio; a substituição é feita por data e método. Para suportar edição e exclusão segura, acrescentar:

- `recordId`: identificador estável e imutável;
- `deletedAtIso`: marca de exclusão lógica, opcional;
- `updatedAtIso`: data de última edição, opcional.

Para os registros antigos dos schemas 1–12, criar `recordId` determinístico durante a migração usando método, data e resultado original. Evitar IDs diferentes a cada inicialização.

### 4.2 Opções discretas em cada teste

Cada teste no histórico terá um único card com:

- data;
- método e resultado (Cooper: km em 12 min; 3 km: tempo);
- VO₂máx estimado;
- idade/referência fisiológica e nível;
- indicador de expansão para zonas e informações complementares.

Um menu discreto de três pontos deverá oferecer:

- **Editar teste**;
- **Excluir teste**.

A edição abrirá um diálogo compacto com método, data, resultado, idade na data do teste e referência fisiológica. Ao salvar, recalcular VO₂máx, pace médio e zonas de acordo com o método correto. A data antiga não deve ser bloqueada pelo limite de 56 dias reservado à entrada de um teste novo.

### 4.3 Exclusão segura e reversível

Adotar exclusão lógica, no mesmo padrão de segurança do histórico de treinos:

- marcar `deletedAtIso` sem apagar o registro do arquivo;
- retirar o teste excluído da escolha de referência fisiológica, evolução, calibração e comparações;
- disponibilizar seção “Testes removidos” com opção de restaurar;
- preservar o registro removido nos backups;
- só permitir exclusão definitiva após segunda confirmação.

Ao excluir o teste mais recente, o sistema deve procurar o teste ativo válido anterior. Se existir, usar esse teste como referência; se não existir, retornar para “Aguardando teste”. Nenhuma dessas operações deve reconstruir o plano automaticamente.

### 4.4 Efeito da edição ou exclusão sobre o plano

- Atualizar a referência fisiológica e zonas correntes a partir do teste ativo mais recente.
- Se a alteração mudar nível, objetivo permitido ou zonas de referência, marcar o plano como necessitando revisão.
- Preservar sessões concluídas, feedbacks, arquivos importados e datas reais.
- Não alterar treinos futuros até o usuário confirmar a atualização do plano.
- Se o teste usado como âncora da calibração adaptativa for editado, excluído ou substituído, reancorar a calibração no teste ativo correto e registrar a alteração no histórico de auditoria.
- Não apagar os snapshots das zonas congeladas em testes anteriores.

---

## 5. Plano de interface — histórico de treinos em card único

### 5.1 Remover a duplicação na origem

Substituir a composição atual de `WorkoutCard()` + `FeedbackHistoryDetails()` por um único componente, por exemplo `CompletedWorkoutHistoryCard()`.

A mesma sessão não pode gerar um card de resumo e outro card de detalhes. As informações devem residir dentro de um único `CardSurface` expansível.

### 5.2 Estrutura visual do card fechado

Cada card deve exibir somente as informações de consulta rápida:

1. ícone/tipo da sessão e status concluído;
2. título do treino;
3. data e horário real;
4. três métricas em linha: distância real, duração e ritmo médio.

Exemplo de hierarquia:

**Longão progressivo Z2** · ✓  
22/11/2026 · 18:05  
**6,1 km** · **44:25** · **7:15 min/km**

Quando não houver atividade medida, identificar explicitamente a distância como prevista/estimada, sem apresentá-la como distância real.

### 5.3 Expansão dentro do mesmo card

Ao tocar no card (ou no chevron), expandir a própria superfície para mostrar:

- esforço percebido e sensação;
- data planejada, quando diferente da data realizada;
- terreno e observações;
- origem da atividade e número de pontos GPS;
- elevação, cadência e parciais;
- tempo medido por zona;
- execução manual dos blocos e comparação com o ritmo proposto;
- alerta de dor, quando houver.

O card fechado deve continuar compacto. Os dados complementares não podem criar uma segunda caixa/card independente.

### 5.4 Ações sem desperdiçar espaço

Retirar a linha atual de botões com `Modifier.weight(1f)` e textos distribuídos pela largura. Usar menu de três pontos no canto superior direito, com ações contextuais:

- Editar registro;
- Vincular ao treino correto (quando aplicável);
- Remover do histórico;
- Restaurar (na seção removidos);
- Excluir definitivamente (somente para item já removido).

Manter os diálogos de confirmação e o comportamento atual de edição dos dados reais, sem perder rota, parciais, blocos ou metadados importados.

### 5.5 Lista, filtros e resumo do período

Adotar a referência do Pace Coach sem copiar sua identidade visual:

- filtros **Todos / Semana / Mês / Ano**;
- agrupamento por data de realização;
- resumo do período: quantidade de sessões, quilômetros medidos e duração acumulada;
- ordenação da mais recente para a mais antiga;
- um card por sessão/atividade;
- contagem sem duplicar a mesma sessão por ter Workout e Feedback associados.

Os filtros devem usar a data real da atividade (`feedbackActivityDate`), não apenas a data originalmente planejada. Cards sem distância/duração real não devem contaminar os totais medidos.

### 5.6 Registros arquivados e removidos

Os registros sem vínculo com o ciclo atual e os registros removidos também devem usar o mesmo padrão de card único. A seção pode ter rótulo e cor de status próprios, mas não deve voltar a separar resumo e detalhe em duas caixas.

---

## 6. Correção da apresentação do cadastro

A tela de cadastro deve distinguir três fontes de informação, em vez de misturá-las:

| Fonte | Rótulo correto | Regra |
|---|---|---|
| Campo preenchido pelo corredor | Base semanal declarada / Maior sessão declarada | É a referência prioritária do perfil e não muda sozinha |
| Catálogo do objetivo | Referência automática para o objetivo | Só é usada quando o respectivo campo estiver em branco |
| Histórico de atividades | Volume medido / Maior corrida medida | Exibido separadamente; só vira nova base após confirmação explícita |

Exemplo de apresentação quando os campos forem 16 km e 10 km e o catálogo do objetivo 5 km tiver referência 12 km e 3 km:

- **Sua base semanal declarada: 16 km**
- Referência automática do objetivo: 12 km (usada somente se a base declarada estiver vazia)
- **Sua maior sessão declarada: 10 km**
- Capacidade presumida do catálogo: 3 km (não é seu registro pessoal)

Ajustar os textos nas etapas 5 e 6 do onboarding. Remover a frase que sugere adoção automática do histórico medido. Exibir os valores reais através de `effectiveDisplayWeeklyKm()` e `effectiveDisplayLongestKm()` e apresentar os valores do catálogo em linha separada e claramente identificada.

Também garantir que a tela de edição do perfil não inicialize os campos com valores de fallback por cima dos campos declarados.

---

## 7. Arquivos e módulos envolvidos

| Arquivo | Alteração prevista |
|---|---|
| `MainActivity.kt` | Separar rascunho e histórico fisiológico; ajustar `createPlan()`; editar/excluir testes; rever consumo de testes ativos; corrigir textos do cadastro; criar card unificado do histórico; filtros e resumo |
| `CooperAssessmentEngine.kt` | Gestão de identidade, validação por método, edição, exclusão lógica e restauração de teste |
| `AppBackupManager.kt` / `AppBackupCodec` | Schema 13, migração dos testes antigos, validação semântica e preservação de registros removidos |
| `CooperAssessmentEngineTest.kt` | Testes de edição, exclusão, restauração, datas antigas e métodos Cooper/3 km |
| `AppBackupCodecTest.kt` | Round-trip com IDs, tombstones e migração dos schemas 1–12 |
| Novo `CooperAssessmentManagementEngineTest.kt` | Testes isolados de CRUD e seleção da referência fisiológica ativa |
| Novo `WorkoutHistoryPresentationTest.kt` (ou equivalente) | Testes de agrupamento, período, métricas e prevenção de duplicidade |
| `BUILD_STATUS_V98.md`, `TEST_REPORT_V98.md`, `CHANGELOG.md`, `PROJECT_STATUS.md` | Registro de versão, testes e limitações de build |

---

## 8. Testes obrigatórios de aprovação

### Backup e fisiologia

1. Criar backup V97 com Cooper de 2,1 km, 12 min, 11/10/2026, VO₂máx 35,6, idade 36, referência masculina e zonas.
2. Restaurar em V98 e confirmar que o registro permanece idêntico no histórico.
3. Com o campo de novo Cooper vazio, recalcular o plano sem erro; o motor usa o teste salvo.
4. Repetir com teste de 3 km e tempo salvo.
5. Restaurar backup V97 exportado enquanto a tela de novo teste estava aberta e com campos vazios; o rascunho não deve bloquear o plano.
6. Registrar novo Cooper incompleto: botão desabilitado ou erro pontual; não substituir o teste anterior.
7. Registrar novo teste válido: salvar histórico e somente então atualizar a referência do atleta.
8. Testar backups de todos os schemas 1–12; gerar novo backup schema 13 e confirmar round-trip de testes ativos e removidos.
9. Testar registro 3 km legado sem zonas congeladas: reconstruir pelo tempo de 3 km, nunca pela fórmula Cooper.

### Edição e exclusão de testes

10. Editar distância/tempo, data, idade e referência; recalcular VO₂máx e zonas pelo método certo.
11. Editar teste histórico com mais de 56 dias; não bloquear por regra de entrada de teste novo.
12. Excluir logicamente o último teste e confirmar seleção do teste ativo anterior.
13. Excluir o único teste e confirmar estado “Aguardando teste”, sem apagar sessões concluídas.
14. Restaurar teste removido e confirmar que volta a participar das comparações.
15. Confirmar que edição/exclusão não atualiza o plano sem autorização.
16. Confirmar que snapshots de zonas de testes antigos permanecem intactos.

### Cadastro e histórico de treinos

17. Abrir/editar cadastro com base 16 km e maior sessão 10 km; conferir que os campos continuam 16/10.
18. Mostrar referência padrão 12/3 separadamente, sem apresentá-la como dado real do corredor.
19. Confirmar que o texto não sugere adoção automática da média do histórico.
20. Com seis sessões concluídas, exibir seis cards, nunca doze.
21. Conferir card fechado com distância, duração e pace em uma só superfície.
22. Expandir e recolher detalhes sem criar um segundo card.
23. Editar e remover feedback pelo menu discreto; restaurar item removido.
24. Manter parciais, rota, cadência, elevação, blocos e metadados importados após editar outros campos.
25. Testar filtros Todos/Semana/Mês/Ano, agrupamento por data e totais sem duplicatas.
26. Testar registros arquivados e removidos no mesmo componente visual.

### Build e regressão

27. Executar suíte Kotlin/JVM e testes de backup.
28. Executar build Android e testes instrumentados disponíveis no GitHub Actions.
29. Confirmar instalação/atualização no Android 16.
30. Verificar exportação e restauração real no aparelho, com o plano e o histórico anteriores preservados.

---

## 9. Critérios de aceite da V98

A V98 só deve ser considerada concluída quando:

- restaurar backup e atualizar o plano sem exigir que o formulário de um novo teste esteja preenchido, desde que exista teste histórico válido;
- o teste fisiológico puder ser editado e excluído de maneira segura e reversível;
- edição ou exclusão selecionar corretamente a referência fisiológica ativa e não recalcular o plano sem confirmação;
- o cadastro mostrar separadamente valores declarados, referências automáticas e histórico medido;
- cada sessão concluída aparecer em exatamente um card;
- detalhes e ações forem acessíveis sem uma segunda caixa e sem a linha de botões desperdiçar a largura;
- todos os dados de backups V97 e anteriores permanecerem legíveis;
- testes e build oficial passarem.

## 10. Parecer final

A prioridade máxima é corrigir a separação entre **teste fisiológico salvo** e **formulário de novo teste**. O resultado Cooper está presente no histórico da imagem; o recálculo falha porque a geração do plano valida um campo de entrada vazio como se o atleta estivesse tentando registrar um teste naquele momento.

Em paralelo, a tela de histórico precisa ser reorganizada na origem: a duplicação não é um problema de espaçamento isolado, mas o resultado direto de dois componentes completos renderizados para a mesma sessão. A V98 deve substituir essa estrutura por um único card com métricas essenciais, expansão interna e ações discretas.

**Status final:** auditoria da V97 concluída; plano detalhado V98 elaborado. Implementação ainda não realizada.
