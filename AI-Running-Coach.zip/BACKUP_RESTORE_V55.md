# Contrato de backup e restauração — V55

## Fonte de verdade

O backup é a fonte autoritativa para todo o histórico anterior à data da restauração. A migração preserva as sessões que realmente estão no arquivo (concluídas, pendentes e com feedback), sem fabricar sessões anteriores ausentes. Uma segunda-feira passada que não tinha treino no backup continua sem treino depois da importação.

## Reconstrução do futuro

Quando `engineVersion` exige migração e o perfil está completo, o motor recupera a âncora da semana 1 a partir de `planStartDateIso` e, quando necessário, cruza as datas com o número `week` de cada sessão. O ciclo original e `planWeeks` são mantidos. O motor gera novamente apenas sessões de hoje em diante, dentro da janela original; sessões passadas nunca entram no conjunto de candidatos.

As sessões antigas existentes são mescladas com a programação atual/futura por `sessionId`. Feedbacks continuam vinculados à sessão e marcam como concluído quando aplicável. Sessões extras futuras pendentes permanecem preservadas quando não colidem com uma sessão principal gerada.

## Segurança e integridade

O backup schema 2 conserva SHA-256 sobre preferências tipadas canonizadas e o manifesto de contagens. A integridade é verificada antes de limpar as preferências locais. Schema 1 permanece aceito para compatibilidade. O identificador do aplicativo exportador é `V55`; a atualização do código do app não altera o schema porque não houve mudança na estrutura de persistência.

## Teste de aceitação recomendado

1. Exporte backup que contenha duas sessões na semana 1, por exemplo quarta e sexta, mas nenhuma na segunda.
2. Restaure em V55 com um ciclo ainda ativo.
3. Confirme que quarta/sexta continuam no histórico, segunda passada continua vazia, e a semana seguinte recebe apenas as sessões futuras recalculadas.
4. Confirme que a semana 1 continua começando na segunda-feira original e que a duração do ciclo é a mesma do backup.

