# AI Running Coach Android V15 — Interfaces

V15 implements the complete approved interface model in one Android/Jetpack Compose build.

Scope: prescription only. The app does NOT execute workouts, track GPS, provide a workout timer, or provide live audio. Prescriptions are prepared for export to Pace Coach, which remains the execution app.

Implemented screens:
1 Splash / onboarding welcome
2 Objective
3 Experience level
4 Frequency
5 Current volume / availability
6 Profile summary
7 Dashboard
8 Calendar
9 Workout details
10 Workout structure
11 Training plan
12 Evolution
13 Post-workout feedback
14 History
15 Profile / Settings
16 Export to Pace Coach

This version uses local mock data for the interface flow. The backend/Core integration remains a separate layer and can be wired after visual approval/corrections.
