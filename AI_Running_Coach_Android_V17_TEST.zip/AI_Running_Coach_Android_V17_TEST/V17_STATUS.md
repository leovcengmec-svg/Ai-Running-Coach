# AI Running Coach Android V17 — TESTE

Versão preparada para o primeiro teste real no Android.

## Escopo
- Aplicativo exclusivamente de prescrição inteligente.
- Sem execução de treino, cronômetro, GPS ou áudio de execução.
- Interfaces aprovadas reunidas na mesma versão.
- Fluxo de onboarding → dashboard → calendário → detalhes → estrutura → plano → evolução → feedback → histórico → perfil → exportação.
- Prescrição preparada para transferência ao Pace Coach.
- GitHub Actions gera APK Debug automaticamente.
- versionCode 17 / versionName 17.0.0.

## Observação
Esta é a versão de teste funcional da camada Android. O objetivo desta etapa é instalar, navegar por todas as telas e validar o fluxo visual/interativo. A integração de produção entre o motor de decisão e a persistência será consolidada nas próximas etapas sem alterar a separação entre AI Running Coach e Pace Coach.
