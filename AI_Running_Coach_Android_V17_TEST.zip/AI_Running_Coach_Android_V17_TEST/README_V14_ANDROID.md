# AI Running Coach V14 — Android

V14 inicia a camada Android nativa do AI Running Coach. O projeto é separado do Pace Coach.

## Tecnologia
- Kotlin
- Jetpack Compose
- Android Gradle Plugin 9.4.0
- Gradle 9.6
- Compose BOM 2026.09.00
- minSdk 26 / targetSdk 37

As versões seguem a documentação oficial atual do Android/Jetpack Compose em setembro de 2026.

## Arquitetura
Android UI → API → Application Service → Core V11 → Banco.

A interface não duplica as regras fisiológicas e não escolhe treinos por conta própria.

## Backend
O V13 continua sendo o backend atual. O app usa por padrão `http://10.0.2.2:8080` para emulador Android. Em produção, substituir pelo endereço HTTPS do backend.

## Abrir
Abra a pasta `android/` no Android Studio e faça Sync Gradle. Depois execute no emulador ou aparelho Android.

## Observação
Esta V14 entrega o projeto Android nativo e a primeira integração com onboarding. A geração de APK/AAB depende de um ambiente Android SDK/Gradle configurado; este ambiente de trabalho não possui o SDK Android instalado, portanto o APK não foi alegado como compilado aqui.
