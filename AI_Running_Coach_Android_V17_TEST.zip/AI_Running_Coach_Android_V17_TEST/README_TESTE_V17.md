# TESTE DA V17

## Gerar o APK
1. Crie um repositório vazio no GitHub.
2. Envie o conteúdo desta pasta para a branch `main`.
3. Abra **Actions**.
4. Execute **Android APK** → **Run workflow**.
5. Ao terminar, abra a execução e procure **Artifacts**.
6. Baixe `ai-running-coach-debug-apk`.
7. Extraia o ZIP e instale o APK no Android.

## O que validar
- abertura do aplicativo;
- onboarding;
- criação do perfil;
- dashboard;
- calendário;
- abertura de treino;
- estrutura do treino;
- plano;
- evolução;
- feedback;
- histórico;
- perfil;
- exportação para Pace Coach;
- navegação e ausência de telas de execução.

## Regra do projeto
O AI Running Coach prescreve. O Pace Coach executa.
