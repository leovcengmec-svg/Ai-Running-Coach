# AI Running Coach Android V16 — Status

V16 prepara o projeto Android para compilação automática no GitHub Actions.

Incluído:
- workflow de APK debug;
- workflow manual de APK release não assinado;
- Java 21;
- Android SDK configurado no CI;
- Gradle 9.6 no CI;
- artifact automático do APK;
- `.gitignore` para projeto Android;
- instruções de publicação e download do APK;
- versionCode 16 / versionName 16.0.0.

A V15 e a referência visual aprovada foram preservadas.

Observação: o workflow de release ainda não assina o APK. A assinatura será configurada quando formos preparar uma versão instalável/distribuível definitiva.
